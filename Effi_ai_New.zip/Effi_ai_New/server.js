
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static('.'));
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

app.post('/send-text', (req, res) => {
    const text = req.body.text;
    fs.appendFileSync('session_log.txt', `[טקסט]: ${text}\n`);
    res.sendStatus(200);
});

app.post('/upload', upload.single('file'), (req, res) => {
    const tempPath = req.file.path;
    const targetPath = path.join('uploads', req.file.originalname);
    fs.renameSync(tempPath, targetPath);
    fs.appendFileSync('session_log.txt', `[קובץ]: ${targetPath}\n`);
    res.sendStatus(200);
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
