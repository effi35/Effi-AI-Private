
// כאן תוכל להדביק את מפתח ה־API שלך מ־Claude
const CLAUDE_API_KEY = "your-api-key-here";
