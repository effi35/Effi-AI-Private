/**
 * 🔧 Effi-AI System Settings Validator
 * מערכת ולידציה של הגדרות מערכת
 * Version: 1.0.0
 */

class SystemSettingsValidator {
    constructor() {
        this.validationRules = new Map();
        this.settingsCache = new Map();
        this.validationResults = new Map();
        
        this.initializeValidationRules();
        console.log('🔧 System Settings Validator initialized');
    }

    /**
     * אתחול כללי ולידציה
     */
    initializeValidationRules() {
        // כללי ולידציה לבסיס נתונים
        this.validationRules.set('database', {
            host: { required: true, type: 'string', pattern: /^[\w\.-]+$/ },
            port: { required: true, type: 'number', min: 1, max: 65535 },
            username: { required: true, type: 'string', minLength: 3 },
            password: { required: true, type: 'string', minLength: 6 },
            database: { required: true, type: 'string', pattern: /^[a-zA-Z0-9_]+$/ }
        });

        // כללי ולידציה למערכת AI
        this.validationRules.set('ai_system', {
            defaultEngine: { required: true, type: 'string', enum: ['private', 'commercial', 'python'] },
            maxTokens: { required: true, type: 'number', min: 100, max: 8000 },
            temperature: { required: true, type: 'number', min: 0, max: 2 },
            timeout: { required: true, type: 'number', min: 5000, max: 120000 }
        });

        // כללי ולידציה לרשת
        this.validationRules.set('network', {
            maxConnections: { required: true, type: 'number', min: 10, max: 100000 },
            timeout: { required: true, type: 'number', min: 1000, max: 60000 },
            retryAttempts: { required: true, type: 'number', min: 1, max: 10 },
            proxy: { required: false, type: 'string', pattern: /^https?:\/\/.+/ }
        });

        // כללי ולידציה לאבטחה
        this.validationRules.set('security', {
            encryptionEnabled: { required: true, type: 'boolean' },
            sessionTimeout: { required: true, type: 'number', min: 300, max: 86400 },
            maxLoginAttempts: { required: true, type: 'number', min: 3, max: 10 },
            twoFactorEnabled: { required: false, type: 'boolean' }
        });

        // כללי ולידציה לביצועים
        this.validationRules.set('performance', {
            cacheSize: { required: true, type: 'number', min: 10, max: 1000 },
            maxMemoryUsage: { required: true, type: 'number', min: 100, max: 8192 },
            enableOptimization: { required: true, type: 'boolean' },
            compressionLevel: { required: false, type: 'number', min: 1, max: 9 }
        });

        // כללי ולידציה למערכת גיבויים
        this.validationRules.set('backup', {
            enabled: { required: true, type: 'boolean' },
            interval: { required: true, type: 'number', min: 3600, max: 604800 },
            maxBackups: { required: true, type: 'number', min: 1, max: 100 },
            compressionEnabled: { required: false, type: 'boolean' }
        });
    }

    /**
     * ולידציה של הגדרות מערכת
     */
    validateSystemSettings(settings = {}) {
        console.log('🔍 Validating system settings...');
        
        const validationResult = {
            isValid: true,
            errors: [],
            warnings: [],
            sections: {}
        };

        // ולידציה לפי חלקים
        for (const [sectionName, sectionRules] of this.validationRules) {
            const sectionSettings = settings[sectionName] || {};
            const sectionResult = this.validateSection(sectionName, sectionSettings, sectionRules);
            
            validationResult.sections[sectionName] = sectionResult;
            
            if (!sectionResult.isValid) {
                validationResult.isValid = false;
                validationResult.errors.push(...sectionResult.errors.map(e => `${sectionName}: ${e}`));
            }
            
            if (sectionResult.warnings.length > 0) {
                validationResult.warnings.push(...sectionResult.warnings.map(w => `${sectionName}: ${w}`));
            }
        }

        // בדיקות צולבות
        this.performCrossValidation(settings, validationResult);

        // שמירת תוצאות
        this.validationResults.set('latest', validationResult);
        
        // רישום בזיכרון
        if (window.EffiMemory) {
            window.EffiMemory.learn({
                type: 'settings_validation',
                result: validationResult,
                timestamp: Date.now()
            }, {
                system: 'settings_validator',
                valid: validationResult.isValid
            });
        }

        console.log(`✅ Settings validation complete - ${validationResult.isValid ? 'VALID' : 'INVALID'}`);
        return validationResult;
    }

    /**
     * ולידציה של חלק ספציפי
     */
    validateSection(sectionName, sectionSettings, rules) {
        const result = {
            isValid: true,
            errors: [],
            warnings: [],
            fields: {}
        };

        for (const [fieldName, rule] of Object.entries(rules)) {
            const fieldValue = sectionSettings[fieldName];
            const fieldResult = this.validateField(fieldName, fieldValue, rule);
            
            result.fields[fieldName] = fieldResult;
            
            if (!fieldResult.isValid) {
                result.isValid = false;
                result.errors.push(fieldResult.error);
            }
            
            if (fieldResult.warning) {
                result.warnings.push(fieldResult.warning);
            }
        }

        return result;
    }

    /**
     * ולידציה של שדה ספציפי
     */
    validateField(fieldName, value, rule) {
        const result = {
            isValid: true,
            error: null,
            warning: null
        };

        // בדיקת נדרש
        if (rule.required && (value === undefined || value === null || value === '')) {
            result.isValid = false;
            result.error = `שדה '${fieldName}' נדרש`;
            return result;
        }

        // אם השדה לא נדרש וריק, דלג
        if (!rule.required && (value === undefined || value === null || value === '')) {
            return result;
        }

        // בדיקת סוג
        if (rule.type && !this.validateType(value, rule.type)) {
            result.isValid = false;
            result.error = `שדה '${fieldName}' חייב להיות מסוג ${rule.type}`;
            return result;
        }

        // בדיקת טווח מספרי
        if (rule.type === 'number') {
            if (rule.min !== undefined && value < rule.min) {
                result.isValid = false;
                result.error = `שדה '${fieldName}' חייב להיות לפחות ${rule.min}`;
                return result;
            }
            
            if (rule.max !== undefined && value > rule.max) {
                result.isValid = false;
                result.error = `שדה '${fieldName}' חייב להיות לכל היותר ${rule.max}`;
                return result;
            }
        }

        // בדיקת אורך מחרוזת
        if (rule.type === 'string') {
            if (rule.minLength !== undefined && value.length < rule.minLength) {
                result.isValid = false;
                result.error = `שדה '${fieldName}' חייב להכיל לפחות ${rule.minLength} תווים`;
                return result;
            }
            
            if (rule.maxLength !== undefined && value.length > rule.maxLength) {
                result.isValid = false;
                result.error = `שדה '${fieldName}' חייב להכיל לכל היותר ${rule.maxLength} תווים`;
                return result;
            }
        }

        // בדיקת תבנית
        if (rule.pattern && !rule.pattern.test(value)) {
            result.isValid = false;
            result.error = `שדה '${fieldName}' אינו תואם את התבנית הנדרשת`;
            return result;
        }

        // בדיקת רשימת ערכים מותרים
        if (rule.enum && !rule.enum.includes(value)) {
            result.isValid = false;
            result.error = `שדה '${fieldName}' חייב להיות אחד מהערכים: ${rule.enum.join(', ')}`;
            return result;
        }

        // בדיקות אזהרה
        if (rule.type === 'number') {
            const mid = ((rule.min || 0) + (rule.max || 100)) / 2;
            if (value < rule.min * 1.5 || value > rule.max * 0.8) {
                result.warning = `ערך '${fieldName}' נמצא בקצה הטווח המותר`;
            }
        }

        return result;
    }

    /**
     * בדיקת סוג נתונים
     */
    validateType(value, expectedType) {
        switch (expectedType) {
            case 'string':
                return typeof value === 'string';
            case 'number':
                return typeof value === 'number' && !isNaN(value);
            case 'boolean':
                return typeof value === 'boolean';
            case 'array':
                return Array.isArray(value);
            case 'object':
                return typeof value === 'object' && value !== null && !Array.isArray(value);
            default:
                return true;
        }
    }

    /**
     * בדיקות צולבות בין חלקים
     */
    performCrossValidation(settings, validationResult) {
        // בדיקה שזמן session timeout קטן מזמן backup interval
        const security = settings.security || {};
        const backup = settings.backup || {};
        
        if (security.sessionTimeout && backup.interval && 
            security.sessionTimeout > backup.interval) {
            validationResult.warnings.push('זמן session timeout גדול מזמן גיבוי - עלול לגרום לבעיות');
        }

        // בדיקה שמספר connections לא גדול מגבול זיכרון
        const network = settings.network || {};
        const performance = settings.performance || {};
        
        if (network.maxConnections && performance.maxMemoryUsage) {
            const estimatedMemory = network.maxConnections * 0.1; // 0.1MB per connection estimate
            if (estimatedMemory > performance.maxMemoryUsage * 0.8) {
                validationResult.warnings.push('מספר חיבורים מוגדר גבוה יחסית לזיכרון זמין');
            }
        }

        // בדיקה שAI timeout קטן מnetwork timeout
        const aiSystem = settings.ai_system || {};
        if (aiSystem.timeout && network.timeout && 
            aiSystem.timeout > network.timeout) {
            validationResult.warnings.push('זמן timeout של AI גדול מzמן timeout של רשת');
        }
    }

    /**
     * קבלת הגדרות ברירת מחדל
     */
    getDefaultSettings() {
        return {
            database: {
                host: 'localhost',
                port: 5432,
                username: 'effi_user',
                password: 'secure_password_123',
                database: 'effi_ai_db'
            },
            ai_system: {
                defaultEngine: 'private',
                maxTokens: 4000,
                temperature: 0.9,
                timeout: 30000
            },
            network: {
                maxConnections: 1000,
                timeout: 15000,
                retryAttempts: 3,
                proxy: ''
            },
            security: {
                encryptionEnabled: true,
                sessionTimeout: 3600,
                maxLoginAttempts: 5,
                twoFactorEnabled: false
            },
            performance: {
                cacheSize: 100,
                maxMemoryUsage: 1024,
                enableOptimization: true,
                compressionLevel: 6
            },
            backup: {
                enabled: true,
                interval: 86400,
                maxBackups: 7,
                compressionEnabled: true
            }
        };
    }

    /**
     * שחזור הגדרות מLocalStorage
     */
    loadSettingsFromStorage() {
        try {
            const stored = localStorage.getItem('effi-ai-system-settings');
            if (stored) {
                const settings = JSON.parse(stored);
                console.log('⚙️ Settings loaded from storage');
                return settings;
            }
        } catch (error) {
            console.warn('Could not load settings from storage:', error);
        }
        return this.getDefaultSettings();
    }

    /**
     * שמירת הגדרות ב-LocalStorage
     */
    saveSettingsToStorage(settings) {
        try {
            localStorage.setItem('effi-ai-system-settings', JSON.stringify(settings));
            console.log('💾 Settings saved to storage');
            return true;
        } catch (error) {
            console.error('Could not save settings to storage:', error);
            return false;
        }
    }

    /**
     * יצוא הגדרות לקובץ
     */
    exportSettings(format = 'json') {
        const settings = this.loadSettingsFromStorage();
        const exportData = {
            version: '1.0.0',
            timestamp: Date.now(),
            settings,
            validation: this.validateSystemSettings(settings)
        };

        if (format === 'json') {
            return JSON.stringify(exportData, null, 2);
        } else if (format === 'yaml') {
            return this.convertToYAML(exportData);
        }
        
        return exportData;
    }

    /**
     * יבוא הגדרות מקובץ
     */
    importSettings(data, validate = true) {
        try {
            const importData = typeof data === 'string' ? JSON.parse(data) : data;
            const settings = importData.settings || importData;

            if (validate) {
                const validation = this.validateSystemSettings(settings);
                if (!validation.isValid) {
                    console.error('Settings validation failed:', validation.errors);
                    return { success: false, errors: validation.errors };
                }
            }

            this.saveSettingsToStorage(settings);
            console.log('✅ Settings imported successfully');
            return { success: true, settings };
            
        } catch (error) {
            console.error('Failed to import settings:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * המרה ל-YAML
     */
    convertToYAML(obj, indent = 0) {
        let yaml = '';
        const spacing = '  '.repeat(indent);
        
        for (const [key, value] of Object.entries(obj)) {
            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                yaml += `${spacing}${key}:\n`;
                yaml += this.convertToYAML(value, indent + 1);
            } else if (Array.isArray(value)) {
                yaml += `${spacing}${key}:\n`;
                for (const item of value) {
                    yaml += `${spacing}  - ${item}\n`;
                }
            } else {
                yaml += `${spacing}${key}: ${value}\n`;
            }
        }
        
        return yaml;
    }

    /**
     * בדיקת תקינות הגדרות בזמן אמת
     */
    validateRealTime(section, field, value) {
        const rules = this.validationRules.get(section);
        if (!rules || !rules[field]) {
            return { isValid: true };
        }

        return this.validateField(field, value, rules[field]);
    }

    /**
     * קבלת סטטיסטיקות ולידציה
     */
    getValidationStats() {
        const latest = this.validationResults.get('latest');
        if (!latest) {
            return { message: 'No validation performed yet' };
        }

        const stats = {
            overall: {
                isValid: latest.isValid,
                totalErrors: latest.errors.length,
                totalWarnings: latest.warnings.length
            },
            sections: {}
        };

        for (const [sectionName, sectionResult] of Object.entries(latest.sections)) {
            stats.sections[sectionName] = {
                isValid: sectionResult.isValid,
                errors: sectionResult.errors.length,
                warnings: sectionResult.warnings.length,
                fieldsValidated: Object.keys(sectionResult.fields).length
            };
        }

        return stats;
    }
}

// יצירת מופע גלובלי
window.SystemSettingsValidator = new SystemSettingsValidator();

// פונקציה גלובלית לולידציה
window.validateSystemSettings = function(settings) {
    return window.SystemSettingsValidator.validateSystemSettings(settings);
};

// רישום במערכת המודולרית
if (window.EffiModular) {
    window.EffiModular.registerModule('settings_validator', window.SystemSettingsValidator, [], {
        version: '1.0.0',
        category: 'core',
        priority: 'high'
    });
}

console.log('🔧 System Settings Validator loaded successfully!');