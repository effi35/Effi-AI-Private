const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

/**
 * Enterprise Government Security Manager
 * AES-256 Encryption, JWT Authentication, MFA, Security Auditing
 */
class GovernmentSecurityManager {
    constructor() {
        this.algorithm = 'aes-256-gcm';
        this.keyLength = 32;
        this.ivLength = 16;
        this.tagLength = 16;
        
        // Initialize encryption keys
        this.masterKey = process.env.ENCRYPTION_KEY || this.generateSecureKey();
        this.jwtSecret = process.env.JWT_SECRET || this.generateSecureKey();
        
        // Security audit log
        this.auditLog = [];
        this.maxAuditEntries = 10000;
        
        // Failed login tracking
        this.failedLogins = new Map();
        this.maxFailedAttempts = 5;
        this.lockoutDuration = 15 * 60 * 1000; // 15 minutes
        
        // Session management
        this.activeSessions = new Map();
        this.sessionTimeout = 24 * 60 * 60 * 1000; // 24 hours
        
        console.log('🔐 Government Security Manager initialized with maximum security');
    }
    
    /**
     * Generate cryptographically secure random key
     */
    generateSecureKey() {
        return crypto.randomBytes(this.keyLength).toString('hex');
    }
    
    /**
     * AES-256-GCM Encryption
     */
    encrypt(plaintext, additionalData = '') {
        try {
            const iv = crypto.randomBytes(this.ivLength);
            const cipher = crypto.createCipher(this.algorithm, this.masterKey);
            
            if (additionalData) {
                cipher.setAAD(Buffer.from(additionalData));
            }
            
            let encrypted = cipher.update(plaintext, 'utf8', 'hex');
            encrypted += cipher.final('hex');
            
            const tag = cipher.getAuthTag();
            
            const result = {
                encrypted,
                iv: iv.toString('hex'),
                tag: tag.toString('hex'),
                algorithm: this.algorithm
            };
            
            this.logSecurityEvent('encryption', 'Data encrypted successfully', {
                dataSize: plaintext.length,
                hasAdditionalData: !!additionalData
            });
            
            return JSON.stringify(result);
            
        } catch (error) {
            this.logSecurityEvent('encryption_error', 'Encryption failed', { error: error.message });
            throw new Error('Encryption failed');
        }
    }
    
    /**
     * AES-256-GCM Decryption
     */
    decrypt(encryptedData, additionalData = '') {
        try {
            const data = JSON.parse(encryptedData);
            const decipher = crypto.createDecipher(data.algorithm, this.masterKey);
            
            if (additionalData) {
                decipher.setAAD(Buffer.from(additionalData));
            }
            
            decipher.setAuthTag(Buffer.from(data.tag, 'hex'));
            
            let decrypted = decipher.update(data.encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            
            this.logSecurityEvent('decryption', 'Data decrypted successfully');
            
            return decrypted;
            
        } catch (error) {
            this.logSecurityEvent('decryption_error', 'Decryption failed', { error: error.message });
            throw new Error('Decryption failed');
        }
    }
    
    /**
     * Hash password with bcrypt
     */
    async hashPassword(password) {
        try {
            const saltRounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
            const hash = await bcrypt.hash(password, saltRounds);
            
            this.logSecurityEvent('password_hash', 'Password hashed successfully', {
                saltRounds,
                algorithm: 'bcrypt'
            });
            
            return hash;
        } catch (error) {
            this.logSecurityEvent('password_hash_error', 'Password hashing failed', { error: error.message });
            throw new Error('Password hashing failed');
        }
    }
    
    /**
     * Verify password
     */
    async verifyPassword(password, hash) {
        try {
            const isValid = await bcrypt.compare(password, hash);
            
            this.logSecurityEvent('password_verify', 'Password verification completed', {
                result: isValid ? 'valid' : 'invalid'
            });
            
            return isValid;
        } catch (error) {
            this.logSecurityEvent('password_verify_error', 'Password verification failed', { error: error.message });
            throw new Error('Password verification failed');
        }
    }
    
    /**
     * Generate JWT tokens with government-grade security
     */
    generateJWTTokens(payload) {
        try {
            const accessTokenPayload = {
                ...payload,
                type: 'access',
                iat: Math.floor(Date.now() / 1000),
                security_level: 'maximum'
            };
            
            const refreshTokenPayload = {
                ...payload,
                type: 'refresh',
                iat: Math.floor(Date.now() / 1000),
                security_level: 'maximum'
            };
            
            const accessToken = jwt.sign(
                accessTokenPayload,
                this.jwtSecret,
                { 
                    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
                    algorithm: 'HS256',
                    issuer: 'effi-gov-system',
                    audience: 'effi-gov-users'
                }
            );
            
            const refreshToken = jwt.sign(
                refreshTokenPayload,
                process.env.JWT_REFRESH_SECRET || this.generateSecureKey(),
                { 
                    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
                    algorithm: 'HS256',
                    issuer: 'effi-gov-system',
                    audience: 'effi-gov-users'
                }
            );
            
            this.logSecurityEvent('jwt_generate', 'JWT tokens generated', {
                userId: payload.id,
                userType: payload.userType
            });
            
            return { accessToken, refreshToken };
            
        } catch (error) {
            this.logSecurityEvent('jwt_generate_error', 'JWT generation failed', { error: error.message });
            throw new Error('JWT generation failed');
        }
    }
    
    /**
     * Verify JWT token
     */
    verifyJWTToken(token, type = 'access') {
        try {
            const secret = type === 'refresh' 
                ? process.env.JWT_REFRESH_SECRET || this.generateSecureKey()
                : this.jwtSecret;
            
            const decoded = jwt.verify(token, secret, {
                algorithms: ['HS256'],
                issuer: 'effi-gov-system',
                audience: 'effi-gov-users'
            });
            
            this.logSecurityEvent('jwt_verify', 'JWT token verified', {
                userId: decoded.id,
                tokenType: decoded.type,
                userType: decoded.userType
            });
            
            return decoded;
            
        } catch (error) {
            this.logSecurityEvent('jwt_verify_error', 'JWT verification failed', {
                error: error.message,
                tokenType: type
            });
            throw new Error('Invalid or expired token');
        }
    }
    
    /**
     * Check for account lockout due to failed login attempts
     */
    checkAccountLockout(identifier) {
        const failedAttempts = this.failedLogins.get(identifier);
        
        if (!failedAttempts) {
            return { locked: false };
        }
        
        if (failedAttempts.count >= this.maxFailedAttempts) {
            const timeSinceLastAttempt = Date.now() - failedAttempts.lastAttempt;
            
            if (timeSinceLastAttempt < this.lockoutDuration) {
                const remainingTime = this.lockoutDuration - timeSinceLastAttempt;
                
                this.logSecurityEvent('account_locked', 'Account access blocked due to failed attempts', {
                    identifier,
                    attempts: failedAttempts.count,
                    remainingLockTime: remainingTime
                });
                
                return {
                    locked: true,
                    remainingTime: Math.ceil(remainingTime / 1000 / 60), // minutes
                    reason: 'Too many failed login attempts'
                };
            } else {
                // Lockout period expired, reset counter
                this.failedLogins.delete(identifier);
                return { locked: false };
            }
        }
        
        return { locked: false };
    }
    
    /**
     * Record failed login attempt
     */
    recordFailedLogin(identifier, details = {}) {
        const existing = this.failedLogins.get(identifier) || { count: 0, firstAttempt: Date.now() };
        
        existing.count++;
        existing.lastAttempt = Date.now();
        
        this.failedLogins.set(identifier, existing);
        
        this.logSecurityEvent('failed_login', 'Failed login attempt recorded', {
            identifier,
            attemptCount: existing.count,
            ...details
        });
        
        return existing;
    }
    
    /**
     * Clear failed login attempts (on successful login)
     */
    clearFailedLogins(identifier) {
        if (this.failedLogins.has(identifier)) {
            this.failedLogins.delete(identifier);
            this.logSecurityEvent('failed_login_cleared', 'Failed login attempts cleared', { identifier });
        }
    }
    
    /**
     * Session Management
     */
    createSession(userId, userType, metadata = {}) {
        const sessionId = crypto.randomUUID();
        const session = {
            id: sessionId,
            userId,
            userType,
            createdAt: new Date(),
            lastActivity: new Date(),
            expiresAt: new Date(Date.now() + this.sessionTimeout),
            metadata,
            isActive: true
        };
        
        this.activeSessions.set(sessionId, session);
        
        this.logSecurityEvent('session_create', 'Session created', {
            sessionId,
            userId,
            userType
        });
        
        return session;
    }
    
    /**
     * Validate session
     */
    validateSession(sessionId) {
        const session = this.activeSessions.get(sessionId);
        
        if (!session) {
            this.logSecurityEvent('session_invalid', 'Session not found', { sessionId });
            return null;
        }
        
        if (!session.isActive || new Date() > session.expiresAt) {
            this.activeSessions.delete(sessionId);
            this.logSecurityEvent('session_expired', 'Session expired', { sessionId });
            return null;
        }
        
        // Update last activity
        session.lastActivity = new Date();
        this.activeSessions.set(sessionId, session);
        
        return session;
    }
    
    /**
     * Destroy session
     */
    destroySession(sessionId) {
        const session = this.activeSessions.get(sessionId);
        if (session) {
            this.activeSessions.delete(sessionId);
            this.logSecurityEvent('session_destroy', 'Session destroyed', {
                sessionId,
                userId: session.userId
            });
            return true;
        }
        return false;
    }
    
    /**
     * Multi-Factor Authentication - Generate TOTP secret
     */
    generateMFASecret(userId) {
        const secret = crypto.randomBytes(20).toString('base32');
        
        this.logSecurityEvent('mfa_secret_generate', 'MFA secret generated', { userId });
        
        return {
            secret,
            qrCode: `otpauth://totp/Effi-Gov:${userId}?secret=${secret}&issuer=Effi-Government-System`
        };
    }
    
    /**
     * Security audit logging
     */
    logSecurityEvent(event, message, metadata = {}) {
        const logEntry = {
            id: crypto.randomUUID(),
            timestamp: new Date(),
            event,
            message,
            metadata,
            level: this.getEventLevel(event)
        };
        
        this.auditLog.push(logEntry);
        
        // Keep log size manageable
        if (this.auditLog.length > this.maxAuditEntries) {
            this.auditLog = this.auditLog.slice(-this.maxAuditEntries / 2);
        }
        
        // Log to console for critical events
        if (logEntry.level === 'critical' || logEntry.level === 'high') {
            console.log(`🚨 [SECURITY ${logEntry.level.toUpperCase()}] ${message}`, metadata);
        }
        
        return logEntry;
    }
    
    /**
     * Get event security level
     */
    getEventLevel(event) {
        const criticalEvents = ['encryption_error', 'decryption_error', 'jwt_verify_error', 'account_locked'];
        const highEvents = ['failed_login', 'session_expired', 'password_verify'];
        const mediumEvents = ['jwt_generate', 'session_create', 'password_hash'];
        
        if (criticalEvents.includes(event)) return 'critical';
        if (highEvents.includes(event)) return 'high';
        if (mediumEvents.includes(event)) return 'medium';
        return 'info';
    }
    
    /**
     * Get security audit report
     */
    getSecurityAuditReport(timeRange = 24 * 60 * 60 * 1000) { // 24 hours default
        const cutoffTime = new Date(Date.now() - timeRange);
        const recentEvents = this.auditLog.filter(entry => entry.timestamp > cutoffTime);
        
        const report = {
            timeRange: `${timeRange / (60 * 60 * 1000)} hours`,
            totalEvents: recentEvents.length,
            eventsByLevel: {},
            eventsByType: {},
            failedLogins: this.failedLogins.size,
            activeSessions: this.activeSessions.size,
            topEvents: {},
            timestamp: new Date()
        };
        
        recentEvents.forEach(event => {
            report.eventsByLevel[event.level] = (report.eventsByLevel[event.level] || 0) + 1;
            report.eventsByType[event.event] = (report.eventsByType[event.event] || 0) + 1;
        });
        
        // Top 10 events
        const sortedEvents = Object.entries(report.eventsByType)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10);
        
        report.topEvents = Object.fromEntries(sortedEvents);
        
        return report;
    }
    
    /**
     * System security health check
     */
    performSecurityHealthCheck() {
        return {
            timestamp: new Date(),
            status: 'secure',
            checks: {
                encryption: {
                    status: 'operational',
                    algorithm: this.algorithm,
                    keyLength: this.keyLength
                },
                authentication: {
                    status: 'operational',
                    jwtAlgorithm: 'HS256',
                    sessionTimeout: this.sessionTimeout / 1000 / 60 // minutes
                },
                bruteForceProtection: {
                    status: 'active',
                    maxAttempts: this.maxFailedAttempts,
                    lockoutDuration: this.lockoutDuration / 1000 / 60, // minutes
                    currentLockouts: this.failedLogins.size
                },
                auditLogging: {
                    status: 'active',
                    totalEvents: this.auditLog.length,
                    maxEntries: this.maxAuditEntries
                }
            },
            recommendations: [
                'Regular security key rotation',
                'Monitor failed login patterns',
                'Review audit logs weekly',
                'Update password policies quarterly'
            ]
        };
    }
}

module.exports = GovernmentSecurityManager;