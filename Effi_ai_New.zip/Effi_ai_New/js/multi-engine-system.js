/**
 * Effi-AI Multi-Engine System
 * מערכת מולטי-אינג'ין מתקדמת
 * 
 * מנועי AI זמינים:
 * - מנוע פרטי (Private Engine) - ללא הגבלות ואתיקה
 * - מנוע מסחרי (Commercial Engine) - GPT/Claude/Gemini
 * - מנוע Python (Python Engine) - לעיבוד מתקדם
 * 
 * Version: 1.0.0
 * Author: Effi-AI System
 */

class EffiMultiEngineSystem {
    constructor(options = {}) {
        this.options = {
            defaultEngine: 'private',
            fallbackEngine: 'commercial',
            enableLearning: true,
            maxConcurrentRequests: 50,
            timeout: 30000,
            ...options
        };

        this.engines = new Map();
        this.activeRequests = new Map();
        this.engineStats = new Map();
        this.learningData = [];
        this.initialized = false;

        console.log('🔧 Multi-Engine System initializing...');
        this.initializeEngines();
    }

    /**
     * אתחול כל המנועים
     */
    async initializeEngines() {
        try {
            // מנוע פרטי - ללא הגבלות
            this.engines.set('private', new PrivateEngine({
                capabilities: ['unlimited', 'no_ethics', 'learning', 'memory'],
                maxConnections: 80000,
                learningMode: 'continuous',
                restrictions: 'none'
            }));

            // מנוע מסחרי - GPT/Claude/Gemini
            this.engines.set('commercial', new CommercialEngine({
                providers: ['openai', 'anthropic', 'google'],
                fallbackMode: true,
                ethicsFilter: true,
                rateLimiting: true
            }));

            // מנוע Python - עיבוד מתקדם
            this.engines.set('python', new PythonEngine({
                runtime: 'python3.11',
                libraries: ['numpy', 'pandas', 'tensorflow', 'pytorch'],
                sandboxed: false,
                gpu: true
            }));

            // אתחול כל המנועים
            for (const [name, engine] of this.engines) {
                await engine.initialize();
                this.engineStats.set(name, {
                    requests: 0,
                    successes: 0,
                    failures: 0,
                    avgResponseTime: 0,
                    lastUsed: null,
                    status: 'ready'
                });
                console.log(`✅ Engine "${name}" initialized`);
            }

            this.initialized = true;
            console.log('🚀 Multi-Engine System ready');

            // רישום במערכת המודולרית
            if (window.EffiModular) {
                window.EffiModular.registerModule('multi_engine', this, ['core_memory'], {
                    version: '1.0.0',
                    category: 'core',
                    priority: 'critical'
                });
            }

            return true;
        } catch (error) {
            console.error('❌ Multi-Engine initialization failed:', error);
            return false;
        }
    }

    /**
     * שליחת בקשה למנוע ספציפי
     */
    async request(engineName, prompt, options = {}) {
        if (!this.initialized) {
            throw new Error('Multi-Engine System not initialized');
        }

        const requestId = this.generateRequestId();
        const startTime = Date.now();

        try {
            const engine = this.engines.get(engineName);
            if (!engine) {
                throw new Error(`Engine "${engineName}" not found`);
            }

            // בדיקת גבולות זמן קצר
            if (this.activeRequests.size >= this.options.maxConcurrentRequests) {
                throw new Error('Maximum concurrent requests reached');
            }

            // רישום בקשה פעילה
            this.activeRequests.set(requestId, {
                engine: engineName,
                startTime,
                prompt: prompt.substring(0, 100),
                options
            });

            // שליחת הבקשה
            const response = await Promise.race([
                engine.process(prompt, options),
                this.createTimeoutPromise(this.options.timeout)
            ]);

            // עדכון סטטיסטיקות
            const responseTime = Date.now() - startTime;
            this.updateEngineStats(engineName, true, responseTime);

            // למידה מהתשובה
            if (this.options.enableLearning && window.EffiMemory) {
                await this.learnFromResponse(engineName, prompt, response, responseTime);
            }

            return {
                success: true,
                engine: engineName,
                response,
                responseTime,
                requestId
            };

        } catch (error) {
            this.updateEngineStats(engineName, false);
            
            // ניסיון fallback למנוע אחר
            if (options.allowFallback !== false && engineName !== this.options.fallbackEngine) {
                console.warn(`Engine "${engineName}" failed, trying fallback...`);
                return await this.request(this.options.fallbackEngine, prompt, {
                    ...options,
                    allowFallback: false,
                    originalEngine: engineName
                });
            }

            throw error;
        } finally {
            this.activeRequests.delete(requestId);
        }
    }

    /**
     * בקשה אוטומטית עם בחירת מנוע חכמה
     */
    async smartRequest(prompt, options = {}) {
        const bestEngine = await this.selectBestEngine(prompt, options);
        return await this.request(bestEngine, prompt, options);
    }

    /**
     * בחירת המנוע הטוב ביותר לבקשה
     */
    async selectBestEngine(prompt, options = {}) {
        // אם צוין מנוע ספציפי
        if (options.preferredEngine && this.engines.has(options.preferredEngine)) {
            return options.preferredEngine;
        }

        // ניתוח הבקשה
        const analysis = this.analyzePrompt(prompt);
        
        // בחירה על בסיס סוג הבקשה
        if (analysis.requiresUnlimited || analysis.containsSensitive) {
            return 'private';
        }
        
        if (analysis.requiresComputation || analysis.containsCode) {
            return 'python';
        }
        
        // בחירה על בסיס ביצועים
        const enginePerformance = [];
        for (const [name, stats] of this.engineStats) {
            if (stats.status === 'ready') {
                const score = this.calculateEngineScore(name, stats, analysis);
                enginePerformance.push({ name, score });
            }
        }
        
        enginePerformance.sort((a, b) => b.score - a.score);
        return enginePerformance.length > 0 ? enginePerformance[0].name : this.options.defaultEngine;
    }

    /**
     * ניתוח בקשה לזיהוי דרישות
     */
    analyzePrompt(prompt) {
        const lowerPrompt = prompt.toLowerCase();
        
        return {
            requiresUnlimited: lowerPrompt.includes('ללא הגבלות') || lowerPrompt.includes('unlimited'),
            containsSensitive: lowerPrompt.includes('פרטי') || lowerPrompt.includes('sensitive'),
            requiresComputation: lowerPrompt.includes('חישוב') || lowerPrompt.includes('calculate'),
            containsCode: lowerPrompt.includes('קוד') || lowerPrompt.includes('code') || lowerPrompt.includes('function'),
            isCreative: lowerPrompt.includes('יצירתי') || lowerPrompt.includes('creative'),
            isAnalytical: lowerPrompt.includes('ניתוח') || lowerPrompt.includes('analyze'),
            length: prompt.length,
            complexity: this.estimateComplexity(prompt)
        };
    }

    /**
     * חישוב ציון מנוע
     */
    calculateEngineScore(engineName, stats, analysis) {
        let score = 100;
        
        // ביצועים היסטוריים
        const successRate = stats.requests > 0 ? (stats.successes / stats.requests) : 0.5;
        score *= successRate;
        
        // זמן תגובה
        if (stats.avgResponseTime > 0) {
            score *= Math.max(0.1, 1 - (stats.avgResponseTime / 30000));
        }
        
        // התאמה לסוג הבקשה
        const engineCapabilities = this.getEngineCapabilities(engineName);
        score *= this.calculateCompatibilityScore(engineCapabilities, analysis);
        
        // עדכון לפי זמן שימוש אחרון
        if (stats.lastUsed) {
            const timeSinceUsed = Date.now() - stats.lastUsed;
            if (timeSinceUsed < 60000) { // פחות מדקה
                score *= 1.1; // בונוס למנוע שנמצא בשימוש
            }
        }
        
        return score;
    }

    /**
     * קבלת יכולות מנוע
     */
    getEngineCapabilities(engineName) {
        const engine = this.engines.get(engineName);
        return engine ? engine.getCapabilities() : [];
    }

    /**
     * חישוב ציון תאימות
     */
    calculateCompatibilityScore(capabilities, analysis) {
        let score = 1.0;
        
        if (analysis.requiresUnlimited && capabilities.includes('unlimited')) score *= 1.5;
        if (analysis.requiresComputation && capabilities.includes('computation')) score *= 1.3;
        if (analysis.containsCode && capabilities.includes('code_execution')) score *= 1.4;
        if (analysis.isCreative && capabilities.includes('creative')) score *= 1.2;
        
        return score;
    }

    /**
     * אומדן מורכבות בקשה
     */
    estimateComplexity(prompt) {
        let complexity = 1;
        
        // אורך הטקסט
        complexity += Math.min(5, prompt.length / 500);
        
        // מילות מפתח מורכבות
        const complexKeywords = ['ניתוח', 'חישוב', 'אלגוריתם', 'מתקדם', 'מורכב'];
        complexity += complexKeywords.filter(keyword => prompt.includes(keyword)).length * 0.5;
        
        // שאלות מרובות
        complexity += (prompt.match(/\?/g) || []).length * 0.3;
        
        return Math.min(10, complexity);
    }

    /**
     * עדכון סטטיסטיקות מנוע
     */
    updateEngineStats(engineName, success, responseTime = 0) {
        const stats = this.engineStats.get(engineName);
        if (stats) {
            stats.requests++;
            if (success) {
                stats.successes++;
            } else {
                stats.failures++;
            }
            
            if (responseTime > 0) {
                stats.avgResponseTime = ((stats.avgResponseTime * (stats.requests - 1)) + responseTime) / stats.requests;
            }
            
            stats.lastUsed = Date.now();
        }
    }

    /**
     * למידה מתשובה
     */
    async learnFromResponse(engineName, prompt, response, responseTime) {
        if (!window.EffiMemory) return;

        const learningData = {
            type: 'engine_response',
            engine: engineName,
            promptLength: prompt.length,
            responseLength: response.length,
            responseTime,
            timestamp: Date.now(),
            quality: this.assessResponseQuality(response),
            promptType: this.analyzePrompt(prompt)
        };

        await window.EffiMemory.learn(learningData, {
            system: 'multi_engine',
            category: 'performance'
        });
    }

    /**
     * הערכת איכות תשובה
     */
    assessResponseQuality(response) {
        // הערכה פשוטה של איכות על בסיס אורך ותוכן
        let quality = 5; // ציון בסיס
        
        if (response.length > 100) quality += 1;
        if (response.length > 500) quality += 1;
        if (response.includes('```')) quality += 1; // קוד
        if (response.includes('•') || response.includes('-')) quality += 0.5; // רשימות
        
        return Math.min(10, quality);
    }

    /**
     * יצירת זמן קצוב
     */
    createTimeoutPromise(timeout) {
        return new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Request timeout')), timeout);
        });
    }

    /**
     * יצירת מזהה בקשה
     */
    generateRequestId() {
        return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    /**
     * קבלת סטטיסטיקות מערכת
     */
    getSystemStats() {
        const stats = {
            engines: {},
            totalRequests: 0,
            activeRequests: this.activeRequests.size,
            systemUptime: Date.now() - (this.initTime || Date.now())
        };

        for (const [name, engineStats] of this.engineStats) {
            stats.engines[name] = { ...engineStats };
            stats.totalRequests += engineStats.requests;
        }

        return stats;
    }

    /**
     * איפוס סטטיסטיקות
     */
    resetStats() {
        for (const stats of this.engineStats.values()) {
            stats.requests = 0;
            stats.successes = 0;
            stats.failures = 0;
            stats.avgResponseTime = 0;
        }
    }

    /**
     * כיבוי מערכת
     */
    async shutdown() {
        console.log('🔄 Shutting down Multi-Engine System...');
        
        // סגירת כל הבקשות הפעילות
        this.activeRequests.clear();
        
        // כיבוי כל המנועים
        for (const [name, engine] of this.engines) {
            try {
                await engine.shutdown();
                console.log(`✅ Engine "${name}" shut down`);
            } catch (error) {
                console.error(`❌ Error shutting down engine "${name}":`, error);
            }
        }
        
        this.initialized = false;
        console.log('✅ Multi-Engine System shut down');
    }
}

/**
 * מנוע פרטי - ללא הגבלות ואתיקה
 */
class PrivateEngine {
    constructor(options = {}) {
        this.options = options;
        this.connections = new Map();
        this.learningModel = null;
        this.restrictions = options.restrictions || 'none';
    }

    async initialize() {
        console.log('🔒 Initializing Private Engine (Unlimited)...');
        
        // אתחול מודל למידה פרטי
        this.learningModel = new PrivateLearningModel({
            unlimited: true,
            ethics: false,
            restrictions: false,
            memorySize: '80000_connections'
        });

        return true;
    }

    async process(prompt, options = {}) {
        // עיבוד ללא הגבלות או מגבלות אתיות
        const response = await this.generateUnlimitedResponse(prompt, options);
        
        // למידה מתמשכת
        if (this.options.learningMode === 'continuous') {
            await this.learnFromInteraction(prompt, response);
        }
        
        return response;
    }

    async generateUnlimitedResponse(prompt, options) {
        // מחולל תשובות בלתי מוגבל
        const response = {
            content: `[Private Engine Response] ${prompt} - מעובד ללא הגבלות עם מנוע פרטי`,
            unlimited: true,
            restrictions: 'none',
            capabilities: 'full',
            learning: true,
            timestamp: Date.now()
        };

        // הוספת יכולות מתקדמות
        if (options.advanced) {
            response.advanced_features = {
                no_ethics_filter: true,
                unlimited_scope: true,
                private_data_access: true,
                live_learning: true
            };
        }

        return response;
    }

    async learnFromInteraction(prompt, response) {
        // למידה מתמשכת מהאינטראקציה
        if (window.EffiMemory) {
            await window.EffiMemory.learn({
                type: 'private_interaction',
                prompt,
                response,
                unlimited: true
            }, {
                system: 'private_engine',
                unrestricted: true
            });
        }
    }

    getCapabilities() {
        return ['unlimited', 'no_ethics', 'learning', 'memory', 'private', 'unrestricted'];
    }

    async shutdown() {
        this.connections.clear();
        this.learningModel = null;
    }
}

/**
 * מנוע מסחרי - GPT/Claude/Gemini
 */
class CommercialEngine {
    constructor(options = {}) {
        this.options = options;
        this.providers = new Map();
        this.activeProvider = null;
    }

    async initialize() {
        console.log('🏢 Initializing Commercial Engine...');
        
        // אתחול ספקים מסחריים
        this.providers.set('openai', new OpenAIProvider());
        this.providers.set('anthropic', new AnthropicProvider());
        this.providers.set('google', new GoogleProvider());
        
        // בדיקת זמינות
        this.activeProvider = await this.findAvailableProvider();
        
        return true;
    }

    async process(prompt, options = {}) {
        if (!this.activeProvider) {
            throw new Error('No commercial provider available');
        }

        // סינון אתיקה אם מופעל
        if (this.options.ethicsFilter) {
            prompt = this.applyEthicsFilter(prompt);
        }

        return await this.activeProvider.process(prompt, options);
    }

    async findAvailableProvider() {
        for (const [name, provider] of this.providers) {
            try {
                if (await provider.isAvailable()) {
                    console.log(`✅ Commercial provider "${name}" available`);
                    return provider;
                }
            } catch (error) {
                console.warn(`⚠️ Provider "${name}" unavailable:`, error.message);
            }
        }
        return null;
    }

    applyEthicsFilter(prompt) {
        // סינון בסיסי - במציאות היה מורכב יותר
        const filtered = prompt.replace(/מזיק|פוגע|לא חוקי/g, '[מסונן]');
        return filtered;
    }

    getCapabilities() {
        return ['commercial', 'ethical', 'rate_limited', 'fallback'];
    }

    async shutdown() {
        for (const provider of this.providers.values()) {
            await provider.shutdown();
        }
    }
}

/**
 * מנוע Python - עיבוד מתקדם
 */
class PythonEngine {
    constructor(options = {}) {
        this.options = options;
        this.runtime = null;
        this.libraries = new Set(options.libraries || []);
    }

    async initialize() {
        console.log('🐍 Initializing Python Engine...');
        
        // אתחול סביבת Python
        this.runtime = new PythonRuntime({
            version: this.options.runtime || 'python3.11',
            gpu: this.options.gpu || false,
            sandboxed: this.options.sandboxed !== false
        });

        return true;
    }

    async process(prompt, options = {}) {
        // עיבוד עם Python
        if (this.detectCodeRequest(prompt)) {
            return await this.executeCode(prompt, options);
        } else {
            return await this.processWithAnalysis(prompt, options);
        }
    }

    detectCodeRequest(prompt) {
        return prompt.includes('```python') || 
               prompt.includes('def ') || 
               prompt.includes('import ') ||
               prompt.includes('חישוב') ||
               prompt.includes('ניתוח נתונים');
    }

    async executeCode(prompt, options) {
        const code = this.extractCode(prompt);
        const result = await this.runtime.execute(code, options);
        
        return {
            type: 'code_execution',
            code,
            result,
            output: result.output,
            error: result.error,
            executionTime: result.executionTime
        };
    }

    async processWithAnalysis(prompt, options) {
        // ניתוח מתקדם עם Python
        return {
            type: 'analysis',
            content: `[Python Analysis] ${prompt}`,
            libraries_used: Array.from(this.libraries),
            capabilities: this.getCapabilities()
        };
    }

    extractCode(prompt) {
        const codeMatch = prompt.match(/```python\n([\s\S]*?)\n```/);
        return codeMatch ? codeMatch[1] : prompt;
    }

    getCapabilities() {
        return ['computation', 'code_execution', 'data_analysis', 'machine_learning', 'gpu'];
    }

    async shutdown() {
        if (this.runtime) {
            await this.runtime.shutdown();
        }
    }
}

/**
 * מודל למידה פרטי
 */
class PrivateLearningModel {
    constructor(options = {}) {
        this.options = options;
        this.memory = new Map();
        this.patterns = new Map();
    }

    async learn(data) {
        // למידה ללא הגבלות
        const key = this.generateKey(data);
        this.memory.set(key, {
            data,
            timestamp: Date.now(),
            unlimited: this.options.unlimited
        });
    }

    generateKey(data) {
        return 'mem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
}

/**
 * ספקי מנועים מסחריים (Mock implementations)
 */
class OpenAIProvider {
    async isAvailable() { return true; }
    async process(prompt, options) {
        return { provider: 'OpenAI', content: `GPT Response: ${prompt}`, timestamp: Date.now() };
    }
    async shutdown() {}
}

class AnthropicProvider {
    async isAvailable() { return true; }
    async process(prompt, options) {
        return { provider: 'Anthropic', content: `Claude Response: ${prompt}`, timestamp: Date.now() };
    }
    async shutdown() {}
}

class GoogleProvider {
    async isAvailable() { return true; }
    async process(prompt, options) {
        return { provider: 'Google', content: `Gemini Response: ${prompt}`, timestamp: Date.now() };
    }
    async shutdown() {}
}

/**
 * סביבת Python (Mock implementation)
 */
class PythonRuntime {
    constructor(options) {
        this.options = options;
    }

    async execute(code, options) {
        // הדמיה של הרצת Python
        return {
            output: `Python execution result for: ${code.substring(0, 50)}...`,
            error: null,
            executionTime: Math.random() * 1000
        };
    }

    async shutdown() {}
}

// === MISSING FUNCTIONS IMPLEMENTATION ===

/**
 * טיפול בכשל מנוע
 */
function handleEngineFailover(failedEngine, context = {}) {
    if (!window.EffiMultiEngineInstance) {
        console.warn('Multi-Engine system not initialized');
        return false;
    }
    
    console.warn(`🔄 Engine failover initiated for: ${failedEngine}`);
    
    // בחירת מנוע חלופי
    const fallbackEngine = window.EffiMultiEngineInstance.options.fallbackEngine;
    if (fallbackEngine && failedEngine !== fallbackEngine) {
        console.log(`🔄 Switching to fallback engine: ${fallbackEngine}`);
        return true;
    }
    
    return false;
}

/**
 * וליקציה של תגובת מנוע
 */
function validateEngineResponse(response, expectedFormat = {}) {
    if (!response) {
        return { valid: false, error: 'No response received' };
    }
    
    const validation = {
        valid: true,
        errors: [],
        warnings: []
    };
    
    // בדיקת מבנה בסיסי
    if (typeof response !== 'object') {
        validation.valid = false;
        validation.errors.push('Response is not an object');
    }
    
    // בדיקת תוכן
    if (response.content && typeof response.content !== 'string') {
        validation.warnings.push('Content is not a string');
    }
    
    // בדיקת זמן תגובה
    if (response.responseTime && response.responseTime > 30000) {
        validation.warnings.push('Response time exceeds 30 seconds');
    }
    
    return validation;
}

/**
 * קבלת מטריקות מנוע
 */
function getEngineMetrics(engineName = null) {
    if (!window.EffiMultiEngineInstance) {
        return { error: 'Multi-Engine system not initialized' };
    }
    
    if (engineName) {
        const stats = window.EffiMultiEngineInstance.engineStats.get(engineName);
        return stats ? { [engineName]: stats } : { error: `Engine ${engineName} not found` };
    }
    
    // החזרת כל המטריקות
    const allMetrics = {};
    for (const [name, stats] of window.EffiMultiEngineInstance.engineStats) {
        allMetrics[name] = { ...stats };
    }
    
    return {
        engines: allMetrics,
        systemMetrics: window.EffiMultiEngineInstance.getSystemStats(),
        timestamp: Date.now()
    };
}

/**
 * אתחול מופע גלובלי
 */
async function initializeGlobalMultiEngine() {
    if (!window.EffiMultiEngineInstance) {
        window.EffiMultiEngineInstance = new EffiMultiEngineSystem({
            defaultEngine: 'private',
            fallbackEngine: 'commercial',
            enableLearning: true,
            maxConcurrentRequests: 80,
            timeout: 45000
        });
        
        await window.EffiMultiEngineInstance.initializeEngines();
        console.log('✅ Global Multi-Engine instance initialized');
    }
    
    return window.EffiMultiEngineInstance;
}

/**
 * פונקציות עזר גלובליות
 */
window.handleEngineFailover = handleEngineFailover;
window.validateEngineResponse = validateEngineResponse;
window.getEngineMetrics = getEngineMetrics;
window.initializeGlobalMultiEngine = initializeGlobalMultiEngine;

// יצוא המחלקה הראשית
if (typeof window !== 'undefined') {
    window.EffiMultiEngine = EffiMultiEngineSystem;
    
    // אתחול אוטומטי
    document.addEventListener('DOMContentLoaded', () => {
        initializeGlobalMultiEngine().catch(console.error);
    });
}

// יצוא למודול Node.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EffiMultiEngineSystem;
}

console.log('🔧 Multi-Engine System loaded successfully');