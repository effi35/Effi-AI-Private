const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const router = express.Router();

// Mock user database for development (will be replaced with MongoDB)
const users = new Map();
const sessions = new Map();

// Default admin user
const adminUser = {
    id: 'admin_001',
    username: 'admin',
    email: 'admin@effi-gov.il',
    password: bcrypt.hashSync('EffiGov2024!', 12),
    userType: 'admin',
    permissions: ['all'],
    createdAt: new Date(),
    isActive: true
};
users.set('admin', adminUser);

// Government demo users
const govUsers = [
    {
        id: 'gov_001',
        username: 'minister_defense',
        email: 'defense@gov.il',
        password: bcrypt.hashSync('Defense2024!', 12),
        userType: 'government',
        permissions: ['defense', 'security', 'citizens'],
        department: 'משרד הביטחון'
    },
    {
        id: 'gov_002', 
        username: 'minister_interior',
        email: 'interior@gov.il',
        password: bcrypt.hashSync('Interior2024!', 12),
        userType: 'government',
        permissions: ['interior', 'citizens', 'municipal'],
        department: 'משרד הפנים'
    }
];

govUsers.forEach(user => users.set(user.username, user));

// JWT Token Generation
function generateTokens(user) {
    const payload = {
        id: user.id,
        username: user.username,
        userType: user.userType,
        permissions: user.permissions
    };
    
    const accessToken = jwt.sign(payload, process.env.JWT_SECRET || 'effi_default_secret', {
        expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    });
    
    const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET || 'effi_refresh_secret', {
        expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
    });
    
    return { accessToken, refreshToken };
}

// Authentication Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }
    
    jwt.verify(token, process.env.JWT_SECRET || 'effi_default_secret', (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
}

// Login Route
router.post('/login', [
    body('username').trim().notEmpty().withMessage('Username is required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }
        
        const { username, password } = req.body;
        const user = users.get(username);
        
        if (!user || !user.isActive) {
            return res.status(401).json({
                error: 'Invalid credentials',
                code: 'INVALID_CREDENTIALS'
            });
        }
        
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(401).json({
                error: 'Invalid credentials',
                code: 'INVALID_CREDENTIALS'
            });
        }
        
        // Update last login
        user.lastLogin = new Date();
        
        // Generate tokens
        const { accessToken, refreshToken } = generateTokens(user);
        
        // Store session
        const sessionId = `session_${Date.now()}_${Math.random()}`;
        sessions.set(sessionId, {
            userId: user.id,
            refreshToken,
            createdAt: new Date(),
            lastActivity: new Date()
        });
        
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                userType: user.userType,
                permissions: user.permissions,
                department: user.department
            },
            tokens: {
                accessToken,
                refreshToken
            },
            sessionId
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            error: 'Login failed',
            message: 'Internal server error'
        });
    }
});

// Register Route (for citizens)
router.post('/register', [
    body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
    body('email').isEmail().withMessage('Valid email is required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('citizenId').isLength({ min: 9, max: 9 }).withMessage('Israeli ID must be 9 digits')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }
        
        const { username, email, password, citizenId, fullName } = req.body;
        
        // Check if user already exists
        if (users.has(username)) {
            return res.status(409).json({
                error: 'Username already exists',
                code: 'USERNAME_EXISTS'
            });
        }
        
        // Check if email already exists
        const emailExists = Array.from(users.values()).some(user => user.email === email);
        if (emailExists) {
            return res.status(409).json({
                error: 'Email already registered',
                code: 'EMAIL_EXISTS'
            });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);
        
        // Create new user
        const newUser = {
            id: `citizen_${Date.now()}`,
            username,
            email, 
            password: hashedPassword,
            userType: 'citizen',
            permissions: ['basic'],
            citizenId,
            fullName,
            createdAt: new Date(),
            isActive: true,
            isVerified: false
        };
        
        users.set(username, newUser);
        
        // Generate tokens
        const { accessToken, refreshToken } = generateTokens(newUser);
        
        res.status(201).json({
            success: true,
            message: 'Registration successful',
            user: {
                id: newUser.id,
                username: newUser.username,
                email: newUser.email,
                userType: newUser.userType,
                permissions: newUser.permissions
            },
            tokens: {
                accessToken,
                refreshToken
            }
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            error: 'Registration failed',
            message: 'Internal server error'
        });
    }
});

// Token Refresh Route
router.post('/refresh', async (req, res) => {
    try {
        const { refreshToken } = req.body;
        
        if (!refreshToken) {
            return res.status(401).json({
                error: 'Refresh token required'
            });
        }
        
        jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'effi_refresh_secret', (err, decoded) => {
            if (err) {
                return res.status(403).json({
                    error: 'Invalid refresh token'
                });
            }
            
            const user = users.get(decoded.username);
            if (!user || !user.isActive) {
                return res.status(403).json({
                    error: 'User not found or inactive'
                });
            }
            
            // Generate new access token
            const { accessToken } = generateTokens(user);
            
            res.json({
                success: true,
                accessToken
            });
        });
        
    } catch (error) {
        console.error('Token refresh error:', error);
        res.status(500).json({
            error: 'Token refresh failed'
        });
    }
});

// Logout Route
router.post('/logout', authenticateToken, (req, res) => {
    try {
        const { sessionId } = req.body;
        
        if (sessionId) {
            sessions.delete(sessionId);
        }
        
        res.json({
            success: true,
            message: 'Logout successful'
        });
        
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            error: 'Logout failed'
        });
    }
});

// Get Current User Profile
router.get('/profile', authenticateToken, (req, res) => {
    try {
        const user = users.get(req.user.username);
        
        if (!user) {
            return res.status(404).json({
                error: 'User not found'
            });
        }
        
        res.json({
            success: true,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                userType: user.userType,
                permissions: user.permissions,
                department: user.department,
                fullName: user.fullName,
                createdAt: user.createdAt,
                lastLogin: user.lastLogin
            }
        });
        
    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({
            error: 'Failed to fetch profile'
        });
    }
});

// Verify Token Route
router.get('/verify', authenticateToken, (req, res) => {
    res.json({
        success: true,
        valid: true,
        user: {
            id: req.user.id,
            username: req.user.username,
            userType: req.user.userType,
            permissions: req.user.permissions
        }
    });
});

// Get All Users (Admin only)
router.get('/users', authenticateToken, (req, res) => {
    try {
        if (req.user.userType !== 'admin') {
            return res.status(403).json({
                error: 'Admin access required'
            });
        }
        
        const userList = Array.from(users.values()).map(user => ({
            id: user.id,
            username: user.username,
            email: user.email,
            userType: user.userType,
            permissions: user.permissions,
            department: user.department,
            createdAt: user.createdAt,
            lastLogin: user.lastLogin,
            isActive: user.isActive
        }));
        
        res.json({
            success: true,
            users: userList,
            total: userList.length
        });
        
    } catch (error) {
        console.error('Users fetch error:', error);
        res.status(500).json({
            error: 'Failed to fetch users'
        });
    }
});

module.exports = router;