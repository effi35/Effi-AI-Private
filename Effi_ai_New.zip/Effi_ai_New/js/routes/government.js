const express = require('express');
const router = express.Router();

// In-memory government database (will be replaced with MongoDB)
let citizenDatabase = new Map();
let governmentModules = new Map();
let serviceRequests = new Map();

// Initialize with sample Israeli government data
const initializeGovernmentData = () => {
    // Sample citizens (following Israeli privacy laws)
    const sampleCitizens = [
        {
            id: '123456789',
            fullName: 'יוסף כהן',
            birthDate: '1985-03-15',
            address: 'תל אביב, ישראל',
            status: 'active',
            services: ['תעודת זהות', 'ביטוח לאומי', 'מס הכנסה'],
            lastActivity: new Date(),
            securityLevel: 'standard'
        },
        {
            id: '987654321',
            fullName: 'מרים לוי',
            birthDate: '1992-08-22',
            address: 'ירושלים, ישראל',
            status: 'active',
            services: ['דרכון', 'רישיון נהיגה', 'ביטוח לאומי'],
            lastActivity: new Date(),
            securityLevel: 'standard'
        }
    ];
    
    sampleCitizens.forEach(citizen => {
        citizenDatabase.set(citizen.id, citizen);
    });
    
    // Government modules
    const modules = [
        {
            id: 'ministry_interior',
            name: 'משרד הפנים',
            services: ['תעודות זהות', 'מרשם האוכלוסין', 'אזרחות'],
            status: 'operational',
            citizens_served: 2840000,
            daily_requests: 15000
        },
        {
            id: 'ministry_defense',
            name: 'משרד הביטחון',
            services: ['גיוס', 'שירות צבאי', 'ביטחון'],
            status: 'operational',
            citizens_served: 1200000,
            daily_requests: 5000
        },
        {
            id: 'ministry_health',
            name: 'משרד הבריאות',
            services: ['רישוי רפואי', 'בריאות הציבור', 'ביטוח בריאות'],
            status: 'operational',
            citizens_served: 6800000,
            daily_requests: 25000
        },
        {
            id: 'tax_authority',
            name: 'רשות המסים',
            services: ['מס הכנסה', 'מעמ', 'החזרי מס'],
            status: 'operational',
            citizens_served: 4200000,
            daily_requests: 30000
        },
        {
            id: 'national_insurance',
            name: 'ביטוח לאומי',
            services: ['קצבאות', 'ביטוח אבטלה', 'קצבת זקנה'],
            status: 'operational',
            citizens_served: 6500000,
            daily_requests: 40000
        }
    ];
    
    modules.forEach(module => {
        governmentModules.set(module.id, module);
    });
    
    console.log(`✅ Initialized government data: ${citizenDatabase.size} citizens, ${governmentModules.size} modules`);
};

// Initialize data on startup
initializeGovernmentData();

// Middleware for government admin access
const requireGovernmentAccess = (req, res, next) => {
    const userType = req.user?.userType;
    if (!['government', 'admin'].includes(userType)) {
        return res.status(403).json({
            error: 'Government access required',
            code: 'INSUFFICIENT_PERMISSIONS'
        });
    }
    next();
};

// Get government dashboard overview
router.get('/dashboard', requireGovernmentAccess, (req, res) => {
    try {
        const overview = {
            total_citizens: 6847293, // Real Israeli population estimate
            active_services: Array.from(governmentModules.values()).reduce((total, module) => total + module.services.length, 0),
            daily_requests: Array.from(governmentModules.values()).reduce((total, module) => total + module.daily_requests, 0),
            system_uptime: '99.97%',
            security_level: 'MAXIMUM',
            active_modules: governmentModules.size,
            pending_requests: Math.floor(Math.random() * 500) + 100,
            completed_today: Math.floor(Math.random() * 10000) + 5000,
            citizen_satisfaction: 4.3,
            timestamp: new Date()
        };
        
        res.json({
            success: true,
            overview
        });
        
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({
            error: 'Failed to get dashboard data'
        });
    }
});

// Get all government modules
router.get('/modules', requireGovernmentAccess, (req, res) => {
    try {
        const modules = Array.from(governmentModules.values());
        
        res.json({
            success: true,
            modules,
            total: modules.length
        });
        
    } catch (error) {
        console.error('Modules error:', error);
        res.status(500).json({
            error: 'Failed to get modules'
        });
    }
});

// Get citizen information (with privacy protection)
router.get('/citizens/:citizenId', requireGovernmentAccess, (req, res) => {
    try {
        const { citizenId } = req.params;
        const citizen = citizenDatabase.get(citizenId);
        
        if (!citizen) {
            return res.status(404).json({
                error: 'Citizen not found',
                code: 'CITIZEN_NOT_FOUND'
            });
        }
        
        // Privacy protection - limit data based on user permissions
        const sanitizedCitizen = {
            id: citizen.id,
            fullName: req.user.userType === 'admin' ? citizen.fullName : '***',
            status: citizen.status,
            services: citizen.services.length,
            lastActivity: citizen.lastActivity,
            securityLevel: citizen.securityLevel
        };
        
        res.json({
            success: true,
            citizen: sanitizedCitizen
        });
        
    } catch (error) {
        console.error('Citizen lookup error:', error);
        res.status(500).json({
            error: 'Failed to get citizen information'
        });
    }
});

// Search citizens (government use only)
router.post('/citizens/search', requireGovernmentAccess, (req, res) => {
    try {
        const { query, filters = {} } = req.body;
        
        if (!query || query.length < 3) {
            return res.status(400).json({
                error: 'Search query must be at least 3 characters',
                code: 'INVALID_QUERY'
            });
        }
        
        // Security: Only admin can do full searches
        if (req.user.userType !== 'admin') {
            return res.status(403).json({
                error: 'Admin access required for citizen search',
                code: 'ADMIN_REQUIRED'
            });
        }
        
        const results = Array.from(citizenDatabase.values()).filter(citizen => {
            const matchesQuery = citizen.fullName.toLowerCase().includes(query.toLowerCase()) ||
                               citizen.id.includes(query);
            
            if (filters.status) {
                return matchesQuery && citizen.status === filters.status;
            }
            
            return matchesQuery;
        }).slice(0, 50); // Limit results
        
        // Sanitize results
        const sanitizedResults = results.map(citizen => ({
            id: citizen.id,
            fullName: citizen.fullName,
            status: citizen.status,
            lastActivity: citizen.lastActivity
        }));
        
        res.json({
            success: true,
            results: sanitizedResults,
            total: sanitizedResults.length,
            query
        });
        
    } catch (error) {
        console.error('Citizen search error:', error);
        res.status(500).json({
            error: 'Failed to search citizens'
        });
    }
});

// Create service request
router.post('/services/request', (req, res) => {
    try {
        const { citizenId, serviceType, description, priority = 'normal' } = req.body;
        
        if (!citizenId || !serviceType || !description) {
            return res.status(400).json({
                error: 'Missing required fields',
                code: 'MISSING_FIELDS'
            });
        }
        
        const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const serviceRequest = {
            id: requestId,
            citizenId,
            serviceType,
            description,
            priority,
            status: 'pending',
            submittedAt: new Date(),
            estimatedCompletion: new Date(Date.now() + (priority === 'urgent' ? 24 : 72) * 60 * 60 * 1000),
            assignedTo: null,
            updates: []
        };
        
        serviceRequests.set(requestId, serviceRequest);
        
        res.status(201).json({
            success: true,
            request: serviceRequest,
            message: 'Service request created successfully'
        });
        
    } catch (error) {
        console.error('Service request error:', error);
        res.status(500).json({
            error: 'Failed to create service request'
        });
    }
});

// Get service requests
router.get('/services/requests', requireGovernmentAccess, (req, res) => {
    try {
        const { status, priority, citizenId, limit = 50, offset = 0 } = req.query;
        
        let requests = Array.from(serviceRequests.values());
        
        // Apply filters
        if (status) {
            requests = requests.filter(req => req.status === status);
        }
        if (priority) {
            requests = requests.filter(req => req.priority === priority);
        }
        if (citizenId) {
            requests = requests.filter(req => req.citizenId === citizenId);
        }
        
        // Sort by submission date (newest first)
        requests.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));
        
        // Pagination
        const startIndex = parseInt(offset);
        const endIndex = startIndex + parseInt(limit);
        const paginatedRequests = requests.slice(startIndex, endIndex);
        
        res.json({
            success: true,
            requests: paginatedRequests,
            total: requests.length,
            pagination: {
                limit: parseInt(limit),
                offset: startIndex,
                hasMore: endIndex < requests.length
            }
        });
        
    } catch (error) {
        console.error('Get requests error:', error);
        res.status(500).json({
            error: 'Failed to get service requests'
        });
    }
});

// Update service request status
router.patch('/services/requests/:requestId', requireGovernmentAccess, (req, res) => {
    try {
        const { requestId } = req.params;
        const { status, notes, assignedTo } = req.body;
        
        const request = serviceRequests.get(requestId);
        if (!request) {
            return res.status(404).json({
                error: 'Service request not found',
                code: 'REQUEST_NOT_FOUND'
            });
        }
        
        // Update request
        if (status) request.status = status;
        if (assignedTo) request.assignedTo = assignedTo;
        
        // Add update to history
        request.updates.push({
            timestamp: new Date(),
            status: status || request.status,
            notes: notes || '',
            updatedBy: req.user.id
        });
        
        // Update completion time if completed
        if (status === 'completed') {
            request.completedAt = new Date();
        }
        
        serviceRequests.set(requestId, request);
        
        res.json({
            success: true,
            request,
            message: 'Service request updated successfully'
        });
        
    } catch (error) {
        console.error('Update request error:', error);
        res.status(500).json({
            error: 'Failed to update service request'
        });
    }
});

// Government statistics
router.get('/statistics', requireGovernmentAccess, (req, res) => {
    try {
        const stats = {
            population: {
                total: 6847293,
                adults: 5234567,
                seniors: 876543,
                children: 1612726
            },
            services: {
                identity_cards: 6234567,
                passports: 4567890,
                driving_licenses: 3456789,
                birth_certificates: 6847293,
                marriage_certificates: 2345678
            },
            daily_activity: {
                new_requests: Math.floor(Math.random() * 1000) + 500,
                completed_requests: Math.floor(Math.random() * 1200) + 800,
                pending_requests: Math.floor(Math.random() * 500) + 200,
                citizen_logins: Math.floor(Math.random() * 10000) + 5000
            },
            system_performance: {
                uptime: '99.97%',
                response_time: Math.floor(Math.random() * 50) + 30,
                success_rate: '99.8%',
                security_incidents: 0
            },
            modules_status: Array.from(governmentModules.values()).map(module => ({
                name: module.name,
                status: module.status,
                citizens_served: module.citizens_served,
                daily_requests: module.daily_requests
            }))
        };
        
        res.json({
            success: true,
            statistics: stats,
            generated_at: new Date()
        });
        
    } catch (error) {
        console.error('Statistics error:', error);
        res.status(500).json({
            error: 'Failed to get statistics'
        });
    }
});

// Emergency broadcast system
router.post('/emergency/broadcast', requireGovernmentAccess, (req, res) => {
    try {
        const { message, priority, targetAudience, expiresAt } = req.body;
        
        if (!message || !priority) {
            return res.status(400).json({
                error: 'Message and priority are required',
                code: 'MISSING_REQUIRED_FIELDS'
            });
        }
        
        const broadcast = {
            id: `broadcast_${Date.now()}`,
            message,
            priority,
            targetAudience: targetAudience || 'all_citizens',
            issuedBy: req.user.id,
            issuedAt: new Date(),
            expiresAt: expiresAt ? new Date(expiresAt) : new Date(Date.now() + 24 * 60 * 60 * 1000),
            status: 'active'
        };
        
        // In production, this would trigger real emergency systems
        console.log('🚨 Emergency broadcast issued:', broadcast);
        
        res.json({
            success: true,
            broadcast,
            message: 'Emergency broadcast sent successfully'
        });
        
    } catch (error) {
        console.error('Emergency broadcast error:', error);
        res.status(500).json({
            error: 'Failed to send emergency broadcast'
        });
    }
});

// Citizen portal access (public endpoint)
router.get('/portal/services', (req, res) => {
    try {
        const publicServices = [
            {
                id: 'identity_card',
                name: 'חידוש תעודת זהות',
                description: 'חידוש או הוצאת תעודת זהות חדשה',
                estimated_time: '5-7 ימי עבודה',
                online: true,
                required_documents: ['תעודת זהות ישנה', 'תמונה']
            },
            {
                id: 'passport',
                name: 'הוצאת דרכון',
                description: 'הוצאת דרכון חדש או חידוש דרכון',
                estimated_time: '10-14 ימי עבודה',
                online: true,
                required_documents: ['תעודת זהות', 'תמונה', 'אישור תשלום']
            },
            {
                id: 'birth_certificate',
                name: 'תעודת לידה',
                description: 'הוצאת תעודת לידה או העתק',
                estimated_time: '2-3 ימי עבודה',
                online: true,
                required_documents: ['תעודת זהות', 'פרטי הילד']
            },
            {
                id: 'tax_return',
                name: 'דוח שנתי למס הכנסה',
                description: 'הגשת דוח שנתי למס הכנסה',
                estimated_time: 'מיידי',
                online: true,
                required_documents: ['טפסי שכר', 'קבלות']
            },
            {
                id: 'unemployment_benefits',
                name: 'דמי אבטלה',
                description: 'הגשת בקשה לדמי אבטלה',
                estimated_time: '7-10 ימי עבודה',
                online: true,
                required_documents: ['תעודת זהות', 'אישור פיטורין']
            }
        ];
        
        res.json({
            success: true,
            services: publicServices,
            total: publicServices.length
        });
        
    } catch (error) {
        console.error('Portal services error:', error);
        res.status(500).json({
            error: 'Failed to get portal services'
        });
    }
});

module.exports = router;