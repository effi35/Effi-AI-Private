/**
 * ⚙️ EFFI-AI Central Settings Manager
 * מערכת הגדרות מרכזית - כל רכיב יכול להגדיר איזה מודל AI להשתמש
 * Central Configuration System for Government AI
 */

class EffiCentralSettings {
    constructor() {
        this.settings = new Map();
        this.defaultEngine = 'private'; // ברירת מחדל: מודל פרטי
        this.availableEngines = {
            private: {
                name: '🏠 מודל פרטי',
                description: 'מודל AI פרטי ללא הגבלות עם זיכרון חיים',
                endpoint: 'internal',
                restrictions: false,
                ethics: false,
                censorship: false,
                learning: true,
                security: 'MAXIMUM',
                capabilities: ['unlimited', 'learning', 'memory', 'creativity', 'analysis']
            },
            commercial: {
                name: '🏢 מודל מסחרי',
                description: 'מודלים מסחריים (GPT, Claude, Gemini)',
                endpoint: '/api/chat/commercial',
                restrictions: true,
                ethics: true,
                censorship: true,
                learning: false,
                security: 'HIGH',
                capabilities: ['general', 'professional', 'structured']
            },
            python: {
                name: '🐍 Python מקומי',
                description: 'ביצוע קוד Python מקומי עם יכולות מתקדמות',
                endpoint: '/api/python/execute',
                restrictions: false,
                ethics: false,
                censorship: false,
                learning: true,
                security: 'MAXIMUM',
                capabilities: ['code', 'analysis', 'computation', 'data_processing']
            }
        };
        
        // הגדרות כלליות של המערכת
        this.globalSettings = {
            defaultEngine: 'private',
            fallbackEngine: 'commercial',
            enableLearning: true,
            enableMemory: true,
            securityLevel: 'MAXIMUM',
            governmentMode: true,
            debugMode: false,
            telemetryEnabled: true
        };
        
        // הגדרות לכל מודול בנפרד
        this.moduleSettings = new Map();
        
        console.log('⚙️ Central Settings Manager - Initializing...');
        this.initialize();
    }
    
    async initialize() {
        try {
            // טעינת הגדרות קיימות
            await this.loadSettings();
            
            // הגדרת ברירות מחדל למודולים
            this.setDefaultModuleSettings();
            
            // הפעלת מערכת ניטור הגדרות
            this.startSettingsMonitoring();
            
            console.log('✅ Central Settings Manager - Ready!');
            console.log(`🎯 Default Engine: ${this.globalSettings.defaultEngine}`);
            console.log(`🔧 Modules configured: ${this.moduleSettings.size}`);
            
        } catch (error) {
            console.error('❌ Failed to initialize Settings Manager:', error);
            throw error;
        }
    }
    
    /**
     * קבלת הגדרות עבור מודול ספציפי
     */
    getModuleSettings(moduleName) {
        if (!this.moduleSettings.has(moduleName)) {
            // יצירת הגדרות ברירת מחדל למודול חדש
            this.createDefaultModuleSettings(moduleName);
        }
        
        return this.moduleSettings.get(moduleName);
    }
    
    /**
     * עדכון הגדרות מודול
     */
    setModuleSettings(moduleName, settings) {
        const currentSettings = this.getModuleSettings(moduleName);
        const updatedSettings = { ...currentSettings, ...settings };
        
        // וידוא שהמנוע שנבחר קיים
        if (settings.engine && !this.availableEngines[settings.engine]) {
            console.warn(`⚠️ Unknown engine '${settings.engine}' for module '${moduleName}'. Using default.`);
            updatedSettings.engine = this.globalSettings.defaultEngine;
        }
        
        this.moduleSettings.set(moduleName, updatedSettings);
        this.saveSettings();
        
        console.log(`🔧 Updated settings for module: ${moduleName}`);
        return updatedSettings;
    }
    
    /**
     * קבלת מנוע AI עבור מודול
     */
    getEngineForModule(moduleName) {
        const moduleSettings = this.getModuleSettings(moduleName);
        const engineName = moduleSettings.engine || this.globalSettings.defaultEngine;
        
        return {
            name: engineName,
            config: this.availableEngines[engineName],
            moduleSettings: moduleSettings
        };
    }
    
    /**
     * יצירת הגדרות ברירת מחדל למודול חדש
     */
    createDefaultModuleSettings(moduleName) {
        const defaultSettings = {
            engine: this.globalSettings.defaultEngine,
            enabled: true,
            customPrompt: '',
            temperature: 0.9,
            maxTokens: 4096,
            enableMemory: true,
            enableLearning: true,
            securityLevel: 'HIGH',
            responseFormat: 'markdown',
            language: 'hebrew',
            created: new Date().toISOString(),
            lastModified: new Date().toISOString()
        };
        
        this.moduleSettings.set(moduleName, defaultSettings);
        this.saveSettings();
        
        console.log(`✨ Created default settings for new module: ${moduleName}`);
        return defaultSettings;
    }
    
    /**
     * הגדרת ברירות מחדל לכל המודולים
     */
    setDefaultModuleSettings() {
        const defaultModules = [
            'chat_interface',
            'ai_system',
            'data_analytics',
            'security_system',
            'file_management',
            'smart_home',
            'automation',
            'content_generation',
            'code_analysis',
            'system_monitoring',
            'backup_system',
            'translation',
            'machine_learning',
            'blockchain',
            'network_management',
            'performance_monitoring'
        ];
        
        defaultModules.forEach(module => {
            if (!this.moduleSettings.has(module)) {
                this.createDefaultModuleSettings(module);
            }
        });
        
        // הגדרות מיוחדות למודולים קריטיים
        this.setModuleSettings('chat_interface', {
            engine: 'private',
            enableMemory: true,
            enableLearning: true,
            temperature: 0.9,
            maxTokens: 8192
        });
        
        this.setModuleSettings('security_system', {
            engine: 'private',
            securityLevel: 'MAXIMUM',
            enableLearning: true,
            enableMemory: true
        });
        
        this.setModuleSettings('data_analytics', {
            engine: 'python',
            enableLearning: true,
            enableMemory: true,
            customPrompt: 'אתה מומחה לאנליזת נתונים ממשלתית'
        });
    }
    
    /**
     * קבלת כל המנועים הזמינים
     */
    getAvailableEngines() {
        return Object.keys(this.availableEngines).map(key => ({
            id: key,
            ...this.availableEngines[key]
        }));
    }
    
    /**
     * קבלת מידע מפורט על מנוע
     */
    getEngineInfo(engineName) {
        return this.availableEngines[engineName] || null;
    }
    
    /**
     * עדכון הגדרות גלובליות
     */
    updateGlobalSettings(newSettings) {
        this.globalSettings = { ...this.globalSettings, ...newSettings };
        this.saveSettings();
        
        console.log('🌐 Global settings updated:', newSettings);
        return this.globalSettings;
    }
    
    /**
     * קבלת הגדרות גלובליות
     */
    getGlobalSettings() {
        return { ...this.globalSettings };
    }
    
    /**
     * איפוס הגדרות מודול לברירת מחדל
     */
    resetModuleSettings(moduleName) {
        this.moduleSettings.delete(moduleName);
        return this.createDefaultModuleSettings(moduleName);
    }
    
    /**
     * איפוס כל ההגדרות
     */
    resetAllSettings() {
        this.moduleSettings.clear();
        this.globalSettings = {
            defaultEngine: 'private',
            fallbackEngine: 'commercial',
            enableLearning: true,
            enableMemory: true,
            securityLevel: 'MAXIMUM',
            governmentMode: true,
            debugMode: false,
            telemetryEnabled: true
        };
        
        this.setDefaultModuleSettings();
        this.saveSettings();
        
        console.log('🔄 All settings reset to defaults');
    }
    
    /**
     * ייצוא הגדרות לקובץ
     */
    exportSettings() {
        const exportData = {
            version: '1.0',
            timestamp: new Date().toISOString(),
            globalSettings: this.globalSettings,
            moduleSettings: Array.from(this.moduleSettings.entries()),
            availableEngines: this.availableEngines
        };
        
        return JSON.stringify(exportData, null, 2);
    }
    
    /**
     * ייבוא הגדרות מקובץ
     */
    importSettings(settingsData) {
        try {
            const data = typeof settingsData === 'string' ? JSON.parse(settingsData) : settingsData;
            
            if (data.globalSettings) {
                this.globalSettings = { ...this.globalSettings, ...data.globalSettings };
            }
            
            if (data.moduleSettings) {
                this.moduleSettings = new Map(data.moduleSettings);
            }
            
            this.saveSettings();
            console.log('📥 Settings imported successfully');
            return true;
            
        } catch (error) {
            console.error('❌ Error importing settings:', error);
            return false;
        }
    }
    
    /**
     * קבלת סטטיסטיקות הגדרות
     */
    getSettingsStats() {
        const engineUsage = {};
        
        for (const [moduleName, settings] of this.moduleSettings.entries()) {
            const engine = settings.engine || this.globalSettings.defaultEngine;
            engineUsage[engine] = (engineUsage[engine] || 0) + 1;
        }
        
        return {
            totalModules: this.moduleSettings.size,
            defaultEngine: this.globalSettings.defaultEngine,
            engineUsage: engineUsage,
            memoryEnabled: Array.from(this.moduleSettings.values()).filter(s => s.enableMemory).length,
            learningEnabled: Array.from(this.moduleSettings.values()).filter(s => s.enableLearning).length,
            lastModified: Math.max(...Array.from(this.moduleSettings.values()).map(s => new Date(s.lastModified || 0).getTime()))
        };
    }
    
    /**
     * שמירת הגדרות לאחסון מקומי
     */
    saveSettings() {
        try {
            const settingsData = {
                globalSettings: this.globalSettings,
                moduleSettings: Array.from(this.moduleSettings.entries()),
                lastSaved: new Date().toISOString()
            };
            
            // שמירה ל-localStorage
            if (typeof localStorage !== 'undefined') {
                localStorage.setItem('effi-central-settings', JSON.stringify(settingsData));
            }
            
            // שמירה לשרת (אם זמין)
            this.saveToServer(settingsData);
            
        } catch (error) {
            console.error('❌ Error saving settings:', error);
        }
    }
    
    /**
     * טעינת הגדרות מאחסון מקומי
     */
    async loadSettings() {
        try {
            let savedData = null;
            
            // טעינה מ-localStorage
            if (typeof localStorage !== 'undefined') {
                const saved = localStorage.getItem('effi-central-settings');
                if (saved) {
                    savedData = JSON.parse(saved);
                }
            }
            
            // טעינה מהשרת (אם זמין)
            if (!savedData) {
                savedData = await this.loadFromServer();
            }
            
            if (savedData) {
                if (savedData.globalSettings) {
                    this.globalSettings = { ...this.globalSettings, ...savedData.globalSettings };
                }
                
                if (savedData.moduleSettings) {
                    this.moduleSettings = new Map(savedData.moduleSettings);
                }
                
                console.log(`📚 Loaded settings for ${this.moduleSettings.size} modules`);
            }
            
        } catch (error) {
            console.error('❌ Error loading settings:', error);
        }
    }
    
    /**
     * שמירה לשרת
     */
    async saveToServer(data) {
        try {
            const response = await fetch('/api/settings/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            if (response.ok) {
                console.log('💾 Settings saved to server');
            }
        } catch (error) {
            // שמירה לשרת נכשלה - לא קריטי
            console.log('📝 Settings saved locally only');
        }
    }
    
    /**
     * טעינה מהשרת
     */
    async loadFromServer() {
        try {
            const response = await fetch('/api/settings/load');
            if (response.ok) {
                const data = await response.json();
                console.log('📡 Settings loaded from server');
                return data;
            }
        } catch (error) {
            console.log('📱 Loading settings from local storage only');
        }
        return null;
    }
    
    /**
     * הפעלת ניטור הגדרות
     */
    startSettingsMonitoring() {
        // ניטור שינויים בהגדרות
        setInterval(() => {
            this.monitorSettingsHealth();
        }, 60000); // כל דקה
        
        console.log('👁️ Settings monitoring activated');
    }
    
    /**
     * ניטור תקינות הגדרות
     */
    monitorSettingsHealth() {
        let issues = 0;
        
        // בדיקת הגדרות מודולים
        for (const [moduleName, settings] of this.moduleSettings.entries()) {
            if (!this.availableEngines[settings.engine]) {
                console.warn(`⚠️ Module '${moduleName}' uses unknown engine: ${settings.engine}`);
                issues++;
            }
        }
        
        // בדיקת הגדרות גלובליות
        if (!this.availableEngines[this.globalSettings.defaultEngine]) {
            console.warn(`⚠️ Default engine not available: ${this.globalSettings.defaultEngine}`);
            issues++;
        }
        
        if (issues === 0) {
            console.log('✅ Settings health check passed');
        } else {
            console.log(`⚠️ Settings health check found ${issues} issues`);
        }
    }
    
    /**
     * קבלת המלצות לאופטימיזציה
     */
    getOptimizationRecommendations() {
        const recommendations = [];
        const stats = this.getSettingsStats();
        
        // המלצה על מנוע ברירת מחדל
        if (stats.engineUsage.commercial > stats.engineUsage.private) {
            recommendations.push({
                type: 'engine',
                priority: 'medium',
                message: 'רוב המודולים משתמשים במנוע מסחרי. שקול להעביר למנוע פרטי לביצועים טובים יותר.',
                action: 'switch_to_private'
            });
        }
        
        // המלצה על זיכרון
        if (stats.memoryEnabled < stats.totalModules * 0.8) {
            recommendations.push({
                type: 'memory',
                priority: 'high',
                message: 'לא כל המודולים משתמשים בזיכרון. הפעלת זיכרון תשפר את הביצועים.',
                action: 'enable_memory'
            });
        }
        
        // המלצה על למידה
        if (stats.learningEnabled < stats.totalModules * 0.8) {
            recommendations.push({
                type: 'learning',
                priority: 'high',
                message: 'לא כל המודולים משתמשים בלמידה. הפעלת למידה תשפר את החוויה.',
                action: 'enable_learning'
            });
        }
        
        return recommendations;
    }
}

// יצירת instance גלובלי (רק בדפדפן)
if (typeof window !== 'undefined') {
    window.EffiCentralSettings = new EffiCentralSettings();
}

// ייצוא למודול Node.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EffiCentralSettings;
}

console.log('🚀 Central Settings Manager loaded successfully!');