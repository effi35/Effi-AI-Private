/**
 * Effi-AI Enterprise API Gateway
 * שער API ברמה ארגונית מתקדם עבור Effi-AI
 * 
 * תכונות עיקריות:
 * - הגנה מפני DDoS והגבלת קצב מתקדמת
 * - אימות JWT וניהול מפתחות API
 * - טרנספורמציה ולידציה של בקשות ותגובות
 * - איזון עומסים וגילוי שירותים
 * - ניטור וניתוח API בזמן אמת
 * - לוגים ורישומי ביקורת מקיפים
 * - דפוס Circuit Breaker לעמידות
 * - גרסאות API ותאימות לאחור
 * - קאש בקשות ואופטימיזציית ביצועים
 * - כותרות אבטחה וניהול CORS
 * - תמיכה ב-Webhooks וזרימת אירועים
 * - יצירת תיעוד API אוטומטית
 * - בדיקות בריאות וניטור שירותים
 * - עיצוב תעבורה ובקרת רוחב פס
 * - אינטגרציה עם ניהול משתמשים ארגוני
 */

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const compression = require('compression');
const cors = require('cors');
const winston = require('winston');
const redis = require('redis');
const EventEmitter = require('events');

class EnterpriseAPIGateway extends EventEmitter {
    constructor(config = {}) {
        super();
        
        // הגדרות בסיסיות
        this.config = {
            port: config.port || 8080,
            redis: config.redis || { host: 'localhost', port: 6379 },
            jwt: {
                secret: config.jwtSecret || crypto.randomBytes(32).toString('hex'),
                expiresIn: config.jwtExpiresIn || '24h'
            },
            rateLimit: {
                windowMs: config.rateLimitWindow || 15 * 60 * 1000, // 15 דקות
                max: config.rateLimitMax || 100,
                ddosThreshold: config.ddosThreshold || 1000
            },
            circuitBreaker: {
                failureThreshold: config.failureThreshold || 5,
                recoveryTimeout: config.recoveryTimeout || 60000
            },
            cache: {
                ttl: config.cacheTtl || 300, // 5 דקות
                maxSize: config.maxCacheSize || 1000
            },
            monitoring: {
                enabled: config.monitoringEnabled !== false,
                alertThresholds: {
                    errorRate: config.errorRateThreshold || 0.05,
                    responseTime: config.responseTimeThreshold || 2000
                }
            },
            security: {
                enableHelmet: config.enableHelmet !== false,
                corsOrigins: config.corsOrigins || ['http://localhost:3000'],
                blockSuspiciousRequests: config.blockSuspiciousRequests !== false
            }
        };

        // אתחול מרכיבי המערכת
        this.initializeComponents();
        this.setupLogger();
        this.setupRedis();
        this.setupMetrics();
        this.setupSecurityPatterns();
        this.setupCircuitBreakers();
        this.setupLoadBalancer();
        this.setupCache();
        this.setupWebhooks();
        
        console.log('🚀 Effi-AI Enterprise API Gateway initialized');
    }

    /**
     * אתחול מרכיבי המערכת הבסיסיים
     */
    initializeComponents() {
        this.services = new Map(); // רשימת שירותים רשומים
        this.apiKeys = new Map(); // מפתחות API פעילים
        this.rateLimiters = new Map(); // מגבילי קצב לפי שירות
        this.circuitBreakers = new Map(); // Circuit breakers לכל שירות
        this.cache = new Map(); // קאש בקשות
        this.metrics = {
            requests: 0,
            errors: 0,
            responseTime: [],
            activeConnections: 0,
            bandwidth: { in: 0, out: 0 }
        };
        this.webhooks = new Map(); // רשימת webhooks רשומים
        this.healthChecks = new Map(); // בדיקות בריאות לשירותים
        this.auditLog = [];
        this.suspiciousPatterns = new Set([
            '/.env',
            '/wp-admin',
            '/admin',
            '/.git',
            '/config',
            '/backup',
            '../',
            '..\\',
            '<script>',
            'javascript:',
            'eval(',
            'base64',
            'union select',
            'drop table'
        ]);
    }

    /**
     * הגדרת מערכת לוגים מתקדמת
     */
    setupLogger() {
        this.logger = winston.createLogger({
            level: 'info',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.errors({ stack: true }),
                winston.format.json(),
                winston.format.printf(({ timestamp, level, message, ...meta }) => {
                    return `${timestamp} [${level.toUpperCase()}]: ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`;
                })
            ),
            defaultMeta: { service: 'effi-api-gateway' },
            transports: [
                new winston.transports.File({ 
                    filename: '/root/Effi_ai_New/logs/api-gateway-error.log', 
                    level: 'error',
                    maxsize: 10485760, // 10MB
                    maxFiles: 5
                }),
                new winston.transports.File({ 
                    filename: '/root/Effi_ai_New/logs/api-gateway-combined.log',
                    maxsize: 10485760,
                    maxFiles: 10
                }),
                new winston.transports.Console({
                    format: winston.format.simple()
                })
            ]
        });

        // לוגר ביקורת נפרד
        this.auditLogger = winston.createLogger({
            level: 'info',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.json()
            ),
            transports: [
                new winston.transports.File({ 
                    filename: '/root/Effi_ai_New/logs/api-gateway-audit.log',
                    maxsize: 20971520, // 20MB
                    maxFiles: 20
                })
            ]
        });
    }

    /**
     * הגדרת חיבור Redis למטמון ונתונים משותפים
     */
    async setupRedis() {
        try {
            this.redisClient = redis.createClient(this.config.redis);
            await this.redisClient.connect();
            this.logger.info('Redis connection established');
        } catch (error) {
            this.logger.warn('Redis connection failed, using in-memory cache', { error: error.message });
            this.redisClient = null;
        }
    }

    /**
     * הגדרת מערכת מדדים וניטור
     */
    setupMetrics() {
        this.metricsCollector = {
            requestCount: 0,
            errorCount: 0,
            totalResponseTime: 0,
            activeConnections: 0,
            bandwidth: { in: 0, out: 0 },
            endpoints: new Map(),
            clients: new Map(),
            alerts: []
        };

        // עדכון מדדים כל 10 שניות
        setInterval(() => {
            this.updateMetrics();
            this.checkAlerts();
        }, 10000);
    }

    /**
     * הגדרת דפוסי אבטחה ותבניות חשודות
     */
    setupSecurityPatterns() {
        this.securityRules = {
            // דפוסי URL חשודים
            suspiciousUrls: [
                /\/\.env/i,
                /\/wp-admin/i,
                /\/admin/i,
                /\/\.git/i,
                /\/config/i,
                /\/backup/i,
                /\.\./,
                /<script>/i,
                /javascript:/i,
                /eval\(/i,
                /union\s+select/i,
                /drop\s+table/i
            ],
            
            // כותרות חשודות
            suspiciousHeaders: [
                'x-forwarded-for',
                'x-real-ip',
                'x-originating-ip'
            ],
            
            // User agents חשודים
            suspiciousUserAgents: [
                /bot/i,
                /crawler/i,
                /spider/i,
                /scanner/i,
                /curl/i,
                /wget/i
            ],
            
            // גדלים מקסימליים
            maxRequestSize: 10 * 1024 * 1024, // 10MB
            maxHeaderSize: 8192 // 8KB
        };
    }

    /**
     * הגדרת Circuit Breakers לכל השירותים
     */
    setupCircuitBreakers() {
        this.circuitBreakerStates = {
            CLOSED: 'closed',
            OPEN: 'open',
            HALF_OPEN: 'half_open'
        };
    }

    /**
     * הגדרת מאזן עומסים
     */
    setupLoadBalancer() {
        this.loadBalancingStrategies = {
            ROUND_ROBIN: 'round_robin',
            LEAST_CONNECTIONS: 'least_connections',
            WEIGHTED: 'weighted',
            IP_HASH: 'ip_hash'
        };
        
        this.serviceInstances = new Map();
    }

    /**
     * הגדרת מערכת קאש מתקדמת
     */
    setupCache() {
        this.cacheStrategies = {
            LRU: 'lru',
            TTL: 'ttl',
            ADAPTIVE: 'adaptive'
        };
        
        // ניקוי קאש אוטומטי
        setInterval(() => {
            this.cleanupCache();
        }, 60000); // כל דקה
    }

    /**
     * הגדרת מערכת Webhooks
     */
    setupWebhooks() {
        this.webhookEvents = {
            REQUEST_RECEIVED: 'request_received',
            RESPONSE_SENT: 'response_sent',
            ERROR_OCCURRED: 'error_occurred',
            RATE_LIMIT_EXCEEDED: 'rate_limit_exceeded',
            SECURITY_VIOLATION: 'security_violation',
            SERVICE_DOWN: 'service_down',
            SERVICE_UP: 'service_up'
        };
    }

    /**
     * רישום שירות חדש במערכת
     */
    registerService(serviceConfig) {
        const {
            name,
            version = '1.0.0',
            endpoints,
            healthCheckUrl,
            instances = [],
            loadBalancing = 'round_robin',
            circuitBreaker = true,
            rateLimit,
            authentication = [],
            cors = {},
            cache = {}
        } = serviceConfig;

        if (!name || !endpoints) {
            throw new Error('שם שירות ונקודות קצה נדרשים');
        }

        const service = {
            name,
            version,
            endpoints: new Map(),
            healthCheckUrl,
            instances: instances.map(instance => ({
                ...instance,
                healthy: true,
                connections: 0,
                responseTime: 0
            })),
            loadBalancing,
            circuitBreaker: circuitBreaker ? {
                state: this.circuitBreakerStates.CLOSED,
                failures: 0,
                lastFailure: null,
                halfOpenRequests: 0
            } : null,
            rateLimit,
            authentication,
            cors,
            cache,
            metrics: {
                requests: 0,
                errors: 0,
                averageResponseTime: 0
            },
            createdAt: new Date(),
            updatedAt: new Date()
        };

        // רישום נקודות קצה
        endpoints.forEach(endpoint => {
            service.endpoints.set(endpoint.path, {
                ...endpoint,
                metrics: {
                    requests: 0,
                    errors: 0,
                    averageResponseTime: 0
                }
            });
        });

        this.services.set(name, service);
        
        // הגדרת Circuit Breaker
        if (circuitBreaker) {
            this.circuitBreakers.set(name, service.circuitBreaker);
        }

        // הגדרת Rate Limiter
        if (rateLimit) {
            this.setupServiceRateLimit(name, rateLimit);
        }

        // התחלת בדיקות בריאות
        if (healthCheckUrl) {
            this.startHealthChecks(name, healthCheckUrl);
        }

        this.logger.info(`שירות ${name} נרשם בהצלחה`, { service: name, version });
        this.auditLogger.info('Service registered', { service: name, version, timestamp: new Date() });

        return service;
    }

    /**
     * הגדרת הגבלת קצב לשירות ספציפי
     */
    setupServiceRateLimit(serviceName, rateLimitConfig) {
        const limiter = rateLimit({
            windowMs: rateLimitConfig.windowMs || this.config.rateLimit.windowMs,
            max: rateLimitConfig.max || this.config.rateLimit.max,
            message: {
                error: 'Too many requests',
                retryAfter: Math.ceil(rateLimitConfig.windowMs / 1000),
                service: serviceName
            },
            standardHeaders: true,
            legacyHeaders: false,
            keyGenerator: (req) => {
                return `${serviceName}:${req.ip}:${req.headers['x-api-key'] || 'anonymous'}`;
            },
            onLimitReached: (req, res) => {
                this.logger.warn('הגבלת קצב הופעלה', {
                    service: serviceName,
                    ip: req.ip,
                    userAgent: req.headers['user-agent']
                });
                
                this.triggerWebhook(this.webhookEvents.RATE_LIMIT_EXCEEDED, {
                    service: serviceName,
                    ip: req.ip,
                    timestamp: new Date()
                });
            }
        });

        this.rateLimiters.set(serviceName, limiter);
    }

    /**
     * התחלת בדיקות בריאות לשירות
     */
    startHealthChecks(serviceName, healthCheckUrl) {
        const healthCheck = {
            url: healthCheckUrl,
            interval: 30000, // 30 שניות
            timeout: 5000, // 5 שניות
            retries: 3,
            lastCheck: null,
            status: 'unknown'
        };

        this.healthChecks.set(serviceName, healthCheck);

        const performHealthCheck = async () => {
            try {
                const startTime = Date.now();
                const response = await fetch(healthCheckUrl, {
                    method: 'GET',
                    timeout: healthCheck.timeout
                });

                const responseTime = Date.now() - startTime;
                const isHealthy = response.ok;

                healthCheck.lastCheck = new Date();
                healthCheck.status = isHealthy ? 'healthy' : 'unhealthy';
                healthCheck.responseTime = responseTime;

                // עדכון סטטוס השירות
                const service = this.services.get(serviceName);
                if (service) {
                    service.instances.forEach(instance => {
                        instance.healthy = isHealthy;
                        instance.responseTime = responseTime;
                    });
                }

                if (!isHealthy) {
                    this.logger.warn(`שירות ${serviceName} לא בריא`, {
                        service: serviceName,
                        responseTime,
                        status: response.status
                    });

                    this.triggerWebhook(this.webhookEvents.SERVICE_DOWN, {
                        service: serviceName,
                        timestamp: new Date(),
                        responseTime
                    });
                } else if (healthCheck.status === 'unhealthy') {
                    this.logger.info(`שירות ${serviceName} חזר לפעילות`, {
                        service: serviceName,
                        responseTime
                    });

                    this.triggerWebhook(this.webhookEvents.SERVICE_UP, {
                        service: serviceName,
                        timestamp: new Date(),
                        responseTime
                    });
                }

            } catch (error) {
                healthCheck.lastCheck = new Date();
                healthCheck.status = 'error';
                healthCheck.error = error.message;

                this.logger.error(`בדיקת בריאות נכשלה עבור ${serviceName}`, {
                    service: serviceName,
                    error: error.message
                });
            }
        };

        // הרצה ראשונית
        performHealthCheck();

        // בדיקות תקופתיות
        setInterval(performHealthCheck, healthCheck.interval);
    }

    /**
     * יצירת מפתח API חדש
     */
    generateApiKey(clientConfig) {
        const {
            clientId,
            name,
            permissions = [],
            rateLimit,
            expiresAt,
            ipWhitelist = [],
            services = []
        } = clientConfig;

        if (!clientId || !name) {
            throw new Error('מזהה לקוח ושם נדרשים');
        }

        const apiKey = crypto.randomBytes(32).toString('hex');
        const keyData = {
            key: apiKey,
            clientId,
            name,
            permissions,
            rateLimit,
            expiresAt: expiresAt ? new Date(expiresAt) : null,
            ipWhitelist,
            services,
            createdAt: new Date(),
            lastUsed: null,
            requestCount: 0,
            active: true
        };

        this.apiKeys.set(apiKey, keyData);
        
        this.logger.info(`מפתח API חדש נוצר`, { clientId, name });
        this.auditLogger.info('API key created', { clientId, name, timestamp: new Date() });

        return { apiKey, ...keyData };
    }

    /**
     * אימות מפתח API
     */
    validateApiKey(apiKey, requiredPermissions = []) {
        const keyData = this.apiKeys.get(apiKey);
        
        if (!keyData) {
            return { valid: false, reason: 'מפתח API לא נמצא' };
        }

        if (!keyData.active) {
            return { valid: false, reason: 'מפתח API לא פעיל' };
        }

        if (keyData.expiresAt && keyData.expiresAt < new Date()) {
            return { valid: false, reason: 'מפתח API פג תוקף' };
        }

        // בדיקת הרשאות
        if (requiredPermissions.length > 0) {
            const hasPermissions = requiredPermissions.every(permission => 
                keyData.permissions.includes(permission) || keyData.permissions.includes('*')
            );
            
            if (!hasPermissions) {
                return { valid: false, reason: 'הרשאות לא מספיקות' };
            }
        }

        // עדכון נתוני שימוש
        keyData.lastUsed = new Date();
        keyData.requestCount++;

        return { valid: true, keyData };
    }

    /**
     * אימות JWT Token
     */
    validateJwtToken(token) {
        try {
            const decoded = jwt.verify(token, this.config.jwt.secret);
            return { valid: true, payload: decoded };
        } catch (error) {
            return { valid: false, reason: error.message };
        }
    }

    /**
     * יצירת JWT Token
     */
    generateJwtToken(payload) {
        return jwt.sign(payload, this.config.jwt.secret, {
            expiresIn: this.config.jwt.expiresIn
        });
    }

    /**
     * בדיקת אבטחה מתקדמת לבקשה
     */
    performSecurityCheck(req) {
        const securityReport = {
            safe: true,
            threats: [],
            riskScore: 0
        };

        // בדיקת URL חשוד
        const url = req.url.toLowerCase();
        for (const pattern of this.securityRules.suspiciousUrls) {
            if (pattern.test(url)) {
                securityReport.threats.push({
                    type: 'suspicious_url',
                    pattern: pattern.source,
                    severity: 'high'
                });
                securityReport.riskScore += 50;
            }
        }

        // בדיקת User Agent חשוד
        const userAgent = req.headers['user-agent'] || '';
        for (const pattern of this.securityRules.suspiciousUserAgents) {
            if (pattern.test(userAgent)) {
                securityReport.threats.push({
                    type: 'suspicious_user_agent',
                    value: userAgent,
                    severity: 'medium'
                });
                securityReport.riskScore += 25;
            }
        }

        // בדיקת גודל בקשה
        const contentLength = parseInt(req.headers['content-length'] || 0);
        if (contentLength > this.securityRules.maxRequestSize) {
            securityReport.threats.push({
                type: 'oversized_request',
                size: contentLength,
                severity: 'medium'
            });
            securityReport.riskScore += 30;
        }

        // בדיקת כותרות חשודות
        for (const header of this.securityRules.suspiciousHeaders) {
            if (req.headers[header]) {
                securityReport.threats.push({
                    type: 'suspicious_header',
                    header: header,
                    value: req.headers[header],
                    severity: 'low'
                });
                securityReport.riskScore += 10;
            }
        }

        // בדיקת דפוסי SQL Injection
        const queryString = req.url.split('?')[1] || '';
        const sqlPatterns = [
            /union\s+select/i,
            /drop\s+table/i,
            /insert\s+into/i,
            /delete\s+from/i,
            /update\s+set/i,
            /exec\s*\(/i,
            /script\s*>/i
        ];

        for (const pattern of sqlPatterns) {
            if (pattern.test(queryString) || pattern.test(JSON.stringify(req.body || {}))) {
                securityReport.threats.push({
                    type: 'sql_injection_attempt',
                    pattern: pattern.source,
                    severity: 'critical'
                });
                securityReport.riskScore += 100;
            }
        }

        securityReport.safe = securityReport.riskScore < 50;

        return securityReport;
    }

    /**
     * בחירת instance של שירות לפי אלגוריתם איזון עומסים
     */
    selectServiceInstance(serviceName, req) {
        const service = this.services.get(serviceName);
        if (!service || !service.instances.length) {
            return null;
        }

        const healthyInstances = service.instances.filter(instance => instance.healthy);
        if (!healthyInstances.length) {
            return null;
        }

        switch (service.loadBalancing) {
            case this.loadBalancingStrategies.ROUND_ROBIN:
                return this.selectRoundRobin(serviceName, healthyInstances);
            
            case this.loadBalancingStrategies.LEAST_CONNECTIONS:
                return this.selectLeastConnections(healthyInstances);
            
            case this.loadBalancingStrategies.WEIGHTED:
                return this.selectWeighted(healthyInstances);
            
            case this.loadBalancingStrategies.IP_HASH:
                return this.selectIpHash(req.ip, healthyInstances);
            
            default:
                return this.selectRoundRobin(serviceName, healthyInstances);
        }
    }

    /**
     * בחירה לפי Round Robin
     */
    selectRoundRobin(serviceName, instances) {
        if (!this.serviceInstances.has(serviceName)) {
            this.serviceInstances.set(serviceName, { currentIndex: 0 });
        }

        const serviceData = this.serviceInstances.get(serviceName);
        const instance = instances[serviceData.currentIndex % instances.length];
        serviceData.currentIndex++;

        return instance;
    }

    /**
     * בחירה לפי מספר החיבורים הנמוך ביותר
     */
    selectLeastConnections(instances) {
        return instances.reduce((min, current) => 
            current.connections < min.connections ? current : min
        );
    }

    /**
     * בחירה לפי משקל
     */
    selectWeighted(instances) {
        const totalWeight = instances.reduce((sum, instance) => sum + (instance.weight || 1), 0);
        const randomWeight = Math.random() * totalWeight;
        
        let currentWeight = 0;
        for (const instance of instances) {
            currentWeight += (instance.weight || 1);
            if (randomWeight <= currentWeight) {
                return instance;
            }
        }
        
        return instances[0];
    }

    /**
     * בחירה לפי hash של IP
     */
    selectIpHash(ip, instances) {
        const hash = crypto.createHash('md5').update(ip).digest('hex');
        const index = parseInt(hash.substring(0, 8), 16) % instances.length;
        return instances[index];
    }

    /**
     * בדיקת Circuit Breaker
     */
    checkCircuitBreaker(serviceName) {
        const breaker = this.circuitBreakers.get(serviceName);
        if (!breaker) {
            return { allowed: true };
        }

        const now = Date.now();

        switch (breaker.state) {
            case this.circuitBreakerStates.CLOSED:
                return { allowed: true };

            case this.circuitBreakerStates.OPEN:
                if (now - breaker.lastFailure > this.config.circuitBreaker.recoveryTimeout) {
                    breaker.state = this.circuitBreakerStates.HALF_OPEN;
                    breaker.halfOpenRequests = 0;
                    return { allowed: true };
                }
                return { allowed: false, reason: 'Circuit breaker is open' };

            case this.circuitBreakerStates.HALF_OPEN:
                if (breaker.halfOpenRequests < 3) {
                    breaker.halfOpenRequests++;
                    return { allowed: true };
                }
                return { allowed: false, reason: 'Circuit breaker is half-open with max requests' };

            default:
                return { allowed: true };
        }
    }

    /**
     * עדכון Circuit Breaker לאחר תגובה
     */
    updateCircuitBreaker(serviceName, success) {
        const breaker = this.circuitBreakers.get(serviceName);
        if (!breaker) return;

        if (success) {
            if (breaker.state === this.circuitBreakerStates.HALF_OPEN) {
                breaker.state = this.circuitBreakerStates.CLOSED;
                breaker.failures = 0;
            }
        } else {
            breaker.failures++;
            breaker.lastFailure = Date.now();

            if (breaker.failures >= this.config.circuitBreaker.failureThreshold) {
                breaker.state = this.circuitBreakerStates.OPEN;
                
                this.logger.warn(`Circuit breaker opened for service ${serviceName}`, {
                    service: serviceName,
                    failures: breaker.failures
                });
            }
        }
    }

    /**
     * בדיקת קאש לבקשה
     */
    getCachedResponse(cacheKey) {
        if (this.redisClient) {
            // TODO: אימפלמנטציה עם Redis
            return null;
        }

        const cached = this.cache.get(cacheKey);
        if (cached && cached.expires > Date.now()) {
            return cached.data;
        }

        return null;
    }

    /**
     * שמירת תגובה בקאש
     */
    setCachedResponse(cacheKey, data, ttl = this.config.cache.ttl) {
        const expires = Date.now() + (ttl * 1000);
        
        if (this.redisClient) {
            // TODO: אימפלמנטציה עם Redis
            return;
        }

        if (this.cache.size >= this.config.cache.maxSize) {
            // מחיקת הכניסה הישנה ביותר
            const oldestKey = this.cache.keys().next().value;
            this.cache.delete(oldestKey);
        }

        this.cache.set(cacheKey, { data, expires });
    }

    /**
     * ניקוי קאש פג תוקף
     */
    cleanupCache() {
        const now = Date.now();
        for (const [key, value] of this.cache.entries()) {
            if (value.expires <= now) {
                this.cache.delete(key);
            }
        }
    }

    /**
     * יצירת מפתח קאש לבקשה
     */
    generateCacheKey(req) {
        const keyData = {
            method: req.method,
            url: req.url,
            headers: req.headers['accept'],
            body: req.method === 'POST' ? req.body : undefined
        };

        return crypto.createHash('md5').update(JSON.stringify(keyData)).digest('hex');
    }

    /**
     * הפעלת webhook
     */
    async triggerWebhook(event, data) {
        const webhooks = this.webhooks.get(event);
        if (!webhooks || !webhooks.length) {
            return;
        }

        for (const webhook of webhooks) {
            try {
                await fetch(webhook.url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Event-Type': event,
                        'X-Timestamp': new Date().toISOString()
                    },
                    body: JSON.stringify(data),
                    timeout: 5000
                });
            } catch (error) {
                this.logger.error('Webhook failed', {
                    event,
                    url: webhook.url,
                    error: error.message
                });
            }
        }
    }

    /**
     * רישום webhook
     */
    registerWebhook(event, url, options = {}) {
        if (!this.webhooks.has(event)) {
            this.webhooks.set(event, []);
        }

        this.webhooks.get(event).push({
            url,
            ...options,
            createdAt: new Date()
        });

        this.logger.info('Webhook registered', { event, url });
    }

    /**
     * עדכון מדדים
     */
    updateMetrics() {
        // חישוב זמן תגובה ממוצע
        if (this.metricsCollector.totalResponseTime > 0 && this.metricsCollector.requestCount > 0) {
            this.metrics.averageResponseTime = this.metricsCollector.totalResponseTime / this.metricsCollector.requestCount;
        }

        // חישוב שיעור שגיאות
        this.metrics.errorRate = this.metricsCollector.requestCount > 0 ? 
            this.metricsCollector.errorCount / this.metricsCollector.requestCount : 0;

        // עדכון מדדי רוחב פס
        this.metrics.bandwidth = { ...this.metricsCollector.bandwidth };
    }

    /**
     * בדיקת התראות
     */
    checkAlerts() {
        const alerts = [];

        // בדיקת שיעור שגיאות גבוה
        if (this.metrics.errorRate > this.config.monitoring.alertThresholds.errorRate) {
            alerts.push({
                type: 'high_error_rate',
                severity: 'critical',
                message: `שיעור שגיאות גבוה: ${(this.metrics.errorRate * 100).toFixed(2)}%`,
                timestamp: new Date()
            });
        }

        // בדיקת זמן תגובה גבוה
        if (this.metrics.averageResponseTime > this.config.monitoring.alertThresholds.responseTime) {
            alerts.push({
                type: 'high_response_time',
                severity: 'warning',
                message: `זמן תגובה גבוה: ${this.metrics.averageResponseTime}ms`,
                timestamp: new Date()
            });
        }

        // שליחת התראות
        if (alerts.length > 0) {
            this.emit('alerts', alerts);
            this.logger.warn('System alerts triggered', { alerts });
        }
    }

    /**
     * מידלוור עיקרי לעיבוד בקשות
     */
    middleware() {
        return async (req, res, next) => {
            const startTime = Date.now();
            
            try {
                // עדכון מדדים
                this.metricsCollector.requestCount++;
                this.metricsCollector.activeConnections++;

                // בדיקת אבטחה
                const securityCheck = this.performSecurityCheck(req);
                if (!securityCheck.safe && this.config.security.blockSuspiciousRequests) {
                    this.logger.warn('בקשה חשודה נחסמה', {
                        ip: req.ip,
                        url: req.url,
                        threats: securityCheck.threats,
                        riskScore: securityCheck.riskScore
                    });

                    this.triggerWebhook(this.webhookEvents.SECURITY_VIOLATION, {
                        ip: req.ip,
                        url: req.url,
                        threats: securityCheck.threats,
                        timestamp: new Date()
                    });

                    return res.status(403).json({
                        error: 'Request blocked due to security policy',
                        riskScore: securityCheck.riskScore
                    });
                }

                // אימות API Key או JWT
                const authResult = await this.authenticate(req);
                if (!authResult.authenticated) {
                    return res.status(401).json({
                        error: 'Authentication failed',
                        reason: authResult.reason
                    });
                }

                req.auth = authResult.data;

                // הגבלת קצב
                const rateLimitResult = await this.checkRateLimit(req);
                if (!rateLimitResult.allowed) {
                    return res.status(429).json({
                        error: 'Rate limit exceeded',
                        retryAfter: rateLimitResult.retryAfter
                    });
                }

                // בדיקת קאש
                const cacheKey = this.generateCacheKey(req);
                const cachedResponse = this.getCachedResponse(cacheKey);
                if (cachedResponse) {
                    return res.json(cachedResponse);
                }

                // מעבר לטיפול הבא
                req.startTime = startTime;
                req.cacheKey = cacheKey;
                next();

            } catch (error) {
                this.metricsCollector.errorCount++;
                this.logger.error('Middleware error', {
                    error: error.message,
                    stack: error.stack,
                    ip: req.ip,
                    url: req.url
                });

                res.status(500).json({
                    error: 'Internal server error',
                    requestId: req.id
                });
            } finally {
                this.metricsCollector.activeConnections--;
            }
        };
    }

    /**
     * אימות בקשה
     */
    async authenticate(req) {
        // בדיקת API Key
        const apiKey = req.headers['x-api-key'];
        if (apiKey) {
            const validation = this.validateApiKey(apiKey);
            if (validation.valid) {
                return {
                    authenticated: true,
                    type: 'api_key',
                    data: validation.keyData
                };
            }
        }

        // בדיקת JWT Token
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            const validation = this.validateJwtToken(token);
            if (validation.valid) {
                return {
                    authenticated: true,
                    type: 'jwt',
                    data: validation.payload
                };
            }
        }

        return {
            authenticated: false,
            reason: 'No valid authentication provided'
        };
    }

    /**
     * בדיקת הגבלת קצב
     */
    async checkRateLimit(req) {
        // TODO: אימפלמנטציה מלאה של Rate Limiting
        return { allowed: true };
    }

    /**
     * קבלת סטטיסטיקות מערכת
     */
    getSystemStats() {
        return {
            uptime: process.uptime(),
            services: this.services.size,
            activeApiKeys: Array.from(this.apiKeys.values()).filter(key => key.active).length,
            metrics: this.metrics,
            circuitBreakers: Array.from(this.circuitBreakers.entries()).map(([service, breaker]) => ({
                service,
                state: breaker.state,
                failures: breaker.failures
            })),
            cache: {
                size: this.cache.size,
                hitRate: this.cacheHitRate || 0
            },
            memory: process.memoryUsage(),
            timestamp: new Date()
        };
    }

    /**
     * יצירת תיעוד API אוטומטית
     */
    generateApiDocumentation() {
        const documentation = {
            title: 'Effi-AI Enterprise API Gateway',
            version: '1.0.0',
            description: 'שער API ברמה ארגונית עבור Effi-AI',
            baseUrl: `http://localhost:${this.config.port}`,
            services: [],
            authentication: {
                apiKey: {
                    type: 'apiKey',
                    in: 'header',
                    name: 'x-api-key'
                },
                bearer: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT'
                }
            },
            generatedAt: new Date()
        };

        // תיעוד שירותים
        for (const [serviceName, service] of this.services.entries()) {
            const serviceDoc = {
                name: serviceName,
                version: service.version,
                description: service.description || '',
                endpoints: []
            };

            for (const [path, endpoint] of service.endpoints.entries()) {
                serviceDoc.endpoints.push({
                    path,
                    method: endpoint.method,
                    description: endpoint.description || '',
                    parameters: endpoint.parameters || [],
                    responses: endpoint.responses || {},
                    authentication: endpoint.authentication || service.authentication
                });
            }

            documentation.services.push(serviceDoc);
        }

        return documentation;
    }

    /**
     * הפעלת השרת
     */
    start() {
        const express = require('express');
        const app = express();

        // הגדרות אבטחה בסיסיות
        if (this.config.security.enableHelmet) {
            app.use(helmet({
                contentSecurityPolicy: {
                    directives: {
                        defaultSrc: ["'self'"],
                        scriptSrc: ["'self'", "'unsafe-inline'"],
                        styleSrc: ["'self'", "'unsafe-inline'"],
                        imgSrc: ["'self'", "data:", "https:"]
                    }
                }
            }));
        }

        // הגדרת CORS
        app.use(cors({
            origin: this.config.security.corsOrigins,
            credentials: true,
            methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
            allowedHeaders: ['Content-Type', 'Authorization', 'x-api-key']
        }));

        // דחיסת תגובות
        app.use(compression());

        // פרסינג JSON
        app.use(express.json({ limit: '10mb' }));
        app.use(express.urlencoded({ extended: true, limit: '10mb' }));

        // מידלוור עיקרי
        app.use('/api', this.middleware());

        // נקודת קצה לבריאות המערכת
        app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                timestamp: new Date(),
                uptime: process.uptime(),
                services: Array.from(this.services.keys())
            });
        });

        // נקודת קצה לסטטיסטיקות
        app.get('/stats', (req, res) => {
            res.json(this.getSystemStats());
        });

        // נקודת קצה לתיעוד API
        app.get('/docs', (req, res) => {
            res.json(this.generateApiDocumentation());
        });

        // הפעלת השרת
        const server = app.listen(this.config.port, () => {
            this.logger.info(`🚀 Effi-AI Enterprise API Gateway started on port ${this.config.port}`);
        });

        // טיפול בכיבוי חד
        process.on('SIGTERM', () => {
            this.logger.info('SIGTERM received, shutting down gracefully');
            server.close(() => {
                if (this.redisClient) {
                    this.redisClient.quit();
                }
                process.exit(0);
            });
        });

        return server;
    }
}

// יצוא המחלקה
module.exports = EnterpriseAPIGateway;

// דוגמה לשימוש
if (require.main === module) {
    const gateway = new EnterpriseAPIGateway({
        port: 8080,
        jwtSecret: process.env.JWT_SECRET || 'your-secret-key',
        rateLimitMax: 1000,
        enableHelmet: true,
        corsOrigins: ['http://localhost:3000', 'https://effi-ai.com'],
        blockSuspiciousRequests: true
    });

    // רישום שירות דוגמה
    gateway.registerService({
        name: 'effi-ai-core',
        version: '1.0.0',
        endpoints: [
            {
                path: '/chat',
                method: 'POST',
                description: 'Chat with Effi-AI',
                authentication: ['api_key']
            },
            {
                path: '/analyze',
                method: 'POST',
                description: 'Analyze data with AI',
                authentication: ['jwt']
            }
        ],
        healthCheckUrl: 'http://localhost:3001/health',
        instances: [
            { url: 'http://localhost:3001', weight: 1 },
            { url: 'http://localhost:3002', weight: 1 }
        ],
        rateLimit: {
            windowMs: 15 * 60 * 1000,
            max: 100
        }
    });

    // יצירת מפתח API דוגמה
    const apiKeyData = gateway.generateApiKey({
        clientId: 'demo-client',
        name: 'Demo Client',
        permissions: ['chat', 'analyze'],
        services: ['effi-ai-core']
    });

    console.log('Demo API Key:', apiKeyData.apiKey);

    // הפעלת השרת
    gateway.start();
}