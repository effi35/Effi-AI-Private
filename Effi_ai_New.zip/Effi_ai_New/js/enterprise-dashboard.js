/**
 * Effi-AI Enterprise Real-Time Monitoring Dashboard
 * Professional Fortune 500 Command Center
 * Hebrew Interface with Real-Time GPS, Security, and Analytics
 * 
 * @author Effi-AI Enterprise Solutions
 * @version 2.0.0
 * @license Enterprise
 */

class EffiAIEnterpriseDashboard {
    constructor() {
        this.isInitialized = false;
        this.isHebrew = true;
        this.websocket = null;
        this.charts = {};
        this.widgets = {};
        this.alertSystem = null;
        this.gpsTracking = [];
        this.securityEvents = [];
        this.systemMetrics = {};
        this.userSessions = new Map();
        this.kpiData = {};
        this.updateInterval = 1000; // 1 second updates
        this.maxDataPoints = 100;
        
        // Hebrew translations
        this.translations = {
            he: {
                dashboard: 'לוח בקרה מתקדם',
                systemHealth: 'בריאות המערכת',
                networkTraffic: 'תעבורת רשת',
                securityThreats: 'איומי אבטחה',
                userActivity: 'פעילות משתמשים',
                gpsTracking: 'מעקב GPS',
                performanceMetrics: 'מדדי ביצועים',
                businessKpis: 'מדדי עסק',
                realTimeAlerts: 'התראות בזמן אמת',
                apiPerformance: 'ביצועי API',
                mobileDevices: 'מכשירים ניידים',
                revenue: 'הכנסות',
                users: 'משתמשים',
                requests: 'בקשות',
                latency: 'השהיה',
                cpu: 'מעבד',
                memory: 'זיכרון',
                disk: 'דיסק',
                network: 'רשת',
                critical: 'קריטי',
                warning: 'אזהרה',
                normal: 'רגיל',
                online: 'מחובר',
                offline: 'מנותק',
                active: 'פעיל',
                inactive: 'לא פעיל',
                location: 'מיקום',
                timestamp: 'זמן',
                export: 'יצוא',
                configure: 'הגדרות',
                refresh: 'רענון',
                details: 'פרטים'
            }
        };
        
        this.init();
    }

    async init() {
        if (this.isInitialized) return;
        
        try {
            console.log('🚀 Initializing Effi-AI Enterprise Dashboard...');
            
            await this.setupWebSocket();
            await this.createDashboardLayout();
            await this.initializeWidgets();
            await this.setupAlertSystem();
            await this.startRealTimeUpdates();
            await this.loadInitialData();
            
            this.isInitialized = true;
            console.log('✅ Enterprise Dashboard initialized successfully');
            
        } catch (error) {
            console.error('❌ Dashboard initialization failed:', error);
            this.showErrorNotification('Failed to initialize dashboard', error.message);
        }
    }

    async setupWebSocket() {
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const host = window.location.host;
            this.websocket = new WebSocket(`${protocol}//${host}/ws-dashboard`);
            
            this.websocket.onopen = () => {
                console.log('🔗 WebSocket connected for real-time updates');
                this.showSuccessNotification('Real-time connection established');
            };
            
            this.websocket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleRealtimeData(data);
                } catch (error) {
                    console.error('WebSocket message parse error:', error);
                }
            };
            
            this.websocket.onclose = () => {
                console.log('🔗 WebSocket disconnected, attempting reconnection...');
                setTimeout(() => this.setupWebSocket(), 5000);
            };
            
            this.websocket.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
            
        } catch (error) {
            console.error('WebSocket setup failed:', error);
            // Fallback to polling
            this.setupPolling();
        }
    }

    setupPolling() {
        setInterval(() => {
            this.fetchRealtimeData();
        }, this.updateInterval);
    }

    async createDashboardLayout() {
        const dashboardHTML = `
            <div id="effi-enterprise-dashboard" class="enterprise-dashboard" dir="rtl">
                <!-- Header -->
                <header class="dashboard-header">
                    <div class="header-brand">
                        <h1><i class="fas fa-chart-line"></i> ${this.t('dashboard')} - Effi-AI Enterprise</h1>
                        <div class="system-status">
                            <span class="status-indicator online" id="system-status"></span>
                            <span class="status-text">${this.t('online')}</span>
                        </div>
                    </div>
                    <div class="header-controls">
                        <button class="btn btn-export" onclick="dashboard.exportData()">
                            <i class="fas fa-download"></i> ${this.t('export')}
                        </button>
                        <button class="btn btn-configure" onclick="dashboard.openSettings()">
                            <i class="fas fa-cog"></i> ${this.t('configure')}
                        </button>
                        <button class="btn btn-refresh" onclick="dashboard.refreshAll()">
                            <i class="fas fa-sync"></i> ${this.t('refresh')}
                        </button>
                    </div>
                </header>

                <!-- Main Dashboard Grid -->
                <div class="dashboard-grid">
                    <!-- Row 1: System Overview -->
                    <div class="widget-row">
                        <div class="widget system-health" id="system-health-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-heartbeat"></i> ${this.t('systemHealth')}</h3>
                                <div class="widget-controls">
                                    <button onclick="dashboard.toggleWidget('system-health')"><i class="fas fa-expand"></i></button>
                                </div>
                            </div>
                            <div class="widget-content">
                                <div class="metrics-grid">
                                    <div class="metric-card cpu">
                                        <div class="metric-icon"><i class="fas fa-microchip"></i></div>
                                        <div class="metric-info">
                                            <div class="metric-label">${this.t('cpu')}</div>
                                            <div class="metric-value" id="cpu-usage">0%</div>
                                            <div class="metric-chart" id="cpu-chart"></div>
                                        </div>
                                    </div>
                                    <div class="metric-card memory">
                                        <div class="metric-icon"><i class="fas fa-memory"></i></div>
                                        <div class="metric-info">
                                            <div class="metric-label">${this.t('memory')}</div>
                                            <div class="metric-value" id="memory-usage">0%</div>
                                            <div class="metric-chart" id="memory-chart"></div>
                                        </div>
                                    </div>
                                    <div class="metric-card disk">
                                        <div class="metric-icon"><i class="fas fa-hdd"></i></div>
                                        <div class="metric-info">
                                            <div class="metric-label">${this.t('disk')}</div>
                                            <div class="metric-value" id="disk-usage">0%</div>
                                            <div class="metric-chart" id="disk-chart"></div>
                                        </div>
                                    </div>
                                    <div class="metric-card network">
                                        <div class="metric-icon"><i class="fas fa-wifi"></i></div>
                                        <div class="metric-info">
                                            <div class="metric-label">${this.t('network')}</div>
                                            <div class="metric-value" id="network-usage">0 MB/s</div>
                                            <div class="metric-chart" id="network-chart"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="widget security-threats" id="security-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-shield-alt"></i> ${this.t('securityThreats')}</h3>
                                <div class="threat-counter" id="threat-counter">0</div>
                            </div>
                            <div class="widget-content">
                                <div class="security-map" id="security-map"></div>
                                <div class="threat-list" id="threat-list"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 2: Real-time Tracking -->
                    <div class="widget-row">
                        <div class="widget gps-tracking large" id="gps-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-map-marker-alt"></i> ${this.t('gpsTracking')} - Live</h3>
                                <div class="tracking-stats">
                                    <span class="active-devices" id="active-devices">0 ${this.t('active')}</span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <div class="gps-map" id="gps-map"></div>
                                <div class="device-list" id="device-list"></div>
                            </div>
                        </div>

                        <div class="widget user-activity" id="activity-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-users"></i> ${this.t('userActivity')}</h3>
                            </div>
                            <div class="widget-content">
                                <div class="activity-heatmap" id="activity-heatmap"></div>
                                <div class="session-stats">
                                    <div class="stat">
                                        <span class="label">${this.t('users')}:</span>
                                        <span class="value" id="active-users">0</span>
                                    </div>
                                    <div class="stat">
                                        <span class="label">${this.t('requests')}:</span>
                                        <span class="value" id="total-requests">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 3: Performance & Business -->
                    <div class="widget-row">
                        <div class="widget api-performance" id="api-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-tachometer-alt"></i> ${this.t('apiPerformance')}</h3>
                            </div>
                            <div class="widget-content">
                                <div class="performance-chart" id="api-chart"></div>
                                <div class="endpoint-stats" id="endpoint-stats"></div>
                            </div>
                        </div>

                        <div class="widget business-kpis" id="kpi-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-chart-bar"></i> ${this.t('businessKpis')}</h3>
                            </div>
                            <div class="widget-content">
                                <div class="kpi-grid">
                                    <div class="kpi-card revenue">
                                        <div class="kpi-icon"><i class="fas fa-dollar-sign"></i></div>
                                        <div class="kpi-info">
                                            <div class="kpi-label">${this.t('revenue')}</div>
                                            <div class="kpi-value" id="revenue-value">$0</div>
                                            <div class="kpi-trend" id="revenue-trend">+0%</div>
                                        </div>
                                    </div>
                                    <div class="kpi-card users">
                                        <div class="kpi-icon"><i class="fas fa-user-friends"></i></div>
                                        <div class="kpi-info">
                                            <div class="kpi-label">${this.t('users')}</div>
                                            <div class="kpi-value" id="user-count">0</div>
                                            <div class="kpi-trend" id="user-trend">+0%</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kpi-chart" id="kpi-chart"></div>
                            </div>
                        </div>

                        <div class="widget mobile-devices" id="mobile-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-mobile-alt"></i> ${this.t('mobileDevices')}</h3>
                            </div>
                            <div class="widget-content">
                                <div class="device-breakdown" id="device-breakdown"></div>
                                <div class="mobile-stats" id="mobile-stats"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 4: Alerts & Logs -->
                    <div class="widget-row">
                        <div class="widget alerts full-width" id="alerts-widget">
                            <div class="widget-header">
                                <h3><i class="fas fa-bell"></i> ${this.t('realTimeAlerts')}</h3>
                                <div class="alert-controls">
                                    <button onclick="dashboard.clearAlerts()">Clear All</button>
                                    <button onclick="dashboard.exportAlerts()">Export</button>
                                </div>
                            </div>
                            <div class="widget-content">
                                <div class="alert-list" id="alert-list"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Alert Notifications -->
                <div id="notification-container" class="notification-container"></div>

                <!-- Modal for Configuration -->
                <div id="dashboard-modal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="dashboard.closeModal()">&times;</span>
                        <div id="modal-body"></div>
                    </div>
                </div>
            </div>
        `;

        // Inject CSS
        this.injectCSS();
        
        // Add to DOM
        if (document.getElementById('effi-enterprise-dashboard')) {
            document.getElementById('effi-enterprise-dashboard').remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', dashboardHTML);
        
        // Set global reference
        window.dashboard = this;
    }

    async initializeWidgets() {
        // Initialize charts with Chart.js
        await this.initializeCharts();
        
        // Initialize maps
        await this.initializeMaps();
        
        // Initialize other widgets
        await this.initializeSystemHealth();
        await this.initializeSecurityWidget();
        await this.initializeUserActivity();
        await this.initializeAPIPerformance();
        await this.initializeBusinessKPIs();
        await this.initializeMobileTracking();
        
        console.log('✅ All widgets initialized');
    }

    async initializeCharts() {
        // CPU Chart
        this.charts.cpu = new Chart(document.getElementById('cpu-chart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'CPU Usage',
                    data: [],
                    borderColor: '#ff6b6b',
                    backgroundColor: 'rgba(255, 107, 107, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, max: 100 }
                },
                plugins: { legend: { display: false } }
            }
        });

        // Memory Chart
        this.charts.memory = new Chart(document.getElementById('memory-chart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Memory Usage',
                    data: [],
                    borderColor: '#4ecdc4',
                    backgroundColor: 'rgba(78, 205, 196, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, max: 100 }
                },
                plugins: { legend: { display: false } }
            }
        });

        // Network Chart
        this.charts.network = new Chart(document.getElementById('network-chart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Network Usage',
                    data: [],
                    borderColor: '#45b7d1',
                    backgroundColor: 'rgba(69, 183, 209, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } }
            }
        });

        // API Performance Chart
        this.charts.api = new Chart(document.getElementById('api-chart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Response Time (ms)',
                    data: [],
                    backgroundColor: 'rgba(255, 193, 7, 0.8)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } }
            }
        });

        // KPI Chart
        this.charts.kpi = new Chart(document.getElementById('kpi-chart'), {
            type: 'doughnut',
            data: {
                labels: ['Revenue', 'Users', 'Requests'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: ['#ff6b6b', '#4ecdc4', '#45b7d1']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    async initializeMaps() {
        // Initialize GPS tracking map
        try {
            this.gpsMap = L.map('gps-map').setView([32.0853, 34.7818], 10); // Tel Aviv center
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(this.gpsMap);

            this.gpsMarkers = L.layerGroup().addTo(this.gpsMap);
            
        } catch (error) {
            console.warn('Map initialization failed, using fallback:', error);
            document.getElementById('gps-map').innerHTML = '<div class="map-fallback">Map loading...</div>';
        }

        // Initialize security map
        try {
            this.securityMap = L.map('security-map').setView([32.0853, 34.7818], 8);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(this.securityMap);

            this.securityMarkers = L.layerGroup().addTo(this.securityMap);
            
        } catch (error) {
            console.warn('Security map initialization failed:', error);
            document.getElementById('security-map').innerHTML = '<div class="map-fallback">Security Map</div>';
        }
    }

    async initializeSystemHealth() {
        // Start system monitoring
        this.systemMonitor = setInterval(() => {
            this.updateSystemMetrics();
        }, 1000);
    }

    async initializeSecurityWidget() {
        // Initialize security monitoring
        this.securityMonitor = setInterval(() => {
            this.updateSecurityThreats();
        }, 2000);
    }

    async initializeUserActivity() {
        // Initialize activity heatmap
        this.activityHeatmap = new CalHeatMap();
        this.activityHeatmap.init({
            selector: '#activity-heatmap',
            domain: 'hour',
            subDomain: 'min',
            data: {},
            cellSize: 10,
            range: 24
        });
    }

    async initializeAPIPerformance() {
        // Monitor API endpoints
        this.apiMonitor = setInterval(() => {
            this.updateAPIMetrics();
        }, 5000);
    }

    async initializeBusinessKPIs() {
        // Update business metrics
        this.kpiMonitor = setInterval(() => {
            this.updateKPIMetrics();
        }, 10000);
    }

    async initializeMobileTracking() {
        // Track mobile device usage
        this.mobileMonitor = setInterval(() => {
            this.updateMobileStats();
        }, 3000);
    }

    async setupAlertSystem() {
        this.alertSystem = {
            alerts: [],
            rules: [
                { metric: 'cpu', threshold: 80, level: 'warning' },
                { metric: 'cpu', threshold: 95, level: 'critical' },
                { metric: 'memory', threshold: 85, level: 'warning' },
                { metric: 'memory', threshold: 95, level: 'critical' },
                { metric: 'security', threshold: 1, level: 'warning' },
                { metric: 'api_latency', threshold: 1000, level: 'warning' }
            ]
        };
    }

    async startRealTimeUpdates() {
        // Main update loop
        this.updateLoop = setInterval(() => {
            this.updateAllWidgets();
        }, this.updateInterval);
        
        console.log('🔄 Real-time updates started');
    }

    async loadInitialData() {
        try {
            // Load historical data
            await this.fetchInitialMetrics();
            await this.fetchGPSData();
            await this.fetchSecurityEvents();
            await this.fetchUserSessions();
            
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }

    async fetchInitialMetrics() {
        try {
            const response = await fetch('/api/dashboard/metrics');
            if (response.ok) {
                const data = await response.json();
                this.processMetricsData(data);
            }
        } catch (error) {
            // Generate mock data for demo
            this.generateMockData();
        }
    }

    generateMockData() {
        // Generate realistic mock data
        this.systemMetrics = {
            cpu: Math.random() * 60 + 20,
            memory: Math.random() * 70 + 15,
            disk: Math.random() * 50 + 30,
            network: Math.random() * 100
        };
        
        this.kpiData = {
            revenue: Math.random() * 100000 + 50000,
            users: Math.floor(Math.random() * 1000 + 500),
            requests: Math.floor(Math.random() * 10000 + 5000)
        };
    }

    async fetchGPSData() {
        try {
            // Parse GPS data from server logs
            const logResponse = await fetch('/server.log');
            if (logResponse.ok) {
                const logText = await logResponse.text();
                this.parseGPSFromLogs(logText);
            }
        } catch (error) {
            console.error('Failed to fetch GPS data:', error);
        }
    }

    parseGPSFromLogs(logText) {
        const gpsRegex = /POST \/\?id=(\d+)&timestamp=(\d+)&lat=([\d.]+)&lon=([\d.]+)&speed=([\d.]+)&bearing=([\d.]+)&altitude=([\d.]+)&accuracy=([\d.]+)&batt=(\d+)/g;
        let match;
        
        this.gpsTracking = [];
        
        while ((match = gpsRegex.exec(logText)) !== null) {
            const [, id, timestamp, lat, lon, speed, bearing, altitude, accuracy, battery] = match;
            
            this.gpsTracking.push({
                id: id,
                timestamp: parseInt(timestamp),
                lat: parseFloat(lat),
                lon: parseFloat(lon),
                speed: parseFloat(speed),
                bearing: parseFloat(bearing),
                altitude: parseFloat(altitude),
                accuracy: parseFloat(accuracy),
                battery: parseInt(battery),
                time: new Date(parseInt(timestamp) * 1000)
            });
        }
        
        this.updateGPSMap();
        console.log(`📍 Parsed ${this.gpsTracking.length} GPS tracking points`);
    }

    async fetchSecurityEvents() {
        try {
            const response = await fetch('/server.log');
            if (response.ok) {
                const logText = await response.text();
                this.parseSecurityFromLogs(logText);
            }
        } catch (error) {
            console.error('Failed to fetch security events:', error);
        }
    }

    parseSecurityFromLogs(logText) {
        const securityPatterns = [
            /GET \/\.well-known\/security\.txt/g,
            /GET \/admin/g,
            /GET \/wp-admin/g,
            /GET \/\.env/g,
            /POST.*(\?.*&.*&)/g
        ];
        
        this.securityEvents = [];
        
        securityPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(logText)) !== null) {
                this.securityEvents.push({
                    type: 'security_scan',
                    timestamp: new Date(),
                    ip: this.extractIPFromLog(match[0]),
                    severity: 'medium',
                    description: 'Security probe detected'
                });
            }
        });
        
        this.updateSecurityWidget();
        console.log(`🛡️ Detected ${this.securityEvents.length} security events`);
    }

    extractIPFromLog(logEntry) {
        // Mock IP extraction - in real implementation, parse from actual logs
        const mockIPs = ['192.168.1.100', '10.0.0.1', '172.16.0.1', '203.0.113.1'];
        return mockIPs[Math.floor(Math.random() * mockIPs.length)];
    }

    handleRealtimeData(data) {
        switch (data.type) {
            case 'system_metrics':
                this.updateSystemMetrics(data.payload);
                break;
            case 'gps_update':
                this.addGPSPoint(data.payload);
                break;
            case 'security_event':
                this.addSecurityEvent(data.payload);
                break;
            case 'user_activity':
                this.updateUserActivity(data.payload);
                break;
            case 'api_metrics':
                this.updateAPIMetrics(data.payload);
                break;
            default:
                console.log('Unknown realtime data type:', data.type);
        }
    }

    updateAllWidgets() {
        try {
            this.updateSystemMetrics();
            this.updateGPSTracking();
            this.updateUserSessions();
            this.updateAPIMetrics();
            this.updateKPIMetrics();
            this.updateMobileStats();
            this.checkAlerts();
        } catch (error) {
            console.error('Widget update error:', error);
        }
    }

    updateSystemMetrics(data = null) {
        if (!data) {
            // Generate realistic fluctuating data
            this.systemMetrics.cpu += (Math.random() - 0.5) * 10;
            this.systemMetrics.cpu = Math.max(0, Math.min(100, this.systemMetrics.cpu));
            
            this.systemMetrics.memory += (Math.random() - 0.5) * 5;
            this.systemMetrics.memory = Math.max(0, Math.min(100, this.systemMetrics.memory));
            
            this.systemMetrics.network = Math.random() * 150;
        } else {
            this.systemMetrics = { ...this.systemMetrics, ...data };
        }
        
        // Update UI
        document.getElementById('cpu-usage').textContent = `${this.systemMetrics.cpu.toFixed(1)}%`;
        document.getElementById('memory-usage').textContent = `${this.systemMetrics.memory.toFixed(1)}%`;
        document.getElementById('network-usage').textContent = `${this.systemMetrics.network.toFixed(1)} MB/s`;
        
        // Update charts
        this.updateChart('cpu', this.systemMetrics.cpu);
        this.updateChart('memory', this.systemMetrics.memory);
        this.updateChart('network', this.systemMetrics.network);
        
        // Update system status indicator
        const status = this.getSystemStatus();
        const indicator = document.getElementById('system-status');
        indicator.className = `status-indicator ${status}`;
    }

    updateChart(chartName, value) {
        const chart = this.charts[chartName];
        if (!chart) return;
        
        const now = new Date().toLocaleTimeString();
        
        // Add new data point
        chart.data.labels.push(now);
        chart.data.datasets[0].data.push(value);
        
        // Keep only last 20 points
        if (chart.data.labels.length > 20) {
            chart.data.labels.shift();
            chart.data.datasets[0].data.shift();
        }
        
        chart.update('none'); // No animation for performance
    }

    updateGPSMap() {
        if (!this.gpsMap || !this.gpsMarkers) return;
        
        // Clear existing markers
        this.gpsMarkers.clearLayers();
        
        // Group tracking points by device ID
        const deviceGroups = {};
        this.gpsTracking.forEach(point => {
            if (!deviceGroups[point.id]) {
                deviceGroups[point.id] = [];
            }
            deviceGroups[point.id].push(point);
        });
        
        // Add markers for each device
        Object.keys(deviceGroups).forEach(deviceId => {
            const points = deviceGroups[deviceId];
            const latestPoint = points[points.length - 1];
            
            // Create device marker
            const marker = L.marker([latestPoint.lat, latestPoint.lon], {
                icon: L.divIcon({
                    className: 'gps-marker',
                    html: `<div class="marker-device" data-battery="${latestPoint.battery}">
                        <i class="fas fa-mobile-alt"></i>
                        <span class="device-id">${deviceId}</span>
                    </div>`,
                    iconSize: [40, 40]
                })
            });
            
            // Add popup with device info
            marker.bindPopup(`
                <div class="device-popup">
                    <h4>Device ${deviceId}</h4>
                    <p><strong>Location:</strong> ${latestPoint.lat.toFixed(6)}, ${latestPoint.lon.toFixed(6)}</p>
                    <p><strong>Battery:</strong> ${latestPoint.battery}%</p>
                    <p><strong>Speed:</strong> ${latestPoint.speed} km/h</p>
                    <p><strong>Last Update:</strong> ${latestPoint.time.toLocaleString()}</p>
                </div>
            `);
            
            this.gpsMarkers.addLayer(marker);
            
            // Add trail if multiple points
            if (points.length > 1) {
                const trail = points.map(p => [p.lat, p.lon]);
                const polyline = L.polyline(trail, {
                    color: this.getDeviceColor(deviceId),
                    weight: 3,
                    opacity: 0.7
                });
                this.gpsMarkers.addLayer(polyline);
            }
        });
        
        // Update device count
        document.getElementById('active-devices').textContent = `${Object.keys(deviceGroups).length} ${this.t('active')}`;
        
        // Update device list
        this.updateDeviceList(deviceGroups);
    }

    updateDeviceList(deviceGroups) {
        const deviceList = document.getElementById('device-list');
        if (!deviceList) return;
        
        const html = Object.keys(deviceGroups).map(deviceId => {
            const points = deviceGroups[deviceId];
            const latest = points[points.length - 1];
            const batteryClass = latest.battery < 20 ? 'low' : latest.battery < 50 ? 'medium' : 'high';
            
            return `
                <div class="device-item" onclick="dashboard.focusDevice('${deviceId}')">
                    <div class="device-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="device-info">
                        <div class="device-name">Device ${deviceId}</div>
                        <div class="device-status">
                            <span class="battery ${batteryClass}">${latest.battery}%</span>
                            <span class="speed">${latest.speed} km/h</span>
                        </div>
                    </div>
                    <div class="device-location">
                        ${latest.lat.toFixed(4)}, ${latest.lon.toFixed(4)}
                    </div>
                </div>
            `;
        }).join('');
        
        deviceList.innerHTML = html;
    }

    updateSecurityWidget() {
        const threatCounter = document.getElementById('threat-counter');
        const threatList = document.getElementById('threat-list');
        
        if (threatCounter) {
            threatCounter.textContent = this.securityEvents.length;
        }
        
        if (threatList && this.securityEvents.length > 0) {
            const recentThreats = this.securityEvents.slice(-10).reverse();
            const html = recentThreats.map(event => `
                <div class="threat-item ${event.severity}">
                    <div class="threat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="threat-info">
                        <div class="threat-type">${event.type}</div>
                        <div class="threat-description">${event.description}</div>
                        <div class="threat-meta">
                            <span class="threat-ip">${event.ip}</span>
                            <span class="threat-time">${event.timestamp.toLocaleTimeString()}</span>
                        </div>
                    </div>
                </div>
            `).join('');
            
            threatList.innerHTML = html;
        }
    }

    updateUserActivity() {
        // Update session count
        const activeUsers = document.getElementById('active-users');
        const totalRequests = document.getElementById('total-requests');
        
        if (activeUsers) {
            activeUsers.textContent = this.userSessions.size;
        }
        
        if (totalRequests) {
            totalRequests.textContent = this.kpiData.requests || 0;
        }
        
        // Update heatmap
        if (this.activityHeatmap) {
            const now = new Date();
            const data = {};
            data[Math.floor(now.getTime() / 1000)] = Math.floor(Math.random() * 10) + 1;
            this.activityHeatmap.update(data);
        }
    }

    updateAPIMetrics() {
        // Generate mock API metrics
        const endpoints = ['/api/auth', '/api/data', '/api/gps', '/api/files'];
        const endpointStats = document.getElementById('endpoint-stats');
        
        if (endpointStats) {
            const stats = endpoints.map(endpoint => {
                const responseTime = Math.random() * 500 + 50;
                const requests = Math.floor(Math.random() * 100) + 10;
                const statusClass = responseTime > 300 ? 'slow' : responseTime > 150 ? 'medium' : 'fast';
                
                return `
                    <div class="endpoint-stat">
                        <div class="endpoint-name">${endpoint}</div>
                        <div class="endpoint-metrics">
                            <span class="response-time ${statusClass}">${responseTime.toFixed(0)}ms</span>
                            <span class="request-count">${requests} req/min</span>
                        </div>
                    </div>
                `;
            }).join('');
            
            endpointStats.innerHTML = stats;
        }
        
        // Update API chart
        if (this.charts.api) {
            this.charts.api.data.labels = endpoints;
            this.charts.api.data.datasets[0].data = endpoints.map(() => Math.random() * 500 + 50);
            this.charts.api.update('none');
        }
    }

    updateKPIMetrics() {
        // Update revenue
        this.kpiData.revenue += (Math.random() - 0.5) * 1000;
        this.kpiData.revenue = Math.max(0, this.kpiData.revenue);
        
        // Update user count
        this.kpiData.users += Math.floor((Math.random() - 0.5) * 10);
        this.kpiData.users = Math.max(0, this.kpiData.users);
        
        // Update requests
        this.kpiData.requests += Math.floor(Math.random() * 100);
        
        // Update UI
        const revenueValue = document.getElementById('revenue-value');
        const userCount = document.getElementById('user-count');
        
        if (revenueValue) {
            revenueValue.textContent = `$${this.kpiData.revenue.toLocaleString()}`;
        }
        
        if (userCount) {
            userCount.textContent = this.kpiData.users.toLocaleString();
        }
        
        // Update KPI chart
        if (this.charts.kpi) {
            this.charts.kpi.data.datasets[0].data = [
                this.kpiData.revenue / 1000,
                this.kpiData.users,
                this.kpiData.requests / 100
            ];
            this.charts.kpi.update('none');
        }
    }

    updateMobileStats() {
        const deviceBreakdown = document.getElementById('device-breakdown');
        const mobileStats = document.getElementById('mobile-stats');
        
        if (deviceBreakdown) {
            const devices = {
                'iOS': Math.floor(Math.random() * 40) + 30,
                'Android': Math.floor(Math.random() * 50) + 40,
                'Desktop': Math.floor(Math.random() * 30) + 20
            };
            
            const total = Object.values(devices).reduce((a, b) => a + b, 0);
            
            const html = Object.entries(devices).map(([device, count]) => {
                const percentage = ((count / total) * 100).toFixed(1);
                return `
                    <div class="device-type">
                        <div class="device-label">${device}</div>
                        <div class="device-bar">
                            <div class="device-fill" style="width: ${percentage}%"></div>
                        </div>
                        <div class="device-percentage">${percentage}%</div>
                    </div>
                `;
            }).join('');
            
            deviceBreakdown.innerHTML = html;
        }
        
        if (mobileStats) {
            mobileStats.innerHTML = `
                <div class="mobile-stat">
                    <span class="label">Active Sessions:</span>
                    <span class="value">${Math.floor(Math.random() * 200) + 100}</span>
                </div>
                <div class="mobile-stat">
                    <span class="label">App Downloads:</span>
                    <span class="value">${Math.floor(Math.random() * 1000) + 500}</span>
                </div>
            `;
        }
    }

    checkAlerts() {
        this.alertSystem.rules.forEach(rule => {
            let value;
            
            switch (rule.metric) {
                case 'cpu':
                    value = this.systemMetrics.cpu;
                    break;
                case 'memory':
                    value = this.systemMetrics.memory;
                    break;
                case 'security':
                    value = this.securityEvents.length;
                    break;
                default:
                    return;
            }
            
            if (value > rule.threshold) {
                this.addAlert({
                    id: Date.now(),
                    level: rule.level,
                    metric: rule.metric,
                    value: value,
                    threshold: rule.threshold,
                    timestamp: new Date(),
                    message: `${rule.metric.toUpperCase()} ${rule.level}: ${value.toFixed(1)} > ${rule.threshold}`
                });
            }
        });
    }

    addAlert(alert) {
        // Avoid duplicate alerts
        const existing = this.alertSystem.alerts.find(a => 
            a.metric === alert.metric && 
            a.level === alert.level && 
            Date.now() - a.timestamp.getTime() < 60000 // 1 minute
        );
        
        if (existing) return;
        
        this.alertSystem.alerts.unshift(alert);
        
        // Keep only last 50 alerts
        if (this.alertSystem.alerts.length > 50) {
            this.alertSystem.alerts = this.alertSystem.alerts.slice(0, 50);
        }
        
        this.updateAlertsList();
        this.showNotification(alert.message, alert.level);
    }

    updateAlertsList() {
        const alertList = document.getElementById('alert-list');
        if (!alertList) return;
        
        const html = this.alertSystem.alerts.map(alert => `
            <div class="alert-item ${alert.level}">
                <div class="alert-icon">
                    <i class="fas fa-${alert.level === 'critical' ? 'exclamation-circle' : 'exclamation-triangle'}"></i>
                </div>
                <div class="alert-content">
                    <div class="alert-message">${alert.message}</div>
                    <div class="alert-meta">
                        <span class="alert-time">${alert.timestamp.toLocaleString()}</span>
                        <span class="alert-metric">${alert.metric}</span>
                    </div>
                </div>
                <div class="alert-actions">
                    <button onclick="dashboard.dismissAlert('${alert.id}')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `).join('');
        
        alertList.innerHTML = html || '<div class="no-alerts">No alerts</div>';
    }

    // Utility Methods
    t(key) {
        return this.translations.he[key] || key;
    }

    getSystemStatus() {
        const cpu = this.systemMetrics.cpu || 0;
        const memory = this.systemMetrics.memory || 0;
        
        if (cpu > 90 || memory > 90) return 'critical';
        if (cpu > 70 || memory > 70) return 'warning';
        return 'online';
    }

    getDeviceColor(deviceId) {
        const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#ffa726', '#ab47bc'];
        return colors[parseInt(deviceId) % colors.length];
    }

    // Event Handlers
    focusDevice(deviceId) {
        const devicePoints = this.gpsTracking.filter(point => point.id === deviceId);
        if (devicePoints.length > 0 && this.gpsMap) {
            const latest = devicePoints[devicePoints.length - 1];
            this.gpsMap.setView([latest.lat, latest.lon], 15);
        }
    }

    toggleWidget(widgetId) {
        const widget = document.getElementById(`${widgetId}-widget`);
        if (widget) {
            widget.classList.toggle('expanded');
        }
    }

    dismissAlert(alertId) {
        this.alertSystem.alerts = this.alertSystem.alerts.filter(alert => alert.id != alertId);
        this.updateAlertsList();
    }

    clearAlerts() {
        this.alertSystem.alerts = [];
        this.updateAlertsList();
    }

    refreshAll() {
        this.loadInitialData();
        this.showSuccessNotification('Dashboard refreshed');
    }

    exportData() {
        const data = {
            timestamp: new Date().toISOString(),
            systemMetrics: this.systemMetrics,
            gpsTracking: this.gpsTracking,
            securityEvents: this.securityEvents,
            kpiData: this.kpiData,
            alerts: this.alertSystem.alerts
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `effi-ai-dashboard-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showSuccessNotification('Data exported successfully');
    }

    exportAlerts() {
        const csv = [
            'Timestamp,Level,Metric,Message,Value,Threshold',
            ...this.alertSystem.alerts.map(alert => 
                `${alert.timestamp.toISOString()},${alert.level},${alert.metric},"${alert.message}",${alert.value},${alert.threshold}`
            )
        ].join('\n');
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `effi-ai-alerts-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    }

    openSettings() {
        const modalBody = document.getElementById('modal-body');
        modalBody.innerHTML = `
            <h2>Dashboard Settings</h2>
            <div class="settings-form">
                <div class="setting-group">
                    <label>Update Interval (ms):</label>
                    <input type="number" id="update-interval" value="${this.updateInterval}" min="500" max="10000">
                </div>
                <div class="setting-group">
                    <label>Max Data Points:</label>
                    <input type="number" id="max-data-points" value="${this.maxDataPoints}" min="20" max="200">
                </div>
                <div class="setting-group">
                    <label>Language:</label>
                    <select id="language">
                        <option value="he" ${this.isHebrew ? 'selected' : ''}>עברית</option>
                        <option value="en" ${!this.isHebrew ? 'selected' : ''}>English</option>
                    </select>
                </div>
                <div class="setting-actions">
                    <button onclick="dashboard.saveSettings()">Save Settings</button>
                    <button onclick="dashboard.resetSettings()">Reset to Default</button>
                </div>
            </div>
        `;
        
        document.getElementById('dashboard-modal').style.display = 'block';
    }

    saveSettings() {
        this.updateInterval = parseInt(document.getElementById('update-interval').value);
        this.maxDataPoints = parseInt(document.getElementById('max-data-points').value);
        
        // Restart update loop with new interval
        clearInterval(this.updateLoop);
        this.startRealTimeUpdates();
        
        this.closeModal();
        this.showSuccessNotification('Settings saved');
    }

    resetSettings() {
        this.updateInterval = 1000;
        this.maxDataPoints = 100;
        this.saveSettings();
    }

    closeModal() {
        document.getElementById('dashboard-modal').style.display = 'none';
    }

    // Notification System
    showNotification(message, type = 'info') {
        const container = document.getElementById('notification-container');
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
            <button onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    showSuccessNotification(message) {
        this.showNotification(message, 'success');
    }

    showErrorNotification(title, message) {
        this.showNotification(`${title}: ${message}`, 'error');
    }

    // CSS Injection
    injectCSS() {
        const css = `
            .enterprise-dashboard {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: #0f1419;
                color: #ffffff;
                min-height: 100vh;
                padding: 0;
                margin: 0;
                direction: rtl;
            }

            .dashboard-header {
                background: linear-gradient(135deg, #1a1f2e 0%, #16213e 100%);
                padding: 1rem 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 2px solid #2d3748;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            }

            .header-brand h1 {
                margin: 0;
                font-size: 1.5rem;
                font-weight: 700;
                color: #00d4ff;
                text-shadow: 0 0 10px rgba(0, 212, 255, 0.3);
            }

            .system-status {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                margin-top: 0.5rem;
            }

            .status-indicator {
                width: 12px;
                height: 12px;
                border-radius: 50%;
                animation: pulse 2s infinite;
            }

            .status-indicator.online { background: #00ff88; }
            .status-indicator.warning { background: #ffaa00; }
            .status-indicator.critical { background: #ff4444; }

            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }

            .header-controls {
                display: flex;
                gap: 1rem;
            }

            .btn {
                background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
                border: none;
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(74, 144, 226, 0.3);
            }

            .dashboard-grid {
                padding: 1rem;
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .widget-row {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 1rem;
            }

            .widget {
                background: linear-gradient(135deg, #1e2a3a 0%, #2d3748 100%);
                border-radius: 12px;
                border: 1px solid #4a5568;
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
                overflow: hidden;
                transition: all 0.3s ease;
            }

            .widget:hover {
                transform: translateY(-5px);
                box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
            }

            .widget.large {
                grid-column: span 2;
            }

            .widget.full-width {
                grid-column: 1 / -1;
            }

            .widget-header {
                background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
                padding: 1rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #4a5568;
            }

            .widget-header h3 {
                margin: 0;
                font-size: 1.1rem;
                font-weight: 600;
                color: #00d4ff;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .widget-content {
                padding: 1rem;
            }

            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
            }

            .metric-card {
                background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
                padding: 1rem;
                border-radius: 8px;
                border: 1px solid #4a5568;
                display: flex;
                align-items: center;
                gap: 1rem;
                transition: all 0.3s ease;
            }

            .metric-card:hover {
                background: linear-gradient(135deg, #4a5568 0%, #5a6578 100%);
            }

            .metric-icon {
                font-size: 2rem;
                padding: 0.5rem;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .metric-card.cpu .metric-icon {
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
                color: white;
            }

            .metric-card.memory .metric-icon {
                background: linear-gradient(135deg, #4ecdc4, #44a08d);
                color: white;
            }

            .metric-card.disk .metric-icon {
                background: linear-gradient(135deg, #45b7d1, #3498db);
                color: white;
            }

            .metric-card.network .metric-icon {
                background: linear-gradient(135deg, #f093fb, #f5576c);
                color: white;
            }

            .metric-info {
                flex: 1;
            }

            .metric-label {
                font-size: 0.9rem;
                color: #a0aec0;
                margin-bottom: 0.25rem;
            }

            .metric-value {
                font-size: 1.5rem;
                font-weight: 700;
                color: #00d4ff;
                margin-bottom: 0.5rem;
            }

            .metric-chart {
                height: 40px;
                position: relative;
            }

            .gps-map, .security-map {
                height: 300px;
                border-radius: 8px;
                margin-bottom: 1rem;
            }

            .map-fallback {
                height: 300px;
                background: #2d3748;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #a0aec0;
                font-size: 1.1rem;
            }

            .device-list {
                max-height: 200px;
                overflow-y: auto;
            }

            .device-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.75rem;
                background: #2d3748;
                border-radius: 6px;
                margin-bottom: 0.5rem;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .device-item:hover {
                background: #4a5568;
                transform: translateX(-5px);
            }

            .device-icon {
                color: #00d4ff;
                font-size: 1.2rem;
            }

            .device-info {
                flex: 1;
            }

            .device-name {
                font-weight: 600;
                color: #ffffff;
            }

            .device-status {
                display: flex;
                gap: 1rem;
                margin-top: 0.25rem;
            }

            .battery.low { color: #ff4444; }
            .battery.medium { color: #ffaa00; }
            .battery.high { color: #00ff88; }

            .device-location {
                font-family: 'Courier New', monospace;
                font-size: 0.85rem;
                color: #a0aec0;
            }

            .threat-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.75rem;
                border-left: 4px solid;
                margin-bottom: 0.5rem;
                border-radius: 0 6px 6px 0;
            }

            .threat-item.warning {
                background: rgba(255, 170, 0, 0.1);
                border-color: #ffaa00;
            }

            .threat-item.critical {
                background: rgba(255, 68, 68, 0.1);
                border-color: #ff4444;
            }

            .threat-icon {
                color: #ffaa00;
                font-size: 1.2rem;
            }

            .threat-item.critical .threat-icon {
                color: #ff4444;
            }

            .threat-info {
                flex: 1;
            }

            .threat-type {
                font-weight: 600;
                color: #ffffff;
            }

            .threat-description {
                color: #a0aec0;
                font-size: 0.9rem;
            }

            .threat-meta {
                display: flex;
                gap: 1rem;
                margin-top: 0.25rem;
                font-size: 0.8rem;
                color: #718096;
            }

            .kpi-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-bottom: 1rem;
            }

            .kpi-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 1.5rem;
                border-radius: 10px;
                display: flex;
                align-items: center;
                gap: 1rem;
                color: white;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            }

            .kpi-icon {
                font-size: 2.5rem;
                opacity: 0.8;
            }

            .kpi-info {
                flex: 1;
            }

            .kpi-label {
                font-size: 0.9rem;
                opacity: 0.8;
                margin-bottom: 0.25rem;
            }

            .kpi-value {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 0.25rem;
            }

            .kpi-trend {
                font-size: 0.9rem;
                font-weight: 600;
            }

            .alert-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 1rem;
                margin-bottom: 0.5rem;
                border-radius: 8px;
                border-left: 4px solid;
                transition: all 0.3s ease;
            }

            .alert-item.warning {
                background: rgba(255, 193, 7, 0.1);
                border-color: #ffc107;
            }

            .alert-item.critical {
                background: rgba(220, 53, 69, 0.1);
                border-color: #dc3545;
            }

            .alert-icon {
                font-size: 1.5rem;
            }

            .alert-item.warning .alert-icon { color: #ffc107; }
            .alert-item.critical .alert-icon { color: #dc3545; }

            .alert-content {
                flex: 1;
            }

            .alert-message {
                font-weight: 600;
                color: #ffffff;
                margin-bottom: 0.25rem;
            }

            .alert-meta {
                display: flex;
                gap: 1rem;
                font-size: 0.8rem;
                color: #a0aec0;
            }

            .alert-actions button {
                background: none;
                border: none;
                color: #a0aec0;
                cursor: pointer;
                padding: 0.25rem;
                border-radius: 4px;
                transition: all 0.3s ease;
            }

            .alert-actions button:hover {
                background: #4a5568;
                color: #ffffff;
            }

            .notification-container {
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 10000;
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }

            .notification {
                background: #2d3748;
                color: white;
                padding: 1rem;
                border-radius: 8px;
                border-left: 4px solid;
                display: flex;
                align-items: center;
                justify-content: space-between;
                min-width: 300px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
                animation: slideIn 0.3s ease;
            }

            .notification.success { border-color: #48bb78; }
            .notification.error { border-color: #f56565; }
            .notification.info { border-color: #4299e1; }

            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .notification button {
                background: none;
                border: none;
                color: #a0aec0;
                cursor: pointer;
                padding: 0.25rem;
            }

            @keyframes slideIn {
                from {
                    transform: translateX(-100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }

            .modal {
                display: none;
                position: fixed;
                z-index: 10001;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
            }

            .modal-content {
                background-color: #2d3748;
                margin: 5% auto;
                padding: 2rem;
                border-radius: 12px;
                width: 90%;
                max-width: 600px;
                color: white;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            }

            .close {
                color: #a0aec0;
                float: left;
                font-size: 2rem;
                font-weight: bold;
                cursor: pointer;
                margin-bottom: 1rem;
            }

            .close:hover {
                color: #ffffff;
            }

            .settings-form {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .setting-group {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }

            .setting-group label {
                font-weight: 600;
                color: #00d4ff;
            }

            .setting-group input,
            .setting-group select {
                background: #4a5568;
                border: 1px solid #718096;
                color: white;
                padding: 0.5rem;
                border-radius: 6px;
            }

            .setting-actions {
                display: flex;
                gap: 1rem;
                justify-content: flex-end;
                margin-top: 1rem;
            }

            /* Scrollbar styling */
            ::-webkit-scrollbar {
                width: 8px;
            }

            ::-webkit-scrollbar-track {
                background: #2d3748;
            }

            ::-webkit-scrollbar-thumb {
                background: #4a5568;
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb:hover {
                background: #718096;
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .dashboard-grid {
                    padding: 0.5rem;
                }
                
                .widget-row {
                    grid-template-columns: 1fr;
                }
                
                .metrics-grid {
                    grid-template-columns: 1fr;
                }
                
                .header-controls {
                    flex-direction: column;
                    gap: 0.5rem;
                }
            }
        `;

        const style = document.createElement('style');
        style.textContent = css;
        document.head.appendChild(style);
    }

    // Cleanup
    destroy() {
        if (this.websocket) {
            this.websocket.close();
        }
        
        clearInterval(this.updateLoop);
        clearInterval(this.systemMonitor);
        clearInterval(this.securityMonitor);
        clearInterval(this.apiMonitor);
        clearInterval(this.kpiMonitor);
        clearInterval(this.mobileMonitor);
        
        const dashboard = document.getElementById('effi-enterprise-dashboard');
        if (dashboard) {
            dashboard.remove();
        }
        
        this.isInitialized = false;
        console.log('🧹 Dashboard destroyed and cleaned up');
    }
}

// Auto-initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Load required libraries
    const loadLibraries = async () => {
        // Chart.js
        if (!window.Chart) {
            const chartScript = document.createElement('script');
            chartScript.src = 'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js';
            document.head.appendChild(chartScript);
            
            await new Promise(resolve => {
                chartScript.onload = resolve;
            });
        }
        
        // Leaflet Maps
        if (!window.L) {
            const leafletCSS = document.createElement('link');
            leafletCSS.rel = 'stylesheet';
            leafletCSS.href = 'https://unpkg.com/leaflet@1.9.3/dist/leaflet.css';
            document.head.appendChild(leafletCSS);
            
            const leafletScript = document.createElement('script');
            leafletScript.src = 'https://unpkg.com/leaflet@1.9.3/dist/leaflet.js';
            document.head.appendChild(leafletScript);
            
            await new Promise(resolve => {
                leafletScript.onload = resolve;
            });
        }
        
        // Font Awesome
        if (!document.querySelector('link[href*="font-awesome"]')) {
            const fontAwesome = document.createElement('link');
            fontAwesome.rel = 'stylesheet';
            fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
            document.head.appendChild(fontAwesome);
        }
    };
    
    loadLibraries().then(() => {
        // Initialize dashboard
        window.effiAIDashboard = new EffiAIEnterpriseDashboard();
        console.log('🚀 Effi-AI Enterprise Dashboard loaded and ready!');
    }).catch(error => {
        console.error('Failed to load dashboard libraries:', error);
    });
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EffiAIEnterpriseDashboard;
}