/**
 * 🔄 Effi-AI Workflow Engine
 * מנוע תהליכי עבודה מתקדם - ניהול אוטומציה ותהליכים
 * תשתית לניהול, יצירה וביצוע של workflows מורכבים
 */

class EffiWorkflowEngine {
    constructor() {
        this.workflows = new Map();
        this.templates = new Map();
        this.executingWorkflows = new Map();
        this.scheduledTasks = new Map();
        this.triggers = new Map();
        this.eventBus = new EventTarget();
        this.analytics = new Map();
        this.visualBuilder = null;
        this.errorHandlers = new Map();
        
        // הגדרות מערכת
        this.config = {
            maxConcurrentWorkflows: 50,
            enableScheduling: true,
            enableVisualBuilder: true,
            autoSave: true,
            errorRecovery: true,
            performanceMonitoring: true,
            maxExecutionTime: 300000, // 5 דקות
            retryAttempts: 3
        };
        
        this.initializeEngine();
    }

    /**
     * אתחול מנוע התהליכים
     */
    async initializeEngine() {
        console.log('🔄 Initializing Workflow Engine...');
        
        try {
            // טעינת templates מובנים
            await this.loadBuiltInTemplates();
            
            // אתחול מערכת scheduling
            this.initializeScheduler();
            
            // אתחול Visual Builder
            this.initializeVisualBuilder();
            
            // הפעלת מונטור ביצועים
            this.startPerformanceMonitoring();
            
            // טעינת workflows שמורים
            await this.loadPersistedWorkflows();
            
            // רישום עם המערכת המודולרית
            this.registerWithModularSystem();
            
            console.log('✅ Workflow Engine Active');
            
        } catch (error) {
            console.error('❌ Failed to initialize Workflow Engine:', error);
        }
    }

    /**
     * יצירת workflow חדש
     */
    createWorkflow(workflowId, definition, options = {}) {
        try {
            const workflow = {
                id: workflowId,
                name: definition.name || workflowId,
                description: definition.description || '',
                version: definition.version || '1.0.0',
                author: definition.author || 'System',
                createdAt: Date.now(),
                updatedAt: Date.now(),
                
                // מבנה התהליך
                nodes: definition.nodes || [],
                edges: definition.edges || [],
                variables: definition.variables || {},
                
                // הגדרות ביצוע
                config: {
                    timeout: definition.timeout || this.config.maxExecutionTime,
                    retries: definition.retries || this.config.retryAttempts,
                    parallel: definition.parallel || false,
                    conditions: definition.conditions || [],
                    triggers: definition.triggers || [],
                    ...options
                },
                
                // סטטיסטיקות
                stats: {
                    executions: 0,
                    successes: 0,
                    failures: 0,
                    avgExecutionTime: 0,
                    lastExecution: null,
                    totalExecutionTime: 0
                },
                
                // מצב
                status: 'created',
                enabled: true
            };

            // ולידציה
            if (!this.validateWorkflow(workflow)) {
                throw new Error(`Workflow validation failed: ${workflowId}`);
            }

            this.workflows.set(workflowId, workflow);
            
            // אירוע יצירה
            this.emitWorkflowEvent('workflow_created', {
                workflowId,
                name: workflow.name
            });

            // שמירה אוטומטית
            if (this.config.autoSave) {
                this.saveWorkflows();
            }

            console.log(`✅ Workflow '${workflowId}' created successfully`);
            return workflow;

        } catch (error) {
            console.error(`❌ Failed to create workflow '${workflowId}':`, error);
            throw error;
        }
    }

    /**
     * ביצוע workflow
     */
    async executeWorkflow(workflowId, inputData = {}, options = {}) {
        const startTime = performance.now();
        const executionId = `${workflowId}_${Date.now()}`;
        
        try {
            const workflow = this.workflows.get(workflowId);
            if (!workflow) {
                throw new Error(`Workflow '${workflowId}' not found`);
            }

            if (!workflow.enabled) {
                throw new Error(`Workflow '${workflowId}' is disabled`);
            }

            // בדיקת מגבלת concurrent executions
            if (this.executingWorkflows.size >= this.config.maxConcurrentWorkflows) {
                throw new Error('Maximum concurrent workflows limit reached');
            }

            console.log(`🔄 Executing workflow '${workflowId}' (${executionId})`);

            // יצירת context לביצוע
            const executionContext = {
                id: executionId,
                workflowId,
                workflow,
                startTime,
                inputData,
                variables: { ...workflow.variables, ...inputData },
                currentNode: null,
                executionPath: [],
                results: {},
                errors: [],
                status: 'running',
                options
            };

            this.executingWorkflows.set(executionId, executionContext);

            // אירוע התחלת ביצוע
            this.emitWorkflowEvent('workflow_started', {
                workflowId,
                executionId,
                inputData
            });

            // ביצוע בפועל
            const result = await this.executeWorkflowNodes(executionContext);

            // חישוב זמן ביצוע
            const executionTime = performance.now() - startTime;

            // עדכון סטטיסטיקות
            this.updateWorkflowStats(workflowId, executionTime, true);

            // ניקוי context
            this.executingWorkflows.delete(executionId);

            // אירוע סיום מוצלח
            this.emitWorkflowEvent('workflow_completed', {
                workflowId,
                executionId,
                executionTime,
                result
            });

            console.log(`✅ Workflow '${workflowId}' completed in ${executionTime.toFixed(2)}ms`);
            return result;

        } catch (error) {
            const executionTime = performance.now() - startTime;
            
            // עדכון סטטיסטיקות כשל
            this.updateWorkflowStats(workflowId, executionTime, false);
            
            // ניקוי context
            this.executingWorkflows.delete(executionId);

            // טיפול בשגיאה
            await this.handleWorkflowError(workflowId, executionId, error, options);

            // אירוע שגיאה
            this.emitWorkflowEvent('workflow_failed', {
                workflowId,
                executionId,
                error: error.message,
                executionTime
            });

            console.error(`❌ Workflow '${workflowId}' failed:`, error);
            
            if (!options.suppressErrors) {
                throw error;
            }
            
            return { error: error.message, executionTime };
        }
    }

    /**
     * ביצוע צמתי הworkflow
     */
    async executeWorkflowNodes(context) {
        const { workflow, variables } = context;
        const results = {};
        let currentNodes = this.findStartNodes(workflow);

        while (currentNodes.length > 0) {
            const nextNodes = [];

            // ביצוע parallel או sequential
            if (workflow.config.parallel) {
                const promises = currentNodes.map(node => this.executeNode(node, context));
                const nodeResults = await Promise.allSettled(promises);
                
                nodeResults.forEach((result, index) => {
                    const node = currentNodes[index];
                    if (result.status === 'fulfilled') {
                        results[node.id] = result.value;
                        nextNodes.push(...this.findNextNodes(node, workflow, result.value));
                    } else {
                        throw new Error(`Node '${node.id}' failed: ${result.reason}`);
                    }
                });
            } else {
                for (const node of currentNodes) {
                    const nodeResult = await this.executeNode(node, context);
                    results[node.id] = nodeResult;
                    nextNodes.push(...this.findNextNodes(node, workflow, nodeResult));
                }
            }

            currentNodes = nextNodes;
            
            // בדיקת timeout
            if (performance.now() - context.startTime > workflow.config.timeout) {
                throw new Error('Workflow execution timeout');
            }
        }

        return results;
    }

    /**
     * ביצוע צומת בודד
     */
    async executeNode(node, context) {
        try {
            context.currentNode = node;
            context.executionPath.push(node.id);

            console.log(`🔹 Executing node '${node.id}' (type: ${node.type})`);

            let result;

            switch (node.type) {
                case 'start':
                    result = { status: 'started', timestamp: Date.now() };
                    break;
                    
                case 'end':
                    result = { status: 'completed', timestamp: Date.now() };
                    break;
                    
                case 'task':
                    result = await this.executeTaskNode(node, context);
                    break;
                    
                case 'condition':
                    result = await this.executeConditionNode(node, context);
                    break;
                    
                case 'loop':
                    result = await this.executeLoopNode(node, context);
                    break;
                    
                case 'parallel':
                    result = await this.executeParallelNode(node, context);
                    break;
                    
                case 'delay':
                    result = await this.executeDelayNode(node, context);
                    break;
                    
                case 'script':
                    result = await this.executeScriptNode(node, context);
                    break;
                    
                case 'api':
                    result = await this.executeApiNode(node, context);
                    break;
                    
                case 'notification':
                    result = await this.executeNotificationNode(node, context);
                    break;
                    
                default:
                    throw new Error(`Unknown node type: ${node.type}`);
            }

            // שמירת תוצאה בcontext
            context.results[node.id] = result;

            return result;

        } catch (error) {
            context.errors.push({
                nodeId: node.id,
                error: error.message,
                timestamp: Date.now()
            });
            
            throw new Error(`Node '${node.id}' execution failed: ${error.message}`);
        }
    }

    /**
     * ביצוע task node
     */
    async executeTaskNode(node, context) {
        const { config, data } = node;
        
        switch (config.taskType) {
            case 'function':
                return await this.executeFunction(config.functionName, data, context);
                
            case 'module':
                return await this.executeModuleFunction(config.moduleId, config.functionName, data, context);
                
            case 'command':
                return await this.executeCommand(config.command, data, context);
                
            case 'http':
                return await this.executeHttpRequest(config.method, config.url, data, context);
                
            default:
                throw new Error(`Unknown task type: ${config.taskType}`);
        }
    }

    /**
     * ביצוע condition node
     */
    async executeConditionNode(node, context) {
        const { condition, trueNodes, falseNodes } = node.config;
        const result = await this.evaluateCondition(condition, context);
        
        return {
            conditionResult: result,
            nextNodes: result ? trueNodes : falseNodes,
            timestamp: Date.now()
        };
    }

    /**
     * ביצוע loop node
     */
    async executeLoopNode(node, context) {
        const { condition, maxIterations, loopNodes } = node.config;
        const results = [];
        let iteration = 0;
        
        while (iteration < maxIterations) {
            if (condition && !await this.evaluateCondition(condition, context)) {
                break;
            }
            
            const iterationResult = {};
            for (const loopNode of loopNodes) {
                iterationResult[loopNode.id] = await this.executeNode(loopNode, context);
            }
            
            results.push(iterationResult);
            iteration++;
        }
        
        return {
            iterations: iteration,
            results,
            timestamp: Date.now()
        };
    }

    /**
     * ביצוע parallel node
     */
    async executeParallelNode(node, context) {
        const { parallelNodes } = node.config;
        const promises = parallelNodes.map(parallelNode => 
            this.executeNode(parallelNode, context)
        );
        
        const results = await Promise.allSettled(promises);
        
        return {
            results: results.map((result, index) => ({
                nodeId: parallelNodes[index].id,
                status: result.status,
                value: result.status === 'fulfilled' ? result.value : result.reason
            })),
            timestamp: Date.now()
        };
    }

    /**
     * ביצוע delay node
     */
    async executeDelayNode(node, context) {
        const delay = node.config.delay || 1000;
        
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    delayed: delay,
                    timestamp: Date.now()
                });
            }, delay);
        });
    }

    /**
     * ביצוע script node
     */
    async executeScriptNode(node, context) {
        const { script, language } = node.config;
        
        if (language === 'javascript') {
            // ביצוע JavaScript בסביבה מבוקרת
            const func = new Function('context', 'variables', script);
            return func(context, context.variables);
        }
        
        throw new Error(`Unsupported script language: ${language}`);
    }

    /**
     * ביצוע API node
     */
    async executeApiNode(node, context) {
        const { method, url, headers, body } = node.config;
        
        const response = await fetch(url, {
            method: method || 'GET',
            headers: headers || {},
            body: body ? JSON.stringify(body) : undefined
        });
        
        const result = await response.json();
        
        return {
            status: response.status,
            statusText: response.statusText,
            data: result,
            timestamp: Date.now()
        };
    }

    /**
     * ביצוע notification node
     */
    async executeNotificationNode(node, context) {
        const { type, title, message, data } = node.config;
        
        const notification = {
            type,
            title,
            message,
            data,
            timestamp: Date.now(),
            workflowId: context.workflowId,
            executionId: context.id
        };
        
        // שליחת התראה
        this.emitWorkflowEvent('workflow_notification', notification);
        
        // אם זמין - שימוש במערכת התראות של המערכת
        if (window.EffiNotifications) {
            window.EffiNotifications.show(notification);
        }
        
        return notification;
    }

    /**
     * יצירת workflow מתוך template
     */
    createWorkflowFromTemplate(templateId, workflowId, customizations = {}) {
        const template = this.templates.get(templateId);
        if (!template) {
            throw new Error(`Template '${templateId}' not found`);
        }

        const workflowDefinition = {
            ...template.definition,
            name: customizations.name || template.definition.name,
            description: customizations.description || template.definition.description,
            ...customizations
        };

        return this.createWorkflow(workflowId, workflowDefinition);
    }

    /**
     * תזמון workflow
     */
    scheduleWorkflow(workflowId, schedule, inputData = {}) {
        if (!this.config.enableScheduling) {
            throw new Error('Scheduling is disabled');
        }

        const scheduleId = `${workflowId}_${Date.now()}`;
        const scheduledTask = {
            id: scheduleId,
            workflowId,
            schedule,
            inputData,
            createdAt: Date.now(),
            nextRun: this.calculateNextRun(schedule),
            enabled: true,
            executions: 0
        };

        this.scheduledTasks.set(scheduleId, scheduledTask);

        console.log(`📅 Workflow '${workflowId}' scheduled with ID '${scheduleId}'`);
        return scheduleId;
    }

    /**
     * רישום trigger לworkflow
     */
    registerTrigger(workflowId, triggerConfig) {
        const triggerId = `${workflowId}_${triggerConfig.type}_${Date.now()}`;
        const trigger = {
            id: triggerId,
            workflowId,
            type: triggerConfig.type,
            config: triggerConfig,
            enabled: true,
            createdAt: Date.now()
        };

        this.triggers.set(triggerId, trigger);

        // רישום event listener בהתאם לסוג הtrigger
        this.setupTriggerListener(trigger);

        console.log(`🎯 Trigger '${triggerId}' registered for workflow '${workflowId}'`);
        return triggerId;
    }

    /**
     * טעינת templates מובנים
     */
    async loadBuiltInTemplates() {
        const builtInTemplates = [
            {
                id: 'data_backup',
                name: 'גיבוי נתונים',
                description: 'תהליך גיבוי אוטומטי של נתונים',
                category: 'backup',
                definition: {
                    name: 'גיבוי נתונים',
                    nodes: [
                        { id: 'start', type: 'start', x: 100, y: 100 },
                        { id: 'check_space', type: 'task', x: 300, y: 100, config: { taskType: 'function', functionName: 'checkDiskSpace' } },
                        { id: 'backup_files', type: 'task', x: 500, y: 100, config: { taskType: 'function', functionName: 'backupFiles' } },
                        { id: 'verify_backup', type: 'task', x: 700, y: 100, config: { taskType: 'function', functionName: 'verifyBackup' } },
                        { id: 'notification', type: 'notification', x: 900, y: 100, config: { type: 'success', title: 'גיבוי הושלם', message: 'הגיבוי הושלם בהצלחה' } },
                        { id: 'end', type: 'end', x: 1100, y: 100 }
                    ],
                    edges: [
                        { from: 'start', to: 'check_space' },
                        { from: 'check_space', to: 'backup_files' },
                        { from: 'backup_files', to: 'verify_backup' },
                        { from: 'verify_backup', to: 'notification' },
                        { from: 'notification', to: 'end' }
                    ]
                }
            },
            {
                id: 'system_monitoring',
                name: 'ניטור מערכת',
                description: 'ניטור ביצועי מערכת ושליחת התראות',
                category: 'monitoring',
                definition: {
                    name: 'ניטור מערכת',
                    nodes: [
                        { id: 'start', type: 'start', x: 100, y: 100 },
                        { id: 'check_cpu', type: 'task', x: 300, y: 100, config: { taskType: 'function', functionName: 'checkCpuUsage' } },
                        { id: 'check_memory', type: 'task', x: 300, y: 200, config: { taskType: 'function', functionName: 'checkMemoryUsage' } },
                        { id: 'check_disk', type: 'task', x: 300, y: 300, config: { taskType: 'function', functionName: 'checkDiskUsage' } },
                        { id: 'evaluate_health', type: 'condition', x: 500, y: 200, config: { condition: 'cpu < 80 && memory < 85 && disk < 90' } },
                        { id: 'send_alert', type: 'notification', x: 700, y: 100, config: { type: 'warning', title: 'אזהרת מערכת', message: 'ביצועי המערכת ירודים' } },
                        { id: 'log_status', type: 'task', x: 700, y: 300, config: { taskType: 'function', functionName: 'logSystemStatus' } },
                        { id: 'end', type: 'end', x: 900, y: 200 }
                    ],
                    edges: [
                        { from: 'start', to: 'check_cpu' },
                        { from: 'start', to: 'check_memory' },
                        { from: 'start', to: 'check_disk' },
                        { from: 'check_cpu', to: 'evaluate_health' },
                        { from: 'check_memory', to: 'evaluate_health' },
                        { from: 'check_disk', to: 'evaluate_health' },
                        { from: 'evaluate_health', to: 'send_alert', condition: 'false' },
                        { from: 'evaluate_health', to: 'log_status', condition: 'true' },
                        { from: 'send_alert', to: 'end' },
                        { from: 'log_status', to: 'end' }
                    ]
                }
            },
            {
                id: 'data_processing',
                name: 'עיבוד נתונים',
                description: 'תהליך עיבוד וניתוח נתונים',
                category: 'data',
                definition: {
                    name: 'עיבוד נתונים',
                    nodes: [
                        { id: 'start', type: 'start', x: 100, y: 100 },
                        { id: 'load_data', type: 'task', x: 300, y: 100, config: { taskType: 'function', functionName: 'loadDataSet' } },
                        { id: 'validate_data', type: 'condition', x: 500, y: 100, config: { condition: 'data.length > 0 && data.valid' } },
                        { id: 'clean_data', type: 'task', x: 700, y: 100, config: { taskType: 'function', functionName: 'cleanData' } },
                        { id: 'process_data', type: 'loop', x: 900, y: 100, config: { maxIterations: 100, condition: 'hasMoreData' } },
                        { id: 'save_results', type: 'task', x: 1100, y: 100, config: { taskType: 'function', functionName: 'saveResults' } },
                        { id: 'error_handler', type: 'notification', x: 500, y: 300, config: { type: 'error', title: 'שגיאת נתונים', message: 'הנתונים לא תקינים' } },
                        { id: 'end', type: 'end', x: 1300, y: 100 }
                    ],
                    edges: [
                        { from: 'start', to: 'load_data' },
                        { from: 'load_data', to: 'validate_data' },
                        { from: 'validate_data', to: 'clean_data', condition: 'true' },
                        { from: 'validate_data', to: 'error_handler', condition: 'false' },
                        { from: 'clean_data', to: 'process_data' },
                        { from: 'process_data', to: 'save_results' },
                        { from: 'save_results', to: 'end' },
                        { from: 'error_handler', to: 'end' }
                    ]
                }
            },
            {
                id: 'api_integration',
                name: 'אינטגרציית API',
                description: 'תהליך אינטגרציה עם API חיצוני',
                category: 'integration',
                definition: {
                    name: 'אינטגרציית API',
                    nodes: [
                        { id: 'start', type: 'start', x: 100, y: 100 },
                        { id: 'authenticate', type: 'api', x: 300, y: 100, config: { method: 'POST', url: '/api/auth', headers: { 'Content-Type': 'application/json' } } },
                        { id: 'fetch_data', type: 'api', x: 500, y: 100, config: { method: 'GET', url: '/api/data' } },
                        { id: 'transform_data', type: 'script', x: 700, y: 100, config: { language: 'javascript', script: 'return data.map(item => ({ ...item, processed: true }))' } },
                        { id: 'validate_response', type: 'condition', x: 900, y: 100, config: { condition: 'response.status === 200' } },
                        { id: 'save_data', type: 'task', x: 1100, y: 100, config: { taskType: 'function', functionName: 'saveApiData' } },
                        { id: 'retry_request', type: 'delay', x: 900, y: 300, config: { delay: 5000 } },
                        { id: 'end', type: 'end', x: 1300, y: 100 }
                    ],
                    edges: [
                        { from: 'start', to: 'authenticate' },
                        { from: 'authenticate', to: 'fetch_data' },
                        { from: 'fetch_data', to: 'transform_data' },
                        { from: 'transform_data', to: 'validate_response' },
                        { from: 'validate_response', to: 'save_data', condition: 'true' },
                        { from: 'validate_response', to: 'retry_request', condition: 'false' },
                        { from: 'retry_request', to: 'fetch_data' },
                        { from: 'save_data', to: 'end' }
                    ]
                }
            }
        ];

        for (const template of builtInTemplates) {
            this.templates.set(template.id, template);
        }

        console.log(`✅ Loaded ${builtInTemplates.length} built-in workflow templates`);
    }

    /**
     * פונקציה לטעינת workflow templates (נדרשת לעמוד האוטומציה)
     */
    loadWorkflowTemplates() {
        const templatesArray = Array.from(this.templates.values());
        
        // קיבוץ לפי קטגוריות
        const categorizedTemplates = templatesArray.reduce((acc, template) => {
            const category = template.category || 'general';
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(template);
            return acc;
        }, {});

        return {
            templates: templatesArray,
            categories: categorizedTemplates,
            total: templatesArray.length
        };
    }

    /**
     * אתחול מערכת scheduling
     */
    initializeScheduler() {
        if (!this.config.enableScheduling) {
            return;
        }

        // בדיקת משימות מתוזמנות כל דקה
        setInterval(() => {
            this.checkScheduledTasks();
        }, 60000);

        console.log('📅 Workflow Scheduler initialized');
    }

    /**
     * בדיקת משימות מתוזמנות
     */
    async checkScheduledTasks() {
        const now = Date.now();
        
        for (const [scheduleId, task] of this.scheduledTasks) {
            if (task.enabled && task.nextRun <= now) {
                try {
                    console.log(`📅 Executing scheduled workflow '${task.workflowId}'`);
                    
                    await this.executeWorkflow(task.workflowId, task.inputData, {
                        scheduledExecution: true,
                        scheduleId
                    });
                    
                    task.executions++;
                    task.nextRun = this.calculateNextRun(task.schedule);
                    
                } catch (error) {
                    console.error(`❌ Scheduled workflow execution failed:`, error);
                }
            }
        }
    }

    /**
     * חישוב זמן ההרצה הבא
     */
    calculateNextRun(schedule) {
        const now = new Date();
        
        switch (schedule.type) {
            case 'interval':
                return now.getTime() + schedule.interval;
                
            case 'daily':
                const nextDay = new Date(now);
                nextDay.setDate(nextDay.getDate() + 1);
                nextDay.setHours(schedule.hour || 0, schedule.minute || 0, 0, 0);
                return nextDay.getTime();
                
            case 'weekly':
                const nextWeek = new Date(now);
                nextWeek.setDate(nextWeek.getDate() + (7 - nextWeek.getDay() + schedule.dayOfWeek));
                nextWeek.setHours(schedule.hour || 0, schedule.minute || 0, 0, 0);
                return nextWeek.getTime();
                
            case 'cron':
                // פשטן של cron expression
                return this.parseCronExpression(schedule.expression);
                
            default:
                throw new Error(`Unknown schedule type: ${schedule.type}`);
        }
    }

    /**
     * אתחול Visual Builder
     */
    initializeVisualBuilder() {
        if (!this.config.enableVisualBuilder) {
            return;
        }

        this.visualBuilder = {
            canvas: null,
            nodes: new Map(),
            edges: new Map(),
            selectedNodes: new Set(),
            draggedNode: null,
            
            // פונקציות ציור
            drawNode: (node, ctx) => this.drawWorkflowNode(node, ctx),
            drawEdge: (edge, ctx) => this.drawWorkflowEdge(edge, ctx),
            
            // אירועים
            onNodeDrag: (node, x, y) => this.handleNodeDrag(node, x, y),
            onNodeConnect: (fromNode, toNode) => this.handleNodeConnect(fromNode, toNode),
            onNodeDelete: (node) => this.handleNodeDelete(node)
        };

        console.log('🎨 Visual Workflow Builder initialized');
    }

    /**
     * הפעלת מונטור ביצועים
     */
    startPerformanceMonitoring() {
        if (!this.config.performanceMonitoring) {
            return;
        }

        setInterval(() => {
            this.analyzeWorkflowPerformance();
        }, 60000); // כל דקה

        setInterval(() => {
            this.optimizeWorkflowExecution();
        }, 300000); // כל 5 דקות

        console.log('📊 Workflow Performance Monitoring started');
    }

    /**
     * ניתוח ביצועי workflows
     */
    analyzeWorkflowPerformance() {
        const performanceReport = {
            timestamp: Date.now(),
            totalWorkflows: this.workflows.size,
            activeExecutions: this.executingWorkflows.size,
            workflows: []
        };

        for (const [workflowId, workflow] of this.workflows) {
            const stats = workflow.stats;
            const health = this.calculateWorkflowHealth(stats);
            
            performanceReport.workflows.push({
                id: workflowId,
                name: workflow.name,
                health,
                stats: { ...stats },
                recommendations: this.generateWorkflowRecommendations(workflowId, stats)
            });
        }

        // שמירה ב-analytics
        this.analytics.set(`performance_${Date.now()}`, performanceReport);

        // שמירה ב-memory system אם זמין
        if (window.EffiMemory) {
            window.EffiMemory.learn({
                type: 'workflow_performance',
                data: performanceReport
            }, {
                system: 'workflow_engine',
                analysis: 'performance'
            });
        }

        return performanceReport;
    }

    /**
     * טיפול בשגיאות workflow
     */
    async handleWorkflowError(workflowId, executionId, error, options) {
        const workflow = this.workflows.get(workflowId);
        if (!workflow) return;

        // רישום השגיאה
        console.error(`❌ Workflow Error [${workflowId}]:`, error);

        // ניסיון recovery אם מופעל
        if (this.config.errorRecovery && workflow.config.retries > 0) {
            const retryCount = options.retryCount || 0;
            
            if (retryCount < workflow.config.retries) {
                console.log(`🔄 Retrying workflow '${workflowId}' (attempt ${retryCount + 1}/${workflow.config.retries})`);
                
                // המתנה קצרה לפני ניסיון חוזר
                setTimeout(async () => {
                    try {
                        await this.executeWorkflow(workflowId, options.inputData, {
                            ...options,
                            retryCount: retryCount + 1
                        });
                    } catch (retryError) {
                        console.error(`❌ Retry failed for workflow '${workflowId}':`, retryError);
                    }
                }, 1000 * (retryCount + 1)); // exponential backoff
            }
        }

        // הפעלת error handlers מותאמים
        const errorHandler = this.errorHandlers.get(workflowId);
        if (errorHandler) {
            try {
                await errorHandler(error, executionId, options);
            } catch (handlerError) {
                console.error('Error handler failed:', handlerError);
            }
        }
    }

    /**
     * רישום עם המערכת המודולרית
     */
    registerWithModularSystem() {
        if (window.EffiModular) {
            window.EffiModular.registerModule('WorkflowEngine', EffiWorkflowEngine, [], {
                version: '1.0.0',
                author: 'Effi-AI System'
            });
            
            console.log('🔗 Workflow Engine registered with Modular System');
        }
    }

    /**
     * שמירה וטעינה של workflows
     */
    async saveWorkflows() {
        try {
            const workflowsData = {
                workflows: Array.from(this.workflows.entries()),
                templates: Array.from(this.templates.entries()),
                scheduledTasks: Array.from(this.scheduledTasks.entries()),
                triggers: Array.from(this.triggers.entries()),
                config: this.config,
                timestamp: Date.now()
            };

            localStorage.setItem('effi-workflows', JSON.stringify(workflowsData));
            console.log('✅ Workflows saved successfully');
            return true;
            
        } catch (error) {
            console.error('❌ Failed to save workflows:', error);
            return false;
        }
    }

    async loadPersistedWorkflows() {
        try {
            const workflowsData = localStorage.getItem('effi-workflows');
            if (!workflowsData) {
                return false;
            }

            const parsedData = JSON.parse(workflowsData);
            
            // שחזור workflows
            this.workflows = new Map(parsedData.workflows || []);
            
            // שחזור scheduled tasks
            this.scheduledTasks = new Map(parsedData.scheduledTasks || []);
            
            // שחזור triggers
            this.triggers = new Map(parsedData.triggers || []);
            
            // שחזור קונפיגורציה
            this.config = { ...this.config, ...parsedData.config };

            console.log(`✅ Loaded ${this.workflows.size} persisted workflows`);
            return true;
            
        } catch (error) {
            console.warn('⚠️ Could not load persisted workflows:', error);
            return false;
        }
    }

    // === UTILITY METHODS ===

    validateWorkflow(workflow) {
        // בדיקות בסיסיות
        if (!workflow.id || !workflow.name) {
            return false;
        }

        // בדיקת nodes
        if (!workflow.nodes || workflow.nodes.length === 0) {
            return false;
        }

        // בדיקת start node
        const startNodes = workflow.nodes.filter(node => node.type === 'start');
        if (startNodes.length !== 1) {
            return false;
        }

        // בדיקת end nodes
        const endNodes = workflow.nodes.filter(node => node.type === 'end');
        if (endNodes.length === 0) {
            return false;
        }

        return true;
    }

    findStartNodes(workflow) {
        return workflow.nodes.filter(node => node.type === 'start');
    }

    findNextNodes(currentNode, workflow, nodeResult) {
        const nextNodes = [];
        
        for (const edge of workflow.edges) {
            if (edge.from === currentNode.id) {
                // בדיקת תנאי אם קיים
                if (edge.condition) {
                    const conditionMet = this.evaluateCondition(edge.condition, { result: nodeResult });
                    if (!conditionMet) continue;
                }
                
                const nextNode = workflow.nodes.find(node => node.id === edge.to);
                if (nextNode) {
                    nextNodes.push(nextNode);
                }
            }
        }
        
        return nextNodes;
    }

    async evaluateCondition(condition, context) {
        try {
            // יצירת פונקציה לבדיקת התנאי
            const conditionFunc = new Function('context', 'variables', 'result', `return ${condition}`);
            return conditionFunc(context, context.variables, context.result);
        } catch (error) {
            console.error('Condition evaluation failed:', error);
            return false;
        }
    }

    async executeFunction(functionName, data, context) {
        if (typeof window[functionName] === 'function') {
            return await window[functionName](data, context);
        }
        throw new Error(`Function '${functionName}' not found`);
    }

    async executeModuleFunction(moduleId, functionName, data, context) {
        if (window.EffiModular) {
            return await window.EffiModular.executeModuleFunction(moduleId, functionName, data, context);
        }
        throw new Error('Modular system not available');
    }

    updateWorkflowStats(workflowId, executionTime, success) {
        const workflow = this.workflows.get(workflowId);
        if (!workflow) return;

        const stats = workflow.stats;
        stats.executions++;
        stats.lastExecution = Date.now();
        stats.totalExecutionTime += executionTime;
        stats.avgExecutionTime = stats.totalExecutionTime / stats.executions;

        if (success) {
            stats.successes++;
        } else {
            stats.failures++;
        }

        workflow.updatedAt = Date.now();
    }

    calculateWorkflowHealth(stats) {
        if (stats.executions === 0) return 1;
        
        const successRate = stats.successes / stats.executions;
        const performanceScore = Math.min(10000 / Math.max(stats.avgExecutionTime, 1), 1);
        
        return successRate * 0.7 + performanceScore * 0.3;
    }

    emitWorkflowEvent(eventType, data) {
        const event = new CustomEvent(eventType, { detail: data });
        this.eventBus.dispatchEvent(event);
        
        // גם ב-window לגישה גלובלית
        window.dispatchEvent(new CustomEvent(`effi_${eventType}`, { detail: data }));
    }

    setupTriggerListener(trigger) {
        switch (trigger.type) {
            case 'event':
                window.addEventListener(trigger.config.eventName, async (event) => {
                    if (trigger.enabled) {
                        await this.executeWorkflow(trigger.workflowId, event.detail);
                    }
                });
                break;
                
            case 'time':
                // תזמון לפי זמן מסוים
                const targetTime = new Date(trigger.config.time);
                const delay = targetTime.getTime() - Date.now();
                if (delay > 0) {
                    setTimeout(async () => {
                        if (trigger.enabled) {
                            await this.executeWorkflow(trigger.workflowId);
                        }
                    }, delay);
                }
                break;
                
            case 'condition':
                // בדיקה תקופתית של תנאי
                setInterval(async () => {
                    if (trigger.enabled && await this.evaluateCondition(trigger.config.condition, {})) {
                        await this.executeWorkflow(trigger.workflowId);
                    }
                }, trigger.config.checkInterval || 60000);
                break;
        }
    }

    generateWorkflowRecommendations(workflowId, stats) {
        const recommendations = [];

        if (stats.avgExecutionTime > 30000) {
            recommendations.push('בדוק אופטימיזציה של צמתים איטיים');
        }

        if (stats.failures > stats.successes * 0.1) {
            recommendations.push('שיעור כשלונות גבוה - בדוק טיפול בשגיאות');
        }

        if (stats.executions > 1000 && stats.avgExecutionTime > 10000) {
            recommendations.push('שקול חלוקה למספר workflows קטנים יותר');
        }

        return recommendations;
    }

    optimizeWorkflowExecution() {
        for (const [workflowId, workflow] of this.workflows) {
            const health = this.calculateWorkflowHealth(workflow.stats);
            
            if (health < 0.5) {
                console.warn(`🔧 Workflow '${workflowId}' needs optimization (health: ${health.toFixed(2)})`);
                
                // ניסיון אופטימיזציה אוטומטית
                this.attemptWorkflowOptimization(workflowId, workflow);
            }
        }
    }

    async attemptWorkflowOptimization(workflowId, workflow) {
        try {
            // איפוס סטטיסטיקות אם יש יותר מדי כשלונות
            if (workflow.stats.failures > 100) {
                workflow.stats.failures = Math.floor(workflow.stats.failures * 0.5);
                console.log(`🔧 Reset failure count for workflow '${workflowId}'`);
            }

            // אופטימיזציה של timeout אם הביצוע איטי
            if (workflow.stats.avgExecutionTime > workflow.config.timeout * 0.8) {
                workflow.config.timeout = Math.min(workflow.config.timeout * 1.5, this.config.maxExecutionTime);
                console.log(`🔧 Increased timeout for workflow '${workflowId}'`);
            }

        } catch (error) {
            console.error(`Failed to optimize workflow '${workflowId}':`, error);
        }
    }

    // === PUBLIC API METHODS ===

    /**
     * קבלת רשימת workflows
     */
    getWorkflows() {
        return Array.from(this.workflows.values());
    }

    /**
     * קבלת workflow ספציפי
     */
    getWorkflow(workflowId) {
        return this.workflows.get(workflowId);
    }

    /**
     * עדכון workflow
     */
    updateWorkflow(workflowId, updates) {
        const workflow = this.workflows.get(workflowId);
        if (!workflow) {
            throw new Error(`Workflow '${workflowId}' not found`);
        }

        Object.assign(workflow, updates);
        workflow.updatedAt = Date.now();

        if (this.config.autoSave) {
            this.saveWorkflows();
        }

        this.emitWorkflowEvent('workflow_updated', { workflowId, updates });
        return workflow;
    }

    /**
     * מחיקת workflow
     */
    deleteWorkflow(workflowId) {
        const workflow = this.workflows.get(workflowId);
        if (!workflow) {
            return false;
        }

        // מחיקת scheduled tasks קשורים
        for (const [scheduleId, task] of this.scheduledTasks) {
            if (task.workflowId === workflowId) {
                this.scheduledTasks.delete(scheduleId);
            }
        }

        // מחיקת triggers קשורים
        for (const [triggerId, trigger] of this.triggers) {
            if (trigger.workflowId === workflowId) {
                this.triggers.delete(triggerId);
            }
        }

        this.workflows.delete(workflowId);

        if (this.config.autoSave) {
            this.saveWorkflows();
        }

        this.emitWorkflowEvent('workflow_deleted', { workflowId });
        return true;
    }

    /**
     * הפסקת workflow בביצוע
     */
    stopWorkflow(executionId) {
        const execution = this.executingWorkflows.get(executionId);
        if (execution) {
            execution.status = 'stopped';
            this.executingWorkflows.delete(executionId);
            
            this.emitWorkflowEvent('workflow_stopped', {
                workflowId: execution.workflowId,
                executionId
            });
            
            return true;
        }
        return false;
    }

    /**
     * קבלת סטטיסטיקות מערכת
     */
    getSystemStats() {
        return {
            totalWorkflows: this.workflows.size,
            activeExecutions: this.executingWorkflows.size,
            scheduledTasks: this.scheduledTasks.size,
            triggers: this.triggers.size,
            templates: this.templates.size,
            systemHealth: this.calculateSystemHealth()
        };
    }

    calculateSystemHealth() {
        const workflowHealths = Array.from(this.workflows.values())
            .map(w => this.calculateWorkflowHealth(w.stats));
        
        if (workflowHealths.length === 0) return 1;
        
        return workflowHealths.reduce((sum, health) => sum + health, 0) / workflowHealths.length;
    }

    /**
     * יצוא workflows
     */
    exportWorkflows(workflowIds = null) {
        const workflowsToExport = workflowIds 
            ? workflowIds.map(id => this.workflows.get(id)).filter(Boolean)
            : Array.from(this.workflows.values());

        return {
            version: '1.0.0',
            exportedAt: Date.now(),
            workflows: workflowsToExport,
            templates: Array.from(this.templates.values())
        };
    }

    /**
     * יבוא workflows
     */
    async importWorkflows(importData, options = {}) {
        try {
            const { workflows, templates } = importData;
            let imported = 0;

            // יבוא templates
            if (templates) {
                for (const template of templates) {
                    if (options.overwrite || !this.templates.has(template.id)) {
                        this.templates.set(template.id, template);
                    }
                }
            }

            // יבוא workflows
            if (workflows) {
                for (const workflow of workflows) {
                    if (options.overwrite || !this.workflows.has(workflow.id)) {
                        this.workflows.set(workflow.id, workflow);
                        imported++;
                    }
                }
            }

            if (this.config.autoSave) {
                await this.saveWorkflows();
            }

            console.log(`✅ Imported ${imported} workflows`);
            return { imported, total: workflows?.length || 0 };

        } catch (error) {
            console.error('❌ Failed to import workflows:', error);
            throw error;
        }
    }
}

// יצירת מופע גלובלי
window.EffiWorkflowEngine = new EffiWorkflowEngine();

// רישום הפונקציה הגלובלית הנדרשת
window.loadWorkflowTemplates = () => {
    return window.EffiWorkflowEngine.loadWorkflowTemplates();
};

console.log('🔄 Effi Workflow Engine Loaded - Ready for Automation!');