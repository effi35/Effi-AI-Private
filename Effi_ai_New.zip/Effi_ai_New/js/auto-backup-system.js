/**
 * 💾 Effi-AI Auto Backup System
 * מערכת גיבויים אוטומטיים כל 5 דקות עם איתנה מלאה
 * גיבוי חכם עם דחיסה, הצפנה ושחזור מהיר
 */

class EffiAutoBackupSystem {
    constructor() {
        this.backupInterval = 5 * 60 * 1000; // 5 דקות
        this.maxBackups = 20; // מקסימום 20 גיבויים
        this.compressionEnabled = true;
        this.encryptionEnabled = true;
        this.backupHistory = [];
        this.backupStats = {
            totalBackups: 0,
            successfulBackups: 0,
            failedBackups: 0,
            totalDataSaved: 0,
            compressionRatio: 0
        };
        
        // אחסון מקומי מתקדם
        this.storageEngine = this.detectBestStorage();
        
        this.initializeBackupSystem();
    }

    /**
     * אתחול מערכת הגיבויים
     */
    initializeBackupSystem() {
        console.log('💾 Initializing Auto Backup System...');
        
        // טעינת היסטוריית גיבויים
        this.loadBackupHistory();
        
        // הפעלת גיבוי אוטומטי
        this.startAutoBackup();
        
        // הפעלת ניטור מקום
        this.startStorageMonitoring();
        
        // רישום event listeners
        this.setupEventListeners();
        
        console.log('✅ Auto Backup System Active - Every 5 minutes');
    }

    /**
     * ביצוע גיבוי מלא של המערכת
     */
    async performFullBackup(manual = false) {
        const backupId = this.generateBackupId();
        const startTime = Date.now();
        
        try {
            console.log(`💾 Starting ${manual ? 'manual' : 'automatic'} backup: ${backupId}`);
            
            // איסוף נתונים לגיבוי
            const backupData = await this.collectBackupData();
            
            // דחיסה (אם מופעלת)
            const compressedData = this.compressionEnabled ? 
                await this.compressData(backupData) : backupData;
            
            // הצפנה (אם מופעלת)
            const encryptedData = this.encryptionEnabled ? 
                await this.encryptData(compressedData) : compressedData;
            
            // מטא-דאטה של הגיבוי
            const backupMetadata = {
                id: backupId,
                timestamp: startTime,
                type: manual ? 'manual' : 'automatic',
                size: this.calculateDataSize(encryptedData),
                originalSize: this.calculateDataSize(backupData),
                compressed: this.compressionEnabled,
                encrypted: this.encryptionEnabled,
                version: this.getSystemVersion(),
                integrity: await this.calculateIntegrityHash(encryptedData)
            };
            
            // שמירת הגיבוי
            const success = await this.saveBackup(backupId, encryptedData, backupMetadata);
            
            if (success) {
                // עדכון היסטוריה
                this.backupHistory.unshift(backupMetadata);
                
                // ניקוי גיבויים ישנים
                await this.cleanupOldBackups();
                
                // עדכון סטטיסטיקות
                this.updateBackupStats(backupMetadata, true);
                
                const duration = Date.now() - startTime;
                console.log(`✅ Backup completed: ${backupId} in ${duration}ms`);
                
                // למידה במערכת זיכרון
                if (window.EffiMemory) {
                    window.EffiMemory.learn({
                        type: 'backup_success',
                        id: backupId,
                        duration,
                        size: backupMetadata.size
                    }, {
                        system: 'backup',
                        automatic: !manual
                    });
                }
                
                return {
                    success: true,
                    backupId,
                    duration,
                    metadata: backupMetadata
                };
                
            } else {
                throw new Error('Failed to save backup');
            }
            
        } catch (error) {
            console.error(`❌ Backup failed: ${backupId}`, error);
            this.updateBackupStats(null, false);
            
            return {
                success: false,
                backupId,
                error: error.message
            };
        }
    }

    /**
     * איסוף נתונים לגיבוי
     */
    async collectBackupData() {
        const backupData = {
            timestamp: Date.now(),
            version: this.getSystemVersion(),
            
            // הגדרות מערכת
            settings: this.collectSettings(),
            
            // זיכרון מערכת
            memory: this.collectMemoryData(),
            
            // מצב מודולים
            modules: this.collectModuleStates(),
            
            // נתוני משתמש
            userData: this.collectUserData(),
            
            // קונפיגורציות
            configurations: this.collectConfigurations(),
            
            // מטריקות ביצועים
            performance: this.collectPerformanceData(),
            
            // לוגים חשובים
            logs: this.collectImportantLogs()
        };
        
        return backupData;
    }

    /**
     * שחזור מגיבוי
     */
    async restoreFromBackup(backupId, options = {}) {
        try {
            console.log(`🔄 Starting restore from backup: ${backupId}`);
            
            // טעינת הגיבוי
            const backupData = await this.loadBackup(backupId);
            if (!backupData) {
                throw new Error(`Backup ${backupId} not found`);
            }
            
            // בדיקת שלמות
            const integrityCheck = await this.verifyBackupIntegrity(backupData);
            if (!integrityCheck.valid) {
                throw new Error(`Backup integrity check failed: ${integrityCheck.error}`);
            }
            
            // פענוח (אם מוצפן)
            const decryptedData = backupData.metadata.encrypted ? 
                await this.decryptData(backupData.data) : backupData.data;
            
            // פירוק דחיסה (אם דחוס)
            const decompressedData = backupData.metadata.compressed ? 
                await this.decompressData(decryptedData) : decryptedData;
            
            // ביצוע השחזור
            const restoreResult = await this.performRestore(decompressedData, options);
            
            if (restoreResult.success) {
                console.log(`✅ Restore completed successfully from backup: ${backupId}`);
                
                // למידה במערכת זיכרון
                if (window.EffiMemory) {
                    window.EffiMemory.learn({
                        type: 'restore_success',
                        backupId,
                        restoredComponents: restoreResult.components
                    }, {
                        system: 'backup',
                        operation: 'restore'
                    });
                }
                
                return restoreResult;
            } else {
                throw new Error('Restore operation failed');
            }
            
        } catch (error) {
            console.error(`❌ Restore failed for backup ${backupId}:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * דחיסת נתונים חכמה
     */
    async compressData(data) {
        try {
            const jsonString = JSON.stringify(data);
            
            // שימוש ב-LZ compression
            const compressed = this.lzCompress(jsonString);
            
            const originalSize = new Blob([jsonString]).size;
            const compressedSize = new Blob([compressed]).size;
            const ratio = ((originalSize - compressedSize) / originalSize) * 100;
            
            console.log(`🗜️ Compression: ${originalSize} → ${compressedSize} bytes (${ratio.toFixed(1)}% saved)`);
            
            return {
                compressed: true,
                data: compressed,
                originalSize,
                compressedSize,
                ratio
            };
            
        } catch (error) {
            console.warn('⚠️ Compression failed, using uncompressed data:', error);
            return {
                compressed: false,
                data: JSON.stringify(data)
            };
        }
    }

    /**
     * הצפנת נתונים מקומית
     */
    async encryptData(data) {
        if (!this.encryptionEnabled) {
            return data;
        }
        
        try {
            // יצירת מפתח הצפנה מקומי
            const encryptionKey = await this.generateEncryptionKey();
            
            // הצפנה באמצעות Web Crypto API
            const encrypted = await this.performEncryption(data, encryptionKey);
            
            return {
                encrypted: true,
                data: encrypted,
                keyId: encryptionKey.id
            };
            
        } catch (error) {
            console.warn('⚠️ Encryption failed, storing unencrypted:', error);
            return {
                encrypted: false,
                data: data
            };
        }
    }

    /**
     * שמירת גיבוי באחסון המקומי
     */
    async saveBackup(backupId, data, metadata) {
        try {
            const backupKey = `effi_backup_${backupId}`;
            const metadataKey = `effi_backup_meta_${backupId}`;
            
            // שמירה לפי סוג האחסון הטוב ביותר
            switch (this.storageEngine) {
                case 'indexedDB':
                    return await this.saveToIndexedDB(backupKey, data, metadataKey, metadata);
                    
                case 'localStorage':
                    return await this.saveToLocalStorage(backupKey, data, metadataKey, metadata);
                    
                case 'webSQL':
                    return await this.saveToWebSQL(backupKey, data, metadataKey, metadata);
                    
                default:
                    throw new Error('No suitable storage engine available');
            }
            
        } catch (error) {
            console.error('❌ Failed to save backup:', error);
            return false;
        }
    }

    /**
     * ניקוי גיבויים ישנים
     */
    async cleanupOldBackups() {
        if (this.backupHistory.length <= this.maxBackups) {
            return;
        }
        
        const backupsToDelete = this.backupHistory.slice(this.maxBackups);
        
        for (const backup of backupsToDelete) {
            try {
                await this.deleteBackup(backup.id);
                console.log(`🗑️ Deleted old backup: ${backup.id}`);
            } catch (error) {
                console.warn(`⚠️ Failed to delete backup ${backup.id}:`, error);
            }
        }
        
        // עדכון היסטוריה
        this.backupHistory = this.backupHistory.slice(0, this.maxBackups);
        this.saveBackupHistory();
    }

    /**
     * ניטור מקום אחסון
     */
    startStorageMonitoring() {
        setInterval(async () => {
            const storageInfo = await this.getStorageInfo();
            
            // התראה אם המקום אוזל
            if (storageInfo.usage > 0.85) { // 85%
                console.warn('⚠️ Storage usage high:', storageInfo);
                this.emitStorageWarning(storageInfo);
            }
            
            // ניקוי אוטומטי אם המקום מלא
            if (storageInfo.usage > 0.95) { // 95%
                console.log('🧹 Auto-cleanup triggered due to low storage');
                await this.performEmergencyCleanup();
            }
            
        }, 60000); // כל דקה
    }

    /**
     * גיבוי אוטומטי מתוזמן
     */
    startAutoBackup() {
        // גיבוי ראשוני
        setTimeout(() => {
            this.performFullBackup(false);
        }, 5000); // 5 שניות אחרי האתחול
        
        // גיבויים מתוזמנים
        setInterval(() => {
            this.performFullBackup(false);
        }, this.backupInterval);
        
        console.log(`⏰ Auto backup scheduled every ${this.backupInterval / 60000} minutes`);
    }

    /**
     * רישום event listeners
     */
    setupEventListeners() {
        // גיבוי בעת סגירת הדף
        window.addEventListener('beforeunload', () => {
            this.performFullBackup(true);
        });
        
        // גיבוי בעת שגיאה קריטית
        window.addEventListener('error', (event) => {
            if (event.error && event.error.critical) {
                this.performFullBackup(true);
            }
        });
        
        // גיבוי ידני מהמשתמש
        window.addEventListener('effi_manual_backup', () => {
            this.performFullBackup(true);
        });
    }

    // === UTILITY METHODS ===

    detectBestStorage() {
        if ('indexedDB' in window) {
            return 'indexedDB';
        } else if ('localStorage' in window) {
            return 'localStorage';
        } else if ('openDatabase' in window) {
            return 'webSQL';
        } else {
            console.warn('⚠️ No suitable storage engine found');
            return null;
        }
    }

    generateBackupId() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2, 8);
        return `backup_${timestamp}_${random}`;
    }

    getSystemVersion() {
        return '3.1.0'; // גרסת המערכת
    }

    calculateDataSize(data) {
        if (typeof data === 'string') {
            return new Blob([data]).size;
        } else {
            return new Blob([JSON.stringify(data)]).size;
        }
    }

    async calculateIntegrityHash(data) {
        const encoder = new TextEncoder();
        const dataBuffer = encoder.encode(JSON.stringify(data));
        const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }

    collectSettings() {
        const settings = {};
        
        // הגדרות מ-localStorage
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('effi-')) {
                settings[key] = localStorage.getItem(key);
            }
        }
        
        return settings;
    }

    collectMemoryData() {
        if (window.EffiMemory) {
            return window.EffiMemory.exportMemory('compressed');
        }
        return null;
    }

    collectModuleStates() {
        if (window.EffiModular) {
            return {
                modules: Array.from(window.EffiModular.modules.entries()),
                states: Array.from(window.EffiModular.moduleStates.entries()),
                dependencies: Array.from(window.EffiModular.dependencies.entries())
            };
        }
        return null;
    }

    collectUserData() {
        // איסוף נתוני משתמש (הגדרות אישיות, העדפות)
        return {
            preferences: localStorage.getItem('user-preferences'),
            customizations: localStorage.getItem('user-customizations'),
            history: localStorage.getItem('user-history')
        };
    }

    updateBackupStats(metadata, success) {
        this.backupStats.totalBackups++;
        
        if (success) {
            this.backupStats.successfulBackups++;
            if (metadata) {
                this.backupStats.totalDataSaved += metadata.size;
                if (metadata.originalSize && metadata.size) {
                    const ratio = ((metadata.originalSize - metadata.size) / metadata.originalSize) * 100;
                    this.backupStats.compressionRatio = 
                        (this.backupStats.compressionRatio + ratio) / 2; // ממוצע
                }
            }
        } else {
            this.backupStats.failedBackups++;
        }
        
        // שמירת סטטיסטיקות
        localStorage.setItem('effi-backup-stats', JSON.stringify(this.backupStats));
    }

    // קומפרסיה פשוטה (LZ-like)
    lzCompress(str) {
        const dict = {};
        const data = (str + "").split("");
        const out = [];
        let currChar;
        let phrase = data[0];
        let code = 256;
        
        for (let i = 1; i < data.length; i++) {
            currChar = data[i];
            if (dict[phrase + currChar] != null) {
                phrase += currChar;
            } else {
                out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
                dict[phrase + currChar] = code;
                code++;
                phrase = currChar;
            }
        }
        out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
        
        return JSON.stringify(out);
    }

    async saveToIndexedDB(backupKey, data, metadataKey, metadata) {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('EffiBackups', 1);
            
            request.onerror = () => reject(request.error);
            
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['backups'], 'readwrite');
                const store = transaction.objectStore('backups');
                
                const backupRequest = store.put({ key: backupKey, data, metadata });
                
                backupRequest.onsuccess = () => resolve(true);
                backupRequest.onerror = () => reject(backupRequest.error);
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('backups')) {
                    db.createObjectStore('backups', { keyPath: 'key' });
                }
            };
        });
    }

    saveBackupHistory() {
        localStorage.setItem('effi-backup-history', JSON.stringify(this.backupHistory));
    }

    loadBackupHistory() {
        try {
            const history = localStorage.getItem('effi-backup-history');
            if (history) {
                this.backupHistory = JSON.parse(history);
            }
            
            const stats = localStorage.getItem('effi-backup-stats');
            if (stats) {
                this.backupStats = { ...this.backupStats, ...JSON.parse(stats) };
            }
        } catch (error) {
            console.warn('⚠️ Could not load backup history:', error);
        }
    }
}

// יצירת מופע גלובלי
window.EffiBackup = new EffiAutoBackupSystem();

console.log('💾 Effi Auto Backup System Loaded - Every 5 Minutes!');