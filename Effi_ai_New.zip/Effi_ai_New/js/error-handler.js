/**
 * 🛡️ Effi-AI Global Error Handler
 * מערכת טיפול בשגיאות מתקדמת
 * Version: 1.0.0
 */

class EffiErrorHandler {
    constructor() {
        this.errors = [];
        this.errorThreshold = 50;
        this.criticalErrorCallback = null;
        this.enableLogging = true;
        this.enableReporting = true;
        
        this.initializeErrorHandling();
    }

    /**
     * אתחול מערכת טיפול בשגיאות
     */
    initializeErrorHandling() {
        console.log('🛡️ Initializing Global Error Handler...');
        
        // טיפול בשגיאות JavaScript
        window.addEventListener('error', (event) => {
            this.handleJavaScriptError(event);
        });
        
        // טיפול בשגיאות Promise
        window.addEventListener('unhandledrejection', (event) => {
            this.handlePromiseRejection(event);
        });
        
        // טיפול בשגיאות רשת
        this.setupNetworkErrorHandling();
        
        // ניטור ביצועים
        this.startPerformanceMonitoring();
        
        console.log('✅ Global Error Handler Active');
    }

    /**
     * טיפול בשגיאות JavaScript
     */
    handleJavaScriptError(event) {
        const error = {
            type: 'javascript',
            message: event.message,
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno,
            stack: event.error ? event.error.stack : null,
            timestamp: Date.now(),
            url: window.location.href,
            userAgent: navigator.userAgent
        };
        
        this.logError(error);
        this.reportError(error);
        
        // מניעת הצגת שגיאה לمستخدم אם זה לא קריטי
        if (!this.isCriticalError(error)) {
            event.preventDefault();
        }
    }

    /**
     * טיפול בשגיאות Promise
     */
    handlePromiseRejection(event) {
        const error = {
            type: 'promise_rejection',
            message: event.reason ? event.reason.toString() : 'Unknown promise rejection',
            stack: event.reason && event.reason.stack ? event.reason.stack : null,
            timestamp: Date.now(),
            url: window.location.href
        };
        
        this.logError(error);
        this.reportError(error);
        
        // מניעת הצגת שגיאה בקונסול
        event.preventDefault();
    }

    /**
     * טיפול בשגיאות רשת
     */
    setupNetworkErrorHandling() {
        // Override fetch לטיפול בשגיאות רשת
        const originalFetch = window.fetch;
        window.fetch = async (...args) => {
            try {
                const response = await originalFetch(...args);
                
                if (!response.ok) {
                    const networkError = {
                        type: 'network',
                        message: `HTTP ${response.status}: ${response.statusText}`,
                        url: args[0],
                        status: response.status,
                        timestamp: Date.now()
                    };
                    
                    this.logError(networkError);
                    
                    // התמודדות עם שגיאות רשת ספציפיות
                    if (response.status >= 500) {
                        this.handleServerError(networkError);
                    } else if (response.status === 404) {
                        this.handleNotFoundError(networkError);
                    }
                }
                
                return response;
            } catch (error) {
                const fetchError = {
                    type: 'fetch_failed',
                    message: error.message,
                    url: args[0],
                    timestamp: Date.now()
                };
                
                this.logError(fetchError);
                this.handleConnectionError(fetchError);
                
                throw error;
            }
        };
    }

    /**
     * רישום שגיאה
     */
    logError(error) {
        if (!this.enableLogging) return;
        
        this.errors.push(error);
        
        // ניקוי שגיאות ישנות
        if (this.errors.length > this.errorThreshold) {
            this.errors = this.errors.slice(-this.errorThreshold);
        }
        
        // רישום בקונסול
        console.error('🚨 Error captured:', error);
        
        // שמירה ב-localStorage לדיבוג
        try {
            localStorage.setItem('effi-ai-errors', JSON.stringify(this.errors));
        } catch (e) {
            console.warn('Could not save errors to localStorage');
        }
        
        // שליחה למערכת זיכרון
        if (window.EffiMemory) {
            window.EffiMemory.learn({
                type: 'error_captured',
                error: error
            }, {
                system: 'error_handler',
                severity: this.calculateErrorSeverity(error)
            });
        }
    }

    /**
     * דיווח על שגיאה
     */
    reportError(error) {
        if (!this.enableReporting) return;
        
        // הצגת הודעה לمستخدم אם נדרש
        if (this.shouldNotifyUser(error)) {
            this.showUserNotification(error);
        }
        
        // קריאה לפונקציה חיצונית אם הוגדרה
        if (this.criticalErrorCallback && this.isCriticalError(error)) {
            this.criticalErrorCallback(error);
        }
        
        // שליחה לשרת (אם יש)
        this.sendErrorToServer(error);
    }

    /**
     * בדיקה אם שגיאה קריטית
     */
    isCriticalError(error) {
        const criticalPatterns = [
            /modular.*core/i,
            /memory.*system/i,
            /multi.*engine/i,
            /critical/i,
            /fatal/i
        ];
        
        return criticalPatterns.some(pattern => 
            pattern.test(error.message) || 
            (error.stack && pattern.test(error.stack))
        );
    }

    /**
     * חישוב חומרת שגיאה
     */
    calculateErrorSeverity(error) {
        if (this.isCriticalError(error)) return 'critical';
        if (error.type === 'network' && error.status >= 500) return 'high';
        if (error.type === 'promise_rejection') return 'medium';
        return 'low';
    }

    /**
     * בדיקה אם להודיע למשתמש
     */
    shouldNotifyUser(error) {
        // הודע רק על שגיאות קריטיות או רשת
        return this.isCriticalError(error) || 
               (error.type === 'network' && error.status >= 500);
    }

    /**
     * הצגת הודעה למשתמש
     */
    showUserNotification(error) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc2626;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            z-index: 10000;
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        `;
        
        const severity = this.calculateErrorSeverity(error);
        const message = this.getErrorMessage(error, severity);
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.2rem;">⚠️</span>
                <div>
                    <div style="font-weight: bold;">שגיאת מערכת</div>
                    <div style="font-size: 0.9rem; opacity: 0.9;">${message}</div>
                </div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // הסרה אוטומטית
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    /**
     * קבלת הודעת שגיאה מותאמת למשתמש
     */
    getErrorMessage(error, severity) {
        if (severity === 'critical') {
            return 'שגיאה קריטית במערכת. המערכת מנסה להתאושש...';
        } else if (error.type === 'network') {
            return 'בעיית חיבור לשרת. בודק חיבור...';
        } else {
            return 'שגיאה טכנית זוהתה ונרשמה לטיפול.';
        }
    }

    /**
     * שליחת שגיאה לשרת
     */
    async sendErrorToServer(error) {
        // הדמיה של שליחה לשרת
        try {
            // במציאות היה כאן fetch לשרת לוגים
            console.log('📤 Error would be sent to server:', error);
        } catch (e) {
            console.warn('Could not send error to server:', e);
        }
    }

    /**
     * טיפול בשגיאות שרת
     */
    handleServerError(error) {
        console.warn('🚨 Server error detected:', error);
        
        // ניסיון חיבור מחדש
        if (error.status === 503 || error.status === 502) {
            setTimeout(() => {
                console.log('🔄 Attempting to reconnect...');
                // כאן היה ניסיון חיבור מחדש
            }, 5000);
        }
    }

    /**
     * טיפול בשגיאות 404
     */
    handleNotFoundError(error) {
        console.warn('📁 Resource not found:', error.url);
        
        // ניסיון טעינת fallback
        if (error.url.includes('.js')) {
            this.loadFallbackModule(error.url);
        }
    }

    /**
     * טיפול בשגיאות חיבור
     */
    handleConnectionError(error) {
        console.warn('🌐 Connection error:', error);
        
        // בדיקת מצב חיבור
        if (!navigator.onLine) {
            this.handleOfflineMode();
        }
    }

    /**
     * טיפול במצב offline
     */
    handleOfflineMode() {
        console.log('📴 Offline mode detected');
        
        // הצגת הודעה
        this.showUserNotification({
            type: 'offline',
            message: 'אין חיבור לאינטרנט. עובד במצב לא מקוון.'
        });
    }

    /**
     * טעינת מודול fallback
     */
    loadFallbackModule(failedUrl) {
        console.log('🔄 Loading fallback for:', failedUrl);
        
        // ניסיון טעינת גרסה מקומית או fallback
        // זה ייושם לפי הצורך הספציפי
    }

    /**
     * ניטור ביצועים
     */
    startPerformanceMonitoring() {
        // ניטור זמני טעינה ארוכים
        if (window.PerformanceObserver) {
            const observer = new PerformanceObserver((list) => {
                for (const entry of list.getEntries()) {
                    if (entry.duration > 5000) { // מעל 5 שניות
                        this.logError({
                            type: 'performance',
                            message: `Slow operation detected: ${entry.name}`,
                            duration: entry.duration,
                            timestamp: Date.now()
                        });
                    }
                }
            });
            
            observer.observe({ entryTypes: ['measure', 'navigation'] });
        }
    }

    /**
     * קבלת סטטיסטיקות שגיאות
     */
    getErrorStats() {
        const now = Date.now();
        const hour = 60 * 60 * 1000;
        const recentErrors = this.errors.filter(e => now - e.timestamp < hour);
        
        const stats = {
            total: this.errors.length,
            recent: recentErrors.length,
            byType: {},
            bySeverity: { critical: 0, high: 0, medium: 0, low: 0 }
        };
        
        this.errors.forEach(error => {
            // לפי סוג
            stats.byType[error.type] = (stats.byType[error.type] || 0) + 1;
            
            // לפי חומרה
            const severity = this.calculateErrorSeverity(error);
            stats.bySeverity[severity]++;
        });
        
        return stats;
    }

    /**
     * ניקוי שגיאות
     */
    clearErrors() {
        this.errors = [];
        try {
            localStorage.removeItem('effi-ai-errors');
        } catch (e) {
            console.warn('Could not clear errors from localStorage');
        }
        console.log('✅ Error log cleared');
    }

    /**
     * הגדרת callback לשגיאות קריטיות
     */
    setCriticalErrorCallback(callback) {
        this.criticalErrorCallback = callback;
    }

    /**
     * הפעלה/כיבוי של רישום
     */
    setLogging(enabled) {
        this.enableLogging = enabled;
    }

    /**
     * הפעלה/כיבוי של דיווח
     */
    setReporting(enabled) {
        this.enableReporting = enabled;
    }
}

// יצירת מופע גלובלי
window.EffiErrorHandler = new EffiErrorHandler();

// רישום במערכת המודולרית
if (window.EffiModular) {
    window.EffiModular.registerModule('error_handler', window.EffiErrorHandler, [], {
        version: '1.0.0',
        category: 'core',
        priority: 'critical'
    });
}

console.log('🛡️ Effi Error Handler System Loaded - System Protected!');