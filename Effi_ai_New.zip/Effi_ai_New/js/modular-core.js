/**
 * 🔧 Effi-AI Modular Core System
 * מערכת מודולרית מתקדמת - אפשרות החלפה/שדרוג ללא פגיעה
 * תשתית לניהול מודולים עם hot-swapping
 */

class EffiModularCore {
    constructor() {
        this.modules = new Map();
        this.moduleStates = new Map();
        this.dependencies = new Map();
        this.moduleMetrics = new Map();
        this.eventBus = new EventTarget();
        this.moduleVersions = new Map();
        this.fallbackModules = new Map();
        
        // הגדרות מערכת
        this.config = {
            autoReload: true,
            fallbackEnabled: true,
            performanceMonitoring: true,
            dependencyValidation: true,
            hotSwapping: true
        };
        
        this.initializeCore();
    }

    /**
     * אתחול המערכת המודולרית
     */
    initializeCore() {
        console.log('🔧 Initializing Modular Core System...');
        
        // רישום event listeners גלובליים
        this.setupGlobalEventHandlers();
        
        // טעינת מודולים שמורים
        this.loadPersistedModules();
        
        // הפעלת מונטור ביצועים
        this.startPerformanceMonitoring();
        
        // הפעלת מערכת fallback
        this.initializeFallbackSystem();
        
        console.log('✅ Modular Core System Active');
    }

    /**
     * רישום מודול חדש במערכת
     */
    registerModule(moduleId, moduleClass, dependencies = [], options = {}) {
        try {
            // וליקציה של תלויות
            if (this.config.dependencyValidation && !this.validateDependencies(dependencies)) {
                throw new Error(`Dependencies validation failed for module: ${moduleId}`);
            }

            // יצירת מודול
            const moduleInstance = new moduleClass(options);
            
            // מטא-דאטה של המודול
            const moduleMetadata = {
                id: moduleId,
                instance: moduleInstance,
                class: moduleClass,
                dependencies,
                options,
                version: options.version || '1.0.0',
                status: 'registered',
                registeredAt: Date.now(),
                metrics: {
                    loadTime: 0,
                    executionCount: 0,
                    errorCount: 0,
                    avgExecutionTime: 0
                }
            };

            // שמירה במערכת
            this.modules.set(moduleId, moduleMetadata);
            this.moduleStates.set(moduleId, 'inactive');
            this.moduleVersions.set(moduleId, options.version || '1.0.0');
            
            // רישום תלויות
            this.dependencies.set(moduleId, dependencies);
            
            // אירוע רישום
            this.emitModuleEvent('module_registered', {
                moduleId,
                version: options.version,
                dependencies
            });

            console.log(`✅ Module '${moduleId}' registered successfully`);
            return true;

        } catch (error) {
            console.error(`❌ Failed to register module '${moduleId}':`, error);
            return false;
        }
    }

    /**
     * טעינה והפעלה של מודול
     */
    async loadModule(moduleId, force = false) {
        const startTime = performance.now();
        
        try {
            const moduleData = this.modules.get(moduleId);
            if (!moduleData) {
                throw new Error(`Module '${moduleId}' not found`);
            }

            // בדיקת מצב נוכחי
            const currentState = this.moduleStates.get(moduleId);
            if (currentState === 'active' && !force) {
                console.log(`ℹ️ Module '${moduleId}' already active`);
                return true;
            }

            // טעינת תלויות
            await this.loadDependencies(moduleId);

            // אתחול המודול
            if (moduleData.instance.initialize) {
                await moduleData.instance.initialize();
            }

            // עדכון מצב
            this.moduleStates.set(moduleId, 'active');
            
            // עדכון מטריקות
            const loadTime = performance.now() - startTime;
            moduleData.metrics.loadTime = loadTime;
            
            // אירוע טעינה
            this.emitModuleEvent('module_loaded', {
                moduleId,
                loadTime
            });

            // חיבור ל-memory system אם קיים
            if (window.EffiMemory) {
                window.EffiMemory.learn({
                    type: 'module_loaded',
                    id: moduleId,
                    loadTime
                }, {
                    system: 'modular_core',
                    module: moduleId
                });
            }

            console.log(`✅ Module '${moduleId}' loaded in ${loadTime.toFixed(2)}ms`);
            return true;

        } catch (error) {
            this.handleModuleError(moduleId, 'load', error);
            return false;
        }
    }

    /**
     * השבתה והסרה של מודול
     */
    async unloadModule(moduleId, options = {}) {
        try {
            const moduleData = this.modules.get(moduleId);
            if (!moduleData) {
                throw new Error(`Module '${moduleId}' not found`);
            }

            // בדיקת תלויות (מודולים שתלויים במודול הזה)
            const dependentModules = this.findDependentModules(moduleId);
            if (dependentModules.length > 0 && !options.force) {
                console.warn(`⚠️ Cannot unload '${moduleId}' - has dependent modules:`, dependentModules);
                return false;
            }

            // ניקוי המודול
            if (moduleData.instance.cleanup) {
                await moduleData.instance.cleanup();
            }

            // עדכון מצב
            this.moduleStates.set(moduleId, 'inactive');
            
            // אירוע השבתה
            this.emitModuleEvent('module_unloaded', {
                moduleId
            });

            console.log(`✅ Module '${moduleId}' unloaded successfully`);
            return true;

        } catch (error) {
            this.handleModuleError(moduleId, 'unload', error);
            return false;
        }
    }

    /**
     * Hot-swapping של מודול (החלפה בזמן ריצה)
     */
    async swapModule(moduleId, newModuleClass, options = {}) {
        try {
            if (!this.config.hotSwapping) {
                throw new Error('Hot swapping is disabled');
            }

            console.log(`🔄 Hot-swapping module '${moduleId}'...`);

            // שמירת מצב נוכחי
            const currentState = await this.captureModuleState(moduleId);
            
            // השבתה זמנית
            await this.unloadModule(moduleId, { force: true });
            
            // עדכון המודול
            const moduleData = this.modules.get(moduleId);
            moduleData.class = newModuleClass;
            moduleData.instance = new newModuleClass(options);
            moduleData.version = options.version || moduleData.version;
            
            // טעינה מחדש
            await this.loadModule(moduleId, true);
            
            // שחזור מצב
            await this.restoreModuleState(moduleId, currentState);
            
            // עדכון גרסה
            this.moduleVersions.set(moduleId, moduleData.version);
            
            // אירוע החלפה
            this.emitModuleEvent('module_swapped', {
                moduleId,
                newVersion: moduleData.version
            });

            console.log(`✅ Module '${moduleId}' hot-swapped successfully`);
            return true;

        } catch (error) {
            console.error(`❌ Hot-swap failed for '${moduleId}':`, error);
            
            // ניסיון שחזור fallback
            await this.activateFallback(moduleId);
            return false;
        }
    }

    /**
     * ביצוע פונקציה במודול עם error handling
     */
    async executeModuleFunction(moduleId, functionName, ...args) {
        const startTime = performance.now();
        
        try {
            const moduleData = this.modules.get(moduleId);
            if (!moduleData) {
                throw new Error(`Module '${moduleId}' not found`);
            }

            const currentState = this.moduleStates.get(moduleId);
            if (currentState !== 'active') {
                // ניסיון טעינה אוטומטית
                const loaded = await this.loadModule(moduleId);
                if (!loaded) {
                    throw new Error(`Module '${moduleId}' could not be loaded`);
                }
            }

            // ביצוע הפונקציה
            const result = await moduleData.instance[functionName](...args);
            
            // עדכון מטריקות
            const executionTime = performance.now() - startTime;
            this.updateExecutionMetrics(moduleId, executionTime, true);
            
            return result;

        } catch (error) {
            const executionTime = performance.now() - startTime;
            this.updateExecutionMetrics(moduleId, executionTime, false);
            this.handleModuleError(moduleId, 'execution', error);
            
            // ניסיון fallback
            return await this.attemptFallback(moduleId, functionName, args);
        }
    }

    /**
     * מערכת fallback אוטומטית
     */
    async activateFallback(moduleId) {
        if (!this.config.fallbackEnabled) {
            return false;
        }

        const fallbackModule = this.fallbackModules.get(moduleId);
        if (!fallbackModule) {
            console.warn(`⚠️ No fallback available for module '${moduleId}'`);
            return false;
        }

        try {
            console.log(`🔄 Activating fallback for module '${moduleId}'...`);
            
            // הפעלת fallback
            await this.loadModule(fallbackModule.id);
            
            // עדכון routing
            this.modules.set(moduleId + '_primary', this.modules.get(moduleId));
            this.modules.set(moduleId, this.modules.get(fallbackModule.id));
            
            console.log(`✅ Fallback activated for '${moduleId}'`);
            return true;

        } catch (error) {
            console.error(`❌ Fallback activation failed:`, error);
            return false;
        }
    }

    /**
     * ניטור ביצועים של מודולים
     */
    startPerformanceMonitoring() {
        if (!this.config.performanceMonitoring) {
            return;
        }

        setInterval(() => {
            this.analyzeModulePerformance();
        }, 30000); // כל 30 שניות

        setInterval(() => {
            this.optimizeModuleUsage();
        }, 300000); // כל 5 דקות
    }

    /**
     * ניתוח ביצועי מודולים
     */
    analyzeModulePerformance() {
        const performanceReport = {
            timestamp: Date.now(),
            modules: []
        };

        for (const [moduleId, moduleData] of this.modules) {
            const metrics = moduleData.metrics;
            const health = this.calculateModuleHealth(metrics);
            
            performanceReport.modules.push({
                id: moduleId,
                health,
                metrics: { ...metrics },
                recommendations: this.generateOptimizationRecommendations(moduleId, metrics)
            });

            // התראות על ביצועים גרועים
            if (health < 0.7) {
                this.emitModuleEvent('performance_warning', {
                    moduleId,
                    health,
                    metrics
                });
            }
        }

        // שמירה ב-memory system
        if (window.EffiMemory) {
            window.EffiMemory.learn({
                type: 'performance_analysis',
                data: performanceReport
            }, {
                system: 'modular_core',
                analysis: 'performance'
            });
        }

        return performanceReport;
    }

    /**
     * שמירה וטעינה של מצב מודולים
     */
    async saveModuleState() {
        const stateData = {
            modules: Array.from(this.modules.entries()).map(([id, data]) => ({
                id,
                version: data.version,
                options: data.options,
                state: this.moduleStates.get(id)
            })),
            dependencies: Array.from(this.dependencies.entries()),
            config: this.config,
            timestamp: Date.now()
        };

        try {
            localStorage.setItem('effi-modular-state', JSON.stringify(stateData));
            console.log('✅ Module state saved');
            return true;
        } catch (error) {
            console.error('❌ Failed to save module state:', error);
            return false;
        }
    }

    async loadPersistedModules() {
        try {
            const stateData = localStorage.getItem('effi-modular-state');
            if (!stateData) {
                return false;
            }

            const parsedState = JSON.parse(stateData);
            
            // שחזור קונפיגורציה
            this.config = { ...this.config, ...parsedState.config };
            
            // שחזור תלויות
            this.dependencies = new Map(parsedState.dependencies);
            
            console.log('✅ Persisted module state loaded');
            return true;
            
        } catch (error) {
            console.warn('⚠️ Could not load persisted modules:', error);
            return false;
        }
    }

    // === UTILITY METHODS ===

    validateDependencies(dependencies) {
        return dependencies.every(dep => 
            this.modules.has(dep) || this.isCoreDependency(dep)
        );
    }

    isCoreDependency(dependency) {
        const coreDependencies = ['EffiMemory', 'EffiModularCore', 'window', 'localStorage'];
        return coreDependencies.includes(dependency);
    }

    async loadDependencies(moduleId) {
        const dependencies = this.dependencies.get(moduleId) || [];
        
        for (const dep of dependencies) {
            if (this.modules.has(dep)) {
                const depState = this.moduleStates.get(dep);
                if (depState !== 'active') {
                    await this.loadModule(dep);
                }
            }
        }
    }

    findDependentModules(moduleId) {
        const dependent = [];
        for (const [id, deps] of this.dependencies) {
            if (deps.includes(moduleId)) {
                dependent.push(id);
            }
        }
        return dependent;
    }

    emitModuleEvent(eventType, data) {
        const event = new CustomEvent(eventType, { detail: data });
        this.eventBus.dispatchEvent(event);
        
        // גם ב-window לגישה גלובלית
        window.dispatchEvent(new CustomEvent(`effi_${eventType}`, { detail: data }));
    }

    handleModuleError(moduleId, operation, error) {
        const moduleData = this.modules.get(moduleId);
        if (moduleData) {
            moduleData.metrics.errorCount++;
        }

        this.emitModuleEvent('module_error', {
            moduleId,
            operation,
            error: error.message,
            timestamp: Date.now()
        });

        console.error(`❌ Module '${moduleId}' error in '${operation}':`, error);
    }

    updateExecutionMetrics(moduleId, executionTime, success) {
        const moduleData = this.modules.get(moduleId);
        if (!moduleData) return;

        const metrics = moduleData.metrics;
        metrics.executionCount++;
        
        if (success) {
            metrics.totalExecutionTime = (metrics.totalExecutionTime || 0) + executionTime;
            metrics.avgExecutionTime = metrics.totalExecutionTime / metrics.executionCount;
        } else {
            metrics.errorCount++;
        }
    }

    calculateModuleHealth(metrics) {
        const errorRate = metrics.errorCount / Math.max(metrics.executionCount, 1);
        const performanceScore = Math.min(1000 / Math.max(metrics.avgExecutionTime, 1), 1);
        
        return (1 - errorRate) * 0.7 + performanceScore * 0.3;
    }

    setupGlobalEventHandlers() {
        // שמירה אוטומטית
        setInterval(() => {
            this.saveModuleState();
        }, 60000); // כל דקה

        // שמירה בסגירת הדף
        window.addEventListener('beforeunload', () => {
            this.saveModuleState();
        });
    }

    // === PUBLIC API METHODS ===

    /**
     * קבלת רשימת מודולים טעונים
     */
    getLoadedModules() {
        const loadedModules = [];
        for (const [moduleId, moduleData] of this.modules) {
            const state = this.moduleStates.get(moduleId);
            if (state === 'active') {
                loadedModules.push({
                    id: moduleId,
                    version: moduleData.version,
                    metrics: moduleData.metrics,
                    health: this.calculateModuleHealth(moduleData.metrics)
                });
            }
        }
        return loadedModules;
    }

    /**
     * וליקציה של תלויות מודול
     */
    validateModuleDependencies(moduleId) {
        const dependencies = this.dependencies.get(moduleId) || [];
        const results = {
            valid: true,
            missing: [],
            inactive: []
        };

        for (const dep of dependencies) {
            if (!this.modules.has(dep) && !this.isCoreDependency(dep)) {
                results.missing.push(dep);
                results.valid = false;
            } else if (this.modules.has(dep)) {
                const state = this.moduleStates.get(dep);
                if (state !== 'active') {
                    results.inactive.push(dep);
                }
            }
        }

        return results;
    }

    /**
     * טיפול בשגיאות מודול
     */
    handleModuleErrors(moduleId, errorHandler) {
        this.eventBus.addEventListener('module_error', (event) => {
            if (event.detail.moduleId === moduleId) {
                errorHandler(event.detail);
            }
        });
    }

    /**
     * יצירת מודול דינמי
     */
    createDynamicModule(moduleId, implementation, options = {}) {
        const ModuleClass = class {
            constructor(opts) {
                this.options = opts;
                Object.assign(this, implementation);
            }

            async initialize() {
                if (implementation.initialize) {
                    await implementation.initialize.call(this);
                }
            }

            async cleanup() {
                if (implementation.cleanup) {
                    await implementation.cleanup.call(this);
                }
            }
        };

        return this.registerModule(moduleId, ModuleClass, options.dependencies || [], options);
    }

    /**
     * יצוא סטטיסטיקות מודולים
     */
    exportModuleStats() {
        const stats = {
            timestamp: Date.now(),
            totalModules: this.modules.size,
            activeModules: Array.from(this.moduleStates.values()).filter(s => s === 'active').length,
            modules: this.getLoadedModules(),
            systemHealth: this.calculateSystemHealth(),
            memoryUsage: this.estimateMemoryUsage()
        };

        return stats;
    }

    /**
     * חישוב בריאות המערכת
     */
    calculateSystemHealth() {
        const moduleHealths = this.getLoadedModules().map(m => m.health);
        if (moduleHealths.length === 0) return 1;
        
        return moduleHealths.reduce((sum, health) => sum + health, 0) / moduleHealths.length;
    }

    /**
     * הערכת שימוש בזיכרון
     */
    estimateMemoryUsage() {
        return {
            modules: this.modules.size * 1024, // הערכה גסה
            dependencies: this.dependencies.size * 256,
            events: 512,
            total: (this.modules.size * 1024) + (this.dependencies.size * 256) + 512
        };
    }

    /**
     * שחזור מצב מודול
     */
    async captureModuleState(moduleId) {
        const moduleData = this.modules.get(moduleId);
        if (!moduleData || !moduleData.instance.getState) {
            return null;
        }

        try {
            return await moduleData.instance.getState();
        } catch (error) {
            console.warn(`Could not capture state for module '${moduleId}':`, error);
            return null;
        }
    }

    /**
     * שחזור מצב מודול
     */
    async restoreModuleState(moduleId, state) {
        if (!state) return false;

        const moduleData = this.modules.get(moduleId);
        if (!moduleData || !moduleData.instance.setState) {
            return false;
        }

        try {
            await moduleData.instance.setState(state);
            return true;
        } catch (error) {
            console.warn(`Could not restore state for module '${moduleId}':`, error);
            return false;
        }
    }

    /**
     * ניסיון fallback
     */
    async attemptFallback(moduleId, functionName, args) {
        const fallbackModule = this.fallbackModules.get(moduleId);
        if (!fallbackModule) {
            throw new Error(`No fallback available for module '${moduleId}'`);
        }

        try {
            await this.loadModule(fallbackModule.id);
            const fallbackData = this.modules.get(fallbackModule.id);
            return await fallbackData.instance[functionName](...args);
        } catch (error) {
            console.error(`Fallback failed for '${moduleId}':`, error);
            throw error;
        }
    }

    /**
     * יצירת המלצות אופטימיזציה
     */
    generateOptimizationRecommendations(moduleId, metrics) {
        const recommendations = [];

        if (metrics.avgExecutionTime > 1000) {
            recommendations.push('Consider optimizing slow operations');
        }

        if (metrics.errorCount > metrics.executionCount * 0.1) {
            recommendations.push('High error rate - review error handling');
        }

        if (metrics.loadTime > 5000) {
            recommendations.push('Slow loading - consider lazy loading');
        }

        return recommendations;
    }

    /**
     * אופטימיזציה של שימוש במודולים
     */
    optimizeModuleUsage() {
        for (const [moduleId, moduleData] of this.modules) {
            const health = this.calculateModuleHealth(moduleData.metrics);
            
            if (health < 0.5) {
                console.warn(`🔧 Module '${moduleId}' needs optimization (health: ${health.toFixed(2)})`);
                
                // ניסיון אופטימיזציה אוטומטית
                this.attemptAutoOptimization(moduleId, moduleData);
            }
        }
    }

    /**
     * ניסיון אופטימיזציה אוטומטית
     */
    async attemptAutoOptimization(moduleId, moduleData) {
        try {
            // איפוס מטריקות אם יש יותר מדי שגיאות
            if (moduleData.metrics.errorCount > 50) {
                moduleData.metrics.errorCount = Math.floor(moduleData.metrics.errorCount * 0.5);
                console.log(`🔧 Reset error count for module '${moduleId}'`);
            }

            // אתחול מחדש אם הביצועים ירודים
            const health = this.calculateModuleHealth(moduleData.metrics);
            if (health < 0.3) {
                await this.unloadModule(moduleId);
                await this.loadModule(moduleId);
                console.log(`🔄 Reloaded module '${moduleId}' for optimization`);
            }
        } catch (error) {
            console.error(`Failed to optimize module '${moduleId}':`, error);
        }
    }
}

// יצירת מופע גלובלי
window.EffiModular = new EffiModularCore();

console.log('🔧 Effi Modular Core System Loaded - Hot-Swapping Ready!');