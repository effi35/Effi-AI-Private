/**
 * Effi-AI Global Theme System
 * מערכת עיצוב גלובלית שמשפיעה על כל המודולים במערכת
 * Version: 1.0.0
 */

class EffiGlobalTheme {
    constructor() {
        this.currentTheme = 'default';
        this.themes = {
            default: {
                name: 'ברירת מחדל',
                primaryColor: '#2196f3',
                primaryLight: '#42a5f5',
                primaryDark: '#1976d2',
                background: 'linear-gradient(135deg, #e3f2fd 0%, #bbdefb 50%, #e1f5fe 100%)',
                textPrimary: '#1e293b',
                icon: '🔵'
            },
            dark: {
                name: 'כהה',
                primaryColor: '#8b5cf6',
                primaryLight: '#a855f7',
                primaryDark: '#7c3aed',
                background: 'linear-gradient(135deg, #0a0a1a 0%, #1a0a1a 25%, #2a1a3a 50%, #3a2a5a 75%, #4a3a7a 100%)',
                textPrimary: '#ffffff',
                icon: '🌙'
            },
            neon: {
                name: 'ניאון',
                primaryColor: '#00ff88',
                primaryLight: '#33ffaa',
                primaryDark: '#00cc66',
                background: 'linear-gradient(135deg, #000000 0%, #001a0a 50%, #002a1a 100%)',
                textPrimary: '#00ff88',
                icon: '⚡'
            },
            ocean: {
                name: 'אוקיינוס',
                primaryColor: '#0891b2',
                primaryLight: '#06b6d4',
                primaryDark: '#0e7490',
                background: 'linear-gradient(135deg, #cffafe 0%, #a5f3fc 50%, #67e8f9 100%)',
                textPrimary: '#0f172a',
                icon: '🌊'
            },
            forest: {
                name: 'יער',
                primaryColor: '#16a34a',
                primaryLight: '#22c55e',
                primaryDark: '#15803d',
                background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%)',
                textPrimary: '#0f172a',
                icon: '🌲'
            },
            royal: {
                name: 'מלכותי',
                primaryColor: '#7c3aed',
                primaryLight: '#8b5cf6',
                primaryDark: '#6d28d9',
                background: 'linear-gradient(135deg, #faf5ff 0%, #f3e8ff 50%, #e9d5ff 100%)',
                textPrimary: '#0f172a',
                icon: '👑'
            }
        };
        
        this.settings = {
            brightness: 100,
            contrast: 100,
            saturation: 100,
            borderRadius: 12,
            fontSize: 16,
            animationSpeed: 1
        };
        
        this.initialized = false;
        this.changeCallbacks = [];
        
        console.log('🎨 Global Theme System initializing...');
        this.init();
    }

    /**
     * אתחול המערכת
     */
    async init() {
        try {
            // טעינת הגדרות מ-localStorage
            this.loadSettings();
            
            // החלת הגדרות נוכחיות
            this.applyCurrentTheme();
            
            // רישום event listeners
            this.setupEventListeners();
            
            // רישום במערכת המודולרית
            if (window.EffiModular) {
                window.EffiModular.registerModule('global_theme', this, [], {
                    version: '1.0.0',
                    category: 'core',
                    priority: 'critical'
                });
            }
            
            this.initialized = true;
            console.log('🎨 Global Theme System ready');
            
            // הודעה לכל המודולים על אתחול המערכת
            this.broadcastThemeChange();
            
            return true;
        } catch (error) {
            console.error('❌ Global Theme initialization failed:', error);
            return false;
        }
    }

    /**
     * טעינת הגדרות מ-localStorage
     */
    loadSettings() {
        try {
            const savedTheme = localStorage.getItem('effi-global-theme');
            if (savedTheme) {
                const themeData = JSON.parse(savedTheme);
                this.currentTheme = themeData.theme || 'default';
                this.settings = { ...this.settings, ...themeData.settings };
                console.log(`🎨 Loaded saved theme: ${this.currentTheme}`);
            }
        } catch (error) {
            console.warn('⚠️ Failed to load theme settings:', error);
            this.currentTheme = 'default';
        }
    }

    /**
     * שמירת הגדרות ל-localStorage
     */
    saveSettings() {
        try {
            const themeData = {
                theme: this.currentTheme,
                settings: this.settings,
                timestamp: Date.now()
            };
            localStorage.setItem('effi-global-theme', JSON.stringify(themeData));
            console.log(`💾 Theme settings saved: ${this.currentTheme}`);
        } catch (error) {
            console.error('❌ Failed to save theme settings:', error);
        }
    }

    /**
     * החלפת תמה
     */
    setTheme(themeName) {
        if (!this.themes[themeName]) {
            console.error(`❌ Theme "${themeName}" not found`);
            return false;
        }

        console.log(`🎨 Changing theme from "${this.currentTheme}" to "${themeName}"`);
        
        this.currentTheme = themeName;
        this.applyCurrentTheme();
        this.saveSettings();
        this.broadcastThemeChange();
        
        return true;
    }

    /**
     * החלת התמה הנוכחית
     */
    applyCurrentTheme() {
        const theme = this.themes[this.currentTheme];
        const root = document.documentElement;
        
        // עדכון CSS Variables
        root.style.setProperty('--primary-color', theme.primaryColor);
        root.style.setProperty('--primary-light', theme.primaryLight);
        root.style.setProperty('--primary-dark', theme.primaryDark);
        root.style.setProperty('--text-primary', theme.textPrimary);
        root.style.setProperty('--primary-background', theme.background);
        
        // עדכון body background
        if (document.body) {
            document.body.style.background = theme.background;
            document.body.style.color = theme.textPrimary;
        }
        
        // הוספת class לתמה
        document.body.className = document.body.className.replace(/theme-\w+/g, '');
        if (this.currentTheme !== 'default') {
            document.body.classList.add(`theme-${this.currentTheme}`);
        }
        
        // החלת הגדרות נוספות
        this.applySettings();
        
        console.log(`✅ Applied theme: ${theme.name}`);
    }

    /**
     * החלת הגדרות נוספות
     */
    applySettings() {
        const root = document.documentElement;
        
        // Brightness, Contrast, Saturation
        const filters = [
            `brightness(${this.settings.brightness}%)`,
            `contrast(${this.settings.contrast}%)`,
            `saturate(${this.settings.saturation}%)`
        ].join(' ');
        
        root.style.setProperty('--global-filter', filters);
        if (document.body) {
            document.body.style.filter = filters;
        }
        
        // Border Radius
        root.style.setProperty('--radius-md', `${this.settings.borderRadius}px`);
        
        // Font Size
        root.style.setProperty('--font-size-base', `${this.settings.fontSize}px`);
        
        // Animation Speed
        root.style.setProperty('--animation-speed', `${this.settings.animationSpeed}s`);
    }

    /**
     * עדכון הגדרה בודדת
     */
    setSetting(key, value) {
        if (this.settings.hasOwnProperty(key)) {
            this.settings[key] = value;
            this.applySettings();
            this.saveSettings();
            this.broadcastThemeChange();
            console.log(`🔧 Updated setting ${key}: ${value}`);
            return true;
        }
        return false;
    }

    /**
     * קבלת התמה הנוכחית
     */
    getCurrentTheme() {
        return {
            name: this.currentTheme,
            data: this.themes[this.currentTheme],
            settings: this.settings
        };
    }

    /**
     * קבלת כל התמות הזמינות
     */
    getAvailableThemes() {
        return Object.keys(this.themes).map(key => ({
            key,
            name: this.themes[key].name,
            icon: this.themes[key].icon,
            preview: {
                primaryColor: this.themes[key].primaryColor,
                background: this.themes[key].background
            }
        }));
    }

    /**
     * רישום callback לשינוי תמה
     */
    onThemeChange(callback) {
        if (typeof callback === 'function') {
            this.changeCallbacks.push(callback);
        }
    }

    /**
     * שידור שינוי תמה לכל המודולים
     */
    broadcastThemeChange() {
        const themeData = this.getCurrentTheme();
        
        // קריאה ל-callbacks רשומים
        this.changeCallbacks.forEach(callback => {
            try {
                callback(themeData);
            } catch (error) {
                console.error('❌ Theme change callback failed:', error);
            }
        });
        
        // שידור דרך Custom Events
        const event = new CustomEvent('effi-theme-changed', {
            detail: themeData,
            bubbles: true
        });
        document.dispatchEvent(event);
        
        // שידור לחלונות אחרים (אם יש)
        if (window.BroadcastChannel) {
            try {
                const channel = new BroadcastChannel('effi-theme-channel');
                channel.postMessage({
                    type: 'theme-change',
                    theme: themeData
                });
                channel.close();
            } catch (error) {
                console.warn('⚠️ BroadcastChannel not supported:', error);
            }
        }
        
        // עדכון דרך localStorage event
        const storageData = {
            type: 'effi-theme-update',
            theme: themeData,
            timestamp: Date.now()
        };
        localStorage.setItem('effi-theme-broadcast', JSON.stringify(storageData));
        
        console.log(`📡 Theme change broadcasted: ${themeData.name}`);
    }

    /**
     * רישום event listeners
     */
    setupEventListeners() {
        // האזנה לשינויים ב-localStorage מחלונות אחרים
        window.addEventListener('storage', (e) => {
            if (e.key === 'effi-theme-broadcast' && e.newValue) {
                try {
                    const data = JSON.parse(e.newValue);
                    if (data.type === 'effi-theme-update') {
                        this.handleExternalThemeChange(data.theme);
                    }
                } catch (error) {
                    console.error('❌ Failed to handle external theme change:', error);
                }
            }
        });

        // האזנה ל-BroadcastChannel
        if (window.BroadcastChannel) {
            try {
                const channel = new BroadcastChannel('effi-theme-channel');
                channel.onmessage = (event) => {
                    if (event.data.type === 'theme-change') {
                        this.handleExternalThemeChange(event.data.theme);
                    }
                };
            } catch (error) {
                console.warn('⚠️ BroadcastChannel setup failed:', error);
            }
        }

        // האזנה לשינוי גודל חלון
        window.addEventListener('resize', () => {
            // עדכון משתנים רספונסיביים
            this.updateResponsiveVariables();
        });
    }

    /**
     * טיפול בשינוי תמה חיצוני
     */
    handleExternalThemeChange(themeData) {
        if (themeData.name !== this.currentTheme) {
            console.log(`🔄 External theme change detected: ${themeData.name}`);
            this.currentTheme = themeData.name;
            this.settings = { ...this.settings, ...themeData.settings };
            this.applyCurrentTheme();
        }
    }

    /**
     * עדכון משתנים רספונסיביים
     */
    updateResponsiveVariables() {
        const width = window.innerWidth;
        const root = document.documentElement;
        
        if (width <= 768) {
            root.style.setProperty('--responsive-font-scale', '0.9');
            root.style.setProperty('--responsive-spacing-scale', '0.8');
        } else if (width <= 1024) {
            root.style.setProperty('--responsive-font-scale', '0.95');
            root.style.setProperty('--responsive-spacing-scale', '0.9');
        } else {
            root.style.setProperty('--responsive-font-scale', '1');
            root.style.setProperty('--responsive-spacing-scale', '1');
        }
    }

    /**
     * יצירת תמה מותאמת אישית
     */
    createCustomTheme(name, themeData) {
        const customKey = `custom_${name.toLowerCase().replace(/\s+/g, '_')}`;
        this.themes[customKey] = {
            name,
            ...themeData,
            custom: true
        };
        
        console.log(`🎨 Created custom theme: ${name}`);
        return customKey;
    }

    /**
     * ייצוא הגדרות תמה
     */
    exportTheme() {
        const exportData = {
            version: '1.0.0',
            theme: this.currentTheme,
            settings: this.settings,
            customThemes: Object.keys(this.themes)
                .filter(key => this.themes[key].custom)
                .reduce((acc, key) => {
                    acc[key] = this.themes[key];
                    return acc;
                }, {}),
            timestamp: Date.now()
        };
        
        return JSON.stringify(exportData, null, 2);
    }

    /**
     * יבוא הגדרות תמה
     */
    importTheme(importData) {
        try {
            const data = typeof importData === 'string' ? JSON.parse(importData) : importData;
            
            // יבוא תמות מותאמות אישית
            if (data.customThemes) {
                Object.assign(this.themes, data.customThemes);
            }
            
            // החלת הגדרות
            if (data.settings) {
                this.settings = { ...this.settings, ...data.settings };
            }
            
            // החלת תמה
            if (data.theme && this.themes[data.theme]) {
                this.setTheme(data.theme);
            }
            
            console.log('✅ Theme imported successfully');
            return true;
        } catch (error) {
            console.error('❌ Failed to import theme:', error);
            return false;
        }
    }

    /**
     * איפוס למצב ברירת מחדל
     */
    reset() {
        this.currentTheme = 'default';
        this.settings = {
            brightness: 100,
            contrast: 100,
            saturation: 100,
            borderRadius: 12,
            fontSize: 16,
            animationSpeed: 1
        };
        
        this.applyCurrentTheme();
        this.saveSettings();
        this.broadcastThemeChange();
        
        console.log('🔄 Theme system reset to defaults');
    }

    /**
     * קבלת סטטיסטיקות
     */
    getStats() {
        return {
            currentTheme: this.currentTheme,
            totalThemes: Object.keys(this.themes).length,
            customThemes: Object.keys(this.themes).filter(key => this.themes[key].custom).length,
            callbacks: this.changeCallbacks.length,
            initialized: this.initialized
        };
    }
}

// יצירת instance גלובלי
window.EffiTheme = new EffiGlobalTheme();

// התחלה אוטומטית כאשר הדף נטען
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.EffiTheme.init();
    });
} else {
    window.EffiTheme.init();
}

// יצוא למודולים
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EffiGlobalTheme;
}

console.log('🎨 Global Theme System loaded successfully');