/**
 * ⚡ Performance Optimizer - Effi-AI Government System
 * מערכת אופטימיזציית ביצועים לטעינה מהירה
 */

class PerformanceOptimizer {
    constructor() {
        this.startTime = performance.now();
        this.critical = true;
        this.init();
    }

    init() {
        // אופטימיזציה מיידית
        this.optimizePageLoad();
        this.setupLazyLoading();
        this.optimizeAnimations();
        this.setupResourcePrefetch();
        
        console.log(`⚡ Performance Optimizer loaded in ${(performance.now() - this.startTime).toFixed(2)}ms`);
    }

    /**
     * אופטימיזציית טעינת הדף
     */
    optimizePageLoad() {
        // Defer non-critical scripts
        const scripts = document.querySelectorAll('script[src]');
        scripts.forEach(script => {
            if (!script.hasAttribute('defer') && !script.hasAttribute('async')) {
                script.defer = true;
            }
        });

        // Optimize images
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (!img.hasAttribute('loading')) {
                img.loading = 'lazy';
            }
            if (!img.hasAttribute('decoding')) {
                img.decoding = 'async';
            }
        });

        // Remove unused CSS (basic optimization)
        this.removeUnusedCSS();
    }

    /**
     * הגדרת lazy loading
     */
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const element = entry.target;
                        
                        // Load images
                        if (element.dataset.src) {
                            element.src = element.dataset.src;
                            element.removeAttribute('data-src');
                        }
                        
                        // Load content
                        if (element.dataset.content) {
                            element.innerHTML = element.dataset.content;
                            element.removeAttribute('data-content');
                        }
                        
                        observer.unobserve(element);
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.01
            });

            // Observe lazy elements
            document.querySelectorAll('[data-src], [data-content]').forEach(el => {
                observer.observe(el);
            });
        }
    }

    /**
     * אופטימיזציית אנימציות
     */
    optimizeAnimations() {
        // Use requestAnimationFrame for smoother animations
        const style = document.createElement('style');
        style.textContent = `
            * {
                -webkit-transform: translateZ(0);
                transform: translateZ(0);
                -webkit-backface-visibility: hidden;
                backface-visibility: hidden;
                -webkit-perspective: 1000;
                perspective: 1000;
            }
            
            .dashboard-panel, .control-panel, .settings-panel,
            .nav-btn, .control-btn, .setting-btn, .action-btn {
                will-change: transform, opacity;
                contain: layout style paint;
            }
            
            @media (prefers-reduced-motion: reduce) {
                * {
                    animation-duration: 0.01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.01ms !important;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * הגדרת prefetch למשאבים
     */
    setupResourcePrefetch() {
        const criticalResources = [
            '/css/government-navigation.css',
            '/js/government-navigation.js',
            '/css/performance-optimized.css',
            '/js/modular-core.js'
        ];

        criticalResources.forEach(resource => {
            if (!document.querySelector(`link[href="${resource}"], script[src="${resource}"]`)) {
                const link = document.createElement('link');
                link.rel = 'prefetch';
                link.href = resource;
                document.head.appendChild(link);
            }
        });
    }

    /**
     * הסרת CSS לא בשימוש (בסיסי)
     */
    removeUnusedCSS() {
        // Basic unused CSS removal
        const styleSheets = Array.from(document.styleSheets);
        
        styleSheets.forEach(sheet => {
            try {
                if (sheet.cssRules) {
                    const rules = Array.from(sheet.cssRules);
                    rules.forEach(rule => {
                        if (rule.selectorText && !document.querySelector(rule.selectorText)) {
                            // Rule is unused - could be removed but we'll just log for now
                            // console.log('Unused CSS rule:', rule.selectorText);
                        }
                    });
                }
            } catch (e) {
                // Cross-origin or other access issues
            }
        });
    }

    /**
     * דחיית JavaScript לא קריטי
     */
    deferNonCriticalScripts() {
        // Move non-critical scripts to end of body
        const scripts = document.querySelectorAll('script[src]');
        scripts.forEach(script => {
            const src = script.getAttribute('src');
            if (src && !this.isCriticalScript(src)) {
                script.remove();
                
                // Re-add at end of body with defer
                const newScript = document.createElement('script');
                newScript.src = src;
                newScript.defer = true;
                document.body.appendChild(newScript);
            }
        });
    }

    /**
     * בדיקה אם סקריפט הוא קריטי
     */
    isCriticalScript(src) {
        const critical = [
            'government-navigation.js',
            'error-handler.js',
            'performance-optimizer.js'
        ];
        
        return critical.some(name => src.includes(name));
    }

    /**
     * ניטור ביצועים
     */
    monitorPerformance() {
        const navigation = performance.getEntriesByType('navigation')[0];
        const metrics = {
            domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
            loadComplete: navigation.loadEventEnd - navigation.loadEventStart,
            totalLoad: navigation.loadEventEnd - navigation.fetchStart
        };

        console.log('📊 Performance Metrics:', metrics);

        // Alert if slow
        if (metrics.totalLoad > 5000) {
            console.warn('⚠️ Slow page load detected:', metrics.totalLoad + 'ms');
            this.optimizeSlowLoad();
        }

        return metrics;
    }

    /**
     * אופטימיזציה לטעינה איטית
     */
    optimizeSlowLoad() {
        // Remove non-essential elements
        const nonEssential = document.querySelectorAll('.animation, .effect, .decoration');
        nonEssential.forEach(el => {
            el.style.display = 'none';
        });

        // Simplify styles
        const style = document.createElement('style');
        style.textContent = `
            * {
                animation: none !important;
                transition: none !important;
                box-shadow: none !important;
                text-shadow: none !important;
                border-radius: 0 !important;
            }
        `;
        document.head.appendChild(style);

        console.log('🚀 Emergency performance optimization applied');
    }

    /**
     * הפעלת מצב חירום לביצועים
     */
    enableEmergencyMode() {
        document.body.classList.add('emergency-performance');
        
        const emergencyStyle = document.createElement('style');
        emergencyStyle.textContent = `
            .emergency-performance * {
                animation: none !important;
                transition: none !important;
                transform: none !important;
                filter: none !important;
                backdrop-filter: none !important;
                box-shadow: none !important;
                text-shadow: none !important;
                border-radius: 4px !important;
                background-image: none !important;
            }
            
            .emergency-performance .dashboard-panel,
            .emergency-performance .control-panel,
            .emergency-performance .settings-panel {
                background: rgba(255, 255, 255, 0.1) !important;
                border: 1px solid rgba(255, 255, 255, 0.2) !important;
            }
        `;
        document.head.appendChild(emergencyStyle);
        
        console.log('🚨 Emergency performance mode enabled');
    }
}

// Auto-initialize when loaded
document.addEventListener('DOMContentLoaded', () => {
    window.EffiPerformanceOptimizer = new PerformanceOptimizer();
    
    // Monitor page load
    window.addEventListener('load', () => {
        setTimeout(() => {
            const metrics = window.EffiPerformanceOptimizer.monitorPerformance();
            
            // Enable emergency mode if needed
            if (metrics.totalLoad > 8000) {
                window.EffiPerformanceOptimizer.enableEmergencyMode();
            }
        }, 1000);
    });
});