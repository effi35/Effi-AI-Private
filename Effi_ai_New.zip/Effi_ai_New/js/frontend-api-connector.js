/**
 * Frontend API Connector
 * Connects all HTML pages to the real backend system
 */
class FrontendAPIConnector {
    constructor() {
        this.baseURL = window.location.origin;
        this.apiBase = `${this.baseURL}/api`;
        this.token = localStorage.getItem('authToken');
        this.socket = null;
        this.isConnected = false;
        
        // Initialize connection
        this.initializeConnection();
        this.setupWebSocket();
        
        console.log('🔗 Frontend API Connector initialized');
    }
    
    /**
     * Initialize API connection
     */
    async initializeConnection() {
        try {
            // Test API connectivity
            const response = await this.makeRequest('/health', 'GET');
            if (response.success !== false) {
                this.isConnected = true;
                console.log('✅ Backend API connected successfully');
                this.updateConnectionStatus(true);
            }
        } catch (error) {
            console.warn('⚠️ Backend API not available, using mock data');
            this.isConnected = false;
            this.updateConnectionStatus(false);
        }
    }
    
    /**
     * Setup WebSocket connection
     */
    setupWebSocket() {
        try {
            this.socket = io();
            
            this.socket.on('connect', () => {
                console.log('🔗 WebSocket connected');
                
                // Authenticate if token exists
                if (this.token) {
                    this.socket.emit('authenticate', { 
                        token: this.token,
                        userType: localStorage.getItem('userType') || 'citizen'
                    });
                }
            });
            
            this.socket.on('authenticated', (data) => {
                console.log('✅ WebSocket authenticated:', data);
                this.handleWebSocketAuth(data);
            });
            
            this.socket.on('stream_data', (data) => {
                this.handleStreamData(data);
            });
            
            this.socket.on('system_alert', (alert) => {
                this.showSystemAlert(alert);
            });
            
            this.socket.on('disconnect', () => {
                console.log('❌ WebSocket disconnected');
            });
            
        } catch (error) {
            console.warn('⚠️ WebSocket not available:', error.message);
        }
    }
    
    /**
     * Make API request
     */
    async makeRequest(endpoint, method = 'GET', data = null) {
        try {
            const headers = {
                'Content-Type': 'application/json'
            };
            
            if (this.token) {
                headers['Authorization'] = `Bearer ${this.token}`;
            }
            
            const config = {
                method,
                headers
            };
            
            if (data && method !== 'GET') {
                config.body = JSON.stringify(data);
            }
            
            const response = await fetch(`${this.apiBase}${endpoint}`, config);
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.error || `HTTP ${response.status}`);
            }
            
            return result;
            
        } catch (error) {
            console.error(`API request failed: ${method} ${endpoint}`, error);
            
            // Return mock data for development
            return this.getMockData(endpoint, method, data);
        }
    }
    
    /**
     * Authentication methods
     */
    async login(username, password) {
        try {
            const response = await this.makeRequest('/auth/login', 'POST', {
                username,
                password
            });
            
            if (response.success) {
                this.token = response.tokens.accessToken;
                localStorage.setItem('authToken', this.token);
                localStorage.setItem('userType', response.user.userType);
                localStorage.setItem('userInfo', JSON.stringify(response.user));
                
                // Reconnect WebSocket with auth
                if (this.socket) {
                    this.socket.emit('authenticate', {
                        token: this.token,
                        userType: response.user.userType
                    });
                }
                
                return response;
            }
            
            throw new Error(response.error);
            
        } catch (error) {
            console.error('Login failed:', error);
            throw error;
        }
    }
    
    async logout() {
        try {
            if (this.token) {
                await this.makeRequest('/auth/logout', 'POST');
            }
        } catch (error) {
            console.warn('Logout request failed:', error);
        } finally {
            this.token = null;
            localStorage.removeItem('authToken');
            localStorage.removeItem('userType');
            localStorage.removeItem('userInfo');
            
            if (this.socket) {
                this.socket.disconnect();
                this.setupWebSocket();
            }
        }
    }
    
    /**
     * AI Chat methods
     */
    async sendChatMessage(message, engine = 'private', context = {}) {
        return await this.makeRequest('/ai/chat', 'POST', {
            message,
            engine,
            context: {
                ...context,
                language: this.detectLanguage(message),
                timestamp: new Date().toISOString()
            }
        });
    }
    
    /**
     * Connections management
     */
    async getConnections(filters = {}) {
        const queryParams = new URLSearchParams(filters).toString();
        const endpoint = `/connections${queryParams ? '?' + queryParams : ''}`;
        return await this.makeRequest(endpoint);
    }
    
    async updateConnectionPermissions(connectionId, permissions) {
        return await this.makeRequest(`/connections/${connectionId}/permissions`, 'PATCH', permissions);
    }
    
    async testConnection(connectionId) {
        return await this.makeRequest(`/connections/${connectionId}/test`, 'POST');
    }
    
    /**
     * System monitoring
     */
    async getSystemStatus() {
        return await this.makeRequest('/system/status');
    }
    
    async getSystemMetrics() {
        return await this.makeRequest('/system/metrics');
    }
    
    async getSystemLogs(filters = {}) {
        const queryParams = new URLSearchParams(filters).toString();
        const endpoint = `/system/logs${queryParams ? '?' + queryParams : ''}`;
        return await this.makeRequest(endpoint);
    }
    
    /**
     * WebSocket stream subscription
     */
    subscribeToStream(streamName) {
        if (this.socket && this.socket.connected) {
            this.socket.emit('subscribe', streamName);
        }
    }
    
    unsubscribeFromStream(streamName) {
        if (this.socket && this.socket.connected) {
            this.socket.emit('unsubscribe', streamName);
        }
    }
    
    /**
     * Handle WebSocket authentication
     */
    handleWebSocketAuth(data) {
        // Update UI based on user permissions
        this.updateUIForUserType(data.userType);
        
        // Auto-subscribe to relevant streams
        if (data.availableStreams) {
            data.availableStreams.forEach(stream => {
                if (stream.autoSubscribe !== false) {
                    this.subscribeToStream(stream.name);
                }
            });
        }
    }
    
    /**
     * Handle incoming stream data
     */
    handleStreamData(data) {
        // Dispatch to appropriate handlers based on stream type
        switch (data.stream) {
            case 'connections':
                this.updateConnectionsDisplay(data.data);
                break;
            case 'system_metrics':
                this.updateSystemMetrics(data.data);
                break;
            case 'citizen_services':
                this.updateCitizenServices(data.data);
                break;
            case 'security':
                this.updateSecurityStatus(data.data);
                break;
            case 'announcements':
                this.showAnnouncement(data.data);
                break;
        }
        
        // Trigger custom event for other handlers
        window.dispatchEvent(new CustomEvent('streamData', { 
            detail: data 
        }));
    }
    
    /**
     * Update connections display
     */
    updateConnectionsDisplay(data) {
        // Update live connections dashboard
        const elements = {
            totalConnections: document.getElementById('totalConnections'),
            activeConnections: document.getElementById('activeConnections'),
            avgResponseTime: document.getElementById('avgResponseTime'),
            throughput: document.getElementById('throughput')
        };
        
        Object.keys(elements).forEach(key => {
            if (elements[key] && data[key] !== undefined) {
                elements[key].textContent = data[key];
            }
        });
        
        // Trigger update event
        window.dispatchEvent(new CustomEvent('connectionsUpdated', { 
            detail: data 
        }));
    }
    
    /**
     * Update system metrics
     */
    updateSystemMetrics(data) {
        // Update system metrics displays
        const metrics = ['cpuUsage', 'memoryUsage', 'diskUsage', 'networkIn', 'networkOut'];
        
        metrics.forEach(metric => {
            const element = document.getElementById(metric);
            if (element && data[metric] !== undefined) {
                element.textContent = Math.round(data[metric]);
                
                // Update progress bars if they exist
                const progressBar = document.getElementById(`${metric}Progress`);
                if (progressBar) {
                    progressBar.style.width = `${data[metric]}%`;
                }
            }
        });
        
        window.dispatchEvent(new CustomEvent('metricsUpdated', { 
            detail: data 
        }));
    }
    
    /**
     * Show system alert
     */
    showSystemAlert(alert) {
        // Create alert notification
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${alert.priority} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <strong>התראת מערכת:</strong> ${alert.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Add to alerts container or create one
        let alertsContainer = document.getElementById('systemAlerts');
        if (!alertsContainer) {
            alertsContainer = document.createElement('div');
            alertsContainer.id = 'systemAlerts';
            alertsContainer.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
            document.body.appendChild(alertsContainer);
        }
        
        alertsContainer.appendChild(alertDiv);
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 10000);
    }
    
    /**
     * Show announcement
     */
    showAnnouncement(announcement) {
        const announcementElement = document.getElementById('latestAnnouncement');
        if (announcementElement) {
            announcementElement.textContent = announcement.latestAnnouncement;
        }
        
        // Show as toast notification
        this.showToast(announcement.latestAnnouncement, 'info');
    }
    
    /**
     * Show toast notification
     */
    showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast show`;
        toast.innerHTML = `
            <div class="toast-header">
                <strong class="me-auto">מערכת ממשלתית</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">${message}</div>
        `;
        
        // Add to toasts container
        let toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toastContainer';
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.appendChild(toast);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
    }
    
    /**
     * Update UI for user type
     */
    updateUIForUserType(userType) {
        // Show/hide elements based on user permissions
        const elements = {
            government: document.querySelectorAll('.government-only'),
            admin: document.querySelectorAll('.admin-only'),
            citizen: document.querySelectorAll('.citizen-only')
        };
        
        // Hide all restricted elements first
        Object.values(elements).forEach(nodeList => {
            nodeList.forEach(element => {
                element.style.display = 'none';
            });
        });
        
        // Show elements for current user type
        if (elements[userType]) {
            elements[userType].forEach(element => {
                element.style.display = '';
            });
        }
        
        // Update user info display
        const userTypeElement = document.getElementById('currentUserType');
        if (userTypeElement) {
            userTypeElement.textContent = userType;
        }
    }
    
    /**
     * Update connection status indicator
     */
    updateConnectionStatus(isConnected) {
        const statusIndicator = document.getElementById('connectionStatus');
        if (statusIndicator) {
            statusIndicator.className = isConnected ? 'status-connected' : 'status-disconnected';
            statusIndicator.textContent = isConnected ? 'מחובר' : 'לא מחובר';
        }
    }
    
    /**
     * Detect message language
     */
    detectLanguage(text) {
        // Simple Hebrew detection
        const hebrewPattern = /[\u0590-\u05FF]/;
        return hebrewPattern.test(text) ? 'hebrew' : 'english';
    }
    
    /**
     * Get mock data for development
     */
    getMockData(endpoint, method, data) {
        // Return mock responses for development
        const mockResponses = {
            '/health': { status: 'OK', mock: true },
            '/auth/login': { 
                success: true, 
                user: { userType: 'citizen', username: 'demo' },
                tokens: { accessToken: 'mock_token' }
            },
            '/ai/chat': {
                success: true,
                response: `תשובה מדומה עבור: "${data?.message}". מערכת ה-AI עובדת במצב פיתוח.`,
                engine: 'mock'
            },
            '/connections': {
                success: true,
                connections: [
                    { name: 'משרד הפנים', status: 'active' },
                    { name: 'משרד הביטחון', status: 'active' }
                ],
                total: 5560
            },
            '/system/status': {
                success: true,
                status: 'operational',
                modules: { active: 140309 }
            }
        };
        
        return mockResponses[endpoint] || { 
            success: false, 
            error: 'Mock data not available',
            mock: true 
        };
    }
    
    /**
     * Get connection instance
     */
    static getInstance() {
        if (!window.effiAPIConnector) {
            window.effiAPIConnector = new FrontendAPIConnector();
        }
        return window.effiAPIConnector;
    }
}

// Initialize global API connector
window.EffiAPI = FrontendAPIConnector.getInstance();

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FrontendAPIConnector;
}