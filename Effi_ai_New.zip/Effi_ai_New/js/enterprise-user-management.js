/**
 * Effi-AI Enterprise User Management & Security System
 * מערכת ניהול משתמשים ואבטחה ברמה ארגונית
 * 
 * Professional enterprise-grade user management with comprehensive security features
 * מערכת ניהול משתמשים מקצועית ברמה ארגונית עם תכונות אבטחה מקיפות
 * 
 * @version 2.0.0
 * @author Effi-AI Development Team
 * @license Enterprise License
 */

import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import speakeasy from 'speakeasy';
import ldap from 'ldapjs';
import redis from 'redis';
import { EventEmitter } from 'events';

/**
 * Enterprise User Management System
 * מערכת ניהול משתמשים ארגונית
 */
class EnterpriseUserManagement extends EventEmitter {
    constructor(config = {}) {
        super();
        
        // תצורת מערכת בסיסית
        this.config = {
            // הגדרות JWT
            jwtSecret: config.jwtSecret || process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex'),
            jwtExpiry: config.jwtExpiry || '24h',
            refreshTokenExpiry: config.refreshTokenExpiry || '30d',
            
            // הגדרות אבטחה
            passwordMinLength: config.passwordMinLength || 12,
            passwordComplexity: config.passwordComplexity || true,
            maxLoginAttempts: config.maxLoginAttempts || 5,
            lockoutDuration: config.lockoutDuration || 900000, // 15 minutes
            
            // הגדרות MFA
            mfaRequired: config.mfaRequired || false,
            mfaWindowSize: config.mfaWindowSize || 2,
            
            // הגדרות LDAP
            ldapEnabled: config.ldapEnabled || false,
            ldapConfig: config.ldapConfig || {},
            
            // הגדרות Redis
            redisUrl: config.redisUrl || 'redis://localhost:6379',
            
            // הגדרות GDPR
            gdprCompliance: config.gdprCompliance || true,
            dataRetentionDays: config.dataRetentionDays || 365,
            
            // הגדרות רעננת API
            rateLimitRequests: config.rateLimitRequests || 1000,
            rateLimitWindow: config.rateLimitWindow || 3600000, // 1 hour
            
            ...config
        };
        
        // אתחול רכיבי המערכת
        this.initializeSystem();
    }
    
    /**
     * אתחול מערכת ניהול המשתמשים
     * Initialize user management system
     */
    async initializeSystem() {
        try {
            // אתחול Redis לניהול הפעלות
            this.redisClient = redis.createClient({ url: this.config.redisUrl });
            await this.redisClient.connect();
            
            // אתחול מאגר נתונים
            this.userDatabase = new Map();
            this.sessionStore = new Map();
            this.auditLog = [];
            this.rateLimitStore = new Map();
            
            // אתחול מערכת הרשאות
            this.initializeRBAC();
            
            // אתחול מערכת LDAP
            if (this.config.ldapEnabled) {
                await this.initializeLDAP();
            }
            
            // אתחול מערכת ניטור
            this.initializeMonitoring();
            
            console.log('🚀 Enterprise User Management System initialized successfully');
            this.emit('system:initialized');
            
        } catch (error) {
            console.error('❌ Failed to initialize user management system:', error);
            throw error;
        }
    }
    
    /**
     * מערכת בקרת גישה מבוססת תפקידים (RBAC)
     * Role-Based Access Control system
     */
    initializeRBAC() {
        // הגדרת תפקידים וההרשאות
        this.roles = {
            'super_admin': {
                permissions: ['*'], // כל ההרשאות
                level: 100,
                description: 'Super Administrator - Full System Access'
            },
            'admin': {
                permissions: [
                    'user:create', 'user:read', 'user:update', 'user:delete',
                    'role:assign', 'system:configure', 'audit:read'
                ],
                level: 90,
                description: 'Administrator - System Management'
            },
            'manager': {
                permissions: [
                    'user:read', 'user:update', 'team:manage', 'reports:view'
                ],
                level: 70,
                description: 'Manager - Team and User Management'
            },
            'user': {
                permissions: [
                    'profile:read', 'profile:update', 'dashboard:access'
                ],
                level: 50,
                description: 'Standard User - Basic Access'
            },
            'guest': {
                permissions: ['dashboard:view'],
                level: 10,
                description: 'Guest User - Limited Access'
            }
        };
        
        // הגדרת הרשאות מפורטות
        this.permissions = {
            'user:create': 'Create new users',
            'user:read': 'View user information',
            'user:update': 'Update user information',
            'user:delete': 'Delete users',
            'role:assign': 'Assign roles to users',
            'system:configure': 'Configure system settings',
            'audit:read': 'View audit logs',
            'team:manage': 'Manage team members',
            'reports:view': 'View reports',
            'profile:read': 'View own profile',
            'profile:update': 'Update own profile',
            'dashboard:access': 'Access dashboard',
            'dashboard:view': 'View dashboard'
        };
    }
    
    /**
     * אתחול מערכת LDAP
     * Initialize LDAP system
     */
    async initializeLDAP() {
        try {
            this.ldapClient = ldap.createClient({
                url: this.config.ldapConfig.url,
                timeout: 5000,
                connectTimeout: 10000
            });
            
            console.log('🔗 LDAP integration initialized');
        } catch (error) {
            console.error('❌ LDAP initialization failed:', error);
        }
    }
    
    /**
     * אתחול מערכת ניטור
     * Initialize monitoring system
     */
    initializeMonitoring() {
        // ניטור פעילות משתמשים בזמן אמת
        this.activeUsers = new Set();
        this.userActivities = new Map();
        this.securityAlerts = [];
        
        // ניטור ביצועים
        this.performanceMetrics = {
            loginAttempts: 0,
            successfulLogins: 0,
            failedLogins: 0,
            mfaVerifications: 0,
            apiRequests: 0,
            blockedRequests: 0
        };
        
        // התחלת ניטור מחזורי
        this.startPeriodicMonitoring();
    }
    
    /**
     * רישום משתמש חדש
     * Register new user
     */
    async registerUser(userData) {
        try {
            // ולידציה של נתוני המשתמש
            this.validateUserData(userData);
            
            // בדיקת קיום משתמש
            if (await this.userExists(userData.email)) {
                throw new Error('User already exists');
            }
            
            // יצירת מזהה ייחודי
            const userId = this.generateUserId();
            
            // הצפנת סיסמה
            const hashedPassword = await this.hashPassword(userData.password);
            
            // יצירת נתוני משתמש
            const user = {
                id: userId,
                email: userData.email.toLowerCase(),
                username: userData.username,
                firstName: userData.firstName,
                lastName: userData.lastName,
                password: hashedPassword,
                role: userData.role || 'user',
                tenant: userData.tenant || 'default',
                status: 'pending_activation',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                lastLogin: null,
                failedLoginAttempts: 0,
                lockedUntil: null,
                mfaEnabled: false,
                mfaSecret: null,
                preferences: userData.preferences || {},
                metadata: {
                    registrationIP: userData.ip,
                    userAgent: userData.userAgent,
                    source: userData.source || 'direct'
                }
            };
            
            // שמירת המשתמש במאגר
            this.userDatabase.set(userId, user);
            
            // רישום בלוג ביקורת
            await this.logAuditEvent('user:registered', userId, {
                email: user.email,
                role: user.role,
                tenant: user.tenant
            });
            
            // שליחת אירוע
            this.emit('user:registered', user);
            
            // יצירת טוקן הפעלה
            const activationToken = await this.generateActivationToken(userId);
            
            console.log(`✅ User registered successfully: ${user.email}`);
            
            return {
                success: true,
                userId,
                activationToken,
                user: this.sanitizeUserData(user)
            };
            
        } catch (error) {
            console.error('❌ User registration failed:', error);
            throw error;
        }
    }
    
    /**
     * אימות משתמש והתחברות
     * Authenticate user and login
     */
    async authenticateUser(credentials) {
        try {
            const startTime = Date.now();
            this.performanceMetrics.loginAttempts++;
            
            // ולידציה של פרטי התחברות
            if (!credentials.email || !credentials.password) {
                throw new Error('Email and password are required');
            }
            
            // איתור המשתמש
            const user = await this.findUserByEmail(credentials.email);
            if (!user) {
                this.performanceMetrics.failedLogins++;
                throw new Error('Invalid credentials');
            }
            
            // בדיקת נעילת חשבון
            if (user.lockedUntil && new Date() < new Date(user.lockedUntil)) {
                throw new Error('Account is locked due to multiple failed attempts');
            }
            
            // בדיקת סטטוס המשתמש
            if (user.status !== 'active') {
                throw new Error('Account is not active');
            }
            
            // אימות סיסמה
            const isPasswordValid = await this.verifyPassword(credentials.password, user.password);
            if (!isPasswordValid) {
                await this.handleFailedLogin(user.id);
                this.performanceMetrics.failedLogins++;
                throw new Error('Invalid credentials');
            }
            
            // איפוס נסיונות התחברות כושלים
            await this.resetFailedLoginAttempts(user.id);
            
            // בדיקת MFA אם נדרש
            if (user.mfaEnabled || this.config.mfaRequired) {
                if (!credentials.mfaToken) {
                    return {
                        success: false,
                        requiresMFA: true,
                        userId: user.id
                    };
                }
                
                const isMFAValid = await this.verifyMFA(user.id, credentials.mfaToken);
                if (!isMFAValid) {
                    this.performanceMetrics.failedLogins++;
                    throw new Error('Invalid MFA token');
                }
                this.performanceMetrics.mfaVerifications++;
            }
            
            // יצירת הפעלה (session)
            const session = await this.createUserSession(user, credentials);
            
            // עדכון זמן התחברות אחרון
            await this.updateLastLogin(user.id, credentials.ip);
            
            // רישום בלוג ביקורת
            await this.logAuditEvent('user:login', user.id, {
                ip: credentials.ip,
                userAgent: credentials.userAgent,
                duration: Date.now() - startTime
            });
            
            this.performanceMetrics.successfulLogins++;
            
            // שליחת אירוע
            this.emit('user:login', user);
            
            console.log(`✅ User authenticated successfully: ${user.email}`);
            
            return {
                success: true,
                user: this.sanitizeUserData(user),
                session,
                permissions: await this.getUserPermissions(user.id)
            };
            
        } catch (error) {
            console.error('❌ Authentication failed:', error);
            throw error;
        }
    }
    
    /**
     * יצירת הפעלת משתמש
     * Create user session
     */
    async createUserSession(user, credentials) {
        const sessionId = this.generateSessionId();
        const accessToken = await this.generateAccessToken(user);
        const refreshToken = await this.generateRefreshToken(user);
        
        const session = {
            id: sessionId,
            userId: user.id,
            accessToken,
            refreshToken,
            createdAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
            ip: credentials.ip,
            userAgent: credentials.userAgent,
            active: true
        };
        
        // שמירת ההפעלה
        this.sessionStore.set(sessionId, session);
        await this.redisClient.setEx(`session:${sessionId}`, 86400, JSON.stringify(session));
        
        // הוספה לרשימת משתמשים פעילים
        this.activeUsers.add(user.id);
        
        return session;
    }
    
    /**
     * אימות טוקן גישה
     * Validate access token
     */
    async validateAccessToken(token) {
        try {
            const decoded = jwt.verify(token, this.config.jwtSecret);
            const user = this.userDatabase.get(decoded.userId);
            
            if (!user || user.status !== 'active') {
                throw new Error('Invalid token or inactive user');
            }
            
            return {
                valid: true,
                user: this.sanitizeUserData(user),
                permissions: await this.getUserPermissions(user.id)
            };
            
        } catch (error) {
            return {
                valid: false,
                error: error.message
            };
        }
    }
    
    /**
     * רענון טוקן גישה
     * Refresh access token
     */
    async refreshAccessToken(refreshToken) {
        try {
            const decoded = jwt.verify(refreshToken, this.config.jwtSecret);
            const user = this.userDatabase.get(decoded.userId);
            
            if (!user || user.status !== 'active') {
                throw new Error('Invalid refresh token');
            }
            
            const newAccessToken = await this.generateAccessToken(user);
            const newRefreshToken = await this.generateRefreshToken(user);
            
            return {
                success: true,
                accessToken: newAccessToken,
                refreshToken: newRefreshToken
            };
            
        } catch (error) {
            throw new Error('Invalid refresh token');
        }
    }
    
    /**
     * הגדרת MFA למשתמש
     * Setup MFA for user
     */
    async setupMFA(userId) {
        try {
            const user = this.userDatabase.get(userId);
            if (!user) {
                throw new Error('User not found');
            }
            
            // יצירת סוד MFA
            const secret = speakeasy.generateSecret({
                length: 32,
                name: `Effi-AI (${user.email})`,
                issuer: 'Effi-AI Enterprise'
            });
            
            // שמירת הסוד במאגר
            user.mfaSecret = secret.base32;
            user.updatedAt = new Date().toISOString();
            
            // רישום בלוג ביקורת
            await this.logAuditEvent('user:mfa_setup', userId);
            
            return {
                success: true,
                secret: secret.base32,
                qrCode: secret.otpauth_url
            };
            
        } catch (error) {
            console.error('❌ MFA setup failed:', error);
            throw error;
        }
    }
    
    /**
     * אימות MFA
     * Verify MFA token
     */
    async verifyMFA(userId, token) {
        try {
            const user = this.userDatabase.get(userId);
            if (!user || !user.mfaSecret) {
                return false;
            }
            
            const verified = speakeasy.totp.verify({
                secret: user.mfaSecret,
                encoding: 'base32',
                token: token,
                window: this.config.mfaWindowSize
            });
            
            if (verified) {
                await this.logAuditEvent('user:mfa_verified', userId);
            } else {
                await this.logAuditEvent('user:mfa_failed', userId);
            }
            
            return verified;
            
        } catch (error) {
            console.error('❌ MFA verification failed:', error);
            return false;
        }
    }
    
    /**
     * בדיקת הרשאות משתמש
     * Check user permissions
     */
    async checkPermission(userId, permission) {
        try {
            const user = this.userDatabase.get(userId);
            if (!user) {
                return false;
            }
            
            const userRole = this.roles[user.role];
            if (!userRole) {
                return false;
            }
            
            // בדיקת הרשאה מלאה
            if (userRole.permissions.includes('*')) {
                return true;
            }
            
            // בדיקת הרשאה ספציפית
            return userRole.permissions.includes(permission);
            
        } catch (error) {
            console.error('❌ Permission check failed:', error);
            return false;
        }
    }
    
    /**
     * קבלת כל הרשאות המשתמש
     * Get user permissions
     */
    async getUserPermissions(userId) {
        try {
            const user = this.userDatabase.get(userId);
            if (!user) {
                return [];
            }
            
            const userRole = this.roles[user.role];
            if (!userRole) {
                return [];
            }
            
            return userRole.permissions;
            
        } catch (error) {
            console.error('❌ Failed to get user permissions:', error);
            return [];
        }
    }
    
    /**
     * ניהול מחזור חיי המשתמש
     * User lifecycle management
     */
    async manageUserLifecycle() {
        // בדיקת משתמשים לא פעילים
        const inactiveUsers = this.findInactiveUsers();
        
        for (const user of inactiveUsers) {
            // שליחת התראה על חוסר פעילות
            this.emit('user:inactive', user);
            
            // השעיית משתמשים לא פעילים לזמן ארוך
            if (this.shouldSuspendUser(user)) {
                await this.suspendUser(user.id, 'Inactive for extended period');
            }
        }
        
        // ניקוי נתונים ישנים (GDPR)
        if (this.config.gdprCompliance) {
            await this.cleanupOldData();
        }
    }
    
    /**
     * ניטור פעילות משתמשים בזמן אמת
     * Real-time user activity monitoring
     */
    trackUserActivity(userId, activity) {
        const timestamp = new Date().toISOString();
        
        if (!this.userActivities.has(userId)) {
            this.userActivities.set(userId, []);
        }
        
        this.userActivities.get(userId).push({
            activity,
            timestamp,
            ip: activity.ip,
            userAgent: activity.userAgent
        });
        
        // שמירה על גודל מוגבל של פעילויות
        const activities = this.userActivities.get(userId);
        if (activities.length > 1000) {
            activities.splice(0, activities.length - 1000);
        }
        
        // זיהוי פעילות חשודה
        this.detectSuspiciousActivity(userId, activity);
    }
    
    /**
     * זיהוי פעילות חשודה
     * Detect suspicious activity
     */
    detectSuspiciousActivity(userId, activity) {
        const userActivities = this.userActivities.get(userId) || [];
        const recentActivities = userActivities.slice(-10);
        
        // בדיקת התחברות ממקומות רבים
        const uniqueIPs = new Set(recentActivities.map(a => a.ip));
        if (uniqueIPs.size > 5) {
            this.createSecurityAlert('multiple_locations', userId, {
                ipCount: uniqueIPs.size,
                ips: Array.from(uniqueIPs)
            });
        }
        
        // בדיקת פעילות יוצאת דופן
        const activityCount = recentActivities.length;
        if (activityCount > 50) {
            this.createSecurityAlert('excessive_activity', userId, {
                activityCount
            });
        }
    }
    
    /**
     * הגבלת קצב API
     * API rate limiting
     */
    async checkRateLimit(userId, endpoint) {
        const key = `${userId}:${endpoint}`;
        const now = Date.now();
        const windowStart = now - this.config.rateLimitWindow;
        
        if (!this.rateLimitStore.has(key)) {
            this.rateLimitStore.set(key, []);
        }
        
        const requests = this.rateLimitStore.get(key);
        
        // ניקוי בקשות ישנות
        const validRequests = requests.filter(time => time > windowStart);
        this.rateLimitStore.set(key, validRequests);
        
        // בדיקת גבול
        if (validRequests.length >= this.config.rateLimitRequests) {
            this.performanceMetrics.blockedRequests++;
            return {
                allowed: false,
                retryAfter: Math.ceil((validRequests[0] + this.config.rateLimitWindow - now) / 1000)
            };
        }
        
        // הוספת הבקשה הנוכחית
        validRequests.push(now);
        this.performanceMetrics.apiRequests++;
        
        return {
            allowed: true,
            remaining: this.config.rateLimitRequests - validRequests.length
        };
    }
    
    /**
     * ניתוח משתמשים מתקדם
     * Advanced user analytics
     */
    generateUserAnalytics() {
        const analytics = {
            totalUsers: this.userDatabase.size,
            activeUsers: this.activeUsers.size,
            usersByRole: {},
            usersByTenant: {},
            usersByStatus: {},
            loginStats: {
                totalAttempts: this.performanceMetrics.loginAttempts,
                successfulLogins: this.performanceMetrics.successfulLogins,
                failedLogins: this.performanceMetrics.failedLogins,
                successRate: this.performanceMetrics.loginAttempts > 0 ? 
                    (this.performanceMetrics.successfulLogins / this.performanceMetrics.loginAttempts * 100).toFixed(2) : 0
            },
            securityAlerts: this.securityAlerts.length,
            apiStats: {
                totalRequests: this.performanceMetrics.apiRequests,
                blockedRequests: this.performanceMetrics.blockedRequests,
                blockRate: this.performanceMetrics.apiRequests > 0 ?
                    (this.performanceMetrics.blockedRequests / this.performanceMetrics.apiRequests * 100).toFixed(2) : 0
            }
        };
        
        // סיכום לפי תפקידים
        for (const user of this.userDatabase.values()) {
            analytics.usersByRole[user.role] = (analytics.usersByRole[user.role] || 0) + 1;
            analytics.usersByTenant[user.tenant] = (analytics.usersByTenant[user.tenant] || 0) + 1;
            analytics.usersByStatus[user.status] = (analytics.usersByStatus[user.status] || 0) + 1;
        }
        
        return analytics;
    }
    
    /**
     * פונקציות עזר
     * Helper functions
     */
    
    generateUserId() {
        return 'usr_' + crypto.randomBytes(16).toString('hex');
    }
    
    generateSessionId() {
        return 'ses_' + crypto.randomBytes(16).toString('hex');
    }
    
    async hashPassword(password) {
        return await bcrypt.hash(password, 12);
    }
    
    async verifyPassword(password, hash) {
        return await bcrypt.compare(password, hash);
    }
    
    async generateAccessToken(user) {
        return jwt.sign(
            {
                userId: user.id,
                email: user.email,
                role: user.role,
                tenant: user.tenant,
                type: 'access'
            },
            this.config.jwtSecret,
            { expiresIn: this.config.jwtExpiry }
        );
    }
    
    async generateRefreshToken(user) {
        return jwt.sign(
            {
                userId: user.id,
                type: 'refresh'
            },
            this.config.jwtSecret,
            { expiresIn: this.config.refreshTokenExpiry }
        );
    }
    
    async generateActivationToken(userId) {
        return jwt.sign(
            {
                userId,
                type: 'activation'
            },
            this.config.jwtSecret,
            { expiresIn: '24h' }
        );
    }
    
    validateUserData(userData) {
        if (!userData.email || !this.isValidEmail(userData.email)) {
            throw new Error('Valid email is required');
        }
        
        if (!userData.password || !this.isValidPassword(userData.password)) {
            throw new Error('Password does not meet security requirements');
        }
        
        if (!userData.firstName || !userData.lastName) {
            throw new Error('First name and last name are required');
        }
    }
    
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    isValidPassword(password) {
        if (password.length < this.config.passwordMinLength) {
            return false;
        }
        
        if (this.config.passwordComplexity) {
            const hasUpper = /[A-Z]/.test(password);
            const hasLower = /[a-z]/.test(password);
            const hasNumber = /\d/.test(password);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
            
            return hasUpper && hasLower && hasNumber && hasSpecial;
        }
        
        return true;
    }
    
    async userExists(email) {
        for (const user of this.userDatabase.values()) {
            if (user.email === email.toLowerCase()) {
                return true;
            }
        }
        return false;
    }
    
    async findUserByEmail(email) {
        for (const user of this.userDatabase.values()) {
            if (user.email === email.toLowerCase()) {
                return user;
            }
        }
        return null;
    }
    
    async handleFailedLogin(userId) {
        const user = this.userDatabase.get(userId);
        if (!user) return;
        
        user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;
        
        if (user.failedLoginAttempts >= this.config.maxLoginAttempts) {
            user.lockedUntil = new Date(Date.now() + this.config.lockoutDuration).toISOString();
            await this.logAuditEvent('user:locked', userId);
        }
        
        user.updatedAt = new Date().toISOString();
    }
    
    async resetFailedLoginAttempts(userId) {
        const user = this.userDatabase.get(userId);
        if (!user) return;
        
        user.failedLoginAttempts = 0;
        user.lockedUntil = null;
        user.updatedAt = new Date().toISOString();
    }
    
    async updateLastLogin(userId, ip) {
        const user = this.userDatabase.get(userId);
        if (!user) return;
        
        user.lastLogin = new Date().toISOString();
        user.metadata.lastLoginIP = ip;
        user.updatedAt = new Date().toISOString();
    }
    
    sanitizeUserData(user) {
        const { password, mfaSecret, ...sanitized } = user;
        return sanitized;
    }
    
    async logAuditEvent(action, userId, metadata = {}) {
        const auditEntry = {
            id: crypto.randomBytes(16).toString('hex'),
            action,
            userId,
            timestamp: new Date().toISOString(),
            metadata
        };
        
        this.auditLog.push(auditEntry);
        
        // שמירה ב-Redis לזמינות גבוהה
        await this.redisClient.lPush('audit_log', JSON.stringify(auditEntry));
        
        // הגבלת גודל הלוג במזכר
        if (this.auditLog.length > 10000) {
            this.auditLog.splice(0, this.auditLog.length - 10000);
        }
    }
    
    createSecurityAlert(type, userId, data) {
        const alert = {
            id: crypto.randomBytes(16).toString('hex'),
            type,
            userId,
            data,
            timestamp: new Date().toISOString(),
            severity: this.getAlertSeverity(type),
            resolved: false
        };
        
        this.securityAlerts.push(alert);
        this.emit('security:alert', alert);
        
        console.warn(`🚨 Security Alert [${type}]: User ${userId}`, data);
    }
    
    getAlertSeverity(type) {
        const severityMap = {
            'multiple_locations': 'high',
            'excessive_activity': 'medium',
            'failed_mfa': 'high',
            'password_breach': 'critical',
            'privilege_escalation': 'critical'
        };
        
        return severityMap[type] || 'low';
    }
    
    findInactiveUsers() {
        const cutoffDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days
        const inactiveUsers = [];
        
        for (const user of this.userDatabase.values()) {
            if (!user.lastLogin || new Date(user.lastLogin) < cutoffDate) {
                inactiveUsers.push(user);
            }
        }
        
        return inactiveUsers;
    }
    
    shouldSuspendUser(user) {
        const cutoffDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000); // 90 days
        return !user.lastLogin || new Date(user.lastLogin) < cutoffDate;
    }
    
    async suspendUser(userId, reason) {
        const user = this.userDatabase.get(userId);
        if (!user) return;
        
        user.status = 'suspended';
        user.suspensionReason = reason;
        user.suspendedAt = new Date().toISOString();
        user.updatedAt = new Date().toISOString();
        
        await this.logAuditEvent('user:suspended', userId, { reason });
        this.emit('user:suspended', user);
    }
    
    async cleanupOldData() {
        const cutoffDate = new Date(Date.now() - this.config.dataRetentionDays * 24 * 60 * 60 * 1000);
        
        // ניקוי לוג ביקורת ישן
        this.auditLog = this.auditLog.filter(entry => new Date(entry.timestamp) > cutoffDate);
        
        // ניקוי פעילויות משתמשים ישנות
        for (const [userId, activities] of this.userActivities.entries()) {
            const filteredActivities = activities.filter(activity => new Date(activity.timestamp) > cutoffDate);
            this.userActivities.set(userId, filteredActivities);
        }
        
        console.log('🧹 Old data cleanup completed');
    }
    
    startPeriodicMonitoring() {
        // ניטור כל דקה
        setInterval(() => {
            this.manageUserLifecycle();
        }, 60000);
        
        // ניקוי נתונים יומי
        setInterval(() => {
            this.cleanupOldData();
        }, 24 * 60 * 60 * 1000);
        
        // דיווח סטטוס כל שעה
        setInterval(() => {
            const analytics = this.generateUserAnalytics();
            this.emit('system:analytics', analytics);
            console.log('📊 User Management Analytics:', analytics);
        }, 60 * 60 * 1000);
    }
    
    /**
     * אתחול SSO
     * Initialize Single Sign-On
     */
    async initializeSSO(provider, config) {
        // הגדרת ספק SSO (Google, Microsoft, etc.)
        this.ssoProviders = this.ssoProviders || {};
        this.ssoProviders[provider] = config;
        
        console.log(`🔐 SSO provider ${provider} initialized`);
    }
    
    /**
     * הפעלת חשבון משתמש
     * Activate user account
     */
    async activateUser(activationToken) {
        try {
            const decoded = jwt.verify(activationToken, this.config.jwtSecret);
            const user = this.userDatabase.get(decoded.userId);
            
            if (!user) {
                throw new Error('User not found');
            }
            
            if (user.status === 'active') {
                throw new Error('User already activated');
            }
            
            user.status = 'active';
            user.activatedAt = new Date().toISOString();
            user.updatedAt = new Date().toISOString();
            
            await this.logAuditEvent('user:activated', user.id);
            this.emit('user:activated', user);
            
            return { success: true, user: this.sanitizeUserData(user) };
            
        } catch (error) {
            throw new Error('Invalid activation token');
        }
    }
    
    /**
     * יציאה מהמערכת
     * Logout user
     */
    async logout(sessionId) {
        try {
            const session = this.sessionStore.get(sessionId);
            if (!session) {
                throw new Error('Session not found');
            }
            
            session.active = false;
            session.loggedOutAt = new Date().toISOString();
            
            // הסרה מ-Redis
            await this.redisClient.del(`session:${sessionId}`);
            
            // הסרה מרשימת משתמשים פעילים
            this.activeUsers.delete(session.userId);
            
            await this.logAuditEvent('user:logout', session.userId);
            
            return { success: true };
            
        } catch (error) {
            throw error;
        }
    }
    
    /**
     * קבלת פרופיל משתמש
     * Get user profile
     */
    async getUserProfile(userId) {
        const user = this.userDatabase.get(userId);
        if (!user) {
            throw new Error('User not found');
        }
        
        return this.sanitizeUserData(user);
    }
    
    /**
     * עדכון פרופיל משתמש
     * Update user profile
     */
    async updateUserProfile(userId, updates) {
        const user = this.userDatabase.get(userId);
        if (!user) {
            throw new Error('User not found');
        }
        
        // ולידציה של העדכונים
        const allowedFields = ['firstName', 'lastName', 'preferences', 'metadata'];
        const validUpdates = {};
        
        for (const field of allowedFields) {
            if (updates[field] !== undefined) {
                validUpdates[field] = updates[field];
            }
        }
        
        // עדכון הנתונים
        Object.assign(user, validUpdates);
        user.updatedAt = new Date().toISOString();
        
        await this.logAuditEvent('user:profile_updated', userId, validUpdates);
        
        return this.sanitizeUserData(user);
    }
    
    /**
     * השמדת מערכת ניהול המשתמשים
     * Destroy user management system
     */
    async destroy() {
        try {
            // סגירת חיבור Redis
            if (this.redisClient) {
                await this.redisClient.quit();
            }
            
            // סגירת חיבור LDAP
            if (this.ldapClient) {
                this.ldapClient.destroy();
            }
            
            // ניקוי נתונים
            this.userDatabase.clear();
            this.sessionStore.clear();
            this.auditLog.length = 0;
            this.rateLimitStore.clear();
            this.activeUsers.clear();
            this.userActivities.clear();
            
            console.log('🔒 Enterprise User Management System destroyed');
            
        } catch (error) {
            console.error('❌ Error destroying user management system:', error);
        }
    }
}

// יצוא המחלקה
export default EnterpriseUserManagement;

// שימוש לדוגמה
export const createUserManagementSystem = (config) => {
    return new EnterpriseUserManagement(config);
};

/**
 * דוגמה לשימוש במערכת
 * Usage example
 */
if (typeof window === 'undefined' && require.main === module) {
    // הרצה כמודול עצמאי
    const userManager = new EnterpriseUserManagement({
        jwtSecret: 'your-super-secret-key',
        mfaRequired: true,
        ldapEnabled: false,
        gdprCompliance: true
    });
    
    console.log('🚀 Effi-AI Enterprise User Management System started');
}