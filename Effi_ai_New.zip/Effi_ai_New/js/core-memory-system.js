/**
 * 🧠 Effi-AI Core Memory System
 * זיכרון חי מתקדם - הליבה של התפתחות המודל
 * מערכת למידה מתמדת עם יכולות אינטליגנטיות
 */

class EffiCoreMemory {
    constructor() {
        this.memoryStore = new Map();
        this.learningPatterns = new Map();
        this.adaptiveThresholds = new Map();
        this.performanceMetrics = new Map();
        this.eventHistory = [];
        this.contextualMemory = new Map();
        this.predictionEngine = new Map();
        
        // מונטי זיכרון ותפוסה
        this.memoryUsage = {
            current: 0,
            peak: 0,
            allocated: 100 * 1024 * 1024, // 100MB initial
            efficiency: 100
        };
        
        // הגדרות למידה
        this.learningConfig = {
            adaptationRate: 0.1,
            retentionThreshold: 0.8,
            contextWindow: 1000,
            predictionAccuracy: 0.85,
            autoOptimization: true
        };
        
        this.initializeMemorySystem();
    }

    /**
     * אתחול מערכת הזיכרון
     */
    initializeMemorySystem() {
        console.log('🧠 Initializing Advanced Memory System...');
        
        // טעינת זיכרון קיים
        this.loadPersistedMemory();
        
        // הפעלת מנועי למידה
        this.startLearningEngines();
        
        // ניטור ביצועים
        this.startPerformanceMonitoring();
        
        // אופטימיזציה אוטומטית
        this.startAutoOptimization();
        
        console.log('✅ Memory System Active - Learning Mode Enabled');
    }

    /**
     * למידה מאירוע או אינטראקציה
     */
    learn(event, context = {}) {
        const timestamp = Date.now();
        const memoryKey = this.generateMemoryKey(event, context);
        
        // שמירת האירוע
        const memoryItem = {
            event,
            context,
            timestamp,
            frequency: 1,
            importance: this.calculateImportance(event, context),
            associations: this.findAssociations(event, context),
            predictiveValue: this.calculatePredictiveValue(event)
        };

        // עדכון או יצירת זיכרון
        if (this.memoryStore.has(memoryKey)) {
            const existing = this.memoryStore.get(memoryKey);
            existing.frequency++;
            existing.lastAccessed = timestamp;
            existing.importance = this.updateImportance(existing);
            this.updateAssociations(existing, context);
        } else {
            this.memoryStore.set(memoryKey, memoryItem);
        }

        // הוספה להיסטוריה
        this.eventHistory.push({
            key: memoryKey,
            timestamp,
            type: 'learn'
        });

        // עדכון דפוסי למידה
        this.updateLearningPatterns(event, context);
        
        // אופטימיזציה אוטומטית
        if (this.shouldOptimize()) {
            this.optimize();
        }

        this.updatePerformanceMetrics('learn', timestamp);
        return memoryKey;
    }

    /**
     * אחזור זיכרון חכם עם הקשר
     */
    recall(query, context = {}) {
        const startTime = performance.now();
        
        // חיפוש ישיר
        const directMatch = this.findDirectMatch(query);
        if (directMatch) {
            this.updateAccessPattern(directMatch);
            return this.enhanceRecall(directMatch, context);
        }

        // חיפוש אסוציאטיבי
        const associativeMatches = this.findAssociativeMatches(query, context);
        
        // חיפוש דפוסים
        const patternMatches = this.findPatternMatches(query, context);
        
        // חיפוש הקשרי
        const contextualMatches = this.findContextualMatches(query, context);

        // איחוד ודירוג תוצאות
        const allMatches = [
            ...associativeMatches,
            ...patternMatches,
            ...contextualMatches
        ];

        const rankedResults = this.rankResults(allMatches, query, context);
        
        // עדכון מטריקות
        const endTime = performance.now();
        this.updatePerformanceMetrics('recall', endTime - startTime);
        
        return rankedResults;
    }

    /**
     * חיזוי מבוסס זיכרון
     */
    predict(scenario, confidence = 0.8) {
        const relevantMemories = this.findRelevantMemories(scenario);
        const patterns = this.analyzePredictivePatterns(relevantMemories);
        
        const predictions = patterns.map(pattern => ({
            scenario: pattern.nextLikelyEvent,
            confidence: pattern.confidence,
            reasoning: pattern.reasoning,
            supportingMemories: pattern.supportingMemories
        })).filter(pred => pred.confidence >= confidence);

        return predictions.sort((a, b) => b.confidence - a.confidence);
    }

    /**
     * אופטימיזציה אוטומטית של הזיכרון
     */
    optimize() {
        console.log('🔧 Running Memory Optimization...');
        
        // ניקוי זיכרונות לא רלוונטיים
        this.cleanupLowValueMemories();
        
        // דחיסת זיכרונות דומים
        this.compressSimilarMemories();
        
        // אופטימיזציה של אינדקסים
        this.optimizeIndexes();
        
        // עדכון סדרי עדיפויות
        this.updatePriorities();
        
        // דיווח על שיפור
        const beforeSize = this.memoryUsage.current;
        this.updateMemoryUsage();
        const improvement = ((beforeSize - this.memoryUsage.current) / beforeSize) * 100;
        
        console.log(`✅ Optimization Complete - ${improvement.toFixed(1)}% improvement`);
        
        return {
            improvement,
            memoryFreed: beforeSize - this.memoryUsage.current,
            efficiency: this.memoryUsage.efficiency
        };
    }

    /**
     * מערכת למידה אדפטיבית
     */
    adaptToUsage() {
        // ניתוח דפוסי שימוש
        const usagePatterns = this.analyzeUsagePatterns();
        
        // התאמת פרמטרים
        this.adaptLearningRate(usagePatterns);
        this.adaptRetentionThreshold(usagePatterns);
        this.adaptContextWindow(usagePatterns);
        
        // עדכון אלגוריתמי חיזוי
        this.updatePredictionAlgorithms(usagePatterns);
        
        return usagePatterns;
    }

    /**
     * יצוא וייבוא זיכרון
     */
    exportMemory(format = 'json') {
        const memoryExport = {
            version: '1.0',
            timestamp: Date.now(),
            memory: Array.from(this.memoryStore.entries()),
            patterns: Array.from(this.learningPatterns.entries()),
            metrics: Array.from(this.performanceMetrics.entries()),
            config: this.learningConfig
        };

        switch (format) {
            case 'json':
                return JSON.stringify(memoryExport, null, 2);
            case 'binary':
                return this.encodeToBinary(memoryExport);
            case 'compressed':
                return this.compressMemory(memoryExport);
            default:
                return memoryExport;
        }
    }

    importMemory(data, format = 'json') {
        try {
            let memoryData;
            
            switch (format) {
                case 'json':
                    memoryData = JSON.parse(data);
                    break;
                case 'binary':
                    memoryData = this.decodeFromBinary(data);
                    break;
                case 'compressed':
                    memoryData = this.decompressMemory(data);
                    break;
                default:
                    memoryData = data;
            }

            // שחזור זיכרון
            this.memoryStore = new Map(memoryData.memory);
            this.learningPatterns = new Map(memoryData.patterns);
            this.performanceMetrics = new Map(memoryData.metrics);
            
            if (memoryData.config) {
                this.learningConfig = { ...this.learningConfig, ...memoryData.config };
            }

            console.log('✅ Memory imported successfully');
            return true;
        } catch (error) {
            console.error('❌ Memory import failed:', error);
            return false;
        }
    }

    // === PRIVATE METHODS ===

    generateMemoryKey(event, context) {
        const contextHash = this.hashContext(context);
        return `${event.type || 'event'}_${event.id || Date.now()}_${contextHash}`;
    }

    calculateImportance(event, context) {
        let importance = 0.5; // בסיס

        // חשיבות לפי תדירות
        if (event.frequency) importance += Math.min(event.frequency * 0.1, 0.3);
        
        // חשיבות לפי הקשר
        if (context.user) importance += 0.2;
        if (context.system) importance += 0.1;
        if (context.performance) importance += 0.15;
        
        // חשיבות לפי סוג אירוע
        const eventWeights = {
            'error': 0.9,
            'success': 0.7,
            'user_action': 0.8,
            'system_event': 0.6,
            'optimization': 0.85
        };
        
        const eventType = event.type || 'default';
        importance *= (eventWeights[eventType] || 0.5);
        
        return Math.min(Math.max(importance, 0), 1);
    }

    findAssociations(event, context) {
        const associations = [];
        
        // חיפוש אירועים דומים
        for (const [key, memory] of this.memoryStore) {
            const similarity = this.calculateSimilarity(event, memory.event);
            if (similarity > 0.7) {
                associations.push({
                    key,
                    similarity,
                    type: 'similar_event'
                });
            }
        }

        // חיפוש הקשרים דומים
        for (const [key, memory] of this.memoryStore) {
            const contextSimilarity = this.calculateContextSimilarity(context, memory.context);
            if (contextSimilarity > 0.6) {
                associations.push({
                    key,
                    similarity: contextSimilarity,
                    type: 'similar_context'
                });
            }
        }

        return associations.sort((a, b) => b.similarity - a.similarity).slice(0, 10);
    }

    calculateSimilarity(event1, event2) {
        // חישוב דמיון בין אירועים
        let similarity = 0;
        
        if (event1.type === event2.type) similarity += 0.4;
        if (event1.category === event2.category) similarity += 0.3;
        if (event1.module === event2.module) similarity += 0.2;
        
        // דמיון בתוכן
        if (event1.data && event2.data) {
            const dataKeys1 = Object.keys(event1.data);
            const dataKeys2 = Object.keys(event2.data);
            const commonKeys = dataKeys1.filter(key => dataKeys2.includes(key));
            similarity += (commonKeys.length / Math.max(dataKeys1.length, dataKeys2.length)) * 0.1;
        }
        
        return similarity;
    }

    startLearningEngines() {
        // מנוע למידה ראשי
        setInterval(() => {
            this.adaptToUsage();
        }, 30000); // כל 30 שניות

        // מנוע אופטימיזציה
        setInterval(() => {
            if (this.shouldOptimize()) {
                this.optimize();
            }
        }, 300000); // כל 5 דקות

        // מנוע חיזוי
        setInterval(() => {
            this.updatePredictionModels();
        }, 60000); // כל דקה
    }

    startPerformanceMonitoring() {
        setInterval(() => {
            this.updateMemoryUsage();
            this.monitorPerformance();
            this.logMemoryStats();
        }, 5000); // כל 5 שניות
    }

    startAutoOptimization() {
        setInterval(() => {
            if (this.learningConfig.autoOptimization) {
                this.performAutoOptimization();
            }
        }, 60000); // כל דקה
    }

    loadPersistedMemory() {
        try {
            const savedMemory = localStorage.getItem('effi-core-memory');
            if (savedMemory) {
                this.importMemory(savedMemory);
                console.log('✅ Persisted memory loaded');
            }
        } catch (error) {
            console.warn('⚠️ Could not load persisted memory:', error);
        }
    }

    saveMemoryToPersistence() {
        try {
            const memoryData = this.exportMemory();
            localStorage.setItem('effi-core-memory', memoryData);
        } catch (error) {
            console.error('❌ Could not save memory:', error);
        }
    }

    updateMemoryUsage() {
        // חישוב שימוש בזיכרון
        const currentUsage = this.memoryStore.size * 1024; // קירוב
        this.memoryUsage.current = currentUsage;
        
        if (currentUsage > this.memoryUsage.peak) {
            this.memoryUsage.peak = currentUsage;
        }
        
        this.memoryUsage.efficiency = 
            ((this.memoryUsage.allocated - currentUsage) / this.memoryUsage.allocated) * 100;
    }

    shouldOptimize() {
        return this.memoryUsage.efficiency < 50 || 
               this.memoryStore.size > 10000 ||
               Date.now() - this.lastOptimization > 300000; // 5 דקות
    }

    hashContext(context) {
        return btoa(JSON.stringify(context)).substring(0, 8);
    }

    updatePerformanceMetrics(operation, duration) {
        const key = `${operation}_performance`;
        const existing = this.performanceMetrics.get(key) || { count: 0, totalTime: 0, avgTime: 0 };
        
        existing.count++;
        existing.totalTime += duration;
        existing.avgTime = existing.totalTime / existing.count;
        
        this.performanceMetrics.set(key, existing);
    }

    // === MISSING FUNCTIONS IMPLEMENTATION ===

    /**
     * יצוא נתוני זיכרון
     */
    exportMemoryData(format = 'json') {
        console.log('📤 Exporting memory data...');
        
        const exportData = {
            version: '1.0.0',
            timestamp: Date.now(),
            memoryStore: Array.from(this.memoryStore.entries()),
            learningPatterns: Array.from(this.learningPatterns.entries()),
            performanceMetrics: Array.from(this.performanceMetrics.entries()),
            memoryUsage: this.memoryUsage,
            learningConfig: this.learningConfig,
            totalMemories: this.memoryStore.size
        };

        if (format === 'json') {
            return JSON.stringify(exportData, null, 2);
        } else if (format === 'csv') {
            return this.convertToCSV(exportData);
        } else if (format === 'xml') {
            return this.convertToXML(exportData);
        }
        
        return exportData;
    }

    /**
     * יבוא נתוני זיכרון
     */
    importMemoryData(data, options = {}) {
        console.log('📥 Importing memory data...');
        
        try {
            const importData = typeof data === 'string' ? JSON.parse(data) : data;
            
            if (!options.merge) {
                // איפוס זיכרון קיים
                this.memoryStore.clear();
                this.learningPatterns.clear();
                this.performanceMetrics.clear();
            }
            
            // יבוא זיכרונות
            if (importData.memoryStore) {
                for (const [key, value] of importData.memoryStore) {
                    this.memoryStore.set(key, value);
                }
            }
            
            // יבוא דפוסי למידה
            if (importData.learningPatterns) {
                for (const [key, value] of importData.learningPatterns) {
                    this.learningPatterns.set(key, value);
                }
            }
            
            // יבוא מטריקות
            if (importData.performanceMetrics) {
                for (const [key, value] of importData.performanceMetrics) {
                    this.performanceMetrics.set(key, value);
                }
            }
            
            // עדכון קונפיגורציה
            if (importData.learningConfig && options.updateConfig) {
                this.learningConfig = { ...this.learningConfig, ...importData.learningConfig };
            }
            
            console.log(`✅ Successfully imported ${this.memoryStore.size} memories`);
            return { success: true, memoriesImported: this.memoryStore.size };
            
        } catch (error) {
            console.error('❌ Failed to import memory data:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * ניקוי היסטוריית זיכרון
     */
    clearMemoryHistory(options = {}) {
        console.log('🗑️ Clearing memory history...');
        
        const beforeCount = this.memoryStore.size;
        
        if (options.all) {
            // ניקוי מוחלט
            this.memoryStore.clear();
            this.learningPatterns.clear();
            this.eventHistory = [];
            this.contextualMemory.clear();
            this.predictionEngine.clear();
        } else {
            // ניקוי סלקטיבי
            if (options.oldMemories) {
                const cutoffTime = Date.now() - (options.maxAge || 30 * 24 * 60 * 60 * 1000); // 30 ימים
                for (const [key, memory] of this.memoryStore) {
                    if (memory.timestamp < cutoffTime) {
                        this.memoryStore.delete(key);
                    }
                }
            }
            
            if (options.lowImportance) {
                for (const [key, memory] of this.memoryStore) {
                    if (memory.importance < (options.importanceThreshold || 0.3)) {
                        this.memoryStore.delete(key);
                    }
                }
            }
            
            if (options.infrequent) {
                for (const [key, memory] of this.memoryStore) {
                    if (memory.frequency < (options.frequencyThreshold || 2)) {
                        this.memoryStore.delete(key);
                    }
                }
            }
        }
        
        const afterCount = this.memoryStore.size;
        const cleared = beforeCount - afterCount;
        
        console.log(`✅ Cleared ${cleared} memories (${beforeCount} → ${afterCount})`);
        
        // עדכון שימוש בזיכרון
        this.updateMemoryUsage();
        
        return {
            memoriesCleared: cleared,
            memoriesRemaining: afterCount,
            efficiency: this.memoryUsage.efficiency
        };
    }

    /**
     * המרה ל-CSV
     */
    convertToCSV(data) {
        const memories = data.memoryStore;
        let csv = 'Key,Event,Context,Timestamp,Frequency,Importance\n';
        
        for (const [key, memory] of memories) {
            const event = JSON.stringify(memory.event).replace(/"/g, '""');
            const context = JSON.stringify(memory.context).replace(/"/g, '""');
            csv += `"${key}","${event}","${context}",${memory.timestamp},${memory.frequency},${memory.importance}\n`;
        }
        
        return csv;
    }

    /**
     * המרה ל-XML
     */
    convertToXML(data) {
        let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<MemoryExport>\n';
        xml += `  <Metadata>\n`;
        xml += `    <Version>${data.version}</Version>\n`;
        xml += `    <Timestamp>${data.timestamp}</Timestamp>\n`;
        xml += `    <TotalMemories>${data.totalMemories}</TotalMemories>\n`;
        xml += `  </Metadata>\n`;
        
        xml += '  <Memories>\n';
        for (const [key, memory] of data.memoryStore) {
            xml += `    <Memory key="${key}">\n`;
            xml += `      <Event><![CDATA[${JSON.stringify(memory.event)}]]></Event>\n`;
            xml += `      <Context><![CDATA[${JSON.stringify(memory.context)}]]></Context>\n`;
            xml += `      <Timestamp>${memory.timestamp}</Timestamp>\n`;
            xml += `      <Frequency>${memory.frequency}</Frequency>\n`;
            xml += `      <Importance>${memory.importance}</Importance>\n`;
            xml += `    </Memory>\n`;
        }
        xml += '  </Memories>\n';
        xml += '</MemoryExport>';
        
        return xml;
    }

    /**
     * סטטיסטיקות זיכרון מפורטות
     */
    getDetailedMemoryStats() {
        const stats = {
            overview: {
                totalMemories: this.memoryStore.size,
                memoryUsage: this.memoryUsage,
                learningPatterns: this.learningPatterns.size,
                eventHistory: this.eventHistory.length,
                lastOptimization: this.lastOptimization
            },
            
            memories: {
                byImportance: this.getMemoriesByImportance(),
                byFrequency: this.getMemoriesByFrequency(),
                byAge: this.getMemoriesByAge(),
                byType: this.getMemoriesByType()
            },
            
            performance: {
                metrics: Array.from(this.performanceMetrics.entries()),
                learningConfig: this.learningConfig,
                systemHealth: this.calculateSystemHealth()
            },
            
            predictions: {
                accuracy: this.calculatePredictionAccuracy(),
                patterns: this.getTopPredictivePatterns(),
                confidence: this.getAverageConfidence()
            }
        };
        
        return stats;
    }

    /**
     * חישוב בריאות המערכת
     */
    calculateSystemHealth() {
        const memoryEfficiency = this.memoryUsage.efficiency / 100;
        const learningRate = this.learningPatterns.size / Math.max(this.memoryStore.size, 1);
        const performanceScore = this.getAveragePerformanceScore();
        
        return {
            overall: (memoryEfficiency + learningRate + performanceScore) / 3,
            memory: memoryEfficiency,
            learning: learningRate,
            performance: performanceScore
        };
    }

    /**
     * ניתוח זיכרונות לפי חשיבות
     */
    getMemoriesByImportance() {
        const importanceRanges = { high: 0, medium: 0, low: 0 };
        
        for (const memory of this.memoryStore.values()) {
            if (memory.importance > 0.7) importanceRanges.high++;
            else if (memory.importance > 0.4) importanceRanges.medium++;
            else importanceRanges.low++;
        }
        
        return importanceRanges;
    }

    /**
     * ניתוח זיכרונות לפי תדירות
     */
    getMemoriesByFrequency() {
        const frequencyRanges = { frequent: 0, occasional: 0, rare: 0 };
        
        for (const memory of this.memoryStore.values()) {
            if (memory.frequency > 10) frequencyRanges.frequent++;
            else if (memory.frequency > 3) frequencyRanges.occasional++;
            else frequencyRanges.rare++;
        }
        
        return frequencyRanges;
    }

    /**
     * ניתוח זיכרונות לפי גיל
     */
    getMemoriesByAge() {
        const now = Date.now();
        const ageRanges = { recent: 0, medium: 0, old: 0 };
        
        for (const memory of this.memoryStore.values()) {
            const age = now - memory.timestamp;
            const hours = age / (1000 * 60 * 60);
            
            if (hours < 24) ageRanges.recent++;
            else if (hours < 168) ageRanges.medium++; // שבוע
            else ageRanges.old++;
        }
        
        return ageRanges;
    }

    /**
     * ניתוח זיכרונות לפי סוג
     */
    getMemoriesByType() {
        const typeStats = {};
        
        for (const memory of this.memoryStore.values()) {
            const type = memory.event.type || 'unknown';
            typeStats[type] = (typeStats[type] || 0) + 1;
        }
        
        return typeStats;
    }
}

// יצירת מופע גלובלי של מערכת הזיכרון
window.EffiMemory = new EffiCoreMemory();

// שמירה אוטומטית
setInterval(() => {
    if (window.EffiMemory && window.EffiMemory.saveMemoryToPersistence) {
        window.EffiMemory.saveMemoryToPersistence();
    }
}, 30000); // כל 30 שניות

// שמירה בסגירת הדף
window.addEventListener('beforeunload', () => {
    if (window.EffiMemory && window.EffiMemory.saveMemoryToPersistence) {
        window.EffiMemory.saveMemoryToPersistence();
    }
});

console.log('🧠 Effi Core Memory System Loaded - Ready for Learning!');