/**
 * 🏛️ מערכת ניווט ממשלתית - Effi-AI Government
 * 4 כפתורי ניווט קבועים + אופטימיזציית ביצועים
 * 
 * Version: 2.0.0
 * Performance Optimized: ✅
 * Government Grade: ✅
 */

class GovernmentNavigation {
    constructor() {
        this.currentEngine = 'private'; // ברירת מחדל תמיד
        this.performance = {
            loadTime: 0,
            renderTime: 0,
            errors: []
        };
        
        this.init();
    }

    /**
     * אתחול מערכת הניווט
     */
    init() {
        const startTime = performance.now();
        
        try {
            this.createNavigationButtons();
            this.createEngineSelector();
            this.setupPerformanceMonitoring();
            this.setupGlobalEventListeners();
            this.optimizePageLoad();
            
            this.performance.loadTime = performance.now() - startTime;
            console.log(`🏛️ ניווט ממשלתי הוטען ב-${this.performance.loadTime.toFixed(2)}ms`);
            
        } catch (error) {
            this.performance.errors.push(error);
            console.error('❌ שגיאה באתחול הניווט:', error);
        }
    }

    /**
     * יצירת 4 כפתורי הניווט הקבועים
     */
    createNavigationButtons() {
        // בדיקה אם כבר קיימים
        if (document.querySelector('.government-nav')) return;

        const nav = document.createElement('div');
        nav.className = 'government-nav';
        nav.innerHTML = `
            <button class="nav-btn back" onclick="history.back()" title="חזור">
                ↩️
            </button>
            <button class="nav-btn home" onclick="window.location.href='/pages/index.html'" title="דף הבית">
                🏠
            </button>
            <button class="nav-btn settings" onclick="window.location.href='/pages/unified_settings.html'" title="הגדרות">
                ⚙️
            </button>
            <button class="nav-btn system" onclick="window.location.href='/pages/dashboard_advanced.html'" title="מרכז המערכת">
                🎛️
            </button>
        `;

        // הוספה לראש הדף
        document.body.appendChild(nav);

        // הוספת אנימציית כניסה
        setTimeout(() => {
            nav.classList.add('page-enter');
        }, 100);
    }

    /**
     * יצירת בורר המנועים (מנוע פרטי ראשון תמיד)
     */
    createEngineSelector() {
        // חיפוש אחר בורר מנועים קיים
        let engineSelector = document.querySelector('.engine-selector');
        
        if (!engineSelector) {
            // יצירת בורר חדש אם לא קיים
            engineSelector = document.createElement('div');
            engineSelector.className = 'engine-selector';
            
            // הוספה לראש הדף
            const header = document.querySelector('header, .header, .main-header, .settings-header') || document.body;
            header.appendChild(engineSelector);
        }

        // עדכון התוכן עם מנוע פרטי ראשון
        engineSelector.innerHTML = `
            <button class="engine-btn active" data-engine="private">
                🏠 מנוע פרטי (ללא הגבלות)
            </button>
            <button class="engine-btn" data-engine="commercial">
                🏢 מנוע מסחרי
            </button>
            <button class="engine-btn" data-engine="python">
                🐍 Python מקומי
            </button>
        `;

        // הוספת פונקציונליות
        this.setupEngineSelector(engineSelector);
    }

    /**
     * הגדרת בורר המנועים
     */
    setupEngineSelector(engineSelector) {
        const buttons = engineSelector.querySelectorAll('.engine-btn');
        
        buttons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                // עדכון כפתור פעיל
                buttons.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                
                // עדכון המנוע הנוכחי
                this.currentEngine = e.target.dataset.engine;
                
                // התראה על שינוי מנוע
                this.showEngineChangeNotification(this.currentEngine);
                
                // עדכון כל המערכות
                this.updateGlobalEngine(this.currentEngine);
                
                console.log(`🔄 מעבר למנוע: ${this.currentEngine}`);
            });
        });
    }

    /**
     * התראה על שינוי מנוע
     */
    showEngineChangeNotification(engine) {
        const engineNames = {
            'private': '🏠 מנוע פרטי (ללא הגבלות)',
            'commercial': '🏢 מנוע מסחרי', 
            'python': '🐍 Python מקומי'
        };

        // יצירת התראה
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: linear-gradient(145deg, #4ade80 0%, #22c55e 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 12px;
            font-weight: bold;
            z-index: 10001;
            box-shadow: 0 8px 25px rgba(74, 222, 128, 0.4);
            animation: slideInRight 0.5s ease-out;
            backdrop-filter: blur(10px);
        `;
        notification.textContent = `עברת ל${engineNames[engine]}`;

        document.body.appendChild(notification);

        // הסרה אוטומטית
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.5s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        }, 3000);
    }

    /**
     * עדכון כל המערכות עם המנוע החדש
     */
    updateGlobalEngine(engine) {
        // עדכון משתנה גלובלי
        if (window.currentEngine !== undefined) {
            window.currentEngine = engine;
        }

        // שליחת אירוע לכל הרכיבים
        const event = new CustomEvent('engineChanged', {
            detail: { engine: engine }
        });
        document.dispatchEvent(event);

        // עדכון localStorage לזכירה
        localStorage.setItem('selectedEngine', engine);
    }

    /**
     * מעקב ביצועים בזמן אמת
     */
    setupPerformanceMonitoring() {
        // מעקב אחר טעינת הדף
        window.addEventListener('load', () => {
            this.performance.renderTime = performance.now();
            this.checkPerformance();
        });

        // מעקב אחר שגיאות JavaScript
        window.addEventListener('error', (error) => {
            this.performance.errors.push({
                message: error.message,
                filename: error.filename,
                lineno: error.lineno,
                timestamp: new Date().toISOString()
            });
            
            console.warn('⚠️ שגיאת JavaScript זוהתה:', error.message);
            this.reportPerformanceIssue('JavaScript Error', error.message);
        });

        // מעקב אחר שגיאות Promise
        window.addEventListener('unhandledrejection', (error) => {
            this.performance.errors.push({
                message: error.reason,
                type: 'Promise Rejection',
                timestamp: new Date().toISOString()
            });
            
            console.warn('⚠️ Promise לא מטופל:', error.reason);
        });
    }

    /**
     * בדיקת ביצועים
     */
    checkPerformance() {
        const navigation = performance.getEntriesByType('navigation')[0];
        const paintEntries = performance.getEntriesByType('paint');
        
        const metrics = {
            pageLoad: navigation.loadEventEnd - navigation.loadEventStart,
            domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
            firstPaint: paintEntries.find(entry => entry.name === 'first-paint')?.startTime || 0,
            firstContentfulPaint: paintEntries.find(entry => entry.name === 'first-contentful-paint')?.startTime || 0,
            errors: this.performance.errors.length
        };

        console.log('📊 מטריקות ביצועים:', metrics);

        // התראה על ביצועים איטיים
        if (metrics.pageLoad > 3000) {
            this.reportPerformanceIssue('Slow Page Load', `${metrics.pageLoad.toFixed(2)}ms`);
        }

        if (metrics.firstContentfulPaint > 2000) {
            this.reportPerformanceIssue('Slow First Paint', `${metrics.firstContentfulPaint.toFixed(2)}ms`);
        }

        return metrics;
    }

    /**
     * דיווח על בעיית ביצועים
     */
    reportPerformanceIssue(type, details) {
        console.warn(`🐌 בעיית ביצועים: ${type} - ${details}`);
        
        // שליחה למערכת מעקב (לעתיד)
        if (window.EffiAnalytics) {
            window.EffiAnalytics.trackPerformanceIssue(type, details);
        }
    }

    /**
     * אופטימיזציית טעינת הדף
     */
    optimizePageLoad() {
        // Preload critical resources
        this.preloadCriticalResources();
        
        // Lazy load images
        this.setupLazyLoading();
        
        // Debounce scroll events
        this.optimizeScrollEvents();
        
        // Clean up unused event listeners
        this.cleanupEventListeners();
    }

    /**
     * טעינה מוקדמת של משאבים קריטיים
     */
    preloadCriticalResources() {
        const criticalResources = [
            '/css/government-navigation.css',
            '/css/performance-optimized.css',
            '/css/global-theme.css',
            '/js/modular-core.js',
            '/js/multi-engine-system.js'
        ];

        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.as = resource.endsWith('.css') ? 'style' : 'script';
            link.href = resource;
            document.head.appendChild(link);
        });
    }

    /**
     * הגדרת lazy loading לתמונות
     */
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        observer.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }

    /**
     * אופטימיזציית אירועי scroll
     */
    optimizeScrollEvents() {
        let ticking = false;
        
        const optimizedScroll = () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    // כאן אפשר להוסיף לוגיקה של scroll
                    ticking = false;
                });
                ticking = true;
            }
        };

        window.addEventListener('scroll', optimizedScroll, { passive: true });
    }

    /**
     * ניקוי event listeners לא בשימוש
     */
    cleanupEventListeners() {
        // יצירת WeakMap למעקב אחר listeners
        if (!window.effiEventListeners) {
            window.effiEventListeners = new WeakMap();
        }

        // פונקציה לניקוי אוטומטי
        const cleanup = () => {
            // כאן אפשר להוסיף לוגיקה לניקוי listeners לא בשימוש
        };

        // הפעלה כל 30 שניות
        setInterval(cleanup, 30000);
    }

    /**
     * הגדרת מאזינים גלובליים
     */
    setupGlobalEventListeners() {
        // מאזין לשינויי hash בכתובת
        window.addEventListener('hashchange', () => {
            console.log('🔄 ניווט hash changed:', window.location.hash);
        });

        // מאזין לשינויי visibility
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                console.log('👁️ דף הוסתר');
            } else {
                console.log('👁️ דף הוצג');
            }
        });

        // מאזין למקשי קיצור
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + Home = דף הבית
            if ((e.ctrlKey || e.metaKey) && e.key === 'Home') {
                e.preventDefault();
                window.location.href = '/pages/index.html';
            }
            
            // Ctrl/Cmd + , = הגדרות
            if ((e.ctrlKey || e.metaKey) && e.key === ',') {
                e.preventDefault();
                window.location.href = '/pages/unified_settings.html';
            }
        });
    }

    /**
     * הוספת כפתורים מורחבים לקטגוריות
     */
    addExpandedButtons(category, expandedPageUrl) {
        const buttons = document.querySelectorAll(`[data-category="${category}"] .control-buttons, [data-category="${category}"] .setting-buttons`);
        
        buttons.forEach(buttonContainer => {
            const expandBtn = document.createElement('button');
            expandBtn.className = 'control-btn expanded';
            expandBtn.innerHTML = '📋 הגדרות מורחבות';
            expandBtn.onclick = () => window.location.href = expandedPageUrl;
            
            buttonContainer.appendChild(expandBtn);
        });
    }

    /**
     * יצוא מטריקות ביצועים
     */
    exportPerformanceReport() {
        const report = {
            timestamp: new Date().toISOString(),
            page: window.location.pathname,
            performance: this.checkPerformance(),
            userAgent: navigator.userAgent,
            errors: this.performance.errors,
            engine: this.currentEngine
        };

        console.log('📊 דוח ביצועים מלא:', report);
        return report;
    }
}

// אתחול גלובלי
let governmentNav;

// הפעלה כשהדף נטען
document.addEventListener('DOMContentLoaded', () => {
    governmentNav = new GovernmentNavigation();
    
    // הוספת משתנה גלובלי
    window.EffiGovernmentNav = governmentNav;
    
    console.log('🏛️ מערכת ניווט ממשלתית הופעלה בהצלחה!');
});

// אנימציות CSS נוספות
const additionalStyles = `
@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOutRight {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

.expanded {
    background: linear-gradient(145deg, #8b5cf6 0%, #7c3aed 100%) !important;
}
`;

// הוספת הסטיילים לדף
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// יצוא לשימוש גלובלי
window.GovernmentNavigation = GovernmentNavigation;