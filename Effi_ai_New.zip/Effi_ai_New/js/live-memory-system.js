/**
 * Effi-AI Live Memory System
 * מערכת זיכרון חיה שלומדת מכל פעולה במערכת הממשלתית
 * Version: 1.0.0
 * Government Grade: ✅
 */

class EffiLiveMemorySystem {
    constructor() {
        this.memoryStore = new Map();
        this.userPatterns = new Map();
        this.systemLogs = [];
        this.learningModel = new Map();
        this.contextHistory = [];
        this.isInitialized = false;
        
        console.log('🧠 מאתחל מערכת זיכרון חיה ממשלתית...');
        this.init();
    }

    /**
     * אתחול מערכת הזיכרון
     */
    async init() {
        try {
            // טעינת זיכרון קיים
            await this.loadMemoryFromStorage();
            
            // הגדרת מאזיני אירועים
            this.setupEventListeners();
            
            // התחלת מעקב פעילות
            this.startActivityTracking();
            
            // רישום במערכת המודולרית
            if (window.EffiModular) {
                window.EffiModular.registerModule('live_memory', this, [], {
                    version: '1.0.0',
                    category: 'core',
                    priority: 'critical',
                    description: 'מערכת זיכרון חיה ולמידה'
                });
            }
            
            this.isInitialized = true;
            console.log('🧠 מערכת זיכרון חיה הופעלה בהצלחה!');
            
            // התחלת למידה
            this.startLearning();
            
            return true;
        } catch (error) {
            console.error('❌ שגיאה באתחול מערכת הזיכרון:', error);
            return false;
        }
    }

    /**
     * טעינת זיכרון מ-localStorage
     */
    async loadMemoryFromStorage() {
        try {
            // טעינת זיכרון כללי
            const memoryData = localStorage.getItem('effi-live-memory');
            if (memoryData) {
                const data = JSON.parse(memoryData);
                this.memoryStore = new Map(data.memory || []);
                this.userPatterns = new Map(data.patterns || []);
                this.systemLogs = data.logs || [];
                this.learningModel = new Map(data.learning || []);
                this.contextHistory = data.context || [];
                
                console.log('🧠 זיכרון נטען:', {
                    memories: this.memoryStore.size,
                    patterns: this.userPatterns.size,
                    logs: this.systemLogs.length,
                    context: this.contextHistory.length
                });
            }
            
            // טעינת היסטוריית שיחות
            const chatHistory = localStorage.getItem('effi-chat-memory');
            if (chatHistory) {
                const chats = JSON.parse(chatHistory);
                this.memorizeConversations(chats);
            }
            
        } catch (error) {
            console.error('❌ שגיאה בטעינת הזיכרון:', error);
        }
    }

    /**
     * שמירת זיכרון ל-localStorage
     */
    saveMemoryToStorage() {
        try {
            const memoryData = {
                memory: Array.from(this.memoryStore.entries()),
                patterns: Array.from(this.userPatterns.entries()),
                logs: this.systemLogs.slice(-1000), // שמירת 1000 הלוגים האחרונים
                learning: Array.from(this.learningModel.entries()),
                context: this.contextHistory.slice(-100), // שמירת 100 ההקשרים האחרונים
                lastSaved: Date.now()
            };
            
            localStorage.setItem('effi-live-memory', JSON.stringify(memoryData));
            console.log('💾 זיכרון נשמר למטמון מקומי');
            
        } catch (error) {
            console.error('❌ שגיאה בשמירת הזיכרון:', error);
        }
    }

    /**
     * הוספת זיכרון חדש
     */
    memorize(key, value, context = {}) {
        const memory = {
            value,
            context,
            timestamp: Date.now(),
            accessCount: 0,
            importance: this.calculateImportance(key, value, context),
            lastAccessed: Date.now()
        };
        
        this.memoryStore.set(key, memory);
        
        // הוספה להיסטוריית הקשר
        this.contextHistory.push({
            key,
            context,
            timestamp: Date.now()
        });
        
        // למידה מהזיכרון החדש
        this.learnFromMemory(key, value, context);
        
        // שמירה אוטומטית
        this.saveMemoryToStorage();
        
        console.log(`🧠 זיכרון חדש נוסף: ${key}`, memory);
    }

    /**
     * אחזור זיכרון
     */
    remember(key) {
        const memory = this.memoryStore.get(key);
        if (memory) {
            // עדכון סטטיסטיקות גישה
            memory.accessCount++;
            memory.lastAccessed = Date.now();
            memory.importance = Math.min(1.0, memory.importance + 0.1);
            
            this.memoryStore.set(key, memory);
            
            console.log(`🧠 זיכרון נזכר: ${key}`, memory.value);
            return memory.value;
        }
        
        return null;
    }

    /**
     * חיפוש זיכרונות דומים
     */
    findSimilarMemories(query, limit = 5) {
        const results = [];
        const queryWords = query.toLowerCase().split(' ');
        
        for (const [key, memory] of this.memoryStore) {
            let score = 0;
            const keyWords = key.toLowerCase().split(' ');
            const valueStr = JSON.stringify(memory.value).toLowerCase();
            
            // חיפוש מילות מפתח
            queryWords.forEach(word => {
                if (keyWords.some(kw => kw.includes(word))) score += 3;
                if (valueStr.includes(word)) score += 1;
            });
            
            // בונוס על חשיבות וגישה
            score += memory.importance * 2;
            score += Math.log(memory.accessCount + 1);
            
            if (score > 0) {
                results.push({ key, memory, score });
            }
        }
        
        return results
            .sort((a, b) => b.score - a.score)
            .slice(0, limit)
            .map(r => ({ key: r.key, value: r.memory.value, score: r.score }));
    }

    /**
     * למידה מפעולות משתמש
     */
    learnFromUserAction(action, context = {}) {
        const pattern = `${action}_${context.page || 'unknown'}`;
        
        // עדכון דפוסי משתמש
        const current = this.userPatterns.get(pattern) || { count: 0, contexts: [], lastSeen: 0 };
        current.count++;
        current.contexts.push(context);
        current.lastSeen = Date.now();
        
        // שמירת הקשרים רלוונטיים בלבד
        if (current.contexts.length > 10) {
            current.contexts = current.contexts.slice(-10);
        }
        
        this.userPatterns.set(pattern, current);
        
        // למידה מהדפוס
        this.updateLearningModel(action, context, current);
        
        // רישום פעילות
        this.logActivity('user_action', action, context);
        
        console.log(`📊 למידה מפעולה: ${action}`, current);
    }

    /**
     * עדכון מודל למידה
     */
    updateLearningModel(action, context, pattern) {
        const timeOfDay = new Date().getHours();
        const dayOfWeek = new Date().getDay();
        
        const features = {
            action,
            page: context.page || 'unknown',
            timeOfDay,
            dayOfWeek,
            frequency: pattern.count,
            recency: Date.now() - pattern.lastSeen
        };
        
        const modelKey = `${action}_model`;
        const model = this.learningModel.get(modelKey) || {
            patterns: [],
            predictions: new Map(),
            accuracy: 0
        };
        
        model.patterns.push(features);
        
        // שמירת דפוסים רלוונטיים בלבד
        if (model.patterns.length > 100) {
            model.patterns = model.patterns.slice(-100);
        }
        
        // עדכון תחזיות
        this.updatePredictions(model, features);
        
        this.learningModel.set(modelKey, model);
    }

    /**
     * עדכון תחזיות
     */
    updatePredictions(model, features) {
        // תחזית פשוטה בהתבסס על תדירות ושעה
        const timePattern = `${features.timeOfDay}_${features.dayOfWeek}`;
        const timePrediction = model.predictions.get(timePattern) || { score: 0, count: 0 };
        
        timePrediction.count++;
        timePrediction.score = (timePrediction.score + features.frequency) / 2;
        
        model.predictions.set(timePattern, timePrediction);
    }

    /**
     * תחזית פעולה הבאה
     */
    predictNextAction(currentContext = {}) {
        const timeOfDay = new Date().getHours();
        const dayOfWeek = new Date().getDay();
        const timePattern = `${timeOfDay}_${dayOfWeek}`;
        
        const predictions = [];
        
        for (const [modelKey, model] of this.learningModel) {
            const action = modelKey.replace('_model', '');
            const prediction = model.predictions.get(timePattern);
            
            if (prediction && prediction.score > 0) {
                predictions.push({
                    action,
                    score: prediction.score,
                    confidence: Math.min(1, prediction.count / 10)
                });
            }
        }
        
        return predictions
            .sort((a, b) => (b.score * b.confidence) - (a.score * a.confidence))
            .slice(0, 3);
    }

    /**
     * זכירת שיחות
     */
    memorizeConversations(conversations) {
        conversations.forEach(conv => {
            if (conv.sender === 'user') {
                this.memorize(`user_query_${Date.now()}`, conv.text, {
                    type: 'conversation',
                    engine: conv.engine,
                    agent: conv.agent,
                    timestamp: conv.timestamp
                });
            } else {
                this.memorize(`ai_response_${Date.now()}`, conv.text, {
                    type: 'ai_response',
                    engine: conv.engine,
                    agent: conv.agent,
                    timestamp: conv.timestamp
                });
            }
        });
    }

    /**
     * חישוב חשיבות זיכרון
     */
    calculateImportance(key, value, context) {
        let importance = 0.1; // חשיבות בסיסית
        
        // בונוס לפי סוג התוכן
        if (context.type === 'conversation') importance += 0.3;
        if (context.type === 'user_preference') importance += 0.5;
        if (context.type === 'security_event') importance += 0.9;
        if (context.type === 'system_error') importance += 0.7;
        
        // בונוס לפי אורך התוכן
        const contentLength = JSON.stringify(value).length;
        importance += Math.min(0.3, contentLength / 1000);
        
        // בונוס למילות מפתח חשובות
        const keyStr = key.toLowerCase();
        if (keyStr.includes('ממשלת') || keyStr.includes('אבטחה') || keyStr.includes('חירום')) {
            importance += 0.4;
        }
        
        return Math.min(1.0, importance);
    }

    /**
     * רישום פעילות
     */
    logActivity(type, action, context = {}) {
        const log = {
            type,
            action,
            context,
            timestamp: Date.now(),
            session: this.getSessionId()
        };
        
        this.systemLogs.push(log);
        
        // שמירת 1000 הלוגים האחרונים
        if (this.systemLogs.length > 1000) {
            this.systemLogs = this.systemLogs.slice(-1000);
        }
        
        // שמירה אוטומטית כל 10 לוגים
        if (this.systemLogs.length % 10 === 0) {
            this.saveMemoryToStorage();
        }
    }

    /**
     * קבלת מזהה סשן
     */
    getSessionId() {
        let sessionId = sessionStorage.getItem('effi-session-id');
        if (!sessionId) {
            sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            sessionStorage.setItem('effi-session-id', sessionId);
        }
        return sessionId;
    }

    /**
     * הגדרת מאזיני אירועים
     */
    setupEventListeners() {
        // מעקב אחר קליקים
        document.addEventListener('click', (e) => {
            const target = e.target.closest('button, a, [onclick]');
            if (target) {
                const action = target.textContent?.trim() || target.getAttribute('title') || 'click';
                this.learnFromUserAction('click', {
                    element: target.tagName.toLowerCase(),
                    text: action,
                    page: window.location.pathname,
                    time: Date.now()
                });
            }
        });

        // מעקב אחר שינויי דף
        let currentPage = window.location.pathname;
        const checkPageChange = () => {
            if (window.location.pathname !== currentPage) {
                this.learnFromUserAction('page_change', {
                    from: currentPage,
                    to: window.location.pathname,
                    time: Date.now()
                });
                currentPage = window.location.pathname;
            }
        };
        
        setInterval(checkPageChange, 1000);

        // מעקב אחר שדות טקסט
        document.addEventListener('input', (e) => {
            if (e.target.type === 'text' || e.target.type === 'textarea') {
                this.learnFromUserAction('text_input', {
                    element: e.target.name || e.target.id || 'unknown',
                    length: e.target.value.length,
                    page: window.location.pathname
                });
            }
        });

        // מעקב אחר שגיאות JavaScript
        window.addEventListener('error', (e) => {
            this.memorize(`error_${Date.now()}`, {
                message: e.message,
                filename: e.filename,
                lineno: e.lineno,
                colno: e.colno
            }, {
                type: 'system_error',
                severity: 'high'
            });
        });
    }

    /**
     * התחלת מעקב פעילות
     */
    startActivityTracking() {
        // מעקב זמן פעילות
        let isActive = true;
        let lastActivity = Date.now();
        
        const trackActivity = () => {
            if (isActive) {
                this.learnFromUserAction('session_active', {
                    duration: Date.now() - lastActivity,
                    page: window.location.pathname
                });
                lastActivity = Date.now();
            }
        };
        
        // איפוס זמן פעילות עם אינטראקציה
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, () => {
                lastActivity = Date.now();
                isActive = true;
            });
        });
        
        // זיהוי חוסר פעילות
        setInterval(() => {
            if (Date.now() - lastActivity > 60000) { // דקה של חוסר פעילות
                isActive = false;
            }
        }, 10000);
        
        // מעקב תקופתי
        setInterval(trackActivity, 30000); // כל 30 שניות
    }

    /**
     * התחלת למידה אוטומטית
     */
    startLearning() {
        // למידה תקופתית
        setInterval(() => {
            this.analyzePatternsAndLearn();
        }, 300000); // כל 5 דקות
        
        // שמירה תקופתית
        setInterval(() => {
            this.saveMemoryToStorage();
        }, 60000); // כל דקה
    }

    /**
     * ניתוח דפוסים ולמידה
     */
    analyzePatternsAndLearn() {
        console.log('🔍 מנתח דפוסים ולומד...');
        
        // ניתוח דפוסי זמן
        const timePatterns = this.analyzeTimePatterns();
        
        // ניתוח דפוסי ניווט
        const navigationPatterns = this.analyzeNavigationPatterns();
        
        // עדכון תחזיות
        this.updateGlobalPredictions(timePatterns, navigationPatterns);
        
        console.log('📊 ניתוח הושלם:', {
            timePatterns: timePatterns.length,
            navigationPatterns: navigationPatterns.length,
            totalMemories: this.memoryStore.size
        });
    }

    /**
     * ניתוח דפוסי זמן
     */
    analyzeTimePatterns() {
        const patterns = [];
        const hourlyActivity = new Map();
        
        this.systemLogs.forEach(log => {
            const hour = new Date(log.timestamp).getHours();
            const current = hourlyActivity.get(hour) || 0;
            hourlyActivity.set(hour, current + 1);
        });
        
        // מציאת שעות פעילות עיקריות
        for (const [hour, activity] of hourlyActivity) {
            if (activity > 5) { // סף מינימלי
                patterns.push({
                    type: 'time_pattern',
                    hour,
                    activity,
                    prediction: activity / Math.max(...hourlyActivity.values())
                });
            }
        }
        
        return patterns;
    }

    /**
     * ניתוח דפוסי ניווט
     */
    analyzeNavigationPatterns() {
        const patterns = [];
        const pageTransitions = new Map();
        
        let lastPage = null;
        this.systemLogs
            .filter(log => log.action === 'page_change')
            .forEach(log => {
                if (lastPage && log.context.to) {
                    const transition = `${lastPage} -> ${log.context.to}`;
                    const current = pageTransitions.get(transition) || 0;
                    pageTransitions.set(transition, current + 1);
                }
                lastPage = log.context.to;
            });
        
        // מציאת מעברים פופולריים
        for (const [transition, count] of pageTransitions) {
            if (count > 2) {
                patterns.push({
                    type: 'navigation_pattern',
                    transition,
                    count,
                    strength: count / Math.max(...pageTransitions.values())
                });
            }
        }
        
        return patterns;
    }

    /**
     * עדכון תחזיות גלובליות
     */
    updateGlobalPredictions(timePatterns, navigationPatterns) {
        // שמירת תחזיות למטמון
        const predictions = {
            timePatterns,
            navigationPatterns,
            nextActions: this.predictNextAction(),
            timestamp: Date.now()
        };
        
        localStorage.setItem('effi-predictions', JSON.stringify(predictions));
    }

    /**
     * קבלת סטטיסטיקות
     */
    getStats() {
        return {
            memories: this.memoryStore.size,
            patterns: this.userPatterns.size,
            logs: this.systemLogs.length,
            contexts: this.contextHistory.length,
            learningModels: this.learningModel.size,
            sessionId: this.getSessionId(),
            isInitialized: this.isInitialized,
            lastSaved: localStorage.getItem('effi-live-memory') ? 
                JSON.parse(localStorage.getItem('effi-live-memory')).lastSaved : null
        };
    }

    /**
     * איפוס זיכרון
     */
    resetMemory() {
        this.memoryStore.clear();
        this.userPatterns.clear();
        this.systemLogs = [];
        this.learningModel.clear();
        this.contextHistory = [];
        
        localStorage.removeItem('effi-live-memory');
        localStorage.removeItem('effi-predictions');
        
        console.log('🧠 זיכרון אופס בהצלחה');
    }

    /**
     * ייצוא זיכרון
     */
    exportMemory() {
        const exportData = {
            version: '1.0.0',
            exportDate: new Date().toISOString(),
            memories: Array.from(this.memoryStore.entries()),
            patterns: Array.from(this.userPatterns.entries()),
            logs: this.systemLogs,
            learning: Array.from(this.learningModel.entries()),
            context: this.contextHistory,
            stats: this.getStats()
        };
        
        return JSON.stringify(exportData, null, 2);
    }
}

// יצירת instance גלובלי
window.EffiLiveMemory = new EffiLiveMemorySystem();

// התחלה אוטומטית כאשר הדף נטען
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.EffiLiveMemory.init();
    });
} else {
    window.EffiLiveMemory.init();
}

// יצוא למודולים
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EffiLiveMemorySystem;
}

console.log('🧠 מערכת זיכרון חיה נטענה בהצלחה!');