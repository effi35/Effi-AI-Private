/**
 * 🚀 Effi-AI Service Worker
 * PWA מלא עם offline support, caching מתקדם וביצועים מיוחדים
 */

const CACHE_NAME = 'effi-ai-v3.1.0';
const DYNAMIC_CACHE = 'effi-ai-dynamic-v3.1.0';
const OFFLINE_PAGE = '/offline.html';

// קבצים לשמירה בCache
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/manifest.json',
    '/offline.html',
    
    // מודולים עיקריים
    '/pages/dashboard_advanced.html',
    '/pages/ai_system_advanced.html',
    '/pages/security_system_advanced.html',
    '/pages/unified_settings.html',
    '/pages/chat_interface_advanced.html',
    '/pages/modules_advanced.html',
    '/pages/connections_advanced.html',
    '/pages/file_system_advanced.html',
    '/pages/backup_system_advanced.html',
    '/pages/logs_system_advanced.html',
    '/pages/system_settings_advanced.html',
    '/pages/physical_system_advanced.html',
    
    // מערכת הליבה
    '/js/core-memory-system.js',
    '/js/modular-core.js',
    
    // הדגמות
    '/animations_demo.html',
    
    // נכסים קיימים
    '/assets/icons/icon-192x192.svg',
    '/assets/icons/icon-512x512.svg',
    '/assets/icons/icon-144x144.svg',
    '/assets/icons/icon-72x72.svg'
];

// URLs שמותר לשמור ב-Dynamic Cache
const CACHEABLE_DOMAINS = [
    'localhost:2025',
    '10.100.102.200:2025',
    'fonts.googleapis.com',
    'fonts.gstatic.com',
    'cdnjs.cloudflare.com'
];

/**
 * התקנת Service Worker
 */
self.addEventListener('install', (event) => {
    console.log('🚀 Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('📦 Service Worker: Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                console.log('✅ Service Worker: Installation complete');
                return self.skipWaiting(); // הפעלה מיידית
            })
            .catch((error) => {
                console.error('❌ Service Worker: Installation failed', error);
            })
    );
});

/**
 * הפעלת Service Worker
 */
self.addEventListener('activate', (event) => {
    console.log('⚡ Service Worker: Activating...');
    
    event.waitUntil(
        Promise.all([
            // ניקוי cache ישנים
            caches.keys().then((cacheNames) => {
                return Promise.all(
                    cacheNames.map((cacheName) => {
                        if (cacheName !== CACHE_NAME && cacheName !== DYNAMIC_CACHE) {
                            console.log('🗑️ Service Worker: Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        }
                    })
                );
            }),
            
            // השתלטות על כל הלקוחות
            self.clients.claim()
        ]).then(() => {
            console.log('✅ Service Worker: Activation complete');
        })
    );
});

/**
 * מחיקת בקשות רשת עם Cache Strategy
 */
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);
    
    // התעלמות מ-Chrome extensions
    if (url.protocol === 'chrome-extension:') {
        return;
    }
    
    // התעלמות מ-POST requests
    if (request.method !== 'GET') {
        return;
    }
    
    event.respondWith(
        handleRequest(request)
    );
});

/**
 * טיפול בבקשות עם אסטרטגיית Cache מתקדמת
 */
async function handleRequest(request) {
    const url = new URL(request.url);
    
    try {
        // דפי HTML - Cache First עם Network Fallback
        if (request.destination === 'document') {
            return await cacheFirstStrategy(request);
        }
        
        // JavaScript/CSS - Stale While Revalidate
        if (request.destination === 'script' || request.destination === 'style') {
            return await staleWhileRevalidateStrategy(request);
        }
        
        // תמונות - Cache First
        if (request.destination === 'image') {
            return await cacheFirstStrategy(request);
        }
        
        // API calls - Network First
        if (url.pathname.includes('/api/')) {
            return await networkFirstStrategy(request);
        }
        
        // שאר הבקשות - Network First עם Cache Fallback
        return await networkFirstStrategy(request);
        
    } catch (error) {
        console.error('❌ Service Worker: Request handling failed', error);
        return await getOfflineResponse(request);
    }
}

/**
 * Cache First Strategy - מהיר לנכסים סטטיים
 */
async function cacheFirstStrategy(request) {
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
        // עדכון ברקע אם נדרש
        updateCacheInBackground(request);
        return cachedResponse;
    }
    
    // אם אין ב-cache, נסה מהרשת
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            await addToCache(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        return await getOfflineResponse(request);
    }
}

/**
 * Network First Strategy - עדכני לנתונים דינמיים
 */
async function networkFirstStrategy(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            await addToCache(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        // אם הרשת נכשלה, נסה מ-cache
        const cachedResponse = await caches.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        return await getOfflineResponse(request);
    }
}

/**
 * Stale While Revalidate Strategy - מהיר + עדכני
 */
async function staleWhileRevalidateStrategy(request) {
    const cachedResponse = await caches.match(request);
    
    // החזר מ-cache מיידית אם קיים
    const responsePromise = cachedResponse || fetch(request);
    
    // עדכן ברקע
    const updatePromise = fetch(request).then(async (networkResponse) => {
        if (networkResponse.ok) {
            await addToCache(request, networkResponse.clone());
        }
        return networkResponse;
    }).catch(() => {
        // שגיאת רשת - נשאר עם cache
    });
    
    // אם אין cache, חכה לרשת
    if (!cachedResponse) {
        return await updatePromise;
    }
    
    return responsePromise;
}

/**
 * הוספה חכמה ל-Cache
 */
async function addToCache(request, response) {
    const url = new URL(request.url);
    
    // בדיקה אם מותר לשמור
    if (!shouldCache(url)) {
        return;
    }
    
    try {
        const cache = await caches.open(DYNAMIC_CACHE);
        await cache.put(request, response);
    } catch (error) {
        console.warn('⚠️ Service Worker: Failed to cache response', error);
    }
}

/**
 * בדיקה אם צריך לשמור ב-Cache
 */
function shouldCache(url) {
    // שמור רק דומיינים מורשים
    return CACHEABLE_DOMAINS.some(domain => url.host.includes(domain));
}

/**
 * עדכון Cache ברקע
 */
function updateCacheInBackground(request) {
    // עדכון ברקע ללא חסימה
    fetch(request).then(async (response) => {
        if (response.ok) {
            await addToCache(request, response.clone());
        }
    }).catch(() => {
        // שגיאת רשת - לא נורא
    });
}

/**
 * תגובת Offline מותאמת
 */
async function getOfflineResponse(request) {
    const url = new URL(request.url);
    
    // עבור דפי HTML - החזר דף offline
    if (request.destination === 'document') {
        const offlineResponse = await caches.match(OFFLINE_PAGE);
        if (offlineResponse) {
            return offlineResponse;
        }
        
        // אם אין דף offline, יצור תגובה בסיסית
        return new Response(`
            <!DOCTYPE html>
            <html lang="he" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>🔌 Effi-AI - מצב Offline</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                        color: #1976d2;
                        text-align: center;
                    }
                    .offline-container {
                        background: white;
                        padding: 40px;
                        border-radius: 20px;
                        box-shadow: 0 8px 32px rgba(25, 118, 210, 0.2);
                        max-width: 500px;
                    }
                    .offline-icon {
                        font-size: 4rem;
                        margin-bottom: 20px;
                    }
                    .offline-title {
                        font-size: 2rem;
                        margin-bottom: 15px;
                    }
                    .offline-message {
                        font-size: 1.1rem;
                        margin-bottom: 30px;
                        color: #64748b;
                    }
                    .retry-btn {
                        background: linear-gradient(135deg, #2196f3, #1976d2);
                        color: white;
                        border: none;
                        padding: 15px 30px;
                        border-radius: 25px;
                        font-size: 1rem;
                        cursor: pointer;
                        transition: all 0.3s ease;
                    }
                    .retry-btn:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 8px 25px rgba(33, 150, 243, 0.3);
                    }
                </style>
            </head>
            <body>
                <div class="offline-container">
                    <div class="offline-icon">🔌</div>
                    <h1 class="offline-title">מצב Offline</h1>
                    <p class="offline-message">
                        אין חיבור לאינטרנט כרגע.<br>
                        Effi-AI ממשיך לפעול במצב מקומי.
                    </p>
                    <button class="retry-btn" onclick="location.reload()">
                        נסה שוב
                    </button>
                </div>
            </body>
            </html>
        `, {
            status: 200,
            headers: {
                'Content-Type': 'text/html; charset=utf-8'
            }
        });
    }
    
    // עבור משאבים אחרים
    return new Response('Offline - No cached version available', {
        status: 503,
        statusText: 'Service Unavailable'
    });
}

/**
 * הודעות Background Sync
 */
self.addEventListener('sync', (event) => {
    console.log('🔄 Service Worker: Background sync triggered');
    
    if (event.tag === 'background-sync') {
        event.waitUntil(performBackgroundSync());
    }
});

/**
 * ביצוע סנכרון ברקע
 */
async function performBackgroundSync() {
    try {
        // סנכרון נתוני זיכרון
        if (self.registration.sync) {
            console.log('📡 Service Worker: Performing background sync');
            
            // כאן ניתן להוסיף לוגיקה לסנכרון נתונים
            // עם השרת כשהחיבור חוזר
        }
    } catch (error) {
        console.error('❌ Service Worker: Background sync failed', error);
    }
}

/**
 * התראות Push
 */
self.addEventListener('push', (event) => {
    const options = {
        body: event.data ? event.data.text() : 'התראה חדשה מ-Effi-AI',
        icon: '/assets/icons/icon-192.png',
        badge: '/assets/icons/icon-72.png',
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'explore',
                title: 'פתח את המערכת',
                icon: '/assets/icons/action-explore.png'
            },
            {
                action: 'close',
                title: 'סגור',
                icon: '/assets/icons/action-close.png'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification('Effi-AI', options)
    );
});

/**
 * לחיצה על התראה
 */
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    
    if (event.action === 'explore') {
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

/**
 * עדכון מטמון כל שעה
 */
setInterval(() => {
    self.registration.update();
}, 3600000); // שעה

console.log('🚀 Effi-AI Service Worker Loaded - PWA Ready!');