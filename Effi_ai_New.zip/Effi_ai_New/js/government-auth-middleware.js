const GovernmentSecurityManager = require('./security-manager');
const rateLimit = require('express-rate-limit');

/**
 * Government Authentication & Authorization Middleware
 * Enterprise-grade security for Israeli Government System
 */
class GovernmentAuthMiddleware {
    constructor() {
        this.securityManager = new GovernmentSecurityManager();
        
        // Government permission levels
        this.permissionLevels = {
            'citizen': ['basic', 'personal_data'],
            'municipal': ['basic', 'personal_data', 'municipal_services'],
            'government': ['basic', 'personal_data', 'municipal_services', 'government_data', 'system_admin'],
            'security': ['basic', 'personal_data', 'municipal_services', 'government_data', 'system_admin', 'security_clearance'],
            'admin': ['all']
        };
        
        // API endpoint permissions mapping
        this.endpointPermissions = {
            '/api/auth/login': ['public'],
            '/api/auth/register': ['public'],
            '/api/connections': ['government_data'],
            '/api/system': ['system_admin'],
            '/api/citizens': ['government_data'],
            '/api/security': ['security_clearance'],
            '/api/admin': ['all']
        };
        
        console.log('🛡️ Government Authentication Middleware initialized');
    }
    
    /**
     * JWT Authentication Middleware
     */
    authenticateJWT() {
        return async (req, res, next) => {
            try {
                const authHeader = req.headers['authorization'];
                const token = authHeader && authHeader.split(' ')[1];
                
                if (!token) {
                    this.securityManager.logSecurityEvent('auth_missing_token', 'Missing authorization token', {
                        ip: req.ip,
                        userAgent: req.get('User-Agent'),
                        endpoint: req.originalUrl
                    });
                    
                    return res.status(401).json({
                        error: 'Access token required',
                        code: 'MISSING_TOKEN'
                    });
                }
                
                // Verify JWT token
                const decoded = this.securityManager.verifyJWTToken(token, 'access');
                
                // Check if session is still valid
                if (decoded.sessionId) {
                    const session = this.securityManager.validateSession(decoded.sessionId);
                    if (!session) {
                        return res.status(401).json({
                            error: 'Session expired',
                            code: 'SESSION_EXPIRED'
                        });
                    }
                }
                
                // Attach user info to request
                req.user = {
                    id: decoded.id,
                    username: decoded.username,
                    userType: decoded.userType,
                    permissions: decoded.permissions || [],
                    sessionId: decoded.sessionId,
                    securityLevel: decoded.security_level
                };
                
                this.securityManager.logSecurityEvent('auth_success', 'Authentication successful', {
                    userId: decoded.id,
                    userType: decoded.userType,
                    endpoint: req.originalUrl
                });
                
                next();
                
            } catch (error) {
                this.securityManager.logSecurityEvent('auth_failed', 'Authentication failed', {
                    error: error.message,
                    ip: req.ip,
                    endpoint: req.originalUrl
                });
                
                return res.status(403).json({
                    error: 'Invalid or expired token',
                    code: 'INVALID_TOKEN'
                });
            }
        };
    }
    
    /**
     * Authorization Middleware - Check permissions
     */
    authorize(requiredPermissions = []) {
        return (req, res, next) => {
            try {
                if (!req.user) {
                    return res.status(401).json({
                        error: 'Authentication required',
                        code: 'NOT_AUTHENTICATED'
                    });
                }
                
                const userPermissions = this.permissionLevels[req.user.userType] || [];
                
                // Admin has all permissions
                if (userPermissions.includes('all')) {
                    return next();
                }
                
                // Check if user has required permissions
                const hasPermission = requiredPermissions.every(permission => 
                    userPermissions.includes(permission) || req.user.permissions.includes(permission)
                );
                
                if (!hasPermission) {
                    this.securityManager.logSecurityEvent('auth_insufficient_permissions', 'Insufficient permissions', {
                        userId: req.user.id,
                        userType: req.user.userType,
                        requiredPermissions,
                        userPermissions,
                        endpoint: req.originalUrl
                    });
                    
                    return res.status(403).json({
                        error: 'Insufficient permissions',
                        code: 'INSUFFICIENT_PERMISSIONS',
                        required: requiredPermissions
                    });
                }
                
                this.securityManager.logSecurityEvent('auth_authorized', 'Authorization successful', {
                    userId: req.user.id,
                    endpoint: req.originalUrl,
                    permissions: requiredPermissions
                });
                
                next();
                
            } catch (error) {
                this.securityManager.logSecurityEvent('auth_authorization_error', 'Authorization error', {
                    error: error.message,
                    userId: req.user?.id,
                    endpoint: req.originalUrl
                });
                
                return res.status(500).json({
                    error: 'Authorization error',
                    code: 'AUTHORIZATION_ERROR'
                });
            }
        };
    }
    
    /**
     * Rate Limiting for Government APIs
     */
    createRateLimit(options = {}) {
        const defaultOptions = {
            windowMs: 15 * 60 * 1000, // 15 minutes
            max: 1000, // limit each IP to 1000 requests per windowMs
            message: {
                error: 'Too many requests from this IP',
                code: 'RATE_LIMIT_EXCEEDED'
            },
            standardHeaders: true,
            legacyHeaders: false,
            handler: (req, res) => {
                this.securityManager.logSecurityEvent('rate_limit_exceeded', 'Rate limit exceeded', {
                    ip: req.ip,
                    userAgent: req.get('User-Agent'),
                    endpoint: req.originalUrl
                });
                
                res.status(429).json({
                    error: 'Too many requests from this IP',
                    code: 'RATE_LIMIT_EXCEEDED',
                    retryAfter: Math.ceil(options.windowMs / 1000)
                });
            }
        };
        
        return rateLimit({ ...defaultOptions, ...options });
    }
    
    /**
     * Secure endpoint middleware - combines auth, authorization, and rate limiting
     */
    secureEndpoint(requiredPermissions = [], rateLimitOptions = {}) {
        return [
            this.createRateLimit(rateLimitOptions),
            this.authenticateJWT(),
            this.authorize(requiredPermissions)
        ];
    }
    
    /**
     * Government security headers middleware
     */
    addSecurityHeaders() {
        return (req, res, next) => {
            // Government security headers
            res.setHeader('X-Government-System', 'Effi-AI-Israel');
            res.setHeader('X-Security-Level', 'Maximum');
            res.setHeader('X-Content-Type-Options', 'nosniff');
            res.setHeader('X-Frame-Options', 'DENY');
            res.setHeader('X-XSS-Protection', '1; mode=block');
            res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
            res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
            
            // HSTS for government systems
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
            
            // CSP for government content
            res.setHeader('Content-Security-Policy', 
                "default-src 'self'; " +
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
                "font-src 'self' https://fonts.gstatic.com; " +
                "img-src 'self' data: https:; " +
                "connect-src 'self' ws: wss:;"
            );
            
            next();
        };
    }
    
    /**
     * IP Whitelist middleware for government endpoints
     */
    ipWhitelist(allowedIPs = []) {
        return (req, res, next) => {
            const clientIP = req.ip || req.connection.remoteAddress;
            
            // Allow localhost for development
            const governmentIPs = [
                '127.0.0.1',
                '::1',
                'localhost',
                ...allowedIPs
            ];
            
            if (process.env.NODE_ENV === 'development' || governmentIPs.includes(clientIP)) {
                return next();
            }
            
            this.securityManager.logSecurityEvent('ip_blocked', 'IP address blocked', {
                blockedIP: clientIP,
                endpoint: req.originalUrl
            });
            
            return res.status(403).json({
                error: 'Access denied from this IP address',
                code: 'IP_BLOCKED'
            });
        };
    }
    
    /**
     * Session validation middleware
     */
    validateSession() {
        return (req, res, next) => {
            if (req.user && req.user.sessionId) {
                const session = this.securityManager.validateSession(req.user.sessionId);
                if (!session) {
                    return res.status(401).json({
                        error: 'Session expired',
                        code: 'SESSION_EXPIRED'
                    });
                }
                req.session = session;
            }
            next();
        };
    }
    
    /**
     * Multi-factor authentication check
     */
    requireMFA() {
        return (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({
                    error: 'Authentication required',
                    code: 'NOT_AUTHENTICATED'
                });
            }
            
            // For high-security operations, require MFA
            if (req.user.userType === 'security' || req.user.userType === 'admin') {
                const mfaToken = req.headers['x-mfa-token'];
                
                if (!mfaToken) {
                    this.securityManager.logSecurityEvent('mfa_required', 'MFA token required', {
                        userId: req.user.id,
                        endpoint: req.originalUrl
                    });
                    
                    return res.status(403).json({
                        error: 'Multi-factor authentication required',
                        code: 'MFA_REQUIRED'
                    });
                }
                
                // In production, verify MFA token here
                // For now, log the requirement
                this.securityManager.logSecurityEvent('mfa_verified', 'MFA verification completed', {
                    userId: req.user.id,
                    endpoint: req.originalUrl
                });
            }
            
            next();
        };
    }
    
    /**
     * Audit logging middleware
     */
    auditRequest() {
        return (req, res, next) => {
            const startTime = Date.now();
            
            res.on('finish', () => {
                const duration = Date.now() - startTime;
                
                this.securityManager.logSecurityEvent('api_request', 'API request completed', {
                    method: req.method,
                    endpoint: req.originalUrl,
                    statusCode: res.statusCode,
                    duration,
                    userId: req.user?.id,
                    userType: req.user?.userType,
                    ip: req.ip,
                    userAgent: req.get('User-Agent')
                });
            });
            
            next();
        };
    }
    
    /**
     * Get security manager instance
     */
    getSecurityManager() {
        return this.securityManager;
    }
    
    /**
     * Get user permissions
     */
    getUserPermissions(userType) {
        return this.permissionLevels[userType] || [];
    }
}

module.exports = GovernmentAuthMiddleware;