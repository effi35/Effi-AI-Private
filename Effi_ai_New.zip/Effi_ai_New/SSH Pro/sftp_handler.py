"""
SFTP Handler for SSH/SFTP Manager
מטפל בכל העברות הקבצים דרך SFTP
"""

import asyncio
import asyncssh
import os
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, AsyncGenerator
from datetime import datetime
import mimetypes
import aiofiles

logger = logging.getLogger(__name__)

class SFTPHandler:
    """Handles SFTP file operations"""
    
    def __init__(self, ssh_session):
        self.ssh_session = ssh_session
        self.sftp_client: Optional[asyncssh.SFTPClient] = None
        self.transfer_progress = {}
        
    async def connect(self) -> bool:
        """Initialize SFTP client"""
        try:
            if not self.ssh_session.connected:
                logger.error("SSH session not connected")
                return False
                
            self.sftp_client = await self.ssh_session.ssh_client.start_sftp_client()
            logger.info("SFTP client initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize SFTP: {str(e)}")
            return False
    
    async def list_directory(self, path: str = '.') -> List[Dict[str, Any]]:
        """List files in directory"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            files = []
            async for entry in self.sftp_client.scandir(path):
                file_info = {
                    'name': entry.filename,
                    'path': os.path.join(path, entry.filename),
                    'size': entry.attrs.size if entry.attrs.size else 0,
                    'type': 'directory' if await self._is_directory(entry) else 'file',
                    'permissions': self._format_permissions(entry.attrs.permissions),
                    'modified': datetime.fromtimestamp(entry.attrs.mtime).isoformat() if entry.attrs.mtime else None,
                    'owner': entry.attrs.owner,
                    'group': entry.attrs.group,
                    'mime_type': self._get_mime_type(entry.filename)
                }
                files.append(file_info)
                
            # Sort: directories first, then by name
            files.sort(key=lambda x: (x['type'] != 'directory', x['name'].lower()))
            return files
            
        except Exception as e:
            logger.error(f"Failed to list directory {path}: {str(e)}")
            raise
    
    async def _is_directory(self, entry) -> bool:
        """Check if entry is a directory"""
        try:
            return entry.attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY
        except:
            # Fallback method
            return entry.attrs.permissions & 0o40000 != 0
    
    def _format_permissions(self, perms: int) -> str:
        """Format permissions to readable string"""
        if perms is None:
            return '----------'
            
        # File type
        if perms & 0o40000:
            file_type = 'd'
        elif perms & 0o20000:
            file_type = 'c'
        elif perms & 0o60000:
            file_type = 'b'
        elif perms & 0o10000:
            file_type = 'p'
        elif perms & 0o140000:
            file_type = 's'
        elif perms & 0o120000:
            file_type = 'l'
        else:
            file_type = '-'
            
        # Permissions
        permissions = ''
        for i in range(9):
            bit = 8 - i
            if perms & (1 << bit):
                if i % 3 == 0:
                    permissions += 'r'
                elif i % 3 == 1:
                    permissions += 'w'
                else:
                    permissions += 'x'
            else:
                permissions += '-'
                
        return file_type + permissions
    
    def _get_mime_type(self, filename: str) -> str:
        """Get MIME type for file"""
        mime_type, _ = mimetypes.guess_type(filename)
        return mime_type or 'application/octet-stream'
    
    async def upload_file(self, local_path: str, remote_path: str, 
                         progress_callback=None) -> Dict[str, Any]:
        """Upload file to remote server"""
        if not self.sftp_client:
            await self.connect()
            
        transfer_id = f"upload_{datetime.now().timestamp()}"
        self.transfer_progress[transfer_id] = {
            'total': 0,
            'transferred': 0,
            'status': 'starting'
        }
        
        try:
            # Get file size
            file_size = os.path.getsize(local_path)
            self.transfer_progress[transfer_id]['total'] = file_size
            
            # Upload with progress tracking
            async def progress_handler(transferred, total):
                self.transfer_progress[transfer_id]['transferred'] = transferred
                self.transfer_progress[transfer_id]['status'] = 'transferring'
                
                if progress_callback:
                    await progress_callback({
                        'transfer_id': transfer_id,
                        'transferred': transferred,
                        'total': total,
                        'percentage': (transferred / total * 100) if total > 0 else 0
                    })
            
            await self.sftp_client.put(
                local_path, 
                remote_path,
                progress_handler=progress_handler
            )
            
            self.transfer_progress[transfer_id]['status'] = 'completed'
            
            return {
                'success': True,
                'transfer_id': transfer_id,
                'local_path': local_path,
                'remote_path': remote_path,
                'size': file_size
            }
            
        except Exception as e:
            self.transfer_progress[transfer_id]['status'] = 'failed'
            logger.error(f"Upload failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'transfer_id': transfer_id
            }
    
    async def download_file(self, remote_path: str, local_path: str,
                           progress_callback=None) -> Dict[str, Any]:
        """Download file from remote server"""
        if not self.sftp_client:
            await self.connect()
            
        transfer_id = f"download_{datetime.now().timestamp()}"
        self.transfer_progress[transfer_id] = {
            'total': 0,
            'transferred': 0,
            'status': 'starting'
        }
        
        try:
            # Get remote file size
            attrs = await self.sftp_client.stat(remote_path)
            file_size = attrs.size
            self.transfer_progress[transfer_id]['total'] = file_size
            
            # Ensure local directory exists
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            # Download with progress tracking
            async def progress_handler(transferred, total):
                self.transfer_progress[transfer_id]['transferred'] = transferred
                self.transfer_progress[transfer_id]['status'] = 'transferring'
                
                if progress_callback:
                    await progress_callback({
                        'transfer_id': transfer_id,
                        'transferred': transferred,
                        'total': total,
                        'percentage': (transferred / total * 100) if total > 0 else 0
                    })
            
            await self.sftp_client.get(
                remote_path,
                local_path,
                progress_handler=progress_handler
            )
            
            self.transfer_progress[transfer_id]['status'] = 'completed'
            
            return {
                'success': True,
                'transfer_id': transfer_id,
                'remote_path': remote_path,
                'local_path': local_path,
                'size': file_size
            }
            
        except Exception as e:
            self.transfer_progress[transfer_id]['status'] = 'failed'
            logger.error(f"Download failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'transfer_id': transfer_id
            }
    
    async def create_directory(self, path: str) -> bool:
        """Create directory on remote server"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            await self.sftp_client.mkdir(path)
            logger.info(f"Created directory: {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to create directory {path}: {str(e)}")
            return False
    
    async def delete_file(self, path: str) -> bool:
        """Delete file on remote server"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            await self.sftp_client.remove(path)
            logger.info(f"Deleted file: {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete file {path}: {str(e)}")
            return False
    
    async def delete_directory(self, path: str) -> bool:
        """Delete directory on remote server"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            await self.sftp_client.rmdir(path)
            logger.info(f"Deleted directory: {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete directory {path}: {str(e)}")
            return False
    
    async def rename(self, old_path: str, new_path: str) -> bool:
        """Rename file or directory"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            await self.sftp_client.rename(old_path, new_path)
            logger.info(f"Renamed {old_path} to {new_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to rename {old_path}: {str(e)}")
            return False
    
    async def get_file_info(self, path: str) -> Dict[str, Any]:
        """Get detailed file information"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            attrs = await self.sftp_client.stat(path)
            return {
                'path': path,
                'size': attrs.size,
                'permissions': self._format_permissions(attrs.permissions),
                'owner': attrs.owner,
                'group': attrs.group,
                'modified': datetime.fromtimestamp(attrs.mtime).isoformat() if attrs.mtime else None,
                'accessed': datetime.fromtimestamp(attrs.atime).isoformat() if attrs.atime else None,
                'type': 'directory' if attrs.permissions & 0o40000 else 'file'
            }
        except Exception as e:
            logger.error(f"Failed to get file info for {path}: {str(e)}")
            raise
    
    async def read_file_content(self, path: str, max_size: int = 1024 * 1024) -> str:
        """Read file content (for small text files)"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            # Check file size first
            attrs = await self.sftp_client.stat(path)
            if attrs.size > max_size:
                raise ValueError(f"File too large ({attrs.size} bytes). Max size: {max_size} bytes")
            
            # Read file
            async with self.sftp_client.open(path, 'r') as f:
                content = await f.read()
                return content.decode('utf-8', errors='replace')
                
        except Exception as e:
            logger.error(f"Failed to read file {path}: {str(e)}")
            raise
    
    async def write_file_content(self, path: str, content: str) -> bool:
        """Write content to file"""
        if not self.sftp_client:
            await self.connect()
            
        try:
            async with self.sftp_client.open(path, 'w') as f:
                await f.write(content.encode('utf-8'))
            logger.info(f"Wrote content to file: {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to write file {path}: {str(e)}")
            return False
    
    def get_transfer_progress(self, transfer_id: str) -> Dict[str, Any]:
        """Get transfer progress"""
        return self.transfer_progress.get(transfer_id, {
            'status': 'not_found'
        })
    
    async def batch_download(self, files: List[Dict[str, str]], 
                           progress_callback=None) -> List[Dict[str, Any]]:
        """Download multiple files"""
        results = []
        for file_info in files:
            result = await self.download_file(
                file_info['remote_path'],
                file_info['local_path'],
                progress_callback
            )
            results.append(result)
        return results
    
    async def batch_upload(self, files: List[Dict[str, str]], 
                         progress_callback=None) -> List[Dict[str, Any]]:
        """Upload multiple files"""
        results = []
        for file_info in files:
            result = await self.upload_file(
                file_info['local_path'],
                file_info['remote_path'],
                progress_callback
            )
            results.append(result)
        return results
