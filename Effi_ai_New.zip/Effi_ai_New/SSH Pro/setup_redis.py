#!/usr/bin/env python3
"""
Redis Setup and Configuration for SSH/SFTP Manager
התקנת והגדרת Redis למערכת
"""

import os
import sys
import subprocess
import platform
import time
import socket
from pathlib import Path

def check_redis_installed():
    """Check if Redis is installed"""
    try:
        result = subprocess.run(['redis-server', '--version'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Redis is already installed")
            print(f"   Version: {result.stdout.strip()}")
            return True
    except FileNotFoundError:
        pass
    return False

def install_redis():
    """Install Redis based on the operating system"""
    system = platform.system().lower()
    
    print(f"🔍 Detected OS: {system}")
    
    if system == 'linux':
        distro = get_linux_distro()
        
        if distro in ['ubuntu', 'debian']:
            print("📦 Installing Redis on Ubuntu/Debian...")
            commands = [
                ['sudo', 'apt-get', 'update'],
                ['sudo', 'apt-get', 'install', '-y', 'redis-server']
            ]
        elif distro in ['centos', 'rhel', 'fedora']:
            print("📦 Installing Redis on CentOS/RHEL/Fedora...")
            commands = [
                ['sudo', 'yum', 'install', '-y', 'epel-release'],
                ['sudo', 'yum', 'install', '-y', 'redis']
            ]
        else:
            print("⚠️  Unknown Linux distribution")
            return False
            
    elif system == 'darwin':  # macOS
        print("📦 Installing Redis on macOS...")
        # Check if Homebrew is installed
        if not check_command_exists('brew'):
            print("❌ Homebrew is required. Please install it first:")
            print("   /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
            return False
        commands = [['brew', 'install', 'redis']]
        
    elif system == 'windows':
        print("⚠️  Windows detected. Redis installation on Windows requires WSL or Docker.")
        print("   Please install Redis manually:")
        print("   - Using WSL: https://docs.microsoft.com/en-us/windows/wsl/install")
        print("   - Using Docker: docker run -d -p 6379:6379 redis")
        return False
    else:
        print(f"❌ Unsupported OS: {system}")
        return False
    
    # Execute installation commands
    for cmd in commands:
        print(f"🔧 Running: {' '.join(cmd)}")
        try:
            result = subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"❌ Error running command: {e}")
            return False
    
    print("✅ Redis installed successfully")
    return True

def get_linux_distro():
    """Get Linux distribution name"""
    try:
        with open('/etc/os-release', 'r') as f:
            for line in f:
                if line.startswith('ID='):
                    return line.split('=')[1].strip().strip('"').lower()
    except:
        pass
    return 'unknown'

def check_command_exists(command):
    """Check if a command exists"""
    try:
        subprocess.run(['which', command], capture_output=True, check=True)
        return True
    except:
        return False

def configure_redis():
    """Configure Redis for the SSH/SFTP Manager"""
    print("\n🔧 Configuring Redis...")
    
    # Create Redis config directory
    config_dir = Path.home() / '.ssh_sftp_manager' / 'redis'
    config_dir.mkdir(parents=True, exist_ok=True)
    
    # Create custom Redis configuration
    config_file = config_dir / 'redis.conf'
    
    config_content = """
# Redis Configuration for SSH/SFTP Manager

# Network
bind 127.0.0.1
port 6379
timeout 0
tcp-keepalive 300

# General
daemonize no
supervised no
pidfile /var/run/redis_6379.pid
loglevel notice
logfile ""
databases 16

# Persistence
save 900 1
save 300 10
save 60 10000
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb
dir ./

# Security
# requirepass your_secure_password_here

# Limits
maxclients 10000

# Memory Management
maxmemory 256mb
maxmemory-policy allkeys-lru

# Append Only Mode
appendonly yes
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb

# Slow Log
slowlog-log-slower-than 10000
slowlog-max-len 128

# Event Notification
notify-keyspace-events ""
"""
    
    with open(config_file, 'w') as f:
        f.write(config_content)
    
    print(f"✅ Redis configuration saved to: {config_file}")
    
    # Create systemd service file for Linux
    if platform.system().lower() == 'linux':
        create_systemd_service()
    
    return str(config_file)

def create_systemd_service():
    """Create systemd service for Redis"""
    service_content = """[Unit]
Description=Redis for SSH/SFTP Manager
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/redis-server {config_path}
Restart=always
RestartSec=5
User={user}
Group={user}

[Install]
WantedBy=multi-user.target
"""
    
    config_path = Path.home() / '.ssh_sftp_manager' / 'redis' / 'redis.conf'
    service_content = service_content.format(
        config_path=config_path,
        user=os.getenv('USER')
    )
    
    service_file = Path.home() / '.config' / 'systemd' / 'user' / 'redis-ssh-manager.service'
    service_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(service_file, 'w') as f:
        f.write(service_content)
    
    print(f"✅ Systemd service created: {service_file}")
    print("   To enable: systemctl --user enable redis-ssh-manager")
    print("   To start: systemctl --user start redis-ssh-manager")

def start_redis(config_file=None):
    """Start Redis server"""
    print("\n🚀 Starting Redis server...")
    
    # Check if Redis is already running
    if is_redis_running():
        print("✅ Redis is already running")
        return True
    
    try:
        if config_file:
            cmd = ['redis-server', config_file]
        else:
            cmd = ['redis-server']
        
        # Start Redis in background
        process = subprocess.Popen(cmd, 
                                 stdout=subprocess.PIPE, 
                                 stderr=subprocess.PIPE)
        
        # Wait a moment for Redis to start
        time.sleep(2)
        
        if is_redis_running():
            print("✅ Redis started successfully")
            return True
        else:
            print("❌ Failed to start Redis")
            return False
            
    except Exception as e:
        print(f"❌ Error starting Redis: {e}")
        return False

def is_redis_running(host='localhost', port=6379):
    """Check if Redis is running"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except:
        return False

def test_redis_connection():
    """Test Redis connection"""
    print("\n🧪 Testing Redis connection...")
    
    try:
        import redis
        
        r = redis.Redis(host='localhost', port=6379, decode_responses=True)
        
        # Test SET and GET
        r.set('test_key', 'Hello Redis!')
        value = r.get('test_key')
        
        if value == 'Hello Redis!':
            print("✅ Redis connection test passed")
            r.delete('test_key')
            return True
        else:
            print("❌ Redis connection test failed")
            return False
            
    except ImportError:
        print("⚠️  Redis Python package not installed")
        print("   Installing redis package...")
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'redis'])
        return test_redis_connection()  # Retry after installation
        
    except Exception as e:
        print(f"❌ Redis connection error: {e}")
        return False

def create_redis_utils():
    """Create Redis utility scripts"""
    utils_dir = Path.home() / '.ssh_sftp_manager' / 'redis' / 'utils'
    utils_dir.mkdir(parents=True, exist_ok=True)
    
    # Create backup script
    backup_script = utils_dir / 'backup_redis.sh'
    backup_content = """#!/bin/bash
# Redis Backup Script

BACKUP_DIR="$HOME/.ssh_sftp_manager/redis/backups"
mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/redis_backup_$TIMESTAMP.rdb"

echo "Creating Redis backup..."
redis-cli BGSAVE
sleep 2

cp /var/lib/redis/dump.rdb "$BACKUP_FILE"
echo "Backup saved to: $BACKUP_FILE"

# Keep only last 7 backups
ls -t "$BACKUP_DIR"/redis_backup_*.rdb | tail -n +8 | xargs -r rm
"""
    
    with open(backup_script, 'w') as f:
        f.write(backup_content)
    
    os.chmod(backup_script, 0o755)
    
    # Create monitor script
    monitor_script = utils_dir / 'monitor_redis.sh'
    monitor_content = """#!/bin/bash
# Redis Monitor Script

echo "Redis Server Info:"
redis-cli INFO server

echo -e "\\nMemory Usage:"
redis-cli INFO memory | grep used_memory_human

echo -e "\\nConnected Clients:"
redis-cli INFO clients | grep connected_clients

echo -e "\\nKeyspace:"
redis-cli INFO keyspace
"""
    
    with open(monitor_script, 'w') as f:
        f.write(monitor_content)
    
    os.chmod(monitor_script, 0o755)
    
    print(f"✅ Redis utilities created in: {utils_dir}")

def main():
    """Main setup function"""
    print("🔧 SSH/SFTP Manager - Redis Setup")
    print("==================================")
    
    # Check if Redis is installed
    if not check_redis_installed():
        print("\n📦 Redis not found. Installing...")
        if not install_redis():
            print("❌ Failed to install Redis")
            sys.exit(1)
    
    # Configure Redis
    config_file = configure_redis()
    
    # Start Redis
    if not is_redis_running():
        start_redis(config_file)
    
    # Test connection
    if not test_redis_connection():
        print("❌ Redis setup failed")
        sys.exit(1)
    
    # Create utility scripts
    create_redis_utils()
    
    print("\n✅ Redis setup completed successfully!")
    print("\n📋 Quick Commands:")
    print("   Start Redis:   redis-server ~/.ssh_sftp_manager/redis/redis.conf")
    print("   Stop Redis:    redis-cli shutdown")
    print("   Monitor Redis: ~/.ssh_sftp_manager/redis/utils/monitor_redis.sh")
    print("   Backup Redis:  ~/.ssh_sftp_manager/redis/utils/backup_redis.sh")

if __name__ == "__main__":
    main()
