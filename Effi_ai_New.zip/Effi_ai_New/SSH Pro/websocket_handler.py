"""
WebSocket Handler for SSH/SFTP Manager
מטפל בתקשורת WebSocket בזמן אמת עם הלקוחות
"""

import asyncio
import json
import logging
from typing import Dict, Set, Optional, Any
from datetime import datetime
import weakref
from fastapi import WebSocket, WebSocketDisconnect
from ssh_handler import ssh_manager
from sftp_handler import SFTPHandler
from sync_manager import SyncManager

logger = logging.getLogger(__name__)

class WebSocketConnection:
    """Represents a WebSocket connection"""
    
    def __init__(self, websocket: WebSocket, client_id: str):
        self.websocket = websocket
        self.client_id = client_id
        self.session_id: Optional[str] = None
        self.connected_at = datetime.now()
        self.last_activity = datetime.now()
        self.subscriptions: Set[str] = set()
        self.terminal_size = {'cols': 80, 'rows': 24}
        
    async def send(self, message: Dict[str, Any]):
        """Send message to client"""
        try:
            await self.websocket.send_json(message)
            self.last_activity = datetime.now()
        except Exception as e:
            logger.error(f"Failed to send message to {self.client_id}: {str(e)}")
            
    async def send_text(self, text: str):
        """Send text message to client"""
        try:
            await self.websocket.send_text(text)
            self.last_activity = datetime.now()
        except Exception as e:
            logger.error(f"Failed to send text to {self.client_id}: {str(e)}")

class WebSocketManager:
    """Manages all WebSocket connections"""
    
    def __init__(self):
        self.connections: Dict[str, WebSocketConnection] = {}
        self.session_connections: Dict[str, Set[str]] = {}  # session_id -> client_ids
        self.terminal_tasks: Dict[str, asyncio.Task] = {}
        self.sync_manager = SyncManager()
        
    async def connect(self, websocket: WebSocket, client_id: str):
        """Handle new WebSocket connection"""
        await websocket.accept()
        
        connection = WebSocketConnection(websocket, client_id)
        self.connections[client_id] = connection
        
        logger.info(f"Client {client_id} connected")
        
        # Send welcome message
        await connection.send({
            'type': 'welcome',
            'message': 'Connected to SSH/SFTP Manager',
            'client_id': client_id,
            'timestamp': datetime.now().isoformat()
        })
        
        # Check for existing sessions
        await self._check_existing_sessions(connection)
        
    async def disconnect(self, client_id: str):
        """Handle WebSocket disconnection"""
        connection = self.connections.get(client_id)
        if not connection:
            return
            
        # Remove from session connections
        if connection.session_id:
            session_clients = self.session_connections.get(connection.session_id, set())
            session_clients.discard(client_id)
            if not session_clients:
                del self.session_connections[connection.session_id]
                
        # Cancel terminal task if exists
        if client_id in self.terminal_tasks:
            self.terminal_tasks[client_id].cancel()
            del self.terminal_tasks[client_id]
            
        # Remove connection
        del self.connections[client_id]
        
        logger.info(f"Client {client_id} disconnected")
        
    async def handle_message(self, client_id: str, data: str):
        """Handle incoming message from client"""
        connection = self.connections.get(client_id)
        if not connection:
            return
            
        try:
            message = json.loads(data)
            message_type = message.get('type')
            
            # Update activity
            connection.last_activity = datetime.now()
            
            # Route message to appropriate handler
            if message_type == 'connect':
                await self._handle_connect(connection, message)
            elif message_type == 'disconnect':
                await self._handle_disconnect(connection, message)
            elif message_type == 'input':
                await self._handle_terminal_input(connection, message)
            elif message_type == 'resize':
                await self._handle_resize(connection, message)
            elif message_type == 'command':
                await self._handle_command(connection, message)
            elif message_type == 'file_list':
                await self._handle_file_list(connection, message)
            elif message_type == 'file_upload':
                await self._handle_file_upload(connection, message)
            elif message_type == 'file_download':
                await self._handle_file_download(connection, message)
            elif message_type == 'sync':
                await self._handle_sync(connection, message)
            elif message_type == 'voice_command':
                await self._handle_voice_command(connection, message)
            else:
                logger.warning(f"Unknown message type: {message_type}")
                
        except json.JSONDecodeError:
            # Handle plain text as terminal input
            if connection.session_id:
                await self._handle_terminal_input(connection, {'data': data})
        except Exception as e:
            logger.error(f"Error handling message: {str(e)}")
            await connection.send({
                'type': 'error',
                'message': str(e)
            })
    
    async def _check_existing_sessions(self, connection: WebSocketConnection):
        """Check for existing sessions that can be resumed"""
        sessions = ssh_manager.list_sessions()
        if sessions:
            await connection.send({
                'type': 'existing_sessions',
                'sessions': sessions
            })
    
    async def _handle_connect(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle SSH connection request"""
        try:
            connection_params = message.get('params', {})
            session_id = message.get('session_id', f"session_{connection.client_id}_{datetime.now().timestamp()}")
            
            # Check if resuming existing session
            existing_session = ssh_manager.get_session(session_id)
            if existing_session:
                connection.session_id = session_id
                logger.info(f"Resuming existing session {session_id}")
            else:
                # Create new session
                session = await ssh_manager.create_session(session_id, connection_params)
                connection.session_id = session_id
                logger.info(f"Created new session {session_id}")
            
            # Add to session connections
            if connection.session_id not in self.session_connections:
                self.session_connections[connection.session_id] = set()
            self.session_connections[connection.session_id].add(connection.client_id)
            
            # Start terminal handler
            self.terminal_tasks[connection.client_id] = asyncio.create_task(
                self._terminal_handler(connection)
            )
            
            await connection.send({
                'type': 'connected',
                'session_id': connection.session_id,
                'message': 'SSH connection established'
            })
            
            # Sync data
            await self.sync_manager.sync_session_start(connection.session_id, connection.client_id)
            
        except Exception as e:
            logger.error(f"Connection failed: {str(e)}")
            await connection.send({
                'type': 'connection_error',
                'error': str(e)
            })
    
    async def _handle_disconnect(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle SSH disconnection request"""
        if not connection.session_id:
            return
            
        try:
            # Only disconnect if this is the last client
            session_clients = self.session_connections.get(connection.session_id, set())
            if len(session_clients) <= 1:
                await ssh_manager.disconnect_session(connection.session_id)
                await connection.send({
                    'type': 'disconnected',
                    'message': 'SSH session closed'
                })
            else:
                await connection.send({
                    'type': 'detached',
                    'message': 'Detached from session (other clients still connected)'
                })
                
            connection.session_id = None
            
        except Exception as e:
            logger.error(f"Disconnect failed: {str(e)}")
            await connection.send({
                'type': 'error',
                'message': str(e)
            })
    
    async def _handle_terminal_input(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle terminal input"""
        if not connection.session_id:
            return
            
        session = ssh_manager.get_session(connection.session_id)
        if not session or not session.connected:
            return
            
        data = message.get('data', '')
        
        # Send to SSH session
        if hasattr(session, 'channel') and session.channel:
            session.channel.write(data)
    
    async def _terminal_handler(self, connection: WebSocketConnection):
        """Handle terminal output for a connection"""
        try:
            session = ssh_manager.get_session(connection.session_id)
            if not session:
                return
                
            # Create interactive shell
            shell_info = await session.create_interactive_shell()
            if not shell_info:
                return
                
            channel = shell_info['channel']
            
            # Start shell
            await channel.exec('$SHELL')
            
            # Read output and send to client
            while True:
                data = await channel.read(4096)
                if not data:
                    break
                    
                # Send to all clients connected to this session
                await self._broadcast_to_session(connection.session_id, {
                    'type': 'output',
                    'data': data.decode('utf-8', errors='replace')
                })
                
        except asyncio.CancelledError:
            logger.info(f"Terminal handler cancelled for {connection.client_id}")
        except Exception as e:
            logger.error(f"Terminal handler error: {str(e)}")
            await connection.send({
                'type': 'error',
                'message': f'Terminal error: {str(e)}'
            })
    
    async def _handle_resize(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle terminal resize"""
        cols = message.get('cols', 80)
        rows = message.get('rows', 24)
        
        connection.terminal_size = {'cols': cols, 'rows': rows}
        
        if connection.session_id:
            session = ssh_manager.get_session(connection.session_id)
            if session:
                await session.resize_terminal(cols, rows)
    
    async def _handle_command(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle command execution"""
        if not connection.session_id:
            await connection.send({
                'type': 'error',
                'message': 'No active session'
            })
            return
            
        session = ssh_manager.get_session(connection.session_id)
        if not session:
            return
            
        command = message.get('command', '')
        result = await session.execute_command(command)
        
        await connection.send({
            'type': 'command_result',
            'result': result
        })
        
        # Sync command history
        await self.sync_manager.add_command(connection.session_id, command)
    
    async def _handle_file_list(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle file list request"""
        if not connection.session_id:
            return
            
        session = ssh_manager.get_session(connection.session_id)
        if not session:
            return
            
        path = message.get('path', '.')
        
        try:
            sftp = SFTPHandler(session)
            files = await sftp.list_directory(path)
            
            await connection.send({
                'type': 'file_list',
                'path': path,
                'files': files
            })
        except Exception as e:
            await connection.send({
                'type': 'error',
                'message': f'Failed to list files: {str(e)}'
            })
    
    async def _handle_file_upload(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle file upload"""
        # Implementation for file upload
        pass
    
    async def _handle_file_download(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle file download"""
        # Implementation for file download
        pass
    
    async def _handle_sync(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle sync request"""
        sync_type = message.get('sync_type', 'all')
        
        if sync_type == 'aliases':
            aliases = await self.sync_manager.get_aliases()
            await connection.send({
                'type': 'sync_aliases',
                'aliases': aliases
            })
        elif sync_type == 'commands':
            commands = await self.sync_manager.get_command_history(connection.session_id)
            await connection.send({
                'type': 'sync_commands',
                'commands': commands
            })
        elif sync_type == 'all':
            sync_data = await self.sync_manager.get_all_sync_data(connection.session_id)
            await connection.send({
                'type': 'sync_all',
                'data': sync_data
            })
    
    async def _handle_voice_command(self, connection: WebSocketConnection, message: Dict[str, Any]):
        """Handle voice command"""
        command = message.get('data', {}).get('command', '')
        language = message.get('data', {}).get('language', 'he-IL')
        
        # Save voice command
        await self.sync_manager.add_voice_command(
            connection.session_id,
            command,
            language
        )
        
        # Broadcast to other clients
        await self._broadcast_to_session(connection.session_id, {
            'type': 'voice_command_sync',
            'command': command,
            'language': language,
            'from_client': connection.client_id
        }, exclude_client=connection.client_id)
    
    async def _broadcast_to_session(self, session_id: str, message: Dict[str, Any], 
                                   exclude_client: Optional[str] = None):
        """Broadcast message to all clients in a session"""
        client_ids = self.session_connections.get(session_id, set())
        
        for client_id in client_ids:
            if client_id == exclude_client:
                continue
                
            connection = self.connections.get(client_id)
            if connection:
                await connection.send(message)
    
    async def cleanup_inactive_connections(self, timeout_minutes: int = 30):
        """Clean up inactive connections"""
        now = datetime.now()
        
        for client_id, connection in list(self.connections.items()):
            inactive_time = (now - connection.last_activity).total_seconds() / 60
            if inactive_time > timeout_minutes:
                logger.info(f"Cleaning up inactive connection {client_id}")
                await self.disconnect(client_id)

# Global WebSocket manager instance
ws_manager = WebSocketManager()
