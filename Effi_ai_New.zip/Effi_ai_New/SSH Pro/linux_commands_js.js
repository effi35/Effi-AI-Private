/**
 * Linux Commands Bank for SSH/SFTP Manager
 * בנק פקודות Linux עם חיפוש חכם והרצה בקליק
 */

// Linux commands database
const LinuxCommands = {
    // File Operations
    files: [
        {
            command: 'ls',
            description: 'רשימת קבצים בתיקייה',
            examples: ['ls', 'ls -la', 'ls -lh', 'ls -lt'],
            category: 'files'
        },
        {
            command: 'cd',
            description: 'שינוי תיקייה',
            examples: ['cd /home', 'cd ..', 'cd ~', 'cd -'],
            category: 'files'
        },
        {
            command: 'pwd',
            description: 'הצג תיקייה נוכחית',
            examples: ['pwd'],
            category: 'files'
        },
        {
            command: 'mkdir',
            description: 'יצירת תיקייה',
            examples: ['mkdir newfolder', 'mkdir -p path/to/folder'],
            category: 'files'
        },
        {
            command: 'rm',
            description: 'מחיקת קובץ או תיקייה',
            examples: ['rm file.txt', 'rm -rf folder', 'rm -i file.txt'],
            category: 'files'
        },
        {
            command: 'cp',
            description: 'העתקת קובץ או תיקייה',
            examples: ['cp source.txt dest.txt', 'cp -r folder1 folder2'],
            category: 'files'
        },
        {
            command: 'mv',
            description: 'הזז או שנה שם',
            examples: ['mv old.txt new.txt', 'mv file.txt /path/to/'],
            category: 'files'
        },
        {
            command: 'touch',
            description: 'יצירת קובץ ריק',
            examples: ['touch newfile.txt'],
            category: 'files'
        },
        {
            command: 'cat',
            description: 'הצג תוכן קובץ',
            examples: ['cat file.txt', 'cat file1.txt file2.txt'],
            category: 'files'
        },
        {
            command: 'less',
            description: 'הצג קובץ עם גלילה',
            examples: ['less large_file.txt'],
            category: 'files'
        },
        {
            command: 'head',
            description: 'הצג תחילת קובץ',
            examples: ['head file.txt', 'head -n 20 file.txt'],
            category: 'files'
        },
        {
            command: 'tail',
            description: 'הצג סוף קובץ',
            examples: ['tail file.txt', 'tail -f log.txt', 'tail -n 50 file.txt'],
            category: 'files'
        },
        {
            command: 'find',
            description: 'חיפוש קבצים',
            examples: ['find . -name "*.txt"', 'find / -type d -name config'],
            category: 'files'
        },
        {
            command: 'grep',
            description: 'חיפוש טקסט בקבצים',
            examples: ['grep "pattern" file.txt', 'grep -r "text" .', 'grep -i "case" file.txt'],
            category: 'files'
        },
        {
            command: 'chmod',
            description: 'שינוי הרשאות',
            examples: ['chmod 755 script.sh', 'chmod +x file.sh', 'chmod -R 644 folder'],
            category: 'files'
        },
        {
            command: 'chown',
            description: 'שינוי בעלות',
            examples: ['chown user:group file.txt', 'chown -R user folder'],
            category: 'files'
        }
    ],
    
    // System Information
    system: [
        {
            command: 'df',
            description: 'מקום פנוי בדיסק',
            examples: ['df -h', 'df -i'],
            category: 'system'
        },
        {
            command: 'du',
            description: 'גודל תיקיות',
            examples: ['du -sh *', 'du -h --max-depth=1'],
            category: 'system'
        },
        {
            command: 'free',
            description: 'זיכרון פנוי',
            examples: ['free -h', 'free -m'],
            category: 'system'
        },
        {
            command: 'top',
            description: 'תהליכים פעילים',
            examples: ['top', 'top -u username'],
            category: 'system'
        },
        {
            command: 'htop',
            description: 'תהליכים פעילים (משופר)',
            examples: ['htop'],
            category: 'system'
        },
        {
            command: 'ps',
            description: 'רשימת תהליכים',
            examples: ['ps aux', 'ps -ef', 'ps aux | grep process'],
            category: 'system'
        },
        {
            command: 'kill',
            description: 'עצור תהליך',
            examples: ['kill PID', 'kill -9 PID', 'killall process_name'],
            category: 'system'
        },
        {
            command: 'uname',
            description: 'מידע על המערכת',
            examples: ['uname -a', 'uname -r'],
            category: 'system'
        },
        {
            command: 'whoami',
            description: 'משתמש נוכחי',
            examples: ['whoami'],
            category: 'system'
        },
        {
            command: 'uptime',
            description: 'זמן פעילות',
            examples: ['uptime'],
            category: 'system'
        },
        {
            command: 'date',
            description: 'תאריך ושעה',
            examples: ['date', 'date "+%Y-%m-%d %H:%M:%S"'],
            category: 'system'
        },
        {
            command: 'history',
            description: 'היסטוריית פקודות',
            examples: ['history', 'history | grep command'],
            category: 'system'
        }
    ],
    
    // Network
    network: [
        {
            command: 'ping',
            description: 'בדיקת חיבור',
            examples: ['ping google.com', 'ping -c 4 8.8.8.8'],
            category: 'network'
        },
        {
            command: 'ifconfig',
            description: 'הגדרות רשת',
            examples: ['ifconfig', 'ifconfig eth0'],
            category: 'network'
        },
        {
            command: 'ip',
            description: 'הגדרות רשת (חדש)',
            examples: ['ip addr', 'ip route', 'ip link show'],
            category: 'network'
        },
        {
            command: 'netstat',
            description: 'חיבורי רשת',
            examples: ['netstat -tuln', 'netstat -anp'],
            category: 'network'
        },
        {
            command: 'ss',
            description: 'חיבורי רשת (חדש)',
            examples: ['ss -tuln', 'ss -ta'],
            category: 'network'
        },
        {
            command: 'wget',
            description: 'הורדת קבצים',
            examples: ['wget http://example.com/file.zip', 'wget -O output.html http://site.com'],
            category: 'network'
        },
        {
            command: 'curl',
            description: 'העברת נתונים',
            examples: ['curl http://example.com', 'curl -o file.html http://site.com'],
            category: 'network'
        },
        {
            command: 'ssh',
            description: 'חיבור מרוחק',
            examples: ['ssh user@host', 'ssh -p 2222 user@host'],
            category: 'network'
        },
        {
            command: 'scp',
            description: 'העתקה מרוחקת',
            examples: ['scp file.txt user@host:/path/', 'scp -r folder user@host:/'],
            category: 'network'
        },
        {
            command: 'nslookup',
            description: 'בדיקת DNS',
            examples: ['nslookup google.com', 'nslookup domain.com 8.8.8.8'],
            category: 'network'
        }
    ],
    
    // Package Management
    packages: [
        {
            command: 'apt',
            description: 'ניהול חבילות (Debian/Ubuntu)',
            examples: ['apt update', 'apt upgrade', 'apt install package', 'apt search package'],
            category: 'packages'
        },
        {
            command: 'yum',
            description: 'ניהול חבילות (RedHat/CentOS)',
            examples: ['yum update', 'yum install package', 'yum search package'],
            category: 'packages'
        },
        {
            command: 'dpkg',
            description: 'ניהול חבילות Debian',
            examples: ['dpkg -i package.deb', 'dpkg -l', 'dpkg -r package'],
            category: 'packages'
        },
        {
            command: 'snap',
            description: 'ניהול Snap packages',
            examples: ['snap install package', 'snap list', 'snap remove package'],
            category: 'packages'
        }
    ],
    
    // Text Processing
    text: [
        {
            command: 'sed',
            description: 'עיבוד טקסט',
            examples: ['sed "s/old/new/g" file.txt', 'sed -i "s/pattern/replace/g" file.txt'],
            category: 'text'
        },
        {
            command: 'awk',
            description: 'עיבוד טקסט מתקדם',
            examples: ['awk "{print $1}" file.txt', 'awk -F":" "{print $1}" /etc/passwd'],
            category: 'text'
        },
        {
            command: 'cut',
            description: 'חיתוך טקסט',
            examples: ['cut -d":" -f1 /etc/passwd', 'cut -c1-10 file.txt'],
            category: 'text'
        },
        {
            command: 'sort',
            description: 'מיון שורות',
            examples: ['sort file.txt', 'sort -n numbers.txt', 'sort -r file.txt'],
            category: 'text'
        },
        {
            command: 'uniq',
            description: 'הסרת כפילויות',
            examples: ['uniq file.txt', 'sort file.txt | uniq -c'],
            category: 'text'
        },
        {
            command: 'wc',
            description: 'ספירת מילים/שורות',
            examples: ['wc file.txt', 'wc -l file.txt', 'wc -w file.txt'],
            category: 'text'
        }
    ],
    
    // Archives
    archives: [
        {
            command: 'tar',
            description: 'ארכיון tar',
            examples: ['tar -czf archive.tar.gz folder/', 'tar -xzf archive.tar.gz', 'tar -tf archive.tar'],
            category: 'archives'
        },
        {
            command: 'zip',
            description: 'דחיסת ZIP',
            examples: ['zip archive.zip file1 file2', 'zip -r archive.zip folder/'],
            category: 'archives'
        },
        {
            command: 'unzip',
            description: 'חילוץ ZIP',
            examples: ['unzip archive.zip', 'unzip -l archive.zip', 'unzip archive.zip -d /path/'],
            category: 'archives'
        },
        {
            command: 'gzip',
            description: 'דחיסת GZIP',
            examples: ['gzip file.txt', 'gzip -d file.txt.gz'],
            category: 'archives'
        }
    ],
    
    // Process Management
    process: [
        {
            command: 'systemctl',
            description: 'ניהול שירותים',
            examples: ['systemctl status service', 'systemctl start service', 'systemctl enable service'],
            category: 'process'
        },
        {
            command: 'service',
            description: 'ניהול שירותים (ישן)',
            examples: ['service apache2 status', 'service nginx restart'],
            category: 'process'
        },
        {
            command: 'cron',
            description: 'משימות מתוזמנות',
            examples: ['crontab -e', 'crontab -l', 'crontab -r'],
            category: 'process'
        },
        {
            command: 'nohup',
            description: 'הרצה ברקע',
            examples: ['nohup command &', 'nohup python script.py > output.log &'],
            category: 'process'
        },
        {
            command: 'screen',
            description: 'סשן מרובה',
            examples: ['screen', 'screen -r', 'screen -ls'],
            category: 'process'
        },
        {
            command: 'tmux',
            description: 'מנהל סשנים',
            examples: ['tmux', 'tmux attach', 'tmux ls', 'tmux new -s session_name'],
            category: 'process'
        }
    ]
};

// Initialize Linux commands bank
function initializeLinuxCommands() {
    // Add commands UI if not exists
    addLinuxCommandsUI();
    
    // Load default commands
    loadDefaultCommands();
    
    console.log('✅ Linux commands bank initialized');
}

// Add Linux commands UI
function addLinuxCommandsUI() {
    // Create floating command palette
    const commandPalette = document.createElement('div');
    commandPalette.id = 'linuxCommandPalette';
    commandPalette.className = 'command-palette';
    commandPalette.style.display = 'none';
    commandPalette.innerHTML = `
        <div class="command-header">
            <h3>בנק פקודות Linux</h3>
            <button class="close-btn" onclick="toggleCommandPalette()">✕</button>
        </div>
        <div class="command-search">
            <input type="text" id="commandSearch" placeholder="חפש פקודה..." 
                   oninput="searchCommands(this.value)">
        </div>
        <div class="command-categories">
            <button class="cat-btn active" onclick="filterCategory('all')">הכל</button>
            <button class="cat-btn" onclick="filterCategory('files')">קבצים</button>
            <button class="cat-btn" onclick="filterCategory('system')">מערכת</button>
            <button class="cat-btn" onclick="filterCategory('network')">רשת</button>
            <button class="cat-btn" onclick="filterCategory('packages')">חבילות</button>
            <button class="cat-btn" onclick="filterCategory('text')">טקסט</button>
            <button class="cat-btn" onclick="filterCategory('archives')">ארכיונים</button>
            <button class="cat-btn" onclick="filterCategory('process')">תהליכים</button>
        </div>
        <div class="command-list" id="commandList"></div>
        <div class="command-footer">
            <button class="add-command-btn" onclick="showAddCommand()">+ הוסף פקודה</button>
        </div>
    `;
    
    document.body.appendChild(commandPalette);
    
    // Add button to open command palette
    const openBtn = document.createElement('button');
    openBtn.className = 'command-bank-btn';
    openBtn.innerHTML = '📚 פקודות';
    openBtn.onclick = toggleCommandPalette;
    openBtn.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: rgba(52, 152, 219, 0.2);
        border: 2px solid rgba(52, 152, 219, 0.4);
        border-radius: 8px;
        padding: 10px 20px;
        color: #3498db;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.2s;
        z-index: 100;
    `;
    
    document.body.appendChild(openBtn);
    
    // Add styles
    addCommandPaletteStyles();
}

// Add command palette styles
function addCommandPaletteStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .command-palette {
            position: fixed;
            bottom: 80px;
            left: 20px;
            width: 400px;
            max-height: 600px;
            background: rgba(30, 30, 30, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
            display: flex;
            flex-direction: column;
            z-index: 1001;
            animation: slideUp 0.3s ease-out;
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .command-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .command-header h3 {
            margin: 0;
            font-size: 1.1rem;
            color: #ecf0f1;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: #95a5a6;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 5px;
        }
        
        .close-btn:hover {
            color: #e74c3c;
        }
        
        .command-search {
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .command-search input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 8px 12px;
            color: white;
            font-size: 0.9rem;
        }
        
        .command-categories {
            display: flex;
            gap: 5px;
            padding: 10px 20px;
            flex-wrap: wrap;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .cat-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 5px 12px;
            color: #95a5a6;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .cat-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ecf0f1;
        }
        
        .cat-btn.active {
            background: rgba(52, 152, 219, 0.2);
            border-color: rgba(52, 152, 219, 0.4);
            color: #3498db;
        }
        
        .command-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        
        .command-item {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .command-item:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(52, 152, 219, 0.3);
            transform: translateX(-2px);
        }
        
        .command-name {
            font-family: 'Consolas', monospace;
            font-size: 1rem;
            color: #3498db;
            margin-bottom: 5px;
        }
        
        .command-desc {
            font-size: 0.85rem;
            color: #95a5a6;
            margin-bottom: 8px;
        }
        
        .command-examples {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        .example-chip {
            background: rgba(52, 152, 219, 0.1);
            border: 1px solid rgba(52, 152, 219, 0.2);
            border-radius: 4px;
            padding: 3px 8px;
            font-family: 'Consolas', monospace;
            font-size: 0.75rem;
            color: #3498db;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .example-chip:hover {
            background: rgba(52, 152, 219, 0.2);
            border-color: rgba(52, 152, 219, 0.4);
        }
        
        .command-footer {
            padding: 15px 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .add-command-btn {
            width: 100%;
            background: rgba(46, 204, 113, 0.2);
            border: 1px solid rgba(46, 204, 113, 0.4);
            border-radius: 6px;
            padding: 8px;
            color: #2ecc71;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .add-command-btn:hover {
            background: rgba(46, 204, 113, 0.3);
        }
        
        /* Mobile responsive */
        @media (max-width: 768px) {
            .command-palette {
                left: 10px;
                right: 10px;
                width: auto;
                bottom: 70px;
                max-height: 70vh;
            }
            
            .command-categories {
                overflow-x: auto;
                flex-wrap: nowrap;
                -webkit-overflow-scrolling: touch;
            }
        }
    `;
    document.head.appendChild(style);
}

// Load default commands
function loadDefaultCommands() {
    displayCommands('all');
}

// Display commands
function displayCommands(category = 'all') {
    const commandList = document.getElementById('commandList');
    if (!commandList) return;
    
    commandList.innerHTML = '';
    
    let commands = [];
    if (category === 'all') {
        // Flatten all commands
        Object.values(LinuxCommands).forEach(catCommands => {
            commands = commands.concat(catCommands);
        });
    } else {
        commands = LinuxCommands[category] || [];
    }
    
    commands.forEach(cmd => {
        const item = createCommandItem(cmd);
        commandList.appendChild(item);
    });
}

// Create command item
function createCommandItem(cmd) {
    const item = document.createElement('div');
    item.className = 'command-item';
    
    const examples = cmd.examples.map(ex => 
        `<span class="example-chip" onclick="executeCommand('${ex}')">${ex}</span>`
    ).join('');
    
    item.innerHTML = `
        <div class="command-name">${cmd.command}</div>
        <div class="command-desc">${cmd.description}</div>
        <div class="command-examples">${examples}</div>
    `;
    
    return item;
}

// Execute command
function executeCommand(command) {
    if (!AppState.terminal) {
        showNotification('הטרמינל לא פעיל', 'warning');
        return;
    }
    
    // Send command to terminal
    AppState.terminal.paste(command);
    
    // Optionally send Enter to execute
    if (confirm(`להריץ את הפקודה: ${command}?`)) {
        AppState.terminal.paste('\n');
    }
    
    // Close palette
    document.getElementById('linuxCommandPalette').style.display = 'none';
}

// Search commands
function searchCommands(query) {
    const commandList = document.getElementById('commandList');
    if (!commandList) return;
    
    commandList.innerHTML = '';
    
    if (!query) {
        displayCommands('all');
        return;
    }
    
    query = query.toLowerCase();
    
    // Search in all commands
    let results = [];
    Object.values(LinuxCommands).forEach(catCommands => {
        catCommands.forEach(cmd => {
            if (cmd.command.includes(query) || 
                cmd.description.includes(query) ||
                cmd.examples.some(ex => ex.includes(query))) {
                results.push(cmd);
            }
        });
    });
    
    // Display results
    if (results.length === 0) {
        commandList.innerHTML = '<div style="text-align: center; color: #95a5a6; padding: 20px;">לא נמצאו תוצאות</div>';
    } else {
        results.forEach(cmd => {
            const item = createCommandItem(cmd);
            commandList.appendChild(item);
        });
    }
}

// Filter by category
function filterCategory(category) {
    // Update active button
    document.querySelectorAll('.cat-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Display filtered commands
    displayCommands(category);
}

// Toggle command palette
function toggleCommandPalette() {
    const palette = document.getElementById('linuxCommandPalette');
    if (!palette) return;
    
    if (palette.style.display === 'none') {
        palette.style.display = 'flex';
        document.getElementById('commandSearch').focus();
    } else {
        palette.style.display = 'none';
    }
}

// Show add command dialog
function showAddCommand() {
    const dialog = document.createElement('div');
    dialog.className = 'modal-overlay';
    dialog.innerHTML = `
        <div class="modal-content">
            <h3>הוסף פקודה חדשה</h3>
            <input type="text" id="newCommand" placeholder="פקודה" style="width: 100%; margin-bottom: 10px;">
            <input type="text" id="newDescription" placeholder="תיאור" style="width: 100%; margin-bottom: 10px;">
            <input type="text" id="newExample" placeholder="דוגמה" style="width: 100%; margin-bottom: 10px;">
            <select id="newCategory" style="width: 100%; margin-bottom: 20px;">
                <option value="files">קבצים</option>
                <option value="system">מערכת</option>
                <option value="network">רשת</option>
                <option value="packages">חבילות</option>
                <option value="text">טקסט</option>
                <option value="archives">ארכיונים</option>
                <option value="process">תהליכים</option>
            </select>
            <div style="display: flex; gap: 10px;">
                <button onclick="saveNewCommand()" style="flex: 1; background: #2ecc71; color: white; border: none; padding: 8px; border-radius: 4px;">שמור</button>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="flex: 1; background: #e74c3c; color: white; border: none; padding: 8px; border-radius: 4px;">ביטול</button>
            </div>
        </div>
    `;
    
    // Add modal styles
    const style = document.createElement('style');
    style.textContent = `
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        }
        
        .modal-content {
            background: #2c3e50;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 20px;
            width: 400px;
            max-width: 90%;
        }
        
        .modal-content h3 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #ecf0f1;
        }
        
        .modal-content input,
        .modal-content select {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            padding: 8px;
            color: white;
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(dialog);
}

// Save new command
async function saveNewCommand() {
    const command = document.getElementById('newCommand').value;
    const description = document.getElementById('newDescription').value;
    const example = document.getElementById('newExample').value;
    const category = document.getElementById('newCategory').value;
    
    if (!command || !description) {
        showNotification('נא למלא פקודה ותיאור', 'warning');
        return;
    }
    
    // Add to local storage (in real app, would save to database)
    const newCmd = {
        command: command,
        description: description,
        examples: example ? [example] : [],
        category: category
    };
    
    // Add to commands
    if (!LinuxCommands[category]) {
        LinuxCommands[category] = [];
    }
    LinuxCommands[category].push(newCmd);
    
    // Refresh display
    displayCommands('all');
    
    // Close dialog
    document.querySelector('.modal-overlay').remove();
    
    showNotification('הפקודה נוספה בהצלחה', 'success');
}

// Add keyboard shortcut
document.addEventListener('keydown', (e) => {
    // Ctrl+K to open command palette
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        toggleCommandPalette();
    }
});

// Export functions
window.initializeLinuxCommands = initializeLinuxCommands;
window.toggleCommandPalette = toggleCommandPalette;
window.searchCommands = searchCommands;
window.filterCategory = filterCategory;
window.executeCommand = executeCommand;
window.showAddCommand = showAddCommand;
window.saveNewCommand = saveNewCommand;
