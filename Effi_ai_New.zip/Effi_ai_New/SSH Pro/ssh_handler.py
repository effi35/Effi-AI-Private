"""
SSH Handler for SSH/SFTP Manager
מטפל בכל חיבורי ה-SSH כולל tmux להמשכיות סשן
"""

import asyncio
import asyncssh
import logging
from typing import Dict, Optional, Any
from datetime import datetime
import subprocess
import os
import pty
import select
import termios
import struct
import fcntl

logger = logging.getLogger(__name__)

class SSHSession:
    """Manages individual SSH sessions with tmux support"""
    
    def __init__(self, session_id: str, connection_params: Dict[str, Any]):
        self.session_id = session_id
        self.connection_params = connection_params
        self.ssh_client: Optional[asyncssh.SSHClientConnection] = None
        self.tmux_session_name = f"ssh_session_{session_id}"
        self.master_fd = None
        self.slave_fd = None
        self.process = None
        self.connected = False
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
        
    async def connect(self) -> bool:
        """Establish SSH connection with tmux session"""
        try:
            logger.info(f"Connecting to {self.connection_params['host']}...")
            
            # Connect using asyncssh
            connect_params = {
                'host': self.connection_params['host'],
                'port': self.connection_params.get('port', 22),
                'username': self.connection_params['username'],
                'known_hosts': None  # For development - in production use proper host verification
            }
            
            # Add authentication method
            if 'password' in self.connection_params:
                connect_params['password'] = self.connection_params['password']
            elif 'key_file' in self.connection_params:
                connect_params['client_keys'] = [self.connection_params['key_file']]
            
            self.ssh_client = await asyncssh.connect(**connect_params)
            
            # Check if tmux is available on remote
            result = await self.ssh_client.run('which tmux', check=False)
            has_tmux = result.exit_status == 0
            
            if has_tmux:
                # Create or attach to tmux session
                await self._setup_tmux_session()
            else:
                logger.warning("tmux not available on remote host, using direct connection")
            
            self.connected = True
            logger.info(f"Successfully connected to {self.connection_params['host']}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect: {str(e)}")
            self.connected = False
            return False
    
    async def _setup_tmux_session(self):
        """Set up tmux session for persistence"""
        try:
            # Check if tmux session exists
            check_cmd = f"tmux has-session -t {self.tmux_session_name} 2>/dev/null"
            result = await self.ssh_client.run(check_cmd, check=False)
            
            if result.exit_status != 0:
                # Create new tmux session
                create_cmd = f"tmux new-session -d -s {self.tmux_session_name}"
                await self.ssh_client.run(create_cmd)
                logger.info(f"Created new tmux session: {self.tmux_session_name}")
            else:
                logger.info(f"Attaching to existing tmux session: {self.tmux_session_name}")
                
        except Exception as e:
            logger.error(f"Failed to setup tmux session: {str(e)}")
    
    async def execute_command(self, command: str) -> Dict[str, Any]:
        """Execute command in SSH session"""
        if not self.connected or not self.ssh_client:
            return {
                'success': False,
                'error': 'Not connected'
            }
        
        try:
            self.last_activity = datetime.now()
            
            # If tmux is available, send command to tmux session
            if await self._has_tmux():
                tmux_cmd = f"tmux send-keys -t {self.tmux_session_name} '{command}' Enter"
                result = await self.ssh_client.run(tmux_cmd)
                
                # Get output from tmux
                capture_cmd = f"tmux capture-pane -t {self.tmux_session_name} -p"
                output_result = await self.ssh_client.run(capture_cmd)
                
                return {
                    'success': True,
                    'output': output_result.stdout,
                    'exit_code': 0
                }
            else:
                # Direct execution
                result = await self.ssh_client.run(command)
                return {
                    'success': True,
                    'output': result.stdout,
                    'exit_code': result.exit_status
                }
                
        except Exception as e:
            logger.error(f"Command execution failed: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def _has_tmux(self) -> bool:
        """Check if tmux is available"""
        if not self.ssh_client:
            return False
        result = await self.ssh_client.run('which tmux', check=False)
        return result.exit_status == 0
    
    async def create_interactive_shell(self):
        """Create interactive shell with PTY"""
        if not self.connected or not self.ssh_client:
            return None
            
        try:
            # Create PTY for interactive session
            self.master_fd, self.slave_fd = pty.openpty()
            
            # Set terminal attributes
            attrs = termios.tcgetattr(self.master_fd)
            attrs[3] = attrs[3] & ~termios.ECHO
            termios.tcsetattr(self.master_fd, termios.TCSADRAIN, attrs)
            
            # Make non-blocking
            fcntl.fcntl(self.master_fd, fcntl.F_SETFL, os.O_NONBLOCK)
            
            # Start interactive shell
            if await self._has_tmux():
                # Attach to tmux session
                shell_cmd = f"tmux attach-session -t {self.tmux_session_name}"
            else:
                # Regular shell
                shell_cmd = "$SHELL"
            
            # Create SSH channel
            channel = await self.ssh_client.create_session(
                term_type='xterm-256color',
                term_size=(80, 24)
            )
            
            return {
                'master_fd': self.master_fd,
                'channel': channel
            }
            
        except Exception as e:
            logger.error(f"Failed to create interactive shell: {str(e)}")
            return None
    
    async def resize_terminal(self, cols: int, rows: int):
        """Resize terminal window"""
        if self.master_fd:
            try:
                # Send terminal resize signal
                fcntl.ioctl(
                    self.master_fd,
                    termios.TIOCSWINSZ,
                    struct.pack('HHHH', rows, cols, 0, 0)
                )
            except Exception as e:
                logger.error(f"Failed to resize terminal: {str(e)}")
    
    async def disconnect(self):
        """Disconnect SSH session but keep tmux alive"""
        try:
            if self.ssh_client:
                # Detach from tmux if connected
                if await self._has_tmux():
                    detach_cmd = f"tmux detach-client -t {self.tmux_session_name}"
                    await self.ssh_client.run(detach_cmd, check=False)
                
                # Close SSH connection
                self.ssh_client.close()
                await self.ssh_client.wait_closed()
                
            if self.master_fd:
                os.close(self.master_fd)
            if self.slave_fd:
                os.close(self.slave_fd)
                
            self.connected = False
            logger.info(f"Disconnected session {self.session_id}")
            
        except Exception as e:
            logger.error(f"Error during disconnect: {str(e)}")
    
    def get_status(self) -> Dict[str, Any]:
        """Get session status"""
        return {
            'session_id': self.session_id,
            'connected': self.connected,
            'host': self.connection_params['host'],
            'username': self.connection_params['username'],
            'created_at': self.created_at.isoformat(),
            'last_activity': self.last_activity.isoformat(),
            'tmux_session': self.tmux_session_name
        }


class SSHManager:
    """Manages all SSH sessions"""
    
    def __init__(self):
        self.sessions: Dict[str, SSHSession] = {}
        
    async def create_session(self, session_id: str, connection_params: Dict[str, Any]) -> SSHSession:
        """Create new SSH session"""
        session = SSHSession(session_id, connection_params)
        if await session.connect():
            self.sessions[session_id] = session
            return session
        else:
            raise Exception("Failed to establish SSH connection")
    
    def get_session(self, session_id: str) -> Optional[SSHSession]:
        """Get existing session"""
        return self.sessions.get(session_id)
    
    async def disconnect_session(self, session_id: str):
        """Disconnect and remove session"""
        session = self.sessions.get(session_id)
        if session:
            await session.disconnect()
            del self.sessions[session_id]
    
    def list_sessions(self) -> list:
        """List all active sessions"""
        return [session.get_status() for session in self.sessions.values()]
    
    async def cleanup_inactive_sessions(self, timeout_minutes: int = 30):
        """Clean up inactive sessions"""
        now = datetime.now()
        for session_id, session in list(self.sessions.items()):
            inactive_time = (now - session.last_activity).total_seconds() / 60
            if inactive_time > timeout_minutes:
                logger.info(f"Cleaning up inactive session {session_id}")
                await self.disconnect_session(session_id)

# Global SSH manager instance
ssh_manager = SSHManager()
