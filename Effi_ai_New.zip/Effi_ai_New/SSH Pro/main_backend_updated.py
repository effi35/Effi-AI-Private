"""
FastAPI Backend for SSH/SFTP Manager with Authentication
שרת FastAPI עם מערכת הרשאות פשוטה
"""

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, status, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import uvicorn

# Import our modules
from ssh_handler import ssh_manager
from sftp_handler import SFTPHandler
from websocket_handler import ws_manager
from sync_manager import SyncManager
from auth_manager import auth_manager

# Initialize FastAPI app
app = FastAPI(
    title="SSH/SFTP Manager API",
    description="מערכת ניהול SSH/SFTP מתקדמת",
    version="3.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Initialize managers
sync_manager = SyncManager()

# Models
class LoginRequest(BaseModel):
    username: str
    password: str

class ConnectionRequest(BaseModel):
    host: str
    port: int = 22
    username: str
    password: Optional[str] = None
    key_file: Optional[str] = None

class CommandRequest(BaseModel):
    command: str
    session_id: str

class FileTransferRequest(BaseModel):
    source: str
    destination: str
    direction: str  # "upload" or "download"

class AliasRequest(BaseModel):
    name: str
    command: str
    category: str = "general"
    description: Optional[str] = None

# Authentication dependency
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token and return user"""
    token = credentials.credentials
    
    # For simple auth, we'll use session validation
    user = await auth_manager.validate_session(token)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

# Mount static files
static_path = Path(__file__).parent.parent / "assets"
if static_path.exists():
    app.mount("/assets", StaticFiles(directory=str(static_path)), name="assets")

# Root endpoint
@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main HTML file"""
    index_path = Path(__file__).parent.parent / "index.html"
    if index_path.exists():
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    else:
        return HTMLResponse(content="<h1>SSH/SFTP Manager API</h1>")

# Authentication endpoints
@app.post("/api/auth/login")
async def login(request: LoginRequest, req: Request):
    """Login user"""
    ip_address = req.client.host if req.client else ""
    user_agent = req.headers.get("user-agent", "")
    
    session = await auth_manager.login(
        request.username, 
        request.password,
        ip_address,
        user_agent
    )
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )
    
    return {
        "access_token": session["session_id"],
        "token_type": "bearer",
        "user": {
            "username": session["username"],
            "full_name": session["full_name"],
            "role": session["role"]
        }
    }

@app.post("/api/auth/logout")
async def logout(user: Dict = Depends(get_current_user)):
    """Logout user"""
    await auth_manager.logout(user["session_id"])
    return {"message": "Logged out successfully"}

@app.get("/api/auth/me")
async def get_me(user: Dict = Depends(get_current_user)):
    """Get current user info"""
    return {
        "username": user["username"],
        "full_name": user["full_name"],
        "role": user["role"]
    }

# User management (admin only)
@app.get("/api/users")
async def list_users(user: Dict = Depends(get_current_user)):
    """List all users (admin only)"""
    if not auth_manager.is_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    
    users = await auth_manager.list_users()
    return {"users": users}

@app.post("/api/users")
async def create_user(
    username: str,
    password: str,
    full_name: str = "",
    email: str = "",
    role: str = "user",
    user: Dict = Depends(get_current_user)
):
    """Create new user (admin only)"""
    if not auth_manager.is_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    
    success = await auth_manager.create_user(
        username, password, full_name, email, role
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to create user (limit reached or user exists)"
        )
    
    return {"message": "User created successfully"}

# API endpoints
@app.get("/api/status")
async def get_status(user: Dict = Depends(get_current_user)):
    """Get system status"""
    return {
        "status": "active",
        "version": "3.0.0",
        "user": user["username"],
        "active_sessions": len(ssh_manager.sessions),
        "uptime": "0:00:00"
    }

@app.post("/api/connect")
async def connect_ssh(
    request: ConnectionRequest,
    user: Dict = Depends(get_current_user)
):
    """Establish SSH connection"""
    try:
        session_id = f"{user['username']}_{datetime.now().timestamp()}"
        session = await ssh_manager.create_session(session_id, request.dict())
        
        # Update sync
        await sync_manager.sync_session_start(session_id, user["username"])
        
        return {
            "session_id": session_id,
            "status": "connected",
            "message": "התחברות הצליחה"
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@app.post("/api/disconnect/{session_id}")
async def disconnect_ssh(
    session_id: str,
    user: Dict = Depends(get_current_user)
):
    """Disconnect SSH session"""
    await ssh_manager.disconnect_session(session_id)
    return {
        "status": "disconnected",
        "message": "ההתנתקות הצליחה"
    }

@app.get("/api/sessions")
async def list_sessions(user: Dict = Depends(get_current_user)):
    """List user's SSH sessions"""
    all_sessions = ssh_manager.list_sessions()
    
    # Filter by user if not admin
    if not auth_manager.is_admin(user):
        user_sessions = [s for s in all_sessions if s["session_id"].startswith(user["username"])]
        return {"sessions": user_sessions}
    
    return {"sessions": all_sessions}

@app.post("/api/command")
async def execute_command(
    request: CommandRequest,
    user: Dict = Depends(get_current_user)
):
    """Execute command in SSH session"""
    session = ssh_manager.get_session(request.session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Check permission
    if not auth_manager.is_admin(user) and not request.session_id.startswith(user["username"]):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    result = await session.execute_command(request.command)
    
    # Log command
    await sync_manager.add_command(
        request.session_id, 
        request.command,
        user["username"],
        result.get("exit_code")
    )
    
    return result

# WebSocket endpoint for terminal
@app.websocket("/ws/terminal/{client_id}")
async def websocket_terminal(
    websocket: WebSocket, 
    client_id: str,
    token: str = None
):
    """WebSocket for terminal interaction"""
    # Validate token
    if token:
        user = await auth_manager.validate_session(token)
        if not user:
            await websocket.close(code=1008, reason="Unauthorized")
            return
    else:
        await websocket.close(code=1008, reason="Token required")
        return
    
    await ws_manager.connect(websocket, client_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            await ws_manager.handle_message(client_id, data)
    except WebSocketDisconnect:
        await ws_manager.disconnect(client_id)

# File management endpoints
@app.get("/api/files/list")
async def list_files(
    path: str = "/",
    session_id: str = None,
    user: Dict = Depends(get_current_user)
):
    """List files in directory"""
    if not session_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Session ID required"
        )
    
    session = ssh_manager.get_session(session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    sftp = SFTPHandler(session)
    try:
        files = await sftp.list_directory(path)
        return {
            "path": path,
            "files": files
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@app.post("/api/files/upload")
async def upload_file(
    request: FileTransferRequest,
    user: Dict = Depends(get_current_user)
):
    """Upload file via SFTP"""
    # Implementation will be handled by WebSocket for progress
    return {
        "status": "initiated",
        "message": "Use WebSocket for file transfer with progress"
    }

@app.post("/api/files/download")
async def download_file(
    request: FileTransferRequest,
    user: Dict = Depends(get_current_user)
):
    """Download file via SFTP"""
    # Implementation will be handled by WebSocket for progress
    return {
        "status": "initiated",
        "message": "Use WebSocket for file transfer with progress"
    }

# Aliases management
@app.get("/api/aliases")
async def get_aliases(
    category: Optional[str] = None,
    user: Dict = Depends(get_current_user)
):
    """Get all command aliases"""
    aliases = await sync_manager.get_aliases(category)
    return {"aliases": aliases}

@app.post("/api/aliases")
async def create_alias(
    alias: AliasRequest,
    user: Dict = Depends(get_current_user)
):
    """Create new alias"""
    await sync_manager.add_alias(
        alias.name,
        alias.command,
        alias.category,
        alias.description,
        user["username"]
    )
    return {
        "status": "created",
        "alias": alias.dict()
    }

@app.delete("/api/aliases/{name}")
async def delete_alias(
    name: str,
    user: Dict = Depends(get_current_user)
):
    """Delete alias"""
    await sync_manager.delete_alias(name)
    return {
        "status": "deleted",
        "name": name
    }

# Linux commands bank
@app.get("/api/commands/search")
async def search_commands(
    query: str,
    user: Dict = Depends(get_current_user)
):
    """Search Linux commands"""
    commands = await sync_manager.search_linux_commands(query)
    return {"commands": commands}

@app.post("/api/commands")
async def add_command(
    command: str,
    description: str = "",
    category: str = "general",
    examples: str = "",
    tags: List[str] = [],
    user: Dict = Depends(get_current_user)
):
    """Add Linux command to bank"""
    await sync_manager.add_linux_command(
        command, description, category, examples, tags
    )
    return {"status": "added"}

# Connection profiles
@app.get("/api/profiles")
async def get_profiles(user: Dict = Depends(get_current_user)):
    """Get connection profiles"""
    profiles = await sync_manager.get_connection_profiles()
    return {"profiles": profiles}

@app.post("/api/profiles")
async def save_profile(
    profile: Dict[str, Any],
    user: Dict = Depends(get_current_user)
):
    """Save connection profile"""
    await sync_manager.save_connection_profile(profile)
    return {"status": "saved"}

# Chat functionality
@app.get("/api/chat/{session_id}")
async def get_chat_history(
    session_id: str,
    limit: int = 50,
    user: Dict = Depends(get_current_user)
):
    """Get chat history for session"""
    messages = await sync_manager.get_chat_history(session_id, limit)
    return {"messages": messages}

@app.post("/api/chat/{session_id}")
async def send_chat_message(
    session_id: str,
    message: str,
    message_type: str = "text",
    user: Dict = Depends(get_current_user)
):
    """Send chat message"""
    await sync_manager.add_chat_message(
        session_id,
        message,
        user["username"],
        message_type
    )
    return {"status": "sent"}

# Settings
@app.get("/api/settings/{key}")
async def get_setting(
    key: str,
    user: Dict = Depends(get_current_user)
):
    """Get setting value"""
    value = await sync_manager.get_setting(key)
    return {"key": key, "value": value}

@app.post("/api/settings/{key}")
async def save_setting(
    key: str,
    value: Any,
    user: Dict = Depends(get_current_user)
):
    """Save setting"""
    await sync_manager.save_setting(key, value)
    return {"status": "saved"}

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    # Initialize sync manager
    await sync_manager.initialize()
    
    # Clean up expired sessions
    await auth_manager.cleanup_expired_sessions()
    
    # Start background tasks
    asyncio.create_task(cleanup_task())
    
    print("🚀 SSH/SFTP Manager API started on port 5000")

# Background cleanup task
async def cleanup_task():
    """Periodic cleanup"""
    while True:
        await asyncio.sleep(3600)  # Every hour
        
        # Clean up inactive SSH sessions
        await ssh_manager.cleanup_inactive_sessions()
        
        # Clean up expired auth sessions
        await auth_manager.cleanup_expired_sessions()
        
        # Clean up old data
        await sync_manager.cleanup_old_data()

# Run the server
if __name__ == "__main__":
    # Ensure logs directory exists
    Path("../logs").mkdir(exist_ok=True)
    
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=5000,
        log_level="info",
        access_log=True
    )
