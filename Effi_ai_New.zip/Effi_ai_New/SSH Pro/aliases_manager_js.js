/**
 * Aliases Manager for SSH/SFTP Manager
 * מנהל קיצורים מתקדם עם קטגוריות וסינכרון
 */

// Aliases state
const AliasesState = {
    aliases: new Map(),
    categories: ['general', 'files', 'system', 'network', 'git', 'docker', 'personal'],
    selectedCategory: 'all',
    draggedAlias: null,
    positions: new Map() // For custom positioning
};

// Initialize aliases manager
async function initializeAliasesManager() {
    setupAliasesUI();
    await loadAliases();
    setupAliasesEventListeners();
    
    console.log('✅ Aliases manager initialized');
}

// Set up aliases UI
function setupAliasesUI() {
    // Update existing aliases section or create new one
    const aliasesSection = document.querySelector('.aliases-section');
    if (!aliasesSection) return;
    
    // Add enhanced UI
    aliasesSection.innerHTML = `
        <div class="aliases-header">
            <h3>קיצורים מהירים</h3>
            <div class="aliases-actions">
                <button class="icon-btn" onclick="showAddAlias()" title="הוסף קיצור">➕</button>
                <button class="icon-btn" onclick="importAliases()" title="ייבוא">📥</button>
                <button class="icon-btn" onclick="exportAliases()" title="ייצוא">📤</button>
            </div>
        </div>
        <div class="aliases-search">
            <input type="text" placeholder="חפש קיצור..." oninput="searchAliases(this.value)">
        </div>
        <div class="aliases-categories">
            <select onchange="filterAliasesByCategory(this.value)">
                <option value="all">כל הקטגוריות</option>
                <option value="general">כללי</option>
                <option value="files">קבצים</option>
                <option value="system">מערכת</option>
                <option value="network">רשת</option>
                <option value="git">Git</option>
                <option value="docker">Docker</option>
                <option value="personal">אישי</option>
            </select>
        </div>
        <div class="aliases-grid" id="aliasesGrid">
            <div class="loading">טוען קיצורים...</div>
        </div>
        <div class="aliases-canvas" id="aliasesCanvas" style="display: none;">
            <!-- For positioned aliases -->
        </div>
    `;
    
    // Add styles
    addAliasesStyles();
}

// Add aliases styles
function addAliasesStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .aliases-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .aliases-header h3 {
            margin: 0;
            font-size: 1rem;
            color: #ecf0f1;
        }
        
        .aliases-actions {
            display: flex;
            gap: 5px;
        }
        
        .icon-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            padding: 5px 8px;
            color: #95a5a6;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.9rem;
        }
        
        .icon-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ecf0f1;
        }
        
        .aliases-search {
            margin-bottom: 10px;
        }
        
        .aliases-search input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 6px 10px;
            color: white;
            font-size: 0.85rem;
        }
        
        .aliases-categories {
            margin-bottom: 15px;
        }
        
        .aliases-categories select {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 6px 10px;
            color: white;
            font-size: 0.85rem;
        }
        
        .aliases-grid {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .alias-item {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 6px;
            padding: 10px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        
        .alias-item:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(52, 152, 219, 0.3);
            transform: translateX(-2px);
        }
        
        .alias-item.dragging {
            opacity: 0.5;
            cursor: move;
        }
        
        .alias-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        
        .alias-name {
            font-weight: 600;
            color: #3498db;
            font-family: 'Consolas', monospace;
        }
        
        .alias-category {
            font-size: 0.7rem;
            background: rgba(52, 152, 219, 0.2);
            border-radius: 10px;
            padding: 2px 8px;
            color: #3498db;
        }
        
        .alias-command {
            font-size: 0.85rem;
            color: #95a5a6;
            font-family: 'Consolas', monospace;
            word-break: break-all;
        }
        
        .alias-actions {
            position: absolute;
            top: 5px;
            right: 5px;
            display: none;
            gap: 5px;
        }
        
        .alias-item:hover .alias-actions {
            display: flex;
        }
        
        .alias-action-btn {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 3px;
            padding: 3px 6px;
            color: #95a5a6;
            cursor: pointer;
            font-size: 0.75rem;
        }
        
        .alias-action-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: #ecf0f1;
        }
        
        .alias-action-btn.delete:hover {
            background: rgba(231, 76, 60, 0.3);
            color: #e74c3c;
        }
        
        /* Canvas mode for positioned aliases */
        .aliases-canvas {
            position: relative;
            width: 100%;
            height: 400px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .alias-positioned {
            position: absolute;
            background: rgba(52, 152, 219, 0.15);
            border: 1px solid rgba(52, 152, 219, 0.3);
            border-radius: 6px;
            padding: 8px 12px;
            cursor: move;
            transition: all 0.2s;
            user-select: none;
        }
        
        .alias-positioned:hover {
            background: rgba(52, 152, 219, 0.25);
            border-color: rgba(52, 152, 219, 0.5);
            z-index: 10;
        }
        
        /* Edit dialog */
        .alias-dialog {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #2c3e50;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 20px;
            width: 400px;
            max-width: 90%;
            z-index: 2000;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        .alias-dialog h3 {
            margin: 0 0 20px 0;
            color: #ecf0f1;
        }
        
        .alias-dialog input,
        .alias-dialog select,
        .alias-dialog textarea {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            padding: 8px;
            color: white;
            margin-bottom: 15px;
        }
        
        .alias-dialog textarea {
            min-height: 60px;
            resize: vertical;
            font-family: 'Consolas', monospace;
        }
        
        .alias-dialog-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .alias-dialog-actions button {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .btn-save {
            background: #2ecc71;
            color: white;
        }
        
        .btn-save:hover {
            background: #27ae60;
        }
        
        .btn-cancel {
            background: rgba(255, 255, 255, 0.1);
            color: #95a5a6;
        }
        
        .btn-cancel:hover {
            background: rgba(255, 255, 255, 0.15);
            color: #ecf0f1;
        }
        
        /* View mode toggle */
        .view-mode-toggle {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            gap: 5px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 4px;
            padding: 2px;
        }
        
        .view-mode-btn {
            background: none;
            border: none;
            padding: 5px 10px;
            color: #95a5a6;
            cursor: pointer;
            border-radius: 3px;
            transition: all 0.2s;
        }
        
        .view-mode-btn.active {
            background: rgba(52, 152, 219, 0.2);
            color: #3498db;
        }
    `;
    document.head.appendChild(style);
}

// Load aliases
async function loadAliases() {
    try {
        // Request aliases from server
        if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
            AppState.socket.send(JSON.stringify({
                type: 'sync',
                sync_type: 'aliases'
            }));
        }
        
        // Load from local storage as fallback
        const savedAliases = localStorage.getItem('aliases');
        if (savedAliases) {
            const aliasesArray = JSON.parse(savedAliases);
            aliasesArray.forEach(alias => {
                AliasesState.aliases.set(alias.name, alias);
            });
            displayAliases();
        }
        
        // Load default aliases if empty
        if (AliasesState.aliases.size === 0) {
            loadDefaultAliases();
        }
        
    } catch (error) {
        console.error('Error loading aliases:', error);
        loadDefaultAliases();
    }
}

// Load default aliases
function loadDefaultAliases() {
    const defaults = [
        { name: 'll', command: 'ls -la --color=auto', category: 'files' },
        { name: 'la', command: 'ls -A', category: 'files' },
        { name: 'l', command: 'ls -CF', category: 'files' },
        { name: '..', command: 'cd ..', category: 'files' },
        { name: '...', command: 'cd ../..', category: 'files' },
        { name: 'update', command: 'sudo apt update && sudo apt upgrade', category: 'system' },
        { name: 'install', command: 'sudo apt install', category: 'system' },
        { name: 'search', command: 'apt search', category: 'system' },
        { name: 'df', command: 'df -h', category: 'system' },
        { name: 'du', command: 'du -sh *', category: 'system' },
        { name: 'free', command: 'free -h', category: 'system' },
        { name: 'gs', command: 'git status', category: 'git' },
        { name: 'ga', command: 'git add', category: 'git' },
        { name: 'gc', command: 'git commit -m', category: 'git' },
        { name: 'gp', command: 'git push', category: 'git' },
        { name: 'gl', command: 'git log --oneline', category: 'git' },
        { name: 'dps', command: 'docker ps', category: 'docker' },
        { name: 'dpsa', command: 'docker ps -a', category: 'docker' },
        { name: 'di', command: 'docker images', category: 'docker' },
        { name: 'dex', command: 'docker exec -it', category: 'docker' }
    ];
    
    defaults.forEach(alias => {
        AliasesState.aliases.set(alias.name, alias);
    });
    
    displayAliases();
    saveAliasesToLocal();
}

// Display aliases
function displayAliases(filter = '') {
    const grid = document.getElementById('aliasesGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    let aliases = Array.from(AliasesState.aliases.values());
    
    // Filter by search
    if (filter) {
        filter = filter.toLowerCase();
        aliases = aliases.filter(alias => 
            alias.name.toLowerCase().includes(filter) ||
            alias.command.toLowerCase().includes(filter) ||
            (alias.description && alias.description.toLowerCase().includes(filter))
        );
    }
    
    // Filter by category
    if (AliasesState.selectedCategory !== 'all') {
        aliases = aliases.filter(alias => alias.category === AliasesState.selectedCategory);
    }
    
    // Sort by name
    aliases.sort((a, b) => a.name.localeCompare(b.name));
    
    // Display
    if (aliases.length === 0) {
        grid.innerHTML = '<div style="text-align: center; color: #95a5a6; padding: 20px;">אין קיצורים</div>';
    } else {
        aliases.forEach(alias => {
            const item = createAliasItem(alias);
            grid.appendChild(item);
        });
    }
}

// Create alias item
function createAliasItem(alias) {
    const item = document.createElement('div');
    item.className = 'alias-item';
    item.draggable = true;
    item.dataset.name = alias.name;
    
    item.innerHTML = `
        <div class="alias-header">
            <span class="alias-name">${alias.name}</span>
            <span class="alias-category">${alias.category || 'general'}</span>
        </div>
        <div class="alias-command">${alias.command}</div>
        <div class="alias-actions">
            <button class="alias-action-btn" onclick="editAlias('${alias.name}')" title="ערוך">✏️</button>
            <button class="alias-action-btn" onclick="copyAlias('${alias.name}')" title="העתק">📋</button>
            <button class="alias-action-btn delete" onclick="deleteAlias('${alias.name}')" title="מחק">🗑️</button>
        </div>
    `;
    
    // Click to execute
    item.addEventListener('click', (e) => {
        if (!e.target.classList.contains('alias-action-btn')) {
            executeAlias(alias.name);
        }
    });
    
    // Drag events
    item.addEventListener('dragstart', (e) => {
        AliasesState.draggedAlias = alias;
        e.dataTransfer.effectAllowed = 'move';
        item.classList.add('dragging');
    });
    
    item.addEventListener('dragend', () => {
        item.classList.remove('dragging');
        AliasesState.draggedAlias = null;
    });
    
    return item;
}

// Execute alias
function executeAlias(name) {
    const alias = AliasesState.aliases.get(name);
    if (!alias) return;
    
    if (!AppState.terminal) {
        showNotification('הטרמינל לא פעיל', 'warning');
        return;
    }
    
    // Paste command to terminal
    AppState.terminal.paste(alias.command);
    
    // Show notification
    showNotification(`הקיצור "${name}" הודבק בטרמינל`, 'info');
}

// Show add alias dialog
function showAddAlias() {
    const dialog = createAliasDialog('הוסף קיצור חדש');
    document.body.appendChild(dialog);
}

// Edit alias
function editAlias(name) {
    const alias = AliasesState.aliases.get(name);
    if (!alias) return;
    
    const dialog = createAliasDialog('ערוך קיצור', alias);
    document.body.appendChild(dialog);
}

// Create alias dialog
function createAliasDialog(title, alias = null) {
    const dialog = document.createElement('div');
    dialog.className = 'alias-dialog';
    
    dialog.innerHTML = `
        <h3>${title}</h3>
        <input type="text" id="aliasName" placeholder="שם הקיצור" value="${alias ? alias.name : ''}" ${alias ? 'readonly' : ''}>
        <textarea id="aliasCommand" placeholder="הפקודה">${alias ? alias.command : ''}</textarea>
        <input type="text" id="aliasDescription" placeholder="תיאור (אופציונלי)" value="${alias && alias.description ? alias.description : ''}">
        <select id="aliasCategory">
            <option value="general" ${alias && alias.category === 'general' ? 'selected' : ''}>כללי</option>
            <option value="files" ${alias && alias.category === 'files' ? 'selected' : ''}>קבצים</option>
            <option value="system" ${alias && alias.category === 'system' ? 'selected' : ''}>מערכת</option>
            <option value="network" ${alias && alias.category === 'network' ? 'selected' : ''}>רשת</option>
            <option value="git" ${alias && alias.category === 'git' ? 'selected' : ''}>Git</option>
            <option value="docker" ${alias && alias.category === 'docker' ? 'selected' : ''}>Docker</option>
            <option value="personal" ${alias && alias.category === 'personal' ? 'selected' : ''}>אישי</option>
        </select>
        <div class="alias-dialog-actions">
            <button class="btn-save" onclick="saveAlias(${alias ? true : false})">שמור</button>
            <button class="btn-cancel" onclick="this.parentElement.parentElement.remove()">ביטול</button>
        </div>
    `;
    
    // Add overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1999;';
    overlay.onclick = () => {
        dialog.remove();
        overlay.remove();
    };
    document.body.appendChild(overlay);
    
    return dialog;
}

// Save alias
async function saveAlias(isEdit) {
    const name = document.getElementById('aliasName').value.trim();
    const command = document.getElementById('aliasCommand').value.trim();
    const description = document.getElementById('aliasDescription').value.trim();
    const category = document.getElementById('aliasCategory').value;
    
    if (!name || !command) {
        showNotification('נא למלא שם ופקודה', 'warning');
        return;
    }
    
    // Check if name exists (for new aliases)
    if (!isEdit && AliasesState.aliases.has(name)) {
        showNotification('קיצור עם שם זה כבר קיים', 'error');
        return;
    }
    
    // Create/update alias
    const alias = {
        name: name,
        command: command,
        description: description,
        category: category,
        created_at: isEdit ? AliasesState.aliases.get(name).created_at : new Date().toISOString()
    };
    
    AliasesState.aliases.set(name, alias);
    
    // Save to local storage
    saveAliasesToLocal();
    
    // Sync to server
    if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
        AppState.socket.send(JSON.stringify({
            type: 'alias_update',
            action: isEdit ? 'update' : 'create',
            alias: alias
        }));
    }
    
    // Update display
    displayAliases();
    
    // Close dialog
    document.querySelector('.alias-dialog').remove();
    document.querySelector('.modal-overlay').remove();
    
    showNotification(`הקיצור "${name}" ${isEdit ? 'עודכן' : 'נוצר'} בהצלחה`, 'success');
}

// Delete alias
async function deleteAlias(name) {
    if (!confirm(`האם למחוק את הקיצור "${name}"?`)) return;
    
    AliasesState.aliases.delete(name);
    
    // Save to local storage
    saveAliasesToLocal();
    
    // Sync to server
    if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
        AppState.socket.send(JSON.stringify({
            type: 'alias_update',
            action: 'delete',
            name: name
        }));
    }
    
    // Update display
    displayAliases();
    
    showNotification(`הקיצור "${name}" נמחק`, 'info');
}

// Copy alias
function copyAlias(name) {
    const alias = AliasesState.aliases.get(name);
    if (!alias) return;
    
    navigator.clipboard.writeText(alias.command);
    showNotification(`הפקודה הועתקה: ${alias.command}`, 'success');
}

// Search aliases
function searchAliases(query) {
    displayAliases(query);
}

// Filter by category
function filterAliasesByCategory(category) {
    AliasesState.selectedCategory = category;
    displayAliases();
}

// Import aliases
async function importAliases() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.bashrc,.zshrc,.txt,.json';
    
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const content = await file.text();
        
        if (file.name.endsWith('.json')) {
            // Import JSON format
            try {
                const aliases = JSON.parse(content);
                let imported = 0;
                
                aliases.forEach(alias => {
                    if (alias.name && alias.command) {
                        AliasesState.aliases.set(alias.name, alias);
                        imported++;
                    }
                });
                
                saveAliasesToLocal();
                displayAliases();
                showNotification(`${imported} קיצורים יובאו בהצלחה`, 'success');
                
            } catch (error) {
                showNotification('שגיאה בקריאת קובץ JSON', 'error');
            }
        } else {
            // Import from bashrc/zshrc format
            const lines = content.split('\n');
            let imported = 0;
            
            lines.forEach(line => {
                line = line.trim();
                if (line.startsWith('alias ')) {
                    const match = line.match(/alias\s+(\w+)=['"]?(.+?)['"]?$/);
                    if (match) {
                        const name = match[1];
                        const command = match[2];
                        
                        AliasesState.aliases.set(name, {
                            name: name,
                            command: command,
                            category: 'imported',
                            created_at: new Date().toISOString()
                        });
                        imported++;
                    }
                }
            });
            
            saveAliasesToLocal();
            displayAliases();
            showNotification(`${imported} קיצורים יובאו בהצלחה`, 'success');
        }
    };
    
    input.click();
}

// Export aliases
function exportAliases() {
    const aliases = Array.from(AliasesState.aliases.values());
    
    // Create export formats
    const jsonExport = JSON.stringify(aliases, null, 2);
    const bashExport = aliases.map(alias => 
        `alias ${alias.name}='${alias.command}'`
    ).join('\n');
    
    // Create download dialog
    const dialog = document.createElement('div');
    dialog.className = 'alias-dialog';
    dialog.innerHTML = `
        <h3>ייצוא קיצורים</h3>
        <p>בחר פורמט ייצוא:</p>
        <div class="alias-dialog-actions">
            <button class="btn-save" onclick="downloadAliases('json')">JSON</button>
            <button class="btn-save" onclick="downloadAliases('bash')">Bash/Zsh</button>
            <button class="btn-cancel" onclick="this.parentElement.parentElement.remove()">ביטול</button>
        </div>
    `;
    
    document.body.appendChild(dialog);
    
    // Store exports for download
    window.aliasExports = { json: jsonExport, bash: bashExport };
}

// Download aliases
function downloadAliases(format) {
    const content = window.aliasExports[format];
    const filename = format === 'json' ? 'aliases.json' : 'aliases.sh';
    const mimeType = format === 'json' ? 'application/json' : 'text/plain';
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    
    URL.revokeObjectURL(url);
    
    // Close dialog
    document.querySelector('.alias-dialog').remove();
    
    showNotification('הקיצורים יוצאו בהצלחה', 'success');
}

// Save aliases to local storage
function saveAliasesToLocal() {
    const aliases = Array.from(AliasesState.aliases.values());
    localStorage.setItem('aliases', JSON.stringify(aliases));
}

// Update aliases list from sync
function updateAliasesList(aliases) {
    AliasesState.aliases.clear();
    
    aliases.forEach(alias => {
        AliasesState.aliases.set(alias.name, alias);
    });
    
    displayAliases();
    saveAliasesToLocal();
}

// Set up event listeners
function setupAliasesEventListeners() {
    // Handle alias drops on canvas
    const canvas = document.getElementById('aliasesCanvas');
    if (canvas) {
        canvas.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
        });
        
        canvas.addEventListener('drop', (e) => {
            e.preventDefault();
            
            if (AliasesState.draggedAlias) {
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                // Save position
                AliasesState.positions.set(AliasesState.draggedAlias.name, { x, y });
                
                // Create positioned alias
                createPositionedAlias(AliasesState.draggedAlias, x, y);
            }
        });
    }
}

// Create positioned alias (for canvas mode)
function createPositionedAlias(alias, x, y) {
    const canvas = document.getElementById('aliasesCanvas');
    if (!canvas) return;
    
    const el = document.createElement('div');
    el.className = 'alias-positioned';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.innerHTML = `
        <strong>${alias.name}</strong><br>
        <small>${alias.command}</small>
    `;
    
    el.onclick = () => executeAlias(alias.name);
    
    // Make draggable
    el.draggable = true;
    el.ondragstart = (e) => {
        AliasesState.draggedAlias = alias;
        e.dataTransfer.effectAllowed = 'move';
    };
    
    canvas.appendChild(el);
}

// Export functions
window.initializeAliasesManager = initializeAliasesManager;
window.showAddAlias = showAddAlias;
window.importAliases = importAliases;
window.exportAliases = exportAliases;
window.searchAliases = searchAliases;
window.filterAliasesByCategory = filterAliasesByCategory;
window.editAlias = editAlias;
window.deleteAlias = deleteAlias;
window.copyAlias = copyAlias;
window.saveAlias = saveAlias;
window.downloadAliases = downloadAliases;
window.updateAliasesList = updateAliasesList;
