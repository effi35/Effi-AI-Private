"""
Simple Auth Manager for SSH/SFTP Manager
מערכת הרשאות פשוטה עד 10 משתמשים
"""

import hashlib
import secrets
import json
from datetime import datetime, timedelta
from typing import Dict, Optional, List
import aiosqlite
import logging

logger = logging.getLogger(__name__)

class SimpleAuthManager:
    """Simple authentication for up to 10 users"""
    
    def __init__(self, db_path: str = "database/sync.db"):
        self.db_path = db_path
        self.max_users = 10
        self.sessions = {}  # Active sessions in memory
        self._ensure_tables()
        
    def _ensure_tables(self):
        """Ensure auth tables exist"""
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.executescript("""
            -- Users table
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                full_name TEXT,
                email TEXT,
                role TEXT DEFAULT 'user', -- 'admin' or 'user'
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            );
            
            -- Sessions table
            CREATE TABLE IF NOT EXISTS user_sessions (
                session_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            
            -- Create default admin if no users exist
            INSERT OR IGNORE INTO users (username, password_hash, full_name, role)
            SELECT 'admin', ?, 'Administrator', 'admin'
            WHERE NOT EXISTS (SELECT 1 FROM users);
        """, (self._hash_password("admin123"),))
        
        conn.commit()
        conn.close()
        logger.info("Auth tables initialized")
    
    def _hash_password(self, password: str) -> str:
        """Hash password with salt"""
        salt = "ssh_sftp_manager_salt"  # Simple salt for this basic system
        return hashlib.sha256(f"{password}{salt}".encode()).hexdigest()
    
    def _generate_session_id(self) -> str:
        """Generate secure session ID"""
        return secrets.token_urlsafe(32)
    
    async def login(self, username: str, password: str, 
                   ip_address: str = "", user_agent: str = "") -> Optional[Dict[str, any]]:
        """Authenticate user and create session"""
        password_hash = self._hash_password(password)
        
        async with aiosqlite.connect(self.db_path) as db:
            # Check credentials
            async with db.execute("""
                SELECT id, username, full_name, email, role
                FROM users
                WHERE username = ? AND password_hash = ? AND is_active = 1
            """, (username, password_hash)) as cursor:
                user = await cursor.fetchone()
                
                if not user:
                    logger.warning(f"Failed login attempt for username: {username}")
                    return None
                
                # Create session
                session_id = self._generate_session_id()
                expires_at = datetime.now() + timedelta(hours=24)  # 24 hour sessions
                
                await db.execute("""
                    INSERT INTO user_sessions 
                    (session_id, user_id, expires_at, ip_address, user_agent)
                    VALUES (?, ?, ?, ?, ?)
                """, (session_id, user[0], expires_at, ip_address, user_agent))
                
                # Update last login
                await db.execute("""
                    UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
                """, (user[0],))
                
                await db.commit()
                
                session_data = {
                    "session_id": session_id,
                    "user_id": user[0],
                    "username": user[1],
                    "full_name": user[2],
                    "email": user[3],
                    "role": user[4],
                    "expires_at": expires_at.isoformat()
                }
                
                # Store in memory for fast access
                self.sessions[session_id] = session_data
                
                logger.info(f"User {username} logged in successfully")
                return session_data
    
    async def validate_session(self, session_id: str) -> Optional[Dict[str, any]]:
        """Validate session and return user data"""
        # Check memory first
        if session_id in self.sessions:
            session = self.sessions[session_id]
            if datetime.fromisoformat(session["expires_at"]) > datetime.now():
                return session
            else:
                del self.sessions[session_id]
        
        # Check database
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT s.session_id, s.user_id, s.expires_at,
                       u.username, u.full_name, u.email, u.role
                FROM user_sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.session_id = ? AND s.expires_at > CURRENT_TIMESTAMP
            """, (session_id,)) as cursor:
                row = await cursor.fetchone()
                
                if row:
                    session_data = {
                        "session_id": row[0],
                        "user_id": row[1],
                        "expires_at": row[2],
                        "username": row[3],
                        "full_name": row[4],
                        "email": row[5],
                        "role": row[6]
                    }
                    
                    # Cache in memory
                    self.sessions[session_id] = session_data
                    return session_data
                
        return None
    
    async def logout(self, session_id: str):
        """Logout user and invalidate session"""
        # Remove from memory
        if session_id in self.sessions:
            del self.sessions[session_id]
        
        # Remove from database
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM user_sessions WHERE session_id = ?", (session_id,))
            await db.commit()
        
        logger.info(f"Session {session_id} logged out")
    
    async def create_user(self, username: str, password: str, full_name: str = "",
                         email: str = "", role: str = "user") -> bool:
        """Create new user (up to 10 users)"""
        async with aiosqlite.connect(self.db_path) as db:
            # Check user count
            async with db.execute("SELECT COUNT(*) FROM users") as cursor:
                count = (await cursor.fetchone())[0]
                if count >= self.max_users:
                    logger.warning(f"Cannot create user - limit of {self.max_users} reached")
                    return False
            
            # Create user
            try:
                password_hash = self._hash_password(password)
                await db.execute("""
                    INSERT INTO users (username, password_hash, full_name, email, role)
                    VALUES (?, ?, ?, ?, ?)
                """, (username, password_hash, full_name, email, role))
                await db.commit()
                
                logger.info(f"User {username} created successfully")
                return True
                
            except Exception as e:
                logger.error(f"Failed to create user {username}: {str(e)}")
                return False
    
    async def update_password(self, username: str, old_password: str, 
                            new_password: str) -> bool:
        """Update user password"""
        old_hash = self._hash_password(old_password)
        new_hash = self._hash_password(new_password)
        
        async with aiosqlite.connect(self.db_path) as db:
            # Verify old password
            async with db.execute("""
                SELECT id FROM users WHERE username = ? AND password_hash = ?
            """, (username, old_hash)) as cursor:
                user = await cursor.fetchone()
                
                if not user:
                    logger.warning(f"Failed password update for {username} - wrong password")
                    return False
            
            # Update password
            await db.execute("""
                UPDATE users SET password_hash = ? WHERE username = ?
            """, (new_hash, username))
            await db.commit()
            
            logger.info(f"Password updated for user {username}")
            return True
    
    async def list_users(self) -> List[Dict[str, any]]:
        """List all users"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT id, username, full_name, email, role, created_at, 
                       last_login, is_active
                FROM users
                ORDER BY username
            """) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "username": row[1],
                        "full_name": row[2],
                        "email": row[3],
                        "role": row[4],
                        "created_at": row[5],
                        "last_login": row[6],
                        "is_active": row[7]
                    }
                    for row in rows
                ]
    
    async def toggle_user_active(self, user_id: int) -> bool:
        """Enable/disable user"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                UPDATE users SET is_active = NOT is_active WHERE id = ?
            """, (user_id,))
            await db.commit()
            return True
    
    async def delete_user(self, user_id: int) -> bool:
        """Delete user and their sessions"""
        async with aiosqlite.connect(self.db_path) as db:
            # Don't allow deleting the last admin
            async with db.execute("""
                SELECT COUNT(*) FROM users WHERE role = 'admin' AND id != ?
            """, (user_id,)) as cursor:
                admin_count = (await cursor.fetchone())[0]
                
                if admin_count == 0:
                    logger.warning("Cannot delete the last admin user")
                    return False
            
            # Delete sessions
            await db.execute("DELETE FROM user_sessions WHERE user_id = ?", (user_id,))
            
            # Delete user
            await db.execute("DELETE FROM users WHERE id = ?", (user_id,))
            await db.commit()
            
            # Clear from memory sessions
            self.sessions = {
                sid: session for sid, session in self.sessions.items()
                if session["user_id"] != user_id
            }
            
            logger.info(f"User {user_id} deleted")
            return True
    
    async def cleanup_expired_sessions(self):
        """Clean up expired sessions"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP
            """)
            await db.commit()
        
        # Clean memory sessions
        now = datetime.now()
        self.sessions = {
            sid: session for sid, session in self.sessions.items()
            if datetime.fromisoformat(session["expires_at"]) > now
        }
        
        logger.info("Cleaned up expired sessions")
    
    def is_admin(self, session_data: Dict[str, any]) -> bool:
        """Check if user is admin"""
        return session_data.get("role") == "admin"
    
    async def get_session_info(self, session_id: str) -> Optional[Dict[str, any]]:
        """Get detailed session information"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT s.*, u.username, u.full_name
                FROM user_sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.session_id = ?
            """, (session_id,)) as cursor:
                row = await cursor.fetchone()
                
                if row:
                    return {
                        "session_id": row[0],
                        "user_id": row[1],
                        "created_at": row[2],
                        "expires_at": row[3],
                        "ip_address": row[4],
                        "user_agent": row[5],
                        "username": row[6],
                        "full_name": row[7]
                    }
                
        return None

# Global auth manager instance
auth_manager = SimpleAuthManager()
