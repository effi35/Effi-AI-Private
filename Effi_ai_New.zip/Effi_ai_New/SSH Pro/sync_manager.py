"""
Sync Manager for SSH/SFTP Manager
מנהל סינכרון נתונים בין כל המכשירים המחוברים
"""

import asyncio
import json
import logging
import aioredis
from typing import Dict, List, Any, Optional
from datetime import datetime
import sqlite3
import aiosqlite
from pathlib import Path

logger = logging.getLogger(__name__)

class SyncManager:
    """Manages data synchronization between devices"""
    
    def __init__(self, db_path: str = "database/sync.db", redis_url: str = "redis://localhost"):
        self.db_path = db_path
        self.redis_url = redis_url
        self.redis: Optional[aioredis.Redis] = None
        self._ensure_database()
        
    async def initialize(self):
        """Initialize sync manager"""
        try:
            # Connect to Redis
            self.redis = await aioredis.from_url(
                self.redis_url,
                encoding="utf-8",
                decode_responses=True
            )
            logger.info("Connected to Redis for sync")
            
            # Test connection
            await self.redis.ping()
            
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {str(e)}")
            logger.warning("Running without Redis - sync will be limited")
    
    def _ensure_database(self):
        """Ensure database exists with proper schema"""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.executescript("""
            -- Sessions table
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                host TEXT NOT NULL,
                username TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                tmux_session TEXT,
                metadata TEXT
            );
            
            -- Command history
            CREATE TABLE IF NOT EXISTS command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                command TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                client_id TEXT,
                exit_code INTEGER,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );
            
            -- Aliases
            CREATE TABLE IF NOT EXISTS aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                command TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                position_x INTEGER,
                position_y INTEGER
            );
            
            -- Voice commands
            CREATE TABLE IF NOT EXISTS voice_commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                command TEXT NOT NULL,
                language TEXT DEFAULT 'he-IL',
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                client_id TEXT,
                transcription_confidence REAL,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );
            
            -- File transfers
            CREATE TABLE IF NOT EXISTS file_transfers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                transfer_type TEXT NOT NULL, -- 'upload' or 'download'
                local_path TEXT,
                remote_path TEXT,
                size INTEGER,
                status TEXT DEFAULT 'pending',
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                error TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );
            
            -- Chat messages
            CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                message TEXT NOT NULL,
                sender TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                message_type TEXT DEFAULT 'text', -- 'text', 'image', 'file'
                attachment_path TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );
            
            -- Settings
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- Connection profiles
            CREATE TABLE IF NOT EXISTS connection_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                host TEXT NOT NULL,
                port INTEGER DEFAULT 22,
                username TEXT NOT NULL,
                auth_type TEXT DEFAULT 'password', -- 'password' or 'key'
                key_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP,
                tags TEXT
            );
            
            -- Linux commands bank
            CREATE TABLE IF NOT EXISTS linux_commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                command TEXT NOT NULL,
                description TEXT,
                category TEXT DEFAULT 'general',
                examples TEXT,
                tags TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                usage_count INTEGER DEFAULT 0
            );
            
            -- Create indexes
            CREATE INDEX IF NOT EXISTS idx_command_history_session ON command_history(session_id);
            CREATE INDEX IF NOT EXISTS idx_command_history_timestamp ON command_history(timestamp);
            CREATE INDEX IF NOT EXISTS idx_voice_commands_session ON voice_commands(session_id);
            CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
            CREATE INDEX IF NOT EXISTS idx_aliases_category ON aliases(category);
        """)
        
        conn.commit()
        conn.close()
        logger.info("Database schema initialized")
    
    async def sync_session_start(self, session_id: str, client_id: str):
        """Record session start and sync to all clients"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT OR REPLACE INTO sessions (session_id, host, username, last_activity)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            """, (session_id, "host", "user"))
            await db.commit()
        
        # Publish to Redis for real-time sync
        if self.redis:
            await self.redis.publish("session_updates", json.dumps({
                "action": "session_start",
                "session_id": session_id,
                "client_id": client_id,
                "timestamp": datetime.now().isoformat()
            }))
    
    async def add_command(self, session_id: str, command: str, 
                         client_id: Optional[str] = None, exit_code: Optional[int] = None):
        """Add command to history and sync"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO command_history (session_id, command, client_id, exit_code)
                VALUES (?, ?, ?, ?)
            """, (session_id, command, client_id, exit_code))
            await db.commit()
            
            # Update session activity
            await db.execute("""
                UPDATE sessions SET last_activity = CURRENT_TIMESTAMP
                WHERE session_id = ?
            """, (session_id,))
            await db.commit()
        
        # Publish for real-time sync
        if self.redis:
            await self.redis.publish("command_updates", json.dumps({
                "session_id": session_id,
                "command": command,
                "client_id": client_id,
                "timestamp": datetime.now().isoformat()
            }))
    
    async def get_command_history(self, session_id: Optional[str] = None, 
                                 limit: int = 100) -> List[Dict[str, Any]]:
        """Get command history"""
        async with aiosqlite.connect(self.db_path) as db:
            if session_id:
                query = """
                    SELECT id, session_id, command, timestamp, client_id, exit_code
                    FROM command_history
                    WHERE session_id = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                """
                params = (session_id, limit)
            else:
                query = """
                    SELECT id, session_id, command, timestamp, client_id, exit_code
                    FROM command_history
                    ORDER BY timestamp DESC
                    LIMIT ?
                """
                params = (limit,)
            
            async with db.execute(query, params) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "session_id": row[1],
                        "command": row[2],
                        "timestamp": row[3],
                        "client_id": row[4],
                        "exit_code": row[5]
                    }
                    for row in rows
                ]
    
    async def add_alias(self, name: str, command: str, category: str = "general",
                       description: str = "", created_by: str = "",
                       position: Optional[Dict[str, int]] = None):
        """Add or update alias"""
        position_x = position.get('x') if position else None
        position_y = position.get('y') if position else None
        
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT OR REPLACE INTO aliases 
                (name, command, category, description, created_by, position_x, position_y)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, command, category, description, created_by, position_x, position_y))
            await db.commit()
        
        # Publish update
        if self.redis:
            await self.redis.publish("alias_updates", json.dumps({
                "action": "alias_added",
                "alias": {
                    "name": name,
                    "command": command,
                    "category": category
                }
            }))
    
    async def get_aliases(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all aliases or by category"""
        async with aiosqlite.connect(self.db_path) as db:
            if category:
                query = """
                    SELECT id, name, command, category, description, created_at, 
                           position_x, position_y
                    FROM aliases
                    WHERE category = ?
                    ORDER BY name
                """
                params = (category,)
            else:
                query = """
                    SELECT id, name, command, category, description, created_at,
                           position_x, position_y
                    FROM aliases
                    ORDER BY category, name
                """
                params = ()
            
            async with db.execute(query, params) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "name": row[1],
                        "command": row[2],
                        "category": row[3],
                        "description": row[4],
                        "created_at": row[5],
                        "position": {"x": row[6], "y": row[7]} if row[6] and row[7] else None
                    }
                    for row in rows
                ]
    
    async def delete_alias(self, name: str):
        """Delete alias"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM aliases WHERE name = ?", (name,))
            await db.commit()
        
        # Publish update
        if self.redis:
            await self.redis.publish("alias_updates", json.dumps({
                "action": "alias_deleted",
                "name": name
            }))
    
    async def add_voice_command(self, session_id: str, command: str, 
                               language: str = "he-IL", client_id: Optional[str] = None):
        """Add voice command to history"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO voice_commands (session_id, command, language, client_id)
                VALUES (?, ?, ?, ?)
            """, (session_id, command, language, client_id))
            await db.commit()
    
    async def add_chat_message(self, session_id: str, message: str, sender: str,
                              message_type: str = "text", attachment_path: Optional[str] = None):
        """Add chat message"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO chat_messages 
                (session_id, message, sender, message_type, attachment_path)
                VALUES (?, ?, ?, ?, ?)
            """, (session_id, message, sender, message_type, attachment_path))
            await db.commit()
        
        # Publish for real-time sync
        if self.redis:
            await self.redis.publish("chat_updates", json.dumps({
                "session_id": session_id,
                "message": message,
                "sender": sender,
                "message_type": message_type,
                "timestamp": datetime.now().isoformat()
            }))
    
    async def get_chat_history(self, session_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get chat history for session"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT id, message, sender, timestamp, message_type, attachment_path
                FROM chat_messages
                WHERE session_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (session_id, limit)) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "message": row[1],
                        "sender": row[2],
                        "timestamp": row[3],
                        "message_type": row[4],
                        "attachment_path": row[5]
                    }
                    for row in reversed(rows)  # Reverse to get chronological order
                ]
    
    async def save_connection_profile(self, profile: Dict[str, Any]):
        """Save connection profile"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO connection_profiles 
                (name, host, port, username, auth_type, key_path, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                profile['name'],
                profile['host'],
                profile.get('port', 22),
                profile['username'],
                profile.get('auth_type', 'password'),
                profile.get('key_path'),
                json.dumps(profile.get('tags', []))
            ))
            await db.commit()
    
    async def get_connection_profiles(self) -> List[Dict[str, Any]]:
        """Get all connection profiles"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT id, name, host, port, username, auth_type, key_path, 
                       created_at, last_used, tags
                FROM connection_profiles
                ORDER BY last_used DESC, name
            """) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "name": row[1],
                        "host": row[2],
                        "port": row[3],
                        "username": row[4],
                        "auth_type": row[5],
                        "key_path": row[6],
                        "created_at": row[7],
                        "last_used": row[8],
                        "tags": json.loads(row[9]) if row[9] else []
                    }
                    for row in rows
                ]
    
    async def update_profile_last_used(self, profile_id: int):
        """Update last used timestamp for profile"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                UPDATE connection_profiles 
                SET last_used = CURRENT_TIMESTAMP 
                WHERE id = ?
            """, (profile_id,))
            await db.commit()
    
    async def add_linux_command(self, command: str, description: str = "",
                               category: str = "general", examples: str = "",
                               tags: List[str] = None):
        """Add Linux command to bank"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO linux_commands 
                (command, description, category, examples, tags)
                VALUES (?, ?, ?, ?, ?)
            """, (
                command,
                description,
                category,
                examples,
                json.dumps(tags) if tags else "[]"
            ))
            await db.commit()
    
    async def search_linux_commands(self, query: str) -> List[Dict[str, Any]]:
        """Search Linux commands"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT id, command, description, category, examples, tags, usage_count
                FROM linux_commands
                WHERE command LIKE ? OR description LIKE ? OR tags LIKE ?
                ORDER BY usage_count DESC, command
                LIMIT 20
            """, (f"%{query}%", f"%{query}%", f"%{query}%")) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        "id": row[0],
                        "command": row[1],
                        "description": row[2],
                        "category": row[3],
                        "examples": row[4],
                        "tags": json.loads(row[5]) if row[5] else [],
                        "usage_count": row[6]
                    }
                    for row in rows
                ]
    
    async def increment_command_usage(self, command_id: int):
        """Increment usage count for command"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                UPDATE linux_commands 
                SET usage_count = usage_count + 1 
                WHERE id = ?
            """, (command_id,))
            await db.commit()
    
    async def save_setting(self, key: str, value: Any):
        """Save setting"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT OR REPLACE INTO settings (key, value)
                VALUES (?, ?)
            """, (key, json.dumps(value)))
            await db.commit()
    
    async def get_setting(self, key: str, default: Any = None) -> Any:
        """Get setting"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT value FROM settings WHERE key = ?", 
                (key,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return json.loads(row[0])
                return default
    
    async def get_all_sync_data(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get all sync data"""
        return {
            "aliases": await self.get_aliases(),
            "commands": await self.get_command_history(session_id),
            "profiles": await self.get_connection_profiles(),
            "settings": {
                "theme": await self.get_setting("theme", "dark"),
                "language": await self.get_setting("language", "he-IL"),
                "terminal_font_size": await self.get_setting("terminal_font_size", 14)
            }
        }
    
    async def import_aliases_from_file(self, file_content: str):
        """Import aliases from bashrc/zshrc file"""
        lines = file_content.split('\n')
        imported = 0
        
        for line in lines:
            line = line.strip()
            if line.startswith('alias '):
                # Parse alias line
                parts = line[6:].split('=', 1)
                if len(parts) == 2:
                    name = parts[0].strip()
                    command = parts[1].strip().strip('"\'')
                    await self.add_alias(name, command, category="imported")
                    imported += 1
        
        logger.info(f"Imported {imported} aliases")
        return imported
    
    async def cleanup_old_data(self, days: int = 30):
        """Clean up old data"""
        cutoff_date = datetime.now().timestamp() - (days * 24 * 60 * 60)
        
        async with aiosqlite.connect(self.db_path) as db:
            # Clean old command history
            await db.execute("""
                DELETE FROM command_history
                WHERE timestamp < datetime(?, 'unixepoch')
            """, (cutoff_date,))
            
            # Clean old voice commands
            await db.execute("""
                DELETE FROM voice_commands
                WHERE timestamp < datetime(?, 'unixepoch')
            """, (cutoff_date,))
            
            # Clean old chat messages
            await db.execute("""
                DELETE FROM chat_messages
                WHERE timestamp < datetime(?, 'unixepoch')
            """, (cutoff_date,))
            
            await db.commit()
            logger.info("Cleaned up old data")
