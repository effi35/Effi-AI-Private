/**
 * Chat Terminal for SSH/SFTP Manager
 * צ'אט טרמינל עם תמיכה בצילום מסך, וידאו ושיתוף מסך
 */

// Chat state
const ChatState = {
    messages: [],
    currentSession: null,
    mediaStream: null,
    screenStream: null,
    isRecording: false,
    attachments: new Map()
};

// Initialize chat terminal
function initializeChatTerminal() {
    setupChatUI();
    setupMediaCapabilities();
    loadChatHistory();
    
    console.log('✅ Chat terminal initialized');
}

// Set up chat UI
function setupChatUI() {
    const chatPanel = document.getElementById('chat-panel');
    if (!chatPanel) return;
    
    chatPanel.innerHTML = `
        <div class="chat-container">
            <div class="chat-header">
                <h3>צ'אט טרמינל</h3>
                <div class="chat-session-info">
                    <span id="chatSessionName">לא מחובר</span>
                    <span class="chat-status-indicator"></span>
                </div>
            </div>
            
            <div class="chat-messages" id="chatMessages">
                <div class="chat-welcome">
                    <h4>ברוכים הבאים לצ'אט הטרמינל!</h4>
                    <p>כאן תוכלו:</p>
                    <ul>
                        <li>💬 לשוחח עם AI או משתמשים אחרים</li>
                        <li>📸 לצלם ולשתף צילומי מסך</li>
                        <li>📹 לשתף וידאו חי</li>
                        <li>🖥️ לשתף את המסך שלכם</li>
                        <li>🎤 להקליט ולשלוח הודעות קוליות</li>
                    </ul>
                </div>
            </div>
            
            <div class="chat-input-area">
                <div class="chat-attachments" id="chatAttachments"></div>
                <div class="chat-input-row">
                    <button class="chat-attach-btn" onclick="showAttachMenu()" title="צרף קובץ">
                        📎
                    </button>
                    <textarea 
                        id="chatInput" 
                        placeholder="הקלד הודעה..." 
                        rows="1"
                        onkeydown="handleChatKeydown(event)"
                        oninput="autoResizeChatInput(this)"
                    ></textarea>
                    <button class="chat-send-btn" onclick="sendChatMessage()" title="שלח">
                        ➤
                    </button>
                </div>
                <div class="chat-quick-actions">
                    <button onclick="captureScreenForChat()" title="צילום מסך">📸</button>
                    <button onclick="toggleVideoChat()" title="וידאו">📹</button>
                    <button onclick="shareScreenInChat()" title="שיתוף מסך">🖥️</button>
                    <button onclick="toggleVoiceMessage()" title="הודעה קולית">🎤</button>
                    <button onclick="insertCodeBlock()" title="בלוק קוד">💻</button>
                </div>
            </div>
            
            <!-- Attach menu -->
            <div class="attach-menu" id="attachMenu" style="display: none;">
                <div class="attach-option" onclick="attachFile()">
                    <span>📄</span>
                    <span>קובץ</span>
                </div>
                <div class="attach-option" onclick="attachImage()">
                    <span>🖼️</span>
                    <span>תמונה</span>
                </div>
                <div class="attach-option" onclick="attachTerminalOutput()">
                    <span>💻</span>
                    <span>פלט טרמינל</span>
                </div>
                <div class="attach-option" onclick="attachFileFromSFTP()">
                    <span>📁</span>
                    <span>קובץ מהשרת</span>
                </div>
            </div>
            
            <!-- Media preview -->
            <div class="media-preview" id="mediaPreview" style="display: none;">
                <div class="media-preview-header">
                    <span id="mediaPreviewTitle">תצוגה מקדימה</span>
                    <button onclick="closeMediaPreview()">✕</button>
                </div>
                <div class="media-preview-content" id="mediaPreviewContent"></div>
                <div class="media-preview-actions">
                    <button onclick="confirmMediaAttach()">צרף</button>
                    <button onclick="closeMediaPreview()">ביטול</button>
                </div>
            </div>
        </div>
    `;
    
    // Add styles
    addChatStyles();
}

// Add chat styles
function addChatStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .chat-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            background: #1a1a1a;
        }
        
        .chat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .chat-header h3 {
            margin: 0;
            font-size: 1.1rem;
            color: #ecf0f1;
        }
        
        .chat-session-info {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            color: #95a5a6;
        }
        
        .chat-status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #e74c3c;
        }
        
        .chat-status-indicator.active {
            background: #2ecc71;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .chat-welcome {
            text-align: center;
            color: #95a5a6;
            padding: 40px 20px;
        }
        
        .chat-welcome h4 {
            color: #ecf0f1;
            margin-bottom: 15px;
        }
        
        .chat-welcome ul {
            list-style: none;
            padding: 0;
            text-align: right;
            max-width: 300px;
            margin: 0 auto;
        }
        
        .chat-welcome li {
            margin-bottom: 8px;
        }
        
        .chat-message {
            display: flex;
            gap: 10px;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .chat-message.own {
            flex-direction: row-reverse;
        }
        
        .chat-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2980b9);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        
        .chat-content {
            max-width: 70%;
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .chat-bubble {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 10px 15px;
            word-wrap: break-word;
        }
        
        .chat-message.own .chat-bubble {
            background: rgba(52, 152, 219, 0.15);
            border-color: rgba(52, 152, 219, 0.3);
        }
        
        .chat-meta {
            font-size: 0.75rem;
            color: #7f8c8d;
            padding: 0 5px;
        }
        
        .chat-attachment {
            margin-top: 8px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .chat-attachment:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.15);
        }
        
        .chat-code-block {
            background: #1e1e1e;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 12px;
            font-family: 'Consolas', monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            position: relative;
        }
        
        .chat-code-block button {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 4px;
            padding: 4px 8px;
            color: #95a5a6;
            cursor: pointer;
            font-size: 0.75rem;
        }
        
        .chat-image {
            max-width: 100%;
            border-radius: 8px;
            margin-top: 8px;
            cursor: pointer;
        }
        
        .chat-input-area {
            padding: 15px;
            background: rgba(255, 255, 255, 0.03);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .chat-attachments {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .chat-attachment-preview {
            position: relative;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .chat-attachment-preview button {
            background: none;
            border: none;
            color: #e74c3c;
            cursor: pointer;
            padding: 0 4px;
        }
        
        .chat-input-row {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .chat-attach-btn,
        .chat-send-btn {
            background: rgba(52, 152, 219, 0.2);
            border: 1px solid rgba(52, 152, 219, 0.4);
            border-radius: 6px;
            padding: 8px 12px;
            color: #3498db;
            cursor: pointer;
            font-size: 1.1rem;
            transition: all 0.2s;
        }
        
        .chat-attach-btn:hover,
        .chat-send-btn:hover {
            background: rgba(52, 152, 219, 0.3);
        }
        
        #chatInput {
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 8px 12px;
            color: white;
            resize: none;
            max-height: 120px;
            font-family: inherit;
        }
        
        .chat-quick-actions {
            display: flex;
            gap: 5px;
            margin-top: 10px;
        }
        
        .chat-quick-actions button {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 6px 10px;
            color: #95a5a6;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .chat-quick-actions button:hover {
            background: rgba(255, 255, 255, 0.08);
            color: #ecf0f1;
        }
        
        .chat-quick-actions button.active {
            background: rgba(231, 76, 60, 0.2);
            border-color: rgba(231, 76, 60, 0.4);
            color: #e74c3c;
            animation: pulse 1s infinite;
        }
        
        .attach-menu {
            position: absolute;
            bottom: 60px;
            left: 15px;
            background: rgba(30, 30, 30, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
            z-index: 100;
        }
        
        .attach-option {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .attach-option:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .media-preview {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #1a1a1a;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            width: 600px;
            max-width: 90%;
            max-height: 80vh;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.8);
        }
        
        .media-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .media-preview-content {
            flex: 1;
            padding: 20px;
            overflow: auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .media-preview-actions {
            display: flex;
            gap: 10px;
            padding: 15px 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            justify-content: flex-end;
        }
        
        .media-preview-actions button {
            padding: 8px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .media-preview-actions button:first-child {
            background: #2ecc71;
            color: white;
        }
        
        .media-preview-actions button:last-child {
            background: rgba(255, 255, 255, 0.1);
            color: #95a5a6;
        }
        
        /* Voice message recording */
        .voice-recording {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid rgba(231, 76, 60, 0.3);
            border-radius: 8px;
        }
        
        .voice-waveform {
            flex: 1;
            height: 40px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 4px;
            position: relative;
            overflow: hidden;
        }
        
        .voice-timer {
            font-family: 'Consolas', monospace;
            font-size: 0.9rem;
            color: #e74c3c;
        }
        
        /* Mobile responsive */
        @media (max-width: 768px) {
            .chat-content {
                max-width: 85%;
            }
            
            .chat-quick-actions {
                flex-wrap: wrap;
            }
            
            .media-preview {
                width: 95%;
            }
        }
    `;
    document.head.appendChild(style);
}

// Load chat history
async function loadChatHistory() {
    if (!AppState.sessionId) return;
    
    try {
        const response = await fetch(`/api/chat/${AppState.sessionId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            ChatState.messages = data.messages || [];
            displayMessages();
        }
    } catch (error) {
        console.error('Error loading chat history:', error);
    }
}

// Display messages
function displayMessages() {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    
    // Clear welcome message if messages exist
    if (ChatState.messages.length > 0) {
        container.innerHTML = '';
    }
    
    ChatState.messages.forEach(msg => {
        const msgEl = createMessageElement(msg);
        container.appendChild(msgEl);
    });
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

// Create message element
function createMessageElement(message) {
    const div = document.createElement('div');
    div.className = `chat-message ${message.sender === 'me' ? 'own' : ''}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'chat-avatar';
    avatar.textContent = message.sender.charAt(0).toUpperCase();
    
    const content = document.createElement('div');
    content.className = 'chat-content';
    
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble';
    
    // Handle different message types
    if (message.message_type === 'code') {
        bubble.innerHTML = createCodeBlock(message.message);
    } else if (message.message_type === 'image') {
        bubble.innerHTML = `<img src="${message.attachment_path}" class="chat-image" onclick="viewFullImage(this.src)">`;
    } else {
        bubble.textContent = message.message;
    }
    
    const meta = document.createElement('div');
    meta.className = 'chat-meta';
    meta.textContent = formatMessageTime(message.timestamp);
    
    content.appendChild(bubble);
    content.appendChild(meta);
    
    div.appendChild(avatar);
    div.appendChild(content);
    
    return div;
}

// Send chat message
async function sendChatMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message && ChatState.attachments.size === 0) return;
    
    // Add message to UI immediately
    const msg = {
        sender: 'me',
        message: message,
        message_type: 'text',
        timestamp: new Date().toISOString()
    };
    
    ChatState.messages.push(msg);
    displayMessages();
    
    // Clear input
    input.value = '';
    autoResizeChatInput(input);
    
    // Send to server
    if (AppState.sessionId) {
        try {
            await fetch(`/api/chat/${AppState.sessionId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({
                    message: message,
                    message_type: 'text'
                })
            });
            
            // Broadcast via WebSocket for real-time sync
            if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
                AppState.socket.send(JSON.stringify({
                    type: 'chat_message',
                    data: msg
                }));
            }
        } catch (error) {
            console.error('Error sending message:', error);
        }
    }
}

// Handle chat input keydown
function handleChatKeydown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendChatMessage();
    }
}

// Auto resize chat input
function autoResizeChatInput(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
}

// Show attach menu
function showAttachMenu() {
    const menu = document.getElementById('attachMenu');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}

// Capture screen for chat
async function captureScreenForChat() {
    try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
            video: { mediaSource: 'screen' }
        });
        
        const video = document.createElement('video');
        video.srcObject = stream;
        video.play();
        
        video.onloadedmetadata = () => {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');
            
            // Draw video frame
            ctx.drawImage(video, 0, 0);
            
            // Stop stream
            stream.getTracks().forEach(track => track.stop());
            
            // Show preview
            showMediaPreview(canvas.toDataURL(), 'image', 'צילום מסך');
        };
    } catch (error) {
        console.error('Screen capture error:', error);
        showNotification('שגיאה בצילום מסך', 'error');
    }
}

// Toggle video chat
async function toggleVideoChat() {
    const btn = event.target;
    
    if (ChatState.mediaStream) {
        // Stop video
        ChatState.mediaStream.getTracks().forEach(track => track.stop());
        ChatState.mediaStream = null;
        btn.classList.remove('active');
    } else {
        // Start video
        try {
            ChatState.mediaStream = await navigator.mediaDevices.getUserMedia({ 
                video: true, 
                audio: false 
            });
            
            btn.classList.add('active');
            
            // Create video element
            const video = document.createElement('video');
            video.srcObject = ChatState.mediaStream;
            video.autoplay = true;
            video.muted = true;
            
            showMediaPreview(video, 'video', 'וידאו חי');
            
        } catch (error) {
            console.error('Video error:', error);
            showNotification('שגיאה בהפעלת וידאו', 'error');
        }
    }
}

// Share screen in chat
async function shareScreenInChat() {
    try {
        ChatState.screenStream = await navigator.mediaDevices.getDisplayMedia({
            video: true,
            audio: false
        });
        
        // Create video element
        const video = document.createElement('video');
        video.srcObject = ChatState.screenStream;
        video.autoplay = true;
        
        showMediaPreview(video, 'screen', 'שיתוף מסך');
        
        // Handle stream end
        ChatState.screenStream.getVideoTracks()[0].onended = () => {
            closeMediaPreview();
            showNotification('שיתוף המסך הסתיים', 'info');
        };
        
    } catch (error) {
        console.error('Screen share error:', error);
        showNotification('שגיאה בשיתוף מסך', 'error');
    }
}

// Toggle voice message
async function toggleVoiceMessage() {
    const btn = event.target;
    
    if (ChatState.isRecording) {
        // Stop recording
        stopVoiceRecording();
        btn.classList.remove('active');
    } else {
        // Start recording
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            startVoiceRecording(stream);
            btn.classList.add('active');
        } catch (error) {
            console.error('Microphone error:', error);
            showNotification('שגיאה בגישה למיקרופון', 'error');
        }
    }
}

// Start voice recording
function startVoiceRecording(stream) {
    ChatState.isRecording = true;
    ChatState.mediaRecorder = new MediaRecorder(stream);
    ChatState.audioChunks = [];
    
    ChatState.mediaRecorder.ondataavailable = (event) => {
        ChatState.audioChunks.push(event.data);
    };
    
    ChatState.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(ChatState.audioChunks, { type: 'audio/webm' });
        showMediaPreview(audioBlob, 'audio', 'הודעה קולית');
    };
    
    ChatState.mediaRecorder.start();
    
    // Show recording UI
    showRecordingUI();
}

// Stop voice recording
function stopVoiceRecording() {
    if (ChatState.mediaRecorder && ChatState.isRecording) {
        ChatState.mediaRecorder.stop();
        ChatState.mediaRecorder.stream.getTracks().forEach(track => track.stop());
        ChatState.isRecording = false;
        hideRecordingUI();
    }
}

// Show recording UI
function showRecordingUI() {
    const inputArea = document.querySelector('.chat-input-area');
    
    const recordingUI = document.createElement('div');
    recordingUI.className = 'voice-recording';
    recordingUI.id = 'voiceRecording';
    recordingUI.innerHTML = `
        <span style="color: #e74c3c;">🔴 מקליט...</span>
        <div class="voice-waveform"></div>
        <span class="voice-timer">00:00</span>
        <button onclick="stopVoiceRecording()">עצור</button>
    `;
    
    inputArea.insertBefore(recordingUI, inputArea.firstChild);
    
    // Start timer
    let seconds = 0;
    ChatState.recordingTimer = setInterval(() => {
        seconds++;
        const timer = recordingUI.querySelector('.voice-timer');
        timer.textContent = formatTime(seconds);
    }, 1000);
}

// Hide recording UI
function hideRecordingUI() {
    const recordingUI = document.getElementById('voiceRecording');
    if (recordingUI) {
        recordingUI.remove();
    }
    
    if (ChatState.recordingTimer) {
        clearInterval(ChatState.recordingTimer);
    }
}

// Insert code block
function insertCodeBlock() {
    const input = document.getElementById('chatInput');
    const code = prompt('הכנס קוד:');
    
    if (code) {
        input.value += `\n\`\`\`\n${code}\n\`\`\`\n`;
        autoResizeChatInput(input);
        input.focus();
    }
}

// Show media preview
function showMediaPreview(content, type, title) {
    const preview = document.getElementById('mediaPreview');
    const previewTitle = document.getElementById('mediaPreviewTitle');
    const previewContent = document.getElementById('mediaPreviewContent');
    
    previewTitle.textContent = title;
    
    if (type === 'image' || typeof content === 'string' && content.startsWith('data:image')) {
        previewContent.innerHTML = `<img src="${content}" style="max-width: 100%; max-height: 400px;">`;
    } else if (type === 'video' || type === 'screen') {
        previewContent.innerHTML = '';
        previewContent.appendChild(content);
    } else if (type === 'audio') {
        const audio = document.createElement('audio');
        audio.controls = true;
        audio.src = URL.createObjectURL(content);
        previewContent.innerHTML = '';
        previewContent.appendChild(audio);
    }
    
    preview.style.display = 'flex';
    
    // Store for attachment
    ChatState.pendingAttachment = { content, type, title };
}

// Close media preview
function closeMediaPreview() {
    const preview = document.getElementById('mediaPreview');
    preview.style.display = 'none';
    
    // Stop any streams
    if (ChatState.mediaStream) {
        ChatState.mediaStream.getTracks().forEach(track => track.stop());
        ChatState.mediaStream = null;
    }
    if (ChatState.screenStream) {
        ChatState.screenStream.getTracks().forEach(track => track.stop());
        ChatState.screenStream = null;
    }
    
    ChatState.pendingAttachment = null;
}

// Confirm media attach
function confirmMediaAttach() {
    if (ChatState.pendingAttachment) {
        // Add to attachments
        const id = Date.now();
        ChatState.attachments.set(id, ChatState.pendingAttachment);
        
        // Show in attachments area
        updateAttachmentsDisplay();
        
        closeMediaPreview();
    }
}

// Update attachments display
function updateAttachmentsDisplay() {
    const container = document.getElementById('chatAttachments');
    container.innerHTML = '';
    
    ChatState.attachments.forEach((attachment, id) => {
        const div = document.createElement('div');
        div.className = 'chat-attachment-preview';
        div.innerHTML = `
            <span>${attachment.title}</span>
            <button onclick="removeAttachment(${id})">✕</button>
        `;
        container.appendChild(div);
    });
}

// Remove attachment
function removeAttachment(id) {
    ChatState.attachments.delete(id);
    updateAttachmentsDisplay();
}

// Create code block
function createCodeBlock(code) {
    return `
        <div class="chat-code-block">
            <button onclick="copyCode(this)">העתק</button>
            <pre>${escapeHtml(code)}</pre>
        </div>
    `;
}

// Copy code
function copyCode(btn) {
    const code = btn.nextElementSibling.textContent;
    navigator.clipboard.writeText(code);
    
    const originalText = btn.textContent;
    btn.textContent = 'הועתק!';
    setTimeout(() => {
        btn.textContent = originalText;
    }, 2000);
}

// View full image
function viewFullImage(src) {
    window.open(src, '_blank');
}

// Format message time
function formatMessageTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('he-IL', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

// Format time
function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Update chat when receiving messages
function updateChatFromSync(message) {
    ChatState.messages.push(message);
    displayMessages();
}

// Export functions
window.initializeChatTerminal = initializeChatTerminal;
window.sendChatMessage = sendChatMessage;
window.handleChatKeydown = handleChatKeydown;
window.autoResizeChatInput = autoResizeChatInput;
window.showAttachMenu = showAttachMenu;
window.captureScreenForChat = captureScreenForChat;
window.toggleVideoChat = toggleVideoChat;
window.shareScreenInChat = shareScreenInChat;
window.toggleVoiceMessage = toggleVoiceMessage;
window.stopVoiceRecording = stopVoiceRecording;
window.insertCodeBlock = insertCodeBlock;
window.closeMediaPreview = closeMediaPreview;
window.confirmMediaAttach = confirmMediaAttach;
window.removeAttachment = removeAttachment;
window.copyCode = copyCode;
window.viewFullImage = viewFullImage;
window.updateChatFromSync = updateChatFromSync;
