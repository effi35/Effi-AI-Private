/**
 * File Explorer functionality for SSH/SFTP Manager
 * ניהול קבצים עם Drag & Drop ותמיכה מלאה במובייל
 */

// File explorer state
const FileExplorerState = {
    localPath: '/',
    remotePath: '/',
    selectedFiles: new Set(),
    uploadQueue: [],
    downloadQueue: [],
    transfersInProgress: new Map()
};

// Initialize file explorer
function initializeFileExplorer() {
    setupFileExplorerUI();
    setupDragAndDrop();
    setupKeyboardNavigation();
    
    // Load initial directories
    loadLocalFiles('/');
    if (AppState.connected) {
        loadRemoteFiles('/');
    }
    
    console.log('✅ File explorer initialized');
}

// Set up file explorer UI
function setupFileExplorerUI() {
    // Create file explorer HTML if not exists
    const localExplorer = document.getElementById('localFiles');
    const remoteExplorer = document.getElementById('remoteFiles');
    
    if (!localExplorer || !remoteExplorer) return;
    
    // Add navigation bars
    localExplorer.innerHTML = `
        <div class="file-nav">
            <button onclick="navigateUp('local')" class="nav-btn">⬆️</button>
            <input type="text" class="path-input" id="localPathInput" value="/" 
                   onkeypress="handlePathInput(event, 'local')">
            <button onclick="refreshFiles('local')" class="nav-btn">🔄</button>
        </div>
        <div class="file-list" id="localFileList">
            <div class="loading">טוען קבצים...</div>
        </div>
        <div class="file-status" id="localStatus"></div>
    `;
    
    remoteExplorer.innerHTML = `
        <div class="file-nav">
            <button onclick="navigateUp('remote')" class="nav-btn">⬆️</button>
            <input type="text" class="path-input" id="remotePathInput" value="/" 
                   onkeypress="handlePathInput(event, 'remote')">
            <button onclick="refreshFiles('remote')" class="nav-btn">🔄</button>
        </div>
        <div class="file-list" id="remoteFileList">
            <div class="loading">טוען קבצים...</div>
        </div>
        <div class="file-status" id="remoteStatus"></div>
    `;
    
    // Add CSS
    addFileExplorerStyles();
}

// Add file explorer styles
function addFileExplorerStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .file-explorer {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .file-nav {
            display: flex;
            gap: 10px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .nav-btn {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 4px;
            padding: 5px 10px;
            color: white;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .nav-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .path-input {
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            padding: 5px 10px;
            color: white;
            font-family: monospace;
        }
        
        .file-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        
        .file-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px;
            margin-bottom: 4px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid transparent;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
            user-select: none;
        }
        
        .file-item:hover {
            background: rgba(255, 255, 255, 0.06);
            border-color: rgba(52, 152, 219, 0.3);
        }
        
        .file-item.selected {
            background: rgba(52, 152, 219, 0.2);
            border-color: rgba(52, 152, 219, 0.5);
        }
        
        .file-item.dragging {
            opacity: 0.5;
        }
        
        .file-icon {
            font-size: 1.2rem;
            width: 24px;
            text-align: center;
        }
        
        .file-name {
            flex: 1;
            font-size: 0.9rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .file-size {
            font-size: 0.8rem;
            color: #95a5a6;
        }
        
        .file-permissions {
            font-size: 0.75rem;
            font-family: monospace;
            color: #7f8c8d;
        }
        
        .file-status {
            padding: 10px;
            font-size: 0.85rem;
            color: #95a5a6;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .drop-zone {
            border: 2px dashed rgba(52, 152, 219, 0.5);
            background: rgba(52, 152, 219, 0.1);
        }
        
        .drop-zone.active {
            background: rgba(52, 152, 219, 0.2);
            border-color: rgba(52, 152, 219, 0.8);
        }
        
        .transfer-progress {
            position: fixed;
            bottom: 70px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 20px;
            min-width: 300px;
            z-index: 1000;
        }
        
        .transfer-item {
            margin-bottom: 15px;
        }
        
        .transfer-name {
            font-size: 0.9rem;
            margin-bottom: 5px;
        }
        
        .progress-bar {
            height: 4px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: #3498db;
            transition: width 0.3s ease;
        }
        
        .transfer-info {
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            color: #95a5a6;
            margin-top: 5px;
        }
        
        /* Mobile optimizations */
        @media (max-width: 768px) {
            .file-item {
                padding: 12px 10px;
            }
            
            .file-permissions {
                display: none;
            }
            
            .file-size {
                font-size: 0.75rem;
            }
        }
    `;
    document.head.appendChild(style);
}

// Load local files (simulated)
async function loadLocalFiles(path) {
    FileExplorerState.localPath = path;
    document.getElementById('localPathInput').value = path;
    
    // In a real implementation, this would access local file system
    // For now, show simulated files
    const files = [
        { name: '..', type: 'directory', size: 0 },
        { name: 'Documents', type: 'directory', size: 0 },
        { name: 'Downloads', type: 'directory', size: 0 },
        { name: 'test.txt', type: 'file', size: 1024 },
        { name: 'image.png', type: 'file', size: 15360 }
    ];
    
    displayFiles(files, 'local');
}

// Load remote files
async function loadRemoteFiles(path) {
    if (!AppState.connected) {
        showNotification('לא מחובר לשרת', 'warning');
        return;
    }
    
    FileExplorerState.remotePath = path;
    document.getElementById('remotePathInput').value = path;
    
    showLoading(true, 'remote');
    
    // Request file list via WebSocket
    if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
        AppState.socket.send(JSON.stringify({
            type: 'file_list',
            path: path
        }));
    }
}

// Display files in explorer
function displayFiles(files, location) {
    const listEl = document.getElementById(`${location}FileList`);
    if (!listEl) return;
    
    listEl.innerHTML = '';
    
    files.forEach(file => {
        const item = createFileItem(file, location);
        listEl.appendChild(item);
    });
    
    updateFileStatus(location, files.length);
    showLoading(false, location);
}

// Create file item element
function createFileItem(file, location) {
    const item = document.createElement('div');
    item.className = 'file-item';
    item.draggable = file.type === 'file';
    item.dataset.name = file.name;
    item.dataset.type = file.type;
    item.dataset.location = location;
    
    const icon = getFileIcon(file);
    const sizeStr = file.type === 'file' ? formatFileSize(file.size) : '';
    
    item.innerHTML = `
        <span class="file-icon">${icon}</span>
        <span class="file-name">${escapeHtml(file.name)}</span>
        <span class="file-size">${sizeStr}</span>
        ${file.permissions ? `<span class="file-permissions">${file.permissions}</span>` : ''}
    `;
    
    // Event listeners
    item.addEventListener('click', (e) => handleFileClick(e, file, location));
    item.addEventListener('dblclick', (e) => handleFileDoubleClick(e, file, location));
    
    if (file.type === 'file') {
        item.addEventListener('dragstart', (e) => handleDragStart(e, file, location));
        item.addEventListener('dragend', handleDragEnd);
    }
    
    return item;
}

// Get file icon based on type and extension
function getFileIcon(file) {
    if (file.type === 'directory') {
        return file.name === '..' ? '⬆️' : '📁';
    }
    
    const ext = file.name.split('.').pop().toLowerCase();
    const icons = {
        'txt': '📄',
        'pdf': '📕',
        'doc': '📘',
        'docx': '📘',
        'xls': '📊',
        'xlsx': '📊',
        'png': '🖼️',
        'jpg': '🖼️',
        'jpeg': '🖼️',
        'gif': '🖼️',
        'mp3': '🎵',
        'mp4': '🎬',
        'zip': '📦',
        'rar': '📦',
        'tar': '📦',
        'gz': '📦',
        'js': '📜',
        'py': '🐍',
        'html': '🌐',
        'css': '🎨',
        'json': '📋'
    };
    
    return icons[ext] || '📄';
}

// Handle file click
function handleFileClick(event, file, location) {
    event.preventDefault();
    
    const item = event.currentTarget;
    const isSelected = item.classList.contains('selected');
    
    if (!event.ctrlKey && !event.metaKey) {
        // Clear other selections
        document.querySelectorAll(`.file-item[data-location="${location}"]`).forEach(el => {
            el.classList.remove('selected');
        });
        FileExplorerState.selectedFiles.clear();
    }
    
    if (isSelected) {
        item.classList.remove('selected');
        FileExplorerState.selectedFiles.delete(file.name);
    } else {
        item.classList.add('selected');
        FileExplorerState.selectedFiles.add(file.name);
    }
}

// Handle file double click
function handleFileDoubleClick(event, file, location) {
    event.preventDefault();
    
    if (file.type === 'directory') {
        let newPath;
        if (file.name === '..') {
            // Go up one directory
            const currentPath = location === 'local' ? 
                FileExplorerState.localPath : FileExplorerState.remotePath;
            const parts = currentPath.split('/').filter(p => p);
            parts.pop();
            newPath = '/' + parts.join('/');
        } else {
            // Enter directory
            const currentPath = location === 'local' ? 
                FileExplorerState.localPath : FileExplorerState.remotePath;
            newPath = currentPath.endsWith('/') ? 
                currentPath + file.name : currentPath + '/' + file.name;
        }
        
        if (location === 'local') {
            loadLocalFiles(newPath);
        } else {
            loadRemoteFiles(newPath);
        }
    } else {
        // File - show options or download
        showFileOptions(file, location);
    }
}

// Set up drag and drop
function setupDragAndDrop() {
    const localList = document.getElementById('localFileList');
    const remoteList = document.getElementById('remoteFileList');
    
    if (!localList || !remoteList) return;
    
    // Set up drop zones
    [localList, remoteList].forEach(list => {
        list.addEventListener('dragover', handleDragOver);
        list.addEventListener('dragleave', handleDragLeave);
        list.addEventListener('drop', handleDrop);
    });
    
    // Also handle file drops from outside
    document.addEventListener('dragover', (e) => {
        if (e.dataTransfer.types.includes('Files')) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        }
    });
    
    document.addEventListener('drop', (e) => {
        if (e.dataTransfer.files.length > 0) {
            e.preventDefault();
            handleExternalFileDrop(e.dataTransfer.files);
        }
    });
}

// Handle drag start
function handleDragStart(event, file, location) {
    event.dataTransfer.effectAllowed = 'copy';
    event.dataTransfer.setData('text/plain', JSON.stringify({
        file: file,
        location: location
    }));
    
    event.currentTarget.classList.add('dragging');
}

// Handle drag end
function handleDragEnd(event) {
    event.currentTarget.classList.remove('dragging');
}

// Handle drag over
function handleDragOver(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    event.currentTarget.classList.add('drop-zone');
}

// Handle drag leave
function handleDragLeave(event) {
    if (event.currentTarget.contains(event.relatedTarget)) return;
    event.currentTarget.classList.remove('drop-zone');
}

// Handle drop
function handleDrop(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('drop-zone');
    
    // Check if files from outside
    if (event.dataTransfer.files.length > 0) {
        handleExternalFileDrop(event.dataTransfer.files);
        return;
    }
    
    // Internal drag and drop
    try {
        const data = JSON.parse(event.dataTransfer.getData('text/plain'));
        const targetLocation = event.currentTarget.id.includes('local') ? 'local' : 'remote';
        
        if (data.location !== targetLocation) {
            // Transfer file
            if (data.location === 'local' && targetLocation === 'remote') {
                uploadFile(data.file);
            } else if (data.location === 'remote' && targetLocation === 'local') {
                downloadFile(data.file);
            }
        }
    } catch (e) {
        console.error('Drop error:', e);
    }
}

// Handle external file drop
function handleExternalFileDrop(files) {
    if (!AppState.connected) {
        showNotification('לא מחובר לשרת', 'warning');
        return;
    }
    
    // Add files to upload queue
    Array.from(files).forEach(file => {
        FileExplorerState.uploadQueue.push({
            file: file,
            remotePath: FileExplorerState.remotePath + '/' + file.name
        });
    });
    
    processUploadQueue();
}

// Upload file
async function uploadFile(fileInfo) {
    const transferId = `upload_${Date.now()}`;
    
    // Show progress
    showTransferProgress(transferId, fileInfo.name, 'upload');
    
    // In real implementation, would upload via WebSocket/HTTP
    // For now, simulate upload
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        updateTransferProgress(transferId, progress);
        
        if (progress >= 100) {
            clearInterval(interval);
            completeTransfer(transferId);
            showNotification(`${fileInfo.name} הועלה בהצלחה`, 'success');
            refreshFiles('remote');
        }
    }, 200);
}

// Download file
async function downloadFile(fileInfo) {
    const transferId = `download_${Date.now()}`;
    
    // Show progress
    showTransferProgress(transferId, fileInfo.name, 'download');
    
    // Request download via WebSocket
    if (AppState.socket && AppState.socket.readyState === WebSocket.OPEN) {
        AppState.socket.send(JSON.stringify({
            type: 'file_download',
            file: fileInfo,
            transferId: transferId
        }));
    }
}

// Process upload queue
async function processUploadQueue() {
    if (FileExplorerState.uploadQueue.length === 0) return;
    
    const item = FileExplorerState.uploadQueue.shift();
    await uploadFile({
        name: item.file.name,
        size: item.file.size,
        file: item.file
    });
    
    // Process next
    if (FileExplorerState.uploadQueue.length > 0) {
        setTimeout(() => processUploadQueue(), 100);
    }
}

// Show transfer progress
function showTransferProgress(transferId, fileName, type) {
    let progressContainer = document.getElementById('transferProgress');
    if (!progressContainer) {
        progressContainer = document.createElement('div');
        progressContainer.id = 'transferProgress';
        progressContainer.className = 'transfer-progress';
        document.body.appendChild(progressContainer);
    }
    
    const transferItem = document.createElement('div');
    transferItem.className = 'transfer-item';
    transferItem.id = `transfer_${transferId}`;
    transferItem.innerHTML = `
        <div class="transfer-name">
            ${type === 'upload' ? '⬆️' : '⬇️'} ${escapeHtml(fileName)}
        </div>
        <div class="progress-bar">
            <div class="progress-fill" style="width: 0%"></div>
        </div>
        <div class="transfer-info">
            <span class="transfer-percent">0%</span>
            <span class="transfer-speed"></span>
        </div>
    `;
    
    progressContainer.appendChild(transferItem);
    FileExplorerState.transfersInProgress.set(transferId, {
        fileName: fileName,
        type: type,
        startTime: Date.now()
    });
}

// Update transfer progress
function updateTransferProgress(transferId, percent, speed) {
    const item = document.getElementById(`transfer_${transferId}`);
    if (!item) return;
    
    item.querySelector('.progress-fill').style.width = `${percent}%`;
    item.querySelector('.transfer-percent').textContent = `${percent}%`;
    
    if (speed) {
        item.querySelector('.transfer-speed').textContent = formatSpeed(speed);
    }
}

// Complete transfer
function completeTransfer(transferId) {
    const item = document.getElementById(`transfer_${transferId}`);
    if (!item) return;
    
    // Show completion
    item.querySelector('.progress-fill').style.background = '#2ecc71';
    
    // Remove after delay
    setTimeout(() => {
        item.remove();
        FileExplorerState.transfersInProgress.delete(transferId);
        
        // Remove container if empty
        const container = document.getElementById('transferProgress');
        if (container && container.children.length === 0) {
            container.remove();
        }
    }, 2000);
}

// Set up keyboard navigation
function setupKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
        // Only handle if file explorer is active
        if (document.getElementById('files-panel').classList.contains('active')) {
            handleFileExplorerKeyboard(e);
        }
    });
}

// Handle keyboard events in file explorer
function handleFileExplorerKeyboard(event) {
    const activeElement = document.activeElement;
    
    // Arrow navigation
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
        navigateFiles(event.key === 'ArrowUp' ? -1 : 1);
    }
    
    // Enter to open
    if (event.key === 'Enter') {
        const selected = document.querySelector('.file-item.selected');
        if (selected) {
            const file = {
                name: selected.dataset.name,
                type: selected.dataset.type
            };
            const location = selected.dataset.location;
            handleFileDoubleClick({ preventDefault: () => {} }, file, location);
        }
    }
    
    // Delete
    if (event.key === 'Delete') {
        deleteSelectedFiles();
    }
    
    // Ctrl+A to select all
    if ((event.ctrlKey || event.metaKey) && event.key === 'a') {
        event.preventDefault();
        selectAllFiles();
    }
}

// Navigate files with keyboard
function navigateFiles(direction) {
    const items = Array.from(document.querySelectorAll('.file-item'));
    const selected = document.querySelector('.file-item.selected');
    
    let currentIndex = selected ? items.indexOf(selected) : -1;
    let newIndex = currentIndex + direction;
    
    if (newIndex < 0) newIndex = items.length - 1;
    if (newIndex >= items.length) newIndex = 0;
    
    // Clear selection
    items.forEach(item => item.classList.remove('selected'));
    FileExplorerState.selectedFiles.clear();
    
    // Select new item
    if (items[newIndex]) {
        items[newIndex].classList.add('selected');
        FileExplorerState.selectedFiles.add(items[newIndex].dataset.name);
        items[newIndex].scrollIntoView({ block: 'nearest' });
    }
}

// Select all files
function selectAllFiles() {
    const location = document.querySelector('.tab-panel.active').id.includes('local') ? 'local' : 'remote';
    const items = document.querySelectorAll(`.file-item[data-location="${location}"]`);
    
    items.forEach(item => {
        if (item.dataset.name !== '..') {
            item.classList.add('selected');
            FileExplorerState.selectedFiles.add(item.dataset.name);
        }
    });
}

// Delete selected files
async function deleteSelectedFiles() {
    if (FileExplorerState.selectedFiles.size === 0) return;
    
    const confirmMsg = FileExplorerState.selectedFiles.size === 1 ?
        'האם למחוק את הקובץ הנבחר?' :
        `האם למחוק ${FileExplorerState.selectedFiles.size} קבצים?`;
    
    if (!confirm(confirmMsg)) return;
    
    // Delete files
    for (const fileName of FileExplorerState.selectedFiles) {
        // Send delete request
        console.log('Deleting:', fileName);
    }
    
    FileExplorerState.selectedFiles.clear();
    refreshFiles('current');
}

// Show file options
function showFileOptions(file, location) {
    // In a real app, would show context menu or modal
    const options = [
        { label: 'הורד', action: () => downloadFile(file) },
        { label: 'שנה שם', action: () => renameFile(file, location) },
        { label: 'מחק', action: () => deleteFile(file, location) },
        { label: 'מידע', action: () => showFileInfo(file, location) }
    ];
    
    // For now, just download
    if (location === 'remote') {
        downloadFile(file);
    }
}

// Utility functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatSpeed(bytesPerSecond) {
    return formatFileSize(bytesPerSecond) + '/s';
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function showLoading(show, location) {
    const list = document.getElementById(`${location}FileList`);
    if (!list) return;
    
    if (show) {
        list.innerHTML = '<div class="loading">טוען קבצים...</div>';
    }
}

function updateFileStatus(location, count) {
    const status = document.getElementById(`${location}Status`);
    if (!status) return;
    
    status.textContent = `${count} פריטים`;
}

function navigateUp(location) {
    const currentPath = location === 'local' ? 
        FileExplorerState.localPath : FileExplorerState.remotePath;
    
    const parts = currentPath.split('/').filter(p => p);
    parts.pop();
    const newPath = '/' + parts.join('/');
    
    if (location === 'local') {
        loadLocalFiles(newPath);
    } else {
        loadRemoteFiles(newPath);
    }
}

function refreshFiles(location) {
    if (location === 'local' || location === 'current') {
        loadLocalFiles(FileExplorerState.localPath);
    }
    if (location === 'remote' || location === 'current') {
        loadRemoteFiles(FileExplorerState.remotePath);
    }
}

function handlePathInput(event, location) {
    if (event.key === 'Enter') {
        const path = event.target.value;
        if (location === 'local') {
            loadLocalFiles(path);
        } else {
            loadRemoteFiles(path);
        }
    }
}

// Update file explorer when receiving data
function updateFileExplorer(data) {
    if (data.path && data.files) {
        displayFiles(data.files, 'remote');
    }
}

// Export functions
window.initializeFileExplorer = initializeFileExplorer;
window.updateFileExplorer = updateFileExplorer;
window.navigateUp = navigateUp;
window.refreshFiles = refreshFiles;
window.handlePathInput = handlePathInput;
