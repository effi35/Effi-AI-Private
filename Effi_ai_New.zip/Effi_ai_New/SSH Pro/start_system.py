#!/usr/bin/env python3
"""
SSH/SFTP Manager - Main Startup Script
סקריפט הפעלה ראשי למערכת
"""

import os
import sys
import subprocess
import signal
import time
import json
import asyncio
import webbrowser
from pathlib import Path
from datetime import datetime

# ASCII Art Logo
LOGO = """
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   ███████╗███████╗██╗  ██╗    ███╗   ███╗ ██████╗ ██████╗       ║
║   ██╔════╝██╔════╝██║  ██║    ████╗ ████║██╔════╝ ██╔══██╗      ║
║   ███████╗███████╗███████║    ██╔████╔██║██║  ███╗██████╔╝      ║
║   ╚════██║╚════██║██╔══██║    ██║╚██╔╝██║██║   ██║██╔══██╗      ║
║   ███████║███████║██║  ██║    ██║ ╚═╝ ██║╚██████╔╝██║  ██║      ║
║   ╚══════╝╚══════╝╚═╝  ╚═╝    ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝      ║
║                                                                   ║
║            SSH/SFTP Manager v3.0 - מערכת ניהול מתקדמת           ║
╚═══════════════════════════════════════════════════════════════════╝
"""

class SystemManager:
    """Main system manager"""
    
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.processes = {}
        self.config = self.load_config()
        
    def load_config(self):
        """Load system configuration"""
        config_path = self.base_dir / "metadata.json"
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            "port": 5000,
            "name": "SSH/SFTP Manager",
            "version": "3.0.0"
        }
    
    def check_requirements(self):
        """Check system requirements"""
        print("🔍 בודק דרישות מערכת...")
        
        issues = []
        
        # Check Python version
        if sys.version_info < (3, 8):
            issues.append(f"❌ Python 3.8+ נדרש (נמצא: {sys.version})")
        else:
            print(f"✅ Python {sys.version.split()[0]}")
        
        # Check Redis
        try:
            result = subprocess.run(['redis-cli', 'ping'], 
                                  capture_output=True, text=True)
            if result.stdout.strip() == 'PONG':
                print("✅ Redis פועל")
            else:
                issues.append("❌ Redis לא פועל")
        except FileNotFoundError:
            issues.append("❌ Redis לא מותקן")
        
        # Check Python packages
        required_packages = [
            'fastapi', 'uvicorn', 'asyncssh', 'aiofiles', 
            'redis', 'websockets', 'python-socketio'
        ]
        
        for package in required_packages:
            try:
                __import__(package.replace('-', '_'))
                print(f"✅ {package}")
            except ImportError:
                issues.append(f"❌ חבילת Python חסרה: {package}")
        
        # Check directories
        required_dirs = ['backend', 'assets', 'database', 'logs']
        for dir_name in required_dirs:
            dir_path = self.base_dir / dir_name
            if not dir_path.exists():
                dir_path.mkdir(parents=True, exist_ok=True)
                print(f"📁 נוצרה תיקייה: {dir_name}")
        
        return issues
    
    def start_redis(self):
        """Start Redis if not running"""
        print("\n🚀 מפעיל Redis...")
        
        try:
            # Check if already running
            result = subprocess.run(['redis-cli', 'ping'], 
                                  capture_output=True, text=True)
            if result.stdout.strip() == 'PONG':
                print("✅ Redis כבר פועל")
                return True
        except:
            pass
        
        # Start Redis
        try:
            config_path = Path.home() / '.ssh_sftp_manager' / 'redis' / 'redis.conf'
            if config_path.exists():
                self.processes['redis'] = subprocess.Popen(
                    ['redis-server', str(config_path)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            else:
                self.processes['redis'] = subprocess.Popen(
                    ['redis-server'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            
            time.sleep(2)  # Wait for Redis to start
            
            # Verify Redis started
            result = subprocess.run(['redis-cli', 'ping'], 
                                  capture_output=True, text=True)
            if result.stdout.strip() == 'PONG':
                print("✅ Redis הופעל בהצלחה")
                return True
            else:
                print("❌ Redis לא הצליח להיפתח")
                return False
                
        except Exception as e:
            print(f"❌ שגיאה בהפעלת Redis: {e}")
            return False
    
    def initialize_database(self):
        """Initialize database"""
        print("\n🗄️ מאתחל בסיס נתונים...")
        
        try:
            # Import and run database initialization
            sys.path.insert(0, str(self.base_dir / 'backend'))
            from sync_manager import SyncManager
            
            sync_manager = SyncManager()
            print("✅ בסיס הנתונים אותחל בהצלחה")
            
            # Create default admin user if needed
            from auth_manager import auth_manager
            users = asyncio.run(auth_manager.list_users())
            
            if len(users) == 0:
                print("📝 יוצר משתמש מנהל ראשוני...")
                print("   שם משתמש: admin")
                print("   סיסמה: admin123")
                print("   ⚠️  נא לשנות סיסמה לאחר הכניסה הראשונה!")
            
            return True
            
        except Exception as e:
            print(f"❌ שגיאה באתחול בסיס נתונים: {e}")
            return False
    
    def start_backend(self):
        """Start FastAPI backend"""
        print("\n🚀 מפעיל שרת Backend...")
        
        try:
            # Change to backend directory
            backend_dir = self.base_dir / 'backend'
            
            # Start uvicorn
            self.processes['backend'] = subprocess.Popen(
                [sys.executable, '-m', 'uvicorn', 
                 'main:app', '--host', '0.0.0.0', 
                 '--port', str(self.config['port']),
                 '--reload'],
                cwd=backend_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            print(f"✅ שרת Backend פועל על פורט {self.config['port']}")
            return True
            
        except Exception as e:
            print(f"❌ שגיאה בהפעלת Backend: {e}")
            return False
    
    def wait_for_server(self, timeout=30):
        """Wait for server to be ready"""
        print("\n⏳ ממתין לשרת...")
        
        import requests
        
        start_time = time.time()
        url = f"http://localhost:{self.config['port']}/health"
        
        while time.time() - start_time < timeout:
            try:
                response = requests.get(url, timeout=1)
                if response.status_code == 200:
                    print("✅ השרת מוכן!")
                    return True
            except:
                pass
            
            time.sleep(1)
            sys.stdout.write('.')
            sys.stdout.flush()
        
        print("\n❌ הזמן הקצוב לחיבור לשרת עבר")
        return False
    
    def open_browser(self):
        """Open browser to the application"""
        url = f"http://localhost:{self.config['port']}"
        print(f"\n🌐 פותח דפדפן: {url}")
        
        # Wait a moment before opening
        time.sleep(2)
        
        try:
            webbrowser.open(url)
        except:
            print(f"⚠️  לא ניתן לפתוח דפדפן אוטומטית")
            print(f"   נא לפתוח ידנית: {url}")
    
    def show_status(self):
        """Show system status"""
        print("\n" + "="*60)
        print("📊 סטטוס מערכת:")
        print("="*60)
        
        # Check processes
        for name, process in self.processes.items():
            if process and process.poll() is None:
                print(f"✅ {name}: פועל (PID: {process.pid})")
            else:
                print(f"❌ {name}: לא פועל")
        
        # System info
        print(f"\n🔧 גרסה: {self.config['version']}")
        print(f"🌐 כתובת: http://localhost:{self.config['port']}")
        print(f"📁 תיקייה: {self.base_dir}")
        
        print("\n📋 פקודות מהירות:")
        print("   Ctrl+C - עצירת המערכת")
        print("   r - רענון הדף")
        print("   l - הצגת לוגים")
        print("   s - הצגת סטטוס")
        print("="*60)
    
    def monitor_logs(self):
        """Monitor system logs"""
        print("\n📜 לוגים:")
        print("-"*60)
        
        # Monitor backend logs
        if 'backend' in self.processes:
            process = self.processes['backend']
            
            # Read stdout
            while True:
                line = process.stdout.readline()
                if not line:
                    break
                print(f"[Backend] {line.decode().strip()}")
    
    def shutdown(self):
        """Shutdown all processes"""
        print("\n🛑 מכבה מערכת...")
        
        # Stop all processes
        for name, process in self.processes.items():
            if process and process.poll() is None:
                print(f"   עוצר {name}...")
                process.terminate()
                
                # Wait for graceful shutdown
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        
        print("✅ המערכת כובתה")
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print("\n\n⚠️  התקבל סיגנל כיבוי")
        self.shutdown()
        sys.exit(0)
    
    def run(self):
        """Run the system"""
        # Clear screen
        os.system('clear' if os.name == 'posix' else 'cls')
        
        # Show logo
        print(LOGO)
        print(f"🚀 מפעיל {self.config['name']} v{self.config['version']}...")
        print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*60)
        
        # Register signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        # Check requirements
        issues = self.check_requirements()
        if issues:
            print("\n❌ נמצאו בעיות:")
            for issue in issues:
                print(f"   {issue}")
            print("\n💡 הרץ את install.sh להתקנת התלויות")
            sys.exit(1)
        
        # Start services
        if not self.start_redis():
            print("❌ לא ניתן להפעיל את Redis")
            sys.exit(1)
        
        if not self.initialize_database():
            print("❌ לא ניתן לאתחל בסיס נתונים")
            sys.exit(1)
        
        if not self.start_backend():
            print("❌ לא ניתן להפעיל את השרת")
            sys.exit(1)
        
        # Wait for server
        if self.wait_for_server():
            self.show_status()
            self.open_browser()
            
            print("\n✅ המערכת פועלת!")
            print("   לחץ Ctrl+C לעצירה")
            
            # Keep running
            try:
                while True:
                    time.sleep(1)
                    
                    # Check if processes are still running
                    for name, process in self.processes.items():
                        if process and process.poll() is not None:
                            print(f"\n⚠️  תהליך {name} נעצר באופן לא צפוי")
                            self.shutdown()
                            sys.exit(1)
                            
            except KeyboardInterrupt:
                pass
        else:
            print("❌ השרת לא הצליח לעלות")
            self.shutdown()
            sys.exit(1)

def main():
    """Main entry point"""
    manager = SystemManager()
    manager.run()

if __name__ == "__main__":
    main()
