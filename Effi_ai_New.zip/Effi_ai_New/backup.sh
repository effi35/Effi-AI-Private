#!/bin/bash
# גיבוי של קובץ index.html לקובץ עם תאריך
cp index.html "index_backup_$(date +%Y%m%d_%H%M%S).html"
echo "✅ גובּה בהצלחה." 