require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');
const http = require('http');
const socketIo = require('socket.io');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const morgan = require('morgan');
const winston = require('winston');
const path = require('path');
const fs = require('fs');

// Initialize Express App
const app = express();
const server = http.createServer(app);

// Initialize Socket.IO with CORS
const io = socketIo(server, {
    cors: {
        origin: process.env.WEBSOCKET_ORIGINS?.split(',') || ["http://localhost:3000"],
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Initialize Redis Client
const redisClient = redis.createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379'
});

redisClient.on('error', (err) => {
    console.error('Redis Client Error (fallback to memory):', err);
});

redisClient.on('connect', () => {
    console.log('✅ Redis connected successfully');
});

// Try to connect to Redis, fallback gracefully
redisClient.connect().catch((err) => {
    console.warn('⚠️ Redis connection failed, using memory fallback:', err.message);
});

// Winston Logger Configuration
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    defaultMeta: { service: 'effi-government-system' },
    transports: [
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/combined.log' }),
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        })
    ]
});

// Create logs directory if it doesn't exist
if (!fs.existsSync('logs')) {
    fs.mkdirSync('logs');
}

// Database Connection with fallback
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/effi_government_db', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    logger.info('✅ Connected to MongoDB - Effi Government Database');
})
.catch((error) => {
    logger.warn('⚠️ MongoDB connection failed, using memory fallback:', error.message);
});

// Security Middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "ws:", "wss:"]
        }
    }
}));

// Rate Limiting
const limiter = rateLimit({
    windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000,
    max: process.env.RATE_LIMIT_MAX || 1000,
    message: {
        error: 'Too many requests from this IP, please try again later.',
        code: 'RATE_LIMIT_EXCEEDED'
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
        res.status(429).json({
            error: 'Too many requests from this IP, please try again later.',
            code: 'RATE_LIMIT_EXCEEDED'
        });
    }
});

app.use('/api/', limiter);

// CORS Configuration
app.use(cors({
    origin: function (origin, callback) {
        const allowedOrigins = ['http://localhost:3000', 'http://localhost:2025', 'https://effi-gov.israel.gov.il'];
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            callback(null, true); // Allow all for development
        }
    },
    credentials: true
}));

// Body Parsing & Compression
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging
app.use(morgan('combined', {
    stream: { write: message => logger.info(message.trim()) }
}));

// Static Files
app.use(express.static(__dirname));
app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/pages', express.static(path.join(__dirname, 'pages')));
app.use('/data', express.static(path.join(__dirname, 'data')));

// Database Models (simplified for quick setup)
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    userType: { type: String, enum: ['citizen', 'government', 'admin'], default: 'citizen' },
    permissions: [String],
    createdAt: { type: Date, default: Date.now },
    lastLogin: Date,
    isActive: { type: Boolean, default: true }
});

const ConnectionSchema = new mongoose.Schema({
    name: { type: String, required: true },
    category: { type: String, required: true },
    status: { type: String, enum: ['active', 'inactive', 'pending'], default: 'active' },
    permissions: {
        read: { type: Boolean, default: true },
        write: { type: Boolean, default: false },
        configure: { type: Boolean, default: false }
    },
    lastUpdated: { type: Date, default: Date.now },
    metadata: mongoose.Schema.Types.Mixed
});

const SystemLogSchema = new mongoose.Schema({
    level: { type: String, enum: ['info', 'warn', 'error', 'debug'], required: true },
    message: { type: String, required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    module: String,
    metadata: mongoose.Schema.Types.Mixed,
    timestamp: { type: Date, default: Date.now }
});

// Initialize models
let User, Connection, SystemLog;
try {
    User = mongoose.model('User', UserSchema);
    Connection = mongoose.model('Connection', ConnectionSchema);
    SystemLog = mongoose.model('SystemLog', SystemLogSchema);
} catch (error) {
    // Models already exist or MongoDB not connected
    logger.warn('Models initialization skipped:', error.message);
}

// Import Security & Auth
const GovernmentAuthMiddleware = require('./js/government-auth-middleware');
const authMiddleware = new GovernmentAuthMiddleware();

// Security headers for all routes
app.use(authMiddleware.addSecurityHeaders());
app.use(authMiddleware.auditRequest());

// API Routes with security
app.use('/api/auth', require('./js/routes/auth.js'));
app.use('/api/connections', authMiddleware.secureEndpoint(['government_data']), require('./js/routes/connections.js'));
app.use('/api/system', authMiddleware.secureEndpoint(['system_admin']), require('./js/routes/system.js'));
app.use('/api/ai', authMiddleware.secureEndpoint(['basic']), require('./js/routes/ai.js'));
app.use('/api/government', require('./js/routes/government.js'));

// Main Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV || 'development',
        version: require('./package.json').version,
        services: {
            mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
            redis: redisClient.isReady ? 'connected' : 'disconnected'
        }
    });
});

// Import Real-time WebSocket Manager
const RealTimeWebSocketManager = require('./js/realtime-websocket-manager');

// Initialize Real-time WebSocket Manager
const realtimeManager = new RealTimeWebSocketManager(io, redisClient);

// WebSocket statistics endpoint
app.get('/api/websocket/stats', (req, res) => {
    res.json({
        success: true,
        statistics: realtimeManager.getStatistics(),
        timestamp: new Date()
    });
});

// Send system alert endpoint
app.post('/api/websocket/alert', authMiddleware.secureEndpoint(['system_admin']), (req, res) => {
    const { message, priority } = req.body;
    realtimeManager.sendSystemAlert(message, priority);
    res.json({
        success: true,
        message: 'Alert sent successfully'
    });
});

// Broadcast to user type endpoint
app.post('/api/websocket/broadcast', authMiddleware.secureEndpoint(['system_admin']), (req, res) => {
    const { userType, event, data } = req.body;
    realtimeManager.broadcastToUserType(userType, event, data);
    res.json({
        success: true,
        message: 'Message broadcasted successfully'
    });
});

// Legacy connection references for compatibility
const activeConnections = realtimeManager.activeConnections;
const governmentConnections = realtimeManager.governmentConnections;

// Error Handling Middleware
app.use((err, req, res, next) => {
    logger.error('Unhandled error:', err);
    
    if (err.name === 'ValidationError') {
        return res.status(400).json({
            error: 'Validation Error',
            details: err.message
        });
    }
    
    if (err.name === 'UnauthorizedError') {
        return res.status(401).json({
            error: 'Unauthorized',
            message: 'Invalid or expired token'
        });
    }
    
    res.status(500).json({
        error: 'Internal Server Error',
        message: process.env.NODE_ENV === 'production' ? 'Something went wrong' : err.message
    });
});

// 404 Handler
app.use('*', (req, res) => {
    if (req.originalUrl.startsWith('/api/')) {
        res.status(404).json({
            error: 'API endpoint not found',
            path: req.originalUrl
        });
    } else {
        res.sendFile(path.join(__dirname, 'index.html'));
    }
});

// Graceful Shutdown
process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully');
    server.close(() => {
        if (mongoose.connection.readyState === 1) {
            mongoose.connection.close();
        }
        if (redisClient.isReady) {
            redisClient.quit();
        }
        process.exit(0);
    });
});

process.on('SIGINT', async () => {
    logger.info('SIGINT received, shutting down gracefully');
    server.close(() => {
        if (mongoose.connection.readyState === 1) {
            mongoose.connection.close();
        }
        if (redisClient.isReady) {
            redisClient.quit();
        }
        process.exit(0);
    });
});

const PORT = process.env.PORT || 2025;
server.listen(PORT, () => {
    logger.info(`🚀 Effi AI Government System started on port ${PORT}`);
    logger.info(`🏛️  Environment: ${process.env.NODE_ENV || 'development'}`);
    logger.info(`🔗 WebSocket server ready`);
    logger.info(`📊 Health check: http://localhost:${PORT}/health`);
    logger.info(`🏠 Main system: http://localhost:${PORT}`);
});

module.exports = { app, io, redisClient, activeConnections, governmentConnections };