#!/bin/bash
# שומר את ההוראות האחרונות לקובץ יומן
echo "$(date +%Y-%m-%d_%H:%M:%S): $1" >> session_log.txt
echo "📝 נשמר ביומן." 