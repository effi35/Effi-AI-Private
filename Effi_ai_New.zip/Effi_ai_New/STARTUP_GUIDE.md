# 🚀 Effi-AI הפעלה אוטומטית

המערכת מוגדרת כעת להפעלה אוטומטית!

## 🔄 הפעלה אוטומטית
המערכת תתחיל אוטומטית עם אתחול המכונה באמצעות systemd service.

## 📱 גישה למערכת
- **מקומי**: http://localhost:2025
- **ברשת**: http://10.100.102.200:2025

## ⚡ פקודות מהירות

```bash
# הפעלה מהירה
effi-start

# עצירת השרת
effi-stop

# בדיקת סטטוס
effi-status

# צפייה בלוגים
effi-log

# הצגת כתובת
effi-url
```

## 🛠️ פקודות ידניות

```bash
# הפעלה ידנית
/root/start-effi.sh

# עצירה ידנית
sudo systemctl stop effi-ai

# הפעלה מחדש
sudo systemctl restart effi-ai

# הצגת לוגים
sudo systemctl status effi-ai
```

## 📋 דפי מערכת ראשיים

1. **🏠 דף הבית**: http://localhost:2025
2. **📊 דשבורד**: http://localhost:2025/pages/dashboard_advanced.html
3. **🤖 מערכת AI**: http://localhost:2025/pages/ai_system_advanced.html
4. **🎛️ הגדרות**: http://localhost:2025/pages/unified_settings.html
5. **🔧 אוטומציה**: http://localhost:2025/pages/automation_workflows_advanced.html

## 🔧 פתרון בעיות

אם השרת לא עובד:
```bash
# בדיקת סטטוס
sudo systemctl status effi-ai

# הפעלה מחדש
sudo systemctl restart effi-ai

# צפייה בלוגים
tail -f /root/Effi_ai_New/server.log
```

## ✅ המערכת מוכנה!
השרת יתחיל אוטומטית עם כל אתחול מכונה ויהיה זמין תמיד!