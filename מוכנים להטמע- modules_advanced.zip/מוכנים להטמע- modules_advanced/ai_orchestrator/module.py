"""
AI Orchestrator Module - Entry Point
מודול מתאם הבינה המלאכותית - נקודת כניסה

Professional AI orchestration system for managing and coordinating advanced modules.
מערכת תיאום בינה מלאכותית מקצועית לניהול ותיאום מודולים מתקדמים.
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

# Import all components
from .models.orchestrator_config import OrchestratorConfig
from .core.module_coordinator import ModuleCoordinator
from .ui.orchestrator_dashboard import OrchestratorDashboard
from .utils.orchestrator_utils import OrchestratorUtils
from .utils.system_monitor import SystemMonitor
from .utils.module_validator import ModuleValidator
from .utils.performance_analyzer import PerformanceAnalyzer

logger = logging.getLogger(__name__)

class AIOrchestrator:
    """
    Main AI Orchestrator class for system coordination
    כלל ראשי של מתאם הבינה המלאכותית לתיאום המערכת
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize AI Orchestrator
        אתחול מתאם הבינה המלאכותית
        """
        # Load configuration
        if config_path and Path(config_path).exists():
            self.config = OrchestratorConfig.load_from_file(config_path)
        else:
            self.config = OrchestratorConfig()
        
        # Initialize core components
        self.coordinator = ModuleCoordinator(self.config)
        self.dashboard = OrchestratorDashboard(self.coordinator)
        self.system_monitor = SystemMonitor()
        self.module_validator = ModuleValidator()
        self.performance_analyzer = PerformanceAnalyzer()
        
        # System state
        self.is_running = False
        self.startup_time = None
        
        logger.info("AI Orchestrator initialized successfully")
    
    async def start(self) -> bool:
        """
        Start the AI Orchestrator system
        הפעלת מערכת מתאם הבינה המלאכותית
        """
        try:
            logger.info("Starting AI Orchestrator system...")
            
            # Start system monitoring
            await self.system_monitor.start_monitoring()
            
            # Start performance analysis
            module_names = [name for name in self.config.modules.keys()]
            self.performance_analyzer.start_auto_analysis(module_names)
            
            # Start module coordinator
            success = await self.coordinator.start_system()
            
            if success:
                self.is_running = True
                self.startup_time = OrchestratorUtils.get_system_info()
                logger.info("AI Orchestrator system started successfully")
                return True
            else:
                logger.error("Failed to start AI Orchestrator system")
                return False
                
        except Exception as e:
            logger.error(f"Error starting AI Orchestrator: {e}")
            return False
    
    async def stop(self) -> bool:
        """
        Stop the AI Orchestrator system
        עצירת מערכת מתאם הבינה המלאכותית
        """
        try:
            logger.info("Stopping AI Orchestrator system...")
            
            # Stop performance analysis
            self.performance_analyzer.stop_auto_analysis()
            
            # Stop system monitoring
            await self.system_monitor.stop_monitoring()
            
            # Stop module coordinator
            await self.coordinator.stop_system()
            
            self.is_running = False
            logger.info("AI Orchestrator system stopped successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error stopping AI Orchestrator: {e}")
            return False
    
    async def restart(self) -> bool:
        """
        Restart the AI Orchestrator system
        הפעלה מחדש של מערכת מתאם הבינה המלאכותית
        """
        logger.info("Restarting AI Orchestrator system...")
        await self.stop()
        await asyncio.sleep(2)  # Brief pause
        return await self.start()
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get comprehensive system status
        קבלת מצב מערכת מקיף
        """
        # Get coordinator status
        coordinator_status = self.coordinator.get_system_status()
        
        # Get system health
        health_summary = self.system_monitor.get_health_summary()
        
        # Get active alerts
        active_alerts = self.system_monitor.get_active_alerts()
        
        # Get performance summary for all modules
        performance_summaries = {}
        for module_name in self.config.modules.keys():
            performance_summaries[module_name] = self.performance_analyzer.get_performance_summary(module_name)
        
        return {
            'orchestrator': {
                'is_running': self.is_running,
                'startup_time': self.startup_time,
                'config_loaded': self.config is not None
            },
            'coordinator': coordinator_status,
            'system_health': health_summary,
            'active_alerts': len(active_alerts),
            'performance': performance_summaries,
            'modules_count': len(self.config.modules),
            'last_updated': OrchestratorUtils.get_system_info().get('timestamp')
        }
    
    async def validate_module(self, module_path: str) -> Dict[str, Any]:
        """
        Validate a module
        אימות מודול
        """
        try:
            result = await self.module_validator.validate_module(module_path)
            return {
                'valid': result.is_valid,
                'score': result.score,
                'issues_count': len(result.issues),
                'critical_issues': len(result.get_issues_by_level('critical')),
                'error_issues': len(result.get_issues_by_level('error')),
                'warning_issues': len(result.get_issues_by_level('warning')),
                'report': self.module_validator.generate_validation_report(result)
            }
        except Exception as e:
            logger.error(f"Error validating module {module_path}: {e}")
            return {
                'valid': False,
                'error': str(e)
            }
    
    async def add_module(self, module_name: str, module_path: str, 
                        auto_start: bool = True) -> bool:
        """
        Add new module to the system
        הוספת מודול חדש למערכת
        """
        try:
            # Validate module first
            validation_result = await self.validate_module(module_path)
            if not validation_result['valid']:
                logger.error(f"Module validation failed for {module_name}")
                return False
            
            # Add to configuration
            success = self.config.add_module(module_name, {
                'path': module_path,
                'enabled': True,
                'auto_start': auto_start,
                'priority': 'normal'
            })
            
            if success and self.is_running:
                # Start module if system is running
                return await self.coordinator.start_module(module_name)
            
            return success
            
        except Exception as e:
            logger.error(f"Error adding module {module_name}: {e}")
            return False
    
    async def remove_module(self, module_name: str) -> bool:
        """
        Remove module from the system
        הסרת מודול מהמערכת
        """
        try:
            if self.is_running:
                # Stop module first
                await self.coordinator.stop_module(module_name)
            
            # Remove from configuration
            return self.config.remove_module(module_name)
            
        except Exception as e:
            logger.error(f"Error removing module {module_name}: {e}")
            return False
    
    def save_configuration(self, config_path: str = None) -> bool:
        """
        Save current configuration
        שמירת תצורה נוכחית
        """
        try:
            if config_path:
                return self.config.save_to_file(config_path)
            else:
                # Save to default location
                default_path = Path(__file__).parent / "configs" / "orchestrator_config.json"
                OrchestratorUtils.ensure_directory(str(default_path.parent))
                return self.config.save_to_file(str(default_path))
                
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            return False
    
    def get_performance_report(self, module_name: str = None) -> Dict[str, Any]:
        """
        Get detailed performance report
        קבלת דוח ביצועים מפורט
        """
        if module_name:
            # Single module report
            analysis = self.performance_analyzer.analyze_performance(module_name)
            benchmarks = self.performance_analyzer.get_benchmark_status(module_name)
            
            return {
                'module_name': module_name,
                'analysis': analysis,
                'benchmarks': benchmarks
            }
        else:
            # All modules report
            reports = {}
            for name in self.config.modules.keys():
                reports[name] = self.get_performance_report(name)
            
            return {
                'modules': reports,
                'system_summary': self.system_monitor.get_health_summary()
            }
    
    async def run_dashboard(self, host: str = "localhost", port: int = 8080):
        """
        Run the orchestrator dashboard
        הפעלת לוח הבקרה של המתאם
        """
        try:
            logger.info(f"Starting orchestrator dashboard on {host}:{port}")
            await self.dashboard.run(host, port)
        except Exception as e:
            logger.error(f"Error running dashboard: {e}")

# Convenience functions for module usage
async def start_orchestrator(config_path: str = None) -> AIOrchestrator:
    """
    Start AI Orchestrator with configuration
    הפעלת מתאם הבינה המלאכותית עם תצורה
    """
    orchestrator = AIOrchestrator(config_path)
    success = await orchestrator.start()
    
    if success:
        logger.info("AI Orchestrator started successfully")
        return orchestrator
    else:
        raise RuntimeError("Failed to start AI Orchestrator")

async def main():
    """
    Main entry point for running the orchestrator
    נקודת כניסה ראשית להפעלת המתאם
    """
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('orchestrator.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    try:
        # Start orchestrator
        orchestrator = await start_orchestrator()
        
        # Run dashboard
        await orchestrator.run_dashboard()
        
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, shutting down...")
    except Exception as e:
        logger.error(f"Error in main: {e}")
    finally:
        if 'orchestrator' in locals():
            await orchestrator.stop()

if __name__ == "__main__":
    asyncio.run(main())