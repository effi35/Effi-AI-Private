"""
AI Orchestrator Utilities
כלי עזר למתאם הבינה המלאכותית

Professional utility functions for the AI Orchestrator system.
פונקציות עזר מקצועיות למערכת מתאם הבינה המלאכותית.
"""

import os
import json
import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import hashlib
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

class OrchestratorUtils:
    """
    Comprehensive utility class for AI Orchestrator operations
    כלי עזר מקיף לפעולות מתאם הבינה המלאכותית
    """
    
    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """
        Get comprehensive system information
        קבלת מידע מערכת מקיף
        """
        try:
            import psutil
            import platform
            
            # System info
            info = {
                'platform': platform.platform(),
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'python_version': sys.version,
                'cpu_count': psutil.cpu_count(),
                'memory_total': psutil.virtual_memory().total,
                'disk_usage': {}
            }
            
            # Disk usage for each mount point
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    info['disk_usage'][partition.mountpoint] = {
                        'total': usage.total,
                        'used': usage.used,
                        'free': usage.free,
                        'percent': (usage.used / usage.total) * 100
                    }
                except PermissionError:
                    continue
            
            return info
            
        except ImportError:
            logger.warning("psutil not available, returning basic system info")
            return {
                'platform': 'unknown',
                'python_version': sys.version,
                'error': 'psutil_not_available'
            }
    
    @staticmethod
    def format_bytes(bytes_val: int) -> str:
        """
        Format bytes to human readable format
        עיצוב בתים לפורמט קריא לאדם
        """
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} PB"
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        """
        Format duration in seconds to human readable format
        עיצוב משך זמן בשניות לפורמט קריא לאדם
        """
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f}m"
        elif seconds < 86400:
            hours = seconds / 3600
            return f"{hours:.1f}h"
        else:
            days = seconds / 86400
            return f"{days:.1f}d"
    
    @staticmethod
    def calculate_hash(data: str) -> str:
        """
        Calculate SHA-256 hash of data
        חישוב hash SHA-256 של נתונים
        """
        return hashlib.sha256(data.encode()).hexdigest()
    
    @staticmethod
    def validate_json(json_str: str) -> Tuple[bool, Optional[Dict]]:
        """
        Validate JSON string
        אימות מחרוזת JSON
        """
        try:
            data = json.loads(json_str)
            return True, data
        except json.JSONDecodeError as e:
            logger.error(f"JSON validation failed: {e}")
            return False, None
    
    @staticmethod
    def safe_execute_command(command: List[str], timeout: int = 30) -> Tuple[bool, str, str]:
        """
        Safely execute command with timeout
        הרצת פקודה בטוחה עם timeout
        """
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False
            )
            return True, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "Command timed out"
        except Exception as e:
            return False, "", str(e)
    
    @staticmethod
    def create_backup_name(base_name: str) -> str:
        """
        Create backup filename with timestamp
        יצירת שם קובץ גיבוי עם חותמת זמן
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{base_name}_backup_{timestamp}"
    
    @staticmethod
    def ensure_directory(path: str) -> bool:
        """
        Ensure directory exists, create if necessary
        וידוא שתיקייה קיימת, יצירה במידת הצורך
        """
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            logger.error(f"Failed to create directory {path}: {e}")
            return False
    
    @staticmethod
    def clean_old_files(directory: str, max_age_days: int = 7) -> int:
        """
        Clean old files from directory
        ניקוי קבצים ישנים מתיקייה
        """
        try:
            cleaned = 0
            cutoff_date = datetime.now() - timedelta(days=max_age_days)
            
            for file_path in Path(directory).glob("*"):
                if file_path.is_file():
                    file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                    if file_time < cutoff_date:
                        file_path.unlink()
                        cleaned += 1
                        
            return cleaned
        except Exception as e:
            logger.error(f"Failed to clean old files: {e}")
            return 0
    
    @staticmethod
    def get_memory_usage() -> Dict[str, float]:
        """
        Get current memory usage
        קבלת השימוש הנוכחי בזיכרון
        """
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            return {
                'rss': memory_info.rss,  # Resident Set Size
                'vms': memory_info.vms,  # Virtual Memory Size
                'percent': process.memory_percent(),
                'available': psutil.virtual_memory().available,
                'total': psutil.virtual_memory().total
            }
        except ImportError:
            return {'error': 'psutil_not_available'}
    
    @staticmethod
    def format_performance_stats(stats: Dict[str, Any]) -> str:
        """
        Format performance statistics for display
        עיצוב סטטיסטיקות ביצועים לתצוגה
        """
        formatted = []
        
        if 'cpu_percent' in stats:
            formatted.append(f"CPU: {stats['cpu_percent']:.1f}%")
        
        if 'memory_percent' in stats:
            formatted.append(f"זיכרון: {stats['memory_percent']:.1f}%")
        
        if 'active_modules' in stats:
            formatted.append(f"מודולים פעילים: {stats['active_modules']}")
        
        if 'uptime' in stats:
            uptime_str = OrchestratorUtils.format_duration(stats['uptime'])
            formatted.append(f"זמן פעילות: {uptime_str}")
        
        return " | ".join(formatted)
    
    @staticmethod
    async def async_retry(func, max_retries: int = 3, delay: float = 1.0):
        """
        Async retry mechanism with exponential backoff
        מנגנון חזרה אסינכרוני עם backoff אקספוננציאלי
        """
        for attempt in range(max_retries):
            try:
                if asyncio.iscoroutinefunction(func):
                    return await func()
                else:
                    return func()
            except Exception as e:
                if attempt == max_retries - 1:
                    raise e
                
                wait_time = delay * (2 ** attempt)
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
    
    @staticmethod
    def validate_module_structure(module_path: str) -> Tuple[bool, List[str]]:
        """
        Validate module directory structure
        אימות מבנה תיקיית מודול
        """
        required_files = ['module.py', 'metadata.json']
        required_dirs = ['models', 'core', 'ui', 'utils']
        issues = []
        
        module_path = Path(module_path)
        
        # Check if module directory exists
        if not module_path.exists():
            issues.append(f"Module directory does not exist: {module_path}")
            return False, issues
        
        # Check required files
        for file_name in required_files:
            file_path = module_path / file_name
            if not file_path.exists():
                issues.append(f"Missing required file: {file_name}")
        
        # Check required directories
        for dir_name in required_dirs:
            dir_path = module_path / dir_name
            if not dir_path.exists():
                issues.append(f"Missing required directory: {dir_name}")
        
        return len(issues) == 0, issues
    
    @staticmethod
    def generate_module_id(module_name: str) -> str:
        """
        Generate unique module ID
        יצירת מזהה ייחודי למודול
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        hash_part = hashlib.md5(module_name.encode()).hexdigest()[:8]
        return f"{module_name}_{timestamp}_{hash_part}"
    
    @staticmethod
    def parse_hebrew_text(text: str) -> Dict[str, Any]:
        """
        Parse Hebrew text and extract metadata
        ניתוח טקסט עברי וחילוץ מטא-דטה
        """
        hebrew_chars = sum(1 for char in text if '\u0590' <= char <= '\u05FF')
        total_chars = len(text.replace(' ', ''))
        
        return {
            'hebrew_ratio': hebrew_chars / total_chars if total_chars > 0 else 0,
            'is_rtl': hebrew_chars > total_chars * 0.5,
            'hebrew_words': len([word for word in text.split() if any('\u0590' <= char <= '\u05FF' for char in word)]),
            'total_words': len(text.split()),
            'character_count': len(text),
            'hebrew_character_count': hebrew_chars
        }