"""
System Monitor Utilities
כלי עזר לניטור המערכת

Real-time system monitoring and health checking utilities.
כלי עזר לניטור מערכת בזמן אמת ובדיקת תקינות.
"""

import asyncio
import logging
import time
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class HealthStatus(Enum):
    """System health status levels"""
    EXCELLENT = "excellent"      # מצוין
    GOOD = "good"               # טוב  
    WARNING = "warning"         # אזהרה
    CRITICAL = "critical"       # קריטי
    UNKNOWN = "unknown"         # לא ידוע

@dataclass
class SystemMetrics:
    """System performance metrics"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_used: int
    memory_total: int
    disk_percent: float
    disk_used: int
    disk_total: int
    active_modules: int
    response_time: float
    health_status: HealthStatus

@dataclass
class Alert:
    """System alert data"""
    timestamp: datetime
    level: str
    message: str
    source: str
    resolved: bool = False

class SystemMonitor:
    """
    Comprehensive system monitoring with real-time health checks
    ניטור מערכת מקיף עם בדיקות תקינות בזמן אמת
    """
    
    def __init__(self):
        self.metrics_history: List[SystemMetrics] = []
        self.alerts: List[Alert] = []
        self.alert_callbacks: List[Callable] = []
        self.monitoring_active = False
        self.monitor_task: Optional[asyncio.Task] = None
        
        # Thresholds for alerts
        self.cpu_warning_threshold = 80.0
        self.cpu_critical_threshold = 95.0
        self.memory_warning_threshold = 85.0
        self.memory_critical_threshold = 95.0
        self.disk_warning_threshold = 90.0
        self.disk_critical_threshold = 98.0
        self.response_warning_threshold = 2.0
        self.response_critical_threshold = 5.0
        
        # History retention
        self.max_history_size = 1000
        self.max_alert_age_hours = 24
    
    async def start_monitoring(self, interval: float = 5.0):
        """
        Start continuous system monitoring
        התחלת ניטור מערכת רציף
        """
        if self.monitoring_active:
            logger.warning("Monitoring already active")
            return
        
        self.monitoring_active = True
        self.monitor_task = asyncio.create_task(
            self._monitoring_loop(interval)
        )
        logger.info(f"System monitoring started (interval: {interval}s)")
    
    async def stop_monitoring(self):
        """
        Stop system monitoring
        עצירת ניטור המערכת
        """
        self.monitoring_active = False
        if self.monitor_task:
            self.monitor_task.cancel()
            try:
                await self.monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("System monitoring stopped")
    
    async def _monitoring_loop(self, interval: float):
        """
        Main monitoring loop
        לולאת הניטור הראשית
        """
        while self.monitoring_active:
            try:
                # Collect metrics
                metrics = await self._collect_metrics()
                
                # Store metrics
                self.metrics_history.append(metrics)
                
                # Check for alerts
                await self._check_alerts(metrics)
                
                # Clean old data
                self._cleanup_old_data()
                
                await asyncio.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(interval)
    
    async def _collect_metrics(self) -> SystemMetrics:
        """
        Collect current system metrics
        איסוף מדדי מערכת נוכחיים
        """
        try:
            import psutil
            
            # Measure response time
            start_time = time.time()
            
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=0.1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_used = memory.used
            memory_total = memory.total
            
            # Disk usage (main partition)
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            disk_used = disk.used
            disk_total = disk.total
            
            # Response time
            response_time = time.time() - start_time
            
            # Active modules (mock - would be real in production)
            active_modules = len([p for p in psutil.process_iter(['name']) 
                                if 'python' in p.info['name'].lower()])
            
            # Determine health status
            health_status = self._calculate_health_status(
                cpu_percent, memory_percent, disk_percent, response_time
            )
            
            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_used=memory_used,
                memory_total=memory_total,
                disk_percent=disk_percent,
                disk_used=disk_used,
                disk_total=disk_total,
                active_modules=active_modules,
                response_time=response_time,
                health_status=health_status
            )
            
        except ImportError:
            logger.warning("psutil not available, returning mock metrics")
            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=25.0,
                memory_percent=45.0,
                memory_used=4000000000,
                memory_total=8000000000,
                disk_percent=60.0,
                disk_used=300000000000,
                disk_total=500000000000,
                active_modules=5,
                response_time=0.1,
                health_status=HealthStatus.GOOD
            )
    
    def _calculate_health_status(self, cpu: float, memory: float, 
                               disk: float, response_time: float) -> HealthStatus:
        """
        Calculate overall system health status
        חישוב מצב בריאות כולל של המערכת
        """
        # Critical conditions
        if (cpu >= self.cpu_critical_threshold or 
            memory >= self.memory_critical_threshold or
            disk >= self.disk_critical_threshold or
            response_time >= self.response_critical_threshold):
            return HealthStatus.CRITICAL
        
        # Warning conditions
        if (cpu >= self.cpu_warning_threshold or
            memory >= self.memory_warning_threshold or
            disk >= self.disk_warning_threshold or
            response_time >= self.response_warning_threshold):
            return HealthStatus.WARNING
        
        # Excellent conditions
        if cpu < 30 and memory < 50 and disk < 70 and response_time < 0.5:
            return HealthStatus.EXCELLENT
        
        # Default to good
        return HealthStatus.GOOD
    
    async def _check_alerts(self, metrics: SystemMetrics):
        """
        Check for alert conditions
        בדיקת תנאי אזהרה
        """
        alerts_to_create = []
        
        # CPU alerts
        if metrics.cpu_percent >= self.cpu_critical_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="critical",
                message=f"CPU usage critical: {metrics.cpu_percent:.1f}%",
                source="cpu_monitor"
            ))
        elif metrics.cpu_percent >= self.cpu_warning_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="warning",
                message=f"CPU usage high: {metrics.cpu_percent:.1f}%",
                source="cpu_monitor"
            ))
        
        # Memory alerts
        if metrics.memory_percent >= self.memory_critical_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="critical",
                message=f"Memory usage critical: {metrics.memory_percent:.1f}%",
                source="memory_monitor"
            ))
        elif metrics.memory_percent >= self.memory_warning_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="warning",
                message=f"Memory usage high: {metrics.memory_percent:.1f}%",
                source="memory_monitor"
            ))
        
        # Disk alerts
        if metrics.disk_percent >= self.disk_critical_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="critical",
                message=f"Disk usage critical: {metrics.disk_percent:.1f}%",
                source="disk_monitor"
            ))
        elif metrics.disk_percent >= self.disk_warning_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="warning",
                message=f"Disk usage high: {metrics.disk_percent:.1f}%",
                source="disk_monitor"
            ))
        
        # Response time alerts
        if metrics.response_time >= self.response_critical_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="critical",
                message=f"Response time critical: {metrics.response_time:.2f}s",
                source="performance_monitor"
            ))
        elif metrics.response_time >= self.response_warning_threshold:
            alerts_to_create.append(Alert(
                timestamp=datetime.now(),
                level="warning",
                message=f"Response time high: {metrics.response_time:.2f}s",
                source="performance_monitor"
            ))
        
        # Add new alerts and trigger callbacks
        for alert in alerts_to_create:
            self.alerts.append(alert)
            await self._trigger_alert_callbacks(alert)
    
    async def _trigger_alert_callbacks(self, alert: Alert):
        """
        Trigger registered alert callbacks
        הפעלת callbacks רשומים לאזהרות
        """
        for callback in self.alert_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(alert)
                else:
                    callback(alert)
            except Exception as e:
                logger.error(f"Error in alert callback: {e}")
    
    def _cleanup_old_data(self):
        """
        Clean up old metrics and alerts
        ניקוי מדדים ואזהרות ישנים
        """
        # Keep only recent metrics
        if len(self.metrics_history) > self.max_history_size:
            self.metrics_history = self.metrics_history[-self.max_history_size:]
        
        # Remove old alerts
        cutoff_time = datetime.now() - timedelta(hours=self.max_alert_age_hours)
        self.alerts = [alert for alert in self.alerts 
                      if alert.timestamp > cutoff_time]
    
    def get_current_metrics(self) -> Optional[SystemMetrics]:
        """
        Get latest system metrics
        קבלת מדדי מערכת אחרונים
        """
        return self.metrics_history[-1] if self.metrics_history else None
    
    def get_metrics_history(self, hours: int = 1) -> List[SystemMetrics]:
        """
        Get metrics history for specified hours
        קבלת היסטוריית מדדים לשעות מוגדרות
        """
        cutoff_time = datetime.now() - timedelta(hours=hours)
        return [metrics for metrics in self.metrics_history 
                if metrics.timestamp > cutoff_time]
    
    def get_active_alerts(self) -> List[Alert]:
        """
        Get unresolved alerts
        קבלת אזהרות שלא נפתרו
        """
        return [alert for alert in self.alerts if not alert.resolved]
    
    def resolve_alert(self, alert_index: int) -> bool:
        """
        Mark alert as resolved
        סימון אזהרה כנפתרה
        """
        try:
            if 0 <= alert_index < len(self.alerts):
                self.alerts[alert_index].resolved = True
                return True
            return False
        except Exception:
            return False
    
    def add_alert_callback(self, callback: Callable):
        """
        Add callback for new alerts
        הוספת callback לאזהרות חדשות
        """
        self.alert_callbacks.append(callback)
    
    def get_health_summary(self) -> Dict[str, Any]:
        """
        Get comprehensive health summary
        קבלת סיכום בריאות מקיף
        """
        current = self.get_current_metrics()
        if not current:
            return {'status': 'unknown', 'message': 'אין נתונים זמינים'}
        
        active_alerts = self.get_active_alerts()
        critical_alerts = [a for a in active_alerts if a.level == 'critical']
        warning_alerts = [a for a in active_alerts if a.level == 'warning']
        
        # Calculate uptime (mock)
        uptime_hours = 24  # Would be calculated from actual system start time
        
        return {
            'status': current.health_status.value,
            'status_hebrew': self._get_hebrew_status(current.health_status),
            'cpu_percent': current.cpu_percent,
            'memory_percent': current.memory_percent,
            'disk_percent': current.disk_percent,
            'response_time': current.response_time,
            'active_modules': current.active_modules,
            'uptime_hours': uptime_hours,
            'critical_alerts': len(critical_alerts),
            'warning_alerts': len(warning_alerts),
            'total_alerts': len(active_alerts),
            'last_updated': current.timestamp.isoformat()
        }
    
    def _get_hebrew_status(self, status: HealthStatus) -> str:
        """Get Hebrew translation of health status"""
        status_map = {
            HealthStatus.EXCELLENT: "מצוין",
            HealthStatus.GOOD: "טוב",
            HealthStatus.WARNING: "אזהרה", 
            HealthStatus.CRITICAL: "קריטי",
            HealthStatus.UNKNOWN: "לא ידוע"
        }
        return status_map.get(status, "לא ידוע")