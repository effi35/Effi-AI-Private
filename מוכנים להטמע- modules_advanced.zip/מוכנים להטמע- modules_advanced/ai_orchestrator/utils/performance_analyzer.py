"""
Performance Analyzer Utilities
כלי עזר לניתוח ביצועים

Advanced performance analysis and optimization recommendations.
ניתוח ביצועים מתקדם והמלצות אופטימיזציה.
"""

import asyncio
import time
import logging
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import statistics
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

class MetricType(Enum):
    """Performance metric types"""
    RESPONSE_TIME = "response_time"
    THROUGHPUT = "throughput"
    CPU_USAGE = "cpu_usage"
    MEMORY_USAGE = "memory_usage"
    ERROR_RATE = "error_rate"
    LATENCY = "latency"

class PerformanceLevel(Enum):
    """Performance levels"""
    EXCELLENT = "excellent"    # מצוין
    GOOD = "good"             # טוב
    AVERAGE = "average"       # ממוצע
    POOR = "poor"            # גרוע
    CRITICAL = "critical"    # קריטי

@dataclass
class PerformanceMetric:
    """Individual performance metric"""
    timestamp: datetime
    metric_type: MetricType
    value: float
    source: str
    context: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PerformanceAnalysis:
    """Performance analysis result"""
    module_name: str
    analysis_time: datetime
    overall_score: float  # 0-100
    level: PerformanceLevel
    metrics_summary: Dict[MetricType, Dict[str, float]]
    bottlenecks: List[str]
    recommendations: List[str]
    trends: Dict[str, str]  # improving, stable, degrading

@dataclass
class PerformanceBenchmark:
    """Performance benchmark data"""
    name: str
    target_value: float
    current_value: float
    status: str  # met, near, missed
    improvement_percent: float

class PerformanceAnalyzer:
    """
    Advanced performance analysis system
    מערכת ניתוח ביצועים מתקדמת
    """
    
    def __init__(self, history_size: int = 10000):
        self.metrics: Dict[str, deque] = defaultdict(lambda: deque(maxlen=history_size))
        self.benchmarks: Dict[str, Dict[MetricType, float]] = {}
        self.analysis_callbacks: List[Callable] = []
        
        # Performance thresholds
        self.thresholds = {
            MetricType.RESPONSE_TIME: {
                'excellent': 0.1,
                'good': 0.5,
                'average': 1.0,
                'poor': 2.0
            },
            MetricType.CPU_USAGE: {
                'excellent': 20.0,
                'good': 50.0,
                'average': 70.0,
                'poor': 85.0
            },
            MetricType.MEMORY_USAGE: {
                'excellent': 30.0,
                'good': 60.0,
                'average': 80.0,
                'poor': 90.0
            },
            MetricType.ERROR_RATE: {
                'excellent': 0.1,
                'good': 0.5,
                'average': 1.0,
                'poor': 2.0
            }
        }
        
        # Automatic analysis interval
        self.auto_analysis_interval = 300  # 5 minutes
        self.auto_analysis_task: Optional[asyncio.Task] = None
        self.auto_analysis_enabled = False
    
    def record_metric(self, module_name: str, metric: PerformanceMetric):
        """
        Record performance metric
        רישום מדד ביצועים
        """
        key = f"{module_name}:{metric.metric_type.value}"
        self.metrics[key].append(metric)
        
        # Trigger real-time analysis if needed
        if self._should_trigger_analysis(module_name, metric):
            asyncio.create_task(self._trigger_analysis_callback(module_name, metric))
    
    def record_response_time(self, module_name: str, operation: str, 
                           duration: float, context: Dict[str, Any] = None):
        """
        Record response time metric
        רישום מדד זמן תגובה
        """
        metric = PerformanceMetric(
            timestamp=datetime.now(),
            metric_type=MetricType.RESPONSE_TIME,
            value=duration,
            source=operation,
            context=context or {}
        )
        self.record_metric(module_name, metric)
    
    def record_throughput(self, module_name: str, operation: str, 
                         requests_per_second: float, context: Dict[str, Any] = None):
        """
        Record throughput metric
        רישום מדד תפוקה
        """
        metric = PerformanceMetric(
            timestamp=datetime.now(),
            metric_type=MetricType.THROUGHPUT,
            value=requests_per_second,
            source=operation,
            context=context or {}
        )
        self.record_metric(module_name, metric)
    
    def record_resource_usage(self, module_name: str, cpu_percent: float, 
                            memory_percent: float, context: Dict[str, Any] = None):
        """
        Record resource usage metrics
        רישום מדדי שימוש במשאבים
        """
        timestamp = datetime.now()
        
        cpu_metric = PerformanceMetric(
            timestamp=timestamp,
            metric_type=MetricType.CPU_USAGE,
            value=cpu_percent,
            source="system_monitor",
            context=context or {}
        )
        
        memory_metric = PerformanceMetric(
            timestamp=timestamp,
            metric_type=MetricType.MEMORY_USAGE,
            value=memory_percent,
            source="system_monitor",
            context=context or {}
        )
        
        self.record_metric(module_name, cpu_metric)
        self.record_metric(module_name, memory_metric)
    
    def analyze_performance(self, module_name: str, 
                          time_window_hours: int = 1) -> PerformanceAnalysis:
        """
        Comprehensive performance analysis
        ניתוח ביצועים מקיף
        """
        cutoff_time = datetime.now() - timedelta(hours=time_window_hours)
        
        # Collect metrics for analysis
        module_metrics = {}
        for key, metrics_deque in self.metrics.items():
            if key.startswith(f"{module_name}:"):
                metric_type_str = key.split(':', 1)[1]
                try:
                    metric_type = MetricType(metric_type_str)
                    recent_metrics = [m for m in metrics_deque if m.timestamp > cutoff_time]
                    if recent_metrics:
                        module_metrics[metric_type] = recent_metrics
                except ValueError:
                    continue
        
        # Calculate metrics summary
        metrics_summary = {}
        for metric_type, metrics_list in module_metrics.items():
            values = [m.value for m in metrics_list]
            if values:
                metrics_summary[metric_type] = {
                    'count': len(values),
                    'avg': statistics.mean(values),
                    'min': min(values),
                    'max': max(values),
                    'median': statistics.median(values),
                    'std': statistics.stdev(values) if len(values) > 1 else 0
                }
        
        # Calculate overall performance score
        overall_score = self._calculate_performance_score(metrics_summary)
        
        # Determine performance level
        level = self._determine_performance_level(overall_score)
        
        # Identify bottlenecks
        bottlenecks = self._identify_bottlenecks(metrics_summary)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(metrics_summary, bottlenecks)
        
        # Analyze trends
        trends = self._analyze_trends(module_name, module_metrics)
        
        return PerformanceAnalysis(
            module_name=module_name,
            analysis_time=datetime.now(),
            overall_score=overall_score,
            level=level,
            metrics_summary=metrics_summary,
            bottlenecks=bottlenecks,
            recommendations=recommendations,
            trends=trends
        )
    
    def set_benchmark(self, module_name: str, metric_type: MetricType, target_value: float):
        """
        Set performance benchmark
        הגדרת בנצ'מרק ביצועים
        """
        if module_name not in self.benchmarks:
            self.benchmarks[module_name] = {}
        self.benchmarks[module_name][metric_type] = target_value
    
    def get_benchmark_status(self, module_name: str) -> List[PerformanceBenchmark]:
        """
        Get benchmark comparison status
        קבלת מצב השוואת בנצ'מרק
        """
        if module_name not in self.benchmarks:
            return []
        
        benchmarks = []
        analysis = self.analyze_performance(module_name)
        
        for metric_type, target_value in self.benchmarks[module_name].items():
            if metric_type in analysis.metrics_summary:
                current_value = analysis.metrics_summary[metric_type]['avg']
                
                # Determine status (lower is better for most metrics)
                if metric_type in [MetricType.RESPONSE_TIME, MetricType.CPU_USAGE, 
                                 MetricType.MEMORY_USAGE, MetricType.ERROR_RATE]:
                    if current_value <= target_value:
                        status = "met"
                    elif current_value <= target_value * 1.1:
                        status = "near"
                    else:
                        status = "missed"
                    
                    improvement_percent = ((target_value - current_value) / target_value) * 100
                else:  # Higher is better (e.g., THROUGHPUT)
                    if current_value >= target_value:
                        status = "met"
                    elif current_value >= target_value * 0.9:
                        status = "near"
                    else:
                        status = "missed"
                    
                    improvement_percent = ((current_value - target_value) / target_value) * 100
                
                benchmarks.append(PerformanceBenchmark(
                    name=f"{metric_type.value}",
                    target_value=target_value,
                    current_value=current_value,
                    status=status,
                    improvement_percent=improvement_percent
                ))
        
        return benchmarks
    
    def start_auto_analysis(self, modules: List[str]):
        """
        Start automatic performance analysis
        התחלת ניתוח ביצועים אוטומטי
        """
        if self.auto_analysis_enabled:
            return
        
        self.auto_analysis_enabled = True
        self.auto_analysis_task = asyncio.create_task(
            self._auto_analysis_loop(modules)
        )
        logger.info("Automatic performance analysis started")
    
    def stop_auto_analysis(self):
        """
        Stop automatic performance analysis
        עצירת ניתוח ביצועים אוטומטי
        """
        self.auto_analysis_enabled = False
        if self.auto_analysis_task:
            self.auto_analysis_task.cancel()
        logger.info("Automatic performance analysis stopped")
    
    async def _auto_analysis_loop(self, modules: List[str]):
        """
        Automatic analysis loop
        לולאת ניתוח אוטומטי
        """
        while self.auto_analysis_enabled:
            try:
                for module_name in modules:
                    analysis = self.analyze_performance(module_name)
                    
                    # Trigger callbacks if performance is concerning
                    if analysis.level in [PerformanceLevel.POOR, PerformanceLevel.CRITICAL]:
                        await self._trigger_analysis_callback(module_name, analysis)
                
                await asyncio.sleep(self.auto_analysis_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in auto analysis loop: {e}")
                await asyncio.sleep(60)  # Wait before retrying
    
    def _calculate_performance_score(self, metrics_summary: Dict[MetricType, Dict[str, float]]) -> float:
        """
        Calculate overall performance score
        חישוב ציון ביצועים כולל
        """
        if not metrics_summary:
            return 50.0  # Neutral score
        
        scores = []
        
        for metric_type, summary in metrics_summary.items():
            avg_value = summary['avg']
            score = self._calculate_metric_score(metric_type, avg_value)
            scores.append(score)
        
        return statistics.mean(scores) if scores else 50.0
    
    def _calculate_metric_score(self, metric_type: MetricType, value: float) -> float:
        """
        Calculate score for individual metric
        חישוב ציון למדד בודד
        """
        if metric_type not in self.thresholds:
            return 50.0
        
        thresholds = self.thresholds[metric_type]
        
        # For metrics where lower is better
        if metric_type in [MetricType.RESPONSE_TIME, MetricType.CPU_USAGE, 
                          MetricType.MEMORY_USAGE, MetricType.ERROR_RATE]:
            if value <= thresholds['excellent']:
                return 95.0
            elif value <= thresholds['good']:
                return 80.0
            elif value <= thresholds['average']:
                return 60.0
            elif value <= thresholds['poor']:
                return 30.0
            else:
                return 10.0
        
        # For metrics where higher is better (e.g., throughput)
        else:
            # Inverse logic for throughput-type metrics
            if value >= thresholds['poor']:
                return 95.0
            elif value >= thresholds['average']:
                return 80.0
            elif value >= thresholds['good']:
                return 60.0
            elif value >= thresholds['excellent']:
                return 30.0
            else:
                return 10.0
    
    def _determine_performance_level(self, score: float) -> PerformanceLevel:
        """
        Determine performance level from score
        קביעת רמת ביצועים מהציון
        """
        if score >= 90:
            return PerformanceLevel.EXCELLENT
        elif score >= 75:
            return PerformanceLevel.GOOD
        elif score >= 50:
            return PerformanceLevel.AVERAGE
        elif score >= 25:
            return PerformanceLevel.POOR
        else:
            return PerformanceLevel.CRITICAL
    
    def _identify_bottlenecks(self, metrics_summary: Dict[MetricType, Dict[str, float]]) -> List[str]:
        """
        Identify performance bottlenecks
        זיהוי צווארי בקבוק בביצועים
        """
        bottlenecks = []
        
        for metric_type, summary in metrics_summary.items():
            avg_value = summary['avg']
            max_value = summary['max']
            
            # Check if metric exceeds thresholds
            if metric_type in self.thresholds:
                thresholds = self.thresholds[metric_type]
                
                if metric_type in [MetricType.RESPONSE_TIME, MetricType.CPU_USAGE, 
                                  MetricType.MEMORY_USAGE, MetricType.ERROR_RATE]:
                    if avg_value > thresholds['poor']:
                        bottlenecks.append(f"High {metric_type.value}: {avg_value:.2f}")
                    elif max_value > thresholds['poor'] * 1.5:
                        bottlenecks.append(f"Spike in {metric_type.value}: {max_value:.2f}")
        
        return bottlenecks
    
    def _generate_recommendations(self, metrics_summary: Dict[MetricType, Dict[str, float]], 
                                bottlenecks: List[str]) -> List[str]:
        """
        Generate optimization recommendations
        יצירת המלצות אופטימיזציה
        """
        recommendations = []
        
        # Response time recommendations
        if MetricType.RESPONSE_TIME in metrics_summary:
            avg_response = metrics_summary[MetricType.RESPONSE_TIME]['avg']
            if avg_response > 1.0:
                recommendations.append("שפר זמני תגובה על ידי אופטימיזציה של שאילתות")
                recommendations.append("שקול שימוש ב-caching לפעולות חוזרות")
        
        # CPU usage recommendations
        if MetricType.CPU_USAGE in metrics_summary:
            avg_cpu = metrics_summary[MetricType.CPU_USAGE]['avg']
            if avg_cpu > 70:
                recommendations.append("שפר שימוש ב-CPU על ידי אופטימיזציה של אלגוריתמים")
                recommendations.append("שקול שימוש ב-async/await לפעולות I/O")
        
        # Memory usage recommendations
        if MetricType.MEMORY_USAGE in metrics_summary:
            avg_memory = metrics_summary[MetricType.MEMORY_USAGE]['avg']
            if avg_memory > 80:
                recommendations.append("שפר ניהול זיכרון על ידי שחרור משאבים לא נחוצים")
                recommendations.append("שקול שימוש ב-memory profiling לזיהוי דליפות")
        
        # Error rate recommendations
        if MetricType.ERROR_RATE in metrics_summary:
            avg_errors = metrics_summary[MetricType.ERROR_RATE]['avg']
            if avg_errors > 1.0:
                recommendations.append("שפר טיפול בשגיאות ואיכות הקוד")
                recommendations.append("הוסף בדיקות נוספות ו-logging מפורט")
        
        # General recommendations based on bottlenecks
        if len(bottlenecks) > 2:
            recommendations.append("בצע ניתוח מקיף של ביצועים המערכת")
            recommendations.append("שקול שדרוג חומרה או תשתית")
        
        return recommendations
    
    def _analyze_trends(self, module_name: str, 
                       module_metrics: Dict[MetricType, List[PerformanceMetric]]) -> Dict[str, str]:
        """
        Analyze performance trends
        ניתוח מגמות ביצועים
        """
        trends = {}
        
        for metric_type, metrics_list in module_metrics.items():
            if len(metrics_list) < 10:  # Need enough data points
                trends[metric_type.value] = "insufficient_data"
                continue
            
            # Sort by timestamp
            sorted_metrics = sorted(metrics_list, key=lambda m: m.timestamp)
            values = [m.value for m in sorted_metrics]
            
            # Simple trend analysis using first and last third of data
            first_third = values[:len(values)//3]
            last_third = values[-(len(values)//3):]
            
            if not first_third or not last_third:
                trends[metric_type.value] = "insufficient_data"
                continue
            
            first_avg = statistics.mean(first_third)
            last_avg = statistics.mean(last_third)
            
            # Calculate percentage change
            if first_avg != 0:
                change_percent = ((last_avg - first_avg) / first_avg) * 100
                
                # For metrics where lower is better
                if metric_type in [MetricType.RESPONSE_TIME, MetricType.CPU_USAGE, 
                                  MetricType.MEMORY_USAGE, MetricType.ERROR_RATE]:
                    if change_percent < -5:
                        trends[metric_type.value] = "improving"
                    elif change_percent > 5:
                        trends[metric_type.value] = "degrading"
                    else:
                        trends[metric_type.value] = "stable"
                else:  # For metrics where higher is better
                    if change_percent > 5:
                        trends[metric_type.value] = "improving"
                    elif change_percent < -5:
                        trends[metric_type.value] = "degrading"
                    else:
                        trends[metric_type.value] = "stable"
            else:
                trends[metric_type.value] = "stable"
        
        return trends
    
    def _should_trigger_analysis(self, module_name: str, metric: PerformanceMetric) -> bool:
        """
        Determine if metric should trigger immediate analysis
        קביעה אם מדד צריך להפעיל ניתוח מיידי
        """
        # Trigger on critical values
        if metric.metric_type in self.thresholds:
            thresholds = self.thresholds[metric.metric_type]
            
            if metric.metric_type in [MetricType.RESPONSE_TIME, MetricType.CPU_USAGE, 
                                    MetricType.MEMORY_USAGE, MetricType.ERROR_RATE]:
                return metric.value > thresholds['poor']
        
        return False
    
    async def _trigger_analysis_callback(self, module_name: str, data: Any):
        """
        Trigger registered analysis callbacks
        הפעלת callbacks רשומים לניתוח
        """
        for callback in self.analysis_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(module_name, data)
                else:
                    callback(module_name, data)
            except Exception as e:
                logger.error(f"Error in analysis callback: {e}")
    
    def add_analysis_callback(self, callback: Callable):
        """
        Add callback for performance analysis alerts
        הוספת callback לאזהרות ניתוח ביצועים
        """
        self.analysis_callbacks.append(callback)
    
    def get_performance_summary(self, module_name: str) -> Dict[str, Any]:
        """
        Get concise performance summary
        קבלת סיכום ביצועים תמציתי
        """
        analysis = self.analyze_performance(module_name)
        benchmarks = self.get_benchmark_status(module_name)
        
        return {
            'module_name': module_name,
            'overall_score': analysis.overall_score,
            'level': analysis.level.value,
            'level_hebrew': self._get_hebrew_level(analysis.level),
            'bottlenecks_count': len(analysis.bottlenecks),
            'recommendations_count': len(analysis.recommendations),
            'benchmarks_met': len([b for b in benchmarks if b.status == 'met']),
            'benchmarks_total': len(benchmarks),
            'last_analysis': analysis.analysis_time.isoformat()
        }
    
    def _get_hebrew_level(self, level: PerformanceLevel) -> str:
        """Get Hebrew translation of performance level"""
        level_map = {
            PerformanceLevel.EXCELLENT: "מצוין",
            PerformanceLevel.GOOD: "טוב",
            PerformanceLevel.AVERAGE: "ממוצע",
            PerformanceLevel.POOR: "גרוע",
            PerformanceLevel.CRITICAL: "קריטי"
        }
        return level_map.get(level, "לא ידוע")