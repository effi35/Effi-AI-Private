"""
Module Validator Utilities
כלי עזר לאימות מודולים

Comprehensive module validation and integrity checking.
אימות מודולים מקיף ובדיקת תקינות.
"""

import os
import json
import ast
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class ValidationLevel(Enum):
    """Validation severity levels"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

@dataclass
class ValidationIssue:
    """Module validation issue"""
    level: ValidationLevel
    category: str
    message: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    suggestion: Optional[str] = None

@dataclass
class ValidationResult:
    """Module validation result"""
    is_valid: bool
    module_name: str
    module_path: str
    issues: List[ValidationIssue]
    score: float  # 0-100 validation score
    
    def get_issues_by_level(self, level: ValidationLevel) -> List[ValidationIssue]:
        """Get issues by severity level"""
        return [issue for issue in self.issues if issue.level == level]

class ModuleValidator:
    """
    Comprehensive module validation system
    מערכת אימות מודולים מקיפה
    """
    
    def __init__(self):
        self.required_files = [
            'module.py',
            'metadata.json'
        ]
        
        self.required_directories = [
            'models',
            'core', 
            'ui',
            'utils'
        ]
        
        self.optional_files = [
            'README.md',
            'requirements.txt',
            '__init__.py'
        ]
        
        self.required_metadata_fields = [
            'name',
            'version', 
            'description',
            'author',
            'dependencies'
        ]
    
    async def validate_module(self, module_path: str) -> ValidationResult:
        """
        Comprehensive module validation
        אימות מודול מקיף
        """
        module_path = Path(module_path)
        module_name = module_path.name
        issues = []
        
        # Basic structure validation
        structure_issues = self._validate_structure(module_path)
        issues.extend(structure_issues)
        
        # Metadata validation
        metadata_issues = self._validate_metadata(module_path)
        issues.extend(metadata_issues)
        
        # Code quality validation
        code_issues = await self._validate_code_quality(module_path)
        issues.extend(code_issues)
        
        # Dependencies validation
        deps_issues = self._validate_dependencies(module_path)
        issues.extend(deps_issues)
        
        # Security validation
        security_issues = self._validate_security(module_path)
        issues.extend(security_issues)
        
        # Performance validation
        perf_issues = self._validate_performance(module_path)
        issues.extend(perf_issues)
        
        # Calculate validation score
        score = self._calculate_validation_score(issues)
        
        # Determine if module is valid
        critical_issues = [i for i in issues if i.level == ValidationLevel.CRITICAL]
        error_issues = [i for i in issues if i.level == ValidationLevel.ERROR]
        is_valid = len(critical_issues) == 0 and len(error_issues) == 0
        
        return ValidationResult(
            is_valid=is_valid,
            module_name=module_name,
            module_path=str(module_path),
            issues=issues,
            score=score
        )
    
    def _validate_structure(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate module directory structure
        אימות מבנה תיקיית מודול
        """
        issues = []
        
        # Check if module directory exists
        if not module_path.exists():
            issues.append(ValidationIssue(
                level=ValidationLevel.CRITICAL,
                category="structure",
                message=f"Module directory does not exist: {module_path}",
                suggestion="Create the module directory"
            ))
            return issues
        
        # Check required files
        for file_name in self.required_files:
            file_path = module_path / file_name
            if not file_path.exists():
                issues.append(ValidationIssue(
                    level=ValidationLevel.ERROR,
                    category="structure",
                    message=f"Missing required file: {file_name}",
                    file_path=str(file_path),
                    suggestion=f"Create {file_name} file"
                ))
        
        # Check required directories
        for dir_name in self.required_directories:
            dir_path = module_path / dir_name
            if not dir_path.exists():
                issues.append(ValidationIssue(
                    level=ValidationLevel.ERROR,
                    category="structure",
                    message=f"Missing required directory: {dir_name}",
                    file_path=str(dir_path),
                    suggestion=f"Create {dir_name} directory"
                ))
            else:
                # Check if directory has __init__.py
                init_file = dir_path / '__init__.py'
                if not init_file.exists():
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        category="structure",
                        message=f"Missing __init__.py in {dir_name}",
                        file_path=str(init_file),
                        suggestion="Create __init__.py for proper package structure"
                    ))
        
        # Check for recommended files
        for file_name in self.optional_files:
            file_path = module_path / file_name
            if not file_path.exists():
                issues.append(ValidationIssue(
                    level=ValidationLevel.INFO,
                    category="structure",
                    message=f"Recommended file missing: {file_name}",
                    file_path=str(file_path),
                    suggestion=f"Consider adding {file_name} for better documentation"
                ))
        
        return issues
    
    def _validate_metadata(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate module metadata
        אימות מטא-דטה של המודול
        """
        issues = []
        metadata_file = module_path / 'metadata.json'
        
        if not metadata_file.exists():
            return issues  # Already handled in structure validation
        
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                metadata = json.load(f)
            
            # Check required fields
            for field in self.required_metadata_fields:
                if field not in metadata:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.ERROR,
                        category="metadata",
                        message=f"Missing required metadata field: {field}",
                        file_path=str(metadata_file),
                        suggestion=f"Add {field} field to metadata.json"
                    ))
                elif not metadata[field]:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        category="metadata",
                        message=f"Empty metadata field: {field}",
                        file_path=str(metadata_file),
                        suggestion=f"Provide value for {field} field"
                    ))
            
            # Validate version format
            if 'version' in metadata:
                version = metadata['version']
                if not self._is_valid_version(version):
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        category="metadata",
                        message=f"Invalid version format: {version}",
                        file_path=str(metadata_file),
                        suggestion="Use semantic versioning (e.g., 1.0.0)"
                    ))
            
            # Check description length
            if 'description' in metadata:
                description = metadata['description']
                if len(description) < 10:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.INFO,
                        category="metadata",
                        message="Description is very short",
                        file_path=str(metadata_file),
                        suggestion="Provide more detailed description"
                    ))
        
        except json.JSONDecodeError as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.CRITICAL,
                category="metadata",
                message=f"Invalid JSON in metadata.json: {e}",
                file_path=str(metadata_file),
                suggestion="Fix JSON syntax errors"
            ))
        except Exception as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.ERROR,
                category="metadata",
                message=f"Error reading metadata.json: {e}",
                file_path=str(metadata_file),
                suggestion="Check file permissions and content"
            ))
        
        return issues
    
    async def _validate_code_quality(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate code quality and syntax
        אימות איכות קוד וחוק תחביר
        """
        issues = []
        
        # Find all Python files
        python_files = list(module_path.rglob("*.py"))
        
        for py_file in python_files:
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Syntax validation
                try:
                    ast.parse(content)
                except SyntaxError as e:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.CRITICAL,
                        category="code_quality",
                        message=f"Syntax error: {e.msg}",
                        file_path=str(py_file),
                        line_number=e.lineno,
                        suggestion="Fix syntax error"
                    ))
                    continue
                
                # Basic code quality checks
                lines = content.split('\n')
                
                # Check for very long lines
                for i, line in enumerate(lines, 1):
                    if len(line) > 120:
                        issues.append(ValidationIssue(
                            level=ValidationLevel.INFO,
                            category="code_quality",
                            message=f"Line too long ({len(line)} chars)",
                            file_path=str(py_file),
                            line_number=i,
                            suggestion="Consider breaking long lines"
                        ))
                
                # Check for missing docstrings in classes and functions
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        if not ast.get_docstring(node):
                            issues.append(ValidationIssue(
                                level=ValidationLevel.INFO,
                                category="code_quality",
                                message=f"Missing docstring for {node.name}",
                                file_path=str(py_file),
                                line_number=node.lineno,
                                suggestion="Add docstring for better documentation"
                            ))
                
                # Check for potential security issues
                if 'eval(' in content or 'exec(' in content:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        category="security",
                        message="Potentially unsafe eval/exec usage",
                        file_path=str(py_file),
                        suggestion="Consider safer alternatives"
                    ))
                
            except Exception as e:
                issues.append(ValidationIssue(
                    level=ValidationLevel.WARNING,
                    category="code_quality",
                    message=f"Error analyzing {py_file.name}: {e}",
                    file_path=str(py_file),
                    suggestion="Check file encoding and content"
                ))
        
        return issues
    
    def _validate_dependencies(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate module dependencies
        אימות תלותות המודול
        """
        issues = []
        requirements_file = module_path / 'requirements.txt'
        
        if requirements_file.exists():
            try:
                with open(requirements_file, 'r', encoding='utf-8') as f:
                    requirements = f.read().strip().split('\n')
                
                for req in requirements:
                    req = req.strip()
                    if req and not req.startswith('#'):
                        # Check for version pinning
                        if not any(op in req for op in ['==', '>=', '<=', '>', '<', '~=']):
                            issues.append(ValidationIssue(
                                level=ValidationLevel.INFO,
                                category="dependencies",
                                message=f"Unpinned dependency: {req}",
                                file_path=str(requirements_file),
                                suggestion="Consider pinning version for reproducibility"
                            ))
                        
                        # Check for development dependencies in production requirements
                        dev_packages = ['pytest', 'flake8', 'black', 'mypy', 'coverage']
                        if any(dev_pkg in req.lower() for dev_pkg in dev_packages):
                            issues.append(ValidationIssue(
                                level=ValidationLevel.WARNING,
                                category="dependencies",
                                message=f"Development dependency in requirements: {req}",
                                file_path=str(requirements_file),
                                suggestion="Move to dev-requirements.txt"
                            ))
                            
            except Exception as e:
                issues.append(ValidationIssue(
                    level=ValidationLevel.WARNING,
                    category="dependencies",
                    message=f"Error reading requirements.txt: {e}",
                    file_path=str(requirements_file),
                    suggestion="Check file format and encoding"
                ))
        
        return issues
    
    def _validate_security(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate security aspects
        אימות היבטי אבטחה
        """
        issues = []
        
        # Check for hardcoded secrets
        secret_patterns = [
            'password', 'secret', 'key', 'token', 'api_key',
            'private_key', 'access_token', 'auth_token'
        ]
        
        for py_file in module_path.rglob("*.py"):
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read().lower()
                
                for pattern in secret_patterns:
                    if f'{pattern} =' in content or f'{pattern}=' in content:
                        issues.append(ValidationIssue(
                            level=ValidationLevel.WARNING,
                            category="security",
                            message=f"Potential hardcoded secret: {pattern}",
                            file_path=str(py_file),
                            suggestion="Use environment variables or config files"
                        ))
                        
            except Exception:
                continue
        
        return issues
    
    def _validate_performance(self, module_path: Path) -> List[ValidationIssue]:
        """
        Validate performance considerations
        אימות שיקולי ביצועים
        """
        issues = []
        
        # Check for large files
        for file_path in module_path.rglob("*"):
            if file_path.is_file():
                size = file_path.stat().st_size
                if size > 1024 * 1024:  # > 1MB
                    issues.append(ValidationIssue(
                        level=ValidationLevel.INFO,
                        category="performance",
                        message=f"Large file detected: {self._format_bytes(size)}",
                        file_path=str(file_path),
                        suggestion="Consider breaking into smaller files"
                    ))
        
        return issues
    
    def _calculate_validation_score(self, issues: List[ValidationIssue]) -> float:
        """
        Calculate overall validation score (0-100)
        חישוב ציון אימות כולל (0-100)
        """
        if not issues:
            return 100.0
        
        # Weight by severity
        weights = {
            ValidationLevel.CRITICAL: 25,
            ValidationLevel.ERROR: 15,
            ValidationLevel.WARNING: 5,
            ValidationLevel.INFO: 1
        }
        
        total_penalty = sum(weights.get(issue.level, 0) for issue in issues)
        score = max(0, 100 - total_penalty)
        
        return score
    
    def _is_valid_version(self, version: str) -> bool:
        """Check if version follows semantic versioning"""
        import re
        pattern = r'^\d+\.\d+\.\d+(?:-[a-zA-Z0-9-]+)?(?:\+[a-zA-Z0-9-]+)?$'
        return bool(re.match(pattern, version))
    
    def _format_bytes(self, bytes_val: int) -> str:
        """Format bytes to human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} TB"
    
    def generate_validation_report(self, result: ValidationResult) -> str:
        """
        Generate human-readable validation report
        יצירת דוח אימות קריא לאדם
        """
        report = []
        report.append(f"דוח אימות מודול: {result.module_name}")
        report.append("=" * 50)
        report.append(f"מיקום: {result.module_path}")
        report.append(f"תקין: {'כן' if result.is_valid else 'לא'}")
        report.append(f"ציון: {result.score:.1f}/100")
        report.append("")
        
        if result.issues:
            # Group by category
            categories = {}
            for issue in result.issues:
                if issue.category not in categories:
                    categories[issue.category] = []
                categories[issue.category].append(issue)
            
            for category, issues in categories.items():
                report.append(f"קטגוריה: {category}")
                report.append("-" * 30)
                
                for issue in issues:
                    level_hebrew = {
                        ValidationLevel.CRITICAL: "קריטי",
                        ValidationLevel.ERROR: "שגיאה",
                        ValidationLevel.WARNING: "אזהרה",
                        ValidationLevel.INFO: "מידע"
                    }.get(issue.level, "לא ידוע")
                    
                    report.append(f"  [{level_hebrew}] {issue.message}")
                    if issue.file_path:
                        report.append(f"    קובץ: {issue.file_path}")
                    if issue.line_number:
                        report.append(f"    שורה: {issue.line_number}")
                    if issue.suggestion:
                        report.append(f"    הצעה: {issue.suggestion}")
                    report.append("")
                
                report.append("")
        else:
            report.append("לא נמצאו בעיות - המודול תקין!")
        
        return "\n".join(report)