"""
לוח בקרה מנצח הבינה המלאכותית - AI Orchestrator Dashboard
ממשק משתמש מרכזי לניהול כל המודולים במערכת
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
from collections import deque
import time

from ..core.module_coordinator import ModuleCoordinator, ModuleStatus
from ..models.orchestrator_config import OrchestratorConfig, PriorityLevel

class OrchestratorDashboard:
    """לוח בקרה מרכזי למנצח הבינה המלאכותית"""
    
    def __init__(self, coordinator: ModuleCoordinator = None):
        self.coordinator = coordinator
        self.root = None
        self.update_thread = None
        self.running = False
        
        # רכיבי UI
        self.modules_tree = None
        self.system_stats_labels = {}
        self.performance_canvas = None
        self.log_text = None
        self.events_listbox = None
        
        # נתוני גרפים
        self.cpu_history = deque(maxlen=100)
        self.memory_history = deque(maxlen=100)
        self.time_history = deque(maxlen=100)
        
        # הגדרות תצוגה
        self.auto_refresh = True
        self.refresh_interval = 2  # שניות
        
    def create_ui(self):
        """יצירת ממשק המשתמש הראשי"""
        self.root = tk.Tk()
        self.root.title("Effi AI - מנצח הבינה המלאכותית")
        self.root.geometry("1800x1000")
        self.root.configure(bg='#1a1a1a')
        
        # הגדרת סגנון כהה
        self._setup_dark_theme()
        
        # יצירת תפריט
        self._create_menu()
        
        # יצירת סרגל כלים
        self._create_toolbar()
        
        # יצירת אזור העבודה הראשי
        self._create_main_workspace()
        
        # יצירת סרגל סטטוס
        self._create_status_bar()
        
        # התחלת עדכון אוטומטי
        self.start_auto_update()
        
        return self.root
    
    def _setup_dark_theme(self):
        """הגדרת עיצוב כהה"""
        style = ttk.Style()
        
        # הגדרת צבעים כהים
        style.theme_use('clam')
        
        style.configure('Dark.TFrame', background='#2d2d2d')
        style.configure('Dark.TLabel', background='#2d2d2d', foreground='#ffffff')
        style.configure('Dark.TButton', background='#404040', foreground='#ffffff')
        style.configure('Dark.TLabelFrame', background='#2d2d2d', foreground='#ffffff')
        
        # treeview כהה
        style.configure('Dark.Treeview', 
                       background='#3d3d3d', 
                       foreground='#ffffff',
                       fieldbackground='#3d3d3d')
        style.configure('Dark.Treeview.Heading',
                       background='#404040',
                       foreground='#ffffff')
    
    def _create_menu(self):
        """יצירת תפריט עליון"""
        menubar = tk.Menu(self.root, bg='#2d2d2d', fg='#ffffff')
        self.root.config(menu=menubar)
        
        # תפריט מערכת
        system_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        menubar.add_cascade(label="מערכת", menu=system_menu)
        system_menu.add_command(label="הפעל מערכת", command=self.start_system)
        system_menu.add_command(label="עצור מערכת", command=self.stop_system)
        system_menu.add_separator()
        system_menu.add_command(label="רענן נתונים", command=self.refresh_data)
        system_menu.add_command(label="ייצוא סטטוס", command=self.export_status)
        system_menu.add_separator()
        system_menu.add_command(label="יציאה", command=self.on_closing)
        
        # תפריט מודולים
        modules_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        menubar.add_cascade(label="מודולים", menu=modules_menu)
        modules_menu.add_command(label="הפעל כל המודולים", command=self.start_all_modules)
        modules_menu.add_command(label="עצור כל המודולים", command=self.stop_all_modules)
        modules_menu.add_separator()
        modules_menu.add_command(label="הפעל מודול נבחר", command=self.start_selected_module)
        modules_menu.add_command(label="עצור מודול נבחר", command=self.stop_selected_module)
        modules_menu.add_command(label="הפעל מחדש מודול נבחר", command=self.restart_selected_module)
        modules_menu.add_separator()
        modules_menu.add_command(label="הגדרות מודולים", command=self.open_module_settings)
        
        # תפריט כלים
        tools_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        menubar.add_cascade(label="כלים", menu=tools_menu)
        tools_menu.add_command(label="ניטור ביצועים", command=self.open_performance_monitor)
        tools_menu.add_command(label="צפייה בלוגים", command=self.open_log_viewer)
        tools_menu.add_command(label="ניתוח משאבים", command=self.open_resource_analyzer)
        tools_menu.add_separator()
        tools_menu.add_command(label="אופטימיזציה אוטומטית", command=self.run_optimization)
        tools_menu.add_command(label="ניקוי מערכת", command=self.cleanup_system)
        
        # תפריט הגדרות
        settings_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        menubar.add_cascade(label="הגדרות", menu=settings_menu)
        settings_menu.add_command(label="הגדרות כלליות", command=self.open_general_settings)
        settings_menu.add_command(label="הגדרות ביצועים", command=self.open_performance_settings)
        settings_menu.add_command(label="הגדרות אבטחה", command=self.open_security_settings)
        settings_menu.add_separator()
        settings_menu.add_command(label="שמור הגדרות", command=self.save_config)
        settings_menu.add_command(label="טען הגדרות", command=self.load_config)
        
        # תפריט עזרה
        help_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        menubar.add_cascade(label="עזרה", menu=help_menu)
        help_menu.add_command(label="מדריך שימוש", command=self.show_help)
        help_menu.add_command(label="קיצורי מקלדת", command=self.show_shortcuts)
        help_menu.add_command(label="אודות", command=self.show_about)
    
    def _create_toolbar(self):
        """יצירת סרגל כלים"""
        toolbar_frame = ttk.Frame(self.root, style='Dark.TFrame')
        toolbar_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # כפתורי פעולה מהירה
        ttk.Button(toolbar_frame, text="🚀 הפעל מערכת", 
                  command=self.start_system, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="⏹ עצור מערכת", 
                  command=self.stop_system, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="🔄 רענן", 
                  command=self.refresh_data, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        # כפתורי מודולים
        ttk.Button(toolbar_frame, text="▶ הפעל מודול", 
                  command=self.start_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="⏸ השהה מודול", 
                  command=self.pause_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="🔁 הפעל מחדש", 
                  command=self.restart_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        # מצב עדכון אוטומטי
        self.auto_refresh_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(toolbar_frame, text="עדכון אוטומטי", 
                       variable=self.auto_refresh_var,
                       command=self.toggle_auto_refresh, style='Dark.TButton').pack(side=tk.LEFT, padx=5)
        
        # מחוון סטטוס מערכת
        self.system_status_indicator = tk.Label(toolbar_frame, text="●", 
                                               fg="red", font=('Arial', 16), bg='#2d2d2d')
        self.system_status_indicator.pack(side=tk.RIGHT, padx=10)
        
        ttk.Label(toolbar_frame, text="סטטוס מערכת:", 
                 style='Dark.TLabel').pack(side=tk.RIGHT, padx=(0, 5))
    
    def _create_main_workspace(self):
        """יצירת אזור העבודה הראשי"""
        # פאנל ראשי עם חלוקה
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # פאנל שמאל - סטטיסטיקות ומודולים
        left_paned = ttk.PanedWindow(main_paned, orient=tk.VERTICAL)
        main_paned.add(left_paned, weight=1)
        
        # סטטיסטיקות מערכת
        stats_frame = ttk.LabelFrame(left_paned, text="סטטיסטיקות מערכת", 
                                    style='Dark.TLabelFrame', padding=10)
        left_paned.add(stats_frame, weight=1)
        
        self._create_system_stats(stats_frame)
        
        # טבלת מודולים
        modules_frame = ttk.LabelFrame(left_paned, text="מודולים פעילים", 
                                      style='Dark.TLabelFrame', padding=10)
        left_paned.add(modules_frame, weight=2)
        
        self._create_modules_table(modules_frame)
        
        # פאנל ימין - גרפים ולוגים
        right_paned = ttk.PanedWindow(main_paned, orient=tk.VERTICAL)
        main_paned.add(right_paned, weight=2)
        
        # גרפי ביצועים
        performance_frame = ttk.LabelFrame(right_paned, text="ביצועי מערכת", 
                                         style='Dark.TLabelFrame', padding=10)
        right_paned.add(performance_frame, weight=2)
        
        self._create_performance_graphs(performance_frame)
        
        # אירועים ולוגים
        events_frame = ttk.LabelFrame(right_paned, text="אירועים ולוגים", 
                                     style='Dark.TLabelFrame', padding=10)
        right_paned.add(events_frame, weight=1)
        
        self._create_events_logs(events_frame)
    
    def _create_system_stats(self, parent):
        """יצירת סטטיסטיקות מערכת"""
        # גריד לסטטיסטיקות
        stats_grid = ttk.Frame(parent, style='Dark.TFrame')
        stats_grid.pack(fill=tk.BOTH, expand=True)
        
        stats = [
            ("זמן פעילות", "uptime", "00:00:00"),
            ("מודולים פעילים", "active_modules", "0/0"),
            ("שימוש CPU", "cpu_usage", "0%"),
            ("שימוש זיכרון", "memory_usage", "0 MB"),
            ("משימות בתור", "queued_tasks", "0"),
            ("הודעות בדקה", "messages_per_minute", "0"),
            ("מהירות תגובה", "avg_response_time", "0 ms"),
            ("שגיאות", "error_count", "0")
        ]
        
        for i, (label, key, default) in enumerate(stats):
            row = i // 2
            col = (i % 2) * 2
            
            # תווית
            ttk.Label(stats_grid, text=f"{label}:", 
                     style='Dark.TLabel', font=('Arial', 9, 'bold')).grid(
                row=row, column=col, sticky=tk.W, padx=5, pady=3)
            
            # ערך
            value_label = ttk.Label(stats_grid, text=default, 
                                   style='Dark.TLabel', font=('Arial', 10))
            value_label.grid(row=row, column=col+1, sticky=tk.W, padx=10, pady=3)
            
            self.system_stats_labels[key] = value_label
    
    def _create_modules_table(self, parent):
        """יצירת טבלת מודולים"""
        # כלי בקרה
        controls_frame = ttk.Frame(parent, style='Dark.TFrame')
        controls_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(controls_frame, text="▶ הפעל", 
                  command=self.start_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(controls_frame, text="⏹ עצור", 
                  command=self.stop_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(controls_frame, text="⏸ השהה", 
                  command=self.pause_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(controls_frame, text="🔁 הפעל מחדש", 
                  command=self.restart_selected_module, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        
        # טבלת מודולים
        columns = ('name', 'status', 'health', 'cpu', 'memory', 'uptime', 'errors')
        self.modules_tree = ttk.Treeview(parent, columns=columns, show='headings',
                                        style='Dark.Treeview', height=12)
        
        # הגדרת כותרות
        headers = {
            'name': 'שם מודול',
            'status': 'סטטוס',
            'health': 'בריאות',
            'cpu': 'CPU %',
            'memory': 'זיכרון MB',
            'uptime': 'זמן פעילות',
            'errors': 'שגיאות'
        }
        
        for col, header in headers.items():
            self.modules_tree.heading(col, text=header, anchor=tk.CENTER)
            
            if col == 'name':
                width = 150
            elif col in ['status', 'health']:
                width = 80
            elif col in ['cpu', 'memory', 'errors']:
                width = 70
            else:
                width = 100
                
            self.modules_tree.column(col, width=width, anchor=tk.CENTER)
        
        # סקרול
        modules_scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.modules_tree.yview)
        self.modules_tree.configure(yscrollcommand=modules_scroll.set)
        
        self.modules_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        modules_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # אירועים
        self.modules_tree.bind('<Double-1>', self.on_module_double_click)
        self.modules_tree.bind('<Button-3>', self.on_module_right_click)
    
    def _create_performance_graphs(self, parent):
        """יצירת גרפי ביצועים"""
        # יצירת גרף matplotlib
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 8))
        fig.patch.set_facecolor('#2d2d2d')
        
        # גרף CPU
        ax1.set_title('שימוש CPU', color='white', fontsize=10)
        ax1.set_facecolor('#3d3d3d')
        ax1.tick_params(colors='white', labelsize=8)
        ax1.set_ylim(0, 100)
        ax1.set_ylabel('אחוזים', color='white', fontsize=8)
        
        # גרף זיכרון
        ax2.set_title('שימוש זיכרון', color='white', fontsize=10)
        ax2.set_facecolor('#3d3d3d')
        ax2.tick_params(colors='white', labelsize=8)
        ax2.set_ylabel('MB', color='white', fontsize=8)
        
        # גרף מודולים פעילים
        ax3.set_title('מודולים פעילים', color='white', fontsize=10)
        ax3.set_facecolor('#3d3d3d')
        ax3.tick_params(colors='white', labelsize=8)
        ax3.set_ylabel('מספר', color='white', fontsize=8)
        ax3.set_xlabel('זמן', color='white', fontsize=8)
        
        plt.tight_layout()
        
        # הטמעה ב-tkinter
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.performance_canvas = (fig, ax1, ax2, ax3, canvas)
    
    def _create_events_logs(self, parent):
        """יצירת אזור אירועים ולוגים"""
        # נוטבוק לטאבים
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב אירועים
        events_frame = ttk.Frame(notebook, style='Dark.TFrame')
        notebook.add(events_frame, text="אירועי מערכת")
        
        # רשימת אירועים
        self.events_listbox = tk.Listbox(events_frame, height=8,
                                        bg='#3d3d3d', fg='#ffffff',
                                        font=('Consolas', 9))
        self.events_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # טאב לוגים
        logs_frame = ttk.Frame(notebook, style='Dark.TFrame')
        notebook.add(logs_frame, text="לוגי מערכת")
        
        # כלי בקרה ללוגים
        logs_controls = ttk.Frame(logs_frame, style='Dark.TFrame')
        logs_controls.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(logs_controls, text="נקה", 
                  command=self.clear_logs, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        ttk.Button(logs_controls, text="שמור", 
                  command=self.save_logs, style='Dark.TButton').pack(side=tk.LEFT, padx=2)
        
        # רמת לוג
        ttk.Label(logs_controls, text="רמה:", style='Dark.TLabel').pack(side=tk.LEFT, padx=(20, 5))
        self.log_level_var = tk.StringVar(value="INFO")
        log_combo = ttk.Combobox(logs_controls, textvariable=self.log_level_var,
                                values=["DEBUG", "INFO", "WARNING", "ERROR"],
                                state="readonly", width=8)
        log_combo.pack(side=tk.LEFT, padx=2)
        
        # תיבת לוגים
        self.log_text = scrolledtext.ScrolledText(logs_frame, height=8,
                                                 bg='#1e1e1e', fg='#00ff00',
                                                 font=('Consolas', 9))
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5)
    
    def _create_status_bar(self):
        """יצירת סרגל סטטוס"""
        status_frame = ttk.Frame(self.root, style='Dark.TFrame')
        status_frame.pack(fill=tk.X, pady=(5, 0))
        
        # סטטוס שמאל
        self.status_left = ttk.Label(status_frame, text="מוכן", style='Dark.TLabel')
        self.status_left.pack(side=tk.LEFT, padx=5)
        
        # פס התקדמות
        self.progress_bar = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress_bar.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # זמן עדכון אחרון
        self.last_update_label = ttk.Label(status_frame, text="", style='Dark.TLabel')
        self.last_update_label.pack(side=tk.RIGHT, padx=5)
    
    # ========== פונקציות עדכון נתונים ==========
    
    def start_auto_update(self):
        """התחלת עדכון אוטומטי"""
        if not self.running:
            self.running = True
            self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
            self.update_thread.start()
    
    def stop_auto_update(self):
        """עצירת עדכון אוטומטי"""
        self.running = False
    
    def _update_loop(self):
        """לולאת עדכון רציפה"""
        while self.running:
            if self.auto_refresh_var.get():
                try:
                    self.root.after(0, self.update_display)
                except:
                    break
            
            time.sleep(self.refresh_interval)
    
    def update_display(self):
        """עדכון תצוגת הנתונים"""
        if not self.coordinator:
            return
        
        try:
            # קבלת סטטוס מערכת
            system_status = self.coordinator.get_system_status()
            
            # עדכון סטטיסטיקות
            self._update_system_stats(system_status)
            
            # עדכון טבלת מודולים
            self._update_modules_table(system_status)
            
            # עדכון גרפים
            self._update_performance_graphs(system_status)
            
            # עדכון אירועים
            self._update_events_list(system_status)
            
            # עדכון מחוון סטטוס
            self._update_status_indicator(system_status)
            
            # עדכון זמן עדכון אחרון
            self.last_update_label.config(text=f"עודכן: {datetime.now().strftime('%H:%M:%S')}")
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון תצוגה: {e}", "ERROR")
    
    def _update_system_stats(self, system_status: Dict[str, Any]):
        """עדכון סטטיסטיקות מערכת"""
        try:
            system_metrics = system_status.get('system_metrics', {})
            
            # זמן פעילות
            uptime_seconds = system_metrics.get('total_uptime_seconds', 0)
            uptime_str = str(timedelta(seconds=int(uptime_seconds)))
            self.system_stats_labels['uptime'].config(text=uptime_str)
            
            # מודולים פעילים
            total_modules = system_status.get('total_modules', 0)
            active_modules = system_status.get('active_modules', 0)
            self.system_stats_labels['active_modules'].config(text=f"{active_modules}/{total_modules}")
            
            # CPU וזיכרון
            cpu_usage = system_metrics.get('total_cpu_usage', 0)
            memory_usage = system_metrics.get('total_memory_usage_mb', 0)
            
            self.system_stats_labels['cpu_usage'].config(text=f"{cpu_usage:.1f}%")
            self.system_stats_labels['memory_usage'].config(text=f"{memory_usage:.0f} MB")
            
            # מדדים נוספים
            message_throughput = system_metrics.get('message_throughput', 0)
            avg_response_time = system_metrics.get('avg_response_time_ms', 0)
            
            self.system_stats_labels['messages_per_minute'].config(text=str(message_throughput))
            self.system_stats_labels['avg_response_time'].config(text=f"{avg_response_time:.1f} ms")
            
            # עדכון נתוני גרפים
            current_time = time.time()
            self.time_history.append(current_time)
            self.cpu_history.append(cpu_usage)
            self.memory_history.append(memory_usage)
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון סטטיסטיקות: {e}", "ERROR")
    
    def _update_modules_table(self, system_status: Dict[str, Any]):
        """עדכון טבלת מודולים"""
        try:
            # ניקוי הטבלה
            for item in self.modules_tree.get_children():
                self.modules_tree.delete(item)
            
            # הוספת מודולים
            modules = system_status.get('modules', {})
            for module_name, module_data in modules.items():
                status = module_data.get('status', 'unknown')
                health = module_data.get('health', 'unknown')
                
                # צבעי סטטוס
                if status == 'running':
                    status_color = 'green'
                elif status == 'error':
                    status_color = 'red'
                elif status == 'paused':
                    status_color = 'orange'
                else:
                    status_color = 'gray'
                
                # מדדי ביצועים
                performance = module_data.get('performance', {})
                cpu_usage = performance.get('cpu_usage', 0)
                memory_usage = performance.get('memory_usage_mb', 0)
                uptime = performance.get('uptime_seconds', 0)
                error_count = module_data.get('error_count', 0)
                
                # פורמט זמן פעילות
                uptime_str = str(timedelta(seconds=int(uptime)))
                
                # הוספה לטבלה
                item_id = self.modules_tree.insert('', 'end', values=(
                    module_name,
                    status,
                    health,
                    f"{cpu_usage:.1f}%",
                    f"{memory_usage:.0f}",
                    uptime_str,
                    str(error_count)
                ))
                
                # צביעת שורה לפי סטטוס
                if status == 'running':
                    self.modules_tree.item(item_id, tags=('running',))
                elif status == 'error':
                    self.modules_tree.item(item_id, tags=('error',))
                elif status == 'paused':
                    self.modules_tree.item(item_id, tags=('paused',))
            
            # הגדרת צבעי תגים
            self.modules_tree.tag_configure('running', background='#2d5a2d')
            self.modules_tree.tag_configure('error', background='#5a2d2d')
            self.modules_tree.tag_configure('paused', background='#5a5a2d')
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון טבלת מודולים: {e}", "ERROR")
    
    def _update_performance_graphs(self, system_status: Dict[str, Any]):
        """עדכון גרפי ביצועים"""
        try:
            if not self.performance_canvas:
                return
            
            fig, ax1, ax2, ax3, canvas = self.performance_canvas
            
            if len(self.time_history) < 2:
                return
            
            # זמנים יחסיים
            times = np.array(self.time_history)
            times = times - times[0]  # התחלה מ-0
            
            # גרף CPU
            ax1.clear()
            ax1.plot(times, list(self.cpu_history), color='#4CAF50', linewidth=2)
            ax1.set_title('שימוש CPU', color='white', fontsize=10)
            ax1.set_ylim(0, 100)
            ax1.set_facecolor('#3d3d3d')
            ax1.tick_params(colors='white', labelsize=8)
            ax1.set_ylabel('אחוזים', color='white', fontsize=8)
            
            # גרף זיכרון
            ax2.clear()
            ax2.plot(times, list(self.memory_history), color='#FF9800', linewidth=2)
            ax2.set_title('שימוש זיכרון', color='white', fontsize=10)
            ax2.set_facecolor('#3d3d3d')
            ax2.tick_params(colors='white', labelsize=8)
            ax2.set_ylabel('MB', color='white', fontsize=8)
            
            # גרף מודולים פעילים
            ax3.clear()
            active_modules_history = [system_status.get('active_modules', 0)] * len(times)
            ax3.plot(times, active_modules_history, color='#2196F3', linewidth=2)
            ax3.set_title('מודולים פעילים', color='white', fontsize=10)
            ax3.set_facecolor('#3d3d3d')
            ax3.tick_params(colors='white', labelsize=8)
            ax3.set_ylabel('מספר', color='white', fontsize=8)
            ax3.set_xlabel('זמן (שניות)', color='white', fontsize=8)
            
            canvas.draw()
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון גרפים: {e}", "ERROR")
    
    def _update_events_list(self, system_status: Dict[str, Any]):
        """עדכון רשימת אירועים"""
        try:
            recent_events = system_status.get('recent_events', [])
            
            # הוספת אירועים חדשים
            current_count = self.events_listbox.size()
            
            for event in recent_events[current_count:]:
                timestamp = event.get('timestamp', datetime.now())
                if isinstance(timestamp, str):
                    timestamp = datetime.fromisoformat(timestamp)
                
                event_type = event.get('type', 'unknown')
                message = event.get('message', '')
                
                event_str = f"[{timestamp.strftime('%H:%M:%S')}] {event_type}: {message}"
                self.events_listbox.insert(tk.END, event_str)
            
            # גלילה לסוף
            self.events_listbox.see(tk.END)
            
            # הגבלת מספר פריטים
            if self.events_listbox.size() > 100:
                self.events_listbox.delete(0, self.events_listbox.size() - 100)
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון אירועים: {e}", "ERROR")
    
    def _update_status_indicator(self, system_status: Dict[str, Any]):
        """עדכון מחוון סטטוס מערכת"""
        try:
            system_running = system_status.get('system_running', False)
            active_modules = system_status.get('active_modules', 0)
            total_modules = system_status.get('total_modules', 0)
            
            if system_running and active_modules > 0:
                self.system_status_indicator.config(fg="green")
                self.status_left.config(text=f"פועל - {active_modules}/{total_modules} מודולים")
            elif system_running:
                self.system_status_indicator.config(fg="orange")
                self.status_left.config(text="פועל - אין מודולים פעילים")
            else:
                self.system_status_indicator.config(fg="red")
                self.status_left.config(text="מערכת מעצרת")
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון סטטוס: {e}", "ERROR")
    
    # ========== פונקציות פעולה ==========
    
    def start_system(self):
        """הפעלת המערכת"""
        if not self.coordinator:
            messagebox.showerror("שגיאה", "לא הוגדר מתאם מודולים")
            return
        
        def run_start():
            try:
                self.progress_bar.start()
                self.status_left.config(text="מפעיל מערכת...")
                
                result = asyncio.run(self.coordinator.start_system())
                
                if result:
                    self.root.after(0, lambda: self.log_message("המערכת הופעלה בהצלחה", "INFO"))
                else:
                    self.root.after(0, lambda: self.log_message("כשל בהפעלת המערכת", "ERROR"))
            except Exception as e:
                self.root.after(0, lambda: self.log_message(f"שגיאה בהפעלת המערכת: {e}", "ERROR"))
            finally:
                self.root.after(0, lambda: self.progress_bar.stop())
        
        threading.Thread(target=run_start, daemon=True).start()
    
    def stop_system(self):
        """עצירת המערכת"""
        if not self.coordinator:
            return
        
        if messagebox.askyesno("אישור", "האם אתה בטוח שברצונך לעצור את המערכת?"):
            def run_stop():
                try:
                    self.progress_bar.start()
                    self.status_left.config(text="עוצר מערכת...")
                    
                    result = asyncio.run(self.coordinator.stop_system())
                    
                    if result:
                        self.root.after(0, lambda: self.log_message("המערכת נעצרה בהצלחה", "INFO"))
                    else:
                        self.root.after(0, lambda: self.log_message("כשל בעצירת המערכת", "ERROR"))
                except Exception as e:
                    self.root.after(0, lambda: self.log_message(f"שגיאה בעצירת המערכת: {e}", "ERROR"))
                finally:
                    self.root.after(0, lambda: self.progress_bar.stop())
            
            threading.Thread(target=run_stop, daemon=True).start()
    
    def start_selected_module(self):
        """הפעלת מודול נבחר"""
        selection = self.modules_tree.selection()
        if not selection:
            messagebox.showwarning("אזהרה", "נא לבחור מודול")
            return
        
        module_name = self.modules_tree.item(selection[0])['values'][0]
        self.log_message(f"מפעיל מודול: {module_name}", "INFO")
        # TODO: יישום הפעלת מודול
    
    def stop_selected_module(self):
        """עצירת מודול נבחר"""
        selection = self.modules_tree.selection()
        if not selection:
            messagebox.showwarning("אזהרה", "נא לבחור מודול")
            return
        
        module_name = self.modules_tree.item(selection[0])['values'][0]
        
        if messagebox.askyesno("אישור", f"האם לעצור את המודול {module_name}?"):
            self.log_message(f"עוצר מודול: {module_name}", "INFO")
            # TODO: יישום עצירת מודול
    
    def pause_selected_module(self):
        """השהיית מודול נבחר"""
        selection = self.modules_tree.selection()
        if not selection:
            messagebox.showwarning("אזהרה", "נא לבחור מודול")
            return
        
        module_name = self.modules_tree.item(selection[0])['values'][0]
        self.log_message(f"משהה מודול: {module_name}", "INFO")
        # TODO: יישום השהיית מודול
    
    def restart_selected_module(self):
        """הפעלה מחדש של מודול נבחר"""
        selection = self.modules_tree.selection()
        if not selection:
            messagebox.showwarning("אזהרה", "נא לבחור מודול")
            return
        
        module_name = self.modules_tree.item(selection[0])['values'][0]
        
        if messagebox.askyesno("אישור", f"האם להפעיל מחדש את המודול {module_name}?"):
            self.log_message(f"מפעיל מחדש מודול: {module_name}", "INFO")
            # TODO: יישום הפעלה מחדש
    
    def refresh_data(self):
        """רענון נתונים"""
        self.update_display()
        self.log_message("נתונים רוענו", "INFO")
    
    def toggle_auto_refresh(self):
        """הפעלה/ביטול עדכון אוטומטי"""
        self.auto_refresh = self.auto_refresh_var.get()
        status = "הופעל" if self.auto_refresh else "בוטל"
        self.log_message(f"עדכון אוטומטי {status}", "INFO")
    
    def log_message(self, message: str, level: str = "INFO"):
        """הוספת הודעה ללוג"""
        if self.log_text:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {level}: {message}\n"
            
            self.log_text.insert(tk.END, log_entry)
            self.log_text.see(tk.END)
    
    # ========== פונקציות UI נוספות ==========
    
    def on_module_double_click(self, event):
        """טיפול בקליק כפול על מודול"""
        selection = self.modules_tree.selection()
        if selection:
            module_name = self.modules_tree.item(selection[0])['values'][0]
            self.show_module_details(module_name)
    
    def on_module_right_click(self, event):
        """תפריט הקשר למודול"""
        selection = self.modules_tree.selection()
        if not selection:
            return
        
        module_name = self.modules_tree.item(selection[0])['values'][0]
        
        context_menu = tk.Menu(self.root, tearoff=0, bg='#2d2d2d', fg='#ffffff')
        context_menu.add_command(label="הפעל", command=self.start_selected_module)
        context_menu.add_command(label="עצור", command=self.stop_selected_module)
        context_menu.add_command(label="השהה", command=self.pause_selected_module)
        context_menu.add_command(label="הפעל מחדש", command=self.restart_selected_module)
        context_menu.add_separator()
        context_menu.add_command(label="הצג פרטים", command=lambda: self.show_module_details(module_name))
        context_menu.add_command(label="הגדרות", command=lambda: self.show_module_settings(module_name))
        
        try:
            context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            context_menu.grab_release()
    
    def show_module_details(self, module_name: str):
        """הצגת פרטי מודול"""
        details_window = tk.Toplevel(self.root)
        details_window.title(f"פרטי מודול: {module_name}")
        details_window.geometry("600x400")
        details_window.configure(bg='#2d2d2d')
        
        # TODO: הוספת תוכן חלון הפרטים
        ttk.Label(details_window, text=f"פרטי מודול: {module_name}", 
                 style='Dark.TLabel', font=('Arial', 14, 'bold')).pack(pady=20)
    
    def on_closing(self):
        """טיפול בסגירת החלון"""
        if messagebox.askokcancel("יציאה", "האם לסגור את המערכת?"):
            self.stop_auto_update()
            if self.coordinator and self.coordinator.is_running:
                asyncio.run(self.coordinator.stop_system())
            self.root.destroy()
    
    # ========== פונקציות stub ==========
    
    def start_all_modules(self): 
        self.log_message("מפעיל כל המודולים", "INFO")
    
    def stop_all_modules(self): 
        self.log_message("עוצר כל המודולים", "INFO")
    
    def open_module_settings(self): 
        messagebox.showinfo("הגדרות", "הגדרות מודולים - בפיתוח")
    
    def open_performance_monitor(self): 
        messagebox.showinfo("ניטור", "ניטור ביצועים - בפיתוח")
    
    def open_log_viewer(self): 
        messagebox.showinfo("לוגים", "צפייה בלוגים - בפיתוח")
    
    def open_resource_analyzer(self): 
        messagebox.showinfo("ניתוח", "ניתוח משאבים - בפיתוח")
    
    def run_optimization(self): 
        self.log_message("מבצע אופטימיזציה", "INFO")
    
    def cleanup_system(self): 
        self.log_message("מנקה מערכת", "INFO")
    
    def open_general_settings(self): 
        messagebox.showinfo("הגדרות", "הגדרות כלליות - בפיתוח")
    
    def open_performance_settings(self): 
        messagebox.showinfo("הגדרות", "הגדרות ביצועים - בפיתוח")
    
    def open_security_settings(self): 
        messagebox.showinfo("הגדרות", "הגדרות אבטחה - בפיתוח")
    
    def save_config(self): 
        self.log_message("שומר הגדרות", "INFO")
    
    def load_config(self): 
        self.log_message("טוען הגדרות", "INFO")
    
    def export_status(self): 
        self.log_message("מייצא סטטוס", "INFO")
    
    def clear_logs(self): 
        self.log_text.delete("1.0", tk.END)
    
    def save_logs(self): 
        self.log_message("שומר לוגים", "INFO")
    
    def show_module_settings(self, module_name): 
        messagebox.showinfo("הגדרות", f"הגדרות {module_name} - בפיתוח")
    
    def show_help(self): 
        messagebox.showinfo("עזרה", "מדריך שימוש - בפיתוח")
    
    def show_shortcuts(self): 
        messagebox.showinfo("קיצורים", "קיצורי מקלדת - בפיתוח")
    
    def show_about(self): 
        messagebox.showinfo("אודות", "Effi AI Private System v1.0\nמנצח בינה מלאכותית מתקדם")

def main():
    """פונקציה ראשית להפעלת הממשק"""
    # יצירת הגדרות בסיסיות
    config = OrchestratorConfig()
    
    # יצירת מתאם מודולים
    coordinator = ModuleCoordinator(config)
    
    # יצירת לוח הבקרה
    dashboard = OrchestratorDashboard(coordinator)
    root = dashboard.create_ui()
    
    # הגדרת פונקציית סגירה
    root.protocol("WM_DELETE_WINDOW", dashboard.on_closing)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("סגירת המערכת...")
    finally:
        dashboard.stop_auto_update()

if __name__ == "__main__":
    main()