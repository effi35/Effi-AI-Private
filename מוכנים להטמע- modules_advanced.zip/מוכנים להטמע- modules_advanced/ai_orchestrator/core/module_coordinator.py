"""
מתאם המודולים - Module Coordinator
מנהל את כל המודולים במערכת ומתאם ביניהם
"""

import asyncio
import logging
import threading
import time
import psutil
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Tuple
from enum import Enum
import json
import queue
import signal
import sys
from pathlib import Path

from ..models.orchestrator_config import (
    OrchestratorConfig, ModuleConfig, PriorityLevel, 
    OrchestratorMode, ResourceAllocation
)

class ModuleStatus(Enum):
    """סטטוס מודול"""
    STOPPED = "stopped"
    STARTING = "starting" 
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    RESTARTING = "restarting"
    STOPPING = "stopping"

class TaskType(Enum):
    """סוגי משימות"""
    STARTUP = "startup"
    SHUTDOWN = "shutdown"
    HEALTH_CHECK = "health_check"
    RESOURCE_MONITOR = "resource_monitor"
    COMMUNICATION = "communication"
    OPTIMIZATION = "optimization"

class ModuleInstance:
    """מופע מודול במערכת"""
    
    def __init__(self, name: str, config: ModuleConfig, module_object: Any = None):
        self.name = name
        self.config = config
        self.module_object = module_object
        self.status = ModuleStatus.STOPPED
        self.start_time: Optional[datetime] = None
        self.last_heartbeat: Optional[datetime] = None
        self.error_count = 0
        self.restart_count = 0
        self.performance_metrics = {
            'cpu_usage': 0.0,
            'memory_usage_mb': 0.0,
            'response_time_ms': 0.0,
            'task_completion_rate': 100.0,
            'uptime_seconds': 0
        }
        self.message_queue = queue.Queue(maxsize=1000)
        self.health_status = "unknown"
        
    def update_metrics(self, cpu: float, memory_mb: float, response_time: float = None):
        """עדכון מדדי ביצועים"""
        self.performance_metrics['cpu_usage'] = cpu
        self.performance_metrics['memory_usage_mb'] = memory_mb
        if response_time is not None:
            self.performance_metrics['response_time_ms'] = response_time
        
        if self.start_time:
            self.performance_metrics['uptime_seconds'] = (
                datetime.now() - self.start_time
            ).total_seconds()

class ModuleCoordinator:
    """מתאם מודולים מרכזי"""
    
    def __init__(self, config: OrchestratorConfig):
        """
        אתחול מתאם המודולים
        
        Args:
            config: הגדרות המנצח
        """
        self.config = config
        self.modules: Dict[str, ModuleInstance] = {}
        self.is_running = False
        self.shutdown_requested = False
        
        # תהליכי רקע
        self.background_tasks: List[asyncio.Task] = []
        self.monitoring_thread: Optional[threading.Thread] = None
        
        # תקשורת בין מודולים
        self.message_bus = queue.Queue(maxsize=self.config.communication.message_queue_size)
        self.event_subscribers: Dict[str, List[Callable]] = {}
        
        # מדדי ביצועים כלליים
        self.system_metrics = {
            'total_cpu_usage': 0.0,
            'total_memory_usage_mb': 0.0,
            'active_modules_count': 0,
            'failed_modules_count': 0,
            'total_uptime_seconds': 0,
            'message_throughput': 0,
            'avg_response_time_ms': 0.0
        }
        
        # היסטוריית אירועים
        self.event_history: List[Dict[str, Any]] = []
        
        # לוגינג
        self.logger = logging.getLogger(__name__)
        self._setup_logging()
        
        # הגדרת signal handlers
        self._setup_signal_handlers()
        
        self.logger.info("מתאם המודולים אותחל בהצלחה")
    
    def _setup_logging(self):
        """הגדרת מערכת הלוגינג"""
        log_config = self.config.logging
        
        # הגדרת רמת לוגינג
        log_level = getattr(logging, log_config.level.upper(), logging.INFO)
        self.logger.setLevel(log_level)
        
        # הסרת handlers קיימים
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)
        
        # יצירת formatters
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s:%(lineno)d] - %(message)s'
        )
        simple_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # handler לקובץ
        if log_config.log_to_file:
            file_handler = logging.FileHandler('orchestrator.log', encoding='utf-8')
            file_handler.setFormatter(detailed_formatter)
            self.logger.addHandler(file_handler)
        
        # handler לקונסול
        if log_config.log_to_console:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(simple_formatter)
            self.logger.addHandler(console_handler)
    
    def _setup_signal_handlers(self):
        """הגדרת signal handlers לעצירה חלקה"""
        def signal_handler(signum, frame):
            self.logger.info(f"התקבל signal {signum} - מתחיל עצירה חלקה")
            self.shutdown_requested = True
            
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    async def start_system(self) -> bool:
        """
        הפעלת המערכת המלאה
        
        Returns:
            bool: True אם ההפעלה הצליחה
        """
        try:
            if self.is_running:
                self.logger.warning("המערכת כבר פועלת")
                return True
            
            self.logger.info("מתחיל הפעלת מערכת המנצח")
            
            # אימות הגדרות
            validation_issues = self.config.validate_config()
            if validation_issues["errors"]:
                self.logger.error(f"שגיאות בהגדרות: {validation_issues['errors']}")
                return False
            
            if validation_issues["warnings"]:
                for warning in validation_issues["warnings"]:
                    self.logger.warning(warning)
            
            # אופטימיזציה לביצועים
            self.config.optimize_for_performance()
            
            # הפעלת מודולים לפי סדר עדיפות
            startup_order = self.config.get_startup_order()
            self.logger.info(f"סדר הפעלה: {startup_order}")
            
            for module_name in startup_order:
                if self.shutdown_requested:
                    break
                    
                success = await self._start_module(module_name)
                if not success:
                    self.logger.error(f"כשל בהפעלת מודול {module_name}")
                    # המשך בהפעלת מודולים אחרים
                
                # המתנה קצרה בין הפעלות
                await asyncio.sleep(self.config.general_config.get("startup_delay", 5))
            
            # הפעלת תהליכי רקע
            await self._start_background_tasks()
            
            # הפעלת ניטור
            self._start_monitoring()
            
            self.is_running = True
            self._log_event("system_startup", "המערכת הופעלה בהצלחה")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת המערכת: {e}")
            return False
    
    async def _start_module(self, module_name: str) -> bool:
        """הפעלת מודול בודד"""
        try:
            config = self.config.get_module_config(module_name)
            if not config or not config.enabled:
                self.logger.info(f"מודול {module_name} מבוטל - מדלג")
                return True
            
            self.logger.info(f"מפעיל מודול: {module_name}")
            
            # יצירת instance של המודול
            module_instance = ModuleInstance(module_name, config)
            module_instance.status = ModuleStatus.STARTING
            
            # טעינת המודול
            module_object = await self._load_module(module_name)
            if not module_object:
                module_instance.status = ModuleStatus.ERROR
                self.modules[module_name] = module_instance
                return False
            
            module_instance.module_object = module_object
            
            # הפעלת המודול
            if hasattr(module_object, 'start_system'):
                await module_object.start_system()
            elif hasattr(module_object, 'start'):
                await module_object.start()
            
            # עדכון סטטוס
            module_instance.status = ModuleStatus.RUNNING
            module_instance.start_time = datetime.now()
            module_instance.last_heartbeat = datetime.now()
            
            self.modules[module_name] = module_instance
            
            self._log_event("module_startup", f"מודול {module_name} הופעל", {"module": module_name})
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מודול {module_name}: {e}")
            if module_name in self.modules:
                self.modules[module_name].status = ModuleStatus.ERROR
                self.modules[module_name].error_count += 1
            return False
    
    async def _load_module(self, module_name: str) -> Optional[Any]:
        """טעינת מודול דינמית"""
        try:
            # מיפוי שמות מודולים לקבצים
            module_mapping = {
                "auto_memory_system": "modules_advanced.auto_memory_system.module",
                "digital_control_system": "modules_advanced.digital_control_system.module", 
                "advanced_nlp_system": "modules_advanced.advanced_nlp_system.module",
                "analysis_audit_system": "modules_advanced.analysis_audit_system.module",
                "ml_intelligence_system": "modules_advanced.ml_intelligence_system.module"
            }
            
            if module_name not in module_mapping:
                self.logger.error(f"מודול לא ידוע: {module_name}")
                return None
            
            # ייבוא דינמי
            module_path = module_mapping[module_name]
            module = __import__(module_path, fromlist=[''])
            
            # יצירת instance של המודול
            if hasattr(module, 'create_system'):
                # פונקציה יוצרת כללית
                config_dict = self.config.get_module_config(module_name).custom_config
                return module.create_system(config_dict)
            elif hasattr(module, f'create_{module_name}'):
                # פונקציה יוצרת ספציפית
                func = getattr(module, f'create_{module_name}')
                return func()
            else:
                # חיפוש מחלקה ראשית
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if (isinstance(attr, type) and 
                        hasattr(attr, '__init__') and 
                        'system' in attr_name.lower()):
                        return attr()
            
            self.logger.error(f"לא נמצאה דרך ליצור instance של {module_name}")
            return None
            
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת מודול {module_name}: {e}")
            return None
    
    async def stop_system(self) -> bool:
        """עצירת המערכת המלאה"""
        try:
            if not self.is_running:
                self.logger.warning("המערכת כבר מעצרת")
                return True
            
            self.logger.info("מתחיל עצירת המערכת")
            self.shutdown_requested = True
            
            # עצירת תהליכי רקע
            await self._stop_background_tasks()
            
            # עצירת ניטור
            self._stop_monitoring()
            
            # עצירת מודולים בסדר הפוך
            startup_order = self.config.get_startup_order()
            shutdown_order = list(reversed(startup_order))
            
            for module_name in shutdown_order:
                await self._stop_module(module_name)
                await asyncio.sleep(1)  # המתנה קצרה בין עצירות
            
            # ניקוי משאבים
            self._cleanup_resources()
            
            self.is_running = False
            self._log_event("system_shutdown", "המערכת נעצרה בהצלחה")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת המערכת: {e}")
            return False
    
    async def _stop_module(self, module_name: str) -> bool:
        """עצירת מודול בודד"""
        try:
            if module_name not in self.modules:
                return True
            
            module_instance = self.modules[module_name]
            if module_instance.status == ModuleStatus.STOPPED:
                return True
            
            self.logger.info(f"עוצר מודול: {module_name}")
            module_instance.status = ModuleStatus.STOPPING
            
            # עצירת המודול
            if module_instance.module_object:
                if hasattr(module_instance.module_object, 'stop_system'):
                    await module_instance.module_object.stop_system()
                elif hasattr(module_instance.module_object, 'stop'):
                    await module_instance.module_object.stop()
                elif hasattr(module_instance.module_object, 'shutdown'):
                    if asyncio.iscoroutinefunction(module_instance.module_object.shutdown):
                        await module_instance.module_object.shutdown()
                    else:
                        module_instance.module_object.shutdown()
            
            module_instance.status = ModuleStatus.STOPPED
            self._log_event("module_shutdown", f"מודול {module_name} נעצר", {"module": module_name})
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מודול {module_name}: {e}")
            return False
    
    async def _start_background_tasks(self):
        """הפעלת תהליכי רקע"""
        # משימת בדיקת בריאות
        health_task = asyncio.create_task(self._health_check_loop())
        self.background_tasks.append(health_task)
        
        # משימת עיבוד הודעות
        message_task = asyncio.create_task(self._message_processing_loop())
        self.background_tasks.append(message_task)
        
        # משימת אופטימיזציה
        optimization_task = asyncio.create_task(self._optimization_loop())
        self.background_tasks.append(optimization_task)
        
        # משימת ניקוי
        cleanup_task = asyncio.create_task(self._cleanup_loop())
        self.background_tasks.append(cleanup_task)
        
        self.logger.info("תהליכי רקע הופעלו")
    
    async def _stop_background_tasks(self):
        """עצירת תהליכי רקע"""
        for task in self.background_tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        self.background_tasks.clear()
        self.logger.info("תהליכי רקע נעצרו")
    
    def _start_monitoring(self):
        """הפעלת ניטור מערכת"""
        if self.config.performance.enable_performance_monitoring:
            self.monitoring_thread = threading.Thread(
                target=self._monitoring_loop,
                daemon=True
            )
            self.monitoring_thread.start()
            self.logger.info("ניטור מערכת הופעל")
    
    def _stop_monitoring(self):
        """עצירת ניטור מערכת"""
        # הניטור יעצור אוטומטית כשהtehrad יסגר
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.logger.info("ניטור מערכת נעצר")
    
    def _monitoring_loop(self):
        """לולאת ניטור רציפה"""
        while self.is_running and not self.shutdown_requested:
            try:
                # עדכון מדדי מערכת כלליים
                self._update_system_metrics()
                
                # עדכון מדדי מודולים
                for module_name, module_instance in self.modules.items():
                    if module_instance.status == ModuleStatus.RUNNING:
                        self._update_module_metrics(module_instance)
                
                # בדיקת מגבלות משאבים
                self._check_resource_limits()
                
                time.sleep(5)  # עדכון כל 5 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בניטור: {e}")
    
    def _update_system_metrics(self):
        """עדכון מדדי מערכת כלליים"""
        try:
            # מדדי מערכת
            self.system_metrics['total_cpu_usage'] = psutil.cpu_percent()
            memory = psutil.virtual_memory()
            self.system_metrics['total_memory_usage_mb'] = memory.used / (1024 * 1024)
            
            # ספירת מודולים
            running_modules = [m for m in self.modules.values() if m.status == ModuleStatus.RUNNING]
            failed_modules = [m for m in self.modules.values() if m.status == ModuleStatus.ERROR]
            
            self.system_metrics['active_modules_count'] = len(running_modules)
            self.system_metrics['failed_modules_count'] = len(failed_modules)
            
            # זמן פעילות כולל
            if running_modules:
                total_uptime = sum(
                    (datetime.now() - m.start_time).total_seconds() 
                    for m in running_modules if m.start_time
                )
                self.system_metrics['total_uptime_seconds'] = total_uptime
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מדדי מערכת: {e}")
    
    def _update_module_metrics(self, module_instance: ModuleInstance):
        """עדכון מדדי ביצועים של מודול"""
        try:
            # זה דורש השתלבות עם המודול עצמו
            # כרגע נשתמש במדדי מערכת כלליים
            
            if module_instance.module_object and hasattr(module_instance.module_object, 'get_performance_stats'):
                stats = module_instance.module_object.get_performance_stats()
                if stats:
                    module_instance.performance_metrics.update(stats)
            
            # עדכון heartbeat
            module_instance.last_heartbeat = datetime.now()
            module_instance.health_status = "healthy"
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מדדי מודול {module_instance.name}: {e}")
            module_instance.health_status = "unhealthy"
    
    def _check_resource_limits(self):
        """בדיקת מגבלות משאבים"""
        try:
            # בדיקת זיכרון
            if self.system_metrics['total_memory_usage_mb'] > self.config.system_limits.max_total_memory_mb:
                self.logger.warning(f"חריגה ממגבלת זיכרון: {self.system_metrics['total_memory_usage_mb']}MB")
                self._handle_resource_emergency("memory")
            
            # בדיקת CPU
            if self.system_metrics['total_cpu_usage'] > self.config.system_limits.max_total_cpu_percent:
                self.logger.warning(f"חריגה ממגבלת CPU: {self.system_metrics['total_cpu_usage']}%")
                self._handle_resource_emergency("cpu")
            
            # בדיקת emergency shutdown
            cpu_threshold = self.config.system_limits.emergency_shutdown_threshold
            if self.system_metrics['total_cpu_usage'] > cpu_threshold:
                self.logger.critical(f"חריגה ממגבלת חירום CPU: {self.system_metrics['total_cpu_usage']}%")
                self._emergency_shutdown()
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת מגבלות: {e}")
    
    def _handle_resource_emergency(self, resource_type: str):
        """טיפול בחירום משאבים"""
        try:
            if resource_type == "memory":
                # הפעלת ניקוי זיכרון בכל המודולים
                for module_instance in self.modules.values():
                    if (module_instance.status == ModuleStatus.RUNNING and 
                        module_instance.module_object and
                        hasattr(module_instance.module_object, 'cleanup_memory')):
                        module_instance.module_object.cleanup_memory()
                        
            elif resource_type == "cpu":
                # הורדת עדיפות לתהליכים לא קריטיים
                for module_instance in self.modules.values():
                    if (module_instance.config.priority != PriorityLevel.CRITICAL and
                        module_instance.status == ModuleStatus.RUNNING):
                        # זמנית השהיית מודולים לא קריטיים
                        asyncio.create_task(self.pause_module(module_instance.name))
            
            self._log_event("resource_emergency", f"חירום משאבים: {resource_type}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בטיפול בחירום משאבים: {e}")
    
    def _emergency_shutdown(self):
        """עצירת חירום של המערכת"""
        self.logger.critical("מבצע עצירת חירום!")
        self.shutdown_requested = True
        asyncio.create_task(self.stop_system())
    
    async def _health_check_loop(self):
        """לולאת בדיקת בריאות מודולים"""
        while self.is_running and not self.shutdown_requested:
            try:
                for module_name, module_instance in self.modules.items():
                    if module_instance.status == ModuleStatus.RUNNING:
                        await self._check_module_health(module_instance)
                
                await asyncio.sleep(30)  # בדיקה כל 30 שניות
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה בבדיקת בריאות: {e}")
    
    async def _check_module_health(self, module_instance: ModuleInstance):
        """בדיקת בריאות מודול בודד"""
        try:
            # בדיקת heartbeat
            if module_instance.last_heartbeat:
                time_since_heartbeat = (datetime.now() - module_instance.last_heartbeat).total_seconds()
                if time_since_heartbeat > module_instance.config.health_check_interval * 2:
                    self.logger.warning(f"מודול {module_instance.name} לא מגיב")
                    module_instance.health_status = "unresponsive"
                    
                    # ניסיון restart אם מוגדר
                    if module_instance.config.restart_on_failure:
                        await self._restart_module(module_instance.name)
            
            # בדיקה פעילה
            if (module_instance.module_object and 
                hasattr(module_instance.module_object, 'health_check')):
                health_result = module_instance.module_object.health_check()
                if not health_result:
                    module_instance.health_status = "unhealthy"
                    module_instance.error_count += 1
                    
                    if module_instance.error_count > 3:
                        self.logger.error(f"מודול {module_instance.name} נכשל מספר פעמים")
                        if module_instance.config.restart_on_failure:
                            await self._restart_module(module_instance.name)
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת בריאות {module_instance.name}: {e}")
    
    async def _restart_module(self, module_name: str) -> bool:
        """הפעלה מחדש של מודול"""
        try:
            if module_name not in self.modules:
                return False
            
            module_instance = self.modules[module_name]
            module_instance.status = ModuleStatus.RESTARTING
            module_instance.restart_count += 1
            
            self.logger.info(f"מפעיל מחדש מודול: {module_name}")
            
            # עצירה
            await self._stop_module(module_name)
            await asyncio.sleep(2)
            
            # הפעלה מחדש
            success = await self._start_module(module_name)
            
            if success:
                module_instance.error_count = 0  # איפוס מונה שגיאות
                self._log_event("module_restart", f"מודול {module_name} הופעל מחדש", 
                               {"module": module_name, "restart_count": module_instance.restart_count})
            
            return success
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלה מחדש של {module_name}: {e}")
            return False
    
    async def _message_processing_loop(self):
        """לולאת עיבוד הודעות בין מודולים"""
        while self.is_running and not self.shutdown_requested:
            try:
                # עיבוד הודעות מהתור
                while not self.message_bus.empty():
                    try:
                        message = self.message_bus.get_nowait()
                        await self._process_message(message)
                    except queue.Empty:
                        break
                
                await asyncio.sleep(0.1)  # בדיקה תכופה
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה בעיבוד הודעות: {e}")
    
    async def _process_message(self, message: Dict[str, Any]):
        """עיבוד הודעה בודדת"""
        try:
            sender = message.get("sender")
            recipient = message.get("recipient")
            message_type = message.get("type")
            data = message.get("data", {})
            
            # הודעות broadcast
            if recipient == "all":
                for module_name, module_instance in self.modules.items():
                    if (module_name != sender and 
                        module_instance.status == ModuleStatus.RUNNING):
                        await self._deliver_message(module_instance, message)
            
            # הודעה למודול ספציפי
            elif recipient in self.modules:
                module_instance = self.modules[recipient]
                if module_instance.status == ModuleStatus.RUNNING:
                    await self._deliver_message(module_instance, message)
            
            # הודעות אירועים
            if message_type == "event":
                event_name = data.get("event_name")
                if event_name in self.event_subscribers:
                    for callback in self.event_subscribers[event_name]:
                        try:
                            if asyncio.iscoroutinefunction(callback):
                                await callback(data)
                            else:
                                callback(data)
                        except Exception as e:
                            self.logger.error(f"שגיאה בעיבוד אירוע {event_name}: {e}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד הודעה: {e}")
    
    async def _deliver_message(self, module_instance: ModuleInstance, message: Dict[str, Any]):
        """מסירת הודעה למודול"""
        try:
            if not module_instance.message_queue.full():
                module_instance.message_queue.put_nowait(message)
            else:
                self.logger.warning(f"תור הודעות מלא למודול {module_instance.name}")
                
        except Exception as e:
            self.logger.error(f"שגיאה במסירת הודעה ל-{module_instance.name}: {e}")
    
    async def _optimization_loop(self):
        """לולאת אופטימיזציה רציפה"""
        while self.is_running and not self.shutdown_requested:
            try:
                if self.config.performance.background_optimization:
                    await self._optimize_system_performance()
                
                await asyncio.sleep(300)  # אופטימיזציה כל 5 דקות
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה באופטימיזציה: {e}")
    
    async def _optimize_system_performance(self):
        """אופטימיזציה של ביצועי המערכת"""
        try:
            # אופטימיזציה של כל המודולים
            for module_instance in self.modules.values():
                if (module_instance.status == ModuleStatus.RUNNING and
                    module_instance.module_object and
                    hasattr(module_instance.module_object, 'optimize')):
                    try:
                        if asyncio.iscoroutinefunction(module_instance.module_object.optimize):
                            await module_instance.module_object.optimize()
                        else:
                            module_instance.module_object.optimize()
                    except Exception as e:
                        self.logger.error(f"שגיאה באופטימיזציה של {module_instance.name}: {e}")
            
            # ניקוי היסטוריית אירועים
            if len(self.event_history) > 1000:
                self.event_history = self.event_history[-500:]
            
            self.logger.debug("אופטימיזציה הושלמה")
            
        except Exception as e:
            self.logger.error(f"שגיאה באופטימיזציה כללית: {e}")
    
    async def _cleanup_loop(self):
        """לולאת ניקוי רציפה"""
        cleanup_interval = self.config.system_limits.cleanup_interval_minutes * 60
        
        while self.is_running and not self.shutdown_requested:
            try:
                await self._cleanup_system()
                await asyncio.sleep(cleanup_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה בניקוי: {e}")
    
    async def _cleanup_system(self):
        """ניקוי כללי של המערכת"""
        try:
            # ניקוי תורי הודעות
            cleaned_messages = 0
            for module_instance in self.modules.values():
                while not module_instance.message_queue.empty():
                    try:
                        module_instance.message_queue.get_nowait()
                        cleaned_messages += 1
                    except queue.Empty:
                        break
            
            if cleaned_messages > 0:
                self.logger.info(f"נוקו {cleaned_messages} הודעות ישנות")
            
            # קריאה לניקוי בכל מודול
            for module_instance in self.modules.values():
                if (module_instance.status == ModuleStatus.RUNNING and
                    module_instance.module_object and
                    hasattr(module_instance.module_object, 'cleanup')):
                    try:
                        if asyncio.iscoroutinefunction(module_instance.module_object.cleanup):
                            await module_instance.module_object.cleanup()
                        else:
                            module_instance.module_object.cleanup()
                    except Exception as e:
                        self.logger.error(f"שגיאה בניקוי {module_instance.name}: {e}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי המערכת: {e}")
    
    def _cleanup_resources(self):
        """ניקוי משאבים בעצירת המערכת"""
        try:
            # ניקוי תורי הודעות
            while not self.message_bus.empty():
                try:
                    self.message_bus.get_nowait()
                except queue.Empty:
                    break
            
            # ניקוי event subscribers
            self.event_subscribers.clear()
            
            # ניקוי instances של מודולים
            for module_instance in self.modules.values():
                module_instance.module_object = None
            
            self.logger.info("משאבים נוקו")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי משאבים: {e}")
    
    def _log_event(self, event_type: str, message: str, data: Dict[str, Any] = None):
        """רישום אירוע במערכת"""
        try:
            event = {
                "timestamp": datetime.now(),
                "type": event_type,
                "message": message,
                "data": data or {}
            }
            
            self.event_history.append(event)
            self.logger.info(f"אירוע: {message}")
            
            # שליחת אירוע למנויים
            if event_type in self.event_subscribers:
                message_data = {
                    "sender": "orchestrator",
                    "recipient": "all",
                    "type": "event",
                    "data": event
                }
                
                try:
                    self.message_bus.put_nowait(message_data)
                except queue.Full:
                    self.logger.warning("תור הודעות מלא - אירוע לא נשלח")
            
        except Exception as e:
            self.logger.error(f"שגיאה ברישום אירוע: {e}")
    
    # ========== API פונקציות ==========
    
    async def pause_module(self, module_name: str) -> bool:
        """השהיית מודול"""
        try:
            if module_name not in self.modules:
                return False
            
            module_instance = self.modules[module_name]
            if module_instance.status != ModuleStatus.RUNNING:
                return False
            
            # השהיה
            if (module_instance.module_object and
                hasattr(module_instance.module_object, 'pause')):
                await module_instance.module_object.pause()
            
            module_instance.status = ModuleStatus.PAUSED
            self._log_event("module_pause", f"מודול {module_name} הושהה")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהשהיית מודול {module_name}: {e}")
            return False
    
    async def resume_module(self, module_name: str) -> bool:
        """חידוש פעילות מודול"""
        try:
            if module_name not in self.modules:
                return False
            
            module_instance = self.modules[module_name]
            if module_instance.status != ModuleStatus.PAUSED:
                return False
            
            # חידוש
            if (module_instance.module_object and
                hasattr(module_instance.module_object, 'resume')):
                await module_instance.module_object.resume()
            
            module_instance.status = ModuleStatus.RUNNING
            self._log_event("module_resume", f"מודול {module_name} חודש")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בחידוש מודול {module_name}: {e}")
            return False
    
    def send_message(self, sender: str, recipient: str, message_type: str, data: Dict[str, Any]) -> bool:
        """שליחת הודעה בין מודולים"""
        try:
            message = {
                "sender": sender,
                "recipient": recipient,
                "type": message_type,
                "timestamp": datetime.now(),
                "data": data
            }
            
            if self.message_bus.full():
                self.logger.warning("תור הודעות מלא")
                return False
            
            self.message_bus.put_nowait(message)
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בשליחת הודעה: {e}")
            return False
    
    def subscribe_to_event(self, event_name: str, callback: Callable):
        """הרשמה לאירוע"""
        if event_name not in self.event_subscribers:
            self.event_subscribers[event_name] = []
        
        self.event_subscribers[event_name].append(callback)
        self.logger.info(f"נרשם לאירוע: {event_name}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מערכת מפורט"""
        try:
            module_statuses = {}
            for name, instance in self.modules.items():
                module_statuses[name] = {
                    "status": instance.status.value,
                    "health": instance.health_status,
                    "uptime": (datetime.now() - instance.start_time).total_seconds() if instance.start_time else 0,
                    "error_count": instance.error_count,
                    "restart_count": instance.restart_count,
                    "performance": instance.performance_metrics
                }
            
            return {
                "system_running": self.is_running,
                "total_modules": len(self.modules),
                "active_modules": len([m for m in self.modules.values() if m.status == ModuleStatus.RUNNING]),
                "system_metrics": self.system_metrics,
                "modules": module_statuses,
                "recent_events": self.event_history[-10:] if self.event_history else []
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת סטטוס: {e}")
            return {"error": str(e)}
    
    def get_module_instance(self, module_name: str) -> Optional[ModuleInstance]:
        """קבלת instance של מודול"""
        return self.modules.get(module_name)