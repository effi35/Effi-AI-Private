"""
הגדרות מנצח הבינה המלאכותית - AI Orchestrator Configuration
ניהול הגדרות מרכזי לכל המודולים במערכת
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
from enum import Enum
import json
from pathlib import Path
from datetime import datetime, timedelta
import logging

class OrchestratorMode(Enum):
    """מצבי פעולה של המנצח"""
    STANDALONE = "standalone"  # פעולה עצמאית
    COORDINATED = "coordinated"  # תיאום בין מודולים
    DISTRIBUTED = "distributed"  # חלוקת עומס
    FAILSAFE = "failsafe"  # מצב בטוח

class PriorityLevel(Enum):
    """רמות עדיפות למשימות"""
    CRITICAL = 5
    HIGH = 4
    NORMAL = 3
    LOW = 2
    BACKGROUND = 1

class ResourceAllocation(Enum):
    """הקצאת משאבים"""
    CONSERVATIVE = "conservative"  # שמרני
    BALANCED = "balanced"  # מאוזן
    AGGRESSIVE = "aggressive"  # אגרסיבי
    ADAPTIVE = "adaptive"  # מסתגל

@dataclass
class ModuleConfig:
    """הגדרות מודול בודד"""
    name: str
    enabled: bool = True
    priority: PriorityLevel = PriorityLevel.NORMAL
    max_memory_mb: int = 512
    max_cpu_percent: float = 25.0
    timeout_seconds: int = 300
    restart_on_failure: bool = True
    health_check_interval: int = 30
    dependencies: List[str] = field(default_factory=list)
    custom_config: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SystemLimits:
    """מגבלות מערכת כלליות"""
    max_total_memory_mb: int = 4096
    max_total_cpu_percent: float = 80.0
    max_concurrent_tasks: int = 20
    max_modules_active: int = 10
    emergency_shutdown_threshold: float = 95.0
    cleanup_interval_minutes: int = 60

@dataclass
class SecuritySettings:
    """הגדרות אבטחה"""
    encryption_enabled: bool = True
    access_control_enabled: bool = True
    audit_logging: bool = True
    secure_communication: bool = True
    sandbox_all_modules: bool = False
    allowed_network_access: List[str] = field(default_factory=list)
    blocked_operations: List[str] = field(default_factory=lambda: [
        "file_delete_system",
        "network_admin", 
        "registry_modify"
    ])

@dataclass
class PerformanceSettings:
    """הגדרות ביצועים"""
    resource_allocation: ResourceAllocation = ResourceAllocation.BALANCED
    enable_performance_monitoring: bool = True
    auto_scaling: bool = True
    load_balancing: bool = True
    cache_enabled: bool = True
    cache_size_mb: int = 256
    background_optimization: bool = True
    memory_cleanup_threshold: float = 85.0

@dataclass
class CommunicationConfig:
    """הגדרות תקשורת בין מודולים"""
    message_queue_size: int = 1000
    heartbeat_interval: int = 10
    timeout_response: int = 30
    retry_attempts: int = 3
    compression_enabled: bool = True
    encryption_in_transit: bool = True
    broadcast_events: bool = True

@dataclass
class LoggingConfig:
    """הגדרות לוגינג מתקדמות"""
    level: str = "INFO"
    max_file_size_mb: int = 100
    max_files_count: int = 10
    log_rotation: bool = True
    structured_logging: bool = True
    include_stack_trace: bool = True
    log_to_file: bool = True
    log_to_console: bool = True
    performance_logging: bool = True
    audit_logging: bool = True

class OrchestratorConfig:
    """מחלקה מרכזית לניהול הגדרות המנצח"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        אתחול הגדרות המנצח
        
        Args:
            config_path: נתיב לקובץ הגדרות (אופציונלי)
        """
        # הגדרות בסיסיות
        self.mode = OrchestratorMode.COORDINATED
        self.system_limits = SystemLimits()
        self.security = SecuritySettings()
        self.performance = PerformanceSettings()
        self.communication = CommunicationConfig()
        self.logging = LoggingConfig()
        
        # הגדרות מודולים
        self.modules: Dict[str, ModuleConfig] = {}
        
        # הגדרות כלליות
        self.general_config = {
            "system_name": "Effi AI Private System",
            "version": "1.0.0",
            "language": "hebrew",
            "timezone": "Asia/Jerusalem",
            "startup_delay": 5,
            "graceful_shutdown_timeout": 30,
            "auto_recovery": True,
            "backup_enabled": True,
            "metrics_collection": True
        }
        
        # טעינת הגדרות מקובץ אם קיים
        if config_path:
            self.load_from_file(config_path)
        else:
            self._init_default_modules()
        
        self.logger = logging.getLogger(__name__)
    
    def _init_default_modules(self):
        """אתחול הגדרות ברירת מחדל למודולים"""
        # מערכת זיכרון אוטומטית
        self.modules["auto_memory_system"] = ModuleConfig(
            name="auto_memory_system",
            enabled=True,
            priority=PriorityLevel.HIGH,
            max_memory_mb=1024,
            max_cpu_percent=30.0,
            timeout_seconds=600,
            health_check_interval=60,
            custom_config={
                "max_memories": 10000,
                "optimization_interval": 30,
                "auto_learning": True,
                "compression_enabled": True
            }
        )
        
        # מערכת שליטה דיגיטלית
        self.modules["digital_control_system"] = ModuleConfig(
            name="digital_control_system",
            enabled=True,
            priority=PriorityLevel.CRITICAL,
            max_memory_mb=512,
            max_cpu_percent=50.0,
            timeout_seconds=300,
            health_check_interval=15,
            custom_config={
                "security_level": "high",
                "sandbox_enabled": True,
                "max_executions": 10,
                "languages_enabled": ["python", "javascript", "bash"]
            }
        )
        
        # מערכת NLP מתקדמת
        self.modules["advanced_nlp_system"] = ModuleConfig(
            name="advanced_nlp_system",
            enabled=True,
            priority=PriorityLevel.HIGH,
            max_memory_mb=2048,
            max_cpu_percent=40.0,
            timeout_seconds=120,
            health_check_interval=45,
            custom_config={
                "quality_level": "high",
                "language_support": ["hebrew", "english"],
                "max_content_length": 5000,
                "seo_optimization": True
            }
        )
        
        # מודול ניתוח וביקורת
        self.modules["analysis_audit_system"] = ModuleConfig(
            name="analysis_audit_system",
            enabled=True,
            priority=PriorityLevel.NORMAL,
            max_memory_mb=256,
            max_cpu_percent=15.0,
            timeout_seconds=180,
            health_check_interval=120,
            custom_config={
                "audit_level": "comprehensive",
                "real_time_analysis": True,
                "threat_detection": True,
                "compliance_checking": True
            }
        )
        
        # מודול למידת מכונה מתקדמת
        self.modules["ml_intelligence_system"] = ModuleConfig(
            name="ml_intelligence_system",
            enabled=True,
            priority=PriorityLevel.HIGH,
            max_memory_mb=3072,
            max_cpu_percent=60.0,
            timeout_seconds=900,
            health_check_interval=90,
            custom_config={
                "model_training": True,
                "auto_feature_selection": True,
                "distributed_computing": False,
                "gpu_acceleration": False
            }
        )
    
    def get_module_config(self, module_name: str) -> Optional[ModuleConfig]:
        """קבלת הגדרות מודול ספציפי"""
        return self.modules.get(module_name)
    
    def set_module_config(self, module_name: str, config: ModuleConfig):
        """הגדרת תצורה למודול"""
        self.modules[module_name] = config
        self.logger.info(f"הגדרות מודול {module_name} עודכנו")
    
    def enable_module(self, module_name: str) -> bool:
        """הפעלת מודול"""
        if module_name in self.modules:
            self.modules[module_name].enabled = True
            self.logger.info(f"מודול {module_name} הופעל")
            return True
        return False
    
    def disable_module(self, module_name: str) -> bool:
        """ביטול מודול"""
        if module_name in self.modules:
            self.modules[module_name].enabled = False
            self.logger.info(f"מודול {module_name} בוטל")
            return True
        return False
    
    def get_enabled_modules(self) -> List[str]:
        """קבלת רשימת מודולים פעילים"""
        return [name for name, config in self.modules.items() if config.enabled]
    
    def validate_config(self) -> Dict[str, List[str]]:
        """אימות תקינות ההגדרות"""
        issues = {
            "errors": [],
            "warnings": [],
            "info": []
        }
        
        # בדיקת מגבלות מערכת
        total_memory = sum(config.max_memory_mb for config in self.modules.values() if config.enabled)
        if total_memory > self.system_limits.max_total_memory_mb:
            issues["errors"].append(f"סה״כ זיכרון חורג מהמותר: {total_memory}MB > {self.system_limits.max_total_memory_mb}MB")
        
        total_cpu = sum(config.max_cpu_percent for config in self.modules.values() if config.enabled)
        if total_cpu > self.system_limits.max_total_cpu_percent:
            issues["warnings"].append(f"סה״כ CPU עלול לחרוג: {total_cpu}% > {self.system_limits.max_total_cpu_percent}%")
        
        # בדיקת תלויות
        for module_name, config in self.modules.items():
            if config.enabled:
                for dependency in config.dependencies:
                    if dependency not in self.modules or not self.modules[dependency].enabled:
                        issues["errors"].append(f"מודול {module_name} תלוי במודול {dependency} שאינו זמין")
        
        # בדיקות אבטחה
        if not self.security.encryption_enabled:
            issues["warnings"].append("הצפנה מבוטלת - אבטחה מופחתת")
        
        if not self.security.access_control_enabled:
            issues["warnings"].append("בקרת גישה מבוטלת - סיכון אבטחה")
        
        return issues
    
    def optimize_for_performance(self):
        """אופטימיזציה אוטומטית לביצועים"""
        if self.performance.resource_allocation == ResourceAllocation.ADAPTIVE:
            # חלוקת משאבים דינמית
            enabled_modules = [config for config in self.modules.values() if config.enabled]
            if enabled_modules:
                # חישוב חלוקת זיכרון לפי עדיפות
                total_priority = sum(config.priority.value for config in enabled_modules)
                available_memory = self.system_limits.max_total_memory_mb
                
                for config in enabled_modules:
                    weight = config.priority.value / total_priority
                    config.max_memory_mb = int(available_memory * weight * 0.8)  # 80% מהזיכרון
                
                self.logger.info("משאבים חולקו מחדש לפי עדיפויות")
    
    def get_security_restrictions(self, module_name: str) -> List[str]:
        """קבלת הגבלות אבטחה למודול"""
        base_restrictions = self.security.blocked_operations.copy()
        
        # הגבלות נוספות לפי מודול
        module_restrictions = {
            "digital_control_system": [
                "system_modify",
                "network_server",
                "hardware_access"
            ],
            "advanced_nlp_system": [
                "file_system_write",
                "network_client"
            ]
        }
        
        if module_name in module_restrictions:
            base_restrictions.extend(module_restrictions[module_name])
        
        return base_restrictions
    
    def load_from_file(self, config_path: str) -> bool:
        """טעינת הגדרות מקובץ JSON"""
        try:
            config_file = Path(config_path)
            if not config_file.exists():
                self.logger.warning(f"קובץ הגדרות לא נמצא: {config_path}")
                return False
            
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # טעינת הגדרות כלליות
            if "general" in data:
                self.general_config.update(data["general"])
            
            # טעינת הגדרות מודולים
            if "modules" in data:
                for module_name, module_data in data["modules"].items():
                    config = ModuleConfig(
                        name=module_name,
                        enabled=module_data.get("enabled", True),
                        priority=PriorityLevel(module_data.get("priority", 3)),
                        max_memory_mb=module_data.get("max_memory_mb", 512),
                        max_cpu_percent=module_data.get("max_cpu_percent", 25.0),
                        timeout_seconds=module_data.get("timeout_seconds", 300),
                        restart_on_failure=module_data.get("restart_on_failure", True),
                        health_check_interval=module_data.get("health_check_interval", 30),
                        dependencies=module_data.get("dependencies", []),
                        custom_config=module_data.get("custom_config", {})
                    )
                    self.modules[module_name] = config
            
            # טעינת הגדרות מערכת
            if "system_limits" in data:
                limits_data = data["system_limits"]
                self.system_limits = SystemLimits(
                    max_total_memory_mb=limits_data.get("max_total_memory_mb", 4096),
                    max_total_cpu_percent=limits_data.get("max_total_cpu_percent", 80.0),
                    max_concurrent_tasks=limits_data.get("max_concurrent_tasks", 20),
                    max_modules_active=limits_data.get("max_modules_active", 10),
                    emergency_shutdown_threshold=limits_data.get("emergency_shutdown_threshold", 95.0),
                    cleanup_interval_minutes=limits_data.get("cleanup_interval_minutes", 60)
                )
            
            self.logger.info(f"הגדרות נטענו מ-{config_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת הגדרות: {e}")
            return False
    
    def save_to_file(self, config_path: str) -> bool:
        """שמירת הגדרות לקובץ JSON"""
        try:
            data = {
                "general": self.general_config,
                "modules": {},
                "system_limits": {
                    "max_total_memory_mb": self.system_limits.max_total_memory_mb,
                    "max_total_cpu_percent": self.system_limits.max_total_cpu_percent,
                    "max_concurrent_tasks": self.system_limits.max_concurrent_tasks,
                    "max_modules_active": self.system_limits.max_modules_active,
                    "emergency_shutdown_threshold": self.system_limits.emergency_shutdown_threshold,
                    "cleanup_interval_minutes": self.system_limits.cleanup_interval_minutes
                },
                "security": {
                    "encryption_enabled": self.security.encryption_enabled,
                    "access_control_enabled": self.security.access_control_enabled,
                    "audit_logging": self.security.audit_logging,
                    "secure_communication": self.security.secure_communication,
                    "sandbox_all_modules": self.security.sandbox_all_modules,
                    "allowed_network_access": self.security.allowed_network_access,
                    "blocked_operations": self.security.blocked_operations
                },
                "performance": {
                    "resource_allocation": self.performance.resource_allocation.value,
                    "enable_performance_monitoring": self.performance.enable_performance_monitoring,
                    "auto_scaling": self.performance.auto_scaling,
                    "load_balancing": self.performance.load_balancing,
                    "cache_enabled": self.performance.cache_enabled,
                    "cache_size_mb": self.performance.cache_size_mb,
                    "background_optimization": self.performance.background_optimization,
                    "memory_cleanup_threshold": self.performance.memory_cleanup_threshold
                }
            }
            
            # הוספת הגדרות מודולים
            for module_name, config in self.modules.items():
                data["modules"][module_name] = {
                    "enabled": config.enabled,
                    "priority": config.priority.value,
                    "max_memory_mb": config.max_memory_mb,
                    "max_cpu_percent": config.max_cpu_percent,
                    "timeout_seconds": config.timeout_seconds,
                    "restart_on_failure": config.restart_on_failure,
                    "health_check_interval": config.health_check_interval,
                    "dependencies": config.dependencies,
                    "custom_config": config.custom_config
                }
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"הגדרות נשמרו ב-{config_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת הגדרות: {e}")
            return False
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        return {
            "mode": self.mode.value,
            "general": self.general_config,
            "modules": {name: {
                "enabled": config.enabled,
                "priority": config.priority.value,
                "max_memory_mb": config.max_memory_mb,
                "max_cpu_percent": config.max_cpu_percent,
                "custom_config": config.custom_config
            } for name, config in self.modules.items()},
            "system_limits": {
                "max_total_memory_mb": self.system_limits.max_total_memory_mb,
                "max_total_cpu_percent": self.system_limits.max_total_cpu_percent
            }
        }
    
    def get_startup_order(self) -> List[str]:
        """קבלת סדר הפעלה מומלץ למודולים"""
        enabled_modules = [(name, config) for name, config in self.modules.items() if config.enabled]
        
        # מיון לפי עדיפות ותלויות
        sorted_modules = sorted(enabled_modules, key=lambda x: (-x[1].priority.value, len(x[1].dependencies)))
        
        return [name for name, _ in sorted_modules]