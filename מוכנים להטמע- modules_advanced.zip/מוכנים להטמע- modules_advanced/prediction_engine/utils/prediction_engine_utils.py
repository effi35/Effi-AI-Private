#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מנוע חיזוי Utils - כלי עזר עבור מנוע חיזוי
"""

import re
from typing import Any, Dict, List, Optional


def validate_input(value: Any, validation_type: str) -> bool:
    """אימות קלט"""
    if validation_type == "string" and isinstance(value, str):
        return len(value.strip()) > 0
    elif validation_type == "number" and isinstance(value, (int, float)):
        return value >= 0
    elif validation_type == "list" and isinstance(value, list):
        return len(value) > 0
    return False


def format_hebrew_text(text: str) -> str:
    """עיצוב טקסט עברי"""
    if not text:
        return ""
    
    # Basic Hebrew text formatting
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)  # Multiple spaces to single space
    
    return text


def safe_dict_get(dictionary: Dict[str, Any], key: str, default: Any = None) -> Any:
    """קבלה בטוחה מהמילון"""
    try:
        return dictionary.get(key, default)
    except (AttributeError, TypeError):
        return default


def log_operation(operation_name: str, success: bool, duration: float = 0.0):
    """רישום פעולה"""
    status = "הצליחה" if success else "נכשלה"
    print(f"פעולה '{operation_name}' {status} ({duration:.2f} שניות)")


class PredictionEngineHelper:
    """עוזר מנוע חיזוי"""
    
    @staticmethod
    def process_data(data: Any) -> Dict[str, Any]:
        """עיבוד נתונים"""
        return {
            "processed": True,
            "original_type": type(data).__name__,
            "data": data
        }
    
    @staticmethod
    def generate_id() -> str:
        """יצירת מזהה ייחודי"""
        import uuid
        return str(uuid.uuid4())
    
    @staticmethod
    def format_timestamp(timestamp: Optional[str] = None) -> str:
        """עיצוב חותמת זמן"""
        from datetime import datetime
        if timestamp:
            return timestamp
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
