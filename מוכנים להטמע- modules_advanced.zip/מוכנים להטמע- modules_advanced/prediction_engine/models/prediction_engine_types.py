#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מנוע חיזוי Types - סוגי נתונים עבור מנוע חיזוי
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum


@dataclass
class PredictionEngineConfig:
    """תצורת מנוע חיזוי"""
    enabled: bool = True
    max_concurrent_operations: int = 10
    timeout_seconds: int = 30
    logging_level: str = "INFO"
    custom_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PredictionEngineResult:
    """תוצאת פעולה של מנוע חיזוי"""
    success: bool
    data: Any = None
    error_message: str = ""
    execution_time: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class PredictionEngineStatistics:
    """סטטיסטיקות מנוע חיזוי"""
    total_operations: int = 0
    successful_operations: int = 0
    failed_operations: int = 0
    average_execution_time: float = 0.0
    uptime_seconds: int = 0
    last_operation: Optional[str] = None
