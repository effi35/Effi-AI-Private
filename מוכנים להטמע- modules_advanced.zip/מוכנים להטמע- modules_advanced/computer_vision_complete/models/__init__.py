"""
Computer Vision Complete Models Package
חבילת מודלי ראייה ממוחשבת מלאה

Professional computer vision system with advanced AI capabilities.
מערכת ראייה ממוחשבת מקצועית עם יכולות בינה מלאכותית מתקדמות.
"""

from .vision_types import (
    DetectionResult, FaceData, EmotionData, ObjectType,
    ImageAnalysis, VideoAnalysis, OCRResult, TextRegion,
    MedicalImage, AnomalyDetection, MovementTracker
)

from .model_types import (
    VisionModel, ModelConfig, TrainingData,
    ModelPerformance, Accuracy, ConfidenceScore,
    ModelEvaluation, BenchmarkResult, CalibrationData
)

from .processing_types import (
    ImageProcessor, VideoProcessor, StreamProcessor,
    FilterChain, Enhancement, Transformation,
    RealTimeConfig, BatchConfig, ProcessingQueue
)

__all__ = [
    # Vision types
    'DetectionResult', 'FaceData', 'EmotionData', 'ObjectType',
    'ImageAnalysis', 'VideoAnalysis', 'OCRResult', 'TextRegion',
    'MedicalImage', 'AnomalyDetection', 'MovementTracker',
    
    # Model types
    'VisionModel', 'ModelConfig', 'TrainingData',
    'ModelPerformance', 'Accuracy', 'ConfidenceScore',
    'ModelEvaluation', 'BenchmarkResult', 'CalibrationData',
    
    # Processing types
    'ImageProcessor', 'VideoProcessor', 'StreamProcessor',
    'FilterChain', 'Enhancement', 'Transformation',
    'RealTimeConfig', 'BatchConfig', 'ProcessingQueue'
]