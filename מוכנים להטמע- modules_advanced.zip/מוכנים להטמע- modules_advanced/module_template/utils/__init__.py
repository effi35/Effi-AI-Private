#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
תבנית מודול - Utils
"""
