"""
Execution Profiler Advanced - Profiler Engine
מנוע profiling מתקדם לניתוח ביצועים ומשאבים בזמן אמת
"""

import asyncio
import time
import threading
import functools
import inspect
import traceback
import psutil
import gc
from typing import Dict, List, Any, Optional, Callable, AsyncGenerator
from datetime import datetime, timedelta
from collections import defaultdict, deque
from contextlib import contextmanager
import json
import logging

from ..models.profiler_types import (
    PerformanceProfile, PerformanceEvent, ProfilerEventType,
    ResourceMetrics, APICallProfile, FunctionProfile,
    BottleneckAnalysis, BottleneckType, PerformanceLevel,
    PerformanceComparison, create_resource_snapshot,
    classify_bottleneck, calculate_performance_score
)

class ResourceMonitor:
    """מוניטור משאבי מערכת בזמן אמת"""
    
    def __init__(self, sampling_interval: float = 0.5):
        self.sampling_interval = sampling_interval
        self.is_monitoring = False
        self.resource_history = deque(maxlen=1000)  # שמירת 1000 דגימות אחרונות
        self.monitor_thread = None
        self.bottleneck_callbacks = []
        
    def start_monitoring(self):
        """התחלת ניטור"""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        logging.info("Resource monitoring started")
    
    def stop_monitoring(self):
        """עצירת ניטור"""
        self.is_monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2.0)
        logging.info("Resource monitoring stopped")
    
    def _monitor_loop(self):
        """לולאת ניטור"""
        while self.is_monitoring:
            try:
                metrics = create_resource_snapshot()
                self.resource_history.append(metrics)
                
                # בדיקת צווארי בקבוק
                bottleneck = classify_bottleneck(metrics)
                if bottleneck:
                    self._handle_bottleneck(bottleneck, metrics)
                
                time.sleep(self.sampling_interval)
                
            except Exception as e:
                logging.error(f"Resource monitoring error: {str(e)}")
                time.sleep(1.0)
    
    def _handle_bottleneck(self, bottleneck_type: BottleneckType, metrics: ResourceMetrics):
        """טיפול בצוואר בקבוק שזוהה"""
        severity = self._calculate_bottleneck_severity(bottleneck_type, metrics)
        
        bottleneck = BottleneckAnalysis(
            bottleneck_type=bottleneck_type,
            severity=severity,
            component="system",
            resource_utilization=metrics.calculate_resource_pressure()
        )
        
        # קריאה לcallbacks
        for callback in self.bottleneck_callbacks:
            try:
                callback(bottleneck)
            except Exception as e:
                logging.error(f"Bottleneck callback error: {str(e)}")
    
    def _calculate_bottleneck_severity(self, bottleneck_type: BottleneckType, metrics: ResourceMetrics) -> float:
        """חישוב חומרת צוואר הבקבוק"""
        if bottleneck_type == BottleneckType.CPU_BOUND:
            return min(metrics.cpu_percent / 100, 1.0)
        elif bottleneck_type == BottleneckType.MEMORY_BOUND:
            return min(metrics.memory_percent / 100, 1.0)
        elif bottleneck_type == BottleneckType.IO_BOUND:
            return min(metrics.disk_usage_percent / 100, 1.0)
        else:
            return 0.5
    
    def add_bottleneck_callback(self, callback: Callable[[BottleneckAnalysis], None]):
        """הוספת callback לצווארי בקבוק"""
        self.bottleneck_callbacks.append(callback)
    
    def get_current_metrics(self) -> Optional[ResourceMetrics]:
        """קבלת מטריקות נוכחיות"""
        return self.resource_history[-1] if self.resource_history else None
    
    def get_metrics_history(self, duration_minutes: int = 5) -> List[ResourceMetrics]:
        """קבלת היסטוריית מטריקות"""
        cutoff_time = datetime.now() - timedelta(minutes=duration_minutes)
        return [m for m in self.resource_history if m.timestamp >= cutoff_time]

class FunctionProfiler:
    """profiler פונקציות"""
    
    def __init__(self):
        self.function_profiles = {}
        self.call_stack = []
        self.active_calls = {}
        
    def profile_function(self, func: Callable) -> Callable:
        """decorator לprofiling פונקציה"""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return self._profile_sync_function(func, args, kwargs)
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            return await self._profile_async_function(func, args, kwargs)
        
        return async_wrapper if inspect.iscoroutinefunction(func) else wrapper
    
    def _profile_sync_function(self, func: Callable, args: tuple, kwargs: dict):
        """profiling פונקציה סינכרונית"""
        func_name = f"{func.__module__}.{func.__name__}"
        
        # מדידת זיכרון לפני
        gc.collect()
        memory_before = psutil.Process().memory_info().rss / 1024 / 1024
        
        start_time = time.perf_counter()
        call_id = id((func, start_time))
        
        try:
            # עדכון call stack
            self.call_stack.append(func_name)
            self.active_calls[call_id] = {
                "function": func_name,
                "start_time": start_time,
                "memory_before": memory_before
            }
            
            # ביצוע הפונקציה
            result = func(*args, **kwargs)
            
            return result
            
        except Exception as e:
            # רישום שגיאה
            self._record_function_error(func_name, str(e))
            raise
            
        finally:
            # מדידת זמן וזיכרון אחרי
            end_time = time.perf_counter()
            execution_time = (end_time - start_time) * 1000  # מילישניות
            
            gc.collect()
            memory_after = psutil.Process().memory_info().rss / 1024 / 1024
            memory_used = memory_after - memory_before
            
            # עדכון פרופיל
            self._update_function_profile(func_name, execution_time, memory_used, func)
            
            # ניקוי
            if call_id in self.active_calls:
                del self.active_calls[call_id]
            if self.call_stack and self.call_stack[-1] == func_name:
                self.call_stack.pop()
    
    async def _profile_async_function(self, func: Callable, args: tuple, kwargs: dict):
        """profiling פונקציה אסינכרונית"""
        func_name = f"{func.__module__}.{func.__name__}"
        
        # מדידת זיכרון לפני
        memory_before = psutil.Process().memory_info().rss / 1024 / 1024
        
        start_time = time.perf_counter()
        call_id = id((func, start_time))
        
        try:
            # עדכון call stack
            self.call_stack.append(func_name)
            self.active_calls[call_id] = {
                "function": func_name,
                "start_time": start_time,
                "memory_before": memory_before
            }
            
            # ביצוע הפונקציה
            result = await func(*args, **kwargs)
            
            return result
            
        except Exception as e:
            # רישום שגיאה
            self._record_function_error(func_name, str(e))
            raise
            
        finally:
            # מדידת זמן וזיכרון אחרי
            end_time = time.perf_counter()
            execution_time = (end_time - start_time) * 1000  # מילישניות
            
            memory_after = psutil.Process().memory_info().rss / 1024 / 1024
            memory_used = memory_after - memory_before
            
            # עדכון פרופיל
            self._update_function_profile(func_name, execution_time, memory_used, func)
            
            # ניקוי
            if call_id in self.active_calls:
                del self.active_calls[call_id]
            if self.call_stack and self.call_stack[-1] == func_name:
                self.call_stack.pop()
    
    def _update_function_profile(self, func_name: str, execution_time: float, memory_used: float, func: Callable):
        """עדכון פרופיל פונקציה"""
        if func_name not in self.function_profiles:
            self.function_profiles[func_name] = FunctionProfile(
                function_name=func.__name__,
                module_name=func.__module__,
                file_path=inspect.getfile(func) if hasattr(func, '__code__') else "",
                line_number=func.__code__.co_firstlineno if hasattr(func, '__code__') else 0
            )
        
        profile = self.function_profiles[func_name]
        profile.update_statistics(execution_time)
        profile.memory_allocated_mb += max(memory_used, 0)
        profile.memory_peak_mb = max(profile.memory_peak_mb, memory_used)
        
        # עדכון קריאות
        if len(self.call_stack) > 1:
            caller = self.call_stack[-2]
            if caller not in profile.called_by:
                profile.called_by.append(caller)
    
    def _record_function_error(self, func_name: str, error_message: str):
        """רישום שגיאת פונקציה"""
        logging.error(f"Function {func_name} error: {error_message}")
    
    def get_function_profile(self, func_name: str) -> Optional[FunctionProfile]:
        """קבלת פרופיל פונקציה"""
        return self.function_profiles.get(func_name)
    
    def get_top_functions(self, limit: int = 10, sort_by: str = "total_time") -> List[FunctionProfile]:
        """קבלת הפונקציות המובילות"""
        sort_key = {
            "total_time": lambda p: p.total_time_ms,
            "avg_time": lambda p: p.avg_time_ms,
            "call_count": lambda p: p.call_count,
            "memory": lambda p: p.memory_allocated_mb
        }.get(sort_by, lambda p: p.total_time_ms)
        
        return sorted(self.function_profiles.values(), key=sort_key, reverse=True)[:limit]

class APIProfiler:
    """profiler קריאות API"""
    
    def __init__(self):
        self.api_profiles = []
        self.active_requests = {}
        
    @contextmanager
    def profile_api_call(self, api_name: str, endpoint: str, method: str = "GET"):
        """context manager לprofiling קריאת API"""
        call_id = f"{api_name}_{endpoint}_{time.time()}"
        
        # יצירת פרופיל
        profile = APICallProfile(
            api_name=api_name,
            endpoint=endpoint,
            method=method
        )
        
        start_time = time.perf_counter()
        self.active_requests[call_id] = profile
        
        try:
            yield profile
            
        finally:
            # עדכון זמנים
            end_time = time.perf_counter()
            profile.total_time_ms = (end_time - start_time) * 1000
            
            # שמירת הפרופיל
            self.api_profiles.append(profile)
            
            # ניקוי
            if call_id in self.active_requests:
                del self.active_requests[call_id]
    
    def get_api_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות API"""
        if not self.api_profiles:
            return {}
        
        total_calls = len(self.api_profiles)
        successful_calls = sum(1 for p in self.api_profiles if 200 <= p.status_code < 300)
        cache_hits = sum(1 for p in self.api_profiles if p.cache_hit)
        
        avg_response_time = sum(p.total_time_ms for p in self.api_profiles) / total_calls
        
        return {
            "total_calls": total_calls,
            "success_rate": successful_calls / total_calls,
            "cache_hit_rate": cache_hits / total_calls,
            "average_response_time_ms": avg_response_time,
            "total_data_transferred_mb": sum(
                (p.request_size_bytes + p.response_size_bytes) / 1024 / 1024 
                for p in self.api_profiles
            )
        }
    
    def get_slowest_apis(self, limit: int = 5) -> List[APICallProfile]:
        """קבלת APIים הכי איטיים"""
        return sorted(self.api_profiles, key=lambda p: p.total_time_ms, reverse=True)[:limit]

class ExecutionProfiler:
    """profiler ביצוע ראשי"""
    
    def __init__(self, ollama_client=None):
        self.resource_monitor = ResourceMonitor()
        self.function_profiler = FunctionProfiler()
        self.api_profiler = APIProfiler()
        self.ollama_client = ollama_client
        
        # פרופילי ביצוע פעילים
        self.active_profiles = {}
        self.completed_profiles = []
        
        # הגדרות
        self.auto_detect_bottlenecks = True
        self.detailed_function_profiling = True
        self.api_profiling_enabled = True
        
        # callbacks
        self.profile_completion_callbacks = []
        self.bottleneck_detection_callbacks = []
        
        # התחלת ניטור
        self.resource_monitor.add_bottleneck_callback(self._handle_bottleneck_detected)
        self.resource_monitor.start_monitoring()
    
    def start_profiling(self, task_name: str, task_id: str = None) -> str:
        """התחלת profiling למשימה"""
        profile = PerformanceProfile(
            task_name=task_name,
            task_id=task_id or f"task_{int(time.time())}"
        )
        
        self.active_profiles[profile.profile_id] = profile
        
        logging.info(f"Started profiling task: {task_name} (ID: {profile.profile_id})")
        return profile.profile_id
    
    def stop_profiling(self, profile_id: str) -> Optional[PerformanceProfile]:
        """עצירת profiling"""
        if profile_id not in self.active_profiles:
            return None
        
        profile = self.active_profiles[profile_id]
        profile.complete_profile()
        
        # העברה לרשימת המושלמים
        self.completed_profiles.append(profile)
        del self.active_profiles[profile_id]
        
        # קריאה לcallbacks
        for callback in self.profile_completion_callbacks:
            try:
                callback(profile)
            except Exception as e:
                logging.error(f"Profile completion callback error: {str(e)}")
        
        logging.info(f"Completed profiling: {profile.task_name} in {profile.total_duration_ms:.2f}ms")
        return profile
    
    def add_event(self, profile_id: str, event_type: ProfilerEventType, **kwargs) -> bool:
        """הוספת אירוע לפרופיל"""
        if profile_id not in self.active_profiles:
            return False
        
        profile = self.active_profiles[profile_id]
        
        event = PerformanceEvent(
            event_type=event_type,
            source=kwargs.get('source', 'system'),
            component=kwargs.get('component', ''),
            operation=kwargs.get('operation', ''),
            duration_ms=kwargs.get('duration_ms', 0.0),
            metadata=kwargs.get('metadata', {}),
            resource_metrics=self.resource_monitor.get_current_metrics()
        )
        
        profile.add_event(event)
        return True
    
    @contextmanager
    def profile_operation(self, profile_id: str, operation_name: str, component: str = ""):
        """context manager לprofiling פעולה"""
        start_time = time.perf_counter()
        
        try:
            yield
            
        except Exception as e:
            # רישום שגיאה
            self.add_event(
                profile_id,
                ProfilerEventType.ERROR_OCCURRED,
                operation=operation_name,
                component=component,
                metadata={"error": str(e)}
            )
            raise
            
        finally:
            # רישום סיום
            end_time = time.perf_counter()
            duration_ms = (end_time - start_time) * 1000
            
            self.add_event(
                profile_id,
                ProfilerEventType.FUNCTION_CALL,
                operation=operation_name,
                component=component,
                duration_ms=duration_ms
            )
    
    def profile_function(self, func: Callable) -> Callable:
        """decorator לprofiling פונקציה"""
        if not self.detailed_function_profiling:
            return func
        
        return self.function_profiler.profile_function(func)
    
    def get_active_profile(self, profile_id: str) -> Optional[PerformanceProfile]:
        """קבלת פרופיל פעיל"""
        return self.active_profiles.get(profile_id)
    
    def get_completed_profiles(self, limit: int = 50) -> List[PerformanceProfile]:
        """קבלת פרופילים מושלמים"""
        return self.completed_profiles[-limit:]
    
    async def analyze_performance(self, profile: PerformanceProfile) -> Dict[str, Any]:
        """ניתוח ביצועים מתקדם"""
        analysis = {
            "summary": profile.get_summary(),
            "bottlenecks": [b.__dict__ for b in profile.bottlenecks],
            "top_functions": [],
            "api_statistics": {},
            "optimization_recommendations": []
        }
        
        # ניתוח פונקציות
        if self.detailed_function_profiling:
            top_functions = self.function_profiler.get_top_functions(10)
            analysis["top_functions"] = [
                {
                    "name": f.function_name,
                    "total_time_ms": f.total_time_ms,
                    "call_count": f.call_count,
                    "avg_time_ms": f.avg_time_ms,
                    "memory_mb": f.memory_allocated_mb
                }
                for f in top_functions
            ]
        
        # סטטיסטיקות API
        if self.api_profiling_enabled:
            analysis["api_statistics"] = self.api_profiler.get_api_statistics()
        
        # המלצות אופטימיזציה
        analysis["optimization_recommendations"] = await self._generate_optimization_recommendations(profile)
        
        # ניתוח AI אם זמין
        if self.ollama_client:
            analysis["ai_insights"] = await self._get_ai_insights(profile)
        
        return analysis
    
    async def _generate_optimization_recommendations(self, profile: PerformanceProfile) -> List[str]:
        """יצירת המלצות אופטימיזציה"""
        recommendations = []
        
        # המלצות לפי זמן ביצוע
        if profile.total_duration_ms > 5000:
            recommendations.append("זמן ביצוע ארוך - בדוק אפשרויות לאופטימיזציה או מקבילות")
        
        # המלצות לפי שימוש זיכרון
        if profile.peak_memory_mb > 1000:
            recommendations.append("שימוש זיכרון גבוה - בדוק דליפות זיכרון או אופטימיזציה")
        
        # המלצות לפי שגיאות
        if profile.error_count > 0:
            recommendations.append(f"נמצאו {profile.error_count} שגיאות - יש לטפל בהן")
        
        # המלצות לפי cache
        if profile.cache_hit_rate < 0.5:
            recommendations.append("שיעור cache נמוך - שקול שיפור אסטרטגיית cache")
        
        # המלצות לפי צווארי בקבוק
        for bottleneck in profile.bottlenecks:
            if bottleneck.severity > 0.7:
                recommendations.append(f"צוואר בקבוק זוהה: {bottleneck.bottleneck_type.value}")
        
        return recommendations
    
    async def _get_ai_insights(self, profile: PerformanceProfile) -> str:
        """קבלת תובנות AI על הביצועים"""
        if not self.ollama_client:
            return "ניתוח AI לא זמין"
        
        try:
            summary = profile.get_summary()
            
            prompt = f"""
            נתח את ביצועי המשימה הבאה ותן המלצות לשיפור:
            
            שם המשימה: {summary['task_name']}
            משך זמן: {summary['duration_seconds']} שניות
            רמת ביצועים: {summary['performance_level']}
            מספר שגיאות: {summary['errors_count']}
            זיכרון מקסימלי: {summary['peak_memory_mb']} MB
            CPU מקסימלי: {summary['peak_cpu_percent']}%
            
            אנא ספק:
            1. ניתוח הביצועים
            2. נקודות בעייתיות
            3. המלצות קונקרטיות לשיפור
            
            תן תשובה קצרה ומעשית בעברית.
            """
            
            # כאן יהיה הקוד לשליחה למודל Ollama
            # לעת עתה נחזיר ניתוח בסיסי
            return f"ניתוח AI: משימה '{summary['task_name']}' הושלמה ברמת ביצועים {summary['performance_level']}. יש לשפר את זמני התגובה."
            
        except Exception as e:
            logging.error(f"AI insights error: {str(e)}")
            return "שגיאה בניתוח AI"
    
    def _handle_bottleneck_detected(self, bottleneck: BottleneckAnalysis):
        """טיפול בצוואר בקבוק שזוהה"""
        # הוספה לכל הפרופילים הפעילים
        for profile in self.active_profiles.values():
            profile.add_bottleneck(bottleneck)
        
        # קריאה לcallbacks
        for callback in self.bottleneck_detection_callbacks:
            try:
                callback(bottleneck)
            except Exception as e:
                logging.error(f"Bottleneck detection callback error: {str(e)}")
        
        logging.warning(f"Bottleneck detected: {bottleneck.bottleneck_type.value} (severity: {bottleneck.severity})")
    
    def compare_profiles(self, baseline_id: str, current_id: str) -> Optional[PerformanceComparison]:
        """השוואת פרופילי ביצועים"""
        # חיפוש הפרופילים
        baseline = None
        current = None
        
        # חיפוש בפרופילים מושלמים
        for profile in self.completed_profiles:
            if profile.profile_id == baseline_id:
                baseline = profile
            elif profile.profile_id == current_id:
                current = profile
        
        if not baseline or not current:
            return None
        
        return PerformanceComparison(baseline, current)
    
    def add_profile_completion_callback(self, callback: Callable[[PerformanceProfile], None]):
        """הוספת callback להשלמת פרופיל"""
        self.profile_completion_callbacks.append(callback)
    
    def add_bottleneck_detection_callback(self, callback: Callable[[BottleneckAnalysis], None]):
        """הוספת callback לזיהוי צוואר בקבוק"""
        self.bottleneck_detection_callbacks.append(callback)
    
    def get_system_performance(self) -> Dict[str, Any]:
        """קבלת ביצועי מערכת כלליים"""
        current_metrics = self.resource_monitor.get_current_metrics()
        
        return {
            "current_metrics": current_metrics.__dict__ if current_metrics else {},
            "active_profiles": len(self.active_profiles),
            "completed_profiles": len(self.completed_profiles),
            "system_load": current_metrics.calculate_resource_pressure() if current_metrics else 0.0,
            "monitoring_active": self.resource_monitor.is_monitoring
        }
    
    def shutdown(self):
        """כיבוי המערכת"""
        self.resource_monitor.stop_monitoring()
        logging.info("Execution profiler shutdown completed")

# פונקציות עזר
def create_profiler(ollama_client=None) -> ExecutionProfiler:
    """יצירת profiler"""
    return ExecutionProfiler(ollama_client)

@contextmanager
def profile_task(profiler: ExecutionProfiler, task_name: str):
    """context manager לprofiling משימה מלאה"""
    profile_id = profiler.start_profiling(task_name)
    
    try:
        yield profile_id
        
    finally:
        profile = profiler.stop_profiling(profile_id)
        return profile