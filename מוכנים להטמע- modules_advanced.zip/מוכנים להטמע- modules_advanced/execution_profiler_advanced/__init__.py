"""
Execution Profiler Advanced Module
==================================

A comprehensive performance analysis and resource consumption tracking module
for all AI tasks, providing detailed metrics on execution time, memory usage,
API calls, and bottleneck identification using local Hudson/Llama models.

Features:
- Real-time performance monitoring
- Memory usage tracking
- API call profiling
- Bottleneck identification
- Resource consumption analysis
- Local AI-powered insights
- Performance visualization
- Historical analytics
- Optimization recommendations

Author: Effi AI System
Version: 1.0.0
"""

from .core.profiler_engine import ExecutionProfiler
from .models.profiling_types import ProfileMetrics, BottleneckReport
from .ui.profiler_dashboard import ProfilerDashboard

__version__ = "1.0.0"
__author__ = "Effi AI System"

__all__ = [
    'ExecutionProfiler',
    'ProfileMetrics', 
    'BottleneckReport',
    'ProfilerDashboard'
]