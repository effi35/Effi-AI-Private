"""
Execution Profiler Advanced - Profiler Types and Models
מודלים לניתוח ביצועים וניתוח משאבים מתקדם
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, Callable
from datetime import datetime, timedelta
import uuid
import json
import psutil
import threading
import time

class ProfilerEventType(Enum):
    """סוגי אירועי profiler"""
    TASK_START = "task_start"
    TASK_END = "task_end"
    FUNCTION_CALL = "function_call"
    API_CALL = "api_call"
    DATABASE_QUERY = "database_query"
    FILE_OPERATION = "file_operation"
    NETWORK_REQUEST = "network_request"
    MEMORY_ALLOCATION = "memory_allocation"
    CPU_SPIKE = "cpu_spike"
    BOTTLENECK_DETECTED = "bottleneck_detected"
    ERROR_OCCURRED = "error_occurred"
    CACHE_HIT = "cache_hit"
    CACHE_MISS = "cache_miss"

class ResourceType(Enum):
    """סוגי משאבים"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK_IO = "disk_io"
    NETWORK_IO = "network_io"
    GPU = "gpu"
    DATABASE = "database"
    CACHE = "cache"
    API_QUOTA = "api_quota"
    THREAD_POOL = "thread_pool"
    CONNECTION_POOL = "connection_pool"

class BottleneckType(Enum):
    """סוגי צווארי בקבוק"""
    CPU_BOUND = "cpu_bound"
    MEMORY_BOUND = "memory_bound"
    IO_BOUND = "io_bound"
    NETWORK_BOUND = "network_bound"
    DATABASE_BOUND = "database_bound"
    API_RATE_LIMITED = "api_rate_limited"
    THREAD_CONTENTION = "thread_contention"
    SYNCHRONIZATION = "synchronization"
    CACHE_CONTENTION = "cache_contention"
    DISK_SPACE = "disk_space"

class PerformanceLevel(Enum):
    """רמות ביצועים"""
    EXCELLENT = "excellent"      # 90-100%
    GOOD = "good"                # 70-89%
    FAIR = "fair"                # 50-69%
    POOR = "poor"                # 30-49%
    CRITICAL = "critical"        # 0-29%

@dataclass
class ResourceMetrics:
    """מטריקות משאבים"""
    timestamp: datetime = field(default_factory=datetime.now)
    
    # CPU
    cpu_percent: float = 0.0          # אחוז CPU
    cpu_cores_used: float = 0.0       # ליבות בשימוש
    cpu_frequency: float = 0.0        # תדירות CPU
    
    # זיכרון
    memory_used_mb: float = 0.0       # זיכרון בשימוש (MB)
    memory_percent: float = 0.0       # אחוז זיכרון
    memory_available_mb: float = 0.0  # זיכרון זמין (MB)
    memory_cached_mb: float = 0.0     # זיכרון cached (MB)
    
    # דיסק
    disk_read_mb: float = 0.0         # קריאת דיסק (MB)
    disk_write_mb: float = 0.0        # כתיבת דיסק (MB)
    disk_usage_percent: float = 0.0   # אחוז שימוש דיסק
    disk_free_gb: float = 0.0         # מקום פנוי (GB)
    
    # רשת
    network_sent_mb: float = 0.0      # נתונים שנשלחו (MB)
    network_recv_mb: float = 0.0      # נתונים שהתקבלו (MB)
    network_connections: int = 0      # חיבורי רשת פעילים
    
    # תהליכים
    processes_count: int = 0          # מספר תהליכים
    threads_count: int = 0            # מספר threads
    
    # GPU (אופציונלי)
    gpu_percent: Optional[float] = None
    gpu_memory_mb: Optional[float] = None
    
    def calculate_resource_pressure(self) -> float:
        """חישוב לחץ משאבים כללי (0-1)"""
        pressures = [
            self.cpu_percent / 100,
            self.memory_percent / 100,
            self.disk_usage_percent / 100,
            min(self.network_connections / 100, 1.0)  # מנרמל לפי 100 חיבורים
        ]
        
        return sum(pressures) / len(pressures)

@dataclass
class PerformanceEvent:
    """אירוע ביצועים"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: ProfilerEventType
    timestamp: datetime = field(default_factory=datetime.now)
    
    # מידע בסיסי
    source: str = ""              # מקור האירוע
    component: str = ""           # רכיב המערכת
    operation: str = ""           # פעולה שבוצעה
    
    # מדדי זמן
    duration_ms: float = 0.0      # משך זמן (מילישניות)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    # משאבים
    resource_metrics: Optional[ResourceMetrics] = None
    
    # מטאדטה
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    # קשר לאירועים אחרים
    parent_event_id: Optional[str] = None
    child_event_ids: List[str] = field(default_factory=list)
    
    # תוצאות
    success: bool = True
    error_message: Optional[str] = None
    
    def add_child_event(self, child_event_id: str):
        """הוספת אירוע ילד"""
        if child_event_id not in self.child_event_ids:
            self.child_event_ids.append(child_event_id)
    
    def calculate_performance_score(self) -> float:
        """חישוב ציון ביצועים (0-1)"""
        if not self.success:
            return 0.0
        
        # ציון בסיסי לפי משך זמן
        if self.duration_ms <= 100:  # מתחת ל-100ms
            time_score = 1.0
        elif self.duration_ms <= 500:  # 100-500ms
            time_score = 0.8
        elif self.duration_ms <= 1000:  # 500ms-1s
            time_score = 0.6
        elif self.duration_ms <= 5000:  # 1-5s
            time_score = 0.4
        else:  # מעל 5s
            time_score = 0.2
        
        # התאמה לפי סוג האירוע
        event_multipliers = {
            ProfilerEventType.API_CALL: 0.8,  # API calls צפויים להיות איטיים יותר
            ProfilerEventType.DATABASE_QUERY: 0.7,
            ProfilerEventType.NETWORK_REQUEST: 0.6,
            ProfilerEventType.FILE_OPERATION: 0.9,
            ProfilerEventType.FUNCTION_CALL: 1.0
        }
        
        multiplier = event_multipliers.get(self.event_type, 1.0)
        return time_score * multiplier

@dataclass
class APICallProfile:
    """פרופיל קריאת API"""
    api_name: str = ""
    endpoint: str = ""
    method: str = "GET"
    request_size_bytes: int = 0
    response_size_bytes: int = 0
    status_code: int = 200
    
    # זמנים מפורטים
    dns_time_ms: float = 0.0
    connect_time_ms: float = 0.0
    request_time_ms: float = 0.0
    response_time_ms: float = 0.0
    total_time_ms: float = 0.0
    
    # headers ומטאדטה
    request_headers: Dict[str, str] = field(default_factory=dict)
    response_headers: Dict[str, str] = field(default_factory=dict)
    
    # cache ו-performance
    cache_hit: bool = False
    retry_count: int = 0
    rate_limited: bool = False

@dataclass
class FunctionProfile:
    """פרופיל פונקציה"""
    function_name: str = ""
    module_name: str = ""
    file_path: str = ""
    line_number: int = 0
    
    # זמני ביצוע
    total_time_ms: float = 0.0
    self_time_ms: float = 0.0        # זמן ללא פונקציות ילד
    call_count: int = 0
    
    # זיכרון
    memory_allocated_mb: float = 0.0
    memory_peak_mb: float = 0.0
    
    # פונקציות שנקראו
    called_functions: List[str] = field(default_factory=list)
    called_by: List[str] = field(default_factory=list)
    
    # פרמטרים סטטיסטיים
    min_time_ms: float = float('inf')
    max_time_ms: float = 0.0
    avg_time_ms: float = 0.0
    
    def update_statistics(self, execution_time_ms: float):
        """עדכון סטטיסטיקות"""
        self.call_count += 1
        self.total_time_ms += execution_time_ms
        self.min_time_ms = min(self.min_time_ms, execution_time_ms)
        self.max_time_ms = max(self.max_time_ms, execution_time_ms)
        self.avg_time_ms = self.total_time_ms / self.call_count

@dataclass
class BottleneckAnalysis:
    """ניתוח צוואר בקבוק"""
    bottleneck_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    bottleneck_type: BottleneckType
    severity: float = 0.0             # 0-1
    
    # זיהוי
    component: str = ""
    operation: str = ""
    detected_at: datetime = field(default_factory=datetime.now)
    
    # מדדים
    resource_utilization: float = 0.0
    wait_time_ms: float = 0.0
    queue_length: int = 0
    
    # השפעה
    affected_operations: List[str] = field(default_factory=list)
    performance_impact: float = 0.0   # השפעה על ביצועים כלליים
    
    # פתרונות
    suggested_solutions: List[str] = field(default_factory=list)
    optimization_potential: float = 0.0  # פוטנציאל שיפור
    
    # מעקב
    resolved: bool = False
    resolution_applied: Optional[str] = None
    resolution_time: Optional[datetime] = None

@dataclass
class PerformanceProfile:
    """פרופיל ביצועים מלא"""
    profile_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_name: str = ""
    task_id: str = ""
    
    # זמנים כלליים
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    total_duration_ms: float = 0.0
    
    # אירועים
    events: List[PerformanceEvent] = field(default_factory=list)
    api_calls: List[APICallProfile] = field(default_factory=list)
    function_calls: List[FunctionProfile] = field(default_factory=list)
    
    # משאבים
    resource_timeline: List[ResourceMetrics] = field(default_factory=list)
    peak_memory_mb: float = 0.0
    peak_cpu_percent: float = 0.0
    total_io_mb: float = 0.0
    
    # ניתוח
    bottlenecks: List[BottleneckAnalysis] = field(default_factory=list)
    performance_level: PerformanceLevel = PerformanceLevel.FAIR
    optimization_score: float = 0.5    # 0-1
    
    # סטטיסטיקות
    error_count: int = 0
    warning_count: int = 0
    cache_hit_rate: float = 0.0
    
    # השוואות
    baseline_duration_ms: Optional[float] = None
    performance_regression: float = 0.0  # אחוז החמרה/שיפור
    
    def add_event(self, event: PerformanceEvent):
        """הוספת אירוע"""
        self.events.append(event)
        
        # עדכון סטטיסטיקות
        if not event.success:
            self.error_count += 1
        
        # עדכון משאבים אם קיימים
        if event.resource_metrics:
            self.resource_timeline.append(event.resource_metrics)
            self.peak_memory_mb = max(self.peak_memory_mb, event.resource_metrics.memory_used_mb)
            self.peak_cpu_percent = max(self.peak_cpu_percent, event.resource_metrics.cpu_percent)
    
    def add_api_call(self, api_call: APICallProfile):
        """הוספת קריאת API"""
        self.api_calls.append(api_call)
        
        # עדכון cache hit rate
        total_calls = len(self.api_calls)
        cache_hits = sum(1 for call in self.api_calls if call.cache_hit)
        self.cache_hit_rate = cache_hits / total_calls if total_calls > 0 else 0.0
    
    def add_bottleneck(self, bottleneck: BottleneckAnalysis):
        """הוספת צוואר בקבוק"""
        self.bottlenecks.append(bottleneck)
        
        # עדכון רמת ביצועים
        if bottleneck.severity > 0.8:
            self.performance_level = PerformanceLevel.CRITICAL
        elif bottleneck.severity > 0.6:
            self.performance_level = PerformanceLevel.POOR
    
    def complete_profile(self):
        """השלמת הפרופיל"""
        self.end_time = datetime.now()
        if self.start_time:
            self.total_duration_ms = (self.end_time - self.start_time).total_seconds() * 1000
        
        # חישוב ציון אופטימיזציה
        self._calculate_optimization_score()
        
        # קביעת רמת ביצועים
        self._determine_performance_level()
    
    def _calculate_optimization_score(self):
        """חישוב ציון אופטימיזציה"""
        factors = []
        
        # ציון זמן ביצוע
        if self.total_duration_ms <= 1000:  # מתחת לשנייה
            factors.append(1.0)
        elif self.total_duration_ms <= 5000:  # 1-5 שניות
            factors.append(0.8)
        elif self.total_duration_ms <= 10000:  # 5-10 שניות
            factors.append(0.6)
        else:
            factors.append(0.4)
        
        # ציון שגיאות
        if self.error_count == 0:
            factors.append(1.0)
        else:
            error_rate = self.error_count / len(self.events) if self.events else 1.0
            factors.append(max(1.0 - error_rate, 0.0))
        
        # ציון cache
        factors.append(self.cache_hit_rate)
        
        # ציון צווארי בקבוק
        if not self.bottlenecks:
            factors.append(1.0)
        else:
            avg_severity = sum(b.severity for b in self.bottlenecks) / len(self.bottlenecks)
            factors.append(1.0 - avg_severity)
        
        self.optimization_score = sum(factors) / len(factors)
    
    def _determine_performance_level(self):
        """קביעת רמת ביצועים"""
        if self.optimization_score >= 0.9:
            self.performance_level = PerformanceLevel.EXCELLENT
        elif self.optimization_score >= 0.7:
            self.performance_level = PerformanceLevel.GOOD
        elif self.optimization_score >= 0.5:
            self.performance_level = PerformanceLevel.FAIR
        elif self.optimization_score >= 0.3:
            self.performance_level = PerformanceLevel.POOR
        else:
            self.performance_level = PerformanceLevel.CRITICAL
    
    def get_summary(self) -> Dict[str, Any]:
        """קבלת סיכום הפרופיל"""
        return {
            "task_name": self.task_name,
            "duration_seconds": self.total_duration_ms / 1000,
            "performance_level": self.performance_level.value,
            "optimization_score": round(self.optimization_score, 3),
            "events_count": len(self.events),
            "api_calls_count": len(self.api_calls),
            "errors_count": self.error_count,
            "bottlenecks_count": len(self.bottlenecks),
            "peak_memory_mb": round(self.peak_memory_mb, 2),
            "peak_cpu_percent": round(self.peak_cpu_percent, 2),
            "cache_hit_rate": round(self.cache_hit_rate, 3)
        }

@dataclass
class PerformanceComparison:
    """השוואת ביצועים"""
    comparison_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    baseline_profile: PerformanceProfile
    current_profile: PerformanceProfile
    
    # שינויים
    duration_change_percent: float = 0.0
    memory_change_percent: float = 0.0
    cpu_change_percent: float = 0.0
    error_rate_change: float = 0.0
    
    # ניתוח
    performance_trend: str = "stable"    # "improving", "degrading", "stable"
    significance: float = 0.0            # רמת משמעותיות השינוי
    recommendations: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """חישוב השוואה"""
        self._calculate_changes()
        self._analyze_trend()
    
    def _calculate_changes(self):
        """חישוב שינויים"""
        # שינוי זמן
        if self.baseline_profile.total_duration_ms > 0:
            self.duration_change_percent = (
                (self.current_profile.total_duration_ms - self.baseline_profile.total_duration_ms)
                / self.baseline_profile.total_duration_ms * 100
            )
        
        # שינוי זיכרון
        if self.baseline_profile.peak_memory_mb > 0:
            self.memory_change_percent = (
                (self.current_profile.peak_memory_mb - self.baseline_profile.peak_memory_mb)
                / self.baseline_profile.peak_memory_mb * 100
            )
        
        # שינוי CPU
        if self.baseline_profile.peak_cpu_percent > 0:
            self.cpu_change_percent = (
                (self.current_profile.peak_cpu_percent - self.baseline_profile.peak_cpu_percent)
                / self.baseline_profile.peak_cpu_percent * 100
            )
    
    def _analyze_trend(self):
        """ניתוח מגמה"""
        changes = [
            abs(self.duration_change_percent),
            abs(self.memory_change_percent),
            abs(self.cpu_change_percent)
        ]
        
        avg_change = sum(changes) / len(changes)
        
        if avg_change < 5:  # פחות מ-5% שינוי
            self.performance_trend = "stable"
            self.significance = 0.1
        elif self.duration_change_percent < -10:  # שיפור משמעותי בזמן
            self.performance_trend = "improving"
            self.significance = min(abs(self.duration_change_percent) / 100, 1.0)
        elif self.duration_change_percent > 10:  # החמרה משמעותית בזמן
            self.performance_trend = "degrading"
            self.significance = min(abs(self.duration_change_percent) / 100, 1.0)
        else:
            self.performance_trend = "stable"
            self.significance = 0.3

class PerformanceThresholds:
    """ספי ביצועים"""
    
    # זמני תגובה (מילישניות)
    EXCELLENT_RESPONSE_TIME = 100
    GOOD_RESPONSE_TIME = 500
    ACCEPTABLE_RESPONSE_TIME = 1000
    SLOW_RESPONSE_TIME = 5000
    
    # שימוש במשאבים (אחוזים)
    HIGH_CPU_THRESHOLD = 80
    HIGH_MEMORY_THRESHOLD = 85
    HIGH_DISK_THRESHOLD = 90
    
    # ביצועי API
    GOOD_CACHE_HIT_RATE = 0.8
    ACCEPTABLE_ERROR_RATE = 0.05
    HIGH_ERROR_RATE = 0.1
    
    # צווארי בקבוק
    BOTTLENECK_SEVERITY_THRESHOLD = 0.7
    CRITICAL_BOTTLENECK_THRESHOLD = 0.9

# פונקציות עזר
def create_resource_snapshot() -> ResourceMetrics:
    """יצירת snapshot של משאבי המערכת"""
    try:
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        network = psutil.net_io_counters()
        
        return ResourceMetrics(
            cpu_percent=cpu_percent,
            cpu_cores_used=psutil.cpu_count() * (cpu_percent / 100),
            memory_used_mb=memory.used / 1024 / 1024,
            memory_percent=memory.percent,
            memory_available_mb=memory.available / 1024 / 1024,
            memory_cached_mb=memory.cached / 1024 / 1024 if hasattr(memory, 'cached') else 0,
            disk_usage_percent=disk.percent,
            disk_free_gb=disk.free / 1024 / 1024 / 1024,
            network_sent_mb=network.bytes_sent / 1024 / 1024,
            network_recv_mb=network.bytes_recv / 1024 / 1024,
            processes_count=len(psutil.pids()),
            threads_count=threading.active_count()
        )
    except Exception:
        return ResourceMetrics()

def classify_bottleneck(resource_metrics: ResourceMetrics) -> Optional[BottleneckType]:
    """סיווג צוואר בקבוק לפי מטריקות"""
    thresholds = PerformanceThresholds()
    
    if resource_metrics.cpu_percent > thresholds.HIGH_CPU_THRESHOLD:
        return BottleneckType.CPU_BOUND
    elif resource_metrics.memory_percent > thresholds.HIGH_MEMORY_THRESHOLD:
        return BottleneckType.MEMORY_BOUND
    elif resource_metrics.disk_usage_percent > thresholds.HIGH_DISK_THRESHOLD:
        return BottleneckType.DISK_SPACE
    elif resource_metrics.network_connections > 1000:
        return BottleneckType.NETWORK_BOUND
    
    return None

def calculate_performance_score(duration_ms: float, error_count: int, resource_pressure: float) -> float:
    """חישוב ציון ביצועים כללי"""
    # ציון זמן (0-1)
    time_score = max(1.0 - (duration_ms / 10000), 0.0)  # נורמליזציה לפי 10 שניות
    
    # ציון שגיאות (0-1)
    error_score = max(1.0 - (error_count * 0.1), 0.0)
    
    # ציון משאבים (0-1)
    resource_score = max(1.0 - resource_pressure, 0.0)
    
    # ממוצע משוקלל
    return (time_score * 0.4 + error_score * 0.3 + resource_score * 0.3)