"""
Models package for Execution Profiler Advanced Module
=====================================================

Contains data models, types, and structures for performance profiling
and resource consumption tracking.
"""

from .profiling_types import (
    ProfileMetrics,
    BottleneckReport,
    ResourceUsage,
    APICallMetrics,
    MemoryMetrics,
    ExecutionContext,
    PerformanceThresholds,
    OptimizationSuggestion
)

__all__ = [
    'ProfileMetrics',
    'BottleneckReport', 
    'ResourceUsage',
    'APICallMetrics',
    'MemoryMetrics',
    'ExecutionContext',
    'PerformanceThresholds',
    'OptimizationSuggestion'
]