"""
Core package for Emotion Analyzer Advanced Module

Contains the main engine classes and processing logic for
emotion and tone analysis functionality.
"""

from .emotion_analyzer_engine import EmotionAnalyzerEngine
from .tone_detector import ToneDetector
from .multimodal_analyzer import MultimodalAnalyzer
from .hebrew_processor import HebrewProcessor
from .voice_emotion_analyzer import VoiceEmotionAnalyzer

__all__ = [
    'EmotionAnalyzerEngine',
    'ToneDetector',
    'MultimodalAnalyzer', 
    'HebrewProcessor',
    'VoiceEmotionAnalyzer'
]