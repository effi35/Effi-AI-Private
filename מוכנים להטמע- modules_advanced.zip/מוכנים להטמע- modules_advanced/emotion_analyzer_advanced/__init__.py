"""
Emotion Analyzer Advanced Module

This module provides advanced emotion and tone analysis capabilities for text, voice, 
and multimodal content using the local Hudson/Llama model with Hebrew language support.

Features:
- Multi-modal emotion analysis (text, voice, visual)
- Hebrew language support with cultural context
- Real-time emotion tracking
- Advanced tone detection
- Emotional intelligence metrics
- Local AI model integration (Hudson/Llama)
"""

__version__ = "1.0.0"
__author__ = "Effi AI System"

from .core.emotion_analyzer_engine import EmotionAnalyzerEngine
from .core.tone_detector import ToneDetector
from .core.multimodal_analyzer import MultimodalAnalyzer
from .models.emotion_types import EmotionTypes, ToneTypes
from .ui.emotion_dashboard import EmotionDashboard

__all__ = [
    'EmotionAnalyzerEngine',
    'ToneDetector', 
    'MultimodalAnalyzer',
    'EmotionTypes',
    'ToneTypes',
    'EmotionDashboard'
]