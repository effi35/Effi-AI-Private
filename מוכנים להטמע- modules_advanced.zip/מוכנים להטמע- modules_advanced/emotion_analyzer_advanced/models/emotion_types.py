"""
Emotion Analyzer Advanced - Emotion Types and Models
מודלים לניתוח רגשות וטון מתקדם עם תמיכה בעברית
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime, timedelta
import uuid
import json
import math

class BasicEmotion(Enum):
    """רגשות בסיסיים (Plutchik's model)"""
    JOY = "joy"                    # שמחה
    SADNESS = "sadness"            # עצב
    ANGER = "anger"                # כעס
    FEAR = "fear"                  # פחד
    SURPRISE = "surprise"          # הפתעה
    DISGUST = "disgust"            # גועל
    TRUST = "trust"                # אמון
    ANTICIPATION = "anticipation"   # ציפייה

class ComplexEmotion(Enum):
    """רגשות מורכבים"""
    LOVE = "love"                  # אהבה (joy + trust)
    GUILT = "guilt"                # אשמה (fear + sadness)
    SHAME = "shame"                # בושה (fear + disgust)
    PRIDE = "pride"                # גאווה (joy + anger)
    ENVY = "envy"                  # קנאה (sadness + anger)
    HOPE = "hope"                  # תקווה (trust + anticipation)
    ANXIETY = "anxiety"            # חרדה (fear + anticipation)
    MELANCHOLY = "melancholy"      # מלנכוליה (sadness + anticipation)
    CONTEMPT = "contempt"          # בוז (anger + disgust)
    NOSTALGIA = "nostalgia"        # נוסטלגיה (sadness + joy)
    OPTIMISM = "optimism"          # אופטימיות (anticipation + joy)
    PESSIMISM = "pessimism"        # פסימיות (sadness + anticipation)
    CURIOSITY = "curiosity"        # סקרנות (trust + surprise)
    CYNICISM = "cynicism"          # ציניות (disgust + anticipation)
    GRATITUDE = "gratitude"        # הכרת תודה (joy + trust)

class HebrewEmotion(Enum):
    """רגשות ספציפיים לתרבות עברית/ישראלית"""
    DAVKA = "davka"                # דווקא - עקשנות יצירתית
    BALAGAN = "balagan"            # בלגן - כאוס מקובל
    FREIER = "freier"              # פראייר - תחושת ניצול
    SABRA = "sabra"                # צבר - גאווה ישראלית מקומית
    YOFI = "yofi"                  # יופי - הסכמה חמה
    HAVAL = "haval"                # חבל - צער על הזדמנות שנפספסה
    ACHI = "achi"                  # אחי - חברותיות ישראלית
    KAPARA = "kapara"              # כפרה - חיבה ישראלית
    PROTEKZIA = "protekzia"        # פרוטקציה - תחושת העדפה לא הוגנת
    TACHLES = "tachles"            # תכל'ס - רצינות לעניין

class ToneType(Enum):
    """סוגי טון"""
    FORMAL = "formal"              # פורמלי
    INFORMAL = "informal"          # לא פורמלי
    FRIENDLY = "friendly"          # ידידותי
    PROFESSIONAL = "professional"  # מקצועי
    CASUAL = "casual"              # קז'ואל
    SERIOUS = "serious"            # רציני
    HUMOROUS = "humorous"          # הומוריסטי
    SARCASTIC = "sarcastic"        # סרקסטי
    AGGRESSIVE = "aggressive"      # תוקפני
    PASSIVE = "passive"            # פסיבי
    ASSERTIVE = "assertive"        # אסרטיבי
    EMPATHETIC = "empathetic"      # אמפתי
    AUTHORITATIVE = "authoritative" # סמכותי
    SUPPORTIVE = "supportive"      # תומך
    CRITICAL = "critical"          # ביקורתי

class EmotionIntensity(Enum):
    """עוצמת רגש"""
    VERY_LOW = "very_low"          # 0.0-0.2
    LOW = "low"                    # 0.2-0.4
    MEDIUM = "medium"              # 0.4-0.6
    HIGH = "high"                  # 0.6-0.8
    VERY_HIGH = "very_high"        # 0.8-1.0

class EmotionValence(Enum):
    """ערכיות רגשית"""
    VERY_NEGATIVE = "very_negative"    # -1.0 to -0.6
    NEGATIVE = "negative"              # -0.6 to -0.2
    NEUTRAL = "neutral"                # -0.2 to 0.2
    POSITIVE = "positive"              # 0.2 to 0.6
    VERY_POSITIVE = "very_positive"    # 0.6 to 1.0

class AnalysisContext(Enum):
    """הקשר ניתוח"""
    CONVERSATION = "conversation"      # שיחה
    SOCIAL_MEDIA = "social_media"     # רשתות חברתיות
    CUSTOMER_SERVICE = "customer_service" # שירות לקוחות
    LITERATURE = "literature"         # ספרות
    NEWS = "news"                     # חדשות
    REVIEW = "review"                 # ביקורת
    EMAIL = "email"                   # אימייל
    CHAT = "chat"                     # צ'אט
    SPEECH = "speech"                 # דיבור
    INTERVIEW = "interview"           # ראיון

@dataclass
class EmotionScore:
    """ציון רגש"""
    emotion: Union[BasicEmotion, ComplexEmotion, HebrewEmotion]
    intensity: float = 0.0            # 0.0-1.0
    confidence: float = 0.0           # 0.0-1.0
    valence: float = 0.0              # -1.0 to 1.0 (negative to positive)
    arousal: float = 0.0              # 0.0-1.0 (calm to excited)
    
    def get_intensity_level(self) -> EmotionIntensity:
        """קבלת רמת עוצמה"""
        if self.intensity <= 0.2:
            return EmotionIntensity.VERY_LOW
        elif self.intensity <= 0.4:
            return EmotionIntensity.LOW
        elif self.intensity <= 0.6:
            return EmotionIntensity.MEDIUM
        elif self.intensity <= 0.8:
            return EmotionIntensity.HIGH
        else:
            return EmotionIntensity.VERY_HIGH
    
    def get_valence_category(self) -> EmotionValence:
        """קבלת קטגוריית ערכיות"""
        if self.valence <= -0.6:
            return EmotionValence.VERY_NEGATIVE
        elif self.valence <= -0.2:
            return EmotionValence.NEGATIVE
        elif self.valence <= 0.2:
            return EmotionValence.NEUTRAL
        elif self.valence <= 0.6:
            return EmotionValence.POSITIVE
        else:
            return EmotionValence.VERY_POSITIVE

@dataclass
class ToneAnalysis:
    """ניתוח טון"""
    primary_tone: ToneType
    secondary_tones: List[ToneType] = field(default_factory=list)
    formality_score: float = 0.5      # 0.0 (informal) to 1.0 (formal)
    politeness_score: float = 0.5     # 0.0 (rude) to 1.0 (very polite)
    assertiveness_score: float = 0.5  # 0.0 (passive) to 1.0 (aggressive)
    confidence_score: float = 0.5     # 0.0 (uncertain) to 1.0 (very confident)
    warmth_score: float = 0.5         # 0.0 (cold) to 1.0 (warm)
    
    def get_communication_style(self) -> str:
        """קבלת סגנון תקשורת"""
        if self.assertiveness_score > 0.7 and self.warmth_score > 0.7:
            return "אסרטיבי וחם"
        elif self.assertiveness_score > 0.7 and self.warmth_score < 0.3:
            return "תוקפני"
        elif self.assertiveness_score < 0.3 and self.warmth_score > 0.7:
            return "תומך ופסיבי"
        elif self.assertiveness_score < 0.3 and self.warmth_score < 0.3:
            return "פסיבי-אגרסיבי"
        else:
            return "מאוזן"

@dataclass
class ContextualFactors:
    """גורמים הקשריים"""
    cultural_context: str = "israeli"  # הקשר תרבותי
    age_group: str = "adult"           # קבוצת גיל
    gender: str = "unknown"            # מגדר
    relationship: str = "unknown"      # יחסים (חבר, עמית, זר)
    setting: str = "neutral"           # מסגרת (רשמי, לא רשמי)
    time_of_day: str = "unknown"       # שעה ביום
    social_status: str = "equal"       # מעמד חברתי יחסי

@dataclass
class EmotionAnalysisResult:
    """תוצאת ניתוח רגשות"""
    analysis_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    
    # רגשות זוהו
    primary_emotion: EmotionScore = field(default_factory=lambda: EmotionScore(BasicEmotion.JOY))
    secondary_emotions: List[EmotionScore] = field(default_factory=list)
    hebrew_emotions: List[EmotionScore] = field(default_factory=list)
    
    # ניתוח טון
    tone_analysis: ToneAnalysis = field(default_factory=lambda: ToneAnalysis(ToneType.NEUTRAL))
    
    # מדדים כלליים
    overall_sentiment: float = 0.0      # -1.0 (very negative) to 1.0 (very positive)
    emotional_intensity: float = 0.0    # 0.0 (calm) to 1.0 (very intense)
    emotional_complexity: float = 0.0   # 0.0 (simple) to 1.0 (complex)
    emotional_stability: float = 0.5    # 0.0 (unstable) to 1.0 (stable)
    
    # הקשר
    context: AnalysisContext = AnalysisContext.CONVERSATION
    contextual_factors: ContextualFactors = field(default_factory=ContextualFactors)
    
    # מטאדטה
    text_length: int = 0
    language: str = "hebrew"
    confidence: float = 0.0              # ביטחון כללי בניתוח
    processing_time_ms: float = 0.0
    
    # מילות מפתח רגשיות
    emotional_keywords: List[str] = field(default_factory=list)
    emotional_phrases: List[str] = field(default_factory=list)
    
    # ניתוח מתקדם
    emotional_arc: List[Dict[str, float]] = field(default_factory=list)  # שינוי רגשי לאורך הטקסט
    dominant_emotion_changes: int = 0    # מספר שינויי רגש דומיננטיים
    
    def get_dominant_emotion(self) -> Union[BasicEmotion, ComplexEmotion, HebrewEmotion]:
        """קבלת הרגש הדומיננטי"""
        return self.primary_emotion.emotion
    
    def get_emotional_summary(self) -> str:
        """קבלת סיכום רגשי"""
        emotion_name = self.primary_emotion.emotion.value
        intensity = self.primary_emotion.get_intensity_level().value
        valence = self.primary_emotion.get_valence_category().value
        
        return f"רגש דומיננטי: {emotion_name}, עוצמה: {intensity}, ערכיות: {valence}"
    
    def add_secondary_emotion(self, emotion: EmotionScore):
        """הוספת רגש משני"""
        if emotion.intensity >= 0.3:  # רק רגשות עם עוצמה מינימלית
            self.secondary_emotions.append(emotion)
            # מיון לפי עוצמה
            self.secondary_emotions.sort(key=lambda e: e.intensity, reverse=True)
            # שמירה על 5 רגשות משניים מקסימום
            self.secondary_emotions = self.secondary_emotions[:5]
    
    def calculate_emotional_complexity(self):
        """חישוב מורכבות רגשית"""
        # מספר רגשות שונים
        total_emotions = 1 + len(self.secondary_emotions) + len(self.hebrew_emotions)
        complexity_from_count = min(total_emotions / 5, 1.0)
        
        # שונות בעוצמות
        intensities = [self.primary_emotion.intensity]
        intensities.extend([e.intensity for e in self.secondary_emotions])
        
        if len(intensities) > 1:
            mean_intensity = sum(intensities) / len(intensities)
            variance = sum((i - mean_intensity) ** 2 for i in intensities) / len(intensities)
            complexity_from_variance = min(variance * 2, 1.0)
        else:
            complexity_from_variance = 0.0
        
        # מורכבות לפי שינויים
        complexity_from_changes = min(self.dominant_emotion_changes / 10, 1.0)
        
        self.emotional_complexity = (
            complexity_from_count * 0.4 +
            complexity_from_variance * 0.3 +
            complexity_from_changes * 0.3
        )

@dataclass
class EmotionPattern:
    """דפוס רגשי"""
    pattern_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    
    # מאפייני הדפוס
    emotion_sequence: List[BasicEmotion] = field(default_factory=list)
    typical_intensity: float = 0.5
    typical_duration: timedelta = field(default_factory=lambda: timedelta(minutes=5))
    
    # סטטיסטיקות
    frequency: int = 0               # כמה פעמים נראה הדפוס
    confidence: float = 0.0          # ביטחון בזיהוי הדפוס
    last_seen: Optional[datetime] = None
    
    # הקשר
    common_contexts: List[AnalysisContext] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)  # מה גורם לדפוס

@dataclass
class EmotionTrend:
    """מגמת רגשית"""
    trend_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    
    # נתוני המגמה
    emotion_data: List[Tuple[datetime, EmotionScore]] = field(default_factory=list)
    overall_direction: str = "stable"  # "improving", "worsening", "stable"
    trend_strength: float = 0.0        # 0.0 (weak) to 1.0 (strong)
    
    # סטטיסטיקות
    average_sentiment: float = 0.0
    sentiment_variance: float = 0.0
    peak_emotion: Optional[EmotionScore] = None
    lowest_emotion: Optional[EmotionScore] = None
    
    def add_emotion_point(self, emotion: EmotionScore, timestamp: datetime = None):
        """הוספת נקודת נתונים רגשית"""
        if timestamp is None:
            timestamp = datetime.now()
        
        self.emotion_data.append((timestamp, emotion))
        
        # עדכון סטטיסטיקות
        self._update_statistics()
    
    def _update_statistics(self):
        """עדכון סטטיסטיקות המגמה"""
        if not self.emotion_data:
            return
        
        sentiments = [emotion.valence for _, emotion in self.emotion_data]
        self.average_sentiment = sum(sentiments) / len(sentiments)
        
        if len(sentiments) > 1:
            mean = self.average_sentiment
            self.sentiment_variance = sum((s - mean) ** 2 for s in sentiments) / len(sentiments)
        
        # מציאת רגש הגבוה והנמוך ביותר
        intensities = [(intensity, emotion) for _, emotion in self.emotion_data 
                      for intensity in [emotion.intensity]]
        
        if intensities:
            self.peak_emotion = max(intensities, key=lambda x: x[0])[1]
            self.lowest_emotion = min(intensities, key=lambda x: x[0])[1]
        
        # חישוב כיוון מגמה
        if len(sentiments) >= 3:
            recent_avg = sum(sentiments[-3:]) / 3
            earlier_avg = sum(sentiments[:-3]) / len(sentiments[:-3])
            
            if recent_avg > earlier_avg + 0.1:
                self.overall_direction = "improving"
                self.trend_strength = min(abs(recent_avg - earlier_avg), 1.0)
            elif recent_avg < earlier_avg - 0.1:
                self.overall_direction = "worsening"
                self.trend_strength = min(abs(recent_avg - earlier_avg), 1.0)
            else:
                self.overall_direction = "stable"
                self.trend_strength = 1.0 - min(self.sentiment_variance, 1.0)

@dataclass
class PersonalityTraits:
    """תכונות אישיות מזוהות מהטקסט"""
    openness: float = 0.5           # פתיחות לחוויות
    conscientiousness: float = 0.5  # מצפוניות
    extraversion: float = 0.5       # אקסטרוברטיות
    agreeableness: float = 0.5      # נוחות הסכמה
    neuroticism: float = 0.5        # נוירוטיות
    
    # תכונות ספציפיות לתרבות ישראלית
    directness: float = 0.5         # ישירות
    warmth: float = 0.5            # חמימות
    humor_tendency: float = 0.5     # נטייה להומור
    criticism_comfort: float = 0.5  # נוחות עם ביקורת
    
    def get_personality_summary(self) -> str:
        """סיכום אישיות"""
        traits = []
        
        if self.extraversion > 0.6:
            traits.append("אקסטרוברט")
        elif self.extraversion < 0.4:
            traits.append("אינטרוברט")
        
        if self.directness > 0.7:
            traits.append("ישיר")
        
        if self.warmth > 0.7:
            traits.append("חם")
        
        if self.humor_tendency > 0.6:
            traits.append("הומוריסטי")
        
        return ", ".join(traits) if traits else "מאוזן"

class EmotionModelConfig:
    """הגדרות מודל רגשות"""
    
    # רגשות עבריים עם מילות מפתח
    HEBREW_EMOTION_KEYWORDS = {
        HebrewEmotion.DAVKA: [
            "דווקא", "בדווקא", "דווקני", "עקשן", "עקשנות",
            "לא אכפת לי", "אעשה בדווקא", "רק בגלל זה"
        ],
        HebrewEmotion.BALAGAN: [
            "בלגן", "בלאגן", "כאוס", "תוהו ובוהו", "לא מסודר",
            "מבולבל", "מבולגן", "איזה בלגן", "עושים בלגן"
        ],
        HebrewEmotion.FREIER: [
            "פראייר", "פרייר", "מרגיש פראייר", "נראה פראייר",
            "עושים אותי פראייר", "לא אהיה פראייר", "פראיירית"
        ],
        HebrewEmotion.SABRA: [
            "צבר", "ישראלי אמיתי", "גאווה ישראלית", "ילוד הארץ",
            "אני צבר", "בן המקום", "ישראליות"
        ],
        HebrewEmotion.YOFI: [
            "יופי", "יופי של דבר", "בסדר גמור", "מצוין",
            "סבבה", "מעולה", "כל הכבוד"
        ],
        HebrewEmotion.HAVAL: [
            "חבל", "חבל על הזמן", "חבל שלא", "איזה חבל",
            "ממש חבל", "חבל מאוד", "חבל עליי"
        ],
        HebrewEmotion.ACHI: [
            "אחי", "אחי שלי", "חבר שלי", "יא אחי",
            "תשמע אחי", "אחי תאמין לי"
        ],
        HebrewEmotion.KAPARA: [
            "כפרה", "כפרה עליך", "כפרה שלי", "יא כפרה",
            "כפרות", "חמוד", "מתוק"
        ]
    }
    
    # מילות מפתח לרגשות בסיסיים בעברית
    BASIC_EMOTION_KEYWORDS_HEBREW = {
        BasicEmotion.JOY: [
            "שמח", "שמחה", "שמחים", "שמחות", "עליז", "עליזה",
            "אושר", "מאושר", "מאושרת", "גיל", "ששון", "צוהל",
            "נהנה", "נהנית", "נהנים", "כיף", "חדווה", "אופוריה"
        ],
        BasicEmotion.SADNESS: [
            "עצוב", "עצובה", "עצבים", "עצבות", "דכדוך", "דכאון",
            "מדוכא", "מדוכאת", "יגון", "אבל", "זעף", "כאב",
            "צער", "מצטער", "מצטערת", "בוכה", "דמעות", "ייאוש"
        ],
        BasicEmotion.ANGER: [
            "כועס", "כועסת", "כעס", "זעם", "חמה", "זעף",
            "מעצבן", "מרגיז", "כעוס", "נרגז", "נרגזת", "זועם",
            "התפרצות", "קצף", "רוגז", "חרון", "סער"
        ],
        BasicEmotion.FEAR: [
            "פחד", "פוחד", "פוחדת", "פחדים", "חרדה", "חרד",
            "חרדה", "מפחיד", "מפחידה", "איום", "פאניקה",
            "בהלה", "אימה", "חרדתי", "נבהל", "נבהלת"
        ]
    }
    
    # דפוסי תקשורת ישראליים
    ISRAELI_COMMUNICATION_PATTERNS = {
        "direct_criticism": [
            "תשמע", "תקשיב טוב", "אמת", "בלי קשקושים",
            "ישר בעניים", "בלי פטפוטים", "תכל'ס"
        ],
        "warmth_expressions": [
            "חמוד", "מתוק", "יקר", "נשמה", "חיים שלי",
            "אהוב", "כפרה", "מלאך", "זהב"
        ],
        "israeli_assertiveness": [
            "אני אגיד לך", "תבין אותי טוב", "ככה זה",
            "אני לא מוותר", "עמדה שלי", "זו ההחלטה"
        ]
    }

# פונקציות עזר
def create_emotion_score(emotion: Union[BasicEmotion, ComplexEmotion, HebrewEmotion], 
                        intensity: float, 
                        confidence: float = 0.8) -> EmotionScore:
    """יצירת ציון רגש"""
    # חישוב valence לפי סוג הרגש
    positive_emotions = {
        BasicEmotion.JOY, BasicEmotion.TRUST, BasicEmotion.ANTICIPATION,
        ComplexEmotion.LOVE, ComplexEmotion.HOPE, ComplexEmotion.OPTIMISM,
        ComplexEmotion.GRATITUDE, HebrewEmotion.YOFI, HebrewEmotion.SABRA
    }
    
    negative_emotions = {
        BasicEmotion.SADNESS, BasicEmotion.ANGER, BasicEmotion.FEAR, BasicEmotion.DISGUST,
        ComplexEmotion.GUILT, ComplexEmotion.SHAME, ComplexEmotion.ENVY,
        HebrewEmotion.FREIER, HebrewEmotion.HAVAL
    }
    
    if emotion in positive_emotions:
        valence = 0.3 + (intensity * 0.7)  # 0.3 to 1.0
    elif emotion in negative_emotions:
        valence = -0.3 - (intensity * 0.7)  # -0.3 to -1.0
    else:
        valence = (intensity - 0.5) * 0.4  # -0.2 to 0.2
    
    # חישוב arousal
    high_arousal_emotions = {
        BasicEmotion.ANGER, BasicEmotion.FEAR, BasicEmotion.SURPRISE,
        ComplexEmotion.ANXIETY, ComplexEmotion.EXCITEMENT,
        HebrewEmotion.DAVKA, HebrewEmotion.BALAGAN
    }
    
    arousal = 0.7 + (intensity * 0.3) if emotion in high_arousal_emotions else 0.3 + (intensity * 0.4)
    
    return EmotionScore(
        emotion=emotion,
        intensity=intensity,
        confidence=confidence,
        valence=valence,
        arousal=arousal
    )

def get_emotion_color(emotion: Union[BasicEmotion, ComplexEmotion, HebrewEmotion]) -> str:
    """קבלת צבע לייצוג הרגש"""
    color_map = {
        BasicEmotion.JOY: "#FFD700",        # זהב
        BasicEmotion.SADNESS: "#4682B4",    # כחול פלדה
        BasicEmotion.ANGER: "#DC143C",      # אדום כהה
        BasicEmotion.FEAR: "#9370DB",       # סגול בינוני
        BasicEmotion.SURPRISE: "#FFA500",   # כתום
        BasicEmotion.DISGUST: "#8FBC8F",    # ירוק ים כהה
        BasicEmotion.TRUST: "#20B2AA",      # ירוק ים בהיר
        BasicEmotion.ANTICIPATION: "#FF69B4", # ורוד
        
        ComplexEmotion.LOVE: "#FF1493",     # ורוד כהה
        ComplexEmotion.HOPE: "#98FB98",     # ירוק בהיר
        ComplexEmotion.ANXIETY: "#DDA0DD",  # שזיף
        
        HebrewEmotion.DAVKA: "#FF6347",     # עגבניה
        HebrewEmotion.YOFI: "#32CD32",      # ירוק ליים
        HebrewEmotion.SABRA: "#4169E1"      # כחול מלכותי
    }
    
    return color_map.get(emotion, "#808080")  # אפור כברירת מחדל

def calculate_emotion_distance(emotion1: EmotionScore, emotion2: EmotionScore) -> float:
    """חישוב מרחק בין שני רגשות בחלל הרגשי"""
    # מרחק במרחב valence-arousal
    valence_dist = abs(emotion1.valence - emotion2.valence)
    arousal_dist = abs(emotion1.arousal - emotion2.arousal)
    intensity_dist = abs(emotion1.intensity - emotion2.intensity)
    
    return math.sqrt(valence_dist**2 + arousal_dist**2 + intensity_dist**2) / math.sqrt(3)