"""
Models package for Emotion Analyzer Advanced Module

Contains data models, type definitions, and configuration classes
for emotion and tone analysis functionality.
"""

from .emotion_types import EmotionTypes, ToneTypes, EmotionResult
from .analysis_config import AnalysisConfig
from .hebrew_emotion_mapping import HebrewEmotionMapping

__all__ = [
    'EmotionTypes',
    'ToneTypes', 
    'EmotionResult',
    'AnalysisConfig',
    'HebrewEmotionMapping'
]