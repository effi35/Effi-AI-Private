# Emotion Analyzer Advanced Module

Advanced emotion and tone analysis module for the Effi AI system, providing comprehensive emotion detection, tone analysis, and multimodal content analysis with Hebrew language support and local AI integration.

## Features

### 🎭 Emotion Analysis
- **Text Emotion Analysis**: Advanced emotion detection in text content
- **Voice Emotion Analysis**: Real-time emotion recognition from audio
- **Multimodal Analysis**: Combined text, voice, and visual emotion analysis
- **Real-time Tracking**: Continuous emotion monitoring and trend analysis

### 🌍 Language Support
- **Hebrew Language**: Full Hebrew language support with cultural context
- **Multilingual**: Support for Hebrew, English, and Arabic
- **Cultural Context**: Hebrew cultural nuances and expressions
- **Auto-Detection**: Automatic language detection

### 🎵 Tone Detection
- **Advanced Tone Analysis**: Sophisticated tone detection algorithms
- **Context Awareness**: Contextual tone interpretation
- **Emotional Tone Mapping**: Connection between emotions and tones
- **Real-time Processing**: Live tone analysis capabilities

### 🧠 Emotional Intelligence
- **EI Metrics**: Comprehensive emotional intelligence scoring
- **Trend Analysis**: Long-term emotion and behavior patterns
- **Recommendations**: Personalized EI improvement suggestions
- **Progress Tracking**: Monitor emotional development over time

### 🤖 AI Integration
- **Local AI Models**: Integration with Hudson/Llama models
- **Offline Processing**: Complete offline emotion analysis
- **Privacy-First**: No data sent to external services
- **High Performance**: Optimized for real-time processing

## Installation

### Automatic Installation
```bash
cd /root/Effi_ai_privet/modules_advanced/emotion_analyzer_advanced
chmod +x install.sh
./install.sh
```

### Manual Installation
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m spacy download he_core_news_sm
```

## Quick Start

### Basic Text Emotion Analysis
```python
from emotion_analyzer_advanced import emotion_analyzer_advanced

# Initialize the module
await emotion_analyzer_advanced.initialize()

# Analyze text emotions
result = await emotion_analyzer_advanced.analyze_text_emotion(
    text="אני מרגיש מאוד שמח היום!",
    language="he"
)

print(result)
# Output: {
#     "emotions": {
#         "joy": 0.85,
#         "trust": 0.65,
#         "anticipation": 0.45
#     },
#     "dominant_emotion": "joy",
#     "cultural_context": {
#         "hebrew_expressions": ["שמח"],
#         "intensity": "high"
#     }
# }
```

### Voice Emotion Analysis
```python
# Analyze voice emotions
with open("audio_file.wav", "rb") as f:
    audio_data = f.read()

result = await emotion_analyzer_advanced.analyze_voice_emotion(
    audio_data=audio_data,
    format="wav"
)

print(result)
```

### Multimodal Analysis
```python
# Combine multiple content types
content = {
    "text": "אני מרגיש נהדר!",
    "audio_data": audio_data,
    "image_data": image_data
}

result = await emotion_analyzer_advanced.analyze_multimodal_emotion(content)
```

### Tone Detection
```python
# Detect tone in text
result = await emotion_analyzer_advanced.detect_tone(
    text="תודה רבה על העזרה שלך",
    context={"conversation_type": "formal"}
)

print(result)
# Output: {
#     "tone": "grateful",
#     "formality": "formal",
#     "politeness": "high",
#     "cultural_markers": ["תודה רבה"]
# }
```

### Emotion Trends
```python
# Get emotion trends
trends = await emotion_analyzer_advanced.get_emotion_trends(time_range="24h")

print(trends)
# Output: {
#     "time_range": "24h",
#     "trends": {
#         "dominant_emotions": ["joy", "trust"],
#         "emotion_distribution": {...},
#         "trend_direction": "positive"
#     }
# }
```

### Emotional Intelligence Metrics
```python
# Get EI metrics
metrics = await emotion_analyzer_advanced.get_emotional_intelligence_metrics()

print(metrics)
# Output: {
#     "emotional_awareness": 0.85,
#     "emotional_regulation": 0.78,
#     "empathy_score": 0.82,
#     "overall_ei_score": 0.81,
#     "recommendations": [...]
# }
```

## API Endpoints

### Text Analysis
- **POST** `/emotion_analyzer_advanced/analyze_text`
  - Parameters: `text` (string), `language` (optional)
  - Returns: Emotion analysis results

### Voice Analysis  
- **POST** `/emotion_analyzer_advanced/analyze_voice`
  - Parameters: `audio_data` (bytes), `format` (optional)
  - Returns: Voice emotion analysis results

### Multimodal Analysis
- **POST** `/emotion_analyzer_advanced/analyze_multimodal`
  - Parameters: `content` (object)
  - Returns: Comprehensive multimodal analysis

### Tone Detection
- **POST** `/emotion_analyzer_advanced/detect_tone`
  - Parameters: `text` (string), `context` (optional)
  - Returns: Tone analysis results

### Trends and Metrics
- **GET** `/emotion_analyzer_advanced/get_trends`
  - Parameters: `time_range` (optional)
  - Returns: Emotion trend data

- **GET** `/emotion_analyzer_advanced/get_ei_metrics`
  - Returns: Emotional intelligence metrics

## Configuration

### Module Configuration
```json
{
    "enabled": true,
    "debug_mode": false,
    "language_support": ["he", "en", "ar"],
    "analysis_modes": ["text", "voice", "multimodal"],
    "local_ai_integration": true,
    "real_time_analysis": true,
    "hebrew_cultural_context": true
}
```

### Hebrew Language Settings
```json
{
    "hebrew_nlp_model": "he_core_news_sm",
    "cultural_context": true,
    "dialect_detection": true,
    "formality_analysis": true,
    "religious_context": true
}
```

## Architecture

### Core Components
- **EmotionAnalyzerEngine**: Main emotion analysis engine
- **ToneDetector**: Advanced tone detection system
- **MultimodalAnalyzer**: Combined content analysis
- **HebrewProcessor**: Hebrew language processing
- **VoiceEmotionAnalyzer**: Audio emotion analysis

### Models Directory
- **emotion_types.py**: Emotion type definitions
- **analysis_config.py**: Configuration classes
- **hebrew_emotion_mapping.py**: Hebrew emotion mappings

### UI Components
- **emotion_dashboard.py**: Main emotion dashboard
- **tone_visualizer.py**: Tone visualization tools
- **emotion_chart_components.py**: Chart components

### Utils Directory
- **emotion_utils.py**: Emotion processing utilities
- **hebrew_text_utils.py**: Hebrew text processing
- **audio_processing_utils.py**: Audio processing tools
- **visualization_utils.py**: Visualization helpers

## Testing

### Run Tests
```bash
cd /root/Effi_ai_privet/modules_advanced/emotion_analyzer_advanced
python -m pytest tests/ -v
```

### Test Coverage
- Unit tests for all core components
- Integration tests for multimodal analysis
- Hebrew language processing tests
- Performance benchmarks

## Performance

### Optimization Features
- **Local Processing**: No external API calls
- **Batch Processing**: Efficient batch analysis
- **Caching**: Intelligent result caching
- **Async Processing**: Non-blocking operations

### Benchmarks
- Text analysis: ~50ms per text
- Voice analysis: ~200ms per 10s audio
- Multimodal analysis: ~500ms combined

## Contributing

### Development Setup
1. Clone the repository
2. Install development dependencies
3. Run tests to verify setup
4. Follow coding standards

### Code Style
- Follow PEP 8 standards
- Use type hints
- Add comprehensive docstrings
- Write unit tests for new features

## License

This module is part of the Effi AI system and follows the same licensing terms.

## Support

For questions, issues, or feature requests, please contact the Effi AI development team.

---

**🎭 Advanced Emotion Analysis for the Modern AI Era** 🤖