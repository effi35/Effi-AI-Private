#!/bin/bash

# Emotion Analyzer Advanced Module Installation Script
# This script installs the emotion analyzer advanced module with all dependencies

echo "🎭 Installing Emotion Analyzer Advanced Module..."

# Check if we're in the right directory
if [ ! -f "metadata.json" ]; then
    echo "❌ Error: Please run this script from the emotion_analyzer_advanced module directory"
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
echo "📚 Installing Python dependencies..."
pip install -r requirements.txt

# Install spaCy language models
echo "🌍 Installing spaCy language models..."
python -m spacy download en_core_web_sm
python -m spacy download he_core_news_sm

# Install NLTK data
echo "📖 Installing NLTK data..."
python -c "
import nltk
try:
    nltk.download('punkt')
    nltk.download('vader_lexicon')
    nltk.download('stopwords')
    nltk.download('wordnet')
    print('✅ NLTK data downloaded successfully')
except Exception as e:
    print(f'⚠️ Warning: NLTK download failed: {e}')
"

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p data/models
mkdir -p data/cache
mkdir -p logs
mkdir -p temp

# Set permissions
echo "🔐 Setting permissions..."
chmod +x install.sh
chmod -R 755 .

# Test installation
echo "🧪 Testing installation..."
python -c "
import sys
sys.path.append('.')

try:
    # Test core imports
    import numpy
    import pandas
    import torch
    import transformers
    import librosa
    import cv2
    import matplotlib
    import nltk
    import spacy
    
    print('✅ Core dependencies imported successfully')
    
    # Test spaCy models
    try:
        nlp_en = spacy.load('en_core_web_sm')
        print('✅ English spaCy model loaded successfully')
    except Exception as e:
        print(f'⚠️ Warning: English spaCy model failed: {e}')
    
    try:
        nlp_he = spacy.load('he_core_news_sm')
        print('✅ Hebrew spaCy model loaded successfully')
    except Exception as e:
        print(f'⚠️ Warning: Hebrew spaCy model failed: {e}')
    
    # Test module import
    from module import emotion_analyzer_advanced
    print('✅ Module imported successfully')
    
    print('\\n🎉 Installation completed successfully!')
    
except ImportError as e:
    print(f'❌ Import error: {e}')
    sys.exit(1)
except Exception as e:
    print(f'❌ Installation test failed: {e}')
    sys.exit(1)
"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Emotion Analyzer Advanced Module installed successfully!"
    echo ""
    echo "📋 Installation Summary:"
    echo "   - Python dependencies: ✅ Installed"
    echo "   - spaCy models: ✅ Installed"
    echo "   - NLTK data: ✅ Installed"
    echo "   - Directory structure: ✅ Created"
    echo "   - Module test: ✅ Passed"
    echo ""
    echo "🚀 Module is ready to use!"
    echo ""
    echo "💡 Next steps:"
    echo "   1. Initialize the module: await emotion_analyzer_advanced.initialize()"
    echo "   2. Start analyzing emotions in text, voice, and multimodal content"
    echo "   3. Check the README.md for detailed usage examples"
    echo ""
else
    echo ""
    echo "❌ Installation failed. Please check the error messages above."
    echo "🔧 Try running: pip install -r requirements.txt"
    echo "📞 Contact support if the problem persists."
    exit 1
fi