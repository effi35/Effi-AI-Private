"""
UI package for Emotion Analyzer Advanced Module

Contains user interface components and dashboards for
emotion and tone analysis visualization.
"""

from .emotion_dashboard import EmotionDashboard
from .tone_visualizer import ToneVisualizer
from .emotion_chart_components import EmotionChartComponents

__all__ = [
    'EmotionDashboard',
    'ToneVisualizer',
    'EmotionChartComponents'
]