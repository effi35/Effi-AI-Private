"""
Configuration package for Emotion Analyzer Advanced Module

Contains configuration files and settings for emotion analysis.
"""