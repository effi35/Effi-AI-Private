"""
Personal AI Assistant Module
מודול העוזר האישי החכם

הופך את המודל המקומי Hudson/Llama3.1 לעוזר אישי חכם עם אישיות חמה
בדיוק כמו Claude אבל פרטי ומקומי לחלוטין!
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
import json

from .core.personal_assistant_engine import (
    PersonalAssistantEngine, create_personal_assistant, create_smart_friend
)
from .models.assistant_personality import (
    AssistantPersonality, AssistantMood, ConversationStyle
)

logger = logging.getLogger(__name__)

class PersonalAIAssistantModule:
    """מודול העוזר האישי החכם"""
    
    def __init__(self):
        self.name = "personal_ai_assistant"
        self.display_name = "עוזר אישי חכם"
        self.version = "1.0.0"
        self.description = "עוזר AI אישי עם אישיות חמה ומקומי לחלוטין"
        self.author = "Effi AI Private System"
        
        # Assistant instances
        self.active_assistants: Dict[str, PersonalAssistantEngine] = {}
        self.default_assistant: Optional[PersonalAssistantEngine] = None
        
        # Module state
        self.is_initialized = False
        self.module_stats = {
            "total_assistants_created": 0,
            "total_conversations": 0,
            "total_messages": 0,
            "uptime_start": None
        }
        
    async def initialize(self) -> bool:
        """אתחול המודול"""
        try:
            logger.info("מאתחל מודול עוזר אישי חכם...")
            
            # Create default assistant
            self.default_assistant = await create_personal_assistant("אפי")
            self.active_assistants["אפי"] = self.default_assistant
            
            self.module_stats["total_assistants_created"] = 1
            self.module_stats["uptime_start"] = datetime.now()
            self.is_initialized = True
            
            logger.info("מודול עוזר אישי חכם אותחל בהצלחה!")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול מודול עוזר אישי: {e}")
            return False
    
    async def create_assistant(self, 
                             name: str, 
                             personality_type: str = "friendly",
                             custom_traits: Dict[str, float] = None) -> str:
        """יצירת עוזר אישי חדש"""
        try:
            if name in self.active_assistants:
                return f"עוזר בשם '{name}' כבר קיים!"
            
            # Create assistant based on type
            if personality_type == "smart_friend":
                assistant = await create_smart_friend(name)
            else:
                assistant = await create_personal_assistant(name)
            
            # Apply custom traits if provided
            if custom_traits:
                for trait in assistant.personality.core_traits:
                    if trait.name in custom_traits:
                        trait.intensity = custom_traits[trait.name]
            
            self.active_assistants[name] = assistant
            self.module_stats["total_assistants_created"] += 1
            
            logger.info(f"נוצר עוזר אישי חדש: {name}")
            return f"העוזר {name} נוצר בהצלחה! הוא מוכן לשיחה."
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת עוזר אישי {name}: {e}")
            return f"שגיאה ביצירת העוזר: {e}"
    
    async def chat_with_assistant(self, 
                                assistant_name: str,
                                message: str,
                                context: str = "",
                                mood_hint: str = "") -> Dict[str, Any]:
        """שיחה עם עוזר אישי"""
        try:
            if not self.is_initialized:
                await self.initialize()
            
            # Use default assistant if name not specified or not found
            if assistant_name not in self.active_assistants:
                if self.default_assistant:
                    assistant = self.default_assistant
                    assistant_name = "אפי"
                else:
                    return {"error": f"עוזר '{assistant_name}' לא קיים"}
            else:
                assistant = self.active_assistants[assistant_name]
            
            # Chat with assistant
            response = await assistant.chat(message, context, mood_hint)
            
            # Update module stats
            self.module_stats["total_conversations"] += 1
            self.module_stats["total_messages"] += 1
            
            return response
            
        except Exception as e:
            logger.error(f"שגיאה בשיחה עם עוזר {assistant_name}: {e}")
            return {
                "error": f"שגיאה בשיחה: {e}",
                "assistant_name": assistant_name
            }
    
    async def quick_chat(self, message: str) -> str:
        """שיחה מהירה עם העוזר הברירת מחדל"""
        try:
            result = await self.chat_with_assistant("אפי", message)
            return result.get("response", "שגיאה בתגובה")
        except Exception as e:
            return f"שגיאה: {e}"
    
    async def generate_code(self, 
                          language: str, 
                          task: str, 
                          context: str = "",
                          assistant_name: str = "אפי") -> Dict[str, Any]:
        """יצירת קוד עם עוזר אישי"""
        try:
            if assistant_name not in self.active_assistants:
                if self.default_assistant:
                    assistant = self.default_assistant
                else:
                    return {"error": f"עוזר '{assistant_name}' לא קיים"}
            else:
                assistant = self.active_assistants[assistant_name]
            
            result = await assistant.generate_code_with_personality(language, task, context)
            return result
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת קוד עם {assistant_name}: {e}")
            return {"error": f"שגיאה ביצירת קוד: {e}"}
    
    async def analyze_text(self, 
                         text: str, 
                         analysis_type: str = "general",
                         assistant_name: str = "אפי") -> Dict[str, Any]:
        """ניתוח טקסט עם עוזר אישי"""
        try:
            if assistant_name not in self.active_assistants:
                if self.default_assistant:
                    assistant = self.default_assistant
                else:
                    return {"error": f"עוזר '{assistant_name}' לא קיים"}
            else:
                assistant = self.active_assistants[assistant_name]
            
            result = await assistant.analyze_text_with_personality(text, analysis_type)
            return result
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח טקסט עם {assistant_name}: {e}")
            return {"error": f"שגיאה בניתוח טקסט: {e}"}
    
    def update_assistant_profile(self, 
                               assistant_name: str, 
                               profile_data: Dict[str, Any]) -> str:
        """עדכון פרופיל משתמש לעוזר"""
        try:
            if assistant_name not in self.active_assistants:
                return f"עוזר '{assistant_name}' לא קיים"
            
            assistant = self.active_assistants[assistant_name]
            assistant.update_user_profile(profile_data)
            
            return f"פרופיל עודכן בהצלחה עבור {assistant_name}"
            
        except Exception as e:
            logger.error(f"שגיאה בעדכון פרופיל {assistant_name}: {e}")
            return f"שגיאה בעדכון פרופיל: {e}"
    
    def get_assistant_info(self, assistant_name: str = "") -> Dict[str, Any]:
        """קבלת מידע על עוזר"""
        try:
            if not assistant_name:
                # Return list of all assistants
                assistants_info = {}
                for name, assistant in self.active_assistants.items():
                    assistants_info[name] = assistant.get_conversation_summary()
                return {
                    "active_assistants": assistants_info,
                    "module_stats": self.module_stats
                }
            
            if assistant_name not in self.active_assistants:
                return {"error": f"עוזר '{assistant_name}' לא קיים"}
            
            assistant = self.active_assistants[assistant_name]
            return assistant.get_conversation_summary()
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת מידע על {assistant_name}: {e}")
            return {"error": f"שגיאה בקבלת מידע: {e}"}
    
    def export_conversation(self, assistant_name: str) -> str:
        """ייצוא שיחה של עוזר"""
        try:
            if assistant_name not in self.active_assistants:
                return f"עוזר '{assistant_name}' לא קיים"
            
            assistant = self.active_assistants[assistant_name]
            return assistant.export_conversation()
            
        except Exception as e:
            logger.error(f"שגיאה בייצוא שיחה {assistant_name}: {e}")
            return f"שגיאה בייצוא: {e}"
    
    async def remove_assistant(self, assistant_name: str) -> str:
        """הסרת עוזר אישי"""
        try:
            if assistant_name == "אפי":
                return "לא ניתן להסיר את העוזר הברירת מחדל"
            
            if assistant_name not in self.active_assistants:
                return f"עוזר '{assistant_name}' לא קיים"
            
            assistant = self.active_assistants[assistant_name]
            await assistant.cleanup()
            del self.active_assistants[assistant_name]
            
            return f"העוזר {assistant_name} הוסר בהצלחה"
            
        except Exception as e:
            logger.error(f"שגיאה בהסרת עוזר {assistant_name}: {e}")
            return f"שגיאה בהסרת עוזר: {e}"
    
    def get_available_personalities(self) -> Dict[str, str]:
        """קבלת סוגי אישיות זמינים"""
        return {
            "friendly": "ידידותי וחם - מתאים לשיחות כלליות",
            "smart_friend": "חבר חכם - מתאים למשימות יצירתיות", 
            "professional": "מקצועי - מתאים לעבודה ופרויקטים",
            "supportive": "תומך - מתאים להנחיה ועידוד",
            "analytical": "אנליטי - מתאים לפתרון בעיות"
        }
    
    def get_conversation_tips(self) -> List[str]:
        """טיפים לשיחה עם העוזר"""
        return [
            "דבר עם העוזר בעברית - הוא מבין אותך מעולה!",
            "שתף פרטים אישיים - הוא יזכור אותם ויתייחס אליהם",
            "תן לו לדעת איך אתה מרגיש - הוא יתאים את הטון שלו",
            "בקש עזרה בקידוד - הוא מומחה בכל השפות",
            "בקש ממנו לנתח טקסטים - הוא נותן תובנות מעניינות",
            "אל תהסס לשאול שאלות - הוא כאן בשבילך",
            "הוא למד מכל שיחה - ככל שתדבר איתו יותר, הוא יכיר אותך יותר"
        ]
    
    async def test_assistant_connection(self, assistant_name: str = "אפי") -> Dict[str, Any]:
        """בדיקת חיבור עוזר"""
        try:
            test_message = "בדיקה - אתה שומע אותי?"
            result = await self.chat_with_assistant(assistant_name, test_message)
            
            return {
                "success": "response" in result and "error" not in result,
                "assistant_name": assistant_name,
                "test_response": result.get("response", ""),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "assistant_name": assistant_name
            }
    
    async def cleanup_all_assistants(self):
        """ניקוי כל העוזרים"""
        try:
            for assistant in self.active_assistants.values():
                await assistant.cleanup()
            
            logger.info("כל העוזרים האישיים נוקו בהצלחה")
            
        except Exception as e:
            logger.error(f"שגיאה בניקוי עוזרים: {e}")

# API Functions for easy access
_module_instance: Optional[PersonalAIAssistantModule] = None

async def get_module() -> PersonalAIAssistantModule:
    """קבלת מופע המודול"""
    global _module_instance
    if _module_instance is None:
        _module_instance = PersonalAIAssistantModule()
        await _module_instance.initialize()
    return _module_instance

async def quick_chat(message: str) -> str:
    """שיחה מהירה"""
    module = await get_module()
    return await module.quick_chat(message)

async def create_my_assistant(name: str, personality: str = "friendly") -> str:
    """יצירת עוזר אישי"""
    module = await get_module()
    return await module.create_assistant(name, personality)

async def chat_with_my_assistant(assistant_name: str, message: str) -> str:
    """שיחה עם העוזר שלי"""
    module = await get_module()
    result = await module.chat_with_assistant(assistant_name, message)
    return result.get("response", "שגיאה בתגובה")

async def my_assistant_generate_code(language: str, task: str, assistant_name: str = "אפי") -> str:
    """יצירת קוד עם העוזר שלי"""
    module = await get_module()
    result = await module.generate_code(language, task, "", assistant_name)
    return result.get("assistant_response", result.get("response", "שגיאה ביצירת קוד"))

# Export everything
__all__ = [
    'PersonalAIAssistantModule',
    'get_module',
    'quick_chat',
    'create_my_assistant', 
    'chat_with_my_assistant',
    'my_assistant_generate_code'
]