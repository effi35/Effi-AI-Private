#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Personal AI Assistant - Usage Examples
דוגמאות שימוש בעוזר האישי החכם

הדגמות של איך להשתמש במודול העוזר האישי עם המודל המקומי Hudson/Llama3.1
"""

import asyncio
import json
from datetime import datetime

# ייבוא המודול
from personal_ai_assistant import (
    quick_chat,
    create_my_assistant,
    chat_with_my_assistant,
    my_assistant_generate_code,
    get_module,
    PersonalAIAssistantModule
)

async def example_1_quick_chat():
    """דוגמה 1: שיחה מהירה"""
    print("🚀 דוגמה 1: שיחה מהירה עם העוזר")
    print("=" * 50)
    
    # שיחה מהירה פשוטה
    response = await quick_chat("היי! איך אתה היום?")
    print(f"עוזר: {response}")
    print()
    
    # שאלה טכנית
    response = await quick_chat("אני רוצה ללמוד Python, איך להתחיל?")
    print(f"עוזר: {response}")
    print()

async def example_2_create_personal_assistant():
    """דוגמה 2: יצירת עוזר אישי"""
    print("🤖 דוגמה 2: יצירת עוזר אישי")
    print("=" * 50)
    
    # יצירת עוזר עם אישיות ידידותית
    result = await create_my_assistant("דני", "friendly")
    print(f"תוצאה: {result}")
    
    # שיחה עם העוזר החדש
    response = await chat_with_my_assistant("דני", "תכיר את עצמך!")
    print(f"דני: {response}")
    print()
    
    # יצירת עוזר חבר חכם
    result = await create_my_assistant("חכם", "smart_friend")
    print(f"תוצאה: {result}")
    
    response = await chat_with_my_assistant("חכם", "בואי נפתור בעיה מעניינת יחד!")
    print(f"חכם: {response}")
    print()

async def example_3_code_generation():
    """דוגמה 3: יצירת קוד עם אישיות"""
    print("💻 דוגמה 3: יצירת קוד עם העוזר")
    print("=" * 50)
    
    # יצירת קוד Python
    code = await my_assistant_generate_code(
        "python", 
        "צור משחק ניחוש מספר פשוט",
        "אפי"
    )
    print("קוד Python שנוצר:")
    print(code)
    print()
    
    # יצירת קוד JavaScript
    code = await my_assistant_generate_code(
        "javascript",
        "צור פונקציה שבודקת אם מספר הוא ראשוני",
        "חכם"
    )
    print("קוד JavaScript שנוצר:")
    print(code)
    print()

async def example_4_advanced_conversation():
    """דוגמה 4: שיחה מתקדמת עם העוזר"""
    print("💬 דוגמה 4: שיחה מתקדמת")
    print("=" * 50)
    
    # קבלת המודול
    module = await get_module()
    
    # עדכון פרופיל משתמש
    profile_data = {
        "שם": "יוסי",
        "עיסוק": "מתכנת",
        "תחומי עניין": ["Python", "בינה מלאכותית", "משחקים"],
        "רמה": "מתחיל-בינוני"
    }
    
    result = module.update_assistant_profile("אפי", profile_data)
    print(f"עדכון פרופיל: {result}")
    
    # שיחה עם הקשר אישי
    response = await module.chat_with_assistant(
        "אפי",
        "אני רוצה ליצור משחק פשוט בPython, מה אתה מציע?",
        context="פיתוח משחק",
        mood_hint="excited"
    )
    print(f"אפי: {response['response']}")
    print(f"מצב רוח של העוזר: {response['mood']}")
    print()

async def example_5_text_analysis():
    """דוגמה 5: ניתוח טקסט"""
    print("📊 דוגמה 5: ניתוח טקסט עם העוזר")
    print("=" * 50)
    
    module = await get_module()
    
    text_to_analyze = """
    היום היה יום מדהים! סיימתי את הפרויקט שלי בעבודה והמנהל שלי היה ממש מרוצה.
    אני מרגיש גאה בעצמי ומתרגש לגבי הפרויקט הבא. זה מראה שכל העבודה הקשה שלי משתלמת.
    """
    
    # ניתוח סנטימנט
    result = await module.analyze_text(text_to_analyze, "sentiment", "אפי")
    print("ניתוח סנטימנט:")
    print(result.get("assistant_analysis", result.get("analysis", "")))
    print()
    
    # סיכום טקסט
    result = await module.analyze_text(text_to_analyze, "summary", "אפי")
    print("סיכום הטקסט:")
    print(result.get("assistant_analysis", result.get("analysis", "")))
    print()

async def example_6_assistant_info():
    """דוגמה 6: מידע על העוזרים"""
    print("📋 דוגמה 6: מידע על העוזרים")
    print("=" * 50)
    
    module = await get_module()
    
    # מידע על כל העוזרים
    info = module.get_assistant_info()
    print("מידע על כל העוזרים:")
    print(json.dumps(info, ensure_ascii=False, indent=2))
    print()
    
    # מידע על עוזר ספציפי
    info = module.get_assistant_info("אפי")
    print("מידע על אפי:")
    print(json.dumps(info, ensure_ascii=False, indent=2))
    print()

async def example_7_conversation_export():
    """דוגמה 7: ייצוא שיחה"""
    print("💾 דוגמה 7: ייצוא שיחה")
    print("=" * 50)
    
    module = await get_module()
    
    # ייצוא השיחה עם אפי
    conversation = module.export_conversation("אפי")
    print("השיחה המיוצאת:")
    print(conversation[:500] + "..." if len(conversation) > 500 else conversation)
    print()

async def example_8_personality_types():
    """דוגמה 8: סוגי אישיות"""
    print("🎭 דוגמה 8: סוגי אישיות זמינים")
    print("=" * 50)
    
    module = await get_module()
    
    personalities = module.get_available_personalities()
    print("סוגי אישיות זמינים:")
    for personality, description in personalities.items():
        print(f"- {personality}: {description}")
    print()
    
    tips = module.get_conversation_tips()
    print("טיפים לשיחה עם העוזר:")
    for i, tip in enumerate(tips, 1):
        print(f"{i}. {tip}")
    print()

async def example_9_test_connection():
    """דוגמה 9: בדיקת חיבור"""
    print("🔍 דוגמה 9: בדיקת חיבור העוזר")
    print("=" * 50)
    
    module = await get_module()
    
    # בדיקת חיבור עם אפי
    test_result = await module.test_assistant_connection("אפי")
    print("תוצאת בדיקת החיבור:")
    print(json.dumps(test_result, ensure_ascii=False, indent=2))
    print()

async def interactive_demo():
    """הדגמה אינטראקטיבית"""
    print("🎪 הדגמה אינטראקטיבית עם העוזר האישי")
    print("=" * 60)
    print("כתוב 'יציאה' כדי לסיים")
    print()
    
    while True:
        try:
            user_input = input("אתה: ").strip()
            if user_input.lower() in ['יציאה', 'exit', 'quit']:
                print("להתראות! 👋")
                break
            
            if not user_input:
                continue
                
            response = await quick_chat(user_input)
            print(f"אפי: {response}")
            print()
            
        except KeyboardInterrupt:
            print("\nלהתראות! 👋")
            break
        except Exception as e:
            print(f"שגיאה: {e}")

async def main():
    """הפעלת כל הדוגמאות"""
    print("🎉 דוגמאות שימוש בעוזר האישי החכם")
    print("=" * 60)
    print("מופעל על המודל המקומי Hudson/Llama3.1-uncensored")
    print("פרטיות מלאה - ללא חיבורים חיצוניים!")
    print("=" * 60)
    print()
    
    try:
        # הרצת כל הדוגמאות
        await example_1_quick_chat()
        await example_2_create_personal_assistant()
        await example_3_code_generation()
        await example_4_advanced_conversation()
        await example_5_text_analysis()
        await example_6_assistant_info()
        await example_7_conversation_export()
        await example_8_personality_types()
        await example_9_test_connection()
        
        print("🎉 כל הדוגמאות הושלמו בהצלחה!")
        print()
        
        # שאלה האם להריץ הדגמה אינטראקטיבית
        response = input("האם תרצה להריץ הדגמה אינטראקטיבית? (כן/לא): ").strip()
        if response.lower() in ['כן', 'yes', 'y', 'ו']:
            await interactive_demo()
            
    except Exception as e:
        print(f"שגיאה כללית: {e}")
    
    finally:
        # ניקוי עוזרים
        module = await get_module()
        await module.cleanup_all_assistants()
        print("ניקוי המערכת הושלם.")

if __name__ == "__main__":
    # הרצת הדוגמאות
    asyncio.run(main())