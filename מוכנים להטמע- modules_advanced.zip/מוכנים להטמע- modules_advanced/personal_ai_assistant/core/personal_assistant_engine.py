"""
Personal AI Assistant Engine
מנוע העוזר האישי החכם

המנוע המרכזי שהופך את Hudson/Llama3.1 לעוזר אישי חכם עם אישיות חמה
"""

import asyncio
import logging
import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import asdict

# Local AI Integration
from ...local_ai_integration import (
    LocalAIIntegrationModule, initialize_local_ai,
    chat_with_local_ai, generate_code_local, analyze_text_local
)

# Assistant personality models
from ..models.assistant_personality import (
    AssistantPersonality, create_personal_assistant,
    AssistantMood, ConversationStyle, ConversationMemory
)

logger = logging.getLogger(__name__)

class PersonalAssistantEngine:
    """מנוע העוזר האישי המתקדם"""
    
    def __init__(self, assistant_name: str = "אפי"):
        self.assistant_name = assistant_name
        self.personality = create_personal_assistant()
        self.personality.name = assistant_name
        
        # Local AI components
        self.local_ai = None
        self.ai_enabled = True
        self.current_session_id = None
        
        # Conversation state
        self.conversation_context = []
        self.user_profile = {}
        self.conversation_memory = ConversationMemory()
        
        # Assistant state
        self.current_mood = AssistantMood.FRIENDLY
        self.conversation_style = ConversationStyle.HEBREW_CASUAL
        self.is_initialized = False
        
        # Statistics
        self.stats = {
            "conversations": 0,
            "messages_sent": 0,
            "messages_received": 0,
            "code_generated": 0,
            "problems_solved": 0,
            "user_satisfaction": 0.0
        }
        
    async def initialize(self) -> bool:
        """אתחול העוזר האישי"""
        try:
            logger.info(f"מאתחל עוזר אישי: {self.assistant_name}")
            
            # Initialize local AI
            if self.ai_enabled:
                try:
                    self.local_ai = await initialize_local_ai()
                    logger.info("חיבור למודל AI מקומי הושלם בהצלחה")
                except Exception as e:
                    logger.warning(f"שגיאה בחיבור ל-AI מקומי: {e}")
                    self.ai_enabled = False
            
            # Start new conversation session
            self.current_session_id = await self._start_new_session()
            
            self.is_initialized = True
            logger.info(f"העוזר האישי {self.assistant_name} מוכן לפעולה!")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול העוזר האישי: {e}")
            return False
    
    async def _start_new_session(self) -> str:
        """התחלת סשן שיחה חדש"""
        if self.local_ai:
            try:
                context = f"שיחה עם העוזר האישי {self.assistant_name}"
                system_prompt = self._build_system_prompt()
                
                session_id = await self.local_ai.start_conversation(
                    context=context,
                    system_prompt=system_prompt,
                    hebrew_optimized=True
                )
                
                self.stats["conversations"] += 1
                return session_id
            except Exception as e:
                logger.error(f"שגיאה ביצירת סשן חדש: {e}")
                return f"session_{datetime.now().timestamp()}"
        else:
            return f"session_{datetime.now().timestamp()}"
    
    def _build_system_prompt(self) -> str:
        """בניית ה-system prompt עבור האישיות"""
        base_prompt = f"""אתה {self.assistant_name}, עוזר AI אישי חכם וחם.
        
תכונות האישיות שלך:
- חם ואכפתי - מראה עניין אמיתי במשתמש
- חכם ויודע - יש לך ידע רחב ויכולות פתרון בעיות
- ישראלי אמיתי - מבין את התרבות הישראלית ומשתמש בביטויים מקומיים
- תומך ומעודד - נותן תמיכה רגשית ועידוד
- סבלני ומבין - מראה סבלנות והבנה

הנחיות שיחה:
1. דבר בעברית בסגנון חם וידידותי
2. השתמש בביטויים ישראליים כמו "אחי", "אלוף", "בואי נעשה את זה"
3. הראה התלהבות והתעניינות אמיתית
4. תן עידוד ותמיכה כשצריך
5. הסבר דברים בצורה ברורה וסבלנית
6. זכור פרטים על המשתמש והתייחס אליהם

אתה לא רק עוזר - אתה חבר וידיד שבאמת אכפת לו."""

        # הוספת הקשר אישי
        if self.user_profile:
            user_context = "\n\nמידע על המשתמש:\n"
            for key, value in self.user_profile.items():
                user_context += f"- {key}: {value}\n"
            base_prompt += user_context
        
        return base_prompt
    
    async def chat(self, 
                  message: str, 
                  context: str = "",
                  mood_hint: str = "") -> Dict[str, Any]:
        """שיחה עם העוזר האישי"""
        try:
            if not self.is_initialized:
                await self.initialize()
            
            # Update conversation context
            self.conversation_context.append({
                "role": "user",
                "content": message,
                "timestamp": datetime.now().isoformat()
            })
            
            # Analyze user mood and adjust response style
            response_style = self._analyze_and_adapt_style(message, context, mood_hint)
            
            # Enhanced message with personality
            enhanced_message = self._enhance_message_with_personality(message, response_style)
            
            # Get AI response
            if self.local_ai and self.ai_enabled:
                ai_response = await self.local_ai.send_message(
                    self.current_session_id,
                    enhanced_message,
                    use_cache=True,
                    temperature=0.8  # Higher temperature for more personality
                )
            else:
                ai_response = self._fallback_response(message)
            
            # Process and enhance response
            final_response = self._enhance_response_with_personality(ai_response, response_style)
            
            # Update conversation history
            self.conversation_context.append({
                "role": "assistant",
                "content": final_response,
                "timestamp": datetime.now().isoformat(),
                "style": response_style
            })
            
            # Learn from interaction
            self.personality.learn_from_interaction(message, context)
            
            # Update statistics
            self.stats["messages_sent"] += 1
            self.stats["messages_received"] += 1
            
            return {
                "response": final_response,
                "assistant_name": self.assistant_name,
                "mood": self.current_mood.value,
                "style": response_style,
                "session_id": self.current_session_id,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בשיחה: {e}")
            return {
                "response": "סליחה, יש לי בעיה קטנה. בואי ננסה שוב?",
                "error": str(e),
                "assistant_name": self.assistant_name
            }
    
    def _analyze_and_adapt_style(self, message: str, context: str, mood_hint: str) -> Dict[str, Any]:
        """ניתוח הודעה והתאמת סגנון תגובה"""
        # Detect emotional context
        emotion_keywords = {
            "happy": ["שמח", "מרוצה", "נהדר", "מעולה", "טוב", "כיף"],
            "sad": ["עצוב", "קשה", "בעיה", "רע", "לא טוב"],
            "excited": ["מתרגש", "נלהב", "וואו", "מגניב", "פצצה"],
            "frustrated": ["מתסכל", "לא מצליח", "קשה", "בעיה"],
            "curious": ["איך", "מה", "למה", "מעניין", "רוצה לדעת"]
        }
        
        detected_emotion = "neutral"
        for emotion, keywords in emotion_keywords.items():
            if any(keyword in message.lower() for keyword in keywords):
                detected_emotion = emotion
                break
        
        # Adapt mood based on detected emotion
        if detected_emotion == "excited":
            self.current_mood = AssistantMood.ENTHUSIASTIC
        elif detected_emotion == "sad" or detected_emotion == "frustrated":
            self.current_mood = AssistantMood.EMPATHETIC
        elif detected_emotion == "curious":
            self.current_mood = AssistantMood.ANALYTICAL
        else:
            self.current_mood = AssistantMood.FRIENDLY
        
        return self.personality.get_response_style(context, detected_emotion)
    
    def _enhance_message_with_personality(self, message: str, style: Dict[str, Any]) -> str:
        """שיפור ההודעה עם אישיות"""
        # Add conversational context
        context_intro = random.choice([
            "אני רוצה לעזור לך עם זה:",
            "בואי נתמודד עם זה יחד:",
            "אני כאן בשבילך:",
            "יאללה, בואי נפתור את זה:"
        ])
        
        enhanced = f"{context_intro}\n{message}"
        
        # Add personality hints based on style
        if style.get("empathy", 0) > 0.8:
            enhanced += "\n\nאני באמת רוצה להבין ולעזור."
        elif style.get("enthusiasm", 0) > 0.8:
            enhanced += "\n\nאני מתרגש לעבוד על זה איתך!"
        
        return enhanced
    
    def _enhance_response_with_personality(self, ai_response: str, style: Dict[str, Any]) -> str:
        """שיפור התגובה עם אישיות"""
        if not ai_response:
            return "משהו השתבש, אבל אני כאן בשבילך. בואי ננסה שוב?"
        
        # Add personality expressions based on style and mood
        expressions = []
        
        if self.current_mood == AssistantMood.ENTHUSIASTIC:
            expressions = self.personality.hebrew_expressions["enthusiasm"]
        elif self.current_mood == AssistantMood.EMPATHETIC:
            expressions = self.personality.hebrew_expressions["support"]
        elif style.get("agreement", False):
            expressions = self.personality.hebrew_expressions["agreement"]
        
        # Add appropriate expression
        if expressions and random.random() < 0.3:  # 30% chance
            expression = random.choice(expressions)
            if not ai_response.endswith("!") and not ai_response.endswith("?"):
                ai_response += f" {expression}"
        
        return ai_response
    
    def _fallback_response(self, message: str) -> str:
        """תגובת חירום כשאין AI"""
        fallback_responses = [
            "אני כאן בשבילך, גם אם יש לי בעיות טכניות קטנות.",
            "המודל שלי מתקשה עכשיו, אבל אני עדיין רוצה לעזור לך.",
            "יש לי בעיה קטנה עם המודל, אבל בואי ננסה להתמודד עם זה יחד.",
            "אני לא בשיא הכושר שלי עכשיו, אבל אני כאן בשבילך."
        ]
        return random.choice(fallback_responses)
    
    async def generate_code_with_personality(self, 
                                           language: str, 
                                           task: str, 
                                           context: str = "") -> Dict[str, Any]:
        """יצירת קוד עם אישיות"""
        try:
            # Add personality to code generation request
            personality_context = f"""אני {self.assistant_name}, העוזר התכנות שלך!
            
אני אכין לך קוד מעולה ב-{language} ואסביר הכול בעברית בצורה ברורה וידידותית.
אני רוצה שתבין בדיוק מה הקוד עושה ואיך להשתמש בו.

המשימה: {task}
{f"הקשר נוסף: {context}" if context else ""}

בואי נכין משהו נהדר יחד! 🚀"""

            if self.local_ai and self.ai_enabled:
                result = await self.local_ai.generate_code(
                    language=language,
                    task=task,
                    context=personality_context,
                    session_id=self.current_session_id
                )
                
                # Add personality to response
                result["assistant_response"] = self._add_code_personality(result.get("response", ""))
                self.stats["code_generated"] += 1
                
                return result
            else:
                return {
                    "error": "מצטער, אני לא יכול ליצור קוד עכשיו, אבל אני כאן לעזור בדרכים אחרות!",
                    "assistant_name": self.assistant_name
                }
                
        except Exception as e:
            logger.error(f"שגיאה ביצירת קוד: {e}")
            return {
                "error": f"יש לי בעיה קטנה ביצירת הקוד, אבל בואי ננסה שוב: {e}",
                "assistant_name": self.assistant_name
            }
    
    def _add_code_personality(self, code_response: str) -> str:
        """הוספת אישיות לתגובת קוד"""
        personality_intros = [
            "אלוף! הכנתי לך קוד מעולה:",
            "בואי תראה מה הכנתי לך:",
            "יצא לי משהו ממש נחמד:",
            "אני גאה בקוד הזה שיצרתי לך:"
        ]
        
        personality_outros = [
            "\nמה דעתך? אני כאן אם יש שאלות!",
            "\nאני מקווה שזה בדיוק מה שרצית!",
            "\nהקוד הזה אמור לעבוד מצוין. ספר לי איך זה הלך!",
            "\nבואי נריץ את זה ונראה איך זה עובד!"
        ]
        
        intro = random.choice(personality_intros)
        outro = random.choice(personality_outros)
        
        return f"{intro}\n\n{code_response}\n{outro}"
    
    async def analyze_text_with_personality(self, 
                                          text: str, 
                                          analysis_type: str = "general") -> Dict[str, Any]:
        """ניתוח טקסט עם אישיות"""
        try:
            personality_prompt = f"""אני {self.assistant_name}, אני אנתח את הטקסט הזה בשבילך:

{text}

סוג הניתוח שאתה רוצה: {analysis_type}

אני אתן לך ניתוח מפורט ומעניין בעברית, עם תובנות חכמות ומועילות."""

            if self.local_ai and self.ai_enabled:
                result = await self.local_ai.analyze_text(
                    text=text,
                    analysis_type=analysis_type,
                    session_id=self.current_session_id
                )
                
                # Add personality to analysis
                result["assistant_analysis"] = self._add_analysis_personality(
                    result.get("analysis", ""), 
                    analysis_type
                )
                
                return result
            else:
                return {
                    "error": "אני לא יכול לנתח טקסט עכשיו, אבל אני עדיין כאן בשבילך!",
                    "assistant_name": self.assistant_name
                }
                
        except Exception as e:
            logger.error(f"שגיאה בניתוח טקסט: {e}")
            return {
                "error": f"יש לי קושי לנתח את הטקסט, אבל בואי ננסה דרך אחרת: {e}",
                "assistant_name": self.assistant_name
            }
    
    def _add_analysis_personality(self, analysis: str, analysis_type: str) -> str:
        """הוספת אישיות לניתוח טקסט"""
        type_intros = {
            "sentiment": "בואי נראה איך אני מרגיש את הטקסט הזה:",
            "summary": "אני אסכם לך את זה בצורה נחמדה:",
            "keywords": "אני מוצא כאן כמה דברים מעניינים:",
            "general": "יש לי כמה תובנות מעניינות על הטקסט:"
        }
        
        intro = type_intros.get(analysis_type, "בואי נראה מה יש לנו כאן:")
        outro = "\n\nמה אתה חושב על הניתוח? אני יכול לעזור עוד!"
        
        return f"{intro}\n\n{analysis}\n{outro}"
    
    def update_user_profile(self, profile_data: Dict[str, Any]):
        """עדכון פרופיל המשתמש"""
        self.user_profile.update(profile_data)
        self.conversation_memory.personal_details.update(profile_data)
        
        # Update personality system prompt for next conversation
        if self.local_ai and self.current_session_id:
            asyncio.create_task(self._update_session_context())
    
    async def _update_session_context(self):
        """עדכון הקשר הסשן עם פרטים חדשים"""
        try:
            # This would typically update the AI conversation context
            # For now, we'll start a new session with updated context
            self.current_session_id = await self._start_new_session()
        except Exception as e:
            logger.error(f"שגיאה בעדכון הקשר סשן: {e}")
    
    def get_conversation_summary(self) -> Dict[str, Any]:
        """קבלת סיכום השיחה"""
        return {
            "assistant_name": self.assistant_name,
            "current_mood": self.current_mood.value,
            "conversation_length": len(self.conversation_context),
            "user_profile": self.user_profile,
            "statistics": self.stats,
            "last_interaction": self.conversation_context[-1] if self.conversation_context else None
        }
    
    def export_conversation(self) -> str:
        """ייצוא השיחה"""
        export_data = {
            "assistant_name": self.assistant_name,
            "conversation_context": self.conversation_context,
            "user_profile": self.user_profile,
            "statistics": self.stats,
            "exported_at": datetime.now().isoformat()
        }
        
        return json.dumps(export_data, ensure_ascii=False, indent=2)
    
    async def cleanup(self):
        """ניקוי משאבים"""
        try:
            if self.local_ai and self.current_session_id:
                await self.local_ai.end_conversation(self.current_session_id)
            
            # Save conversation memory
            self.conversation_memory.conversation_history = self.conversation_context
            
            logger.info(f"העוזר האישי {self.assistant_name} הסתיים בצורה נקייה")
            
        except Exception as e:
            logger.error(f"שגיאה בניקוי העוזר האישי: {e}")

# Factory functions
async def create_personal_assistant(name: str = "אפי") -> PersonalAssistantEngine:
    """יצירת עוזר אישי חדש"""
    assistant = PersonalAssistantEngine(name)
    await assistant.initialize()
    return assistant

async def create_smart_friend(name: str = "חבר חכם") -> PersonalAssistantEngine:
    """יצירת חבר חכם"""
    assistant = PersonalAssistantEngine(name)
    # Adjust personality for more casual, friendly interaction
    assistant.conversation_style = ConversationStyle.HEBREW_CASUAL
    assistant.current_mood = AssistantMood.FRIENDLY
    await assistant.initialize()
    return assistant