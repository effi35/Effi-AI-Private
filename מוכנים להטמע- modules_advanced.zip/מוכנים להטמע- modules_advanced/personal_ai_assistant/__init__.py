"""
Personal AI Assistant Module
מודול העוזר האישי החכם

הופך את המודל המקומי Hudson/Llama3.1 לעוזר אישי חכם עם אישיות חמה
בדיוק כמו Claude אבל פרטי ומקומי לחלוטין!

היכולות של העוזר:
- שיחה חמה ואכפתית בעברית
- אישיות ישראלית אמיתית 
- זיכרון אישי ולמידה מתמשכת
- יצירת קוד מתקדמת עם הסברים
- ניתוח טקסט חכם
- תמיכה רגשית ועידוד
- פרטיות מלאה - הכול מקומי!
"""

from .module import (
    PersonalAIAssistantModule,
    get_module,
    quick_chat,
    create_my_assistant,
    chat_with_my_assistant,
    my_assistant_generate_code
)

from .core.personal_assistant_engine import (
    PersonalAssistantEngine,
    create_personal_assistant,
    create_smart_friend
)

from .models.assistant_personality import (
    AssistantPersonality,
    AssistantMood,
    ConversationStyle,
    PersonalityTrait,
    EmotionalResponse,
    ConversationMemory,
    create_personal_assistant as create_personality,
    create_custom_personality
)

__version__ = "1.0.0"
__author__ = "Effi AI Private System"
__description__ = "עוזר AI אישי חכם עם אישיות חמה ופרטיות מלאה"

# Quick start guide
QUICK_START_GUIDE = """
🎉 מדריך מהיר לעוזר האישי החכם שלך!

1. שיחה מהירה:
   from personal_ai_assistant import quick_chat
   response = await quick_chat("היי! איך אתה?")

2. יצירת עוזר אישי:
   from personal_ai_assistant import create_my_assistant
   result = await create_my_assistant("שלי", "friendly")

3. שיחה עם העוזר:
   from personal_ai_assistant import chat_with_my_assistant  
   response = await chat_with_my_assistant("שלי", "עזור לי עם קוד Python")

4. יצירת קוד:
   from personal_ai_assistant import my_assistant_generate_code
   code = await my_assistant_generate_code("python", "צור משחק נחש פשוט")

העוזר שלך:
✅ מדבר עברית טבעית
✅ זוכר פרטים אישיים
✅ מבין רגשות ומתאים טון
✅ יוצר קוד מעולה 
✅ נותן תמיכה רגשית
✅ פרטי לחלוטין - ללא חיבורים חיצוניים!
"""

# רכיבי המודול הזמינים לייבוא
__all__ = [
    # מודול ראשי
    'PersonalAIAssistantModule',
    'get_module',
    
    # פונקציות מהירות
    'quick_chat',
    'create_my_assistant',
    'chat_with_my_assistant', 
    'my_assistant_generate_code',
    
    # מנוע העוזר
    'PersonalAssistantEngine',
    'create_personal_assistant',
    'create_smart_friend',
    
    # מודלי אישיות
    'AssistantPersonality',
    'AssistantMood',
    'ConversationStyle',
    'PersonalityTrait',
    'EmotionalResponse',
    'ConversationMemory',
    'create_personality',
    'create_custom_personality',
    
    # מדריכים
    'QUICK_START_GUIDE'
]