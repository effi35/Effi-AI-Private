"""
Decision Criteria and Weights
קריטריונים ומשקלים להחלטות
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Union
from enum import Enum
import json

class CriteriaType(Enum):
    """סוגי קריטריונים"""
    QUANTITATIVE = "quantitative"    # כמותי
    QUALITATIVE = "qualitative"      # איכותי
    BINARY = "binary"                # בינארי
    RANKING = "ranking"              # דירוג
    WEIGHTED = "weighted"            # משוקלל

class CriteriaImportance(Enum):
    """חשיבות קריטריונים"""
    CRITICAL = 5    # קריטי
    HIGH = 4        # גבוה
    MEDIUM = 3      # בינוני
    LOW = 2         # נמוך
    OPTIONAL = 1    # אופציונלי

@dataclass
class CriteriaWeight:
    """משקל קריטריון"""
    weight: float           # משקל (0.0-1.0)
    importance: CriteriaImportance
    justification: str      # הצדקה למשקל
    hebrew_justification: str
    confidence: float = 1.0  # רמת ביטחון (0.0-1.0)
    
    def __post_init__(self):
        """ולידציה של משקל"""
        self.weight = max(0.0, min(1.0, self.weight))
        self.confidence = max(0.0, min(1.0, self.confidence))

@dataclass
class DecisionCriteria:
    """קריטריון להחלטה"""
    id: str
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    criteria_type: CriteriaType
    weight: CriteriaWeight
    measurement_unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    target_value: Optional[float] = None
    acceptable_range: Optional[tuple] = None
    sub_criteria: List['DecisionCriteria'] = None
    
    def __post_init__(self):
        if self.sub_criteria is None:
            self.sub_criteria = []

@dataclass
class CriteriaEvaluation:
    """הערכת קריטריון"""
    criteria_id: str
    value: Union[float, str, bool]
    score: float           # ניקוד נורמלי (0.0-1.0)
    confidence: float      # רמת ביטחון
    source: str           # מקור הנתונים
    timestamp: str        # זמן ההערכה
    notes: str = ""       # הערות
    hebrew_notes: str = ""

class CriteriaValidator:
    """מאמת קריטריונים"""
    
    @staticmethod
    def validate_criteria(criteria: DecisionCriteria) -> Dict[str, bool]:
        """מאמת תקינות קריטריון"""
        validations = {
            'has_valid_weight': 0.0 <= criteria.weight.weight <= 1.0,
            'has_name': bool(criteria.name and criteria.hebrew_name),
            'has_description': bool(criteria.description),
            'has_valid_range': True
        }
        
        # בדיקת טווח תקין
        if criteria.min_value is not None and criteria.max_value is not None:
            validations['has_valid_range'] = criteria.min_value <= criteria.max_value
            
        return validations
    
    @staticmethod
    def normalize_weights(criteria_list: List[DecisionCriteria]) -> None:
        """מנרמל משקלים שסכומם יהיה 1.0"""
        total_weight = sum(c.weight.weight for c in criteria_list)
        if total_weight > 0:
            for criteria in criteria_list:
                criteria.weight.weight = criteria.weight.weight / total_weight

@dataclass
class CriteriaTemplate:
    """תבנית קריטריונים מוכנה"""
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    criteria_list: List[DecisionCriteria]
    use_cases: List[str]
    
    @classmethod
    def get_business_template(cls) -> 'CriteriaTemplate':
        """תבנית קריטריונים עסקיים"""
        criteria = [
            DecisionCriteria(
                id="cost",
                name="Cost",
                hebrew_name="עלות",
                description="Financial cost of the decision",
                hebrew_description="עלות כספית של ההחלטה",
                criteria_type=CriteriaType.QUANTITATIVE,
                weight=CriteriaWeight(0.3, CriteriaImportance.HIGH, "Major budget impact", "השפעה תקציבית משמעותית"),
                measurement_unit="ILS"
            ),
            DecisionCriteria(
                id="risk",
                name="Risk Level",
                hebrew_name="רמת סיכון",
                description="Associated risks with the decision",
                hebrew_description="סיכונים הקשורים להחלטה",
                criteria_type=CriteriaType.QUALITATIVE,
                weight=CriteriaWeight(0.25, CriteriaImportance.CRITICAL, "Risk mitigation essential", "הפחתת סיכונים חיונית"),
                min_value=1.0,
                max_value=5.0
            ),
            DecisionCriteria(
                id="timeline",
                name="Implementation Timeline",
                hebrew_name="לוח זמנים ליישום",
                description="Time required for implementation",
                hebrew_description="זמן נדרש ליישום",
                criteria_type=CriteriaType.QUANTITATIVE,
                weight=CriteriaWeight(0.2, CriteriaImportance.MEDIUM, "Time-to-market matters", "זמן להשקה חשוב"),
                measurement_unit="days"
            ),
            DecisionCriteria(
                id="strategic_fit",
                name="Strategic Alignment",
                hebrew_name="התאמה אסטרטגית",
                description="Alignment with organizational strategy",
                hebrew_description="התאמה לאסטרטגיה הארגונית",
                criteria_type=CriteriaType.QUALITATIVE,
                weight=CriteriaWeight(0.25, CriteriaImportance.HIGH, "Must align with goals", "חייב להתיישר עם המטרות"),
                min_value=1.0,
                max_value=5.0
            )
        ]
        
        return cls(
            name="Business Decision Template",
            hebrew_name="תבנית החלטות עסקיות",
            description="Standard criteria for business decisions",
            hebrew_description="קריטריונים סטנדרטיים להחלטות עסקיות",
            criteria_list=criteria,
            use_cases=["עסקי", "אסטרטגי", "השקעות", "פרויקטים"]
        )