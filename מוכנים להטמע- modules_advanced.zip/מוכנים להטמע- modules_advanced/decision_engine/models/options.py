"""
Decision Options and Evaluations
אפשרויות החלטה והערכות
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime
import uuid

class OptionStatus(Enum):
    """סטטוס אפשרות"""
    ACTIVE = "active"             # פעיל
    INACTIVE = "inactive"         # לא פעיל
    ELIMINATED = "eliminated"     # נפסל
    PREFERRED = "preferred"       # מועדף
    BACKUP = "backup"             # גיבוי

class OptionSource(Enum):
    """מקור האפשרות"""
    MANUAL = "manual"             # הוזן ידנית
    GENERATED = "generated"       # נוצר אוטומטית
    IMPORTED = "imported"         # יובא ממקור חיצוני
    HISTORICAL = "historical"     # מבוסס על נתונים היסטוריים
    AI_SUGGESTED = "ai_suggested" # הוצע על ידי AI

@dataclass
class OptionMetrics:
    """מדדי ביצועים לאפשרות"""
    probability_success: float    # הסתברות הצלחה (0.0-1.0)
    expected_value: float         # ערך צפוי
    confidence_level: float       # רמת ביטחון (0.0-1.0)
    complexity_score: float       # ניקוד מורכבות (1.0-5.0)
    implementation_effort: float  # מאמץ יישום (1.0-5.0)
    risk_score: float            # ניקוד סיכון (0.0-1.0)
    
    def __post_init__(self):
        """ולידציה של מדדים"""
        self.probability_success = max(0.0, min(1.0, self.probability_success))
        self.confidence_level = max(0.0, min(1.0, self.confidence_level))
        self.complexity_score = max(1.0, min(5.0, self.complexity_score))
        self.implementation_effort = max(1.0, min(5.0, self.implementation_effort))
        self.risk_score = max(0.0, min(1.0, self.risk_score))

@dataclass
class DecisionOption:
    """אפשרות החלטה"""
    id: str
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    status: OptionStatus
    source: OptionSource
    metrics: OptionMetrics
    created_at: datetime
    costs: Dict[str, float] = None          # עלויות לפי סוג
    benefits: Dict[str, float] = None       # יתרונות לפי סוג
    resources_required: Dict[str, Any] = None # משאבים נדרשים
    dependencies: List[str] = None          # תלויות באפשרויות אחרות
    constraints: List[str] = None           # אילוצים ספציפיים
    assumptions: List[str] = None           # הנחות
    risks: List[str] = None                # סיכונים
    mitigation_plans: List[str] = None     # תוכניות הפחתת סיכונים
    notes: str = ""
    hebrew_notes: str = ""
    
    def __post_init__(self):
        if self.costs is None:
            self.costs = {}
        if self.benefits is None:
            self.benefits = {}
        if self.resources_required is None:
            self.resources_required = {}
        if self.dependencies is None:
            self.dependencies = []
        if self.constraints is None:
            self.constraints = []
        if self.assumptions is None:
            self.assumptions = []
        if self.risks is None:
            self.risks = []
        if self.mitigation_plans is None:
            self.mitigation_plans = []
    
    @classmethod
    def create_default(cls, name: str, hebrew_name: str) -> 'DecisionOption':
        """יוצר אפשרות החלטה ברירת מחדל"""
        return cls(
            id=str(uuid.uuid4()),
            name=name,
            hebrew_name=hebrew_name,
            description=f"Description for {name}",
            hebrew_description=f"תיאור עבור {hebrew_name}",
            status=OptionStatus.ACTIVE,
            source=OptionSource.MANUAL,
            metrics=OptionMetrics(
                probability_success=0.5,
                expected_value=0.0,
                confidence_level=0.5,
                complexity_score=3.0,
                implementation_effort=3.0,
                risk_score=0.5
            ),
            created_at=datetime.now()
        )

@dataclass
class CriteriaScore:
    """ניקוד קריטריון לאפשרות"""
    criteria_id: str
    raw_value: Any              # ערך גולמי
    normalized_score: float     # ניקוד מנורמל (0.0-1.0)
    weighted_score: float       # ניקוד משוקלל
    confidence: float           # רמת ביטחון
    justification: str          # הצדקה לניקוד
    hebrew_justification: str

@dataclass
class OptionEvaluation:
    """הערכת אפשרות החלטה"""
    option_id: str
    evaluation_id: str
    timestamp: datetime
    evaluator: str              # מי ביצע ההערכה
    criteria_scores: List[CriteriaScore]
    total_score: float          # ניקוד כולל משוקלל
    ranking: Optional[int] = None # דירוג יחסי
    recommendation: Optional[str] = None # המלצה
    hebrew_recommendation: Optional[str] = None
    confidence_level: float = 1.0
    notes: str = ""
    hebrew_notes: str = ""
    
    def calculate_total_score(self) -> float:
        """מחשב ניקוד כולל"""
        if not self.criteria_scores:
            return 0.0
        
        total = sum(score.weighted_score for score in self.criteria_scores)
        self.total_score = total
        return total
    
    def get_top_criteria(self, n: int = 3) -> List[CriteriaScore]:
        """מחזיר את הקריטריונים עם הניקוד הגבוה ביותר"""
        return sorted(self.criteria_scores, 
                     key=lambda x: x.weighted_score, 
                     reverse=True)[:n]

class OptionGenerator:
    """מחולל אפשרויות החלטה"""
    
    @staticmethod
    def generate_variations(base_option: DecisionOption, 
                          variations: List[str]) -> List[DecisionOption]:
        """מחולל וריאציות לאפשרות בסיסית"""
        generated_options = []
        
        for i, variation in enumerate(variations):
            new_option = DecisionOption.create_default(
                name=f"{base_option.name} - {variation}",
                hebrew_name=f"{base_option.hebrew_name} - {variation}"
            )
            new_option.source = OptionSource.GENERATED
            new_option.description = f"{base_option.description} with {variation}"
            new_option.hebrew_description = f"{base_option.hebrew_description} עם {variation}"
            
            # העתקת נתונים בסיסיים
            new_option.costs = base_option.costs.copy()
            new_option.benefits = base_option.benefits.copy()
            new_option.resources_required = base_option.resources_required.copy()
            
            generated_options.append(new_option)
        
        return generated_options
    
    @staticmethod
    def create_standard_options() -> List[DecisionOption]:
        """יוצר אפשרויות החלטה סטנדרטיות"""
        options = [
            DecisionOption.create_default("Do Nothing", "לא לעשות דבר"),
            DecisionOption.create_default("Minimal Action", "פעולה מינימלית"),
            DecisionOption.create_default("Standard Approach", "גישה סטנדרטית"),
            DecisionOption.create_default("Aggressive Action", "פעולה אגרסיבית"),
            DecisionOption.create_default("Wait and See", "חכה וראה")
        ]
        
        # התאמת מדדים לכל אפשרות
        options[0].metrics.risk_score = 0.1  # סיכון נמוך בחוסר פעולה
        options[0].metrics.expected_value = -0.2  # ערך צפוי שלילי
        
        options[1].metrics.complexity_score = 2.0  # פשוט יחסית
        options[1].metrics.implementation_effort = 2.0
        
        options[3].metrics.risk_score = 0.8  # סיכון גבוה בפעולה אגרסיבית
        options[3].metrics.expected_value = 0.8  # ערך צפוי גבוה
        
        return options