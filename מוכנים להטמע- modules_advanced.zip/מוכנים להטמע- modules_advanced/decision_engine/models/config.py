"""
Decision Engine Configuration
הגדרות מנוע קבלת החלטות
"""

from dataclasses import dataclass
from typing import Dict, List, Optional
import json

@dataclass
class DecisionEngineConfig:
    """הגדרות מנוע קבלת החלטות"""
    
    # הגדרות כלליות
    default_language: str = "he"
    enable_hebrew_support: bool = True
    decision_timeout: int = 3600  # timeout בשניות
    max_options: int = 20
    max_criteria: int = 15
    
    # אלגוריתמים
    scoring_algorithm: str = "weighted_sum"  # weighted_sum, topsis, ahp
    normalization_method: str = "min_max"   # min_max, z_score, robust
    aggregation_method: str = "weighted"    # weighted, geometric, harmonic
    
    # משקלים ברירת מחדל
    default_weights: Dict[str, float] = None
    
    # הגדרות מסד נתונים
    database_path: str = "decision_engine.db"
    backup_interval: int = 3600  # גיבוי כל שעה
    
    # הגדרות ביצועים
    enable_caching: bool = True
    cache_size: int = 1000
    enable_parallel_processing: bool = True
    max_workers: int = 4
    
    # הגדרות לוגים
    log_level: str = "INFO"
    log_decisions: bool = True
    log_evaluations: bool = True
    
    # הגדרות AI
    enable_ai_suggestions: bool = True
    ai_confidence_threshold: float = 0.7
    enable_learning: bool = True
    
    def __post_init__(self):
        if self.default_weights is None:
            self.default_weights = {
                "cost": 0.25,
                "risk": 0.25,
                "timeline": 0.2,
                "strategic_fit": 0.3
            }
    
    @classmethod
    def load_from_file(cls, file_path: str) -> 'DecisionEngineConfig':
        """טוען הגדרות מקובץ"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return cls(**data)
        except Exception as e:
            print(f"שגיאה בטעינת הגדרות: {e}")
            return cls()
    
    def save_to_file(self, file_path: str):
        """שומר הגדרות לקובץ"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.__dict__, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"שגיאה בשמירת הגדרות: {e}")

# הגדרות ברירת מחדל לסוגי החלטות שונים
DECISION_TYPE_CONFIGS = {
    "strategic": {
        "max_criteria": 10,
        "required_stakeholders": 3,
        "min_evaluation_time": 86400,  # יום אחד
        "default_weights": {
            "strategic_alignment": 0.4,
            "financial_impact": 0.3,
            "risk_level": 0.2,
            "implementation_feasibility": 0.1
        }
    },
    "operational": {
        "max_criteria": 8,
        "required_stakeholders": 2,
        "min_evaluation_time": 3600,  # שעה אחת
        "default_weights": {
            "cost_efficiency": 0.3,
            "time_to_implement": 0.3,
            "resource_availability": 0.2,
            "operational_impact": 0.2
        }
    },
    "emergency": {
        "max_criteria": 5,
        "required_stakeholders": 1,
        "min_evaluation_time": 300,   # 5 דקות
        "default_weights": {
            "immediate_impact": 0.5,
            "resource_availability": 0.3,
            "implementation_speed": 0.2
        }
    }
}

# הגדרות תרבותיות לקהל הישראלי
ISRAELI_CULTURAL_CONFIG = {
    "language": "he",
    "rtl_support": True,
    "date_format": "dd/mm/yyyy",
    "currency": "ILS",
    "business_hours": {
        "start": "08:00",
        "end": "17:00",
        "friday_end": "14:00"
    },
    "holidays_consideration": True,
    "cultural_factors": {
        "directness_preference": True,
        "consensus_importance": "medium",
        "hierarchy_respect": "medium",
        "time_orientation": "flexible"
    }
}