"""
Decision Results and Outcomes
תוצאות החלטות ותוצאות
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime
import json

class ResultStatus(Enum):
    """סטטוס תוצאה"""
    SUCCESS = "success"           # הצלחה
    PARTIAL_SUCCESS = "partial"   # הצלחה חלקית
    FAILURE = "failure"           # כישלון
    PENDING = "pending"           # ממתין
    IN_PROGRESS = "in_progress"   # בתהליך
    CANCELLED = "cancelled"       # בוטל

class OutcomeType(Enum):
    """סוג תוצאה"""
    FINANCIAL = "financial"       # כלכלי
    OPERATIONAL = "operational"   # תפעולי
    STRATEGIC = "strategic"       # אסטרטגי
    SOCIAL = "social"             # חברתי
    ENVIRONMENTAL = "environmental" # סביבתי
    TECHNOLOGICAL = "technological" # טכנולוגי

@dataclass
class DecisionOutcome:
    """תוצאה של החלטה"""
    id: str
    outcome_type: OutcomeType
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    measured_value: float
    expected_value: float
    variance: float               # סטיית התוצאה מהצפוי
    measurement_unit: str
    confidence: float            # רמת ביטחון במדידה
    measurement_date: datetime
    impact_level: int           # רמת השפעה (1-5)
    
    def calculate_variance(self) -> float:
        """מחשב סטיית התוצאה מהצפוי"""
        if self.expected_value == 0:
            return float('inf') if self.measured_value != 0 else 0
        
        self.variance = abs(self.measured_value - self.expected_value) / abs(self.expected_value)
        return self.variance
    
    def is_successful(self, tolerance: float = 0.1) -> bool:
        """בודק אם התוצאה נחשבת מוצלחת"""
        return self.variance <= tolerance

@dataclass
class DecisionResult:
    """תוצאת החלטה מלאה"""
    decision_id: str
    result_id: str
    selected_option_id: str
    implementation_date: datetime
    completion_date: Optional[datetime]
    status: ResultStatus
    outcomes: List[DecisionOutcome]
    actual_costs: Dict[str, float]
    actual_benefits: Dict[str, float]
    lessons_learned: List[str]
    hebrew_lessons: List[str]
    success_factors: List[str]
    failure_factors: List[str]
    overall_satisfaction: int    # דירוג שביעות רצון (1-5)
    would_decide_again: bool     # האם היו מחליטים שוב אותו דבר
    notes: str = ""
    hebrew_notes: str = ""
    
    def __post_init__(self):
        if not self.outcomes:
            self.outcomes = []
        if not self.lessons_learned:
            self.lessons_learned = []
        if not self.hebrew_lessons:
            self.hebrew_lessons = []
        if not self.success_factors:
            self.success_factors = []
        if not self.failure_factors:
            self.failure_factors = []
    
    def calculate_overall_success(self) -> float:
        """מחשב ניקוד הצלחה כולל"""
        if not self.outcomes:
            return 0.0
        
        success_scores = []
        for outcome in self.outcomes:
            # ניקוד בהתבסס על סטיית התוצאה ורמת ההשפעה
            success_score = (1.0 - min(outcome.variance, 1.0)) * (outcome.impact_level / 5.0)
            success_scores.append(success_score)
        
        return sum(success_scores) / len(success_scores)
    
    def get_roi(self) -> Optional[float]:
        """מחשב החזר על השקעה (ROI)"""
        total_costs = sum(self.actual_costs.values()) if self.actual_costs else 0
        total_benefits = sum(self.actual_benefits.values()) if self.actual_benefits else 0
        
        if total_costs == 0:
            return None
        
        return (total_benefits - total_costs) / total_costs
    
    def add_lesson_learned(self, lesson: str, hebrew_lesson: str):
        """מוסיף לקח נלמד"""
        self.lessons_learned.append(lesson)
        self.hebrew_lessons.append(hebrew_lesson)

@dataclass
class DecisionAnalytics:
    """אנליטיקה של החלטות"""
    total_decisions: int
    successful_decisions: int
    failed_decisions: int
    pending_decisions: int
    average_decision_time: float  # זמן ממוצע לקבלת החלטה (ימים)
    average_success_rate: float
    most_common_decision_type: str
    most_successful_criteria: List[str]
    common_failure_patterns: List[str]
    roi_statistics: Dict[str, float]
    
    def calculate_success_rate(self) -> float:
        """מחשב אחוז הצלחה כולל"""
        if self.total_decisions == 0:
            return 0.0
        
        self.average_success_rate = self.successful_decisions / self.total_decisions
        return self.average_success_rate
    
    def get_insights(self) -> List[str]:
        """מחזיר תובנות מהאנליטיקה"""
        insights = []
        
        if self.average_success_rate > 0.8:
            insights.append("אחוז הצלחה גבוה - תהליך קבלת החלטות יעיל")
        elif self.average_success_rate < 0.5:
            insights.append("אחוז הצלחה נמוך - יש לשפר את תהליך קבלת החלטות")
        
        if self.average_decision_time > 30:
            insights.append("זמן קבלת החלטות ארוך מדי - יש לייעל את התהליך")
        
        return insights

class ResultsTracker:
    """עוקב אחר תוצאות החלטות"""
    
    def __init__(self):
        self.results_history: List[DecisionResult] = []
        self.outcome_patterns: Dict[str, List[DecisionOutcome]] = {}
    
    def add_result(self, result: DecisionResult):
        """מוסיף תוצאת החלטה"""
        self.results_history.append(result)
        
        # מסווג תוצאות לפי דפוסים
        for outcome in result.outcomes:
            pattern_key = f"{outcome.outcome_type.value}_{outcome.name}"
            if pattern_key not in self.outcome_patterns:
                self.outcome_patterns[pattern_key] = []
            self.outcome_patterns[pattern_key].append(outcome)
    
    def get_analytics(self) -> DecisionAnalytics:
        """מחזיר אנליטיקה כוללת"""
        if not self.results_history:
            return DecisionAnalytics(0, 0, 0, 0, 0.0, 0.0, "", [], [], {})
        
        total = len(self.results_history)
        successful = len([r for r in self.results_history if r.status == ResultStatus.SUCCESS])
        failed = len([r for r in self.results_history if r.status == ResultStatus.FAILURE])
        pending = len([r for r in self.results_history if r.status == ResultStatus.PENDING])
        
        # חישוב זמן ממוצע
        completed_results = [r for r in self.results_history 
                           if r.completion_date and r.implementation_date]
        avg_time = 0.0
        if completed_results:
            times = [(r.completion_date - r.implementation_date).days 
                    for r in completed_results]
            avg_time = sum(times) / len(times)
        
        # ROI statistics
        rois = [r.get_roi() for r in self.results_history if r.get_roi() is not None]
        roi_stats = {}
        if rois:
            roi_stats = {
                'average': sum(rois) / len(rois),
                'min': min(rois),
                'max': max(rois)
            }
        
        return DecisionAnalytics(
            total_decisions=total,
            successful_decisions=successful,
            failed_decisions=failed,
            pending_decisions=pending,
            average_decision_time=avg_time,
            average_success_rate=successful / total if total > 0 else 0.0,
            most_common_decision_type="",
            most_successful_criteria=[],
            common_failure_patterns=[],
            roi_statistics=roi_stats
        )