"""
Decision Types and Classifications
סוגי החלטות וסיווגים
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Optional
from datetime import datetime

class DecisionType(Enum):
    """סוגי החלטות"""
    STRATEGIC = "strategic"          # החלטות אסטרטגיות
    OPERATIONAL = "operational"      # החלטות תפעוליות  
    TACTICAL = "tactical"           # החלטות טקטיות
    EMERGENCY = "emergency"         # החלטות חירום
    ROUTINE = "routine"             # החלטות שגרתיות
    CREATIVE = "creative"           # החלטות יצירתיות
    ANALYTICAL = "analytical"       # החלטות אנליטיות
    INTUITIVE = "intuitive"         # החלטות אינטואיטיביות

class DecisionPriority(Enum):
    """רמות עדיפות להחלטות"""
    CRITICAL = 5    # קריטי
    HIGH = 4        # גבוה
    MEDIUM = 3      # בינוני
    LOW = 2         # נמוך
    MINIMAL = 1     # מינימלי

class DecisionStatus(Enum):
    """סטטוס החלטות"""
    PENDING = "pending"           # ממתין
    IN_PROGRESS = "in_progress"   # בתהליך
    COMPLETED = "completed"       # הושלם
    CANCELLED = "cancelled"       # בוטל
    DEFERRED = "deferred"         # נדחה
    REVIEWING = "reviewing"       # בבדיקה

@dataclass
class DecisionMetadata:
    """מטה-דטה של החלטה"""
    id: str
    title: str
    hebrew_title: str
    description: str
    hebrew_description: str
    decision_type: DecisionType
    priority: DecisionPriority
    status: DecisionStatus
    created_at: datetime
    deadline: Optional[datetime] = None
    tags: List[str] = None
    context: Dict = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.context is None:
            self.context = {}

@dataclass
class DecisionConstraints:
    """אילוצי החלטה"""
    time_limit: Optional[int] = None      # זמן מקסימלי (שניות)
    budget_limit: Optional[float] = None   # תקציב מקסימלי
    resource_limits: Dict = None          # אילוצי משאבים
    legal_constraints: List[str] = None   # אילוצים חוקיים
    ethical_constraints: List[str] = None # אילוצים אתיים
    cultural_constraints: List[str] = None # אילוצים תרבותיים
    
    def __post_init__(self):
        if self.resource_limits is None:
            self.resource_limits = {}
        if self.legal_constraints is None:
            self.legal_constraints = []
        if self.ethical_constraints is None:
            self.ethical_constraints = []
        if self.cultural_constraints is None:
            self.cultural_constraints = []

class DecisionComplexity(Enum):
    """רמת מורכבות החלטה"""
    SIMPLE = 1      # פשוט - החלטה בינארית
    MODERATE = 2    # בינוני - מספר אפשרויות מוגבל
    COMPLEX = 3     # מורכב - אפשרויות רבות עם קריטריונים
    VERY_COMPLEX = 4 # מאוד מורכב - אפשרויות רבות עם תלויות
    EXTREME = 5     # קיצוני - החלטה רב-ממדית עם אי-ודאות

@dataclass
class DecisionStakeholder:
    """בעלי עניין בהחלטה"""
    name: str
    hebrew_name: str
    role: str
    influence_level: int  # 1-5
    interest_level: int   # 1-5
    decision_power: bool  # האם יש כוח החלטה
    contact_info: Dict = None
    
    def __post_init__(self):
        if self.contact_info is None:
            self.contact_info = {}