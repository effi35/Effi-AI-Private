"""
Main Decision Engine
מנוע קבלת החלטות ראשי
"""

import sqlite3
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
import logging
import uuid

from ..models.decision_types import DecisionMetadata, DecisionType, DecisionPriority, DecisionStatus
from ..models.criteria import DecisionCriteria, CriteriaTemplate
from ..models.options import DecisionOption, OptionGenerator
from ..models.results import DecisionResult, ResultsTracker
from ..models.config import DecisionEngineConfig

from .evaluation_engine import EvaluationEngine
from .scoring_engine import ScoringEngine
from .recommendation_engine import RecommendationEngine
from .learning_engine import LearningEngine

class DecisionEngine:
    """מנוע קבלת החלטות ראשי"""
    
    def __init__(self, config: DecisionEngineConfig = None):
        self.config = config or DecisionEngineConfig()
        self.logger = self._setup_logger()
        self.db_connection = self._init_database()
        
        # מנועי המשנה
        self.evaluation_engine = EvaluationEngine(self.config)
        self.scoring_engine = ScoringEngine(self.config)
        self.recommendation_engine = RecommendationEngine(self.config)
        self.learning_engine = LearningEngine(self.config)
        
        # עוקב תוצאות
        self.results_tracker = ResultsTracker()
        
        # החלטות פעילות
        self.active_decisions: Dict[str, Dict] = {}
        
        self.logger.info("מנוע קבלת החלטות הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים"""
        logger = logging.getLogger("DecisionEngine")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _init_database(self) -> sqlite3.Connection:
        """אתחול מסד נתונים"""
        conn = sqlite3.connect(self.config.database_path)
        
        # יצירת טבלאות
        cursor = conn.cursor()
        
        # טבלת החלטות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS decisions (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                hebrew_title TEXT NOT NULL,
                description TEXT,
                hebrew_description TEXT,
                decision_type TEXT,
                priority INTEGER,
                status TEXT,
                created_at TIMESTAMP,
                deadline TIMESTAMP,
                data TEXT
            )
        ''')
        
        # טבלת אפשרויות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS options (
                id TEXT PRIMARY KEY,
                decision_id TEXT,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                description TEXT,
                status TEXT,
                data TEXT,
                FOREIGN KEY (decision_id) REFERENCES decisions (id)
            )
        ''')
        
        # טבלת קריטריונים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS criteria (
                id TEXT PRIMARY KEY,
                decision_id TEXT,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                criteria_type TEXT,
                weight REAL,
                data TEXT,
                FOREIGN KEY (decision_id) REFERENCES decisions (id)
            )
        ''')
        
        # טבלת תוצאות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS results (
                id TEXT PRIMARY KEY,
                decision_id TEXT,
                selected_option_id TEXT,
                status TEXT,
                implementation_date TIMESTAMP,
                completion_date TIMESTAMP,
                data TEXT,
                FOREIGN KEY (decision_id) REFERENCES decisions (id)
            )
        ''')
        
        conn.commit()
        return conn
    
    def create_decision(self, 
                       title: str,
                       hebrew_title: str,
                       description: str = "",
                       hebrew_description: str = "",
                       decision_type: DecisionType = DecisionType.OPERATIONAL,
                       priority: DecisionPriority = DecisionPriority.MEDIUM,
                       deadline: Optional[datetime] = None) -> str:
        """יוצר החלטה חדשה"""
        
        decision_id = str(uuid.uuid4())
        
        metadata = DecisionMetadata(
            id=decision_id,
            title=title,
            hebrew_title=hebrew_title,
            description=description,
            hebrew_description=hebrew_description,
            decision_type=decision_type,
            priority=priority,
            status=DecisionStatus.PENDING,
            created_at=datetime.now(),
            deadline=deadline
        )
        
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            INSERT INTO decisions 
            (id, title, hebrew_title, description, hebrew_description, 
             decision_type, priority, status, created_at, deadline)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            decision_id, title, hebrew_title, description, hebrew_description,
            decision_type.value, priority.value, metadata.status.value,
            metadata.created_at, deadline
        ))
        self.db_connection.commit()
        
        # הוספה לזיכרון
        self.active_decisions[decision_id] = {
            'metadata': metadata,
            'criteria': [],
            'options': [],
            'evaluations': []
        }
        
        self.logger.info(f"נוצרה החלטה חדשה: {hebrew_title} (ID: {decision_id})")
        return decision_id
    
    def add_criteria(self, decision_id: str, criteria: List[DecisionCriteria]) -> bool:
        """מוסיף קריטריונים להחלטה"""
        if decision_id not in self.active_decisions:
            self.logger.error(f"החלטה לא נמצאה: {decision_id}")
            return False
        
        self.active_decisions[decision_id]['criteria'].extend(criteria)
        
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        for criterion in criteria:
            cursor.execute('''
                INSERT INTO criteria 
                (id, decision_id, name, hebrew_name, criteria_type, weight)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                criterion.id, decision_id, criterion.name, criterion.hebrew_name,
                criterion.criteria_type.value, criterion.weight.weight
            ))
        self.db_connection.commit()
        
        self.logger.info(f"נוספו {len(criteria)} קריטריונים להחלטה {decision_id}")
        return True
    
    def add_options(self, decision_id: str, options: List[DecisionOption]) -> bool:
        """מוסיף אפשרויות להחלטה"""
        if decision_id not in self.active_decisions:
            self.logger.error(f"החלטה לא נמצאה: {decision_id}")
            return False
        
        self.active_decisions[decision_id]['options'].extend(options)
        
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        for option in options:
            cursor.execute('''
                INSERT INTO options 
                (id, decision_id, name, hebrew_name, description, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                option.id, decision_id, option.name, option.hebrew_name,
                option.description, option.status.value
            ))
        self.db_connection.commit()
        
        self.logger.info(f"נוספו {len(options)} אפשרויות להחלטה {decision_id}")
        return True
    
    def evaluate_decision(self, decision_id: str) -> Optional[Dict]:
        """מבצע הערכה מלאה של החלטה"""
        if decision_id not in self.active_decisions:
            self.logger.error(f"החלטה לא נמצאה: {decision_id}")
            return None
        
        decision_data = self.active_decisions[decision_id]
        criteria = decision_data['criteria']
        options = decision_data['options']
        
        if not criteria or not options:
            self.logger.error("חסרים קריטריונים או אפשרויות להערכה")
            return None
        
        self.logger.info(f"מתחיל הערכת החלטה: {decision_id}")
        
        # 1. הערכת אפשרויות לפי קריטריונים
        evaluations = self.evaluation_engine.evaluate_options(options, criteria)
        
        # 2. חישוב ניקודים משוקללים
        scored_options = self.scoring_engine.calculate_scores(evaluations, criteria)
        
        # 3. יצירת המלצות
        recommendations = self.recommendation_engine.generate_recommendations(
            scored_options, criteria, decision_data['metadata']
        )
        
        # 4. למידה מההחלטה
        if self.config.enable_learning:
            self.learning_engine.learn_from_decision(decision_data, evaluations)
        
        # עדכון סטטוס החלטה
        self.active_decisions[decision_id]['evaluations'] = evaluations
        self.active_decisions[decision_id]['scores'] = scored_options
        self.active_decisions[decision_id]['recommendations'] = recommendations
        
        # עדכון במסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            UPDATE decisions SET status = ? WHERE id = ?
        ''', (DecisionStatus.REVIEWING.value, decision_id))
        self.db_connection.commit()
        
        result = {
            'decision_id': decision_id,
            'evaluations': evaluations,
            'scores': scored_options,
            'recommendations': recommendations,
            'evaluation_timestamp': datetime.now()
        }
        
        self.logger.info(f"הערכת החלטה הושלמה: {decision_id}")
        return result
    
    def implement_decision(self, decision_id: str, selected_option_id: str) -> bool:
        """מיישם החלטה שנבחרה"""
        if decision_id not in self.active_decisions:
            self.logger.error(f"החלטה לא נמצאה: {decision_id}")
            return False
        
        # עדכון סטטוס החלטה
        cursor = self.db_connection.cursor()
        cursor.execute('''
            UPDATE decisions SET status = ? WHERE id = ?
        ''', (DecisionStatus.COMPLETED.value, decision_id))
        
        # יצירת רשומת תוצאה
        result_id = str(uuid.uuid4())
        cursor.execute('''
            INSERT INTO results 
            (id, decision_id, selected_option_id, status, implementation_date)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            result_id, decision_id, selected_option_id, 
            "implemented", datetime.now()
        ))
        
        self.db_connection.commit()
        
        self.logger.info(f"החלטה יושמה: {decision_id}, אפשרות נבחרת: {selected_option_id}")
        return True
    
    def get_decision_status(self, decision_id: str) -> Optional[Dict]:
        """מחזיר סטטוס החלטה"""
        if decision_id in self.active_decisions:
            return self.active_decisions[decision_id]
        
        # חיפוש במסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            SELECT * FROM decisions WHERE id = ?
        ''', (decision_id,))
        
        result = cursor.fetchone()
        if result:
            return {
                'id': result[0],
                'title': result[1],
                'hebrew_title': result[2],
                'status': result[7]
            }
        
        return None
    
    def get_pending_decisions(self) -> List[Dict]:
        """מחזיר רשימת החלטות ממתינות"""
        pending = []
        
        for decision_id, data in self.active_decisions.items():
            if data['metadata'].status == DecisionStatus.PENDING:
                pending.append({
                    'id': decision_id,
                    'title': data['metadata'].title,
                    'hebrew_title': data['metadata'].hebrew_title,
                    'priority': data['metadata'].priority,
                    'created_at': data['metadata'].created_at,
                    'deadline': data['metadata'].deadline
                })
        
        return sorted(pending, key=lambda x: x['priority'].value, reverse=True)
    
    def close(self):
        """סגירת המנוע"""
        if self.db_connection:
            self.db_connection.close()
        self.logger.info("מנוע קבלת החלטות נסגר")