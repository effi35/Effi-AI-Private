"""
Scoring Engine for Decision Options
מנוע ניקוד אפשרויות החלטה
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
import logging
from scipy.spatial.distance import euclidean

from ..models.criteria import DecisionCriteria
from ..models.options import OptionEvaluation
from ..models.config import DecisionEngineConfig

class ScoringEngine:
    """מנוע חישוב ניקודים"""
    
    def __init__(self, config: DecisionEngineConfig):
        self.config = config
        self.logger = logging.getLogger("ScoringEngine")
        
        # שיטות ניקוד זמינות
        self.scoring_methods = {
            'weighted_sum': self._weighted_sum_scoring,
            'topsis': self._topsis_scoring,
            'ahp': self._ahp_scoring,
            'promethee': self._promethee_scoring
        }
    
    def calculate_scores(self, 
                        evaluations: List[OptionEvaluation], 
                        criteria: List[DecisionCriteria]) -> List[Dict]:
        """מחשב ניקודים עבור כל האפשרויות"""
        
        self.logger.info(f"מחשב ניקודים עבור {len(evaluations)} אפשרויות")
        
        # בחירת שיטת ניקוד
        scoring_method = self.scoring_methods.get(
            self.config.scoring_algorithm, 
            self._weighted_sum_scoring
        )
        
        # חישוב ניקודים
        scored_options = scoring_method(evaluations, criteria)
        
        # הוספת מטא-דטה לכל אפשרות
        for scored_option in scored_options:
            scored_option['scoring_method'] = self.config.scoring_algorithm
            scored_option['confidence'] = self._calculate_scoring_confidence(
                scored_option, evaluations
            )
        
        self.logger.info(f"חישוב ניקודים הושלם בשיטת {self.config.scoring_algorithm}")
        return scored_options
    
    def _weighted_sum_scoring(self, 
                             evaluations: List[OptionEvaluation], 
                             criteria: List[DecisionCriteria]) -> List[Dict]:
        """שיטת סכום משוקלל"""
        
        scored_options = []
        
        for evaluation in evaluations:
            total_score = evaluation.total_score
            
            # פירוט ניקוד לפי קריטריונים
            criteria_breakdown = {}
            for score in evaluation.criteria_scores:
                criterion = next((c for c in criteria if c.id == score.criteria_id), None)
                if criterion:
                    criteria_breakdown[criterion.hebrew_name] = {
                        'weighted_score': score.weighted_score,
                        'normalized_score': score.normalized_score,
                        'weight': criterion.weight.weight,
                        'confidence': score.confidence
                    }
            
            scored_options.append({
                'option_id': evaluation.option_id,
                'total_score': total_score,
                'ranking': 0,  # יעודכן בסוף
                'criteria_breakdown': criteria_breakdown,
                'evaluation_id': evaluation.evaluation_id
            })
        
        # מיון וקביעת דירוגים
        scored_options.sort(key=lambda x: x['total_score'], reverse=True)
        for i, option in enumerate(scored_options):
            option['ranking'] = i + 1
        
        return scored_options
    
    def _topsis_scoring(self, 
                       evaluations: List[OptionEvaluation], 
                       criteria: List[DecisionCriteria]) -> List[Dict]:
        """שיטת TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution)"""
        
        if len(evaluations) < 2:
            return self._weighted_sum_scoring(evaluations, criteria)
        
        # יצירת מטריצת החלטות
        decision_matrix = []
        option_ids = []
        
        for evaluation in evaluations:
            option_ids.append(evaluation.option_id)
            option_scores = []
            
            for criterion in criteria:
                criterion_score = next(
                    (s for s in evaluation.criteria_scores if s.criteria_id == criterion.id),
                    None
                )
                score = criterion_score.normalized_score if criterion_score else 0.0
                option_scores.append(score)
            
            decision_matrix.append(option_scores)
        
        decision_matrix = np.array(decision_matrix)
        weights = np.array([c.weight.weight for c in criteria])
        
        # נירמול המטריצה
        norms = np.sqrt(np.sum(decision_matrix**2, axis=0))
        normalized_matrix = decision_matrix / norms
        
        # מטריצה משוקללת
        weighted_matrix = normalized_matrix * weights
        
        # פתרון אידיאלי חיובי ושלילי
        ideal_positive = np.max(weighted_matrix, axis=0)
        ideal_negative = np.min(weighted_matrix, axis=0)
        
        # חישוב מרחקים
        distances_positive = []
        distances_negative = []
        
        for i in range(len(weighted_matrix)):
            dist_pos = euclidean(weighted_matrix[i], ideal_positive)
            dist_neg = euclidean(weighted_matrix[i], ideal_negative)
            
            distances_positive.append(dist_pos)
            distances_negative.append(dist_neg)
        
        # חישוב ציון TOPSIS
        topsis_scores = []
        for i in range(len(evaluations)):
            if distances_positive[i] + distances_negative[i] == 0:
                score = 0.5
            else:
                score = distances_negative[i] / (distances_positive[i] + distances_negative[i])
            topsis_scores.append(score)
        
        # יצירת תוצאות
        scored_options = []
        for i, (option_id, score) in enumerate(zip(option_ids, topsis_scores)):
            evaluation = evaluations[i]
            
            criteria_breakdown = {}
            for j, criterion in enumerate(criteria):
                criteria_breakdown[criterion.hebrew_name] = {
                    'weighted_score': weighted_matrix[i][j],
                    'normalized_score': normalized_matrix[i][j],
                    'weight': criterion.weight.weight,
                    'ideal_distance': abs(weighted_matrix[i][j] - ideal_positive[j])
                }
            
            scored_options.append({
                'option_id': option_id,
                'total_score': score,
                'ranking': 0,
                'criteria_breakdown': criteria_breakdown,
                'evaluation_id': evaluation.evaluation_id,
                'distance_to_ideal': distances_positive[i],
                'distance_to_worst': distances_negative[i]
            })
        
        # מיון וקביעת דירוגים
        scored_options.sort(key=lambda x: x['total_score'], reverse=True)
        for i, option in enumerate(scored_options):
            option['ranking'] = i + 1
        
        return scored_options
    
    def _ahp_scoring(self, 
                    evaluations: List[OptionEvaluation], 
                    criteria: List[DecisionCriteria]) -> List[Dict]:
        """שיטת AHP (Analytic Hierarchy Process)"""
        
        # AHP דורש השוואות זוגיות - מחזיר לסכום משוקלל אם אין מספיק נתונים
        return self._weighted_sum_scoring(evaluations, criteria)
    
    def _promethee_scoring(self, 
                          evaluations: List[OptionEvaluation], 
                          criteria: List[DecisionCriteria]) -> List[Dict]:
        """שיטת PROMETHEE"""
        
        if len(evaluations) < 2:
            return self._weighted_sum_scoring(evaluations, criteria)
        
        # יצירת מטריצת השוואות
        n_options = len(evaluations)
        preference_matrix = np.zeros((n_options, n_options))
        
        for i in range(n_options):
            for j in range(n_options):
                if i != j:
                    preference_sum = 0
                    
                    for criterion in criteria:
                        # השוואה בין אפשרויות לכל קריטריון
                        score_i = self._get_criterion_score(evaluations[i], criterion.id)
                        score_j = self._get_criterion_score(evaluations[j], criterion.id)
                        
                        # פונקציית העדפה פשוטה (ליניארית)
                        if score_i > score_j:
                            preference = (score_i - score_j) * criterion.weight.weight
                        else:
                            preference = 0
                        
                        preference_sum += preference
                    
                    preference_matrix[i][j] = preference_sum
        
        # חישוב זרימות חיוביות ושליליות
        positive_flows = np.sum(preference_matrix, axis=1) / (n_options - 1)
        negative_flows = np.sum(preference_matrix, axis=0) / (n_options - 1)
        
        # זרימה נטו
        net_flows = positive_flows - negative_flows
        
        # יצירת תוצאות
        scored_options = []
        for i, evaluation in enumerate(evaluations):
            criteria_breakdown = {}
            for score in evaluation.criteria_scores:
                criterion = next((c for c in criteria if c.id == score.criteria_id), None)
                if criterion:
                    criteria_breakdown[criterion.hebrew_name] = {
                        'weighted_score': score.weighted_score,
                        'normalized_score': score.normalized_score,
                        'weight': criterion.weight.weight
                    }
            
            scored_options.append({
                'option_id': evaluation.option_id,
                'total_score': net_flows[i],
                'ranking': 0,
                'criteria_breakdown': criteria_breakdown,
                'evaluation_id': evaluation.evaluation_id,
                'positive_flow': positive_flows[i],
                'negative_flow': negative_flows[i],
                'net_flow': net_flows[i]
            })
        
        # מיון וקביעת דירוגים
        scored_options.sort(key=lambda x: x['total_score'], reverse=True)
        for i, option in enumerate(scored_options):
            option['ranking'] = i + 1
        
        return scored_options
    
    def _get_criterion_score(self, evaluation: OptionEvaluation, criterion_id: str) -> float:
        """מחזיר ניקוד קריטריון ספציפי מהערכה"""
        for score in evaluation.criteria_scores:
            if score.criteria_id == criterion_id:
                return score.normalized_score
        return 0.0
    
    def _calculate_scoring_confidence(self, 
                                    scored_option: Dict, 
                                    evaluations: List[OptionEvaluation]) -> float:
        """מחשב רמת ביטחון בניקוד"""
        
        # מציאת ההערכה המתאימה
        evaluation = next(
            (e for e in evaluations if e.option_id == scored_option['option_id']),
            None
        )
        
        if not evaluation:
            return 0.5
        
        # חישוב ממוצע רמת ביטחון מכל הקריטריונים
        confidences = [score.confidence for score in evaluation.criteria_scores]
        
        if not confidences:
            return 0.5
        
        base_confidence = sum(confidences) / len(confidences)
        
        # התאמת רמת ביטחון בהתבסס על פיזור הניקודים
        scores = [score.normalized_score for score in evaluation.criteria_scores]
        if len(scores) > 1:
            score_variance = np.var(scores)
            # פיזור גבוה = ביטחון נמוך יותר
            confidence_adjustment = max(0, 1 - score_variance)
            base_confidence *= confidence_adjustment
        
        return min(1.0, max(0.1, base_confidence))
    
    def sensitivity_analysis(self, 
                           evaluations: List[OptionEvaluation], 
                           criteria: List[DecisionCriteria]) -> Dict:
        """ניתוח רגישות לשינויים במשקלי קריטריונים"""
        
        self.logger.info("מבצע ניתוח רגישות")
        
        # חישוב ניקודים בסיסיים
        base_scores = self.calculate_scores(evaluations, criteria)
        base_ranking = [opt['option_id'] for opt in base_scores]
        
        sensitivity_results = {}
        
        # בדיקת שינויים במשקלי קריטריונים
        for criterion in criteria:
            criterion_sensitivity = []
            
            # בדיקת שינוי במשקל ±10%
            for weight_change in [-0.1, 0.1]:
                # שמירת משקל מקורי
                original_weight = criterion.weight.weight
                
                # שינוי זמני של המשקל
                criterion.weight.weight = max(0, min(1, original_weight + weight_change))
                
                # חישוב ניקודים מחדש
                new_scores = self.calculate_scores(evaluations, criteria)
                new_ranking = [opt['option_id'] for opt in new_scores]
                
                # חישוב שינוי בדירוג
                ranking_changes = self._calculate_ranking_changes(base_ranking, new_ranking)
                
                criterion_sensitivity.append({
                    'weight_change': weight_change,
                    'new_weight': criterion.weight.weight,
                    'ranking_changes': ranking_changes,
                    'stability_score': 1 - (len(ranking_changes) / len(base_ranking))
                })
                
                # החזרת משקל מקורי
                criterion.weight.weight = original_weight
            
            sensitivity_results[criterion.hebrew_name] = criterion_sensitivity
        
        return sensitivity_results
    
    def _calculate_ranking_changes(self, base_ranking: List[str], new_ranking: List[str]) -> List[Dict]:
        """מחשב שינויים בדירוג"""
        changes = []
        
        for option_id in base_ranking:
            base_position = base_ranking.index(option_id)
            new_position = new_ranking.index(option_id)
            
            if base_position != new_position:
                changes.append({
                    'option_id': option_id,
                    'from_position': base_position + 1,
                    'to_position': new_position + 1,
                    'change': new_position - base_position
                })
        
        return changes