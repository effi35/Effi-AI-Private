"""
Recommendation Engine for Decision Making
מנוע המלצות לקבלת החלטות
"""

from typing import List, Dict, Optional, Tuple
import numpy as np
from datetime import datetime, timedelta
import logging

from ..models.decision_types import DecisionMetadata, DecisionType, DecisionPriority
from ..models.criteria import DecisionCriteria
from ..models.options import DecisionOption, OptionEvaluation
from ..models.config import DecisionEngineConfig

class RecommendationEngine:
    """מנוע המלצות מתקדם"""
    
    def __init__(self, config: DecisionEngineConfig):
        self.config = config
        self.logger = logging.getLogger("RecommendationEngine")
        
        # בסיס ידע להמלצות
        self.recommendation_patterns = self._load_recommendation_patterns()
        
    def generate_recommendations(self, 
                               scored_options: List[Dict], 
                               criteria: List[DecisionCriteria],
                               decision_metadata: DecisionMetadata) -> Dict:
        """מייצר המלצות מלאות להחלטה"""
        
        self.logger.info(f"מייצר המלצות עבור החלטה: {decision_metadata.hebrew_title}")
        
        # המלצה ראשית
        primary_recommendation = self._get_primary_recommendation(scored_options)
        
        # המלצות חלופיות
        alternative_recommendations = self._get_alternative_recommendations(scored_options)
        
        # ניתוח סיכונים
        risk_analysis = self._analyze_risks(scored_options, criteria)
        
        # אסטרטגיות יישום
        implementation_strategies = self._suggest_implementation_strategies(
            primary_recommendation, decision_metadata
        )
        
        # תוכנית גיבוי
        contingency_plan = self._create_contingency_plan(scored_options, decision_metadata)
        
        # המלצות לשיפור
        improvement_suggestions = self._suggest_improvements(scored_options, criteria)
        
        # התאמה תרבותית
        cultural_considerations = self._add_cultural_considerations(
            primary_recommendation, decision_metadata
        )
        
        return {
            'primary_recommendation': primary_recommendation,
            'alternatives': alternative_recommendations,
            'risk_analysis': risk_analysis,
            'implementation_strategies': implementation_strategies,
            'contingency_plan': contingency_plan,
            'improvement_suggestions': improvement_suggestions,
            'cultural_considerations': cultural_considerations,
            'confidence_level': self._calculate_recommendation_confidence(scored_options),
            'generated_at': datetime.now(),
            'decision_urgency': self._assess_decision_urgency(decision_metadata)
        }
    
    def _get_primary_recommendation(self, scored_options: List[Dict]) -> Dict:
        """מחזיר המלצה ראשית"""
        
        if not scored_options:
            return {'error': 'אין אפשרויות זמינות להמלצה'}
        
        best_option = scored_options[0]  # האפשרות עם הניקוד הגבוה ביותר
        
        # ניתוח נקודות חוזק וחולשה
        strengths = []
        weaknesses = []
        
        for criterion_name, breakdown in best_option['criteria_breakdown'].items():
            if breakdown['weighted_score'] > 0.7:
                strengths.append({
                    'criterion': criterion_name,
                    'score': breakdown['weighted_score'],
                    'description': f"ביצועים מעולים ב{criterion_name}"
                })
            elif breakdown['weighted_score'] < 0.3:
                weaknesses.append({
                    'criterion': criterion_name,
                    'score': breakdown['weighted_score'],
                    'description': f"ביצועים חלשים ב{criterion_name}"
                })
        
        # חישוב רמת ביטחון
        confidence = best_option.get('confidence', 0.5)
        
        # יצירת הצדקה
        justification = self._create_justification(best_option, scored_options)
        
        return {
            'option_id': best_option['option_id'],
            'total_score': best_option['total_score'],
            'ranking': best_option['ranking'],
            'confidence': confidence,
            'strengths': strengths,
            'weaknesses': weaknesses,
            'justification': justification,
            'recommendation_type': self._classify_recommendation_type(best_option, scored_options)
        }
    
    def _get_alternative_recommendations(self, scored_options: List[Dict]) -> List[Dict]:
        """מחזיר המלצות חלופיות"""
        
        alternatives = []
        
        # שלוש האפשרויות הטובות ביותר (מלבד הראשונה)
        for option in scored_options[1:4]:
            alternative = {
                'option_id': option['option_id'],
                'total_score': option['total_score'],
                'ranking': option['ranking'],
                'when_to_consider': self._when_to_consider_alternative(option, scored_options[0]),
                'key_advantages': self._identify_key_advantages(option, scored_options[0])
            }
            alternatives.append(alternative)
        
        return alternatives
    
    def _analyze_risks(self, scored_options: List[Dict], criteria: List[DecisionCriteria]) -> Dict:
        """מנתח סיכונים באפשרויות השונות"""
        
        risk_analysis = {
            'overall_risk_level': 'בינוני',
            'major_risks': [],
            'risk_mitigation': [],
            'risk_comparison': []
        }
        
        # זיהוי קריטריונים הקשורים לסיכון
        risk_criteria = [c for c in criteria if 'risk' in c.name.lower() or 'סיכון' in c.hebrew_name]
        
        if risk_criteria:
            best_option = scored_options[0]
            
            for risk_criterion in risk_criteria:
                criterion_name = risk_criterion.hebrew_name
                if criterion_name in best_option['criteria_breakdown']:
                    risk_score = best_option['criteria_breakdown'][criterion_name]['normalized_score']
                    
                    if risk_score > 0.7:
                        risk_analysis['major_risks'].append({
                            'type': criterion_name,
                            'level': 'גבוה',
                            'score': risk_score,
                            'description': f"רמת סיכון גבוהה ב{criterion_name}"
                        })
                    elif risk_score > 0.4:
                        risk_analysis['major_risks'].append({
                            'type': criterion_name,
                            'level': 'בינוני',
                            'score': risk_score,
                            'description': f"רמת סיכון בינונית ב{criterion_name}"
                        })
        
        # הצעות להפחתת סיכונים
        risk_analysis['risk_mitigation'] = self._suggest_risk_mitigation(risk_analysis['major_risks'])
        
        return risk_analysis
    
    def _suggest_implementation_strategies(self, 
                                         primary_recommendation: Dict, 
                                         decision_metadata: DecisionMetadata) -> List[Dict]:
        """מציע אסטרטגיות יישום"""
        
        strategies = []
        
        # אסטרטגיה בהתבסס על סוג החלטה
        if decision_metadata.decision_type == DecisionType.EMERGENCY:
            strategies.append({
                'name': 'יישום מיידי',
                'hebrew_name': 'יישום מיידי',
                'description': 'יישום מהיר עקב אופי חירום של ההחלטה',
                'timeline': 'תוך 24 שעות',
                'key_steps': [
                    'גיוס צוות יישום מיידי',
                    'הקצאת משאבים בעדיפות עליונה',
                    'ביצוע בשלבים מקוצרים',
                    'מעקב צמוד ובקרה'
                ]
            })
        
        elif decision_metadata.decision_type == DecisionType.STRATEGIC:
            strategies.append({
                'name': 'יישום מתוכנן ומדורג',
                'hebrew_name': 'יישום מתוכנן ומדורג',
                'description': 'יישום מתוכנן בשלבים עם נקודות בקרה',
                'timeline': '3-12 חודשים',
                'key_steps': [
                    'פיתוח תוכנית יישום מפורטת',
                    'הקמת ועדת היגוי',
                    'יישום בשלבים עם אבני דרך',
                    'הערכה ברציפות והתאמות'
                ]
            })
        
        else:
            strategies.append({
                'name': 'יישום סטנדרטי',
                'hebrew_name': 'יישום סטנדרטי',
                'description': 'יישום בהליך רגיל עם מעקב שוטף',
                'timeline': '2-8 שבועות',
                'key_steps': [
                    'הכנת תוכנית יישום',
                    'הקצאת משאבים נדרשים',
                    'ביצוע בשלבים',
                    'מעקב ובקרה שוטפת'
                ]
            })
        
        # הוספת אסטרטגיות נוספות בהתבסס על רמת ביטחון
        confidence = primary_recommendation.get('confidence', 0.5)
        
        if confidence < 0.6:
            strategies.append({
                'name': 'יישום פיילוט',
                'hebrew_name': 'יישום פיילוט',
                'description': 'יישום ראשוני במקביל לתוכנית גיבוי',
                'timeline': 'שלב ראשון: 2-4 שבועות',
                'key_steps': [
                    'הגדרת פיילוט מוגבל',
                    'מדידת תוצאות ראשוניות',
                    'הערכת ביצועים',
                    'החלטה על המשך או שינוי כיוון'
                ]
            })
        
        return strategies
    
    def _create_contingency_plan(self, 
                                scored_options: List[Dict], 
                                decision_metadata: DecisionMetadata) -> Dict:
        """יוצר תוכנית חירום וגיבוי"""
        
        backup_options = scored_options[1:3] if len(scored_options) > 1 else []
        
        contingency_plan = {
            'backup_options': backup_options,
            'trigger_conditions': self._define_trigger_conditions(decision_metadata),
            'rollback_plan': self._create_rollback_plan(),
            'escalation_procedures': self._define_escalation_procedures(decision_metadata)
        }
        
        return contingency_plan
    
    def _suggest_improvements(self, 
                            scored_options: List[Dict], 
                            criteria: List[DecisionCriteria]) -> List[Dict]:
        """מציע שיפורים לאפשרויות"""
        
        improvements = []
        
        # ניתוח פערים באפשרות הטובה ביותר
        best_option = scored_options[0]
        
        for criterion_name, breakdown in best_option['criteria_breakdown'].items():
            if breakdown['weighted_score'] < 0.6:
                improvement = {
                    'area': criterion_name,
                    'current_score': breakdown['weighted_score'],
                    'improvement_potential': min(1.0, breakdown['weighted_score'] + 0.3),
                    'suggestions': self._get_improvement_suggestions(criterion_name),
                    'impact': breakdown['weight'] * 0.3  # השפעה פוטנציאלית
                }
                improvements.append(improvement)
        
        # מיון לפי השפעה פוטנציאלית
        improvements.sort(key=lambda x: x['impact'], reverse=True)
        
        return improvements[:5]  # חמישה שיפורים עיקריים
    
    def _add_cultural_considerations(self, 
                                   primary_recommendation: Dict, 
                                   decision_metadata: DecisionMetadata) -> Dict:
        """מוסיף שיקולים תרבותיים ישראליים"""
        
        cultural_factors = {
            'communication_style': {
                'recommendation': 'תקשורת ישירה וברורה',
                'rationale': 'תרבות ישראלית מעדיפה תקשורת ישירה'
            },
            'decision_timing': {
                'consideration': 'התחשבות בחגים ובמילואים',
                'recommendation': 'תכנון מראש של לוח זמנים'
            },
            'stakeholder_involvement': {
                'approach': 'מעורבות רחבה של בעלי עניין',
                'rationale': 'חשיבות הקונסנזוס בתרבות הישראלית'
            },
            'implementation_style': {
                'preference': 'גמישות ויכולת הסתגלות',
                'rationale': 'סביבה דינמית הדורשת גמישות'
            }
        }
        
        return cultural_factors
    
    def _calculate_recommendation_confidence(self, scored_options: List[Dict]) -> float:
        """מחשב רמת ביטחון בהמלצות"""
        
        if len(scored_options) < 2:
            return 0.5
        
        # פער בין האפשרות הטובה ביותר לשנייה
        score_gap = scored_options[0]['total_score'] - scored_options[1]['total_score']
        
        # ביטחון בסיסי מהאפשרות הטובה ביותר
        base_confidence = scored_options[0].get('confidence', 0.5)
        
        # התאמת ביטחון לפי הפער
        gap_confidence = min(1.0, score_gap * 2)  # פער גדול = ביטחון גבוה יותר
        
        # ממוצע משוקלל
        total_confidence = (base_confidence * 0.6) + (gap_confidence * 0.4)
        
        return min(1.0, max(0.1, total_confidence))
    
    def _assess_decision_urgency(self, decision_metadata: DecisionMetadata) -> str:
        """מעריך דחיפות ההחלטה"""
        
        now = datetime.now()
        
        # בדיקת דדליין
        if decision_metadata.deadline:
            time_left = decision_metadata.deadline - now
            
            if time_left < timedelta(hours=24):
                return 'דחוף מאוד'
            elif time_left < timedelta(days=3):
                return 'דחוף'
            elif time_left < timedelta(weeks=1):
                return 'בדחיפות בינונית'
        
        # בדיקת סוג החלטה
        if decision_metadata.decision_type == DecisionType.EMERGENCY:
            return 'דחוף מאוד'
        elif decision_metadata.priority.value >= 4:
            return 'בדחיפות גבוהה'
        
        return 'רגיל'
    
    # Helper methods
    def _load_recommendation_patterns(self) -> Dict:
        """טוען דפוסי המלצות מוכנים"""
        return {
            'high_risk_patterns': ['high_cost', 'uncertain_outcome', 'complex_implementation'],
            'quick_win_patterns': ['low_cost', 'high_benefit', 'easy_implementation'],
            'strategic_patterns': ['long_term_benefit', 'alignment', 'competitive_advantage']
        }
    
    def _create_justification(self, best_option: Dict, all_options: List[Dict]) -> str:
        """יוצר הצדקה להמלצה"""
        score = best_option['total_score']
        ranking = best_option['ranking']
        
        if len(all_options) > 1:
            score_diff = score - all_options[1]['total_score']
            return f"אפשרות זו דורגה במקום {ranking} עם ניקוד {score:.2f}, גבוה ב-{score_diff:.2f} מהאפשרות השנייה"
        else:
            return f"אפשרות יחידה זמינה עם ניקוד {score:.2f}"
    
    def _classify_recommendation_type(self, best_option: Dict, all_options: List[Dict]) -> str:
        """מסווג סוג המלצה"""
        score = best_option['total_score']
        
        if score > 0.8:
            return 'המלצה חזקה'
        elif score > 0.6:
            return 'המלצה מתונה'
        elif len(all_options) > 1 and (score - all_options[1]['total_score']) < 0.1:
            return 'המלצה זהירה - אפשרויות דומות'
        else:
            return 'המלצה עם סייגים'
    
    def _when_to_consider_alternative(self, alternative: Dict, primary: Dict) -> str:
        """מגדיר מתי לשקול אלטרנטיבה"""
        score_diff = primary['total_score'] - alternative['total_score']
        
        if score_diff < 0.1:
            return 'כאשר קיימת גמישות בביצוע'
        elif score_diff < 0.2:
            return 'כאשר האפשרות הראשית נכשלת'
        else:
            return 'כגיבוי בלבד'
    
    def _identify_key_advantages(self, alternative: Dict, primary: Dict) -> List[str]:
        """מזהה יתרונות מפתח של אלטרנטיבה"""
        advantages = []
        
        for criterion, breakdown in alternative['criteria_breakdown'].items():
            primary_score = primary['criteria_breakdown'].get(criterion, {}).get('weighted_score', 0)
            if breakdown['weighted_score'] > primary_score:
                advantages.append(f"טוב יותר ב{criterion}")
        
        return advantages[:3]  # שלושה יתרונות עיקריים
    
    def _suggest_risk_mitigation(self, major_risks: List[Dict]) -> List[str]:
        """מציע דרכים להפחתת סיכונים"""
        mitigation_suggestions = []
        
        for risk in major_risks:
            if 'כלכלי' in risk['type'] or 'עלות' in risk['type']:
                mitigation_suggestions.append('הקצאת תקציב חירום נוסף')
                mitigation_suggestions.append('ביטוח או גידור כלכלי')
            
            if 'זמן' in risk['type'] or 'לוח' in risk['type']:
                mitigation_suggestions.append('הוספת זמן חצי לתכנון')
                mitigation_suggestions.append('הכנת תוכנית מואצת')
            
            if 'טכנולוגי' in risk['type']:
                mitigation_suggestions.append('בדיקות מקדימות נוספות')
                mitigation_suggestions.append('הכנת פתרון גיבוי טכנולוגי')
        
        return list(set(mitigation_suggestions))  # הסרת כפילויות
    
    def _define_trigger_conditions(self, decision_metadata: DecisionMetadata) -> List[str]:
        """מגדיר תנאי הפעלה לתוכנית חירום"""
        conditions = [
            'סטיית עלות מעל 20% מהתקציב המתוכנן',
            'עיכוב של מעל שבועיים מלוח הזמנים',
            'ירידה משמעותית ברמת שביעות הרצון'
        ]
        
        if decision_metadata.decision_type == DecisionType.STRATEGIC:
            conditions.extend([
                'שינוי במדיניות ארגונית',
                'שינויים מהותיים בסביבה החיצונית'
            ])
        
        return conditions
    
    def _create_rollback_plan(self) -> Dict:
        """יוצר תוכנית חזרה לאחור"""
        return {
            'steps': [
                'הפסקת יישום מיידית',
                'הערכת נזקים',
                'החזרה למצב קודם',
                'ניתוח כישלון ולקחים'
            ],
            'required_resources': 'צוות חירום ותקציב לשחזור',
            'estimated_time': '2-5 ימי עבודה'
        }
    
    def _define_escalation_procedures(self, decision_metadata: DecisionMetadata) -> List[str]:
        """מגדיר נהלי הסלמה"""
        procedures = [
            'דיווח מיידי למקבל ההחלטות הראשי',
            'כינוס ועדת חירום',
            'הפעלת תוכנית גיבוי'
        ]
        
        if decision_metadata.priority.value >= 4:
            procedures.insert(0, 'התראה מיידית לניהול הבכיר')
        
        return procedures
    
    def _get_improvement_suggestions(self, criterion_name: str) -> List[str]:
        """מחזיר הצעות שיפור לקריטריון ספציפי"""
        suggestions_map = {
            'עלות': [
                'חיפוש ספקים חלופיים',
                'משא ומתן על מחירים',
                'אופטימיזציה של תהליכים'
            ],
            'זמן': [
                'הקצאת משאבים נוספים',
                'עבודה במקביל במקום ברצף',
                'שיפור תהליכי עבודה'
            ],
            'איכות': [
                'הוספת בקרת איכות',
                'שיפור הכשרת הצוות',
                'שדרוג כלים וציוד'
            ]
        }
        
        for key, suggestions in suggestions_map.items():
            if key in criterion_name:
                return suggestions
        
        return ['בחינת אפשרויות שיפור נוספות', 'התייעצות עם מומחים', 'ביצוע מחקר נוסף']