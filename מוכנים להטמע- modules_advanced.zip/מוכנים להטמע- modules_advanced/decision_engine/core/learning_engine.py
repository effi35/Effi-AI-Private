"""
Learning Engine for Decision Making
מנוע למידה לקבלת החלטות
"""

import sqlite3
import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime, timedelta
import logging
import json
from collections import defaultdict

from ..models.decision_types import DecisionType, DecisionMetadata
from ..models.criteria import DecisionCriteria
from ..models.options import OptionEvaluation
from ..models.results import DecisionResult, DecisionOutcome
from ..models.config import DecisionEngineConfig

class LearningEngine:
    """מנוע למידה מתקדם לקבלת החלטות"""
    
    def __init__(self, config: DecisionEngineConfig):
        self.config = config
        self.logger = logging.getLogger("LearningEngine")
        
        # מאגר ידע ללמידה
        self.knowledge_base = {
            'decision_patterns': defaultdict(list),
            'success_patterns': defaultdict(list),
            'failure_patterns': defaultdict(list),
            'criteria_effectiveness': defaultdict(list),
            'option_performance': defaultdict(list)
        }
        
        # מדדי למידה
        self.learning_metrics = {
            'total_decisions_learned': 0,
            'accuracy_improvements': [],
            'pattern_discoveries': 0,
            'prediction_accuracy': 0.0
        }
        
        # טעינת ידע קיים
        self._load_historical_knowledge()
        
    def learn_from_decision(self, 
                          decision_data: Dict, 
                          evaluations: List[OptionEvaluation]) -> Dict[str, Any]:
        """לומד מהחלטה שבוצעה"""
        
        self.logger.info(f"לומד מהחלטה: {decision_data.get('metadata', {}).get('hebrew_title', 'ללא כותרת')}")
        
        metadata = decision_data['metadata']
        criteria = decision_data['criteria']
        options = decision_data['options']
        
        # איסוף דפוסי החלטה
        decision_pattern = self._extract_decision_pattern(metadata, criteria, options)
        self.knowledge_base['decision_patterns'][metadata.decision_type.value].append(decision_pattern)
        
        # ניתוח יעילות קריטריונים
        criteria_analysis = self._analyze_criteria_effectiveness(criteria, evaluations)
        
        # לימוד מביצועי אפשרויות
        option_learning = self._learn_from_options(options, evaluations)
        
        # עדכון מדדי למידה
        self.learning_metrics['total_decisions_learned'] += 1
        
        # זיהוי דפוסים חדשים
        new_patterns = self._discover_new_patterns(decision_pattern, criteria_analysis)
        if new_patterns:
            self.learning_metrics['pattern_discoveries'] += len(new_patterns)
        
        learning_insights = {
            'decision_pattern': decision_pattern,
            'criteria_insights': criteria_analysis,
            'option_insights': option_learning,
            'new_patterns': new_patterns,
            'learning_impact': self._calculate_learning_impact()
        }
        
        # שמירת ידע חדש
        self._save_learning_insights(learning_insights)
        
        return learning_insights
    
    def learn_from_outcome(self, 
                          decision_id: str, 
                          actual_result: DecisionResult) -> Dict[str, Any]:
        """לומד מתוצאות החלטה בפועל"""
        
        self.logger.info(f"לומד מתוצאות החלטה: {decision_id}")
        
        # השוואה בין צפוי למעשי
        prediction_accuracy = self._calculate_prediction_accuracy(actual_result)
        
        # זיהוי גורמי הצלחה וכישלון
        success_factors, failure_factors = self._identify_success_failure_factors(actual_result)
        
        # עדכון דפוסי הצלחה וכישלון
        if actual_result.calculate_overall_success() > 0.7:
            self.knowledge_base['success_patterns'][actual_result.selected_option_id].append({
                'factors': success_factors,
                'outcomes': actual_result.outcomes,
                'context': actual_result.notes
            })
        elif actual_result.calculate_overall_success() < 0.3:
            self.knowledge_base['failure_patterns'][actual_result.selected_option_id].append({
                'factors': failure_factors,
                'outcomes': actual_result.outcomes,
                'context': actual_result.notes
            })
        
        # עדכון דיוק תחזיות
        self.learning_metrics['accuracy_improvements'].append(prediction_accuracy)
        self.learning_metrics['prediction_accuracy'] = np.mean(
            self.learning_metrics['accuracy_improvements'][-10:]  # ממוצע של 10 האחרונות
        )
        
        outcome_insights = {
            'prediction_accuracy': prediction_accuracy,
            'success_factors': success_factors,
            'failure_factors': failure_factors,
            'lessons_learned': self._extract_lessons_learned(actual_result),
            'updated_patterns': self._update_learning_patterns(actual_result)
        }
        
        return outcome_insights
    
    def predict_decision_success(self, 
                                decision_data: Dict, 
                                selected_option_id: str) -> Dict[str, Any]:
        """מנבא הצלחת החלטה בהתבסס על למידה קודמת"""
        
        metadata = decision_data['metadata']
        criteria = decision_data['criteria']
        options = decision_data['options']
        
        # מציאת האפשרות הנבחרת
        selected_option = next((opt for opt in options if opt.id == selected_option_id), None)
        if not selected_option:
            return {'error': 'אפשרות נבחרת לא נמצאה'}
        
        # חיפוש דפוסים דומים
        similar_patterns = self._find_similar_patterns(metadata, criteria, selected_option)
        
        # חישוב הסתברות הצלחה
        success_probability = self._calculate_success_probability(similar_patterns)
        
        # זיהוי סיכונים פוטנציאליים
        potential_risks = self._identify_potential_risks(similar_patterns, selected_option)
        
        # המלצות לשיפור סיכויי הצלחה
        improvement_recommendations = self._suggest_success_improvements(
            similar_patterns, selected_option
        )
        
        prediction = {
            'success_probability': success_probability,
            'confidence_level': self._calculate_prediction_confidence(similar_patterns),
            'similar_cases_found': len(similar_patterns),
            'potential_risks': potential_risks,
            'improvement_recommendations': improvement_recommendations,
            'predicted_outcomes': self._predict_specific_outcomes(similar_patterns),
            'timeline_prediction': self._predict_implementation_timeline(similar_patterns)
        }
        
        return prediction
    
    def get_learning_insights(self) -> Dict[str, Any]:
        """מחזיר תובנות למידה כלליות"""
        
        insights = {
            'learning_summary': {
                'total_decisions_analyzed': self.learning_metrics['total_decisions_learned'],
                'patterns_discovered': self.learning_metrics['pattern_discoveries'],
                'current_accuracy': self.learning_metrics['prediction_accuracy']
            },
            'top_success_patterns': self._get_top_success_patterns(),
            'common_failure_patterns': self._get_common_failure_patterns(),
            'most_effective_criteria': self._get_most_effective_criteria(),
            'decision_type_insights': self._get_decision_type_insights(),
            'improvement_trends': self._analyze_improvement_trends()
        }
        
        return insights
    
    def suggest_criteria_weights(self, 
                                decision_type: DecisionType, 
                                context: Dict = None) -> Dict[str, float]:
        """מציע משקלי קריטריונים בהתבסס על למידה"""
        
        # חיפוש החלטות דומות
        similar_decisions = self.knowledge_base['decision_patterns'].get(decision_type.value, [])
        
        if not similar_decisions:
            # משקלים ברירת מחדל
            return self.config.default_weights
        
        # ניתוח יעילות קריטריונים בהחלטות דומות
        criteria_effectiveness = defaultdict(list)
        
        for pattern in similar_decisions:
            for criterion_id, effectiveness in pattern.get('criteria_effectiveness', {}).items():
                criteria_effectiveness[criterion_id].append(effectiveness)
        
        # חישוב משקלים מומלצים
        suggested_weights = {}
        total_weight = 0
        
        for criterion_id, effectiveness_scores in criteria_effectiveness.items():
            avg_effectiveness = np.mean(effectiveness_scores)
            suggested_weights[criterion_id] = avg_effectiveness
            total_weight += avg_effectiveness
        
        # נירמול משקלים
        if total_weight > 0:
            for criterion_id in suggested_weights:
                suggested_weights[criterion_id] /= total_weight
        
        return suggested_weights
    
    def _extract_decision_pattern(self, 
                                 metadata: DecisionMetadata, 
                                 criteria: List[DecisionCriteria], 
                                 options: List) -> Dict:
        """מחלץ דפוס החלטה"""
        
        pattern = {
            'decision_type': metadata.decision_type.value,
            'priority': metadata.priority.value,
            'criteria_count': len(criteria),
            'options_count': len(options),
            'criteria_types': [c.criteria_type.value for c in criteria],
            'criteria_weights': {c.id: c.weight.weight for c in criteria},
            'complexity_indicators': {
                'has_quantitative_criteria': any(c.criteria_type.value == 'quantitative' for c in criteria),
                'has_qualitative_criteria': any(c.criteria_type.value == 'qualitative' for c in criteria),
                'weight_distribution': np.std([c.weight.weight for c in criteria]),
                'decision_urgency': self._calculate_urgency_score(metadata)
            },
            'timestamp': datetime.now()
        }
        
        return pattern
    
    def _analyze_criteria_effectiveness(self, 
                                      criteria: List[DecisionCriteria], 
                                      evaluations: List[OptionEvaluation]) -> Dict:
        """מנתח יעילות קריטריונים"""
        
        effectiveness_analysis = {}
        
        for criterion in criteria:
            criterion_scores = []
            
            # איסוף ניקודים של הקריטריון מכל ההערכות
            for evaluation in evaluations:
                for score in evaluation.criteria_scores:
                    if score.criteria_id == criterion.id:
                        criterion_scores.append({
                            'score': score.normalized_score,
                            'confidence': score.confidence,
                            'weighted_impact': score.weighted_score
                        })
            
            if criterion_scores:
                scores = [s['score'] for s in criterion_scores]
                confidences = [s['confidence'] for s in criterion_scores]
                
                effectiveness_analysis[criterion.id] = {
                    'discrimination_power': np.std(scores),  # כוח הבחנה
                    'average_confidence': np.mean(confidences),
                    'score_range': max(scores) - min(scores),
                    'weight_efficiency': criterion.weight.weight / max(np.std(scores), 0.01),
                    'overall_effectiveness': self._calculate_criterion_effectiveness(criterion_scores)
                }
        
        return effectiveness_analysis
    
    def _learn_from_options(self, 
                           options: List, 
                           evaluations: List[OptionEvaluation]) -> Dict:
        """לומד מביצועי אפשרויות"""
        
        option_insights = {}
        
        for option in options:
            # מציאת ההערכה של האפשרות
            option_evaluation = next(
                (eval for eval in evaluations if eval.option_id == option.id), 
                None
            )
            
            if option_evaluation:
                # ניתוח חוזקות וחולשות
                strengths = []
                weaknesses = []
                
                for score in option_evaluation.criteria_scores:
                    if score.normalized_score > 0.7:
                        strengths.append(score.criteria_id)
                    elif score.normalized_score < 0.3:
                        weaknesses.append(score.criteria_id)
                
                option_insights[option.id] = {
                    'total_score': option_evaluation.total_score,
                    'strengths': strengths,
                    'weaknesses': weaknesses,
                    'performance_profile': {
                        score.criteria_id: score.normalized_score 
                        for score in option_evaluation.criteria_scores
                    },
                    'option_characteristics': {
                        'complexity': option.metrics.complexity_score,
                        'risk_level': option.metrics.risk_score,
                        'expected_value': option.metrics.expected_value
                    }
                }
        
        return option_insights
    
    def _discover_new_patterns(self, 
                              decision_pattern: Dict, 
                              criteria_analysis: Dict) -> List[Dict]:
        """מגלה דפוסים חדשים"""
        
        new_patterns = []
        
        # דפוס קריטריונים יעילים
        effective_criteria = [
            criterion_id for criterion_id, analysis in criteria_analysis.items()
            if analysis['overall_effectiveness'] > 0.8
        ]
        
        if len(effective_criteria) >= 2:
            new_patterns.append({
                'type': 'effective_criteria_combination',
                'criteria_ids': effective_criteria,
                'decision_type': decision_pattern['decision_type'],
                'effectiveness_score': np.mean([
                    criteria_analysis[cid]['overall_effectiveness'] 
                    for cid in effective_criteria
                ])
            })
        
        # דפוס משקלים אופטימליים
        weights = list(decision_pattern['criteria_weights'].values())
        if len(weights) > 2:
            weight_balance = 1 - np.std(weights)  # איזון טוב = סטיית תקן נמוכה
            
            if weight_balance > 0.7:
                new_patterns.append({
                    'type': 'balanced_weights_pattern',
                    'weight_distribution': decision_pattern['criteria_weights'],
                    'balance_score': weight_balance,
                    'decision_type': decision_pattern['decision_type']
                })
        
        return new_patterns
    
    def _calculate_learning_impact(self) -> float:
        """מחשב השפעת הלמידה על ביצועים"""
        
        if len(self.learning_metrics['accuracy_improvements']) < 2:
            return 0.0
        
        recent_accuracy = np.mean(self.learning_metrics['accuracy_improvements'][-5:])
        early_accuracy = np.mean(self.learning_metrics['accuracy_improvements'][:5])
        
        improvement = recent_accuracy - early_accuracy
        return max(0, improvement)
    
    def _find_similar_patterns(self, 
                              metadata: DecisionMetadata, 
                              criteria: List[DecisionCriteria], 
                              selected_option) -> List[Dict]:
        """מוצא דפוסים דומים בבסיס הידע"""
        
        similar_patterns = []
        decision_patterns = self.knowledge_base['decision_patterns'].get(metadata.decision_type.value, [])
        
        for pattern in decision_patterns:
            similarity_score = self._calculate_pattern_similarity(
                metadata, criteria, selected_option, pattern
            )
            
            if similarity_score > 0.6:  # סף דמיון
                pattern['similarity_score'] = similarity_score
                similar_patterns.append(pattern)
        
        # מיון לפי דמיון
        similar_patterns.sort(key=lambda x: x['similarity_score'], reverse=True)
        
        return similar_patterns[:10]  # עד 10 דפוסים דומים
    
    def _calculate_success_probability(self, similar_patterns: List[Dict]) -> float:
        """מחשב הסתברות הצלחה"""
        
        if not similar_patterns:
            return 0.5  # הסתברות ברירת מחדל
        
        # חיפוש תוצאות של דפוסים דומים בבסיס הידע
        success_rates = []
        
        for pattern in similar_patterns:
            # כאן נבדוק בבסיס הנתונים את תוצאות החלטות דומות
            # לצורך הדגמה, נשתמש בהסתברות סינתטית
            
            complexity = pattern.get('complexity_indicators', {})
            urgency = complexity.get('decision_urgency', 0.5)
            weight_balance = 1 - complexity.get('weight_distribution', 0.5)
            
            # חישוב הסתברות בהתבסס על מאפיינים
            estimated_success = (weight_balance * 0.4) + ((1 - urgency) * 0.3) + 0.3
            success_rates.append(estimated_success)
        
        return np.mean(success_rates)
    
    def _calculate_urgency_score(self, metadata: DecisionMetadata) -> float:
        """מחשב ניקוד דחיפות"""
        urgency = 0.0
        
        # בהתבסס על עדיפות
        urgency += metadata.priority.value / 5.0 * 0.4
        
        # בהתבסס על דדליין
        if metadata.deadline:
            time_left = metadata.deadline - datetime.now()
            if time_left < timedelta(days=1):
                urgency += 0.4
            elif time_left < timedelta(days=7):
                urgency += 0.2
        
        # בהתבסס על סוג החלטה
        if metadata.decision_type == DecisionType.EMERGENCY:
            urgency += 0.2
        
        return min(1.0, urgency)
    
    def _calculate_criterion_effectiveness(self, criterion_scores: List[Dict]) -> float:
        """מחשב יעילות קריטריון"""
        if not criterion_scores:
            return 0.0
        
        # ניקוד בהתבסס על כוח הבחנה, ביטחון והשפעה
        scores = [s['score'] for s in criterion_scores]
        confidences = [s['confidence'] for s in criterion_scores]
        impacts = [s['weighted_impact'] for s in criterion_scores]
        
        discrimination = np.std(scores)  # כוח הבחנה
        avg_confidence = np.mean(confidences)  # ביטחון ממוצע
        avg_impact = np.mean(impacts)  # השפעה ממוצעת
        
        effectiveness = (discrimination * 0.4) + (avg_confidence * 0.3) + (avg_impact * 0.3)
        return min(1.0, effectiveness)
    
    def _save_learning_insights(self, insights: Dict):
        """שומר תובנות למידה"""
        # כאן נשמור לבסיס נתונים או קובץ
        self.logger.info(f"נשמרו תובנות למידה: {len(insights)} פריטים")
    
    def _load_historical_knowledge(self):
        """טוען ידע היסטורי"""
        # כאן נטען מבסיס נתונים או קובץ
        self.logger.info("נטען ידע היסטורי")
    
    # Additional helper methods for other functionalities...
    def _calculate_prediction_accuracy(self, actual_result: DecisionResult) -> float:
        """מחשב דיוק תחזית"""
        # Placeholder implementation
        return 0.75
    
    def _identify_success_failure_factors(self, result: DecisionResult) -> Tuple[List[str], List[str]]:
        """מזהה גורמי הצלחה וכישלון"""
        return result.success_factors, result.failure_factors
    
    def _extract_lessons_learned(self, result: DecisionResult) -> List[str]:
        """מחלץ לקחים נלמדים"""
        return result.lessons_learned
    
    def _update_learning_patterns(self, result: DecisionResult) -> Dict:
        """מעדכן דפוסי למידה"""
        return {'updated': True}
    
    def _identify_potential_risks(self, patterns: List[Dict], option) -> List[str]:
        """מזהה סיכונים פוטנציאליים"""
        return ['סיכון לעיכוב בלוח זמנים', 'סיכון לחריגה מתקציב']
    
    def _suggest_success_improvements(self, patterns: List[Dict], option) -> List[str]:
        """מציע שיפורים להצלחה"""
        return ['הוספת מעקב צמוד', 'הקצאת משאבים נוספים']
    
    def _predict_specific_outcomes(self, patterns: List[Dict]) -> Dict:
        """מנבא תוצאות ספציפיות"""
        return {'predicted_duration': '2-3 שבועות', 'predicted_cost': '₪50,000'}
    
    def _predict_implementation_timeline(self, patterns: List[Dict]) -> str:
        """מנבא לוח זמנים ליישום"""
        return '4-6 שבועות'
    
    def _calculate_prediction_confidence(self, patterns: List[Dict]) -> float:
        """מחשב רמת ביטחון בתחזית"""
        if not patterns:
            return 0.3
        return min(0.9, 0.5 + (len(patterns) * 0.05))
    
    def _calculate_pattern_similarity(self, metadata, criteria, option, pattern) -> float:
        """מחשב דמיון בין דפוסים"""
        similarity = 0.0
        
        # דמיון בסוג החלטה
        if pattern.get('decision_type') == metadata.decision_type.value:
            similarity += 0.3
        
        # דמיון במספר קריטריונים
        criteria_diff = abs(len(criteria) - pattern.get('criteria_count', 0))
        similarity += max(0, 0.2 - (criteria_diff * 0.05))
        
        # דמיון בעדיפות
        priority_diff = abs(metadata.priority.value - pattern.get('priority', 3))
        similarity += max(0, 0.2 - (priority_diff * 0.05))
        
        # דמיון במורכבות
        if hasattr(option, 'metrics'):
            complexity_diff = abs(option.metrics.complexity_score - 
                                pattern.get('complexity_indicators', {}).get('avg_complexity', 3))
            similarity += max(0, 0.3 - (complexity_diff * 0.1))
        
        return similarity
    
    def _get_top_success_patterns(self) -> List[Dict]:
        """מחזיר דפוסי הצלחה מובילים"""
        return []  # Placeholder
    
    def _get_common_failure_patterns(self) -> List[Dict]:
        """מחזיר דפוסי כישלון נפוצים"""
        return []  # Placeholder
    
    def _get_most_effective_criteria(self) -> List[Dict]:
        """מחזיר קריטריונים יעילים ביותר"""
        return []  # Placeholder
    
    def _get_decision_type_insights(self) -> Dict:
        """מחזיר תובנות לפי סוג החלטה"""
        return {}  # Placeholder
    
    def _analyze_improvement_trends(self) -> Dict:
        """מנתח מגמות שיפור"""
        return {}  # Placeholder