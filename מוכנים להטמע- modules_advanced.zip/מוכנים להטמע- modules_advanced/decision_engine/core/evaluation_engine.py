"""
Evaluation Engine for Decision Options
מנוע הערכת אפשרויות החלטה
"""

from typing import List, Dict, Any, Optional
import numpy as np
from datetime import datetime
import logging

from ..models.criteria import DecisionCriteria, CriteriaType, CriteriaEvaluation
from ..models.options import DecisionOption, OptionEvaluation, CriteriaScore
from ..models.config import DecisionEngineConfig

class EvaluationEngine:
    """מנוע הערכת אפשרויות"""
    
    def __init__(self, config: DecisionEngineConfig):
        self.config = config
        self.logger = logging.getLogger("EvaluationEngine")
        
        # מטמון הערכות
        self.evaluation_cache: Dict[str, Any] = {}
    
    def evaluate_options(self, 
                        options: List[DecisionOption], 
                        criteria: List[DecisionCriteria]) -> List[OptionEvaluation]:
        """מבצע הערכה של כל האפשרויות לפי הקריטריונים"""
        
        evaluations = []
        
        for option in options:
            self.logger.info(f"מעריך אפשרות: {option.hebrew_name}")
            
            evaluation = self._evaluate_single_option(option, criteria)
            evaluations.append(evaluation)
        
        self.logger.info(f"הערכה הושלמה עבור {len(evaluations)} אפשרויות")
        return evaluations
    
    def _evaluate_single_option(self, 
                               option: DecisionOption, 
                               criteria: List[DecisionCriteria]) -> OptionEvaluation:
        """מבצע הערכה של אפשרות יחידה"""
        
        criteria_scores = []
        
        for criterion in criteria:
            score = self._evaluate_criterion_for_option(option, criterion)
            criteria_scores.append(score)
        
        # יצירת הערכה
        evaluation = OptionEvaluation(
            option_id=option.id,
            evaluation_id=f"eval_{option.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            timestamp=datetime.now(),
            evaluator="EvaluationEngine",
            criteria_scores=criteria_scores,
            total_score=0.0
        )
        
        # חישוב ניקוד כולל
        evaluation.calculate_total_score()
        
        return evaluation
    
    def _evaluate_criterion_for_option(self, 
                                     option: DecisionOption, 
                                     criterion: DecisionCriteria) -> CriteriaScore:
        """מעריך קריטריון ספציפי עבור אפשרות"""
        
        # קבלת ערך גולמי
        raw_value = self._get_raw_value(option, criterion)
        
        # נירמול הערך
        normalized_score = self._normalize_value(raw_value, criterion)
        
        # חישוב ניקוד משוקלל
        weighted_score = normalized_score * criterion.weight.weight
        
        # הערכת רמת ביטחון
        confidence = self._calculate_confidence(option, criterion)
        
        # יצירת הצדקה
        justification, hebrew_justification = self._generate_justification(
            option, criterion, raw_value, normalized_score
        )
        
        return CriteriaScore(
            criteria_id=criterion.id,
            raw_value=raw_value,
            normalized_score=normalized_score,
            weighted_score=weighted_score,
            confidence=confidence,
            justification=justification,
            hebrew_justification=hebrew_justification
        )
    
    def _get_raw_value(self, option: DecisionOption, criterion: DecisionCriteria) -> Any:
        """מקבל ערך גולמי עבור קריטריון מאפשרות"""
        
        # ניסיון למצוא ערך בנתוני האפשרות
        criterion_name = criterion.name.lower()
        
        # חיפוש בעלויות
        if "cost" in criterion_name:
            if option.costs:
                return sum(option.costs.values())
            return option.metrics.expected_value if option.metrics.expected_value < 0 else 0
        
        # חיפוש בסיכונים
        if "risk" in criterion_name:
            return option.metrics.risk_score * 5  # המרה לסקלה 1-5
        
        # חיפוש בזמן
        if "time" in criterion_name or "timeline" in criterion_name:
            return option.metrics.implementation_effort * 30  # המרה לימים
        
        # חיפוש במורכבות
        if "complex" in criterion_name:
            return option.metrics.complexity_score
        
        # חיפוש ביתרונות
        if "benefit" in criterion_name or "value" in criterion_name:
            if option.benefits:
                return sum(option.benefits.values())
            return max(0, option.metrics.expected_value)
        
        # חיפוש בהסתברות הצלחה
        if "success" in criterion_name or "probability" in criterion_name:
            return option.metrics.probability_success * 5  # המרה לסקלה 1-5
        
        # התאמה אסטרטגית (הערכה איכותית)
        if "strategic" in criterion_name or "alignment" in criterion_name:
            # הערכה בהתבסס על תיאור האפשרות
            description_lower = option.description.lower()
            if any(word in description_lower for word in ["strategic", "long-term", "growth"]):
                return 4.5
            elif any(word in description_lower for word in ["maintain", "current", "stable"]):
                return 3.0
            else:
                return 2.5
        
        # ערך ברירת מחדל
        return 3.0  # ניקוד בינוני
    
    def _normalize_value(self, raw_value: Any, criterion: DecisionCriteria) -> float:
        """מנרמל ערך לטווח 0-1"""
        
        if isinstance(raw_value, bool):
            return 1.0 if raw_value else 0.0
        
        if isinstance(raw_value, str):
            # הערכה איכותית
            return self._evaluate_qualitative_value(raw_value, criterion)
        
        # הערכה כמותית
        numeric_value = float(raw_value)
        
        # אם יש טווח מוגדר
        if criterion.min_value is not None and criterion.max_value is not None:
            min_val = criterion.min_value
            max_val = criterion.max_value
            
            # בדיקה אם צריך להפוך (עלות = נמוך יותר טוב)
            if "cost" in criterion.name.lower() or "risk" in criterion.name.lower():
                # עבור עלות וסיכון - ערך נמוך יותר טוב
                normalized = 1.0 - ((numeric_value - min_val) / (max_val - min_val))
            else:
                # עבור יתרונות - ערך גבוה יותר טוב
                normalized = (numeric_value - min_val) / (max_val - min_val)
            
            return max(0.0, min(1.0, normalized))
        
        # נירמול סטנדרטי לטווח 0-1
        if criterion.criteria_type == CriteriaType.RANKING:
            # עבור דירוג 1-5
            return (numeric_value - 1) / 4
        
        # נירמול ברירת מחדל
        return max(0.0, min(1.0, numeric_value / 5.0))
    
    def _evaluate_qualitative_value(self, value: str, criterion: DecisionCriteria) -> float:
        """מעריך ערך איכותי"""
        
        value_lower = value.lower()
        
        # מילות מפתח חיוביות
        positive_keywords = ["excellent", "very good", "high", "strong", "effective", "optimal"]
        # מילות מפתח שליליות
        negative_keywords = ["poor", "weak", "low", "ineffective", "problematic"]
        
        positive_score = sum(1 for keyword in positive_keywords if keyword in value_lower)
        negative_score = sum(1 for keyword in negative_keywords if keyword in value_lower)
        
        if positive_score > negative_score:
            return 0.8
        elif negative_score > positive_score:
            return 0.2
        else:
            return 0.5
    
    def _calculate_confidence(self, option: DecisionOption, criterion: DecisionCriteria) -> float:
        """מחשב רמת ביטחון בהערכה"""
        
        base_confidence = option.metrics.confidence_level
        
        # התאמת רמת ביטחון לפי סוג קריטריון
        if criterion.criteria_type == CriteriaType.QUANTITATIVE:
            # נתונים כמותיים - ביטחון גבוה יותר
            return min(1.0, base_confidence + 0.1)
        elif criterion.criteria_type == CriteriaType.QUALITATIVE:
            # נתונים איכותיים - ביטחון נמוך יותר
            return max(0.3, base_confidence - 0.2)
        
        return base_confidence
    
    def _generate_justification(self, 
                              option: DecisionOption, 
                              criterion: DecisionCriteria, 
                              raw_value: Any, 
                              normalized_score: float) -> tuple:
        """מייצר הצדקה לניקוד"""
        
        score_level = "גבוה" if normalized_score > 0.7 else "בינוני" if normalized_score > 0.3 else "נמוך"
        
        justification = f"Option '{option.name}' scored {score_level} on '{criterion.name}' with value {raw_value}"
        hebrew_justification = f"אפשרות '{option.hebrew_name}' קיבלה ניקוד {score_level} בקריטריון '{criterion.hebrew_name}' עם ערך {raw_value}"
        
        return justification, hebrew_justification
    
    def recalculate_evaluation(self, 
                             evaluation: OptionEvaluation, 
                             updated_criteria: List[DecisionCriteria]) -> OptionEvaluation:
        """מחשב מחדש הערכה עם קריטריונים מעודכנים"""
        
        self.logger.info(f"מחשב מחדש הערכה: {evaluation.evaluation_id}")
        
        # עדכון ניקודים משוקללים
        for score in evaluation.criteria_scores:
            # מציאת הקריטריון המעודכן
            updated_criterion = next(
                (c for c in updated_criteria if c.id == score.criteria_id), 
                None
            )
            
            if updated_criterion:
                score.weighted_score = score.normalized_score * updated_criterion.weight.weight
        
        # חישוב מחדש של הניקוד הכולל
        evaluation.calculate_total_score()
        
        return evaluation
    
    def compare_options(self, 
                       evaluations: List[OptionEvaluation], 
                       criteria: List[DecisionCriteria]) -> Dict[str, Any]:
        """משווה בין אפשרויות ומחזיר ניתוח השוואתי"""
        
        if len(evaluations) < 2:
            return {"error": "נדרשות לפחות 2 אפשרויות לשם השוואה"}
        
        # מיון לפי ניקוד כולל
        sorted_evaluations = sorted(evaluations, 
                                  key=lambda x: x.total_score, 
                                  reverse=True)
        
        best_option = sorted_evaluations[0]
        worst_option = sorted_evaluations[-1]
        
        # ניתוח פערים
        score_gaps = []
        for i in range(len(sorted_evaluations) - 1):
            gap = sorted_evaluations[i].total_score - sorted_evaluations[i + 1].total_score
            score_gaps.append(gap)
        
        # זיהוי קריטריונים מכריעים
        decisive_criteria = []
        for criterion in criteria:
            criterion_scores = []
            for evaluation in evaluations:
                criterion_score = next(
                    (s for s in evaluation.criteria_scores if s.criteria_id == criterion.id),
                    None
                )
                if criterion_score:
                    criterion_scores.append(criterion_score.weighted_score)
            
            if criterion_scores:
                score_range = max(criterion_scores) - min(criterion_scores)
                if score_range > 0.2:  # סף להבדל משמעותי
                    decisive_criteria.append({
                        'criterion': criterion,
                        'score_range': score_range,
                        'impact': score_range * criterion.weight.weight
                    })
        
        return {
            'best_option': best_option,
            'worst_option': worst_option,
            'ranking': [{'option_id': e.option_id, 'score': e.total_score} 
                       for e in sorted_evaluations],
            'score_gaps': score_gaps,
            'average_gap': sum(score_gaps) / len(score_gaps) if score_gaps else 0,
            'decisive_criteria': sorted(decisive_criteria, 
                                      key=lambda x: x['impact'], 
                                      reverse=True)[:3],
            'total_evaluations': len(evaluations)
        }