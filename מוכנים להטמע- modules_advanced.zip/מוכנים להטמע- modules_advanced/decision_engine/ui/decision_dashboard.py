"""
Decision Engine Dashboard
דשבורד מנוע קבלת החלטות
"""

import json
from datetime import datetime
from typing import Dict, List, Optional, Any

class DecisionDashboard:
    """דשבורד ראשי למנוע קבלת החלטות"""
    
    def __init__(self):
        self.current_decision = None
        self.decisions_cache = {}
        
    def render_main_dashboard(self) -> str:
        """מעבד דשבורד ראשי"""
        return f"""
        <div class="decision-dashboard" dir="rtl">
            <div class="dashboard-header">
                <h1 class="dashboard-title">מנוע קבלת החלטות מתקדם</h1>
                <div class="dashboard-stats">
                    {self._render_dashboard_stats()}
                </div>
            </div>
            
            <div class="dashboard-content">
                <div class="dashboard-row">
                    <div class="dashboard-column">
                        {self._render_quick_actions()}
                    </div>
                    <div class="dashboard-column">
                        {self._render_pending_decisions()}
                    </div>
                    <div class="dashboard-column">
                        {self._render_recent_decisions()}
                    </div>
                </div>
                
                <div class="dashboard-row">
                    <div class="dashboard-full-width">
                        {self._render_decision_wizard()}
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        {self._get_dashboard_styles()}
        </style>
        
        <script>
        {self._get_dashboard_scripts()}
        </script>
        """
    
    def _render_dashboard_stats(self) -> str:
        """מעבד סטטיסטיקות דשבורד"""
        return """
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number" id="total-decisions">0</div>
                <div class="stat-label">החלטות כולל</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="pending-decisions">0</div>
                <div class="stat-label">החלטות ממתינות</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="success-rate">0%</div>
                <div class="stat-label">אחוז הצלחה</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="avg-time">0</div>
                <div class="stat-label">זמן ממוצע (ימים)</div>
            </div>
        </div>
        """
    
    def _render_quick_actions(self) -> str:
        """מעבד פעולות מהירות"""
        return """
        <div class="panel quick-actions-panel">
            <h3 class="panel-title">פעולות מהירות</h3>
            <div class="quick-actions">
                <button class="action-btn primary" onclick="DecisionDashboard.createNewDecision()">
                    <i class="icon-plus"></i>
                    החלטה חדשה
                </button>
                <button class="action-btn secondary" onclick="DecisionDashboard.importTemplate()">
                    <i class="icon-template"></i>
                    טעינת תבנית
                </button>
                <button class="action-btn secondary" onclick="DecisionDashboard.viewAnalytics()">
                    <i class="icon-chart"></i>
                    אנליטיקה
                </button>
                <button class="action-btn secondary" onclick="DecisionDashboard.exportData()">
                    <i class="icon-export"></i>
                    ייצוא נתונים
                </button>
            </div>
        </div>
        """
    
    def _render_pending_decisions(self) -> str:
        """מעבד החלטות ממתינות"""
        return """
        <div class="panel pending-panel">
            <h3 class="panel-title">החלטות ממתינות</h3>
            <div class="pending-list" id="pending-decisions-list">
                <div class="loading-placeholder">טוען החלטות ממתינות...</div>
            </div>
            <div class="panel-footer">
                <button class="btn-link" onclick="DecisionDashboard.viewAllPending()">
                    צפה בכל ההחלטות הממתינות
                </button>
            </div>
        </div>
        """
    
    def _render_recent_decisions(self) -> str:
        """מעבד החלטות אחרונות"""
        return """
        <div class="panel recent-panel">
            <h3 class="panel-title">החלטות אחרונות</h3>
            <div class="recent-list" id="recent-decisions-list">
                <div class="loading-placeholder">טוען החלטות אחרונות...</div>
            </div>
            <div class="panel-footer">
                <button class="btn-link" onclick="DecisionDashboard.viewHistory()">
                    צפה בהיסטוריית החלטות
                </button>
            </div>
        </div>
        """
    
    def _render_decision_wizard(self) -> str:
        """מעבד אשף יצירת החלטות"""
        return """
        <div class="panel wizard-panel" id="decision-wizard" style="display: none;">
            <h3 class="panel-title">אשף יצירת החלטה</h3>
            
            <div class="wizard-steps">
                <div class="step active" data-step="1">
                    <div class="step-number">1</div>
                    <div class="step-title">פרטי בסיס</div>
                </div>
                <div class="step" data-step="2">
                    <div class="step-number">2</div>
                    <div class="step-title">קריטריונים</div>
                </div>
                <div class="step" data-step="3">
                    <div class="step-number">3</div>
                    <div class="step-title">אפשרויות</div>
                </div>
                <div class="step" data-step="4">
                    <div class="step-number">4</div>
                    <div class="step-title">הערכה</div>
                </div>
            </div>
            
            <div class="wizard-content">
                <div class="wizard-step-content" id="step-1-content">
                    {self._render_basic_info_step()}
                </div>
                <div class="wizard-step-content" id="step-2-content" style="display: none;">
                    <div class="criteria-builder-placeholder">בנאי קריטריונים יטען כאן...</div>
                </div>
                <div class="wizard-step-content" id="step-3-content" style="display: none;">
                    <div class="options-manager-placeholder">מנהל אפשרויות יטען כאן...</div>
                </div>
                <div class="wizard-step-content" id="step-4-content" style="display: none;">
                    <div class="evaluation-placeholder">מנוע הערכה יטען כאן...</div>
                </div>
            </div>
            
            <div class="wizard-actions">
                <button class="btn secondary" id="wizard-prev" onclick="DecisionDashboard.previousStep()" disabled>
                    הקודם
                </button>
                <button class="btn primary" id="wizard-next" onclick="DecisionDashboard.nextStep()">
                    הבא
                </button>
                <button class="btn success" id="wizard-finish" onclick="DecisionDashboard.finishDecision()" style="display: none;">
                    סיום
                </button>
            </div>
        </div>
        """
    
    def _render_basic_info_step(self) -> str:
        """מעבד שלב פרטי בסיס"""
        return """
        <div class="form-section">
            <h4>פרטי ההחלטה</h4>
            
            <div class="form-group">
                <label for="decision-title">כותרת ההחלטה</label>
                <input type="text" id="decision-title" class="form-control" 
                       placeholder="הזן כותרת מתארת להחלטה" required>
            </div>
            
            <div class="form-group">
                <label for="decision-description">תיאור ההחלטה</label>
                <textarea id="decision-description" class="form-control" rows="3"
                         placeholder="תאר את ההחלטה שצריך לקבל ואת ההקשר"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group half-width">
                    <label for="decision-type">סוג החלטה</label>
                    <select id="decision-type" class="form-control" required>
                        <option value="">בחר סוג החלטה</option>
                        <option value="strategic">אסטרטגית</option>
                        <option value="operational">תפעולית</option>
                        <option value="tactical">טקטית</option>
                        <option value="emergency">חירום</option>
                        <option value="routine">שגרתית</option>
                        <option value="creative">יצירתית</option>
                        <option value="analytical">אנליטית</option>
                        <option value="intuitive">אינטואיטיבית</option>
                    </select>
                </div>
                
                <div class="form-group half-width">
                    <label for="decision-priority">עדיפות</label>
                    <select id="decision-priority" class="form-control" required>
                        <option value="">בחר עדיפות</option>
                        <option value="5">קריטי</option>
                        <option value="4">גבוה</option>
                        <option value="3">בינוני</option>
                        <option value="2">נמוך</option>
                        <option value="1">מינימלי</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="decision-deadline">תאריך יעד (אופציונלי)</label>
                <input type="datetime-local" id="decision-deadline" class="form-control">
            </div>
            
            <div class="form-group">
                <label for="decision-tags">תגיות</label>
                <input type="text" id="decision-tags" class="form-control" 
                       placeholder="הזן תגיות מופרדות בפסיק">
                <small class="form-help">תגיות עוזרות לאירגון ומציאת החלטות דומות</small>
            </div>
        </div>
        """
    
    def _get_dashboard_styles(self) -> str:
        """מחזיר סגנונות CSS לדשבורד"""
        return """
        .decision-dashboard {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .dashboard-title {
            color: white;
            font-size: 2.5em;
            margin: 0 0 20px 0;
            text-align: center;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: white;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9em;
        }
        
        .dashboard-content {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        
        .dashboard-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .dashboard-full-width {
            grid-column: 1 / -1;
        }
        
        .panel {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            height: fit-content;
        }
        
        .panel-title {
            color: white;
            font-size: 1.3em;
            margin: 0 0 20px 0;
            border-bottom: 2px solid rgba(255, 255, 255, 0.2);
            padding-bottom: 10px;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .action-btn {
            background: linear-gradient(45deg, #FF6B6B, #4ECDC4);
            border: none;
            border-radius: 10px;
            padding: 15px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        .action-btn.primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
        }
        
        .action-btn.secondary {
            background: linear-gradient(45deg, #f093fb, #f5576c);
        }
        
        .wizard-panel {
            background: rgba(255, 255, 255, 0.05);
        }
        
        .wizard-steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }
        
        .wizard-steps::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 2px;
            background: rgba(255, 255, 255, 0.2);
            z-index: 1;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            position: relative;
            z-index: 2;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .step.active .step-number {
            background: linear-gradient(45deg, #667eea, #764ba2);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .step-title {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9em;
            text-align: center;
        }
        
        .step.active .step-title {
            color: white;
            font-weight: bold;
        }
        
        .wizard-content {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            min-height: 400px;
        }
        
        .wizard-actions {
            display: flex;
            justify-content: space-between;
            gap: 15px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn.primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn.secondary {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn.success {
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
        }
        
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .form-section h4 {
            color: white;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            padding-bottom: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: white;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.3);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .half-width {
            margin-bottom: 20px;
        }
        
        .form-help {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.85em;
            margin-top: 5px;
        }
        
        .loading-placeholder {
            color: rgba(255, 255, 255, 0.6);
            text-align: center;
            padding: 40px;
            font-style: italic;
        }
        
        .btn-link {
            background: none;
            border: none;
            color: #667eea;
            cursor: pointer;
            text-decoration: underline;
            font-size: 0.9em;
        }
        
        .btn-link:hover {
            color: #764ba2;
        }
        
        .panel-footer {
            margin-top: 20px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 15px;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-row {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .wizard-steps {
                flex-wrap: wrap;
                gap: 15px;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .panel {
            animation: fadeIn 0.6s ease-out;
        }
        """
    
    def _get_dashboard_scripts(self) -> str:
        """מחזיר סקריפטים JavaScript לדשבורד"""
        return """
        class DecisionDashboard {
            static currentStep = 1;
            static totalSteps = 4;
            static decisionData = {};
            
            static init() {
                this.loadDashboardData();
                this.setupEventListeners();
            }
            
            static loadDashboardData() {
                // טעינת נתוני דשבורד
                this.updateStats();
                this.loadPendingDecisions();
                this.loadRecentDecisions();
            }
            
            static updateStats() {
                // עדכון סטטיסטיקות
                document.getElementById('total-decisions').textContent = '0';
                document.getElementById('pending-decisions').textContent = '0';
                document.getElementById('success-rate').textContent = '0%';
                document.getElementById('avg-time').textContent = '0';
            }
            
            static loadPendingDecisions() {
                const list = document.getElementById('pending-decisions-list');
                list.innerHTML = '<div class="no-data">אין החלטות ממתינות</div>';
            }
            
            static loadRecentDecisions() {
                const list = document.getElementById('recent-decisions-list');
                list.innerHTML = '<div class="no-data">אין החלטות אחרונות</div>';
            }
            
            static createNewDecision() {
                document.getElementById('decision-wizard').style.display = 'block';
                this.currentStep = 1;
                this.updateWizardStep();
            }
            
            static nextStep() {
                if (this.validateCurrentStep()) {
                    this.saveStepData();
                    this.currentStep++;
                    this.updateWizardStep();
                }
            }
            
            static previousStep() {
                this.currentStep--;
                this.updateWizardStep();
            }
            
            static updateWizardStep() {
                // עדכון צעדי האשף
                document.querySelectorAll('.step').forEach((step, index) => {
                    if (index + 1 === this.currentStep) {
                        step.classList.add('active');
                    } else {
                        step.classList.remove('active');
                    }
                });
                
                // עדכון תוכן הצעדים
                document.querySelectorAll('.wizard-step-content').forEach((content, index) => {
                    if (index + 1 === this.currentStep) {
                        content.style.display = 'block';
                    } else {
                        content.style.display = 'none';
                    }
                });
                
                // עדכון כפתורים
                const prevBtn = document.getElementById('wizard-prev');
                const nextBtn = document.getElementById('wizard-next');
                const finishBtn = document.getElementById('wizard-finish');
                
                prevBtn.disabled = this.currentStep === 1;
                
                if (this.currentStep === this.totalSteps) {
                    nextBtn.style.display = 'none';
                    finishBtn.style.display = 'inline-block';
                } else {
                    nextBtn.style.display = 'inline-block';
                    finishBtn.style.display = 'none';
                }
            }
            
            static validateCurrentStep() {
                if (this.currentStep === 1) {
                    const title = document.getElementById('decision-title').value;
                    const type = document.getElementById('decision-type').value;
                    const priority = document.getElementById('decision-priority').value;
                    
                    if (!title || !type || !priority) {
                        alert('יש למלא את כל השדות הנדרשים');
                        return false;
                    }
                }
                return true;
            }
            
            static saveStepData() {
                if (this.currentStep === 1) {
                    this.decisionData.title = document.getElementById('decision-title').value;
                    this.decisionData.description = document.getElementById('decision-description').value;
                    this.decisionData.type = document.getElementById('decision-type').value;
                    this.decisionData.priority = document.getElementById('decision-priority').value;
                    this.decisionData.deadline = document.getElementById('decision-deadline').value;
                    this.decisionData.tags = document.getElementById('decision-tags').value;
                }
            }
            
            static finishDecision() {
                this.saveStepData();
                
                // שליחת נתונים לשרת
                fetch('/api/decisions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.decisionData)
                })
                .then(response => response.json())
                .then(data => {
                    alert('ההחלטה נוצרה בהצלחה!');
                    document.getElementById('decision-wizard').style.display = 'none';
                    this.loadDashboardData();
                })
                .catch(error => {
                    console.error('שגיאה ביצירת ההחלטה:', error);
                    alert('שגיאה ביצירת ההחלטה');
                });
            }
            
            static importTemplate() {
                // פתיחת דיאלוג טעינת תבנית
                alert('פונקציונליות טעינת תבנית תיושם בקרוב');
            }
            
            static viewAnalytics() {
                // פתיחת פאנל אנליטיקה
                alert('פונקציונליות אנליטיקה תיושם בקרוב');
            }
            
            static exportData() {
                // ייצוא נתונים
                alert('פונקציונליות ייצוא נתונים תיושם בקרוב');
            }
            
            static viewAllPending() {
                // צפייה בכל ההחלטות הממתינות
                alert('פונקציונליות צפייה בהחלטות ממתינות תיושם בקרוב');
            }
            
            static viewHistory() {
                // צפייה בהיסטוריית החלטות
                alert('פונקציונליות היסטוריית החלטות תיושם בקרוב');
            }
            
            static setupEventListeners() {
                // הוספת מאזיני אירועים נוספים
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape') {
                        const wizard = document.getElementById('decision-wizard');
                        if (wizard.style.display !== 'none') {
                            wizard.style.display = 'none';
                        }
                    }
                });
            }
        }
        
        // אתחול הדשבורד
        document.addEventListener('DOMContentLoaded', () => {
            DecisionDashboard.init();
        });
        """
    
    def create_decision_summary_card(self, decision_data: Dict) -> str:
        """יוצר כרטיס סיכום החלטה"""
        return f"""
        <div class="decision-card" data-decision-id="{decision_data.get('id', '')}">
            <div class="decision-header">
                <h4 class="decision-title">{decision_data.get('hebrew_title', 'ללא כותרת')}</h4>
                <div class="decision-priority priority-{decision_data.get('priority', 3)}">
                    {self._get_priority_text(decision_data.get('priority', 3))}
                </div>
            </div>
            <div class="decision-meta">
                <span class="decision-type">{self._get_type_text(decision_data.get('type', ''))}</span>
                <span class="decision-date">{decision_data.get('created_at', '')}</span>
            </div>
            <div class="decision-description">
                {decision_data.get('hebrew_description', '')[:100]}...
            </div>
            <div class="decision-actions">
                <button class="btn-action" onclick="DecisionDashboard.openDecision('{decision_data.get('id', '')}')">
                    פתח
                </button>
                <button class="btn-action secondary" onclick="DecisionDashboard.editDecision('{decision_data.get('id', '')}')">
                    ערוך
                </button>
            </div>
        </div>
        """
    
    def _get_priority_text(self, priority: int) -> str:
        """מחזיר טקסט עדיפות"""
        priority_map = {
            5: "קריטי",
            4: "גבוה", 
            3: "בינוני",
            2: "נמוך",
            1: "מינימלי"
        }
        return priority_map.get(priority, "בינוני")
    
    def _get_type_text(self, decision_type: str) -> str:
        """מחזיר טקסט סוג החלטה"""
        type_map = {
            "strategic": "אסטרטגית",
            "operational": "תפעולית",
            "tactical": "טקטית", 
            "emergency": "חירום",
            "routine": "שגרתית",
            "creative": "יצירתית",
            "analytical": "אנליטית",
            "intuitive": "אינטואיטיבית"
        }
        return type_map.get(decision_type, "לא ידוע")