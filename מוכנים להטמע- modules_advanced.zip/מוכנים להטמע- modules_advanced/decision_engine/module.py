"""
Decision Engine Module
מודול מנוע קבלת החלטות מתקדם
"""

from .core.decision_engine import DecisionEngine
from .models import *
from .ui.decision_dashboard import DecisionDashboard
from .utils import *

__version__ = "1.0.0"
__author__ = "Effi AI Private"
__description__ = "Advanced Decision Making Engine with AI-powered recommendations"

class DecisionEngineModule:
    """מודול מנוע קבלת החלטות"""
    
    def __init__(self, config=None):
        self.engine = DecisionEngine(config)
        self.dashboard = DecisionDashboard()
        
    def get_info(self):
        return {
            'name': 'Decision Engine',
            'hebrew_name': 'מנוע קבלת החלטות',
            'version': __version__,
            'description': __description__,
            'author': __author__,
            'capabilities': [
                'Multi-criteria decision analysis',
                'AI-powered recommendations', 
                'Learning from outcomes',
                'Hebrew language support',
                'Cultural adaptation for Israel'
            ]
        }

# Main module interface
def create_engine(config=None):
    """יוצר מופע של מנוע קבלת החלטות"""
    return DecisionEngineModule(config)