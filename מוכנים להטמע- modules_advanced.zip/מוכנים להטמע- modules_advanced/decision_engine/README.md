# Decision Engine - מנוע קבלת החלטות מתקדם

## תיאור כללי
מנוע קבלת החלטות מתקדם המיועד לסייע בתהליכי קבלת החלטות מורכבים באמצעות ניתוח מדעי, הערכת אפשרויות, וחישוב ניקודים משוקללים.

## ארכיטקטורה

### Models (מודלים)
- **decision_types.py** - סוגי החלטות, עדיפויות וסטטוסים
- **criteria.py** - קריטריונים להחלטה ומשקלים
- **options.py** - אפשרויות החלטה והערכות
- **results.py** - תוצאות החלטות ותוצאות
- **config.py** - הגדרות מנוע קבלת החלטות

### Core (ליבה)
- **decision_engine.py** - מנוע קבלת החלטות ראשי
- **evaluation_engine.py** - מנוע הערכת אפשרויות
- **scoring_engine.py** - מנוע חישוב ניקודים
- **recommendation_engine.py** - מנוע המלצות
- **learning_engine.py** - מנוע למידה

### UI (ממשק משתמש)
- **decision_dashboard.py** - דשבורד ראשי
- **criteria_builder.py** - בונה קריטריונים
- **options_manager.py** - מנהל אפשרויות
- **results_viewer.py** - מציג תוצאות
- **analytics_panel.py** - פאנל אנליטיקה

### Utils (עזרים)
- **decision_utils.py** - עזרים כלליים להחלטות
- **evaluation_utils.py** - עזרים להערכה
- **scoring_utils.py** - עזרים לניקוד
- **data_utils.py** - עזרים לנתונים
- **hebrew_utils.py** - עזרים לעברית

## תכונות עיקריות

### 🎯 סוגי החלטות נתמכים
- **אסטרטגיות** - החלטות ארוכות טווח
- **תפעוליות** - החלטות יומיומיות
- **טקטיות** - החלטות לטווח בינוני
- **חירום** - החלטות דחופות
- **שגרתיות** - החלטות רגילות
- **יצירתיות** - החלטות חדשניות

### 📊 שיטות ניקוד
- **Weighted Sum** - סכום משוקלל
- **TOPSIS** - טכניקת דירוג לפי דמיון לפתרון אידיאלי
- **AHP** - תהליך היררכיה אנליטית
- **PROMETHEE** - שיטת העדפה

### 🤖 למידה אוטומטית
- למידה מתוצאות החלטות קודמות
- זיהוי דפוסי הצלחה וכישלון
- שיפור המלצות לפי ניסיון
- חיזוי הצלחת החלטות

### 🌍 תמיכה בעברית
- ממשק מלא בעברית
- התאמה תרבותית ישראלית
- תמיכה ב-RTL
- תבניות החלטה מותאמות

## דוגמת שימוש

```python
from decision_engine.core import DecisionEngine
from decision_engine.models import DecisionType, DecisionPriority

# יצירת מנוע החלטות
engine = DecisionEngine()

# יצירת החלטה חדשה
decision_id = engine.create_decision(
    title="בחירת ספק חדש",
    hebrew_title="בחירת ספק חדש לחברה",
    description="בחירת ספק טכנולוגיה עיקרי",
    hebrew_description="בחירת ספק טכנולוגיה עיקרי לחברה",
    decision_type=DecisionType.STRATEGIC,
    priority=DecisionPriority.HIGH
)

# הוספת קריטריונים
criteria = CriteriaTemplate.get_business_template().criteria_list
engine.add_criteria(decision_id, criteria)

# הוספת אפשרויות
options = [
    DecisionOption.create_default("ספק A", "ספק A - פתרון מקומי"),
    DecisionOption.create_default("ספק B", "ספק B - פתרון בינלאומי"),
    DecisionOption.create_default("ספק C", "ספק C - פתרון היברידי")
]
engine.add_options(decision_id, options)

# ביצוע הערכה
results = engine.evaluate_decision(decision_id)

# קבלת המלצות
recommendations = results['recommendations']
print(f"המלצה ראשית: {recommendations['primary_recommendation']}")
```

## התקנה

```bash
# התקנת תלויות
pip install -r requirements.txt

# יצירת מסד נתונים
python setup_database.py

# הרצת בדיקות
python -m pytest tests/
```

## קבצי הגדרה

### decision_engine_config.json
```json
{
    "default_language": "he",
    "enable_hebrew_support": true,
    "scoring_algorithm": "weighted_sum",
    "enable_ai_suggestions": true,
    "enable_learning": true,
    "log_level": "INFO"
}
```

## API Reference

### DecisionEngine

#### create_decision(title, hebrew_title, ...)
יוצר החלטה חדשה במערכת

#### add_criteria(decision_id, criteria)
מוסיף קריטריונים להחלטה

#### add_options(decision_id, options)
מוסיף אפשרויות להחלטה

#### evaluate_decision(decision_id)
מבצע הערכה מלאה של ההחלטה

#### implement_decision(decision_id, selected_option_id)
מיישם החלטה שנבחרה

## תמיכה והרחבות

### הוספת קריטריון חדש
```python
from decision_engine.models import DecisionCriteria, CriteriaType, CriteriaWeight

criterion = DecisionCriteria(
    id="new_criterion",
    name="New Criterion",
    hebrew_name="קריטריון חדש",
    description="Description...",
    hebrew_description="תיאור...",
    criteria_type=CriteriaType.QUANTITATIVE,
    weight=CriteriaWeight(0.3, CriteriaImportance.HIGH, "הצדקה", "הצדקה בעברית")
)
```

### הוספת שיטת ניקוד חדשה
```python
def custom_scoring_method(evaluations, criteria):
    # יישום שיטת ניקוד מותאמת אישית
    return scored_options
    
# רישום השיטה
scoring_engine.register_method("custom", custom_scoring_method)
```

## לוגים ומעקב

המערכת מייצרת לוגים מפורטים:
- החלטות שנוצרו
- הערכות שבוצעו  
- תוצאות החלטות
- למידה מתהליכים

## רישיון
MIT License

## יוצר
מערכת AI מתקדמת - Effi AI Private

---

*מנוע קבלת החלטות זה פותח במיוחד עבור סביבה ישראלית ותומך במלואו בשפה העברית ובמאפיינים תרבותיים מקומיים.*