"""
Analysis Types and Methods
סוגי ניתוח ושיטות
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union
from datetime import datetime

class AnalysisType(Enum):
    """סוגי ניתוח"""
    DESCRIPTIVE = "descriptive"         # תיאורי
    DIAGNOSTIC = "diagnostic"           # אבחנתי
    PREDICTIVE = "predictive"           # חיזוי
    PRESCRIPTIVE = "prescriptive"       # המלצתי
    EXPLORATORY = "exploratory"         # גישושי
    CONFIRMATORY = "confirmatory"       # מאשש
    COMPARATIVE = "comparative"         # השוואתי
    TREND = "trend"                     # מגמות
    CORRELATION = "correlation"         # מתאם
    CLUSTERING = "clustering"           # איגום
    CLASSIFICATION = "classification"   # סיווג
    REGRESSION = "regression"           # רגרסיה
    TIME_SERIES = "time_series"         # סדרות זמן
    TEXT_ANALYSIS = "text_analysis"     # ניתוח טקסט
    SENTIMENT = "sentiment"             # רגש
    ANOMALY_DETECTION = "anomaly"       # זיהוי חריגים

class AnalysisMethod(Enum):
    """שיטות ניתוח"""
    STATISTICAL = "statistical"         # סטטיסטי
    MACHINE_LEARNING = "ml"             # למידת מכונה
    DEEP_LEARNING = "deep_learning"     # למידה עמוקה
    RULE_BASED = "rule_based"           # מבוסס חוקים
    HEURISTIC = "heuristic"             # היוריסטי
    HYBRID = "hybrid"                   # היברידי
    ENSEMBLE = "ensemble"               # אנסמבל
    BAYESIAN = "bayesian"               # בייסיאני
    FUZZY_LOGIC = "fuzzy"               # לוגיקה מטושטשת
    NEURAL_NETWORK = "neural"           # רשת נוירונים
    DECISION_TREE = "decision_tree"     # עץ החלטה
    SVM = "svm"                         # Support Vector Machine
    CLUSTERING_ALGO = "clustering_algo" # אלגוריתמי איגום
    NLP = "nlp"                         # עיבוד שפה טבעית

class AnalysisScope(Enum):
    """היקף ניתוח"""
    SINGLE_DATASET = "single"           # מערך נתונים יחיד
    MULTI_DATASET = "multi"             # מספר מערכי נתונים
    CROSS_PLATFORM = "cross_platform"   # חוצה פלטפורמות
    REAL_TIME = "real_time"             # זמן אמת
    BATCH = "batch"                     # אצווה
    STREAMING = "streaming"             # זרימת נתונים
    HISTORICAL = "historical"           # היסטורי
    COMPARATIVE_TIME = "comparative"     # השוואתי זמני

class AnalysisComplexity(Enum):
    """מורכבות ניתוח"""
    SIMPLE = 1      # פשוט
    MODERATE = 2    # בינוני
    COMPLEX = 3     # מורכב
    ADVANCED = 4    # מתקדם
    EXPERT = 5      # מומחה

@dataclass
class AnalysisParameter:
    """פרמטר ניתוח"""
    name: str
    hebrew_name: str
    parameter_type: str  # string, number, boolean, list, etc.
    default_value: Any
    description: str
    hebrew_description: str
    is_required: bool = True
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    allowed_values: List[Any] = None
    validation_rules: List[str] = None
    
    def __post_init__(self):
        if self.allowed_values is None:
            self.allowed_values = []
        if self.validation_rules is None:
            self.validation_rules = []

@dataclass
class AnalysisConfiguration:
    """הגדרות ניתוח"""
    analysis_id: str
    name: str
    hebrew_name: str
    analysis_type: AnalysisType
    analysis_method: AnalysisMethod
    scope: AnalysisScope
    complexity: AnalysisComplexity
    parameters: List[AnalysisParameter]
    required_data_types: List[str]
    estimated_duration: int  # משך זמן משוער בדקות
    output_types: List[str]  # סוגי פלט צפויים
    prerequisites: List[str] = None  # דרישות מוקדמות
    limitations: List[str] = None    # מגבלות
    recommendations: List[str] = None # המלצות שימוש
    
    def __post_init__(self):
        if self.prerequisites is None:
            self.prerequisites = []
        if self.limitations is None:
            self.limitations = []
        if self.recommendations is None:
            self.recommendations = []

@dataclass
class AnalysisTask:
    """משימת ניתוח"""
    task_id: str
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    configuration: AnalysisConfiguration
    input_datasets: List[str]  # מזהי מערכי נתונים
    parameters_values: Dict[str, Any]  # ערכי פרמטרים
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    status: str = "pending"  # pending, running, completed, failed, cancelled
    progress: float = 0.0    # אחוז התקדמות (0.0-1.0)
    error_message: Optional[str] = None
    warnings: List[str] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []
        if self.metadata is None:
            self.metadata = {}
    
    def update_progress(self, progress: float, status: str = None):
        """עדכון התקדמות"""
        self.progress = max(0.0, min(1.0, progress))
        if status:
            self.status = status
        if progress >= 1.0 and self.status == "running":
            self.status = "completed"
            self.completed_at = datetime.now()

@dataclass
class AnalysisResult:
    """תוצאת ניתוח"""
    result_id: str
    task_id: str
    analysis_type: AnalysisType
    results_data: Dict[str, Any]  # תוצאות הניתוח
    summary: str                  # סיכום התוצאות
    hebrew_summary: str           # סיכום בעברית
    insights: List[str]           # תובנות עיקריות
    hebrew_insights: List[str]    # תובנות בעברית
    confidence_score: float       # ניקוד אמינות (0.0-1.0)
    quality_score: float          # ניקוד איכות (0.0-1.0)
    processing_time: float        # זמן עיבוד בשניות
    generated_at: datetime
    visualizations: List[Dict] = None  # ויזואליזציות
    recommendations: List[str] = None  # המלצות
    hebrew_recommendations: List[str] = None
    statistical_measures: Dict[str, float] = None  # מדדים סטטיסטיים
    
    def __post_init__(self):
        if self.visualizations is None:
            self.visualizations = []
        if self.recommendations is None:
            self.recommendations = []
        if self.hebrew_recommendations is None:
            self.hebrew_recommendations = []
        if self.statistical_measures is None:
            self.statistical_measures = {}

class AnalysisTemplateLibrary:
    """ספריית תבניות ניתוח"""
    
    @staticmethod
    def get_descriptive_analysis() -> AnalysisConfiguration:
        """תבנית ניתוח תיאורי"""
        return AnalysisConfiguration(
            analysis_id="descriptive_basic",
            name="Descriptive Analysis",
            hebrew_name="ניתוח תיאורי בסיסי",
            analysis_type=AnalysisType.DESCRIPTIVE,
            analysis_method=AnalysisMethod.STATISTICAL,
            scope=AnalysisScope.SINGLE_DATASET,
            complexity=AnalysisComplexity.SIMPLE,
            parameters=[
                AnalysisParameter(
                    name="include_visualizations",
                    hebrew_name="כלול ויזואליזציות",
                    parameter_type="boolean",
                    default_value=True,
                    description="Include charts and graphs in results",
                    hebrew_description="כלול גרפים ותרשימים בתוצאות"
                ),
                AnalysisParameter(
                    name="confidence_level",
                    hebrew_name="רמת ביטחון",
                    parameter_type="number",
                    default_value=0.95,
                    description="Statistical confidence level",
                    hebrew_description="רמת ביטחון סטטיסטית",
                    min_value=0.8,
                    max_value=0.99
                )
            ],
            required_data_types=["numerical", "categorical"],
            estimated_duration=5,
            output_types=["statistics", "distributions", "visualizations"],
            recommendations=[
                "מתאים לבדיקה ראשונית של נתונים",
                "עוזר להבנת מבנה הנתונים",
                "נותן בסיס לניתוחים מתקדמים יותר"
            ]
        )
    
    @staticmethod
    def get_trend_analysis() -> AnalysisConfiguration:
        """תבנית ניתוח מגמות"""
        return AnalysisConfiguration(
            analysis_id="trend_analysis",
            name="Trend Analysis",
            hebrew_name="ניתוח מגמות",
            analysis_type=AnalysisType.TREND,
            analysis_method=AnalysisMethod.STATISTICAL,
            scope=AnalysisScope.HISTORICAL,
            complexity=AnalysisComplexity.MODERATE,
            parameters=[
                AnalysisParameter(
                    name="time_period",
                    hebrew_name="תקופת זמן",
                    parameter_type="string",
                    default_value="monthly",
                    description="Time period for trend analysis",
                    hebrew_description="תקופת זמן לניתוח מגמות",
                    allowed_values=["daily", "weekly", "monthly", "quarterly", "yearly"]
                ),
                AnalysisParameter(
                    name="smoothing_method",
                    hebrew_name="שיטת החלקה",
                    parameter_type="string",
                    default_value="moving_average",
                    description="Method for smoothing trend lines",
                    hebrew_description="שיטה להחלקת קווי מגמה",
                    allowed_values=["moving_average", "exponential", "linear_regression"]
                ),
                AnalysisParameter(
                    name="forecast_periods",
                    hebrew_name="תקופות חיזוי",
                    parameter_type="number",
                    default_value=6,
                    description="Number of periods to forecast",
                    hebrew_description="מספר תקופות לחיזוי",
                    min_value=1,
                    max_value=24
                )
            ],
            required_data_types=["datetime", "numerical"],
            estimated_duration=15,
            output_types=["trends", "forecasts", "seasonality", "visualizations"],
            prerequisites=["נתונים עם חותמת זמן", "לפחות 12 נקודות זמן"],
            recommendations=[
                "מתאים לזיהוי דפוסים עונתיים",
                "עוזר בתכנון עתידי",
                "מזהה נקודות מפנה במגמות"
            ]
        )
    
    @staticmethod
    def get_correlation_analysis() -> AnalysisConfiguration:
        """תבנית ניתוח מתאמים"""
        return AnalysisConfiguration(
            analysis_id="correlation_analysis", 
            name="Correlation Analysis",
            hebrew_name="ניתוח מתאמים",
            analysis_type=AnalysisType.CORRELATION,
            analysis_method=AnalysisMethod.STATISTICAL,
            scope=AnalysisScope.SINGLE_DATASET,
            complexity=AnalysisComplexity.MODERATE,
            parameters=[
                AnalysisParameter(
                    name="correlation_method",
                    hebrew_name="שיטת מתאם",
                    parameter_type="string",
                    default_value="pearson",
                    description="Correlation calculation method",
                    hebrew_description="שיטת חישוב מתאם",
                    allowed_values=["pearson", "spearman", "kendall"]
                ),
                AnalysisParameter(
                    name="significance_level",
                    hebrew_name="רמת מובהקות",
                    parameter_type="number",
                    default_value=0.05,
                    description="Statistical significance level",
                    hebrew_description="רמת מובהקות סטטיסטית",
                    allowed_values=[0.01, 0.05, 0.1]
                ),
                AnalysisParameter(
                    name="include_heatmap",
                    hebrew_name="כלול מפת חום",
                    parameter_type="boolean", 
                    default_value=True,
                    description="Generate correlation heatmap",
                    hebrew_description="צור מפת חום של מתאמים"
                )
            ],
            required_data_types=["numerical"],
            estimated_duration=10,
            output_types=["correlation_matrix", "heatmap", "significant_correlations"],
            limitations=[
                "מתאם לא מעיד על סיבתיות",
                "רגיש לערכים חריגים",
                "מתאים רק למשתנים מספריים"
            ],
            recommendations=[
                "בדוק קודם את התפלגות הנתונים",
                "הסר ערכים חריגים אם נדרש",
                "השלם בניתוח סיבתיות אם מתאים"
            ]
        )
    
    @staticmethod
    def get_clustering_analysis() -> AnalysisConfiguration:
        """תבנית ניתוח איגום"""
        return AnalysisConfiguration(
            analysis_id="clustering_analysis",
            name="Clustering Analysis", 
            hebrew_name="ניתוח איגום",
            analysis_type=AnalysisType.CLUSTERING,
            analysis_method=AnalysisMethod.MACHINE_LEARNING,
            scope=AnalysisScope.SINGLE_DATASET,
            complexity=AnalysisComplexity.COMPLEX,
            parameters=[
                AnalysisParameter(
                    name="algorithm",
                    hebrew_name="אלגוריתם",
                    parameter_type="string",
                    default_value="kmeans",
                    description="Clustering algorithm to use",
                    hebrew_description="אלגוריתם איגום לשימוש",
                    allowed_values=["kmeans", "hierarchical", "dbscan", "gaussian_mixture"]
                ),
                AnalysisParameter(
                    name="num_clusters",
                    hebrew_name="מספר אשכולות",
                    parameter_type="number",
                    default_value=3,
                    description="Number of clusters (for k-means)",
                    hebrew_description="מספר אשכולות (עבור k-means)",
                    min_value=2,
                    max_value=20
                ),
                AnalysisParameter(
                    name="auto_optimize",
                    hebrew_name="אופטימיזציה אוטומטית",
                    parameter_type="boolean",
                    default_value=True,
                    description="Automatically find optimal number of clusters",
                    hebrew_description="מצא אוטומטית מספר אשכולות אופטימלי"
                ),
                AnalysisParameter(
                    name="standardize_features",
                    hebrew_name="תקן משתנים",
                    parameter_type="boolean",
                    default_value=True,
                    description="Standardize features before clustering",
                    hebrew_description="תקן משתנים לפני איגום"
                )
            ],
            required_data_types=["numerical"],
            estimated_duration=20,
            output_types=["cluster_assignments", "cluster_centers", "silhouette_analysis", "visualizations"],
            prerequisites=[
                "נתונים מספריים מנורמלים",
                "לפחות 50 רשומות לניתוח משמעותי"
            ],
            limitations=[
                "דורש בחירה מתוחכמת של מספר אשכולות",
                "רגיש להתפלגות הנתונים",
                "קשה לפרש אשכולות במערכי נתונים רב-ממדיים"
            ]
        )
    
    @staticmethod
    def get_anomaly_detection() -> AnalysisConfiguration:
        """תבנית זיהוי חריגים"""
        return AnalysisConfiguration(
            analysis_id="anomaly_detection",
            name="Anomaly Detection",
            hebrew_name="זיהוי חריגים",
            analysis_type=AnalysisType.ANOMALY_DETECTION,
            analysis_method=AnalysisMethod.MACHINE_LEARNING,
            scope=AnalysisScope.REAL_TIME,
            complexity=AnalysisComplexity.ADVANCED,
            parameters=[
                AnalysisParameter(
                    name="detection_method",
                    hebrew_name="שיטת זיהוי",
                    parameter_type="string",
                    default_value="isolation_forest",
                    description="Anomaly detection algorithm",
                    hebrew_description="אלגוריתם זיהוי חריגים",
                    allowed_values=["isolation_forest", "one_class_svm", "statistical", "autoencoder"]
                ),
                AnalysisParameter(
                    name="contamination_rate",
                    hebrew_name="שיעור זיהום",
                    parameter_type="number",
                    default_value=0.1,
                    description="Expected proportion of anomalies",
                    hebrew_description="שיעור חריגים צפוי",
                    min_value=0.01,
                    max_value=0.5
                ),
                AnalysisParameter(
                    name="sensitivity",
                    hebrew_name="רגישות",
                    parameter_type="string",
                    default_value="medium",
                    description="Detection sensitivity level",
                    hebrew_description="רמת רגישות זיהוי",
                    allowed_values=["low", "medium", "high"]
                )
            ],
            required_data_types=["numerical", "datetime"],
            estimated_duration=25,
            output_types=["anomaly_scores", "flagged_records", "detection_summary"],
            recommendations=[
                "מתאים לזיהוי הונאות",
                "עוזר באבטחת איכות נתונים", 
                "זיהוי בעיות במערכות"
            ]
        )

class AnalysisValidator:
    """מאמת הגדרות ניתוח"""
    
    @staticmethod
    def validate_configuration(config: AnalysisConfiguration) -> Dict[str, Any]:
        """מאמת הגדרות ניתוח"""
        validation_result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'parameter_validations': {}
        }
        
        # בדיקת פרמטרים
        for param in config.parameters:
            param_validation = AnalysisValidator._validate_parameter(param)
            validation_result['parameter_validations'][param.name] = param_validation
            
            if not param_validation['is_valid']:
                validation_result['is_valid'] = False
                validation_result['errors'].extend(param_validation['errors'])
        
        # בדיקת התאמה בין סוג ניתוח לשיטה
        compatibility = AnalysisValidator._check_method_compatibility(
            config.analysis_type, config.analysis_method
        )
        if not compatibility['compatible']:
            validation_result['warnings'].append(compatibility['message'])
        
        return validation_result
    
    @staticmethod
    def _validate_parameter(param: AnalysisParameter) -> Dict[str, Any]:
        """מאמת פרמטר יחיד"""
        result = {
            'is_valid': True,
            'errors': [],
            'warnings': []
        }
        
        # בדיקת טווח ערכים
        if param.parameter_type == "number":
            if param.min_value is not None and param.default_value < param.min_value:
                result['errors'].append(f"ערך ברירת מחדל נמוך מהמינימום עבור {param.hebrew_name}")
                result['is_valid'] = False
            
            if param.max_value is not None and param.default_value > param.max_value:
                result['errors'].append(f"ערך ברירת מחדל גבוה מהמקסימום עבור {param.hebrew_name}")
                result['is_valid'] = False
        
        # בדיקת ערכים מותרים
        if param.allowed_values and param.default_value not in param.allowed_values:
            result['errors'].append(f"ערך ברירת מחדל לא מותר עבור {param.hebrew_name}")
            result['is_valid'] = False
        
        return result
    
    @staticmethod
    def _check_method_compatibility(analysis_type: AnalysisType, 
                                   analysis_method: AnalysisMethod) -> Dict[str, Any]:
        """בודק התאמה בין סוג ניתוח לשיטה"""
        # מטריצת התאמה מותאמת אישית
        compatibility_matrix = {
            AnalysisType.DESCRIPTIVE: [AnalysisMethod.STATISTICAL],
            AnalysisType.PREDICTIVE: [AnalysisMethod.MACHINE_LEARNING, AnalysisMethod.DEEP_LEARNING],
            AnalysisType.CLUSTERING: [AnalysisMethod.MACHINE_LEARNING, AnalysisMethod.CLUSTERING_ALGO],
            AnalysisType.TEXT_ANALYSIS: [AnalysisMethod.NLP, AnalysisMethod.MACHINE_LEARNING]
        }
        
        compatible_methods = compatibility_matrix.get(analysis_type, [])
        
        if compatible_methods and analysis_method not in compatible_methods:
            return {
                'compatible': False,
                'message': f"שיטה {analysis_method.value} אינה מומלצת עבור ניתוח {analysis_type.value}"
            }
        
        return {'compatible': True, 'message': 'שילוב תואם'}