"""
Data Types and Sources for Analysis
סוגי נתונים ומקורות לניתוח
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
import numpy as np

class DataType(Enum):
    """סוגי נתונים"""
    NUMERICAL = "numerical"         # מספרי
    CATEGORICAL = "categorical"     # קטגורי  
    TEXT = "text"                  # טקסט
    DATETIME = "datetime"          # תאריך ושעה
    BOOLEAN = "boolean"            # בוליאני
    IMAGE = "image"                # תמונה
    AUDIO = "audio"                # אודיו
    VIDEO = "video"                # וידאו
    GEOSPATIAL = "geospatial"      # מרחבי
    TIME_SERIES = "time_series"    # סדרות זמן
    GRAPH = "graph"                # גרף
    JSON = "json"                  # JSON
    XML = "xml"                    # XML

class DataSource(Enum):
    """מקורות נתונים"""
    DATABASE = "database"          # מסד נתונים
    FILE = "file"                 # קובץ
    API = "api"                   # API
    STREAM = "stream"             # זרימת נתונים
    MANUAL = "manual"             # הזנה ידנית
    WEB_SCRAPING = "web_scraping" # גרידת אינטרנט
    IOT = "iot"                   # Internet of Things
    SOCIAL_MEDIA = "social_media" # רשתות חברתיות
    EMAIL = "email"               # אימייל
    LOGS = "logs"                 # לוגים
    SENSORS = "sensors"           # חיישנים
    EXTERNAL_API = "external_api" # API חיצוני

class DataFormat(Enum):
    """פורמטי נתונים"""
    CSV = "csv"
    JSON = "json" 
    XML = "xml"
    EXCEL = "excel"
    PARQUET = "parquet"
    SQL = "sql"
    AVRO = "avro"
    PROTOBUF = "protobuf"
    YAML = "yaml"
    TEXT = "text"
    BINARY = "binary"
    IMAGE_PNG = "png"
    IMAGE_JPG = "jpg"
    AUDIO_WAV = "wav"
    AUDIO_MP3 = "mp3"

class DataQuality(Enum):
    """איכות נתונים"""
    EXCELLENT = 5    # מעולה
    GOOD = 4         # טוב
    FAIR = 3         # סביר
    POOR = 2         # גרוע
    UNUSABLE = 1     # לא ניתן לשימוש

@dataclass
class DataSchema:
    """סכמת נתונים"""
    field_name: str
    hebrew_name: str
    data_type: DataType
    is_required: bool = True
    default_value: Any = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    allowed_values: List[Any] = None
    pattern: Optional[str] = None  # Regex pattern
    description: str = ""
    hebrew_description: str = ""
    
    def __post_init__(self):
        if self.allowed_values is None:
            self.allowed_values = []

@dataclass 
class DataQualityMetrics:
    """מדדי איכות נתונים"""
    completeness: float      # שלמות (% ערכים לא ריקים)
    accuracy: float          # דיוק (% ערכים תקינים)
    consistency: float       # עקביות (% ערכים עקביים)
    timeliness: float        # עדכניות (% נתונים עדכניים)
    uniqueness: float        # ייחודיות (% ערכים ייחודיים)
    validity: float          # תקפות (% ערכים תקפים)
    overall_quality: float   # איכות כוללת
    
    def calculate_overall_quality(self) -> float:
        """מחשב איכות כוללת"""
        metrics = [
            self.completeness,
            self.accuracy, 
            self.consistency,
            self.timeliness,
            self.uniqueness,
            self.validity
        ]
        self.overall_quality = sum(metrics) / len(metrics)
        return self.overall_quality

@dataclass
class DataSource:
    """מקור נתונים"""
    id: str
    name: str
    hebrew_name: str
    source_type: DataSource
    connection_string: str
    format: DataFormat
    schema: List[DataSchema]
    update_frequency: str    # daily, hourly, real-time, etc.
    last_updated: Optional[datetime] = None
    quality_metrics: Optional[DataQualityMetrics] = None
    metadata: Dict[str, Any] = None
    is_active: bool = True
    access_credentials: Dict[str, str] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.access_credentials is None:
            self.access_credentials = {}

@dataclass
class DataSet:
    """מערך נתונים"""
    id: str
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    source: DataSource
    data: Any  # pandas DataFrame, list, dict, etc.
    row_count: int
    column_count: int
    size_bytes: int
    created_at: datetime
    updated_at: datetime
    quality_score: float = 0.0
    tags: List[str] = None
    processing_notes: str = ""
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []

@dataclass
class DataProfile:
    """פרופיל נתונים סטטיסטי"""
    field_name: str
    data_type: DataType
    
    # סטטיסטיקות בסיסיות
    count: int
    null_count: int
    unique_count: int
    
    # סטטיסטיקות מספריות
    mean: Optional[float] = None
    median: Optional[float] = None
    std_dev: Optional[float] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    q25: Optional[float] = None      # רבעון ראשון
    q75: Optional[float] = None      # רבעון שלישי
    
    # סטטיסטיקות קטגוריות
    mode: Optional[str] = None       # ערך שכיח ביותר
    mode_frequency: Optional[int] = None
    top_values: List[Dict] = None    # ערכים מובילים
    
    # סטטיסטיקות טקסט
    avg_length: Optional[float] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    
    # זיהוי דפוסים
    detected_patterns: List[str] = None
    anomalies_count: int = 0
    outliers_count: int = 0
    
    def __post_init__(self):
        if self.top_values is None:
            self.top_values = []
        if self.detected_patterns is None:
            self.detected_patterns = []

class DataValidator:
    """מאמת נתונים"""
    
    @staticmethod
    def validate_schema(data: Any, schema: List[DataSchema]) -> Dict[str, Any]:
        """מאמת נתונים לפי סכמה"""
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'field_results': {}
        }
        
        for field_schema in schema:
            field_result = DataValidator._validate_field(data, field_schema)
            validation_results['field_results'][field_schema.field_name] = field_result
            
            if not field_result['is_valid']:
                validation_results['is_valid'] = False
                validation_results['errors'].extend(field_result['errors'])
        
        return validation_results
    
    @staticmethod
    def _validate_field(data: Any, field_schema: DataSchema) -> Dict[str, Any]:
        """מאמת שדה יחיד"""
        result = {
            'is_valid': True,
            'errors': [],
            'warnings': []
        }
        
        field_name = field_schema.field_name
        
        # בדיקת קיום השדה
        if hasattr(data, 'columns'):  # pandas DataFrame
            if field_name not in data.columns:
                if field_schema.is_required:
                    result['errors'].append(f"שדה חובה חסר: {field_name}")
                    result['is_valid'] = False
                return result
            
            field_data = data[field_name]
            
            # בדיקת ערכים ריקים
            null_count = field_data.isnull().sum()
            if null_count > 0 and field_schema.is_required:
                result['warnings'].append(f"שדה {field_name} מכיל {null_count} ערכים ריקים")
            
            # בדיקת טווח ערכים
            if field_schema.min_value is not None or field_schema.max_value is not None:
                numeric_data = field_data.dropna()
                if field_schema.min_value is not None:
                    violations = numeric_data < field_schema.min_value
                    if violations.any():
                        result['errors'].append(f"שדה {field_name} מכיל ערכים מתחת למינימום")
                        result['is_valid'] = False
                
                if field_schema.max_value is not None:
                    violations = numeric_data > field_schema.max_value
                    if violations.any():
                        result['errors'].append(f"שדה {field_name} מכיל ערכים מעל המקסימום")
                        result['is_valid'] = False
            
            # בדיקת ערכים מותרים
            if field_schema.allowed_values:
                violations = ~field_data.isin(field_schema.allowed_values)
                if violations.any():
                    result['errors'].append(f"שדה {field_name} מכיל ערכים לא מותרים")
                    result['is_valid'] = False
        
        return result
    
    @staticmethod
    def calculate_quality_metrics(data: Any) -> DataQualityMetrics:
        """מחשב מדדי איכות נתונים"""
        if hasattr(data, 'shape'):  # pandas DataFrame
            total_cells = data.shape[0] * data.shape[1]
            null_cells = data.isnull().sum().sum()
            
            completeness = 1.0 - (null_cells / total_cells) if total_cells > 0 else 0.0
            
            # חישובים נוספים לדוגמה
            accuracy = 0.95  # יחושב בהתבסס על חוקי עסק
            consistency = 0.90  # יחושב בהתבסס על עקביות בין שדות
            timeliness = 0.85   # יחושב בהתבסס על עדכניות הנתונים
            uniqueness = 0.88   # יחושב בהתבסס על כפילויות
            validity = 0.92     # יחושב בהתבסס על תקפות פורמט
            
            metrics = DataQualityMetrics(
                completeness=completeness,
                accuracy=accuracy,
                consistency=consistency,
                timeliness=timeliness,
                uniqueness=uniqueness,
                validity=validity,
                overall_quality=0.0
            )
            
            metrics.calculate_overall_quality()
            return metrics
        
        return DataQualityMetrics(0, 0, 0, 0, 0, 0, 0)

class DataProfiler:
    """מפלח נתונים סטטיסטי"""
    
    @staticmethod
    def profile_dataset(data: Any) -> List[DataProfile]:
        """יוצר פרופיל סטטיסטי למערך נתונים"""
        profiles = []
        
        if hasattr(data, 'columns'):  # pandas DataFrame
            for column in data.columns:
                profile = DataProfiler._profile_column(data[column], column)
                profiles.append(profile)
        
        return profiles
    
    @staticmethod
    def _profile_column(series, column_name: str) -> DataProfile:
        """יוצר פרופיל לעמודה יחידה"""
        data_type = DataProfiler._detect_data_type(series)
        
        profile = DataProfile(
            field_name=column_name,
            data_type=data_type,
            count=len(series),
            null_count=series.isnull().sum(),
            unique_count=series.nunique()
        )
        
        # סטטיסטיקות מספריות
        if data_type == DataType.NUMERICAL:
            profile.mean = float(series.mean()) if not series.empty else None
            profile.median = float(series.median()) if not series.empty else None
            profile.std_dev = float(series.std()) if not series.empty else None
            profile.min_value = float(series.min()) if not series.empty else None
            profile.max_value = float(series.max()) if not series.empty else None
            profile.q25 = float(series.quantile(0.25)) if not series.empty else None
            profile.q75 = float(series.quantile(0.75)) if not series.empty else None
            
            # זיהוי חריגים
            if profile.q25 and profile.q75:
                iqr = profile.q75 - profile.q25
                lower_bound = profile.q25 - 1.5 * iqr
                upper_bound = profile.q75 + 1.5 * iqr
                profile.outliers_count = ((series < lower_bound) | (series > upper_bound)).sum()
        
        # סטטיסטיקות קטגוריות
        elif data_type == DataType.CATEGORICAL:
            mode_series = series.mode()
            if not mode_series.empty:
                profile.mode = str(mode_series.iloc[0])
                profile.mode_frequency = (series == profile.mode).sum()
            
            # ערכים מובילים
            value_counts = series.value_counts().head(10)
            profile.top_values = [
                {'value': str(val), 'count': int(count)}
                for val, count in value_counts.items()
            ]
        
        # סטטיסטיקות טקסט
        elif data_type == DataType.TEXT:
            text_lengths = series.astype(str).str.len()
            profile.avg_length = float(text_lengths.mean()) if not text_lengths.empty else None
            profile.min_length = int(text_lengths.min()) if not text_lengths.empty else None
            profile.max_length = int(text_lengths.max()) if not text_lengths.empty else None
        
        return profile
    
    @staticmethod
    def _detect_data_type(series) -> DataType:
        """מזהה סוג נתונים של סדרה"""
        # נסה לזהות מספרים
        try:
            pd_numeric = series.dropna().apply(lambda x: isinstance(x, (int, float)))
            if pd_numeric.all():
                return DataType.NUMERICAL
        except:
            pass
        
        # נסה לזהות תאריכים
        try:
            pd.to_datetime(series.dropna(), errors='raise')
            return DataType.DATETIME
        except:
            pass
        
        # נסה לזהות בוליאנים
        unique_values = set(series.dropna().astype(str).str.lower())
        boolean_values = {'true', 'false', '1', '0', 'yes', 'no', 'כן', 'לא'}
        if unique_values.issubset(boolean_values):
            return DataType.BOOLEAN
        
        # בדוק אם זה קטגורי (מספר מועט של ערכים ייחודיים)
        unique_ratio = series.nunique() / len(series) if len(series) > 0 else 0
        if unique_ratio < 0.1 and series.nunique() < 50:
            return DataType.CATEGORICAL
        
        # ברירת מחדל - טקסט
        return DataType.TEXT