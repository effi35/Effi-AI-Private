"""
Main Analysis Engine
מנוע ניתוח נתונים ראשי
"""

import sqlite3
from typing import List, Dict, Optional, Any, Union
from datetime import datetime
import logging
import uuid
import pandas as pd
import numpy as np

from ..models.data_types import DataSet, DataSource, DataQualityMetrics
from ..models.analysis_types import AnalysisConfiguration, AnalysisTask, AnalysisResult, AnalysisType
from ..models.config import AnalysisEngineConfig

from .data_processor import DataProcessor
from .statistical_analyzer import StatisticalAnalyzer
from .ml_analyzer import MachineLearningAnalyzer
from .insights_generator import InsightsGenerator

class AnalysisEngine:
    """מנוע ניתוח נתונים ראשי"""
    
    def __init__(self, config: AnalysisEngineConfig = None):
        self.config = config or AnalysisEngineConfig()
        self.logger = self._setup_logger()
        self.db_connection = self._init_database()
        
        # מנועי משנה
        self.data_processor = DataProcessor(self.config)
        self.statistical_analyzer = StatisticalAnalyzer(self.config)
        self.ml_analyzer = MachineLearningAnalyzer(self.config)
        self.insights_generator = InsightsGenerator(self.config)
        
        # מטמון נתונים
        self.datasets_cache: Dict[str, DataSet] = {}
        self.analysis_templates: Dict[str, AnalysisConfiguration] = {}
        
        # משימות פעילות
        self.active_tasks: Dict[str, AnalysisTask] = {}
        
        self.logger.info("מנוע ניתוח נתונים הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים"""
        logger = logging.getLogger("AnalysisEngine")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _init_database(self) -> sqlite3.Connection:
        """אתחול מסד נתונים"""
        conn = sqlite3.connect(self.config.database_path)
        cursor = conn.cursor()
        
        # טבלת מערכי נתונים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS datasets (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                description TEXT,
                source_type TEXT,
                row_count INTEGER,
                column_count INTEGER,
                created_at TIMESTAMP,
                quality_score REAL,
                metadata TEXT
            )
        ''')
        
        # טבלת משימות ניתוח
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS analysis_tasks (
                task_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                analysis_type TEXT,
                status TEXT,
                created_at TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                progress REAL,
                configuration TEXT,
                metadata TEXT
            )
        ''')
        
        # טבלת תוצאות ניתוח
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS analysis_results (
                result_id TEXT PRIMARY KEY,
                task_id TEXT,
                analysis_type TEXT,
                summary TEXT,
                hebrew_summary TEXT,
                confidence_score REAL,
                quality_score REAL,
                processing_time REAL,
                generated_at TIMESTAMP,
                results_data TEXT,
                FOREIGN KEY (task_id) REFERENCES analysis_tasks (task_id)
            )
        ''')
        
        conn.commit()
        return conn
    
    def register_dataset(self, 
                        dataset: DataSet,
                        validate_quality: bool = True) -> bool:
        """רושם מערך נתונים במערכת"""
        
        try:
            # אימות איכות נתונים אם נדרש
            if validate_quality:
                quality_metrics = self.data_processor.assess_data_quality(dataset.data)
                dataset.quality_score = quality_metrics.overall_quality
                
                if dataset.quality_score < self.config.min_quality_threshold:
                    self.logger.warning(f"איכות נתונים נמוכה: {dataset.quality_score}")
            
            # שמירה לזיכרון
            self.datasets_cache[dataset.id] = dataset
            
            # שמירה למסד נתונים
            cursor = self.db_connection.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO datasets
                (id, name, hebrew_name, description, source_type, 
                 row_count, column_count, created_at, quality_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                dataset.id, dataset.name, dataset.hebrew_name, 
                dataset.description, dataset.source.source_type.value,
                dataset.row_count, dataset.column_count, 
                dataset.created_at, dataset.quality_score
            ))
            self.db_connection.commit()
            
            self.logger.info(f"מערך נתונים נרשם: {dataset.hebrew_name} (ID: {dataset.id})")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה ברישום מערך נתונים: {e}")
            return False
    
    def create_analysis_task(self,
                           name: str,
                           hebrew_name: str,
                           configuration: AnalysisConfiguration,
                           dataset_ids: List[str],
                           parameters: Dict[str, Any] = None) -> str:
        """יוצר משימת ניתוח חדשה"""
        
        task_id = str(uuid.uuid4())
        
        # בדיקת קיום מערכי נתונים
        missing_datasets = [
            dataset_id for dataset_id in dataset_ids 
            if dataset_id not in self.datasets_cache
        ]
        
        if missing_datasets:
            raise ValueError(f"מערכי נתונים לא נמצאו: {missing_datasets}")
        
        # יצירת משימה
        task = AnalysisTask(
            task_id=task_id,
            name=name,
            hebrew_name=hebrew_name,
            description=f"Analysis task: {name}",
            hebrew_description=f"משימת ניתוח: {hebrew_name}",
            configuration=configuration,
            input_datasets=dataset_ids,
            parameters_values=parameters or {},
            created_at=datetime.now()
        )
        
        # שמירה לזיכרון
        self.active_tasks[task_id] = task
        
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            INSERT INTO analysis_tasks
            (task_id, name, hebrew_name, analysis_type, status, created_at, progress)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            task_id, name, hebrew_name, configuration.analysis_type.value,
            task.status, task.created_at, task.progress
        ))
        self.db_connection.commit()
        
        self.logger.info(f"נוצרה משימת ניתוח: {hebrew_name} (ID: {task_id})")
        return task_id
    
    def execute_analysis(self, task_id: str) -> Optional[AnalysisResult]:
        """מבצע ניתוח"""
        
        if task_id not in self.active_tasks:
            self.logger.error(f"משימה לא נמצאה: {task_id}")
            return None
        
        task = self.active_tasks[task_id]
        
        try:
            # עדכון סטטוס התחלה
            task.status = "running"
            task.started_at = datetime.now()
            task.update_progress(0.1, "running")
            
            self.logger.info(f"מתחיל ניתוח: {task.hebrew_name}")
            
            # הכנת נתונים
            datasets = [self.datasets_cache[dataset_id] for dataset_id in task.input_datasets]
            processed_data = self.data_processor.prepare_data_for_analysis(
                datasets, task.configuration
            )
            task.update_progress(0.3)
            
            # ביצוע הניתוח לפי סוג
            analysis_result = self._execute_specific_analysis(
                task.configuration.analysis_type,
                processed_data,
                task.parameters_values,
                task
            )
            task.update_progress(0.8)
            
            # יצירת תובנות
            insights = self.insights_generator.generate_insights(
                analysis_result, task.configuration
            )
            analysis_result['insights'] = insights['insights']
            analysis_result['hebrew_insights'] = insights['hebrew_insights']
            task.update_progress(0.9)
            
            # יצירת תוצאה סופית
            result = AnalysisResult(
                result_id=str(uuid.uuid4()),
                task_id=task_id,
                analysis_type=task.configuration.analysis_type,
                results_data=analysis_result,
                summary=analysis_result.get('summary', 'ניתוח הושלם בהצלחה'),
                hebrew_summary=analysis_result.get('hebrew_summary', 'ניתוח הושלם בהצלחה'),
                insights=analysis_result.get('insights', []),
                hebrew_insights=analysis_result.get('hebrew_insights', []),
                confidence_score=analysis_result.get('confidence_score', 0.8),
                quality_score=analysis_result.get('quality_score', 0.8),
                processing_time=(datetime.now() - task.started_at).total_seconds(),
                generated_at=datetime.now()
            )
            
            # שמירת תוצאה
            self._save_analysis_result(result)
            
            # עדכון משימה כהושלמה
            task.update_progress(1.0, "completed")
            task.completed_at = datetime.now()
            
            self.logger.info(f"ניתוח הושלם: {task.hebrew_name}")
            return result
            
        except Exception as e:
            # עדכון משימה ככושלת
            task.status = "failed"
            task.error_message = str(e)
            self.logger.error(f"שגיאה בניתוח {task.hebrew_name}: {e}")
            return None
    
    def _execute_specific_analysis(self,
                                 analysis_type: AnalysisType,
                                 data: Any,
                                 parameters: Dict[str, Any],
                                 task: AnalysisTask) -> Dict[str, Any]:
        """מבצע ניתוח ספציפי לפי סוג"""
        
        if analysis_type == AnalysisType.DESCRIPTIVE:
            return self.statistical_analyzer.descriptive_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.CORRELATION:
            return self.statistical_analyzer.correlation_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.TREND:
            return self.statistical_analyzer.trend_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.CLUSTERING:
            return self.ml_analyzer.clustering_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.CLASSIFICATION:
            return self.ml_analyzer.classification_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.REGRESSION:
            return self.ml_analyzer.regression_analysis(data, parameters)
        
        elif analysis_type == AnalysisType.ANOMALY_DETECTION:
            return self.ml_analyzer.anomaly_detection(data, parameters)
        
        elif analysis_type == AnalysisType.PREDICTIVE:
            return self.ml_analyzer.predictive_analysis(data, parameters)
        
        else:
            raise ValueError(f"סוג ניתוח לא נתמך: {analysis_type}")
    
    def _save_analysis_result(self, result: AnalysisResult):
        """שומר תוצאת ניתוח"""
        cursor = self.db_connection.cursor()
        cursor.execute('''
            INSERT INTO analysis_results
            (result_id, task_id, analysis_type, summary, hebrew_summary,
             confidence_score, quality_score, processing_time, generated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            result.result_id, result.task_id, result.analysis_type.value,
            result.summary, result.hebrew_summary, result.confidence_score,
            result.quality_score, result.processing_time, result.generated_at
        ))
        self.db_connection.commit()
    
    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """מחזיר סטטוס משימה"""
        if task_id in self.active_tasks:
            task = self.active_tasks[task_id]
            return {
                'task_id': task_id,
                'name': task.hebrew_name,
                'status': task.status,
                'progress': task.progress,
                'created_at': task.created_at,
                'started_at': task.started_at,
                'error_message': task.error_message
            }
        return None
    
    def get_analysis_result(self, result_id: str) -> Optional[AnalysisResult]:
        """מחזיר תוצאת ניתוח"""
        cursor = self.db_connection.cursor()
        cursor.execute('''
            SELECT * FROM analysis_results WHERE result_id = ?
        ''', (result_id,))
        
        result = cursor.fetchone()
        if result:
            # כאן נמיר את התוצאה חזרה לאובייקט AnalysisResult
            pass
        return None
    
    def list_datasets(self) -> List[Dict[str, Any]]:
        """מחזיר רשימת מערכי נתונים"""
        datasets_info = []
        for dataset_id, dataset in self.datasets_cache.items():
            datasets_info.append({
                'id': dataset_id,
                'name': dataset.name,
                'hebrew_name': dataset.hebrew_name,
                'row_count': dataset.row_count,
                'column_count': dataset.column_count,
                'quality_score': dataset.quality_score,
                'created_at': dataset.created_at
            })
        return datasets_info
    
    def get_analysis_statistics(self) -> Dict[str, Any]:
        """מחזיר סטטיסטיקות ניתוח"""
        cursor = self.db_connection.cursor()
        
        # סך משימות
        cursor.execute('SELECT COUNT(*) FROM analysis_tasks')
        total_tasks = cursor.fetchone()[0]
        
        # משימות לפי סטטוס
        cursor.execute('''
            SELECT status, COUNT(*) FROM analysis_tasks GROUP BY status
        ''')
        status_counts = dict(cursor.fetchall())
        
        # זמן עיבוד ממוצע
        cursor.execute('''
            SELECT AVG(processing_time) FROM analysis_results
        ''')
        avg_processing_time = cursor.fetchone()[0] or 0
        
        return {
            'total_tasks': total_tasks,
            'status_distribution': status_counts,
            'average_processing_time': avg_processing_time,
            'active_datasets': len(self.datasets_cache)
        }
    
    def close(self):
        """סגירת המנוע"""
        if self.db_connection:
            self.db_connection.close()
        self.logger.info("מנוע ניתוח נתונים נסגר")