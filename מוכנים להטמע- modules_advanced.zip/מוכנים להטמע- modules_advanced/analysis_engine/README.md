# Analysis Engine - מנוע ניתוח נתונים ותובנות

## תיאור כללי
מנוע ניתוח נתונים מתקדם המספק יכולות ניתוח סטטיסטי, למידת מכונה, וגילוי תובנות. המנוע תומך במגוון רחב של סוגי נתונים ושיטות ניתוח.

## ארכיטקטורה

### Models (מודלים)
- **data_types.py** - סוגי נתונים, מקורות ואיכות
- **analysis_types.py** - סוגי ניתוח ושיטות
- **metrics.py** - מדדים ו-KPIs
- **insights.py** - תובנות, דפוסים וחריגים
- **reports.py** - דוחות ודשבורדים
- **config.py** - הגדרות מנוע ניתוח

### Core (ליבה)
- **analysis_engine.py** - מנוע ניתוח ראשי
- **data_processor.py** - מעבד נתונים
- **statistical_analyzer.py** - מנתח סטטיסטי
- **ml_analyzer.py** - מנתח למידת מכונה
- **insights_generator.py** - מחולל תובנות

### UI (ממשק משתמש)
- **analysis_dashboard.py** - דשבורד ניתוח
- **data_explorer.py** - סייר נתונים
- **visualization_panel.py** - פאנל ויזואליזציה
- **insights_viewer.py** - מציג תובנות
- **report_builder.py** - בונה דוחות

### Utils (עזרים)
- **data_utils.py** - עזרים לנתונים
- **statistical_utils.py** - עזרים סטטיסטיים
- **visualization_utils.py** - עזרים לויזואליזציה
- **hebrew_utils.py** - עזרים לעברית
- **export_utils.py** - עזרים לייצוא

## תכונות עיקריות

### 📊 סוגי ניתוח נתמכים
- **תיאורי** - סטטיסטיקות בסיסיות והתפלגויות
- **אבחנתי** - חקירת סיבות לתופעות
- **חיזוי** - תחזיות על בסיס נתונים
- **המלצתי** - המלצות לפעולות
- **מתאמים** - ניתוח קשרים בין משתנים
- **מגמות** - זיהוי מגמות לאורך זמן
- **איגום** - זיהוי קבוצות בנתונים
- **זיהוי חריגים** - איתור ערכים חריגים

### 🔍 מקורות נתונים
- מסדי נתונים (SQL, NoSQL)
- קבצים (CSV, Excel, JSON, XML)
- APIs וזרמי נתונים
- הזנה ידנית
- גרידת אינטרנט
- חיישנים ו-IoT
- רשתות חברתיות

### 🤖 למידת מכונה
- רגרסיה ליניארית ולא-ליניארית
- סיווג (Decision Trees, SVM, Neural Networks)
- איגום (K-Means, Hierarchical, DBSCAN)
- זיהוי חריגים (Isolation Forest, One-Class SVM)
- עיבוד שפה טבעית
- ניתוח רגשות

### 📈 ויזואליזציות
- גרפים סטטיסטיים
- מפות חום
- תרשימי זמן
- התפלגויות
- מתאמים
- דשבורדים אינטראקטיביים

## דוגמת שימוש

```python
from analysis_engine.core import AnalysisEngine
from analysis_engine.models import AnalysisType, DataSet

# יצירת מנוע ניתוח
engine = AnalysisEngine()

# רישום מערך נתונים
dataset = DataSet(
    id="sales_data",
    name="Sales Data",
    hebrew_name="נתוני מכירות",
    description="Monthly sales data",
    hebrew_description="נתוני מכירות חודשיים",
    source=data_source,
    data=df_sales,  # pandas DataFrame
    row_count=len(df_sales),
    column_count=len(df_sales.columns)
)

engine.register_dataset(dataset)

# יצירת משימת ניתוח
task_id = engine.create_analysis_task(
    name="Sales Trend Analysis",
    hebrew_name="ניתוח מגמות מכירות",
    configuration=AnalysisTemplateLibrary.get_trend_analysis(),
    dataset_ids=["sales_data"],
    parameters={
        "time_period": "monthly",
        "forecast_periods": 6
    }
)

# ביצוע הניתוח
result = engine.execute_analysis(task_id)

# קבלת תובנות
insights = result.hebrew_insights
for insight in insights:
    print(f"תובנה: {insight}")
```

## קבצי הגדרה

### analysis_engine_config.json
```json
{
    "default_language": "he",
    "enable_hebrew_support": true,
    "min_quality_threshold": 0.7,
    "enable_auto_insights": true,
    "max_dataset_size": 1000000,
    "cache_enabled": true,
    "log_level": "INFO"
}
```

## איכות נתונים

המנוע מעריך איכות נתונים לפי:
- **שלמות** - אחוז ערכים לא ריקים
- **דיוק** - אחוז ערכים תקינים
- **עקביות** - אחוז ערכים עקביים
- **עדכניות** - אחוז נתונים עדכניים
- **ייחודיות** - אחוז ערכים ייחודיים
- **תקפות** - אחוז ערכים תקפים

## תובנות אוטומטיות

המנוע מזהה אוטומטית:
- דפוסים בנתונים
- מגמות עולות ויורדות
- חריגים ואנומליות
- מתאמים משמעותיים
- תבניות עונתיות
- נקודות מפנה

## API Reference

### AnalysisEngine

#### register_dataset(dataset, validate_quality=True)
רושם מערך נתונים במערכת

#### create_analysis_task(name, configuration, dataset_ids, parameters)
יוצר משימת ניתוח חדשה

#### execute_analysis(task_id)
מבצע ניתוח על המשימה

#### get_task_status(task_id)
מחזיר סטטוס משימת ניתוח

#### generate_insights(analysis_result)
מייצר תובנות מתוצאות ניתוח

## תבניות ניתוח מוכנות

### ניתוח תיאורי
```python
config = AnalysisTemplateLibrary.get_descriptive_analysis()
```

### ניתוח מגמות
```python
config = AnalysisTemplateLibrary.get_trend_analysis()
```

### ניתוח מתאמים
```python
config = AnalysisTemplateLibrary.get_correlation_analysis()
```

### איגום
```python
config = AnalysisTemplateLibrary.get_clustering_analysis()
```

## ייצוא תוצאות

התמיכה בפורמטים:
- Excel (.xlsx)
- CSV
- JSON
- PDF דוחות
- HTML דשבורדים
- תמונות ויזואליזציות

## ביצועים ואופטימיזציה

- עיבוד מקבילי של נתונים גדולים
- מטמון חכם לתוצאות
- אופטימיזציה אוטומטית של שאילתות
- דחיסת נתונים
- סינון והדללה חכמים

## אבטחה ופרטיות

- הצפנת נתונים רגישים
- בקרת גישה מבוססת תפקידים
- מעקב אחר שימוש
- גיבוי ושחזור
- ביקורת ולוגים

## התקנה

```bash
# התקנת תלויות
pip install -r requirements.txt

# הגדרת מסד נתונים
python setup_database.py

# בדיקת התקנה
python test_installation.py
```

## רישיון
MIT License

## יוצר
מערכת AI מתקדמת - Effi AI Private

---

*מנוע ניתוח זה מותאם לעבודה עם נתונים ישראליים ותומך במלואו בשפה העברית ובפורמטים מקומיים.*