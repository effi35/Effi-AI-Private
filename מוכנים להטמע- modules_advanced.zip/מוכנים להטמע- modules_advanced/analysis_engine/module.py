"""
Analysis Engine Module
מודול מנוע ניתוח נתונים ותובנות
"""

from .core.analysis_engine import AnalysisEngine
from .models import *
from .ui.analysis_dashboard import AnalysisDashboard
from .utils import *

__version__ = "1.0.0"
__author__ = "Effi AI Private"
__description__ = "Advanced Data Analysis Engine with AI-powered insights"

class AnalysisEngineModule:
    """מודול מנוע ניתוח נתונים"""
    
    def __init__(self, config=None):
        self.engine = AnalysisEngine(config)
        self.dashboard = AnalysisDashboard()
        
    def get_info(self):
        return {
            'name': 'Analysis Engine',
            'hebrew_name': 'מנוע ניתוח נתונים',
            'version': __version__,
            'description': __description__,
            'author': __author__,
            'capabilities': [
                'Statistical analysis',
                'Machine learning analytics',
                'Automated insights generation',
                'Data quality assessment',
                'Trend analysis and forecasting',
                'Real-time data processing',
                'Hebrew language support'
            ]
        }

# Main module interface
def create_engine(config=None):
    """יוצר מופע של מנוע ניתוח נתונים"""
    return AnalysisEngineModule(config)