"""
Failure Tracker Advanced Module

This module provides comprehensive failure tracking, pattern analysis, 
and learning insights for AI systems using local Hudson/Llama models.

Key Features:
- Real-time failure detection and logging
- Pattern analysis using ML algorithms
- Learning insights generation
- Predictive failure prevention
- System health monitoring
- Performance degradation alerts
"""

__version__ = "1.0.0"
__author__ = "Effi AI System"

from .core.failure_tracker import FailureTracker
from .core.pattern_analyzer import PatternAnalyzer
from .core.learning_engine import LearningEngine
from .models.failure_types import FailureType, FailureCategory, FailureSeverity
from .models.analysis_models import AnalysisResult, Pattern, Insight

__all__ = [
    'FailureTracker',
    'PatternAnalyzer', 
    'LearningEngine',
    'FailureType',
    'FailureCategory',
    'FailureSeverity',
    'AnalysisResult',
    'Pattern',
    'Insight'
]