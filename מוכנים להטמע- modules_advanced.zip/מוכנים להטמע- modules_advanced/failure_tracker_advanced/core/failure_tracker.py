"""
Advanced Failure Tracker Engine
מנוע מעקב כשלונות מתקדם עם ניתוח AI וחיבור למודל Hudson/Llama מקומי
"""

import asyncio
import json
import logging
import threading
import time
from typing import Dict, List, Any, Optional, Set, Tuple, Callable
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dataclasses import asdict
import re
import statistics

from ..models.failure_types import (
    FailureRecord, FailureCategory, FailureSeverity, FailureStatus,
    FailurePattern_Detection, FailurePattern, FailureAlert,
    FailureStatistics, FailureAnalysis, ResolutionInfo,
    FailureFactory, ImpactLevel
)

class FailureCollector:
    """אספן כשלונות מכל המערכת"""
    
    def __init__(self):
        self.failure_buffer = deque(maxlen=10000)  # חוצץ כשלונות
        self.real_time_handlers = []
        self.is_collecting = False
        self.collection_thread = None
        
        # מסננים
        self.severity_filter = set()  # מסנן חומרה
        self.category_filter = set()  # מסנן קטגוריה
        self.module_filter = set()   # מסנן מודול
        
        # סטטיסטיקות איסוף
        self.collection_stats = {
            "total_collected": 0,
            "filtered_out": 0,
            "buffer_overflows": 0,
            "processing_errors": 0
        }
    
    def start_collection(self):
        """התחלת איסוף כשלונות"""
        if self.is_collecting:
            return
        
        self.is_collecting = True
        self.collection_thread = threading.Thread(
            target=self._collection_loop,
            daemon=True
        )
        self.collection_thread.start()
        logging.info("Failure collection started")
    
    def stop_collection(self):
        """עצירת איסוף"""
        self.is_collecting = False
        if self.collection_thread:
            self.collection_thread.join(timeout=5.0)
        logging.info("Failure collection stopped")
    
    def add_real_time_handler(self, handler: Callable[[FailureRecord], None]):
        """הוספת מטפל זמן אמת"""
        self.real_time_handlers.append(handler)
    
    def collect_failure(self, failure: FailureRecord) -> bool:
        """איסוף כשל בודד"""
        try:
            # בדיקת מסננים
            if not self._passes_filters(failure):
                self.collection_stats["filtered_out"] += 1
                return False
            
            # הוספה לחוצץ
            if len(self.failure_buffer) >= self.failure_buffer.maxlen:
                self.collection_stats["buffer_overflows"] += 1
            
            self.failure_buffer.append(failure)
            self.collection_stats["total_collected"] += 1
            
            # עיבוד זמן אמת
            for handler in self.real_time_handlers:
                try:
                    handler(failure)
                except Exception as e:
                    logging.error(f"Real-time handler error: {str(e)}")
            
            return True
            
        except Exception as e:
            self.collection_stats["processing_errors"] += 1
            logging.error(f"Failure collection error: {str(e)}")
            return False
    
    def _collection_loop(self):
        """לולאת איסוף רקע"""
        while self.is_collecting:
            try:
                # כאן יכול להיות קוד לסריקת לוגים, ניטור מערכת וכו'
                time.sleep(1)
            except Exception as e:
                logging.error(f"Collection loop error: {str(e)}")
    
    def _passes_filters(self, failure: FailureRecord) -> bool:
        """בדיקת מסננים"""
        if self.severity_filter and failure.severity not in self.severity_filter:
            return False
        
        if self.category_filter and failure.category not in self.category_filter:
            return False
        
        if self.module_filter and failure.context.module_name not in self.module_filter:
            return False
        
        return True
    
    def get_buffered_failures(self, limit: int = None) -> List[FailureRecord]:
        """קבלת כשלונות מהחוצץ"""
        failures = list(self.failure_buffer)
        if limit:
            failures = failures[-limit:]
        return failures
    
    def clear_buffer(self):
        """ניקוי חוצץ"""
        self.failure_buffer.clear()

class FailureAnalyzer:
    """מנתח כשלונות מתקדם עם AI"""
    
    def __init__(self, ollama_client=None):
        self.ollama_client = ollama_client
        self.analysis_cache = {}
        self.pattern_cache = {}
        self.similarity_threshold = 0.8
        
        # כללי ניתוח
        self.analysis_rules = self._load_analysis_rules()
        
    def _load_analysis_rules(self) -> Dict[str, Any]:
        """טעינת כללי ניתוח"""
        return {
            "ai_model_errors": {
                "keywords": ["ollama", "hudson", "llama", "model", "inference"],
                "patterns": [r"model.*error", r"inference.*failed", r"connection.*refused"],
                "severity_boost": 1.2,
                "auto_categorize": FailureCategory.AI_MODEL_ERROR
            },
            "memory_issues": {
                "keywords": ["memory", "oom", "allocation", "heap"],
                "patterns": [r"out.*memory", r"memory.*leak", r"allocation.*failed"],
                "severity_boost": 1.5,
                "auto_categorize": FailureCategory.MEMORY_ERROR
            },
            "network_timeouts": {
                "keywords": ["timeout", "connection", "network", "socket"],
                "patterns": [r"connection.*timeout", r"network.*unreachable", r"socket.*error"],
                "severity_boost": 1.0,
                "auto_categorize": FailureCategory.NETWORK_ERROR
            }
        }
    
    async def analyze_failure(self, failure: FailureRecord) -> FailureAnalysis:
        """ניתוח כשל מקיף"""
        try:
            analysis = FailureAnalysis()
            
            # ניתוח בסיסי
            analysis.root_cause = await self._identify_root_cause(failure)
            analysis.contributing_factors = await self._find_contributing_factors(failure)
            analysis.risk_factors = await self._identify_risk_factors(failure)
            
            # ניתוח דמיון
            similar_failures = await self._find_similar_failures(failure)
            analysis.similar_patterns = [f.failure_id for f in similar_failures]
            
            # ניתוח מורכבות
            analysis.complexity_score = self._calculate_complexity_score(failure)
            analysis.predictability_score = self._calculate_predictability_score(failure)
            analysis.prevention_score = self._calculate_prevention_score(failure)
            
            # ניתוח AI אם זמין
            if self.ollama_client:
                analysis.ai_analysis = await self._ai_analysis(failure)
                analysis.recommendations = await self._ai_recommendations(failure)
                analysis.analysis_confidence = 0.85
            else:
                analysis.analysis_confidence = 0.6
            
            # שמירה בקאש
            self.analysis_cache[failure.failure_id] = analysis
            
            return analysis
            
        except Exception as e:
            logging.error(f"Failure analysis error: {str(e)}")
            return FailureAnalysis(analysis_confidence=0.1)
    
    async def _identify_root_cause(self, failure: FailureRecord) -> str:
        """זיהוי סיבת שורש"""
        # בדיקת כללים קיימים
        for rule_name, rule in self.analysis_rules.items():
            if self._matches_rule(failure, rule):
                return f"זוהה כ-{rule_name}: {rule.get('description', '')}"
        
        # ניתוח טקסט השגיאה
        error_analysis = self._analyze_error_message(failure.error_message)
        if error_analysis:
            return error_analysis
        
        # ניתוח הקשר
        context_analysis = self._analyze_context(failure.context)
        if context_analysis:
            return context_analysis
        
        return "סיבת שורש לא זוהתה - נדרש ניתוח ידני"
    
    async def _find_contributing_factors(self, failure: FailureRecord) -> List[str]:
        """מציאת גורמים תורמים"""
        factors = []
        
        # בדיקת עומס מערכת
        if failure.metrics.cpu_usage_percent > 80:
            factors.append("עומס CPU גבוה")
        
        if failure.metrics.memory_usage_mb > 1000:
            factors.append("שימוש זיכרון גבוה")
        
        if failure.metrics.concurrent_users > 100:
            factors.append("עומס משתמשים גבוה")
        
        # בדיקת תזמון
        hour = failure.timestamp.hour
        if 9 <= hour <= 17:
            factors.append("שעות עומס (9-17)")
        elif 0 <= hour <= 6:
            factors.append("שעות לילה - אפשרות לתחזוקה")
        
        # בדיקת סביבה
        if failure.context.environment == "production":
            factors.append("סביבת ייצור")
        
        return factors
    
    async def _identify_risk_factors(self, failure: FailureRecord) -> List[str]:
        """זיהוי גורמי סיכון"""
        risks = []
        
        # סיכוני חזרה
        if failure.occurrence_count > 5:
            risks.append("כשל חוזר - סיכון לחזרה גבוה")
        
        # סיכוני השפעה
        if failure.severity in [FailureSeverity.HIGH, FailureSeverity.CRITICAL]:
            risks.append("חומרה גבוהה - סיכון לשירות")
        
        # סיכוני זמן
        if failure.is_recent(hours=1):
            risks.append("כשל אחרון - עלול לחזור")
        
        return risks
    
    async def _find_similar_failures(self, failure: FailureRecord) -> List[FailureRecord]:
        """מציאת כשלונות דומים"""
        # כאן יהיה אלגוריתם חיפוש דמיון מתקדם
        # לעת עתה נחזיר רשימה ריקה
        return []
    
    def _calculate_complexity_score(self, failure: FailureRecord) -> float:
        """חישוב ציון מורכבות"""
        score = 0.0
        
        # מורכבות לפי קטגוריה
        complexity_weights = {
            FailureCategory.AI_MODEL_ERROR: 0.8,
            FailureCategory.SYSTEM_ERROR: 0.7,
            FailureCategory.CONCURRENCY_ERROR: 0.9,
            FailureCategory.LOGIC_ERROR: 0.6,
            FailureCategory.VALIDATION_ERROR: 0.3
        }
        score += complexity_weights.get(failure.category, 0.5)
        
        # מורכבות לפי stack trace
        if failure.stack_trace:
            lines = len(failure.stack_trace.split('\n'))
            score += min(lines / 50, 0.3)  # עד 0.3 נקודות לstack trace
        
        # מורכבות לפי הקשר
        if failure.context.additional_context:
            score += len(failure.context.additional_context) / 100
        
        return min(score, 1.0)
    
    def _calculate_predictability_score(self, failure: FailureRecord) -> float:
        """חישוב ציון ניבוי"""
        score = 0.0
        
        # ניבוי לפי תדירות
        if failure.occurrence_count > 1:
            frequency_score = min(failure.occurrence_count / 10, 0.4)
            score += frequency_score
        
        # ניבוי לפי תבנית זמן
        if failure.is_recent(hours=24):
            score += 0.3
        
        # ניבוי לפי קטגוריה
        predictable_categories = [
            FailureCategory.TIMEOUT_ERROR,
            FailureCategory.MEMORY_ERROR,
            FailureCategory.PERFORMANCE_ERROR
        ]
        if failure.category in predictable_categories:
            score += 0.3
        
        return min(score, 1.0)
    
    def _calculate_prevention_score(self, failure: FailureRecord) -> float:
        """חישוב ציון מניעה"""
        score = 0.0
        
        # מניעה לפי קטגוריה
        preventable_categories = {
            FailureCategory.VALIDATION_ERROR: 0.9,
            FailureCategory.CONFIGURATION_ERROR: 0.8,
            FailureCategory.USER_ERROR: 0.7,
            FailureCategory.RESOURCE_ERROR: 0.6
        }
        score += preventable_categories.get(failure.category, 0.3)
        
        # מניעה לפי חומרה (כשלונות קלים יותר ניתנים למניעה)
        severity_prevention = {
            FailureSeverity.LOW: 0.8,
            FailureSeverity.MEDIUM: 0.6,
            FailureSeverity.HIGH: 0.4,
            FailureSeverity.CRITICAL: 0.2
        }
        score *= severity_prevention.get(failure.severity, 0.5)
        
        return min(score, 1.0)
    
    async def _ai_analysis(self, failure: FailureRecord) -> str:
        """ניתוח AI של הכשל"""
        if not self.ollama_client:
            return "ניתוח AI לא זמין"
        
        try:
            prompt = f"""
            נתח את הכשל הבא ובצע ניתוח מקצועי:
            
            כותרת: {failure.title}
            תיאור: {failure.description}
            קטגוריה: {failure.category.value}
            הודעת שגיאה: {failure.error_message}
            מודול: {failure.context.module_name}
            זמן: {failure.timestamp}
            מספר הופעות: {failure.occurrence_count}
            
            אנא ספק:
            1. ניתוח סיבת השורש
            2. השפעה אפשרית על המערכת
            3. דרגת חומרה מומלצת
            4. צעדי טיפול מיידיים
            
            תן תשובה קצרה ומדויקת בעברית.
            """
            
            # כאן יהיה הקוד לשליחה למודל Ollama
            # לעת עתה נחזיר ניתוח סימולציה
            return f"ניתוח AI: כשל {failure.category.value} עם חומרה {failure.severity.value}. נדרש מעקב ותיקון."
            
        except Exception as e:
            logging.error(f"AI analysis error: {str(e)}")
            return "שגיאה בניתוח AI"
    
    async def _ai_recommendations(self, failure: FailureRecord) -> List[str]:
        """המלצות AI לטיפול"""
        if not self.ollama_client:
            return ["ניתוח AI לא זמין"]
        
        try:
            # המלצות בסיסיות לפי קטגוריה
            category_recommendations = {
                FailureCategory.AI_MODEL_ERROR: [
                    "בדוק חיבור לשירות Ollama",
                    "ודא שמודל Hudson/Llama זמין",
                    "בדוק הגדרות timeout",
                    "נטר משאבי מערכת"
                ],
                FailureCategory.MEMORY_ERROR: [
                    "הגדל זיכרון זמין",
                    "בדוק דליפות זיכרון",
                    "אפטם ניהול זיכרון",
                    "הוסף ניטור זיכרון"
                ],
                FailureCategory.NETWORK_ERROR: [
                    "בדוק חיבור רשת",
                    "הגדר retry logic",
                    "הוסף circuit breaker",
                    "נטר זמני תגובה"
                ]
            }
            
            return category_recommendations.get(failure.category, ["נדרש ניתוח נוסף"])
            
        except Exception as e:
            logging.error(f"AI recommendations error: {str(e)}")
            return ["שגיאה ביצירת המלצות"]
    
    def _matches_rule(self, failure: FailureRecord, rule: Dict[str, Any]) -> bool:
        """בדיקה אם כשל תואם לכלל"""
        text_to_check = f"{failure.title} {failure.description} {failure.error_message}".lower()
        
        # בדיקת מילות מפתח
        for keyword in rule.get("keywords", []):
            if keyword.lower() in text_to_check:
                return True
        
        # בדיקת תבניות regex
        for pattern in rule.get("patterns", []):
            if re.search(pattern, text_to_check, re.IGNORECASE):
                return True
        
        return False
    
    def _analyze_error_message(self, error_message: str) -> Optional[str]:
        """ניתוח הודעת שגיאה"""
        if not error_message:
            return None
        
        error_lower = error_message.lower()
        
        # דפוסי שגיאות נפוצים
        if "connection refused" in error_lower:
            return "שירות לא זמין - חיבור נדחה"
        elif "timeout" in error_lower:
            return "חריגת זמן - שירות איטי או לא זמין"
        elif "out of memory" in error_lower:
            return "אזל זיכרון - צריך להגדיל זיכרון או לאפטם"
        elif "permission denied" in error_lower:
            return "אין הרשאות - בדוק הרשאות קבצים/תיקיות"
        elif "file not found" in error_lower:
            return "קובץ לא נמצא - בדוק נתיבים והרשאות"
        
        return None
    
    def _analyze_context(self, context) -> Optional[str]:
        """ניתוח הקשר הכשל"""
        analysis_parts = []
        
        if context.module_name:
            analysis_parts.append(f"במודול {context.module_name}")
        
        if context.function_name:
            analysis_parts.append(f"בפונקציה {context.function_name}")
        
        if context.environment == "production":
            analysis_parts.append("בסביבת ייצור")
        
        if analysis_parts:
            return " ".join(analysis_parts)
        
        return None

class PatternDetector:
    """מגלה דפוסי כשלונות"""
    
    def __init__(self):
        self.detected_patterns = {}
        self.failure_history = deque(maxlen=1000)
        
    async def detect_patterns(self, failures: List[FailureRecord]) -> List[FailurePattern_Detection]:
        """זיהוי דפוסים בכשלונות"""
        patterns = []
        
        # עדכון היסטוריה
        self.failure_history.extend(failures)
        
        # זיהוי דפוסי זמן
        time_patterns = await self._detect_time_patterns()
        patterns.extend(time_patterns)
        
        # זיהוי דפוסי תדירות
        frequency_patterns = await self._detect_frequency_patterns()
        patterns.extend(frequency_patterns)
        
        # זיהוי דפוסי קטגוריה
        category_patterns = await self._detect_category_patterns()
        patterns.extend(category_patterns)
        
        return patterns
    
    async def _detect_time_patterns(self) -> List[FailurePattern_Detection]:
        """זיהוי דפוסי זמן"""
        patterns = []
        
        if len(self.failure_history) < 10:
            return patterns
        
        # קיבוץ לפי שעות
        hourly_counts = defaultdict(int)
        for failure in self.failure_history:
            hour = failure.timestamp.hour
            hourly_counts[hour] += 1
        
        # חיפוש שעות עם כשלונות רבים
        avg_hourly = sum(hourly_counts.values()) / len(hourly_counts)
        peak_hours = [hour for hour, count in hourly_counts.items() if count > avg_hourly * 2]
        
        if peak_hours:
            pattern = FailurePattern_Detection(
                pattern_type=FailurePattern.PERIODIC,
                description=f"כשלונות מרובים בשעות: {peak_hours}",
                confidence_score=0.7,
                failure_count=sum(hourly_counts[h] for h in peak_hours)
            )
            patterns.append(pattern)
        
        return patterns
    
    async def _detect_frequency_patterns(self) -> List[FailurePattern_Detection]:
        """זיהוי דפוסי תדירות"""
        patterns = []
        
        # קיבוץ לפי קטגוריה
        category_failures = defaultdict(list)
        for failure in self.failure_history:
            category_failures[failure.category].append(failure)
        
        # בדיקת עלייה בתדירות
        for category, failures in category_failures.items():
            if len(failures) >= 5:
                recent_failures = [f for f in failures if f.is_recent(hours=24)]
                if len(recent_failures) > len(failures) * 0.5:  # יותר מחצי בתקופה אחרונה
                    pattern = FailurePattern_Detection(
                        pattern_type=FailurePattern.INCREASING,
                        description=f"עלייה בכשלונות {category.value}",
                        confidence_score=0.8,
                        failure_count=len(recent_failures)
                    )
                    patterns.append(pattern)
        
        return patterns
    
    async def _detect_category_patterns(self) -> List[FailurePattern_Detection]:
        """זיהוי דפוסי קטגוריה"""
        patterns = []
        
        # בדיקת דפוס cascading
        recent_failures = [f for f in self.failure_history if f.is_recent(hours=1)]
        if len(recent_failures) >= 3:
            categories = [f.category for f in recent_failures]
            if len(set(categories)) >= 2:  # כשלונות ממספר קטגוריות
                pattern = FailurePattern_Detection(
                    pattern_type=FailurePattern.CASCADING,
                    description="כשלונות מדרגתיים ממספר קטגוריות",
                    confidence_score=0.75,
                    failure_count=len(recent_failures)
                )
                patterns.append(pattern)
        
        return patterns

class FailureTracker:
    """מעקב כשלונות ראשי"""
    
    def __init__(self, ollama_client=None):
        self.failure_store = {}  # אחסון כשלונות
        self.collector = FailureCollector()
        self.analyzer = FailureAnalyzer(ollama_client)
        self.pattern_detector = PatternDetector()
        
        # מאזינים לאירועים
        self.event_listeners = defaultdict(list)
        
        # הגדרות
        self.auto_analyze = True
        self.auto_detect_patterns = True
        self.analysis_threshold = FailureSeverity.MEDIUM
        
        # מונים וסטטיסטיקות
        self.stats = {
            "total_failures": 0,
            "failures_by_category": defaultdict(int),
            "failures_by_severity": defaultdict(int),
            "resolution_times": [],
            "last_update": datetime.now()
        }
        
        # התחלת איסוף
        self.collector.add_real_time_handler(self._handle_new_failure)
        self.collector.start_collection()
    
    async def track_failure(self, failure: FailureRecord) -> str:
        """מעקב אחר כשל חדש"""
        try:
            # בדיקת כשל קיים
            existing = await self._find_duplicate_failure(failure)
            if existing:
                existing.update_last_occurrence()
                await self._emit_event("failure_updated", existing)
                return existing.failure_id
            
            # שמירת כשל חדש
            self.failure_store[failure.failure_id] = failure
            self.stats["total_failures"] += 1
            self.stats["failures_by_category"][failure.category.value] += 1
            self.stats["failures_by_severity"][failure.severity.value] += 1
            
            # עיבוד אוטומטי
            if self.auto_analyze and failure.severity.value in ["medium", "high", "critical"]:
                analysis = await self.analyzer.analyze_failure(failure)
                failure.analysis = analysis
                failure.ai_processed = True
            
            # איסוף
            self.collector.collect_failure(failure)
            
            # שליחת אירוע
            await self._emit_event("failure_tracked", failure)
            
            logging.info(f"Tracked new failure: {failure.title} ({failure.failure_id})")
            return failure.failure_id
            
        except Exception as e:
            logging.error(f"Error tracking failure: {str(e)}")
            raise
    
    async def resolve_failure(
        self,
        failure_id: str,
        resolution: ResolutionInfo
    ) -> bool:
        """פתרון כשל"""
        try:
            if failure_id not in self.failure_store:
                return False
            
            failure = self.failure_store[failure_id]
            failure.resolution = resolution
            failure.status = FailureStatus.RESOLVED
            
            # חישוב זמן פתרון
            if resolution.resolution_time:
                resolution_time_hours = (
                    resolution.resolution_time - failure.first_occurred
                ).total_seconds() / 3600
                self.stats["resolution_times"].append(resolution_time_hours)
            
            await self._emit_event("failure_resolved", failure)
            
            logging.info(f"Resolved failure: {failure.title}")
            return True
            
        except Exception as e:
            logging.error(f"Error resolving failure: {str(e)}")
            return False
    
    async def get_failure(self, failure_id: str) -> Optional[FailureRecord]:
        """קבלת כשל לפי ID"""
        return self.failure_store.get(failure_id)
    
    async def search_failures(
        self,
        query: str = "",
        category: Optional[FailureCategory] = None,
        severity: Optional[FailureSeverity] = None,
        status: Optional[FailureStatus] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        limit: int = 100
    ) -> List[FailureRecord]:
        """חיפוש כשלונות"""
        results = []
        
        for failure in self.failure_store.values():
            # מסנן קטגוריה
            if category and failure.category != category:
                continue
            
            # מסנן חומרה
            if severity and failure.severity != severity:
                continue
            
            # מסנן סטטוס
            if status and failure.status != status:
                continue
            
            # מסנן תאריכים
            if date_from and failure.timestamp < date_from:
                continue
            if date_to and failure.timestamp > date_to:
                continue
            
            # חיפוש טקסט
            if query and query.lower() not in failure.search_text:
                continue
            
            results.append(failure)
            
            if len(results) >= limit:
                break
        
        # מיון לפי זמן (האחרונים ראשונים)
        results.sort(key=lambda f: f.timestamp, reverse=True)
        return results
    
    async def get_statistics(self, period_days: int = 30) -> FailureStatistics:
        """קבלת סטטיסטיקות"""
        end_time = datetime.now()
        start_time = end_time - timedelta(days=period_days)
        
        # סינון כשלונות לתקופה
        period_failures = [
            f for f in self.failure_store.values()
            if start_time <= f.timestamp <= end_time
        ]
        
        stats = FailureStatistics(
            period_start=start_time,
            period_end=end_time,
            total_failures=len(period_failures),
            new_failures=len([f for f in period_failures if f.occurrence_count == 1]),
            resolved_failures=len([f for f in period_failures if f.status == FailureStatus.RESOLVED]),
            active_failures=len([f for f in period_failures if f.status == FailureStatus.ACTIVE])
        )
        
        # תפלגויות
        for failure in period_failures:
            stats.by_category[failure.category.value] += 1
            stats.by_severity[failure.severity.value] += 1
            stats.by_module[failure.context.module_name] += 1
        
        # זמני פתרון
        resolved_times = [
            f.get_duration_minutes() for f in period_failures
            if f.status == FailureStatus.RESOLVED
        ]
        
        if resolved_times:
            stats.avg_resolution_time_hours = statistics.mean(resolved_times) / 60
            stats.median_resolution_time_hours = statistics.median(resolved_times) / 60
            stats.max_resolution_time_hours = max(resolved_times) / 60
        
        # השפעה כוללת
        stats.total_downtime_minutes = sum(f.impact.downtime_minutes for f in period_failures)
        stats.total_affected_users = sum(f.impact.affected_users_count for f in period_failures)
        
        return stats
    
    async def detect_patterns(self) -> List[FailurePattern_Detection]:
        """זיהוי דפוסים בכשלונות"""
        if not self.auto_detect_patterns:
            return []
        
        recent_failures = [
            f for f in self.failure_store.values()
            if f.is_recent(hours=168)  # שבוע אחרון
        ]
        
        return await self.pattern_detector.detect_patterns(recent_failures)
    
    async def _find_duplicate_failure(self, failure: FailureRecord) -> Optional[FailureRecord]:
        """חיפוש כשל כפול"""
        for existing in self.failure_store.values():
            if (existing.error_message == failure.error_message and
                existing.context.module_name == failure.context.module_name and
                existing.context.function_name == failure.context.function_name and
                existing.status != FailureStatus.RESOLVED):
                return existing
        return None
    
    def _handle_new_failure(self, failure: FailureRecord):
        """טיפול בכשל חדש בזמן אמת"""
        try:
            # בדיקת חומרה קריטית
            if failure.severity == FailureSeverity.CRITICAL:
                asyncio.create_task(self._send_critical_alert(failure))
            
            # עדכון מטריקות זמן אמת
            self.stats["last_update"] = datetime.now()
            
        except Exception as e:
            logging.error(f"Real-time failure handling error: {str(e)}")
    
    async def _send_critical_alert(self, failure: FailureRecord):
        """שליחת התראה קריטית"""
        alert = FailureAlert(
            failure_id=failure.failure_id,
            alert_type="critical",
            message=f"כשל קריטי: {failure.title}",
            severity=FailureSeverity.CRITICAL
        )
        
        await self._emit_event("critical_alert", alert)
    
    async def _emit_event(self, event_type: str, data: Any):
        """שליחת אירוע"""
        if event_type in self.event_listeners:
            for listener in self.event_listeners[event_type]:
                try:
                    await listener(data)
                except Exception as e:
                    logging.error(f"Event listener error: {str(e)}")
    
    def add_event_listener(self, event_type: str, listener: Callable):
        """הוספת מאזין לאירועים"""
        self.event_listeners[event_type].append(listener)
    
    def get_system_health(self) -> Dict[str, Any]:
        """בדיקת בריאות מערכת המעקב"""
        recent_failures = [
            f for f in self.failure_store.values()
            if f.is_recent(hours=1)
        ]
        
        critical_failures = [
            f for f in recent_failures
            if f.severity == FailureSeverity.CRITICAL
        ]
        
        return {
            "status": "critical" if critical_failures else "healthy",
            "total_failures": len(self.failure_store),
            "recent_failures_1h": len(recent_failures),
            "critical_failures_1h": len(critical_failures),
            "collection_active": self.collector.is_collecting,
            "last_update": self.stats["last_update"].isoformat()
        }
    
    def shutdown(self):
        """כיבוי מערכת המעקב"""
        self.collector.stop_collection()
        logging.info("Failure tracker shutdown completed")