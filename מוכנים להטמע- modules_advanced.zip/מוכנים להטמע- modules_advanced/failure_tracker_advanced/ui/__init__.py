"""
UI package for Failure Tracker Advanced Module

Contains user interface components for failure tracking dashboards and visualizations.
"""

from .failure_dashboard import FailureDashboard
from .pattern_visualizer import PatternVisualizer
from .learning_insights_panel import LearningInsightsPanel

__all__ = [
    'FailureDashboard',
    'PatternVisualizer',
    'LearningInsightsPanel'
]