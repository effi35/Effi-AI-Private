"""
Failure Tracker Advanced - Failure Types and Models
מודלים למעקב אחר כשלונות מערכת AI ולמידה מהם
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Set, Union
from datetime import datetime, timedelta
import uuid
import json
import traceback

class FailureCategory(Enum):
    """קטגוריות כשל"""
    SYSTEM_ERROR = "system_error"                   # שגיאת מערכת
    AI_MODEL_ERROR = "ai_model_error"              # שגיאת מודל AI
    NETWORK_ERROR = "network_error"                # שגיאת רשת
    DATABASE_ERROR = "database_error"              # שגיאת מסד נתונים
    AUTHENTICATION_ERROR = "authentication_error"  # שגיאת אימות
    AUTHORIZATION_ERROR = "authorization_error"    # שגיאת הרשאה
    VALIDATION_ERROR = "validation_error"          # שגיאת אימות נתונים
    CONFIGURATION_ERROR = "configuration_error"   # שגיאת הגדרות
    RESOURCE_ERROR = "resource_error"              # שגיאת משאבים
    TIMEOUT_ERROR = "timeout_error"                # שגיאת timeout
    PARSING_ERROR = "parsing_error"                # שגיאת parsing
    LOGIC_ERROR = "logic_error"                    # שגיאת לוגיקה
    USER_ERROR = "user_error"                      # שגיאת משתמש
    EXTERNAL_SERVICE_ERROR = "external_service_error"  # שגיאת שירות חיצוני
    PERFORMANCE_ERROR = "performance_error"        # שגיאת ביצועים
    MEMORY_ERROR = "memory_error"                  # שגיאת זיכרון
    CONCURRENCY_ERROR = "concurrency_error"       # שגיאת מקבילות
    UNKNOWN_ERROR = "unknown_error"                # שגיאה לא ידועה

class FailureSeverity(Enum):
    """חומרת הכשל"""
    LOW = "low"                    # נמוכה - לא משפיע על הפעולה
    MEDIUM = "medium"              # בינונית - פגיעה חלקית בפעולה
    HIGH = "high"                  # גבוהה - פגיעה משמעותית
    CRITICAL = "critical"          # קריטית - עצירת פעולה
    FATAL = "fatal"                # קטלני - קריסת מערכת

class FailureStatus(Enum):
    """סטטוס הכשל"""
    ACTIVE = "active"              # פעיל - טרם טופל
    INVESTIGATING = "investigating" # בחקירה
    FIXING = "fixing"              # בתיקון
    RESOLVED = "resolved"          # נפתר
    CLOSED = "closed"              # סגור
    IGNORED = "ignored"            # מתעלמים
    DUPLICATE = "duplicate"        # כפול

class FailurePattern(Enum):
    """דפוסי כשל"""
    SPORADIC = "sporadic"          # ספורדי
    PERIODIC = "periodic"          # תקופתי
    INCREASING = "increasing"      # עולה
    DECREASING = "decreasing"      # יורד
    BURST = "burst"               # פרץ
    CONSTANT = "constant"          # קבוע
    SEASONAL = "seasonal"          # עונתי
    CASCADING = "cascading"        # מדרגתי

class ImpactLevel(Enum):
    """רמת השפעה"""
    NO_IMPACT = "no_impact"        # ללא השפעה
    MINOR_IMPACT = "minor_impact"  # השפעה קלה
    MODERATE_IMPACT = "moderate_impact"  # השפעה בינונית
    MAJOR_IMPACT = "major_impact"  # השפעה משמעותית
    SEVERE_IMPACT = "severe_impact" # השפעה חמורה

@dataclass
class FailureContext:
    """הקשר הכשל"""
    module_name: str = ""                    # שם המודול
    function_name: str = ""                  # שם הפונקציה
    file_path: str = ""                      # נתיב הקובץ
    line_number: int = 0                     # מספר שורה
    user_id: Optional[str] = None            # מזהה משתמש
    session_id: Optional[str] = None         # מזהה session
    request_id: Optional[str] = None         # מזהה בקשה
    environment: str = "production"          # סביבה
    version: str = ""                        # גרסת המערכת
    platform: str = ""                      # פלטפורמה
    browser: str = ""                        # דפדפן
    ip_address: str = ""                     # כתובת IP
    user_agent: str = ""                     # User agent
    additional_context: Dict[str, Any] = field(default_factory=dict)

@dataclass
class FailureMetrics:
    """מטריקות כשל"""
    response_time_ms: float = 0.0           # זמן תגובה
    memory_usage_mb: float = 0.0            # שימוש בזיכרון
    cpu_usage_percent: float = 0.0          # שימוש במעבד
    concurrent_users: int = 0               # משתמשים מקבילים
    request_count: int = 0                  # מספר בקשות
    error_rate: float = 0.0                 # שיעור שגיאות
    system_load: float = 0.0                # עומס מערכת
    disk_usage_percent: float = 0.0         # שימוש בדיסק
    network_latency_ms: float = 0.0         # זמן תגובת רשת

@dataclass
class ResolutionInfo:
    """מידע על פתרון"""
    resolution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    resolved_by: str = ""                   # מי פתר
    resolution_time: Optional[datetime] = None  # מתי נפתר
    resolution_method: str = ""             # שיטת פתרון
    fix_description: str = ""               # תיאור התיקון
    code_changes: List[str] = field(default_factory=list)  # שינויים בקוד
    configuration_changes: Dict[str, Any] = field(default_factory=dict)  # שינויי הגדרות
    workaround: str = ""                    # פתרון זמני
    prevention_measures: List[str] = field(default_factory=list)  # אמצעי מניעה
    lessons_learned: List[str] = field(default_factory=list)  # לקחים נלמדו
    related_failures: List[str] = field(default_factory=list)  # כשלונות קשורים

@dataclass
class FailureImpact:
    """השפעת הכשל"""
    impact_level: ImpactLevel = ImpactLevel.NO_IMPACT
    affected_users_count: int = 0           # מספר משתמשים מושפעים
    affected_modules: List[str] = field(default_factory=list)  # מודולים מושפעים
    business_impact: str = ""               # השפעה עסקית
    revenue_impact: float = 0.0             # השפעה על הכנסות
    downtime_minutes: float = 0.0           # זמן השבתה בדקות
    data_loss: bool = False                 # אובדן נתונים
    security_breach: bool = False           # פרצת אבטחה
    customer_complaints: int = 0            # תלונות לקוחות
    media_attention: bool = False           # תשומת לב תקשורתית

@dataclass
class FailureAnalysis:
    """ניתוח כשל"""
    analysis_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    root_cause: str = ""                    # סיבת שורש
    contributing_factors: List[str] = field(default_factory=list)  # גורמים תורמים
    failure_chain: List[str] = field(default_factory=list)  # שרשרת כשלונות
    similar_patterns: List[str] = field(default_factory=list)  # דפוסים דומים
    risk_factors: List[str] = field(default_factory=list)  # גורמי סיכון
    complexity_score: float = 0.0           # ציון מורכבות (0-1)
    predictability_score: float = 0.0       # ציון ניבוי (0-1)
    prevention_score: float = 0.0           # ציון מניעה (0-1)
    ai_analysis: str = ""                   # ניתוח AI
    recommendations: List[str] = field(default_factory=list)  # המלצות
    analysis_confidence: float = 0.0        # רמת ביטחון בניתוח

@dataclass
class FailureRecord:
    """רשומת כשל מלאה"""
    failure_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    
    # מידע בסיסי
    title: str = ""
    description: str = ""
    category: FailureCategory = FailureCategory.UNKNOWN_ERROR
    severity: FailureSeverity = FailureSeverity.MEDIUM
    status: FailureStatus = FailureStatus.ACTIVE
    
    # מידע טכני
    error_message: str = ""
    exception_type: str = ""
    stack_trace: str = ""
    error_code: Optional[str] = None
    
    # הקשר
    context: FailureContext = field(default_factory=FailureContext)
    metrics: FailureMetrics = field(default_factory=FailureMetrics)
    impact: FailureImpact = field(default_factory=FailureImpact)
    
    # ניתוח ופתרון
    analysis: Optional[FailureAnalysis] = None
    resolution: Optional[ResolutionInfo] = None
    
    # מעקב זמנים
    first_occurred: datetime = field(default_factory=datetime.now)
    last_occurred: datetime = field(default_factory=datetime.now)
    occurrence_count: int = 1
    
    # חיפוש ותיוג
    tags: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    search_text: str = ""
    
    # קישורים
    related_failures: List[str] = field(default_factory=list)  # כשלונות קשורים
    duplicate_of: Optional[str] = None                          # כפול של
    parent_failure: Optional[str] = None                       # כשל אב
    child_failures: List[str] = field(default_factory=list)    # כשלונות ילד
    
    # מטאדטה
    created_by: str = "system"
    assigned_to: Optional[str] = None
    priority: int = 5                                          # 1-10
    external_ticket_id: Optional[str] = None
    
    # אוטומציה
    auto_detected: bool = True
    auto_categorized: bool = False
    ai_processed: bool = False
    
    def update_last_occurrence(self):
        """עדכון מועד אחרון"""
        self.last_occurred = datetime.now()
        self.occurrence_count += 1
    
    def add_tag(self, tag: str):
        """הוספת תג"""
        if tag not in self.tags:
            self.tags.append(tag)
            self._update_search_text()
    
    def add_keyword(self, keyword: str):
        """הוספת מילת מפתח"""
        if keyword not in self.keywords:
            self.keywords.append(keyword)
            self._update_search_text()
    
    def _update_search_text(self):
        """עדכון טקסט חיפוש"""
        search_parts = [
            self.title,
            self.description,
            self.error_message,
            ' '.join(self.tags),
            ' '.join(self.keywords),
            self.context.module_name,
            self.context.function_name
        ]
        self.search_text = ' '.join(filter(None, search_parts)).lower()
    
    def calculate_age_hours(self) -> float:
        """חישוב גיל הכשל בשעות"""
        return (datetime.now() - self.first_occurred).total_seconds() / 3600
    
    def calculate_frequency_per_hour(self) -> float:
        """חישוב תדירות כשל לשעה"""
        age_hours = self.calculate_age_hours()
        return self.occurrence_count / max(age_hours, 0.0167)  # מינימום דקה אחת
    
    def is_recent(self, hours: int = 24) -> bool:
        """בדיקה אם כשל הוא אחרון"""
        return (datetime.now() - self.last_occurred).total_seconds() < hours * 3600
    
    def get_duration_minutes(self) -> float:
        """קבלת משך הכשל בדקות"""
        if self.resolution and self.resolution.resolution_time:
            return (self.resolution.resolution_time - self.first_occurred).total_seconds() / 60
        return (datetime.now() - self.first_occurred).total_seconds() / 60

@dataclass
class FailurePattern_Detection:
    """זיהוי דפוס כשל"""
    pattern_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    pattern_type: FailurePattern = FailurePattern.SPORADIC
    description: str = ""
    
    # מאפייני הדפוס
    confidence_score: float = 0.0           # רמת ביטחון (0-1)
    frequency: str = ""                     # תדירות
    duration_pattern: str = ""              # דפוס משך זמן
    time_pattern: str = ""                  # דפוס זמן (שעות/ימים)
    
    # נתונים סטטיסטיים
    failure_count: int = 0
    avg_interval_minutes: float = 0.0
    std_interval_minutes: float = 0.0
    trend_direction: str = ""               # "increasing", "decreasing", "stable"
    
    # כשלונות קשורים
    related_failure_ids: List[str] = field(default_factory=list)
    similar_patterns: List[str] = field(default_factory=list)
    
    # זמנים
    first_detected: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    
    # חיזוי
    next_predicted_failure: Optional[datetime] = None
    prediction_confidence: float = 0.0
    
    # אמצעי מניעה
    prevention_suggestions: List[str] = field(default_factory=list)
    monitoring_recommendations: List[str] = field(default_factory=list)

@dataclass
class FailureAlert:
    """התראת כשל"""
    alert_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    failure_id: str = ""
    alert_type: str = ""                    # "new", "recurring", "critical", "resolved"
    message: str = ""
    severity: FailureSeverity = FailureSeverity.MEDIUM
    
    # נמענים
    recipients: List[str] = field(default_factory=list)
    notification_channels: List[str] = field(default_factory=list)  # email, slack, sms
    
    # סטטוס
    sent: bool = False
    sent_at: Optional[datetime] = None
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None
    
    # הגדרות
    escalation_level: int = 0
    auto_resolve: bool = True
    
    def acknowledge(self, user: str):
        """אישור קבלת התראה"""
        self.acknowledged = True
        self.acknowledged_by = user
        self.acknowledged_at = datetime.now()

@dataclass
class FailureStatistics:
    """סטטיסטיקות כשלונות"""
    period_start: datetime
    period_end: datetime
    
    # ספירות בסיסיות
    total_failures: int = 0
    new_failures: int = 0
    resolved_failures: int = 0
    active_failures: int = 0
    
    # תפלגות לפי קטגוריה
    by_category: Dict[str, int] = field(default_factory=dict)
    by_severity: Dict[str, int] = field(default_factory=dict)
    by_module: Dict[str, int] = field(default_factory=dict)
    
    # מטריקות זמן
    avg_resolution_time_hours: float = 0.0
    median_resolution_time_hours: float = 0.0
    max_resolution_time_hours: float = 0.0
    
    # מטריקות השפעה
    total_downtime_minutes: float = 0.0
    total_affected_users: int = 0
    
    # מגמות
    trend_direction: str = ""               # "improving", "worsening", "stable"
    improvement_percentage: float = 0.0
    
    # דפוסים
    most_common_failure_type: str = ""
    peak_failure_hours: List[int] = field(default_factory=list)
    peak_failure_days: List[str] = field(default_factory=list)

class FailureFactory:
    """יצרן כשלונות עם תבניות מוכנות"""
    
    @staticmethod
    def create_ai_model_failure(
        model_name: str,
        error_message: str,
        context: Dict[str, Any] = None
    ) -> FailureRecord:
        """יצירת כשל מודל AI"""
        failure = FailureRecord(
            title=f"AI Model Failure - {model_name}",
            description=f"כשל במודל AI {model_name}: {error_message}",
            category=FailureCategory.AI_MODEL_ERROR,
            severity=FailureSeverity.HIGH,
            error_message=error_message
        )
        
        if context:
            failure.context.additional_context = context
        
        failure.add_tag("ai_model")
        failure.add_tag(model_name.lower())
        failure.add_keyword("ollama")
        failure.add_keyword("hudson")
        failure.add_keyword("llama")
        
        return failure
    
    @staticmethod
    def create_network_timeout_failure(
        service_name: str,
        timeout_seconds: float,
        url: str = ""
    ) -> FailureRecord:
        """יצירת כשל timeout רשת"""
        failure = FailureRecord(
            title=f"Network Timeout - {service_name}",
            description=f"timeout בחיבור לשירות {service_name} לאחר {timeout_seconds} שניות",
            category=FailureCategory.TIMEOUT_ERROR,
            severity=FailureSeverity.MEDIUM,
            error_message=f"Connection timeout after {timeout_seconds}s"
        )
        
        failure.context.additional_context = {
            "service_name": service_name,
            "timeout_seconds": timeout_seconds,
            "url": url
        }
        
        failure.metrics.response_time_ms = timeout_seconds * 1000
        
        failure.add_tag("network")
        failure.add_tag("timeout")
        failure.add_keyword(service_name.lower())
        
        return failure
    
    @staticmethod
    def create_memory_error_failure(
        memory_usage_mb: float,
        available_memory_mb: float,
        process_name: str = ""
    ) -> FailureRecord:
        """יצירת כשל זיכרון"""
        failure = FailureRecord(
            title="Memory Error",
            description=f"כשל זיכרון - שימוש: {memory_usage_mb}MB, זמין: {available_memory_mb}MB",
            category=FailureCategory.MEMORY_ERROR,
            severity=FailureSeverity.HIGH,
            error_message="Out of memory"
        )
        
        failure.metrics.memory_usage_mb = memory_usage_mb
        failure.context.additional_context = {
            "available_memory_mb": available_memory_mb,
            "process_name": process_name
        }
        
        if memory_usage_mb > available_memory_mb * 0.9:
            failure.severity = FailureSeverity.CRITICAL
        
        failure.add_tag("memory")
        failure.add_tag("performance")
        
        return failure
    
    @staticmethod
    def create_validation_error_failure(
        field_name: str,
        invalid_value: Any,
        validation_rule: str
    ) -> FailureRecord:
        """יצירת כשל אימות נתונים"""
        failure = FailureRecord(
            title="Validation Error",
            description=f"שגיאת אימות בשדה {field_name}: {invalid_value}",
            category=FailureCategory.VALIDATION_ERROR,
            severity=FailureSeverity.LOW,
            error_message=f"Validation failed for field '{field_name}'"
        )
        
        failure.context.additional_context = {
            "field_name": field_name,
            "invalid_value": str(invalid_value),
            "validation_rule": validation_rule
        }
        
        failure.add_tag("validation")
        failure.add_tag("user_input")
        failure.add_keyword(field_name.lower())
        
        return failure
    
    @staticmethod
    def create_from_exception(
        exception: Exception,
        context: Optional[FailureContext] = None
    ) -> FailureRecord:
        """יצירת כשל מ-Exception"""
        failure = FailureRecord(
            title=f"{type(exception).__name__}",
            description=str(exception),
            category=FailureFactory._categorize_exception(exception),
            severity=FailureFactory._determine_severity(exception),
            error_message=str(exception),
            exception_type=type(exception).__name__,
            stack_trace=traceback.format_exc()
        )
        
        if context:
            failure.context = context
        
        failure.add_tag("exception")
        failure.add_tag(type(exception).__name__.lower())
        
        return failure
    
    @staticmethod
    def _categorize_exception(exception: Exception) -> FailureCategory:
        """קטגוריזציה של Exception"""
        exception_categories = {
            'ConnectionError': FailureCategory.NETWORK_ERROR,
            'TimeoutError': FailureCategory.TIMEOUT_ERROR,
            'MemoryError': FailureCategory.MEMORY_ERROR,
            'ValueError': FailureCategory.VALIDATION_ERROR,
            'KeyError': FailureCategory.LOGIC_ERROR,
            'AttributeError': FailureCategory.LOGIC_ERROR,
            'FileNotFoundError': FailureCategory.SYSTEM_ERROR,
            'PermissionError': FailureCategory.AUTHORIZATION_ERROR,
            'RuntimeError': FailureCategory.SYSTEM_ERROR,
        }
        
        exception_name = type(exception).__name__
        return exception_categories.get(exception_name, FailureCategory.UNKNOWN_ERROR)
    
    @staticmethod
    def _determine_severity(exception: Exception) -> FailureSeverity:
        """קביעת חומרת Exception"""
        critical_exceptions = ['MemoryError', 'SystemExit', 'KeyboardInterrupt']
        high_exceptions = ['ConnectionError', 'TimeoutError', 'RuntimeError']
        low_exceptions = ['ValueError', 'TypeError', 'AttributeError']
        
        exception_name = type(exception).__name__
        
        if exception_name in critical_exceptions:
            return FailureSeverity.CRITICAL
        elif exception_name in high_exceptions:
            return FailureSeverity.HIGH
        elif exception_name in low_exceptions:
            return FailureSeverity.LOW
        else:
            return FailureSeverity.MEDIUM

# פונקציות עזר
def create_failure_from_log(
    log_line: str,
    log_level: str,
    timestamp: datetime,
    source: str = ""
) -> Optional[FailureRecord]:
    """יצירת כשל מרשומת לוג"""
    if log_level.upper() not in ['ERROR', 'CRITICAL', 'FATAL']:
        return None
    
    severity_map = {
        'ERROR': FailureSeverity.MEDIUM,
        'CRITICAL': FailureSeverity.HIGH,
        'FATAL': FailureSeverity.CRITICAL
    }
    
    failure = FailureRecord(
        title="Log Error",
        description=log_line,
        category=FailureCategory.SYSTEM_ERROR,
        severity=severity_map.get(log_level.upper(), FailureSeverity.MEDIUM),
        error_message=log_line,
        timestamp=timestamp
    )
    
    if source:
        failure.context.module_name = source
    
    failure.add_tag("log_error")
    failure.add_tag(log_level.lower())
    
    return failure

def validate_failure_record(failure: FailureRecord) -> List[str]:
    """אימות תקינות רשומת כשל"""
    errors = []
    
    if not failure.title:
        errors.append("כותרת הכשל חובה")
    
    if not failure.description:
        errors.append("תיאור הכשל חובה")
    
    if failure.occurrence_count < 1:
        errors.append("מספר הופעות חייב להיות לפחות 1")
    
    if failure.priority < 1 or failure.priority > 10:
        errors.append("עדיפות חייבת להיות בין 1 ל-10")
    
    if failure.first_occurred > failure.last_occurred:
        errors.append("זמן הופעה ראשונה לא יכול להיות אחרי האחרונה")
    
    return errors