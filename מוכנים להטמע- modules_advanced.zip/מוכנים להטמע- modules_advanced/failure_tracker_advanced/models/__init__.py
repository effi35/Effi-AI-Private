"""
Models package for Failure Tracker Advanced Module

Contains data models and types for failure tracking and analysis.
"""

from .failure_types import FailureType, FailureCategory, FailureSeverity
from .analysis_models import AnalysisResult, Pattern, Insight
from .system_models import SystemHealth, PerformanceMetric

__all__ = [
    'FailureType',
    'FailureCategory', 
    'FailureSeverity',
    'AnalysisResult',
    'Pattern',
    'Insight',
    'SystemHealth',
    'PerformanceMetric'
]