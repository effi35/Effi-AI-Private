#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ניהול מודולים Module - מודול ניהול מודולים
מערכת טעינה ונידול דינמית של מודולים
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from .core.module_management_engine import ModuleManagementEngine
from .ui.module_management_dashboard import ModuleManagementDashboard
from .models.module_management_types import *

logger = logging.getLogger(__name__)


class ModuleManagementModule:
    """מודול ניהול מודולים"""
    
    def __init__(self):
        """Initialize the ניהול מודולים Module"""
        self.name = "module_management"
        self.version = "2.0.0"
        self.description = "מערכת טעינה ונידול דינמית של מודולים"
        self.hebrew_name = "ניהול מודולים"
        self.is_active = False
        
        # Core engine
        self.engine = None
        
        # UI components
        self.dashboard = None
        
        # Module statistics
        self.statistics = {
            "total_operations": 0,
            "successful_operations": 0,
            "failed_operations": 0,
            "uptime_seconds": 0
        }
        
        self.startup_time = None
    
    def start(self) -> bool:
        """הפעלת המודול"""
        try:
            logger.info(f"[{self.hebrew_name}] מתחיל אתחול...")
            self.startup_time = datetime.now()
            
            # Initialize core engine
            self.engine = ModuleManagementEngine()
            
            # Initialize UI
            self.dashboard = ModuleManagementDashboard(self.engine)
            
            # Update statistics
            self._update_statistics()
            
            self.is_active = True
            logger.info(f"[{self.hebrew_name}] הופעל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"[{self.hebrew_name}] שגיאה בהפעלה: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת המודול"""
        try:
            logger.info(f"[{self.hebrew_name}] עוצר...")
            
            # Save final statistics
            self._update_statistics()
            
            self.is_active = False
            logger.info(f"[{self.hebrew_name}] נעצר בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"[{self.hebrew_name}] שגיאה בעצירה: {e}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """קבלת סטטוס המודול"""
        status = {
            "module": self.name,
            "hebrew_name": self.hebrew_name,
            "version": self.version,
            "description": self.description,
            "is_active": self.is_active,
            "statistics": self.statistics.copy()
        }
        
        if self.engine:
            status["engine_status"] = self.engine.get_status()
        
        return status
    
    def execute_operation(self, operation: str, **kwargs) -> Any:
        """ביצוע פעולה של המודול"""
        if not self.is_active or not self.engine:
            return None
        
        try:
            result = self.engine.execute_operation(operation, **kwargs)
            
            self.statistics["total_operations"] += 1
            if result is not None:
                self.statistics["successful_operations"] += 1
            else:
                self.statistics["failed_operations"] += 1
            
            return result
            
        except Exception as e:
            logger.error(f"[{self.hebrew_name}] שגיאה בביצוע פעולה {operation}: {e}")
            self.statistics["failed_operations"] += 1
            return None
    
    def _update_statistics(self):
        """עדכון סטטיסטיקות"""
        if self.startup_time:
            uptime = (datetime.now() - self.startup_time).total_seconds()
            self.statistics["uptime_seconds"] = int(uptime)


# Module instance for import
module_instance = ModuleManagementModule()
