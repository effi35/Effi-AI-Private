#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
עיבוד שפה מתקדם Engine - מנוע עיבוד שפה מתקדם
Advanced NLP Engine with Local AI Integration
"""

import logging
import asyncio
import uuid
import json
import re
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field

from ..models.nlp_advanced_types import NlpAdvancedConfig, NlpAdvancedResult, NlpAdvancedStatistics

# Local AI Integration
from ...local_ai_integration.core.ollama_client import OllamaClient
from ...local_ai_integration.models.ollama_integration import InferenceRequest, InferenceMode
from ...local_ai_integration.utils.local_ai_utils import (
    MessageProcessor, PromptTemplates, ResponseProcessor, LocalAIConfig
)

logger = logging.getLogger(__name__)

@dataclass
class TextAnalysisResult:
    """Result of text analysis"""
    sentiment: str = "neutral"  # positive, negative, neutral
    sentiment_score: float = 0.0  # -1.0 to 1.0
    language: str = "unknown"
    entities: List[Dict[str, Any]] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    topics: List[str] = field(default_factory=list)
    emotions: List[Dict[str, float]] = field(default_factory=list)
    complexity_score: float = 0.0
    readability_score: float = 0.0
    text_quality: str = "unknown"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'sentiment': self.sentiment,
            'sentiment_score': self.sentiment_score,
            'language': self.language,
            'entities': self.entities,
            'keywords': self.keywords,
            'topics': self.topics,
            'emotions': self.emotions,
            'complexity_score': self.complexity_score,
            'readability_score': self.readability_score,
            'text_quality': self.text_quality
        }

@dataclass
class TranslationResult:
    """Result of text translation"""
    original_text: str
    translated_text: str
    source_language: str
    target_language: str
    confidence_score: float = 0.0
    translation_quality: str = "unknown"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'original_text': self.original_text,
            'translated_text': self.translated_text,
            'source_language': self.source_language,
            'target_language': self.target_language,
            'confidence_score': self.confidence_score,
            'translation_quality': self.translation_quality
        }

@dataclass
class SummarizationResult:
    """Result of text summarization"""
    original_text: str
    summary: str
    summary_type: str = "extractive"  # extractive, abstractive
    compression_ratio: float = 0.0
    key_points: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'original_text': self.original_text,
            'summary': self.summary,
            'summary_type': self.summary_type,
            'compression_ratio': self.compression_ratio,
            'key_points': self.key_points
        }


class NlpAdvancedEngine:
    """מנוע עיבוד שפה מתקדם"""
    
    def __init__(self, config: NlpAdvancedConfig = None):
        """אתחול המנוע"""
        self.config = config or NlpAdvancedConfig()
        self.is_active = False
        self.statistics = NlpAdvancedStatistics()
        self.startup_time = None
        
        # Local AI Integration
        self.local_ai_client: Optional[OllamaClient] = None
        self.ai_enabled: bool = True
        self.ai_model_name: str = LocalAIConfig.DEFAULT_MODEL
        
        # Hebrew language patterns
        self.hebrew_patterns = self._initialize_hebrew_patterns()
        
        # Analysis cache
        self.analysis_cache: Dict[str, Dict] = {}
        
        # Initialize local AI
        self._initialize_local_ai()
    
    def _initialize_local_ai(self):
        """אתחול אינטגרציית בינה מלאכותית מקומית"""
        try:
            self.local_ai_client = OllamaClient()
            logger.info(f"Local AI client initialized for NLP with model: {self.ai_model_name}")
        except Exception as e:
            logger.warning(f"Failed to initialize local AI for NLP: {e}")
            self.ai_enabled = False
    
    def _initialize_hebrew_patterns(self) -> Dict[str, Any]:
        """Initialize Hebrew language patterns"""
        return {
            'hebrew_chars': r'[\u0590-\u05FF]',
            'hebrew_word': r'[\u0590-\u05FF]+',
            'hebrew_sentence': r'[\u0590-\u05FF\s\.,!?;:()"-]+',
            'mixed_text': r'[\u0590-\u05FF\u0000-\u007F\s\.,!?;:()"-]+',
            'common_stopwords': [
                'של', 'את', 'על', 'אל', 'מן', 'אם', 'כי', 'זה', 'זו', 'זאת',
                'הוא', 'היא', 'הם', 'הן', 'אני', 'אתה', 'אתם', 'אתן', 'לא',
                'כל', 'עם', 'בין', 'אחר', 'אחרי', 'לפני', 'תחת', 'מעל'
            ],
            'emotion_words': {
                'positive': ['שמח', 'טוב', 'נהדר', 'מעולה', 'יפה', 'אהבה', 'אושר'],
                'negative': ['עצוב', 'רע', 'גרוע', 'כעס', 'פחד', 'דאגה', 'כאב'],
                'neutral': ['בסדר', 'רגיל', 'נורמלי', 'אמצעי', 'סביר']
            }
        }
    
    def start(self) -> bool:
        """הפעלת המנוע"""
        try:
            logger.info("מתחיל הפעלת מנוע עיבוד שפה מתקדם")
            self.startup_time = datetime.now()
            
            # Initialize engine components here
            
            self.is_active = True
            logger.info("מנוע עיבוד שפה מתקדם הופעל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בהפעלת מנוע עיבוד שפה מתקדם: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת המנוע"""
        try:
            logger.info("עוצר מנוע עיבוד שפה מתקדם")
            
            # Cleanup engine components here
            
            self.is_active = False
            logger.info("מנוע עיבוד שפה מתקדם נעצר בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בעצירת מנוע עיבוד שפה מתקדם: {e}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """קבלת סטטוס המנוע"""
        uptime = 0
        if self.startup_time:
            uptime = (datetime.now() - self.startup_time).total_seconds()
        
        return {
            "is_active": self.is_active,
            "uptime_seconds": int(uptime),
            "statistics": {
                "total_operations": self.statistics.total_operations,
                "successful_operations": self.statistics.successful_operations,
                "failed_operations": self.statistics.failed_operations,
                "average_execution_time": self.statistics.average_execution_time
            },
            "config": {
                "enabled": self.config.enabled,
                "max_concurrent_operations": self.config.max_concurrent_operations,
                "timeout_seconds": self.config.timeout_seconds
            },
            "ai_integration": {
                "enabled": self.ai_enabled,
                "model_name": self.ai_model_name,
                "client_status": "connected" if self.local_ai_client else "disconnected"
            },
            "cache_size": len(self.analysis_cache)
        }
    
    async def analyze_text(self, text: str, analysis_types: List[str] = None) -> TextAnalysisResult:
        """
        ניתוח טקסט מקיף
        Comprehensive text analysis
        """
        if not self.is_active:
            raise RuntimeError("המנוע לא פעיל")
        
        start_time = datetime.now()
        
        try:
            # Default analysis types
            if analysis_types is None:
                analysis_types = ['sentiment', 'language', 'entities', 'keywords', 'emotions']
            
            # Check cache first
            cache_key = self._get_cache_key(text, analysis_types)
            if cache_key in self.analysis_cache:
                self.statistics.total_operations += 1
                self.statistics.successful_operations += 1
                return TextAnalysisResult(**self.analysis_cache[cache_key])
            
            result = TextAnalysisResult()
            
            # Basic language detection
            result.language = self._detect_language(text)
            
            # AI-powered analysis if available
            if self.ai_enabled and self.local_ai_client:
                ai_analysis = await self._analyze_text_with_ai(text, analysis_types)
                
                # Merge AI results
                if ai_analysis:
                    for key, value in ai_analysis.items():
                        if hasattr(result, key):
                            setattr(result, key, value)
            
            # Fallback analysis
            if 'sentiment' in analysis_types:
                result.sentiment, result.sentiment_score = self._analyze_sentiment(text)
            
            if 'entities' in analysis_types:
                result.entities = self._extract_entities(text)
            
            if 'keywords' in analysis_types:
                result.keywords = self._extract_keywords(text)
            
            if 'topics' in analysis_types:
                result.topics = self._extract_topics(text)
            
            if 'emotions' in analysis_types:
                result.emotions = self._analyze_emotions(text)
            
            # Text quality metrics
            result.complexity_score = self._calculate_complexity(text)
            result.readability_score = self._calculate_readability(text)
            result.text_quality = self._assess_text_quality(text)
            
            # Cache the result
            self.analysis_cache[cache_key] = result.to_dict()
            
            # Update statistics
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, True)
            
            return result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, False)
            logger.error(f"שגיאה בניתוח טקסט: {e}")
            raise
    
    async def _analyze_text_with_ai(self, text: str, analysis_types: List[str]) -> Dict[str, Any]:
        """ניתוח טקסט באמצעות בינה מלאכותית מקומית"""
        try:
            analysis_request = ", ".join(analysis_types)
            
            prompt = f"""נתח את הטקסט הבא ופרק את התוצאות ל-JSON:

טקסט לניתוח:
"{text}"

סוגי ניתוח מבוקשים: {analysis_request}

ספק תוצאות בפורמט JSON הבא:
{{
  "sentiment": "positive/negative/neutral",
  "sentiment_score": 0.5,
  "entities": [
    {{"type": "person/location/organization", "text": "שם הישות", "confidence": 0.8}}
  ],
  "keywords": ["מילת מפתח 1", "מילת מפתח 2"],
  "topics": ["נושא 1", "נושא 2"],
  "emotions": [
    {{"emotion": "שמחה", "intensity": 0.7}}
  ],
  "language": "hebrew/english/mixed",
  "complexity_score": 0.6,
  "readability_score": 0.7,
  "text_quality": "high/medium/low"
}}

התגב רק עם ה-JSON:"""
            
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.3,
                max_tokens=1000,
                request_id=str(uuid.uuid4())
            )
            
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                try:
                    analysis_data = json.loads(result.response.strip())
                    return analysis_data
                except json.JSONDecodeError:
                    logger.warning("Failed to parse AI analysis JSON")
                    return {}
            
            return {}
            
        except Exception as e:
            logger.error(f"AI text analysis error: {e}")
            return {}
    
    async def translate_text(self, text: str, target_language: str, source_language: str = "auto") -> TranslationResult:
        """
        תרגום טקסט
        Text translation using local AI
        """
        if not self.is_active:
            raise RuntimeError("המנוע לא פעיל")
        
        start_time = datetime.now()
        
        try:
            # Detect source language if auto
            detected_source = source_language
            if source_language == "auto":
                detected_source = self._detect_language(text)
            
            result = TranslationResult(
                original_text=text,
                translated_text="",
                source_language=detected_source,
                target_language=target_language
            )
            
            # AI translation if available
            if self.ai_enabled and self.local_ai_client:
                ai_translation = await self._translate_with_ai(text, detected_source, target_language)
                if ai_translation:
                    result.translated_text = ai_translation['translated_text']
                    result.confidence_score = ai_translation.get('confidence_score', 0.8)
                    result.translation_quality = ai_translation.get('quality', 'good')
            
            # Fallback to basic translation if needed
            if not result.translated_text:
                result.translated_text = self._basic_translate(text, detected_source, target_language)
                result.confidence_score = 0.5
                result.translation_quality = "basic"
            
            # Update statistics
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, True)
            
            return result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, False)
            logger.error(f"שגיאה בתרגום טקסט: {e}")
            raise
    
    async def _translate_with_ai(self, text: str, source_lang: str, target_lang: str) -> Dict[str, Any]:
        """תרגום באמצעות בינה מלאכותית מקומית"""
        try:
            language_names = {
                'hebrew': 'עברית',
                'english': 'אנגלית',
                'arabic': 'ערבית',
                'spanish': 'ספרדית',
                'french': 'צרפתית',
                'german': 'גרמנית',
                'russian': 'רוסית'
            }
            
            source_name = language_names.get(source_lang, source_lang)
            target_name = language_names.get(target_lang, target_lang)
            
            prompt = f"""תרגם את הטקסט הבא מ{source_name} ל{target_name}.
ספק תרגום מדויק ותוצאות בפורמט JSON:

טקסט לתרגום:
"{text}"

פורמט תגובה:
{{
  "translated_text": "הטקסט המתורגם",
  "confidence_score": 0.9,
  "quality": "excellent/good/fair/poor"
}}

התגב רק עם ה-JSON:"""
            
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.2,
                max_tokens=800,
                request_id=str(uuid.uuid4())
            )
            
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                try:
                    translation_data = json.loads(result.response.strip())
                    return translation_data
                except json.JSONDecodeError:
                    # Fallback: extract translated text directly
                    return {'translated_text': result.response.strip()}
            
            return {}
            
        except Exception as e:
            logger.error(f"AI translation error: {e}")
            return {}
    
    async def summarize_text(self, text: str, summary_length: str = "medium", summary_type: str = "abstractive") -> SummarizationResult:
        """
        סיכום טקסט
        Text summarization using local AI
        """
        if not self.is_active:
            raise RuntimeError("המנוע לא פעיל")
        
        start_time = datetime.now()
        
        try:
            result = SummarizationResult(
                original_text=text,
                summary="",
                summary_type=summary_type
            )
            
            # AI summarization if available
            if self.ai_enabled and self.local_ai_client:
                ai_summary = await self._summarize_with_ai(text, summary_length, summary_type)
                if ai_summary:
                    result.summary = ai_summary['summary']
                    result.key_points = ai_summary.get('key_points', [])
                    result.compression_ratio = len(result.summary) / len(text)
            
            # Fallback to basic summarization
            if not result.summary:
                result.summary = self._basic_summarize(text, summary_length)
                result.compression_ratio = len(result.summary) / len(text)
                result.summary_type = "extractive"
            
            # Update statistics
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, True)
            
            return result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_statistics(execution_time, False)
            logger.error(f"שגיאה בסיכום טקסט: {e}")
            raise
    
    async def _summarize_with_ai(self, text: str, length: str, summary_type: str) -> Dict[str, Any]:
        """סיכום באמצעות בינה מלאכותית מקומית"""
        try:
            length_instructions = {
                'short': 'בכמה משפטים קצרים',
                'medium': 'בפסקה אחת מקיפה',
                'long': 'בכמה פסקאות מפורטות'
            }
            
            length_instruction = length_instructions.get(length, 'בפסקה אחת')
            
            prompt = f"""סכם את הטקסט הבא {length_instruction} ופרק את התוצאות ל-JSON:

טקסט לסיכום:
"{text}"

סוג סיכום: {summary_type}

ספק תוצאות בפורמט JSON:
{{
  "summary": "הסיכום המלא",
  "key_points": ["נקודה עיקרית 1", "נקודה עיקרית 2", "נקודה עיקרית 3"],
  "main_theme": "הנושא המרכזי"
}}

התגב רק עם ה-JSON:"""
            
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.4,
                max_tokens=1000,
                request_id=str(uuid.uuid4())
            )
            
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                try:
                    summary_data = json.loads(result.response.strip())
                    return summary_data
                except json.JSONDecodeError:
                    # Fallback: use the response as summary
                    return {'summary': result.response.strip()}
            
            return {}
            
        except Exception as e:
            logger.error(f"AI summarization error: {e}")
            return {}
    
    async def chat_with_nlp_ai(self, session_id: str, message: str) -> Dict[str, Any]:
        """
        צ'אט עם בינה מלאכותית על נושאי עיבוד שפה
        Chat with AI about NLP topics
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            # Prepare NLP context
            nlp_context = PromptTemplates.NLP_ASSISTANT
            formatted_message = MessageProcessor.prepare_hebrew_message(message)
            full_prompt = f"{nlp_context}\n\n{formatted_message}"
            
            # Chat with AI
            async with self.local_ai_client as client:
                response = await client.chat(session_id, full_prompt, self.ai_model_name)
            
            # Process response
            cleaned_response = ResponseProcessor.clean_hebrew_response(response)
            
            return {
                'success': True,
                'session_id': session_id,
                'user_message': message,
                'ai_response': cleaned_response,
                'metadata': {
                    'model_used': self.ai_model_name,
                    'response_length': len(cleaned_response),
                    'timestamp': datetime.now().isoformat(),
                    'context': 'nlp_processing'
                }
            }
        
        except Exception as e:
            logger.error(f"NLP AI chat error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בצ\'אט NLP: {str(e)}'
            }
    
    # Helper methods for basic analysis
    
    def _detect_language(self, text: str) -> str:
        """זיהוי שפה בסיסי"""
        hebrew_chars = len(re.findall(self.hebrew_patterns['hebrew_chars'], text))
        total_chars = len(re.findall(r'[a-zA-Z\u0590-\u05FF]', text))
        
        if total_chars == 0:
            return "unknown"
        
        hebrew_ratio = hebrew_chars / total_chars
        
        if hebrew_ratio > 0.7:
            return "hebrew"
        elif hebrew_ratio > 0.3:
            return "mixed"
        else:
            return "english"
    
    def _analyze_sentiment(self, text: str) -> Tuple[str, float]:
        """ניתוח סנטימנט בסיסי"""
        positive_words = self.hebrew_patterns['emotion_words']['positive']
        negative_words = self.hebrew_patterns['emotion_words']['negative']
        
        positive_count = sum(1 for word in positive_words if word in text)
        negative_count = sum(1 for word in negative_words if word in text)
        
        if positive_count > negative_count:
            score = min(1.0, positive_count / (positive_count + negative_count + 1))
            return "positive", score
        elif negative_count > positive_count:
            score = -min(1.0, negative_count / (positive_count + negative_count + 1))
            return "negative", score
        else:
            return "neutral", 0.0
    
    def _extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """חילוץ ישויות בסיסי"""
        entities = []
        
        # Simple pattern matching for Hebrew names and locations
        hebrew_word_pattern = self.hebrew_patterns['hebrew_word']
        words = re.findall(hebrew_word_pattern, text)
        
        # Basic entity detection (would be more sophisticated in real implementation)
        for word in words:
            if len(word) > 2 and word[0].isupper():  # Simple capitalization check
                entities.append({
                    'type': 'unknown',
                    'text': word,
                    'confidence': 0.5
                })
        
        return entities[:10]  # Limit to top 10
    
    def _extract_keywords(self, text: str) -> List[str]:
        """חילוץ מילות מפתח בסיסי"""
        # Remove stopwords and extract significant words
        words = re.findall(self.hebrew_patterns['hebrew_word'], text)
        stopwords = self.hebrew_patterns['common_stopwords']
        
        keywords = [word for word in words if word not in stopwords and len(word) > 2]
        
        # Count frequencies
        word_freq = {}
        for word in keywords:
            word_freq[word] = word_freq.get(word, 0) + 1
        
        # Return top keywords
        sorted_keywords = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [word for word, freq in sorted_keywords[:10]]
    
    def _extract_topics(self, text: str) -> List[str]:
        """חילוץ נושאים בסיסי"""
        # Basic topic extraction based on keyword clustering
        keywords = self._extract_keywords(text)
        
        # Simple topic categories (would be more sophisticated in real implementation)
        topic_keywords = {
            'טכנולוגיה': ['מחשב', 'תוכנה', 'אינטרנט', 'AI', 'בינה מלאכותית'],
            'חינוך': ['למידה', 'חינוך', 'סטודנט', 'מורה', 'בית ספר'],
            'בריאות': ['רפואה', 'בריאות', 'רופא', 'בית חולים', 'טיפול'],
            'עסקים': ['עסק', 'כסף', 'רווח', 'שוק', 'חברה']
        }
        
        detected_topics = []
        for topic, topic_words in topic_keywords.items():
            if any(keyword in topic_words for keyword in keywords):
                detected_topics.append(topic)
        
        return detected_topics
    
    def _analyze_emotions(self, text: str) -> List[Dict[str, float]]:
        """ניתוח רגשות בסיסי"""
        emotion_words = self.hebrew_patterns['emotion_words']
        emotions = []
        
        for emotion_type, words in emotion_words.items():
            intensity = sum(1 for word in words if word in text) / len(words)
            if intensity > 0:
                emotions.append({
                    'emotion': emotion_type,
                    'intensity': min(1.0, intensity)
                })
        
        return emotions
    
    def _calculate_complexity(self, text: str) -> float:
        """חישוב מורכבות טקסט"""
        sentences = text.split('.')
        words = text.split()
        
        if not sentences or not words:
            return 0.0
        
        avg_words_per_sentence = len(words) / len(sentences)
        avg_chars_per_word = sum(len(word) for word in words) / len(words)
        
        # Simple complexity score
        complexity = (avg_words_per_sentence / 20) + (avg_chars_per_word / 10)
        return min(1.0, complexity)
    
    def _calculate_readability(self, text: str) -> float:
        """חישוב קריאות טקסט"""
        # Simplified readability score for Hebrew
        words = text.split()
        sentences = text.split('.')
        
        if not sentences or not words:
            return 0.0
        
        avg_sentence_length = len(words) / len(sentences)
        
        # Lower average sentence length = higher readability
        readability = max(0.0, 1.0 - (avg_sentence_length / 30))
        return readability
    
    def _assess_text_quality(self, text: str) -> str:
        """הערכת איכות טקסט"""
        complexity = self._calculate_complexity(text)
        readability = self._calculate_readability(text)
        
        quality_score = (readability + (1 - complexity)) / 2
        
        if quality_score > 0.7:
            return "high"
        elif quality_score > 0.4:
            return "medium"
        else:
            return "low"
    
    def _basic_translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """תרגום בסיסי (placeholder)"""
        # Basic translation fallback
        translation_map = {
            ('hebrew', 'english'): {
                'שלום': 'hello',
                'טוב': 'good',
                'רע': 'bad',
                'כן': 'yes',
                'לא': 'no'
            },
            ('english', 'hebrew'): {
                'hello': 'שלום',
                'good': 'טוב',
                'bad': 'רע',
                'yes': 'כן',
                'no': 'לא'
            }
        }
        
        trans_map = translation_map.get((source_lang, target_lang), {})
        translated_text = text
        
        for source_word, target_word in trans_map.items():
            translated_text = translated_text.replace(source_word, target_word)
        
        return translated_text
    
    def _basic_summarize(self, text: str, length: str) -> str:
        """סיכום בסיסי"""
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        
        if not sentences:
            return text
        
        length_ratios = {
            'short': 0.2,
            'medium': 0.4,
            'long': 0.6
        }
        
        ratio = length_ratios.get(length, 0.4)
        num_sentences = max(1, int(len(sentences) * ratio))
        
        # Return first N sentences as basic summary
        return '. '.join(sentences[:num_sentences]) + '.'
    
    def _get_cache_key(self, text: str, analysis_types: List[str]) -> str:
        """יצירת מפתח קאש"""
        import hashlib
        key_data = f"{text}:{':'.join(sorted(analysis_types))}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def _update_statistics(self, execution_time: float, success: bool):
        """עדכון סטטיסטיקות"""
        self.statistics.total_operations += 1
        
        if success:
            self.statistics.successful_operations += 1
        else:
            self.statistics.failed_operations += 1
        
        # Update average execution time
        total_ops = self.statistics.total_operations
        current_avg = self.statistics.average_execution_time
        self.statistics.average_execution_time = (
            (current_avg * (total_ops - 1) + execution_time) / total_ops
        )
    
    def execute_operation(self, operation: str, **kwargs) -> NlpAdvancedResult:
        """ביצוע פעולה"""
        if not self.is_active:
            return NlpAdvancedResult(
                success=False,
                error_message="המנוע לא פעיל"
            )
        
        start_time = datetime.now()
        
        try:
            # Execute operation logic here
            result_data = self._execute_specific_operation(operation, **kwargs)
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Update statistics
            self.statistics.total_operations += 1
            self.statistics.successful_operations += 1
            self.statistics.last_operation = operation
            
            # Update average execution time
            total_ops = self.statistics.total_operations
            avg_time = self.statistics.average_execution_time
            self.statistics.average_execution_time = (
                (avg_time * (total_ops - 1) + execution_time) / total_ops
            )
            
            return NlpAdvancedResult(
                success=True,
                data=result_data,
                execution_time=execution_time
            )
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Update statistics
            self.statistics.total_operations += 1
            self.statistics.failed_operations += 1
            
            logger.error(f"שגיאה בביצוע פעולה {operation}: {e}")
            
            return NlpAdvancedResult(
                success=False,
                error_message=str(e),
                execution_time=execution_time
            )
    
    def _execute_specific_operation(self, operation: str, **kwargs) -> Any:
        """ביצוע פעולה ספציפית"""
        operations = {
            "analyze_text": self._sync_analyze_text,
            "translate_text": self._sync_translate_text,
            "summarize_text": self._sync_summarize_text,
            "example_operation": self._example_operation,
            # Add more operations here
        }
        
        if operation in operations:
            return operations[operation](**kwargs)
        else:
            raise ValueError(f"פעולה לא מוכרת: {operation}")
    
    def _sync_analyze_text(self, **kwargs) -> Dict[str, Any]:
        """Synchronous wrapper for analyze_text"""
        import asyncio
        text = kwargs.get('text', '')
        analysis_types = kwargs.get('analysis_types', None)
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.analyze_text(text, analysis_types))
            return result.to_dict()
        finally:
            loop.close()
    
    def _sync_translate_text(self, **kwargs) -> Dict[str, Any]:
        """Synchronous wrapper for translate_text"""
        import asyncio
        text = kwargs.get('text', '')
        target_language = kwargs.get('target_language', 'english')
        source_language = kwargs.get('source_language', 'auto')
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.translate_text(text, target_language, source_language))
            return result.to_dict()
        finally:
            loop.close()
    
    def _sync_summarize_text(self, **kwargs) -> Dict[str, Any]:
        """Synchronous wrapper for summarize_text"""
        import asyncio
        text = kwargs.get('text', '')
        summary_length = kwargs.get('summary_length', 'medium')
        summary_type = kwargs.get('summary_type', 'abstractive')
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.summarize_text(text, summary_length, summary_type))
            return result.to_dict()
        finally:
            loop.close()
    
    def _example_operation(self, **kwargs) -> str:
        """פעולה לדוגמה"""
        return f"פעולה לדוגמה בוצעה עם פרמטרים: {kwargs}"