#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
אינטגרציית ענן - Examples
"""
