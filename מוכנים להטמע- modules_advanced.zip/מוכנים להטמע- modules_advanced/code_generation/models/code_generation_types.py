#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
יצירת קוד Types - סוגי נתונים עבור יצירת קוד
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum


@dataclass
class CodeGenerationConfig:
    """תצורת יצירת קוד"""
    enabled: bool = True
    max_concurrent_operations: int = 10
    timeout_seconds: int = 30
    logging_level: str = "INFO"
    custom_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CodeGenerationResult:
    """תוצאת פעולה של יצירת קוד"""
    success: bool
    data: Any = None
    error_message: str = ""
    execution_time: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class CodeGenerationStatistics:
    """סטטיסטיקות יצירת קוד"""
    total_operations: int = 0
    successful_operations: int = 0
    failed_operations: int = 0
    average_execution_time: float = 0.0
    uptime_seconds: int = 0
    last_operation: Optional[str] = None
