"""
Development Automation Models Package
חבילת מודלי אוטומציית פיתוח

Advanced development automation with AI-powered coding assistance.
אוטומציית פיתוח מתקדמת עם סיוע תכנות מונע בינה מלאכותית.
"""

from .code_types import (
    CodeSnippet, CodeCompletion, RefactoringPlan,
    BugReport, CodeQuality, TestCase, APISpec,
    CodeReview, DocumentationGen, CodePattern
)

from .project_types import (
    ProjectStructure, DependencyGraph, BuildConfig,
    DeploymentPlan, Pipeline, Environment,
    Repository, Branch, CommitAnalysis, PRReview
)

from .automation_types import (
    AutomationTask, CICDPipeline, TestSuite,
    QualityGate, SecurityScan, PerformanceTest,
    CodeGeneration, SmartRefactoring, BugFix
)

__all__ = [
    # Code types
    'CodeSnippet', 'CodeCompletion', 'RefactoringPlan',
    'BugReport', 'CodeQuality', 'TestCase', 'APISpec',
    'CodeReview', 'DocumentationGen', 'CodePattern',
    
    # Project types
    'ProjectStructure', 'DependencyGraph', 'BuildConfig',
    'DeploymentPlan', 'Pipeline', 'Environment',
    'Repository', 'Branch', 'CommitAnalysis', 'PRReview',
    
    # Automation types
    'AutomationTask', 'CICDPipeline', 'TestSuite',
    'QualityGate', 'SecurityScan', 'PerformanceTest',
    'CodeGeneration', 'SmartRefactoring', 'BugFix'
]