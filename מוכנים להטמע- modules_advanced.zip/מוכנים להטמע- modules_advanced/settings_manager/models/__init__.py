#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מנהל הגדרות - Models
"""
