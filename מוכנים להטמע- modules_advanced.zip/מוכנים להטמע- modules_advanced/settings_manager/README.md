# מנהל הגדרות Module

ניהול תצורת מערכת והגדרות

## תכונות

- config_management
- user_preferences
- system_settings
- backup_restore

## התקנה

```bash
pip install -r requirements.txt
```

## שימוש

```python
from settings_manager import module_instance

# הפעלת המודול
module_instance.start()

# ביצוע פעולה
result = module_instance.execute_operation("operation_name", param="value")

# עצירת המודול
module_instance.stop()
```

## תיעוד

מידע מפורט זמין בתיקיית `docs/`

## בדיקות

```bash
pytest tests/
```

## רישיון

MIT License
