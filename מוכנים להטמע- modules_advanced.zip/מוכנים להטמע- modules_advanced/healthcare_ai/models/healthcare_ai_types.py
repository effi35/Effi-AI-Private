#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
בינה מלאכותית רפואית Types - סוגי נתונים עבור בינה מלאכותית רפואית
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum


@dataclass
class HealthcareAiConfig:
    """תצורת בינה מלאכותית רפואית"""
    enabled: bool = True
    max_concurrent_operations: int = 10
    timeout_seconds: int = 30
    logging_level: str = "INFO"
    custom_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HealthcareAiResult:
    """תוצאת פעולה של בינה מלאכותית רפואית"""
    success: bool
    data: Any = None
    error_message: str = ""
    execution_time: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class HealthcareAiStatistics:
    """סטטיסטיקות בינה מלאכותית רפואית"""
    total_operations: int = 0
    successful_operations: int = 0
    failed_operations: int = 0
    average_execution_time: float = 0.0
    uptime_seconds: int = 0
    last_operation: Optional[str] = None
