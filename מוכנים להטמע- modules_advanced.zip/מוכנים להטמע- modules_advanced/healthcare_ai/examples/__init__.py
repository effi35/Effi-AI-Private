#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
בינה מלאכותית רפואית - Examples
"""
