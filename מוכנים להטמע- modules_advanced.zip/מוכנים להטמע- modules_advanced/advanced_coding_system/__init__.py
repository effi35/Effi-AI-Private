"""
Advanced Coding System Module Package
חבילת מודול מערכת קידוד מתקדמת

The ultimate programming and development system with local AI integration.
מערכת התכנות והפיתוח הסופית עם אינטגרציית בינה מלאכותית מקומית.
"""

from .module import (
    AdvancedCodingSystemModule,
    create_module,
    MODULE_INFO
)

from .core.advanced_coding_engine import (
    AdvancedCodingEngine,
    CodeExecutionRequest,
    CodeExecutionResult,
    ApplicationGenerationRequest,
    ApplicationStructure,
    CodeExecutionMode,
    ApplicationType
)

from .models.programming_languages import (
    ProgrammingLanguage,
    LanguageType,
    LanguageCategory,
    create_python_language,
    create_javascript_language,
    create_java_language,
    create_cpp_language
)

__version__ = "2.0.0"
__author__ = "Effi AI System"
__description__ = "Advanced Coding System with Local AI Integration"
__description_hebrew__ = "מערכת קידוד מתקדמת עם אינטגרציית בינה מלאכותית מקומית"

__all__ = [
    # Main module
    'AdvancedCodingSystemModule',
    'create_module',
    'MODULE_INFO',
    
    # Core engine
    'AdvancedCodingEngine',
    'CodeExecutionRequest',
    'CodeExecutionResult',
    'ApplicationGenerationRequest',
    'ApplicationStructure',
    'CodeExecutionMode',
    'ApplicationType',
    
    # Programming languages
    'ProgrammingLanguage',
    'LanguageType', 
    'LanguageCategory',
    'create_python_language',
    'create_javascript_language',
    'create_java_language',
    'create_cpp_language',
    
    # Module metadata
    '__version__',
    '__author__',
    '__description__',
    '__description_hebrew__'
]

# Quick start function
def quick_start():
    """
    Quick start guide for the Advanced Coding System
    מדריך התחלה מהירה למערכת הקידוד המתקדמת
    """
    print("🚀 Advanced Coding System v2.0.0")
    print("מערכת קידוד מתקדמת עם בינה מלאכותית מקומית")
    print("=" * 50)
    print("\nQuick Start Example / דוגמה להתחלה:")
    print("""
from advanced_coding_system import create_module
import asyncio

async def main():
    # Create module
    coding_system = create_module()
    
    # Generate code with AI
    result = await coding_system.generate_code(
        language="python",
        task="Create a simple calculator function"
    )
    
    print(result['generated_code'])

# Run
asyncio.run(main())
""")
    print("\nFor more examples, see README.md")
    print("לדוגמאות נוספות, ראה README.md")

# Module capabilities summary
CAPABILITIES = {
    'code_execution': {
        'description': 'Execute code securely in multiple languages',
        'description_hebrew': 'הרצת קוד בטוחה במספר שפות תכנות',
        'supported_languages': ['python', 'javascript', 'java', 'cpp', 'go', 'rust', 'typescript']
    },
    'ai_integration': {
        'description': 'Local AI powered by Hudson/Llama3.1',
        'description_hebrew': 'בינה מלאכותית מקומית מונעת על ידי Hudson/Llama3.1',
        'features': ['code_generation', 'code_analysis', 'code_fixing', 'code_optimization', 'programming_chat']
    },
    'application_generation': {
        'description': 'Generate complete application structures',
        'description_hebrew': 'יצירת מבני אפליקציה מלאים',
        'types': ['web_app', 'mobile_app', 'desktop_app', 'api', 'library']
    },
    'security': {
        'description': 'Advanced security and sandboxing',
        'description_hebrew': 'אבטחה מתקדמת ובידוד',
        'features': ['sandboxed_execution', 'resource_limits', 'security_scanning']
    }
}

def get_capabilities():
    """Get module capabilities information"""
    return CAPABILITIES