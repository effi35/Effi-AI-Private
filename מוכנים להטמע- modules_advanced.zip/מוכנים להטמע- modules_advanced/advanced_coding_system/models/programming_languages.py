"""
Programming Languages Models
מודלים של שפות תכנות

Complete programming languages support and management.
תמיכה וניהול מלא של שפות תכנות.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Set, Union
from datetime import datetime
from enum import Enum
import json

class LanguageType(Enum):
    """Programming language types"""
    COMPILED = "compiled"           # מקומפל
    INTERPRETED = "interpreted"     # מפורש
    HYBRID = "hybrid"              # היברידי
    SCRIPTING = "scripting"        # סקריפטינג
    MARKUP = "markup"              # סימון
    QUERY = "query"                # שאילתות
    ASSEMBLY = "assembly"          # אסמבלי
    FUNCTIONAL = "functional"      # פונקציונלי
    LOGIC = "logic"               # לוגי

class LanguageCategory(Enum):
    """Programming language categories"""
    SYSTEM = "system"              # מערכת
    WEB = "web"                   # אינטרנט
    MOBILE = "mobile"             # נייד
    DESKTOP = "desktop"           # שולחן עבודה
    DATABASE = "database"         # מסד נתונים
    SCIENTIFIC = "scientific"     # מדעי
    GAME = "game"                 # משחקים
    AI_ML = "ai_ml"              # בינה מלאכותית
    BLOCKCHAIN = "blockchain"     # בלוקצ'יין
    EMBEDDED = "embedded"         # מוטמע
    DEVOPS = "devops"            # DevOps
    SECURITY = "security"         # אבטחה

class CompilerType(Enum):
    """Compiler types"""
    GCC = "gcc"                   # GNU Compiler Collection
    CLANG = "clang"              # Clang/LLVM
    MSVC = "msvc"                # Microsoft Visual C++
    JAVAC = "javac"              # Java Compiler
    KOTLINC = "kotlinc"          # Kotlin Compiler
    RUSTC = "rustc"              # Rust Compiler
    GO = "go"                    # Go Compiler
    DOTNET = "dotnet"            # .NET Compiler
    TSC = "tsc"                  # TypeScript Compiler
    BABEL = "babel"              # Babel Transpiler

class RuntimeEnvironment(Enum):
    """Runtime environments"""
    JVM = "jvm"                  # Java Virtual Machine
    CLR = "clr"                  # Common Language Runtime
    NODE = "node"                # Node.js
    PYTHON = "python"            # Python Runtime
    RUBY = "ruby"                # Ruby Runtime
    PHP = "php"                  # PHP Runtime
    BROWSER = "browser"          # Browser Runtime
    NATIVE = "native"            # Native Runtime
    WASM = "wasm"               # WebAssembly
    DOCKER = "docker"           # Docker Container

@dataclass
class LanguageFeature:
    """
    Programming language feature
    תכונת שפת תכנות
    """
    feature_name: str
    feature_type: str  # syntax, paradigm, tool, library
    description: str
    description_hebrew: str
    supported_versions: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    benefits: List[str] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'feature_name': self.feature_name,
            'feature_type': self.feature_type,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'supported_versions': self.supported_versions,
            'examples': self.examples,
            'benefits': self.benefits,
            'limitations': self.limitations
        }

@dataclass
class SyntaxRule:
    """
    Programming language syntax rule
    כלל חוק תחביר של שפת תכנות
    """
    rule_name: str
    pattern: str               # Regex pattern
    description: str
    description_hebrew: str
    examples: List[str] = field(default_factory=list)
    counter_examples: List[str] = field(default_factory=list)
    severity: str = "error"    # error, warning, info
    
    def validate(self, code: str) -> bool:
        """Validate code against this syntax rule"""
        import re
        return bool(re.search(self.pattern, code))
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'rule_name': self.rule_name,
            'pattern': self.pattern,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'examples': self.examples,
            'counter_examples': self.counter_examples,
            'severity': self.severity
        }

@dataclass
class CodePattern:
    """
    Code design pattern
    דפוס עיצוב קוד
    """
    pattern_name: str
    pattern_type: str          # creational, structural, behavioral
    description: str
    description_hebrew: str
    use_cases: List[str] = field(default_factory=list)
    implementation: str = ""   # Code template
    advantages: List[str] = field(default_factory=list)
    disadvantages: List[str] = field(default_factory=list)
    related_patterns: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'pattern_name': self.pattern_name,
            'pattern_type': self.pattern_type,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'use_cases': self.use_cases,
            'implementation': self.implementation,
            'advantages': self.advantages,
            'disadvantages': self.disadvantages,
            'related_patterns': self.related_patterns
        }

@dataclass
class LanguageConfig:
    """
    Programming language configuration
    תצורת שפת תכנות
    """
    language_name: str
    file_extensions: List[str] = field(default_factory=list)
    compiler_flags: List[str] = field(default_factory=list)
    runtime_options: List[str] = field(default_factory=list)
    environment_variables: Dict[str, str] = field(default_factory=dict)
    build_commands: List[str] = field(default_factory=list)
    test_commands: List[str] = field(default_factory=list)
    package_manager: str = ""
    dependency_file: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'language_name': self.language_name,
            'file_extensions': self.file_extensions,
            'compiler_flags': self.compiler_flags,
            'runtime_options': self.runtime_options,
            'environment_variables': self.environment_variables,
            'build_commands': self.build_commands,
            'test_commands': self.test_commands,
            'package_manager': self.package_manager,
            'dependency_file': self.dependency_file
        }

@dataclass
class ProgrammingLanguage:
    """
    Complete programming language definition
    הגדרת שפת תכנות מלאה
    """
    name: str
    name_hebrew: str
    version: str
    language_type: LanguageType
    categories: List[LanguageCategory] = field(default_factory=list)
    
    # Technical details
    compiler_type: Optional[CompilerType] = None
    runtime_environment: Optional[RuntimeEnvironment] = None
    first_appeared: int = 0
    stable_release: str = ""
    
    # Language characteristics
    paradigms: List[str] = field(default_factory=list)  # OOP, functional, procedural, etc.
    typing: str = ""                    # static, dynamic, strong, weak
    memory_management: str = ""         # manual, garbage_collected, reference_counted
    platform_support: List[str] = field(default_factory=list)
    
    # Syntax and features
    syntax_rules: List[SyntaxRule] = field(default_factory=list)
    language_features: List[LanguageFeature] = field(default_factory=list)
    code_patterns: List[CodePattern] = field(default_factory=list)
    
    # Configuration
    config: LanguageConfig = field(default_factory=lambda: LanguageConfig(""))
    
    # Ecosystem
    standard_library: List[str] = field(default_factory=list)
    popular_frameworks: List[str] = field(default_factory=list)
    package_repositories: List[str] = field(default_factory=list)
    ide_support: List[str] = field(default_factory=list)
    
    # Learning and documentation
    difficulty_level: str = "intermediate"  # beginner, intermediate, advanced, expert
    learning_resources: List[str] = field(default_factory=list)
    documentation_url: str = ""
    community_size: str = "medium"      # small, medium, large, huge
    
    # Performance and metrics
    performance_rating: int = 5         # 1-10 scale
    memory_efficiency: int = 5          # 1-10 scale
    development_speed: int = 5          # 1-10 scale
    execution_speed: int = 5            # 1-10 scale
    
    # Usage statistics
    popularity_rank: int = 0
    job_market_demand: str = "medium"   # low, medium, high, very_high
    salary_range: str = ""
    
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def add_syntax_rule(self, rule: SyntaxRule):
        """Add syntax rule to language"""
        self.syntax_rules.append(rule)
        self.updated_at = datetime.now()
    
    def add_feature(self, feature: LanguageFeature):
        """Add feature to language"""
        self.language_features.append(feature)
        self.updated_at = datetime.now()
    
    def add_pattern(self, pattern: CodePattern):
        """Add code pattern to language"""
        self.code_patterns.append(pattern)
        self.updated_at = datetime.now()
    
    def validate_syntax(self, code: str) -> List[Dict[str, Any]]:
        """Validate code syntax against language rules"""
        violations = []
        
        for rule in self.syntax_rules:
            if not rule.validate(code):
                violations.append({
                    'rule': rule.rule_name,
                    'severity': rule.severity,
                    'description': rule.description,
                    'description_hebrew': rule.description_hebrew
                })
        
        return violations
    
    def get_applicable_patterns(self, code_context: str) -> List[CodePattern]:
        """Get applicable design patterns for given context"""
        applicable = []
        
        for pattern in self.code_patterns:
            # Simple keyword matching - in real implementation, use more sophisticated analysis
            if any(use_case.lower() in code_context.lower() for use_case in pattern.use_cases):
                applicable.append(pattern)
        
        return applicable
    
    def get_performance_score(self) -> float:
        """Calculate overall performance score"""
        weights = {
            'performance_rating': 0.3,
            'memory_efficiency': 0.2,
            'execution_speed': 0.3,
            'development_speed': 0.2
        }
        
        score = (
            weights['performance_rating'] * self.performance_rating +
            weights['memory_efficiency'] * self.memory_efficiency +
            weights['execution_speed'] * self.execution_speed +
            weights['development_speed'] * self.development_speed
        )
        
        return score
    
    def is_suitable_for_category(self, category: LanguageCategory) -> bool:
        """Check if language is suitable for given category"""
        return category in self.categories
    
    def get_learning_path(self) -> List[str]:
        """Get recommended learning path for this language"""
        base_path = [
            f"הכרת יסודות {self.name}",
            f"חוק תחביר {self.name}",
            f"מבני נתונים ב{self.name}",
            f"תכנות מונחה עצמים ב{self.name}",
            f"טיפול בשגיאות ב{self.name}",
            f"בדיקות ב{self.name}",
            f"ביצועים ואופטימיזציה ב{self.name}"
        ]
        
        # Add category-specific topics
        if LanguageCategory.WEB in self.categories:
            base_path.extend([
                f"פיתוח web ב{self.name}",
                f"מסדי נתונים ב{self.name}",
                f"API development ב{self.name}"
            ])
        
        if LanguageCategory.AI_ML in self.categories:
            base_path.extend([
                f"machine learning ב{self.name}",
                f"data science ב{self.name}",
                f"neural networks ב{self.name}"
            ])
        
        return base_path
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to comprehensive dictionary"""
        return {
            'name': self.name,
            'name_hebrew': self.name_hebrew,
            'version': self.version,
            'language_type': self.language_type.value,
            'categories': [cat.value for cat in self.categories],
            'compiler_type': self.compiler_type.value if self.compiler_type else None,
            'runtime_environment': self.runtime_environment.value if self.runtime_environment else None,
            'first_appeared': self.first_appeared,
            'stable_release': self.stable_release,
            'paradigms': self.paradigms,
            'typing': self.typing,
            'memory_management': self.memory_management,
            'platform_support': self.platform_support,
            'syntax_rules': [rule.to_dict() for rule in self.syntax_rules],
            'language_features': [feature.to_dict() for feature in self.language_features],
            'code_patterns': [pattern.to_dict() for pattern in self.code_patterns],
            'config': self.config.to_dict(),
            'standard_library': self.standard_library,
            'popular_frameworks': self.popular_frameworks,
            'package_repositories': self.package_repositories,
            'ide_support': self.ide_support,
            'difficulty_level': self.difficulty_level,
            'learning_resources': self.learning_resources,
            'documentation_url': self.documentation_url,
            'community_size': self.community_size,
            'performance_rating': self.performance_rating,
            'memory_efficiency': self.memory_efficiency,
            'development_speed': self.development_speed,
            'execution_speed': self.execution_speed,
            'performance_score': self.get_performance_score(),
            'popularity_rank': self.popularity_rank,
            'job_market_demand': self.job_market_demand,
            'salary_range': self.salary_range,
            'learning_path': self.get_learning_path(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

# Factory functions for creating language instances
def create_python_language() -> ProgrammingLanguage:
    """Create Python language definition"""
    python = ProgrammingLanguage(
        name="Python",
        name_hebrew="פייתון",
        version="3.11",
        language_type=LanguageType.INTERPRETED,
        categories=[LanguageCategory.AI_ML, LanguageCategory.WEB, LanguageCategory.SCIENTIFIC, LanguageCategory.DESKTOP],
        runtime_environment=RuntimeEnvironment.PYTHON,
        first_appeared=1991,
        stable_release="3.11.5",
        paradigms=["object-oriented", "procedural", "functional", "imperative"],
        typing="dynamic, strong",
        memory_management="garbage_collected",
        platform_support=["Windows", "macOS", "Linux", "Unix"],
        standard_library=["os", "sys", "json", "datetime", "collections", "itertools"],
        popular_frameworks=["Django", "Flask", "FastAPI", "Pandas", "NumPy", "TensorFlow", "PyTorch"],
        package_repositories=["PyPI"],
        ide_support=["PyCharm", "VS Code", "Jupyter", "Spyder"],
        difficulty_level="beginner",
        performance_rating=7,
        memory_efficiency=6,
        development_speed=9,
        execution_speed=6,
        popularity_rank=1,
        job_market_demand="very_high",
        community_size="huge"
    )
    
    python.config = LanguageConfig(
        language_name="Python",
        file_extensions=[".py", ".pyw", ".pyi"],
        runtime_options=["-O", "-OO", "-B", "-v"],
        environment_variables={"PYTHONPATH": "", "PYTHONHOME": ""},
        build_commands=["python -m py_compile"],
        test_commands=["python -m pytest", "python -m unittest"],
        package_manager="pip",
        dependency_file="requirements.txt"
    )
    
    return python

def create_javascript_language() -> ProgrammingLanguage:
    """Create JavaScript language definition"""
    javascript = ProgrammingLanguage(
        name="JavaScript",
        name_hebrew="ג'אווה סקריפט",
        version="ES2023",
        language_type=LanguageType.INTERPRETED,
        categories=[LanguageCategory.WEB, LanguageCategory.MOBILE, LanguageCategory.DESKTOP],
        runtime_environment=RuntimeEnvironment.NODE,
        first_appeared=1995,
        stable_release="ES2023",
        paradigms=["event-driven", "functional", "imperative", "object-oriented"],
        typing="dynamic, weak",
        memory_management="garbage_collected",
        platform_support=["Web Browsers", "Node.js", "Deno", "Bun"],
        standard_library=["Array", "Object", "Promise", "Date", "Math", "JSON"],
        popular_frameworks=["React", "Vue.js", "Angular", "Express.js", "Next.js", "Svelte"],
        package_repositories=["npm", "yarn"],
        ide_support=["VS Code", "WebStorm", "Atom", "Sublime Text"],
        difficulty_level="beginner",
        performance_rating=7,
        memory_efficiency=6,
        development_speed=8,
        execution_speed=7,
        popularity_rank=2,
        job_market_demand="very_high",
        community_size="huge"
    )
    
    javascript.config = LanguageConfig(
        language_name="JavaScript",
        file_extensions=[".js", ".mjs", ".jsx"],
        runtime_options=["--experimental-modules", "--inspect", "--trace-warnings"],
        environment_variables={"NODE_ENV": "development", "NODE_PATH": ""},
        build_commands=["npm run build", "webpack"],
        test_commands=["npm test", "jest", "mocha"],
        package_manager="npm",
        dependency_file="package.json"
    )
    
    return javascript

def create_java_language() -> ProgrammingLanguage:
    """Create Java language definition"""
    java = ProgrammingLanguage(
        name="Java",
        name_hebrew="ג'אווה",
        version="21",
        language_type=LanguageType.COMPILED,
        categories=[LanguageCategory.SYSTEM, LanguageCategory.WEB, LanguageCategory.MOBILE, LanguageCategory.DESKTOP],
        compiler_type=CompilerType.JAVAC,
        runtime_environment=RuntimeEnvironment.JVM,
        first_appeared=1995,
        stable_release="Java 21",
        paradigms=["object-oriented", "imperative", "generic"],
        typing="static, strong",
        memory_management="garbage_collected",
        platform_support=["Windows", "macOS", "Linux", "Solaris"],
        standard_library=["java.util", "java.io", "java.lang", "java.net", "java.time"],
        popular_frameworks=["Spring", "Hibernate", "Apache Struts", "JSF", "Maven", "Gradle"],
        package_repositories=["Maven Central", "JCenter"],
        ide_support=["IntelliJ IDEA", "Eclipse", "NetBeans", "VS Code"],
        difficulty_level="intermediate",
        performance_rating=8,
        memory_efficiency=7,
        development_speed=6,
        execution_speed=8,
        popularity_rank=3,
        job_market_demand="high",
        community_size="huge"
    )
    
    java.config = LanguageConfig(
        language_name="Java",
        file_extensions=[".java", ".class", ".jar"],
        compiler_flags=["-cp", "-d", "-g", "-O"],
        runtime_options=["-Xmx", "-Xms", "-XX:+UseG1GC"],
        environment_variables={"JAVA_HOME": "", "CLASSPATH": ""},
        build_commands=["javac", "maven compile", "gradle build"],
        test_commands=["junit", "maven test", "gradle test"],
        package_manager="maven",
        dependency_file="pom.xml"
    )
    
    return java

def create_cpp_language() -> ProgrammingLanguage:
    """Create C++ language definition"""
    cpp = ProgrammingLanguage(
        name="C++",
        name_hebrew="סי פלוס פלוס",
        version="C++23",
        language_type=LanguageType.COMPILED,
        categories=[LanguageCategory.SYSTEM, LanguageCategory.GAME, LanguageCategory.EMBEDDED, LanguageCategory.DESKTOP],
        compiler_type=CompilerType.GCC,
        runtime_environment=RuntimeEnvironment.NATIVE,
        first_appeared=1985,
        stable_release="C++23",
        paradigms=["object-oriented", "procedural", "generic", "functional"],
        typing="static, strong",
        memory_management="manual",
        platform_support=["Windows", "macOS", "Linux", "Unix", "Embedded"],
        standard_library=["iostream", "vector", "string", "algorithm", "memory"],
        popular_frameworks=["Qt", "Boost", "STL", "OpenCV", "Unreal Engine"],
        package_repositories=["vcpkg", "Conan"],
        ide_support=["Visual Studio", "CLion", "Code::Blocks", "Dev-C++"],
        difficulty_level="advanced",
        performance_rating=10,
        memory_efficiency=9,
        development_speed=4,
        execution_speed=10,
        popularity_rank=4,
        job_market_demand="high",
        community_size="large"
    )
    
    cpp.config = LanguageConfig(
        language_name="C++",
        file_extensions=[".cpp", ".cxx", ".cc", ".h", ".hpp"],
        compiler_flags=["-std=c++23", "-O2", "-g", "-Wall", "-Wextra"],
        runtime_options=[],
        environment_variables={"CXX": "g++", "CXXFLAGS": ""},
        build_commands=["g++", "make", "cmake", "ninja"],
        test_commands=["gtest", "catch2", "cppunit"],
        package_manager="vcpkg",
        dependency_file="CMakeLists.txt"
    )
    
    return cpp

# Additional language factory functions can be added for:
# - C#, Rust, Go, TypeScript, Swift, Kotlin, PHP, Ruby, etc.