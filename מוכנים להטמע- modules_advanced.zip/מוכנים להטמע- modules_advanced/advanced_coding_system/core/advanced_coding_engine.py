"""
Advanced Coding Engine
מנוע קידוד מתקדם

The most comprehensive programming and development engine ever created.
המנוע הכי מקיף לתכנות ופיתוח שנוצר אי פעם.
"""

import asyncio
import logging
import subprocess
import tempfile
import os
import sys
import json
import time
import ast
import re
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from pathlib import Path
import hashlib
import uuid
from enum import Enum

# Import our models
from ..models.programming_languages import (
    ProgrammingLanguage, LanguageType, LanguageCategory,
    create_python_language, create_javascript_language,
    create_java_language, create_cpp_language
)

# Import local AI integration
from ...local_ai_integration.core.ollama_client import OllamaClient
from ...local_ai_integration.models.ollama_integration import InferenceRequest, InferenceMode
from ...local_ai_integration.utils.local_ai_utils import (
    MessageProcessor, PromptTemplates, ResponseProcessor, LocalAIConfig
)

logger = logging.getLogger(__name__)

class CodeExecutionMode(Enum):
    """Code execution modes"""
    SAFE = "safe"               # בטוח
    SANDBOXED = "sandboxed"     # מבודד  
    ISOLATED = "isolated"       # מבוזל
    FULL_ACCESS = "full_access" # גישה מלאה
    CONTAINER = "container"     # קונטיינר
    VIRTUAL = "virtual"         # וירטואלי

class ApplicationType(Enum):
    """Application types that can be created"""
    WEB_APP = "web_app"         # אפליקציית אינטרנט
    MOBILE_APP = "mobile_app"   # אפליקציה ניידת
    DESKTOP_APP = "desktop_app" # אפליקציית שולחן עבודה
    GAME = "game"              # משחק
    API = "api"                # ממשק תכנות
    LIBRARY = "library"        # ספרייה
    FRAMEWORK = "framework"    # מסגרת עבודה
    MICROSERVICE = "microservice" # מיקרו שירות
    BLOCKCHAIN = "blockchain"   # בלוקצ'יין
    AI_MODEL = "ai_model"      # מודל בינה מלאכותית
    SCRIPT = "script"          # סקריפט
    TOOL = "tool"             # כלי

@dataclass
class CodeExecutionRequest:
    """
    Request for code execution
    בקשה להרצת קוד
    """
    request_id: str
    language: str
    code: str
    execution_mode: CodeExecutionMode = CodeExecutionMode.SAFE
    timeout_seconds: int = 30
    memory_limit_mb: int = 512
    cpu_limit_percent: float = 50.0
    
    # Input/Output
    input_data: Optional[str] = None
    expected_output: Optional[str] = None
    
    # Environment
    working_directory: str = "/tmp"
    environment_vars: Dict[str, str] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    
    # Security
    network_access: bool = False
    file_system_access: bool = True
    system_calls_allowed: List[str] = field(default_factory=list)
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    user_id: str = ""
    project_id: str = ""

@dataclass
class CodeExecutionResult:
    """
    Result of code execution
    תוצאת הרצת קוד
    """
    request_id: str
    success: bool
    exit_code: int = 0
    
    # Output
    stdout: str = ""
    stderr: str = ""
    output_files: List[str] = field(default_factory=list)
    
    # Performance
    execution_time: float = 0.0
    memory_usage: int = 0  # bytes
    cpu_usage: float = 0.0  # percentage
    
    # Analysis
    syntax_errors: List[str] = field(default_factory=list)
    runtime_errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    
    # Security
    security_violations: List[str] = field(default_factory=list)
    blocked_operations: List[str] = field(default_factory=list)
    
    # Metadata
    completed_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'request_id': self.request_id,
            'success': self.success,
            'exit_code': self.exit_code,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'output_files': self.output_files,
            'execution_time': self.execution_time,
            'memory_usage': self.memory_usage,
            'cpu_usage': self.cpu_usage,
            'syntax_errors': self.syntax_errors,
            'runtime_errors': self.runtime_errors,
            'warnings': self.warnings,
            'suggestions': self.suggestions,
            'security_violations': self.security_violations,
            'blocked_operations': self.blocked_operations,
            'completed_at': self.completed_at.isoformat()
        }

@dataclass
class ApplicationGenerationRequest:
    """
    Request for application generation
    בקשה ליצירת אפליקציה
    """
    app_name: str
    app_type: ApplicationType
    language: str
    description: str
    features: List[str] = field(default_factory=list)
    
    # Technical requirements
    frameworks: List[str] = field(default_factory=list)
    databases: List[str] = field(default_factory=list)
    apis: List[str] = field(default_factory=list)
    deployment_target: str = ""
    
    # UI/UX requirements
    ui_framework: str = ""
    theme: str = "modern"
    responsive: bool = True
    accessibility: bool = True
    
    # Performance requirements
    performance_targets: Dict[str, float] = field(default_factory=dict)
    scalability_requirements: List[str] = field(default_factory=list)
    
    # Security requirements
    authentication: bool = True
    authorization: bool = True
    encryption: bool = True
    security_level: str = "high"  # low, medium, high, critical
    
    created_at: datetime = field(default_factory=datetime.now)

@dataclass
class ApplicationStructure:
    """
    Generated application structure
    מבנה אפליקציה שנוצרה
    """
    app_name: str
    app_type: ApplicationType
    language: str
    
    # File structure
    files: Dict[str, str] = field(default_factory=dict)  # filename -> content
    directories: List[str] = field(default_factory=list)
    
    # Configuration files
    package_file: Optional[str] = None  # package.json, requirements.txt, etc.
    config_files: Dict[str, str] = field(default_factory=dict)
    
    # Build and deployment
    build_scripts: List[str] = field(default_factory=list)
    deployment_scripts: List[str] = field(default_factory=list)
    dockerfile: Optional[str] = None
    
    # Documentation
    readme: str = ""
    api_docs: str = ""
    user_manual: str = ""
    
    # Tests
    test_files: Dict[str, str] = field(default_factory=dict)
    test_data: Dict[str, Any] = field(default_factory=dict)
    
    created_at: datetime = field(default_factory=datetime.now)

class AdvancedCodingEngine:
    """
    The ultimate programming and development engine
    מנוע התכנות והפיתוח הסופי
    """
    
    def __init__(self):
        # Language support
        self.supported_languages: Dict[str, ProgrammingLanguage] = {}
        self.language_executors: Dict[str, callable] = {}
        self.code_analyzers: Dict[str, callable] = {}
        
        # Execution environments
        self.execution_environments: Dict[str, Dict] = {}
        self.active_sessions: Dict[str, Dict] = {}
        
        # Code intelligence
        self.code_templates: Dict[str, Dict] = {}
        self.design_patterns: Dict[str, Dict] = {}
        self.code_snippets: Dict[str, List] = {}
        
        # Application generation
        self.app_templates: Dict[ApplicationType, Dict] = {}
        self.framework_configs: Dict[str, Dict] = {}
        
        # Security and sandboxing
        self.security_policies: Dict[str, Dict] = {}
        self.sandbox_configs: Dict[str, Dict] = {}
        
        # Performance monitoring
        self.execution_metrics: List[Dict] = []
        self.performance_history: Dict[str, List] = {}
        
        # Local AI Integration
        self.local_ai_client: Optional[OllamaClient] = None
        self.ai_enabled: bool = True
        self.ai_model_name: str = LocalAIConfig.DEFAULT_MODEL
        
        # Initialize the engine
        self._initialize_engine()
        
        logger.info("Advanced Coding Engine initialized with ultimate capabilities and local AI support")
    
    def _initialize_engine(self):
        """
        Initialize the coding engine with all capabilities
        אתחול מנוע הקידוד עם כל היכולות
        """
        # Initialize supported languages
        self._initialize_languages()
        
        # Initialize execution environments
        self._initialize_execution_environments()
        
        # Initialize code intelligence
        self._initialize_code_intelligence()
        
        # Initialize application templates
        self._initialize_app_templates()
        
        # Initialize security policies
        self._initialize_security()
        
        # Initialize local AI integration
        self._initialize_local_ai()
        
        logger.info("Engine initialization completed with local AI support")
    
    def _initialize_languages(self):
        """Initialize all supported programming languages"""
        # Core languages
        self.supported_languages['python'] = create_python_language()
        self.supported_languages['javascript'] = create_javascript_language()
        self.supported_languages['java'] = create_java_language()
        self.supported_languages['cpp'] = create_cpp_language()
        
        # Additional languages
        self._add_additional_languages()
        
        # Initialize executors for each language
        self.language_executors = {
            'python': self._execute_python,
            'javascript': self._execute_javascript,
            'java': self._execute_java,
            'cpp': self._execute_cpp,
            'c': self._execute_c,
            'csharp': self._execute_csharp,
            'go': self._execute_go,
            'rust': self._execute_rust,
            'typescript': self._execute_typescript,
            'php': self._execute_php,
            'ruby': self._execute_ruby,
            'swift': self._execute_swift,
            'kotlin': self._execute_kotlin,
            'scala': self._execute_scala,
            'r': self._execute_r,
            'matlab': self._execute_matlab,
            'bash': self._execute_bash,
            'powershell': self._execute_powershell,
            'sql': self._execute_sql,
            'html': self._execute_html,
            'css': self._execute_css
        }
        
        # Initialize code analyzers
        self.code_analyzers = {
            'python': self._analyze_python_code,
            'javascript': self._analyze_javascript_code,
            'java': self._analyze_java_code,
            'cpp': self._analyze_cpp_code
        }
    
    def _add_additional_languages(self):
        """Add support for additional programming languages"""
        
        # C# language
        csharp = ProgrammingLanguage(
            name="C#",
            name_hebrew="סי שארפ",
            version="12.0",
            language_type=LanguageType.COMPILED,
            categories=[LanguageCategory.DESKTOP, LanguageCategory.WEB, LanguageCategory.GAME],
            compiler_type=CompilerType.DOTNET,
            runtime_environment=RuntimeEnvironment.CLR,
            first_appeared=2000,
            paradigms=["object-oriented", "functional", "imperative"],
            typing="static, strong",
            memory_management="garbage_collected",
            platform_support=["Windows", "macOS", "Linux"],
            popular_frameworks=["ASP.NET", "Entity Framework", "Unity", "Xamarin"],
            difficulty_level="intermediate",
            performance_rating=8,
            popularity_rank=5
        )
        self.supported_languages['csharp'] = csharp
        
        # Go language
        go = ProgrammingLanguage(
            name="Go",
            name_hebrew="גו",
            version="1.21",
            language_type=LanguageType.COMPILED,
            categories=[LanguageCategory.SYSTEM, LanguageCategory.WEB, LanguageCategory.DEVOPS],
            compiler_type=CompilerType.GO,
            runtime_environment=RuntimeEnvironment.NATIVE,
            first_appeared=2009,
            paradigms=["procedural", "concurrent"],
            typing="static, strong",
            memory_management="garbage_collected",
            platform_support=["Windows", "macOS", "Linux"],
            popular_frameworks=["Gin", "Echo", "Fiber", "Docker", "Kubernetes"],
            difficulty_level="intermediate",
            performance_rating=9,
            popularity_rank=6
        )
        self.supported_languages['go'] = go
        
        # Rust language
        rust = ProgrammingLanguage(
            name="Rust",
            name_hebrew="ראסט",
            version="1.72",
            language_type=LanguageType.COMPILED,
            categories=[LanguageCategory.SYSTEM, LanguageCategory.WEB, LanguageCategory.BLOCKCHAIN],
            compiler_type=CompilerType.RUSTC,
            runtime_environment=RuntimeEnvironment.NATIVE,
            first_appeared=2010,
            paradigms=["functional", "imperative", "object-oriented"],
            typing="static, strong",
            memory_management="ownership",
            platform_support=["Windows", "macOS", "Linux"],
            popular_frameworks=["Tokio", "Actix", "Rocket", "Serde"],
            difficulty_level="advanced",
            performance_rating=10,
            popularity_rank=7
        )
        self.supported_languages['rust'] = rust
        
        # TypeScript
        typescript = ProgrammingLanguage(
            name="TypeScript",
            name_hebrew="טייפ סקריפט",
            version="5.2",
            language_type=LanguageType.HYBRID,
            categories=[LanguageCategory.WEB, LanguageCategory.MOBILE, LanguageCategory.DESKTOP],
            compiler_type=CompilerType.TSC,
            runtime_environment=RuntimeEnvironment.NODE,
            first_appeared=2012,
            paradigms=["object-oriented", "functional", "imperative"],
            typing="static, strong",
            memory_management="garbage_collected",
            platform_support=["Web Browsers", "Node.js"],
            popular_frameworks=["Angular", "React", "Vue.js", "Express.js"],
            difficulty_level="intermediate",
            performance_rating=7,
            popularity_rank=8
        )
        self.supported_languages['typescript'] = typescript
    
    def _initialize_execution_environments(self):
        """Initialize execution environments for different languages"""
        
        # Python environment
        self.execution_environments['python'] = {
            'interpreter': 'python3',
            'virtual_env': True,
            'package_manager': 'pip',
            'container_image': 'python:3.11-slim',
            'security_level': 'medium',
            'resource_limits': {
                'memory': '512MB',
                'cpu': '1 core',
                'disk': '1GB',
                'network': False
            }
        }
        
        # JavaScript/Node.js environment
        self.execution_environments['javascript'] = {
            'runtime': 'node',
            'package_manager': 'npm',
            'container_image': 'node:18-alpine',
            'security_level': 'medium',
            'resource_limits': {
                'memory': '512MB',
                'cpu': '1 core',
                'disk': '1GB',
                'network': False
            }
        }
        
        # Java environment
        self.execution_environments['java'] = {
            'jvm': 'openjdk-17',
            'build_tool': 'maven',
            'container_image': 'openjdk:17-slim',
            'security_level': 'high',
            'resource_limits': {
                'memory': '1GB',
                'cpu': '2 cores',
                'disk': '2GB',
                'network': False
            }
        }
        
        # Add more environments for other languages
    
    def _initialize_code_intelligence(self):
        """Initialize code intelligence features"""
        
        # Code templates for different patterns
        self.code_templates = {
            'python': {
                'class': '''class {class_name}:
    """
    {description}
    """
    
    def __init__(self{params}):
        {init_body}
    
    def {method_name}(self{method_params}):
        """
        {method_description}
        """
        {method_body}
''',
                'function': '''def {function_name}({params}){return_type}:
    """
    {description}
    
    Args:
{args_docs}
    
    Returns:
        {return_description}
    """
    {function_body}
''',
                'api_endpoint': '''@app.route('/{endpoint}', methods=['{method}'])
def {function_name}():
    """
    {description}
    """
    try:
        {endpoint_body}
        return jsonify({{"success": True, "data": data}})
    except Exception as e:
        return jsonify({{"success": False, "error": str(e)}}), 500
'''
            },
            'javascript': {
                'class': '''class {class_name} {{
    /**
     * {description}
     */
    constructor({params}) {{
        {constructor_body}
    }}
    
    /**
     * {method_description}
     */
    {method_name}({method_params}) {{
        {method_body}
    }}
}}''',
                'function': '''/**
 * {description}
 * @param {{{param_types}}} {param_names}
 * @returns {{{return_type}}} {return_description}
 */
function {function_name}({params}) {{
    {function_body}
}}''',
                'react_component': '''import React, {{ useState, useEffect }} from 'react';

/**
 * {description}
 */
const {component_name} = ({{ {props} }}) => {{
    {state_declarations}
    
    useEffect(() => {{
        {effect_body}
    }}, []);
    
    return (
        <div className="{class_name}">
            {jsx_body}
        </div>
    );
}};

export default {component_name};
'''
            }
        }
        
        # Design patterns
        self.design_patterns = {
            'singleton': {
                'description': 'Ensures a class has only one instance',
                'description_hebrew': 'מבטיח שלכלאס יש רק מופע אחד',
                'use_cases': ['database connections', 'logging', 'configuration'],
                'languages': ['python', 'java', 'cpp', 'csharp']
            },
            'factory': {
                'description': 'Creates objects without specifying exact classes',
                'description_hebrew': 'יוצר אובייקטים מבלי לציין כלאסים מדויקים',
                'use_cases': ['object creation', 'dependency injection'],
                'languages': ['python', 'java', 'cpp', 'csharp']
            },
            'observer': {
                'description': 'Notifies multiple objects about state changes',
                'description_hebrew': 'מודיע למספר אובייקטים על שינויי מצב',
                'use_cases': ['event handling', 'model-view architectures'],
                'languages': ['python', 'java', 'javascript', 'cpp']
            }
        }
        
        # Code snippets library
        self.code_snippets = {
            'python': [
                {
                    'name': 'file_reader',
                    'description': 'Read file content safely',
                    'code': '''def read_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            return file.read()
    except FileNotFoundError:
        print(f"File {filepath} not found")
        return None
    except Exception as e:
        print(f"Error reading file: {e}")
        return None'''
                },
                {
                    'name': 'api_client',
                    'description': 'HTTP API client with error handling',
                    'code': '''import requests
import json

def api_request(url, method='GET', data=None, headers=None):
    try:
        response = requests.request(
            method=method,
            url=url,
            json=data,
            headers=headers or {},
            timeout=30
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"API request failed: {e}")
        return None'''
                }
            ],
            'javascript': [
                {
                    'name': 'fetch_api',
                    'description': 'Modern fetch API wrapper',
                    'code': '''async function apiRequest(url, options = {}) {
    try {
        const response = await fetch(url, {
            method: options.method || 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            body: options.data ? JSON.stringify(options.data) : undefined
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API request failed:', error);
        throw error;
    }
}'''
                }
            ]
        }
    
    def _initialize_app_templates(self):
        """Initialize application generation templates"""
        
        self.app_templates = {
            ApplicationType.WEB_APP: {
                'react': {
                    'name': 'React Web Application',
                    'description': 'Modern React web application with TypeScript',
                    'files': {
                        'package.json': '{"name": "{app_name}", "version": "1.0.0", "scripts": {"start": "react-scripts start", "build": "react-scripts build"}}',
                        'src/App.tsx': 'import React from "react"; function App() { return <div>Hello World</div>; } export default App;',
                        'src/index.tsx': 'import React from "react"; import ReactDOM from "react-dom/client"; import App from "./App"; const root = ReactDOM.createRoot(document.getElementById("root")!); root.render(<App />);',
                        'public/index.html': '<!DOCTYPE html><html><head><title>{app_name}</title></head><body><div id="root"></div></body></html>'
                    }
                },
                'vue': {
                    'name': 'Vue.js Web Application',
                    'description': 'Modern Vue.js web application',
                    'files': {
                        'package.json': '{"name": "{app_name}", "version": "1.0.0", "scripts": {"serve": "vue-cli-service serve", "build": "vue-cli-service build"}}',
                        'src/App.vue': '<template><div>Hello World</div></template><script>export default { name: "App" }</script>',
                        'src/main.js': 'import { createApp } from "vue"; import App from "./App.vue"; createApp(App).mount("#app");',
                        'public/index.html': '<!DOCTYPE html><html><head><title>{app_name}</title></head><body><div id="app"></div></body></html>'
                    }
                },
                'flask': {
                    'name': 'Flask Web Application',
                    'description': 'Python Flask web application',
                    'files': {
                        'app.py': '''from flask import Flask, render_template, jsonify
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/hello')
def hello_api():
    return jsonify({"message": "Hello World!"})

if __name__ == '__main__':
    app.run(debug=True)''',
                        'requirements.txt': 'Flask>=2.3.0\nFlask-CORS>=4.0.0',
                        'templates/index.html': '<!DOCTYPE html><html><head><title>{app_name}</title></head><body><h1>Welcome to {app_name}</h1></body></html>'
                    }
                }
            },
            ApplicationType.API: {
                'fastapi': {
                    'name': 'FastAPI REST API',
                    'description': 'Modern Python API with FastAPI',
                    'files': {
                        'main.py': '''from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="{app_name}")

class Item(BaseModel):
    name: str
    description: str = None

@app.get("/")
def read_root():
    return {"message": "Welcome to {app_name}"}

@app.get("/items/{{item_id}}")
def read_item(item_id: int):
    return {"item_id": item_id, "name": "Sample Item"}

@app.post("/items/")
def create_item(item: Item):
    return {"message": "Item created", "item": item}''',
                        'requirements.txt': 'fastapi>=0.104.0\nuvicorn>=0.24.0'
                    }
                },
                'express': {
                    'name': 'Express.js REST API',
                    'description': 'Node.js API with Express.js',
                    'files': {
                        'app.js': '''const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
    res.json({ message: 'Welcome to {app_name}' });
});

app.get('/api/items/:id', (req, res) => {
    const id = req.params.id;
    res.json({ id: id, name: 'Sample Item' });
});

app.post('/api/items', (req, res) => {
    const item = req.body;
    res.json({ message: 'Item created', item: item });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});''',
                        'package.json': '{"name": "{app_name}", "version": "1.0.0", "main": "app.js", "scripts": {"start": "node app.js", "dev": "nodemon app.js"}, "dependencies": {"express": "^4.18.0"}, "devDependencies": {"nodemon": "^3.0.0"}}'
                    }
                }
            },
            ApplicationType.DESKTOP_APP: {
                'electron': {
                    'name': 'Electron Desktop App',
                    'description': 'Cross-platform desktop app with Electron',
                    'files': {
                        'main.js': '''const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
    const mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: true
        }
    });
    
    mainWindow.loadFile('index.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});''',
                        'index.html': '<!DOCTYPE html><html><head><title>{app_name}</title></head><body><h1>Welcome to {app_name}</h1></body></html>',
                        'package.json': '{"name": "{app_name}", "version": "1.0.0", "main": "main.js", "scripts": {"start": "electron ."}, "dependencies": {"electron": "^latest"}}'
                    }
                },
                'tkinter': {
                    'name': 'Python Tkinter Desktop App',
                    'description': 'Python desktop application with Tkinter',
                    'files': {
                        'main.py': '''import tkinter as tk
from tkinter import ttk, messagebox

class {app_name_class}:
    def __init__(self, root):
        self.root = root
        self.root.title("{app_name}")
        self.root.geometry("800x600")
        
        self.setup_ui()
    
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="Welcome to {app_name}", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, pady=10)
        
        # Button
        action_button = ttk.Button(main_frame, text="Click Me", 
                                  command=self.button_clicked)
        action_button.grid(row=1, column=0, pady=10)
    
    def button_clicked(self):
        messagebox.showinfo("Info", "Hello from {app_name}!")

if __name__ == "__main__":
    root = tk.Tk()
    app = {app_name_class}(root)
    root.mainloop()''',
                        'requirements.txt': '# Tkinter is included with Python'
                    }
                }
            }
        }
    
    def _initialize_security(self):
        """Initialize security policies and configurations"""
        
        self.security_policies = {
            'safe': {
                'network_access': False,
                'file_system_read': True,
                'file_system_write': False,
                'system_calls': [],
                'max_execution_time': 30,
                'max_memory': 512 * 1024 * 1024,  # 512MB
                'max_cpu': 50.0
            },
            'sandboxed': {
                'network_access': False,
                'file_system_read': True,
                'file_system_write': True,
                'file_system_paths': ['/tmp'],
                'system_calls': ['read', 'write', 'open', 'close'],
                'max_execution_time': 60,
                'max_memory': 1024 * 1024 * 1024,  # 1GB
                'max_cpu': 75.0
            },
            'full_access': {
                'network_access': True,
                'file_system_read': True,
                'file_system_write': True,
                'system_calls': 'all',
                'max_execution_time': 300,
                'max_memory': 4 * 1024 * 1024 * 1024,  # 4GB
                'max_cpu': 100.0
            }
        }
        
        # Sandbox configurations for different containerization technologies
        self.sandbox_configs = {
            'docker': {
                'base_images': {
                    'python': 'python:3.11-slim',
                    'node': 'node:18-alpine',
                    'java': 'openjdk:17-slim',
                    'gcc': 'gcc:latest'
                },
                'security_options': [
                    '--no-new-privileges',
                    '--read-only',
                    '--tmpfs /tmp',
                    '--cap-drop ALL'
                ]
            },
            'chroot': {
                'jail_path': '/var/chroot',
                'allowed_binaries': [
                    '/bin/sh', '/bin/bash', '/usr/bin/python3',
                    '/usr/bin/node', '/usr/bin/java'
                ]
            }
        }
    
    def _initialize_local_ai(self):
        """
        Initialize local AI integration
        אתחול אינטגרציית בינה מלאכותית מקומית
        """
        try:
            # Initialize Ollama client for local AI
            self.local_ai_client = OllamaClient()
            logger.info(f"Local AI client initialized with model: {self.ai_model_name}")
        except Exception as e:
            logger.warning(f"Failed to initialize local AI: {e}")
            self.ai_enabled = False
    
    async def execute_code(self, request: CodeExecutionRequest) -> CodeExecutionResult:
        """
        Execute code with comprehensive security and monitoring
        הרצת קוד עם אבטחה וניטור מקיפים
        """
        start_time = time.time()
        result = CodeExecutionResult(request_id=request.request_id, success=False)
        
        try:
            logger.info(f"Executing {request.language} code: {request.request_id}")
            
            # Validate request
            if not self._validate_execution_request(request):
                result.stderr = "Invalid execution request"
                return result
            
            # Security checks
            security_violations = self._check_security_violations(request)
            if security_violations:
                result.security_violations = security_violations
                result.stderr = f"Security violations detected: {', '.join(security_violations)}"
                return result
            
            # Code analysis
            analysis_result = await self._analyze_code(request.language, request.code)
            result.syntax_errors = analysis_result.get('syntax_errors', [])
            result.warnings = analysis_result.get('warnings', [])
            result.suggestions = analysis_result.get('suggestions', [])
            
            if result.syntax_errors:
                result.stderr = f"Syntax errors: {'; '.join(result.syntax_errors)}"
                return result
            
            # Execute code
            if request.language in self.language_executors:
                executor = self.language_executors[request.language]
                execution_result = await executor(request)
                
                # Copy execution results
                result.success = execution_result.get('success', False)
                result.exit_code = execution_result.get('exit_code', -1)
                result.stdout = execution_result.get('stdout', '')
                result.stderr = execution_result.get('stderr', '')
                result.output_files = execution_result.get('output_files', [])
                result.memory_usage = execution_result.get('memory_usage', 0)
                result.cpu_usage = execution_result.get('cpu_usage', 0.0)
                result.runtime_errors = execution_result.get('runtime_errors', [])
                result.blocked_operations = execution_result.get('blocked_operations', [])
                
            else:
                result.stderr = f"Language {request.language} is not supported"
                return result
            
            # Performance monitoring
            result.execution_time = time.time() - start_time
            
            # Store metrics
            self._store_execution_metrics(request, result)
            
            logger.info(f"Code execution completed: {request.request_id} (success: {result.success})")
            
        except Exception as e:
            logger.error(f"Code execution error: {e}")
            result.stderr = f"Execution error: {str(e)}"
            result.execution_time = time.time() - start_time
        
        return result
    
    def _validate_execution_request(self, request: CodeExecutionRequest) -> bool:
        """Validate execution request parameters"""
        if not request.language:
            return False
        
        if not request.code.strip():
            return False
        
        if request.timeout_seconds <= 0 or request.timeout_seconds > 3600:
            return False
        
        if request.memory_limit_mb <= 0 or request.memory_limit_mb > 8192:
            return False
        
        return True
    
    def _check_security_violations(self, request: CodeExecutionRequest) -> List[str]:
        """Check for security violations in code"""
        violations = []
        code = request.code.lower()
        
        # Check for dangerous operations
        dangerous_patterns = [
            r'import\s+os',
            r'import\s+subprocess',
            r'import\s+sys',
            r'eval\s*\(',
            r'exec\s*\(',
            r'__import__',
            r'open\s*\(',
            r'file\s*\(',
            r'input\s*\(',
            r'raw_input\s*\('
        ]
        
        if request.execution_mode == CodeExecutionMode.SAFE:
            for pattern in dangerous_patterns:
                if re.search(pattern, code):
                    violations.append(f"Dangerous operation detected: {pattern}")
        
        # Check for network operations
        if not request.network_access:
            network_patterns = [
                r'requests\.',
                r'urllib\.',
                r'http\.',
                r'socket\.',
                r'fetch\(',
                r'XMLHttpRequest'
            ]
            
            for pattern in network_patterns:
                if re.search(pattern, code):
                    violations.append(f"Network operation not allowed: {pattern}")
        
        return violations
    
    async def _analyze_code(self, language: str, code: str) -> Dict[str, Any]:
        """Analyze code for syntax errors, warnings, and suggestions"""
        analysis_result = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        try:
            if language in self.code_analyzers:
                analyzer = self.code_analyzers[language]
                analysis_result = await analyzer(code)
            else:
                # Basic analysis for unsupported languages
                analysis_result = await self._basic_code_analysis(language, code)
        
        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            analysis_result['warnings'].append(f"Analysis error: {str(e)}")
        
        return analysis_result
    
    async def _basic_code_analysis(self, language: str, code: str) -> Dict[str, Any]:
        """Basic code analysis for any language"""
        analysis = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        # Check for common issues
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for very long lines
            if len(line) > 120:
                analysis['warnings'].append(f"Line {i}: Line too long ({len(line)} characters)")
            
            # Check for TODO/FIXME comments
            if 'todo' in line_stripped.lower() or 'fixme' in line_stripped.lower():
                analysis['suggestions'].append(f"Line {i}: TODO/FIXME comment found")
            
            # Check for hardcoded values
            if re.search(r'["\'](?:password|secret|key|token)["\']', line_stripped.lower()):
                analysis['warnings'].append(f"Line {i}: Possible hardcoded credential")
        
        return analysis
    
    async def _analyze_python_code(self, code: str) -> Dict[str, Any]:
        """Advanced Python code analysis"""
        analysis = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        try:
            # Parse Python AST
            tree = ast.parse(code)
            
            # Check for syntax errors (if we get here, syntax is OK)
            # Advanced analysis using AST
            for node in ast.walk(tree):
                # Check for unused imports
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        # Simple check - in real implementation, track usage
                        analysis['suggestions'].append(f"Import found: {alias.name}")
                
                # Check for print statements (suggest logging)
                if isinstance(node, ast.Call) and hasattr(node.func, 'id') and node.func.id == 'print':
                    analysis['suggestions'].append(f"Line {node.lineno}: Consider using logging instead of print")
                
                # Check for bare except clauses
                if isinstance(node, ast.ExceptHandler) and node.type is None:
                    analysis['warnings'].append(f"Line {node.lineno}: Bare except clause found")
        
        except SyntaxError as e:
            analysis['syntax_errors'].append(f"Line {e.lineno}: {e.msg}")
        except Exception as e:
            analysis['warnings'].append(f"Analysis error: {str(e)}")
        
        return analysis
    
    async def _analyze_javascript_code(self, code: str) -> Dict[str, Any]:
        """Advanced JavaScript code analysis"""
        analysis = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        # Basic JavaScript analysis
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for var usage (suggest let/const)
            if re.search(r'\bvar\s+', line_stripped):
                analysis['suggestions'].append(f"Line {i}: Consider using 'let' or 'const' instead of 'var'")
            
            # Check for == usage (suggest ===)
            if re.search(r'(?<![!=])==(?!=)', line_stripped):
                analysis['suggestions'].append(f"Line {i}: Consider using '===' instead of '=='")
            
            # Check for console.log in production
            if 'console.log' in line_stripped:
                analysis['suggestions'].append(f"Line {i}: Remove console.log before production")
        
        return analysis
    
    async def _analyze_java_code(self, code: str) -> Dict[str, Any]:
        """Advanced Java code analysis"""
        analysis = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for System.out.println (suggest logging)
            if 'System.out.println' in line_stripped:
                analysis['suggestions'].append(f"Line {i}: Consider using a logging framework")
            
            # Check for raw types
            if re.search(r'\b(List|Map|Set)\s+\w+\s*=', line_stripped):
                analysis['warnings'].append(f"Line {i}: Consider using generic types")
        
        return analysis
    
    async def _analyze_cpp_code(self, code: str) -> Dict[str, Any]:
        """Advanced C++ code analysis"""
        analysis = {
            'syntax_errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for malloc/free (suggest smart pointers)
            if re.search(r'\b(malloc|free)\s*\(', line_stripped):
                analysis['suggestions'].append(f"Line {i}: Consider using smart pointers instead of malloc/free")
            
            # Check for missing const
            if re.search(r'(\w+)\s*\*\s*(\w+)', line_stripped):
                analysis['suggestions'].append(f"Line {i}: Consider using const for pointer parameters")
        
        return analysis

    # Language-specific execution methods
    async def _execute_python(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Python code"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(request.code)
                temp_file = f.name
            
            # Prepare command
            cmd = ['python3', temp_file]
            
            # Execute with security constraints
            result = await self._execute_with_constraints(cmd, request)
            
            # Cleanup
            os.unlink(temp_file)
            
            return result
            
        except Exception as e:
            return {'success': False, 'stderr': str(e)}
    
    async def _execute_javascript(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute JavaScript code"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
                f.write(request.code)
                temp_file = f.name
            
            # Prepare command
            cmd = ['node', temp_file]
            
            # Execute with security constraints
            result = await self._execute_with_constraints(cmd, request)
            
            # Cleanup
            os.unlink(temp_file)
            
            return result
            
        except Exception as e:
            return {'success': False, 'stderr': str(e)}
    
    async def _execute_java(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Java code"""
        try:
            # Create temporary directory
            temp_dir = tempfile.mkdtemp()
            
            # Extract class name from code
            class_match = re.search(r'public\s+class\s+(\w+)', request.code)
            class_name = class_match.group(1) if class_match else 'Main'
            
            # Create Java file
            java_file = os.path.join(temp_dir, f'{class_name}.java')
            with open(java_file, 'w') as f:
                f.write(request.code)
            
            # Compile
            compile_cmd = ['javac', java_file]
            compile_result = await self._execute_with_constraints(compile_cmd, request)
            
            if not compile_result['success']:
                return compile_result
            
            # Run
            run_cmd = ['java', '-cp', temp_dir, class_name]
            result = await self._execute_with_constraints(run_cmd, request)
            
            # Cleanup
            import shutil
            shutil.rmtree(temp_dir)
            
            return result
            
        except Exception as e:
            return {'success': False, 'stderr': str(e)}
    
    async def _execute_cpp(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute C++ code"""
        try:
            # Create temporary files
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', delete=False) as f:
                f.write(request.code)
                source_file = f.name
            
            executable_file = source_file.replace('.cpp', '')
            
            # Compile
            compile_cmd = ['g++', '-o', executable_file, source_file]
            compile_result = await self._execute_with_constraints(compile_cmd, request)
            
            if not compile_result['success']:
                return compile_result
            
            # Run
            run_cmd = [executable_file]
            result = await self._execute_with_constraints(run_cmd, request)
            
            # Cleanup
            os.unlink(source_file)
            if os.path.exists(executable_file):
                os.unlink(executable_file)
            
            return result
            
        except Exception as e:
            return {'success': False, 'stderr': str(e)}
    
    # Additional language executors...
    async def _execute_c(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute C code"""
        # Similar to C++ but using gcc
        pass
    
    async def _execute_csharp(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute C# code"""
        # Using dotnet CLI
        pass
    
    async def _execute_go(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Go code"""
        # Using go run
        pass
    
    async def _execute_rust(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Rust code"""
        # Using rustc
        pass
    
    async def _execute_typescript(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute TypeScript code"""
        # Using tsc + node
        pass
    
    async def _execute_php(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute PHP code"""
        # Using php CLI
        pass
    
    async def _execute_ruby(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Ruby code"""
        # Using ruby interpreter
        pass
    
    async def _execute_swift(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Swift code"""
        # Using swift compiler
        pass
    
    async def _execute_kotlin(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Kotlin code"""
        # Using kotlinc
        pass
    
    async def _execute_scala(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Scala code"""
        # Using scalac
        pass
    
    async def _execute_r(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute R code"""
        # Using Rscript
        pass
    
    async def _execute_matlab(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute MATLAB code"""
        # Using octave as alternative
        pass
    
    async def _execute_bash(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute Bash script"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
                f.write('#!/bin/bash\n' + request.code)
                temp_file = f.name
            
            # Make executable
            os.chmod(temp_file, 0o755)
            
            # Execute
            cmd = ['bash', temp_file]
            result = await self._execute_with_constraints(cmd, request)
            
            # Cleanup
            os.unlink(temp_file)
            
            return result
            
        except Exception as e:
            return {'success': False, 'stderr': str(e)}
    
    async def _execute_powershell(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute PowerShell script"""
        # Using pwsh
        pass
    
    async def _execute_sql(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute SQL query"""
        # Using sqlite3 or specified database
        pass
    
    async def _execute_html(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute/validate HTML"""
        # HTML validation and preview generation
        pass
    
    async def _execute_css(self, request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute/validate CSS"""
        # CSS validation and preview generation
        pass
    
    async def _execute_with_constraints(self, cmd: List[str], request: CodeExecutionRequest) -> Dict[str, Any]:
        """Execute command with security and resource constraints"""
        try:
            # Prepare environment
            env = os.environ.copy()
            env.update(request.environment_vars)
            
            # Execute with timeout and resource limits
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                cwd=request.working_directory
            )
            
            # Communicate with process
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(input=request.input_data.encode() if request.input_data else None),
                    timeout=request.timeout_seconds
                )
            except asyncio.TimeoutError:
                process.kill()
                return {
                    'success': False,
                    'exit_code': -1,
                    'stderr': f'Execution timed out after {request.timeout_seconds} seconds'
                }
            
            return {
                'success': process.returncode == 0,
                'exit_code': process.returncode,
                'stdout': stdout.decode('utf-8', errors='replace'),
                'stderr': stderr.decode('utf-8', errors='replace'),
                'memory_usage': 0,  # Would need system monitoring
                'cpu_usage': 0.0    # Would need system monitoring
            }
            
        except Exception as e:
            return {
                'success': False,
                'exit_code': -1,
                'stderr': str(e)
            }
    
    def _store_execution_metrics(self, request: CodeExecutionRequest, result: CodeExecutionResult):
        """Store execution metrics for analysis"""
        metric = {
            'timestamp': datetime.now().isoformat(),
            'language': request.language,
            'execution_time': result.execution_time,
            'memory_usage': result.memory_usage,
            'cpu_usage': result.cpu_usage,
            'success': result.success,
            'code_length': len(request.code),
            'execution_mode': request.execution_mode.value
        }
        
        self.execution_metrics.append(metric)
        
        # Keep only last 1000 metrics
        if len(self.execution_metrics) > 1000:
            self.execution_metrics = self.execution_metrics[-1000:]
        
        # Update performance history
        if request.language not in self.performance_history:
            self.performance_history[request.language] = []
        
        self.performance_history[request.language].append(metric)
        
        # Keep only last 100 per language
        if len(self.performance_history[request.language]) > 100:
            self.performance_history[request.language] = self.performance_history[request.language][-100:]
    
    async def generate_application(self, request: ApplicationGenerationRequest) -> ApplicationStructure:
        """
        Generate complete application based on requirements
        יצירת אפליקציה מלאה על בסיס דרישות
        """
        try:
            logger.info(f"Generating {request.app_type.value} application: {request.app_name}")
            
            # Get appropriate template
            template = self._get_app_template(request)
            if not template:
                raise ValueError(f"No template found for {request.app_type.value}")
            
            # Generate application structure
            app_structure = ApplicationStructure(
                app_name=request.app_name,
                app_type=request.app_type,
                language=request.language
            )
            
            # Generate files from template
            await self._generate_files_from_template(app_structure, template, request)
            
            # Add requested features
            await self._add_application_features(app_structure, request)
            
            # Generate configuration files
            await self._generate_config_files(app_structure, request)
            
            # Generate tests
            await self._generate_test_files(app_structure, request)
            
            # Generate documentation
            await self._generate_documentation(app_structure, request)
            
            # Generate deployment files
            await self._generate_deployment_files(app_structure, request)
            
            logger.info(f"Application generation completed: {request.app_name}")
            return app_structure
            
        except Exception as e:
            logger.error(f"Application generation error: {e}")
            raise
    
    def _get_app_template(self, request: ApplicationGenerationRequest) -> Optional[Dict]:
        """Get appropriate application template"""
        app_templates = self.app_templates.get(request.app_type, {})
        
        # Choose template based on language and frameworks
        for framework in request.frameworks:
            if framework.lower() in app_templates:
                return app_templates[framework.lower()]
        
        # Default template for app type
        if app_templates:
            return list(app_templates.values())[0]
        
        return None
    
    async def _generate_files_from_template(self, app_structure: ApplicationStructure, 
                                           template: Dict, request: ApplicationGenerationRequest):
        """Generate files from template"""
        template_files = template.get('files', {})
        
        for filename, content in template_files.items():
            # Replace placeholders
            formatted_content = content.format(
                app_name=request.app_name,
                app_name_class=self._to_class_name(request.app_name),
                description=request.description
            )
            
            app_structure.files[filename] = formatted_content
    
    async def _add_application_features(self, app_structure: ApplicationStructure, 
                                       request: ApplicationGenerationRequest):
        """Add requested features to application"""
        for feature in request.features:
            await self._add_feature(app_structure, feature, request)
    
    async def _add_feature(self, app_structure: ApplicationStructure, 
                          feature: str, request: ApplicationGenerationRequest):
        """Add specific feature to application"""
        feature_lower = feature.lower()
        
        if 'authentication' in feature_lower:
            await self._add_authentication_feature(app_structure, request)
        elif 'database' in feature_lower:
            await self._add_database_feature(app_structure, request)
        elif 'api' in feature_lower:
            await self._add_api_feature(app_structure, request)
        elif 'ui' in feature_lower or 'frontend' in feature_lower:
            await self._add_frontend_feature(app_structure, request)
        # Add more features as needed
    
    async def _add_authentication_feature(self, app_structure: ApplicationStructure, 
                                         request: ApplicationGenerationRequest):
        """Add authentication feature"""
        if request.language == 'python':
            # Add Flask-Login or similar
            auth_code = '''
from flask_login import LoginManager, login_required, login_user, logout_user

login_manager = LoginManager()
login_manager.init_app(app)

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Authentication logic here
    pass

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))
'''
            app_structure.files['auth.py'] = auth_code
        elif request.language == 'javascript':
            # Add JWT or similar
            auth_code = '''
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
        return res.sendStatus(401);
    }
    
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

module.exports = { authenticateToken };
'''
            app_structure.files['auth.js'] = auth_code
    
    async def _add_database_feature(self, app_structure: ApplicationStructure, 
                                   request: ApplicationGenerationRequest):
        """Add database feature"""
        # Add database models and connections
        pass
    
    async def _add_api_feature(self, app_structure: ApplicationStructure, 
                              request: ApplicationGenerationRequest):
        """Add API endpoints"""
        # Add REST API endpoints
        pass
    
    async def _add_frontend_feature(self, app_structure: ApplicationStructure, 
                                   request: ApplicationGenerationRequest):
        """Add frontend components"""
        # Add UI components and styling
        pass
    
    async def _generate_config_files(self, app_structure: ApplicationStructure, 
                                    request: ApplicationGenerationRequest):
        """Generate configuration files"""
        if request.language == 'python':
            if 'requirements.txt' not in app_structure.files:
                requirements = self._generate_python_requirements(request)
                app_structure.files['requirements.txt'] = requirements
        elif request.language == 'javascript':
            if 'package.json' not in app_structure.files:
                package_json = self._generate_package_json(request)
                app_structure.files['package.json'] = package_json
    
    def _generate_python_requirements(self, request: ApplicationGenerationRequest) -> str:
        """Generate Python requirements.txt"""
        requirements = []
        
        if request.app_type == ApplicationType.WEB_APP:
            requirements.extend(['Flask>=2.3.0', 'Flask-CORS>=4.0.0'])
        elif request.app_type == ApplicationType.API:
            requirements.extend(['FastAPI>=0.104.0', 'uvicorn>=0.24.0'])
        
        if 'authentication' in [f.lower() for f in request.features]:
            requirements.append('Flask-Login>=0.6.0')
        
        if request.databases:
            if 'postgresql' in request.databases:
                requirements.append('psycopg2-binary>=2.9.0')
            if 'mysql' in request.databases:
                requirements.append('PyMySQL>=1.1.0')
            if 'mongodb' in request.databases:
                requirements.append('pymongo>=4.5.0')
        
        return '\n'.join(requirements)
    
    def _generate_package_json(self, request: ApplicationGenerationRequest) -> str:
        """Generate package.json for Node.js projects"""
        package_data = {
            "name": request.app_name.lower().replace(' ', '-'),
            "version": "1.0.0",
            "description": request.description,
            "main": "app.js",
            "scripts": {
                "start": "node app.js",
                "dev": "nodemon app.js",
                "test": "jest"
            },
            "dependencies": {},
            "devDependencies": {
                "nodemon": "^3.0.0",
                "jest": "^29.0.0"
            }
        }
        
        if request.app_type == ApplicationType.WEB_APP:
            package_data["dependencies"]["express"] = "^4.18.0"
        
        if 'authentication' in [f.lower() for f in request.features]:
            package_data["dependencies"]["jsonwebtoken"] = "^9.0.0"
            package_data["dependencies"]["bcrypt"] = "^5.1.0"
        
        return json.dumps(package_data, indent=2)
    
    async def _generate_test_files(self, app_structure: ApplicationStructure, 
                                  request: ApplicationGenerationRequest):
        """Generate test files"""
        if request.language == 'python':
            test_content = f'''
import unittest
from {request.app_name.lower().replace(' ', '_')} import app

class Test{self._to_class_name(request.app_name)}(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
    
    def test_home_page(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_api_endpoint(self):
        response = self.app.get('/api/hello')
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
'''
            app_structure.test_files['test_main.py'] = test_content
        
        elif request.language == 'javascript':
            test_content = f'''
const request = require('supertest');
const app = require('./app');

describe('{request.app_name}', () => {{
    test('GET / should return 200', async () => {{
        const response = await request(app).get('/');
        expect(response.status).toBe(200);
    }});
    
    test('GET /api/hello should return JSON', async () => {{
        const response = await request(app).get('/api/hello');
        expect(response.status).toBe(200);
        expect(response.type).toBe('application/json');
    }});
}});
'''
            app_structure.test_files['app.test.js'] = test_content
    
    async def _generate_documentation(self, app_structure: ApplicationStructure, 
                                     request: ApplicationGenerationRequest):
        """Generate documentation"""
        # README.md
        readme_content = f'''# {request.app_name}

{request.description}

## Features

{chr(10).join(f'- {feature}' for feature in request.features)}

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/{request.app_name.lower().replace(' ', '-')}.git
cd {request.app_name.lower().replace(' ', '-')}

# Install dependencies
{'pip install -r requirements.txt' if request.language == 'python' else 'npm install'}
```

## Usage

```bash
# Run the application
{'python app.py' if request.language == 'python' else 'npm start'}
```

## API Documentation

### Endpoints

- `GET /` - Home page
- `GET /api/hello` - Hello API endpoint

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License
'''
        app_structure.readme = readme_content
        
        # API Documentation
        if request.app_type == ApplicationType.API:
            api_docs = self._generate_api_documentation(request)
            app_structure.api_docs = api_docs
    
    def _generate_api_documentation(self, request: ApplicationGenerationRequest) -> str:
        """Generate API documentation"""
        return f'''# {request.app_name} API Documentation

## Overview

This API provides the following functionality:
{chr(10).join(f'- {feature}' for feature in request.features)}

## Authentication

{f"This API uses JWT authentication." if request.authentication else "No authentication required."}

## Endpoints

### GET /
Returns basic information about the API.

### GET /api/hello
Returns a hello message.

**Response:**
```json
{{
    "message": "Hello World!"
}}
```

## Error Handling

All errors return JSON in the following format:
```json
{{
    "success": false,
    "error": "Error message"
}}
```

## Rate Limiting

API calls are limited to 1000 requests per hour per IP address.
'''
    
    async def _generate_deployment_files(self, app_structure: ApplicationStructure, 
                                        request: ApplicationGenerationRequest):
        """Generate deployment files"""
        # Dockerfile
        if request.language == 'python':
            dockerfile_content = f'''FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["python", "app.py"]
'''
        elif request.language == 'javascript':
            dockerfile_content = f'''FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
'''
        else:
            dockerfile_content = f'''# Dockerfile for {request.app_name}
# Add appropriate base image and commands for {request.language}
'''
        
        app_structure.dockerfile = dockerfile_content
        
        # Docker Compose
        docker_compose = f'''version: '3.8'

services:
  {request.app_name.lower().replace(' ', '-')}:
    build: .
    ports:
      - "{'5000' if request.language == 'python' else '3000'}:{'5000' if request.language == 'python' else '3000'}"
    environment:
      - NODE_ENV=production
    depends_on:
      - database
  
  database:
    image: postgres:15
    environment:
      - POSTGRES_DB={request.app_name.lower().replace(' ', '_')}_db
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
'''
        app_structure.config_files['docker-compose.yml'] = docker_compose
    
    def _to_class_name(self, name: str) -> str:
        """Convert name to class name format"""
        return ''.join(word.capitalize() for word in name.split())
    
    def get_supported_languages(self) -> List[Dict[str, Any]]:
        """Get list of all supported programming languages"""
        return [lang.to_dict() for lang in self.supported_languages.values()]
    
    def get_language_info(self, language_name: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific language"""
        lang = self.supported_languages.get(language_name.lower())
        return lang.to_dict() if lang else None
    
    def get_execution_statistics(self) -> Dict[str, Any]:
        """Get execution statistics and performance metrics"""
        if not self.execution_metrics:
            return {'message': 'No execution data available'}
        
        # Calculate statistics
        total_executions = len(self.execution_metrics)
        successful_executions = sum(1 for m in self.execution_metrics if m['success'])
        
        # Language breakdown
        language_stats = {}
        for metric in self.execution_metrics:
            lang = metric['language']
            if lang not in language_stats:
                language_stats[lang] = {'count': 0, 'success_rate': 0, 'avg_time': 0}
            
            language_stats[lang]['count'] += 1
            if metric['success']:
                language_stats[lang]['success_rate'] += 1
        
        # Calculate averages
        for lang_stat in language_stats.values():
            lang_stat['success_rate'] = (lang_stat['success_rate'] / lang_stat['count']) * 100
        
        return {
            'total_executions': total_executions,
            'success_rate': (successful_executions / total_executions) * 100,
            'language_breakdown': language_stats,
            'average_execution_time': sum(m['execution_time'] for m in self.execution_metrics) / total_executions
        }
    
    def get_code_suggestions(self, language: str, context: str = "") -> List[Dict[str, Any]]:
        """Get code suggestions for a specific language and context"""
        suggestions = []
        
        # Get snippets for the language
        language_snippets = self.code_snippets.get(language.lower(), [])
        
        for snippet in language_snippets:
            if not context or any(keyword in snippet['description'].lower() for keyword in context.lower().split()):
                suggestions.append({
                    'name': snippet['name'],
                    'description': snippet['description'],
                    'code': snippet['code'],
                    'type': 'snippet'
                })
        
        # Get applicable design patterns
        applicable_patterns = []
        for pattern_name, pattern_info in self.design_patterns.items():
            if language.lower() in pattern_info.get('languages', []):
                if not context or any(use_case in context.lower() for use_case in pattern_info.get('use_cases', [])):
                    applicable_patterns.append({
                        'name': pattern_name,
                        'description': pattern_info['description'],
                        'description_hebrew': pattern_info['description_hebrew'],
                        'use_cases': pattern_info['use_cases'],
                        'type': 'pattern'
                    })
        
        suggestions.extend(applicable_patterns)
        
        return suggestions[:10]  # Return top 10 suggestions
    
    # AI-Powered Methods using Local Hudson/Llama3.1 Model
    
    async def generate_code_local(self, language: str, task: str, context: str = "") -> Dict[str, Any]:
        """
        Generate code using local AI model
        יצירת קוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            # Prepare the prompt for code generation
            prompt = MessageProcessor.format_code_request(language, task, context)
            
            # Create inference request
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.3,  # Lower temperature for more deterministic code
                max_tokens=2048,
                request_id=str(uuid.uuid4())
            )
            
            # Generate response
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                # Process the response
                processed_response = ResponseProcessor.format_response_with_metadata(
                    result.response, 
                    {
                        'language': language,
                        'task': task,
                        'model_used': self.ai_model_name,
                        'tokens_used': result.total_tokens,
                        'response_time': result.get_response_time_seconds()
                    }
                )
                
                return {
                    'success': True,
                    'language': language,
                    'task': task,
                    'generated_code': processed_response['content'],
                    'code_blocks': processed_response['code_blocks'],
                    'explanation': processed_response['content'],
                    'metadata': processed_response['metadata']
                }
            else:
                return {
                    'success': False,
                    'error': result.error_message,
                    'error_hebrew': 'שגיאה ביצירת הקוד'
                }
        
        except Exception as e:
            logger.error(f"Code generation error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה ביצירת קוד: {str(e)}'
            }
    
    async def analyze_code_local(self, language: str, code: str) -> Dict[str, Any]:
        """
        Analyze code using local AI model
        ניתוח קוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            # Prepare the prompt for code analysis
            prompt = f"""נתח את הקוד הבא ב-{language} וספק:
1. הסבר מה הקוד עושה
2. איכות הקוד ושיפורים אפשריים  
3. בעיות או באגים פוטנציאליים
4. המלצות לביצועים
5. עמידה בסטנדרטים של השפה

הקוד לניתוח:
```{language}
{code}
```

אנא התגב בעברית עם הסברים מפורטים."""
            
            # Create inference request
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.4,
                max_tokens=1500,
                request_id=str(uuid.uuid4())
            )
            
            # Generate analysis
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                analysis = ResponseProcessor.clean_hebrew_response(result.response)
                
                return {
                    'success': True,
                    'language': language,
                    'code_length': len(code),
                    'analysis': analysis,
                    'suggestions': self._extract_suggestions_from_analysis(analysis),
                    'metadata': {
                        'model_used': self.ai_model_name,
                        'tokens_used': result.total_tokens,
                        'response_time': result.get_response_time_seconds(),
                        'analysis_timestamp': datetime.now().isoformat()
                    }
                }
            else:
                return {
                    'success': False,
                    'error': result.error_message,
                    'error_hebrew': 'שגיאה בניתוח הקוד'
                }
        
        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בניתוח קוד: {str(e)}'
            }
    
    async def fix_code_local(self, language: str, code: str, error_message: str = "") -> Dict[str, Any]:
        """
        Fix code issues using local AI model
        תיקון בעיות בקוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            # Prepare the prompt for code fixing
            prompt = f"""תקן את הקוד הבא ב-{language}.

{f"הודעת השגיאה: {error_message}" if error_message else ""}

הקוד הבעייתי:
```{language}
{code}
```

אנא:
1. תקן את הבעיות בקוד
2. הסבר את השינויים שביצעת
3. ספק את הקוד המתוקן
4. הוסף הערות להבנה טובה יותר

התגב בעברית עם הקוד המתוקן."""
            
            # Create inference request
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.2,  # Very low temperature for reliable fixes
                max_tokens=2048,
                request_id=str(uuid.uuid4())
            )
            
            # Generate fix
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                processed_response = ResponseProcessor.format_response_with_metadata(
                    result.response,
                    {
                        'language': language,
                        'original_code_length': len(code),
                        'error_message': error_message,
                        'model_used': self.ai_model_name
                    }
                )
                
                return {
                    'success': True,
                    'language': language,
                    'original_code': code,
                    'fixed_response': processed_response['content'],
                    'fixed_code_blocks': processed_response['code_blocks'],
                    'explanation': processed_response['content'],
                    'changes_made': self._extract_changes_from_response(processed_response['content']),
                    'metadata': processed_response['metadata']
                }
            else:
                return {
                    'success': False,
                    'error': result.error_message,
                    'error_hebrew': 'שגיאה בתיקון הקוד'
                }
        
        except Exception as e:
            logger.error(f"Code fixing error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בתיקון קוד: {str(e)}'
            }
    
    async def optimize_code_local(self, language: str, code: str, optimization_goals: List[str] = None) -> Dict[str, Any]:
        """
        Optimize code using local AI model
        אופטימיזציה של קוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            goals = optimization_goals or ['performance', 'readability', 'memory_efficiency']
            goals_hebrew = {
                'performance': 'ביצועים',
                'readability': 'קריאות',
                'memory_efficiency': 'יעילות זיכרון',
                'maintainability': 'ניתנות לתחזוקה',
                'security': 'אבטחה'
            }
            
            goals_text = ', '.join(goals_hebrew.get(goal, goal) for goal in goals)
            
            # Prepare the prompt for code optimization
            prompt = f"""אופטם את הקוד הבא ב-{language} עבור: {goals_text}

הקוד הנוכחי:
```{language}
{code}
```

אנא:
1. ספק גרסה מאופטמת של הקוד
2. הסבר את השיפורים שביצעת
3. פרט על היתרונות של הגרסה המאופטמת
4. הוסף הערות להבנה

התגב בעברית עם הקוד המאופטם."""
            
            # Create inference request
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.3,
                max_tokens=2048,
                request_id=str(uuid.uuid4())
            )
            
            # Generate optimization
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                processed_response = ResponseProcessor.format_response_with_metadata(
                    result.response,
                    {
                        'language': language,
                        'original_code_length': len(code),
                        'optimization_goals': goals,
                        'model_used': self.ai_model_name
                    }
                )
                
                return {
                    'success': True,
                    'language': language,
                    'original_code': code,
                    'optimization_goals': goals,
                    'optimized_response': processed_response['content'],
                    'optimized_code_blocks': processed_response['code_blocks'],
                    'improvements': self._extract_improvements_from_response(processed_response['content']),
                    'metadata': processed_response['metadata']
                }
            else:
                return {
                    'success': False,
                    'error': result.error_message,
                    'error_hebrew': 'שגיאה באופטימיזציה של הקוד'
                }
        
        except Exception as e:
            logger.error(f"Code optimization error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה באופטימיזציית קוד: {str(e)}'
            }
    
    async def chat_with_local_ai(self, session_id: str, message: str) -> Dict[str, Any]:
        """
        Chat with local AI about programming topics
        צ'אט עם בינה מלאכותית מקומית על נושאי תכנות
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                return {
                    'success': False,
                    'error': 'Local AI not available',
                    'error_hebrew': 'בינה מלאכותית מקומית לא זמינה'
                }
            
            # Prepare Hebrew message with coding context
            context_prompt = PromptTemplates.CODE_ASSISTANT
            formatted_message = MessageProcessor.prepare_hebrew_message(message)
            full_prompt = f"{context_prompt}\n\n{formatted_message}"
            
            # Chat with the local AI
            async with self.local_ai_client as client:
                response = await client.chat(session_id, full_prompt, self.ai_model_name)
            
            # Process response
            cleaned_response = ResponseProcessor.clean_hebrew_response(response)
            code_blocks = ResponseProcessor.extract_code_blocks(response)
            
            return {
                'success': True,
                'session_id': session_id,
                'user_message': message,
                'ai_response': cleaned_response,
                'code_blocks': code_blocks,
                'metadata': {
                    'model_used': self.ai_model_name,
                    'response_length': len(cleaned_response),
                    'has_code': len(code_blocks) > 0,
                    'timestamp': datetime.now().isoformat()
                }
            }
        
        except Exception as e:
            logger.error(f"AI chat error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בצ\'אט עם AI: {str(e)}'
            }
    
    def _extract_suggestions_from_analysis(self, analysis: str) -> List[str]:
        """Extract suggestions from AI analysis response"""
        suggestions = []
        lines = analysis.split('\n')
        for line in lines:
            line = line.strip()
            if any(keyword in line for keyword in ['המלצה', 'שיפור', 'כדאי', 'מומלץ', 'suggestion', 'recommend']):
                suggestions.append(line)
        return suggestions[:5]  # Return top 5 suggestions
    
    def _extract_changes_from_response(self, response: str) -> List[str]:
        """Extract changes made from AI fix response"""
        changes = []
        lines = response.split('\n')
        for line in lines:
            line = line.strip()
            if any(keyword in line for keyword in ['שיניתי', 'תיקנתי', 'הוספתי', 'הסרתי', 'עדכנתי', 'fixed', 'changed', 'added']):
                changes.append(line)
        return changes[:5]  # Return top 5 changes
    
    def _extract_improvements_from_response(self, response: str) -> List[str]:
        """Extract improvements from AI optimization response"""
        improvements = []
        lines = response.split('\n')
        for line in lines:
            line = line.strip()
            if any(keyword in line for keyword in ['שיפור', 'אופטימיזציה', 'יעילות', 'ביצועים', 'improvement', 'optimization']):
                improvements.append(line)
        return improvements[:5]  # Return top 5 improvements
    
    def get_status(self) -> Dict[str, Any]:
        """Get engine status and capabilities"""
        return {
            'status': 'running',
            'supported_languages': len(self.supported_languages),
            'execution_environments': len(self.execution_environments),
            'active_sessions': len(self.active_sessions),
            'total_executions': len(self.execution_metrics),
            'app_templates': len(self.app_templates),
            'code_snippets': sum(len(snippets) for snippets in self.code_snippets.values()),
            'design_patterns': len(self.design_patterns),
            'security_policies': len(self.security_policies),
            'ai_integration': {
                'enabled': self.ai_enabled,
                'model_name': self.ai_model_name,
                'client_status': 'connected' if self.local_ai_client else 'disconnected',
                'local_model': 'Hudson/Llama3.1'
            },
            'capabilities': [
                'code_execution',
                'application_generation',
                'code_analysis',
                'syntax_validation',
                'performance_monitoring',
                'security_scanning',
                'multi_language_support',
                'template_generation',
                'deployment_automation',
                'ai_code_generation',
                'ai_code_analysis',
                'ai_code_fixing',
                'ai_code_optimization',
                'ai_chat_assistance'
            ]
        }