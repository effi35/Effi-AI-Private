#!/usr/bin/env python3
"""
Test script for Advanced Coding System Module
סקריפט בדיקה למודול מערכת קידוד מתקדמת

Tests the integration with local AI (Hudson/Llama3.1) and core functionality.
בודק את האינטגרציה עם AI מקומי (Hudson/Llama3.1) ואת הפונקציונליות הבסיסית.
"""

import asyncio
import logging
import sys
from pathlib import Path

# Add the module path
sys.path.insert(0, str(Path(__file__).parent))

from module import create_module

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_basic_functionality():
    """Test basic module functionality"""
    print("🧪 Testing Basic Functionality / בדיקת פונקציונליות בסיסית")
    print("=" * 60)
    
    try:
        # Create module instance
        coding_system = create_module()
        print("✅ Module created successfully / המודול נוצר בהצלחה")
        
        # Test status
        status = coding_system.get_status()
        print(f"✅ Module status: {status['module']['name']} v{status['module']['version']}")
        print(f"✅ AI Integration: {'Enabled' if status['engine']['ai_integration']['enabled'] else 'Disabled'}")
        
        # Test supported languages
        languages = coding_system.get_supported_languages()
        print(f"✅ Supported languages: {len(languages)} languages available")
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        return False

async def test_code_execution():
    """Test code execution functionality"""
    print("\n🚀 Testing Code Execution / בדיקת הרצת קוד")
    print("=" * 60)
    
    try:
        coding_system = create_module()
        
        # Test Python code execution
        python_code = """
def hello_world():
    return "Hello from Advanced Coding System!"

result = hello_world()
print(result)
"""
        
        print("Testing Python code execution...")
        result = await coding_system.execute_code(
            language="python",
            code=python_code,
            execution_mode="safe",
            timeout_seconds=10
        )
        
        if result['success']:
            print("✅ Python code executed successfully")
            print(f"Output: {result.get('stdout', 'No output')}")
        else:
            print(f"❌ Python execution failed: {result.get('stderr', 'Unknown error')}")
        
        return result['success']
        
    except Exception as e:
        print(f"❌ Code execution test failed: {e}")
        return False

async def test_ai_integration():
    """Test AI integration functionality"""
    print("\n🤖 Testing AI Integration / בדיקת אינטגרציית AI")
    print("=" * 60)
    
    try:
        coding_system = create_module()
        
        # Test AI code generation
        print("Testing AI code generation...")
        result = await coding_system.generate_code(
            language="python",
            task="Create a simple function to calculate the factorial of a number",
            context="Need a clean, efficient implementation with error handling"
        )
        
        if result['success']:
            print("✅ AI code generation successful")
            print(f"Generated code available: {len(result.get('code_blocks', []))} code blocks")
        else:
            print(f"❌ AI code generation failed: {result.get('error_hebrew', result.get('error', 'Unknown error'))}")
        
        # Test AI chat
        print("\nTesting AI chat...")
        chat_result = await coding_system.chat_with_ai(
            session_id="test_session",
            message="מה הדרך הטובה ביותר לכתוב קוד יעיל בפייתון?"
        )
        
        if chat_result['success']:
            print("✅ AI chat successful")
            print(f"Response length: {len(chat_result.get('ai_response', ''))}")
        else:
            print(f"❌ AI chat failed: {chat_result.get('error_hebrew', chat_result.get('error', 'Unknown error'))}")
        
        return result['success'] and chat_result['success']
        
    except Exception as e:
        print(f"❌ AI integration test failed: {e}")
        return False

async def test_code_analysis():
    """Test code analysis functionality"""
    print("\n🔍 Testing Code Analysis / בדיקת ניתוח קוד")
    print("=" * 60)
    
    try:
        coding_system = create_module()
        
        # Test code with potential issues
        test_code = """
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n-1)  # Potential stack overflow for large n

def divide(a, b):
    return a / b  # No zero division check

x = factorial(10)
y = divide(10, 0)  # This will cause an error
print(x, y)
"""
        
        print("Testing code analysis...")
        result = await coding_system.analyze_code("python", test_code)
        
        if result['success']:
            print("✅ Code analysis successful")
            print(f"Built-in suggestions: {len(result.get('builtin_analysis', {}).get('suggestions', []))}")
            
            ai_analysis = result.get('ai_analysis', {})
            if ai_analysis.get('success'):
                print(f"✅ AI analysis successful")
                print(f"AI suggestions: {len(ai_analysis.get('suggestions', []))}")
            else:
                print(f"⚠️ AI analysis not available: {ai_analysis.get('error_hebrew', 'Unknown error')}")
        else:
            print(f"❌ Code analysis failed: {result.get('error', 'Unknown error')}")
        
        return result['success']
        
    except Exception as e:
        print(f"❌ Code analysis test failed: {e}")
        return False

async def test_application_generation():
    """Test application generation functionality"""
    print("\n🏗️ Testing Application Generation / בדיקת יצירת אפליקציה")
    print("=" * 60)
    
    try:
        coding_system = create_module()
        
        print("Testing Flask web application generation...")
        result = await coding_system.generate_application(
            app_name="Test Web App",
            app_type="web_app",
            language="python",
            description="A simple test web application with basic features",
            features=["authentication", "api"],
            frameworks=["flask"]
        )
        
        if result['success']:
            app_structure = result['app_structure']
            print("✅ Application generation successful")
            print(f"Generated files: {len(app_structure.get('files', {}))}")
            print(f"App name: {app_structure.get('app_name')}")
            print(f"Language: {app_structure.get('language')}")
        else:
            print(f"❌ Application generation failed: {result.get('error', 'Unknown error')}")
        
        return result['success']
        
    except Exception as e:
        print(f"❌ Application generation test failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🎯 Advanced Coding System Module Tests")
    print("מודול מערכת קידוד מתקדמת - בדיקות")
    print("=" * 60)
    
    tests = [
        ("Basic Functionality", test_basic_functionality),
        ("Code Execution", test_code_execution),
        ("AI Integration", test_ai_integration),
        ("Code Analysis", test_code_analysis),
        ("Application Generation", test_application_generation)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ Test {test_name} crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n📊 Test Results Summary / סיכום תוצאות בדיקות")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\nTotal: {passed}/{total} tests passed")
    print(f"Success rate: {(passed/total)*100:.1f}%")
    
    if passed == total:
        print("\n🎉 All tests passed! Module is working correctly.")
        print("🎉 כל הבדיקות עברו! המודול עובד כראוי.")
    else:
        print(f"\n⚠️ {total-passed} tests failed. Please check the errors above.")
        print(f"⚠️ {total-passed} בדיקות נכשלו. אנא בדוק את השגיאות למעלה.")
    
    return passed == total

if __name__ == "__main__":
    try:
        success = asyncio.run(main())
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1)