# Advanced Coding System Module
## מודול מערכת קידוד מתקדמת

The most comprehensive programming and development system with local AI integration using Hudson/Llama3.1.

מערכת התכנות והפיתוח הכי מקיפה עם אינטגרציית בינה מלאכותית מקומית באמצעות Hudson/Llama3.1.

## Features / תכונות

### Core Programming Features / תכונות תכנות יסודיות
- **Multi-language Support** - תמיכה במגוון שפות תכנות
  - Python, JavaScript, Java, C++, C#, Go, Rust, TypeScript ועוד
- **Code Execution** - הרצת קוד עם אבטחה מלאה
- **Code Analysis** - ניתוח קוד מתקדם ואיתור בעיות
- **Application Generation** - יצירה אוטומטית של אפליקציות שלמות

### AI-Powered Features / תכונות מונעות בינה מלאכותית
- **Local AI Code Generation** - יצירת קוד באמצעות מודל מקומי
- **AI Code Analysis** - ניתוח קוד חכם עם המלצות
- **AI Code Fixing** - תיקון אוטומטי של בעיות בקוד
- **AI Code Optimization** - אופטימיזציה של קוד לביצועים
- **AI Programming Assistant** - עוזר תכנות חכם בעברית

### Security & Performance / אבטחה וביצועים
- **Secure Code Execution** - הרצת קוד בסביבה מבודדת
- **Performance Monitoring** - ניטור ביצועים בזמן אמת
- **Resource Management** - ניהול משאבי מערכת
- **Security Scanning** - סריקת אבטחה של קוד

## Installation / התקנה

### Prerequisites / דרישות מוקדמות
1. Python 3.8+
2. Ollama server with Hudson/Llama3.1 model
3. Local AI Integration module

### Setup / הגדרה
```bash
# Install required dependencies
pip install -r requirements.txt

# Ensure Ollama is running with Hudson model
ollama pull hudson/llama3.1-uncensored

# Initialize the module
python module.py
```

## Usage Examples / דוגמאות שימוש

### Basic Code Execution / הרצת קוד בסיסית
```python
from advanced_coding_system import create_module

# Create module instance
coding_system = create_module()

# Execute Python code
result = await coding_system.execute_code(
    language="python",
    code="print('Hello, World!')",
    execution_mode="safe"
)
print(result)
```

### AI Code Generation / יצירת קוד עם AI
```python
# Generate code using local AI
result = await coding_system.generate_code(
    language="python",
    task="Create a function to calculate fibonacci numbers",
    context="Need an efficient recursive implementation"
)
print(result['generated_code'])
```

### AI Code Analysis / ניתוח קוד עם AI
```python
# Analyze code with AI
code = """
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n-1)
"""

result = await coding_system.analyze_code("python", code)
print(result['ai_analysis']['analysis'])
```

### AI Code Fixing / תיקון קוד עם AI
```python
# Fix problematic code
buggy_code = """
def divide(a, b):
    return a / b  # No zero division check
"""

result = await coding_system.fix_code(
    language="python",
    code=buggy_code,
    error_message="ZeroDivisionError possible"
)
print(result['fixed_response'])
```

### Application Generation / יצירת אפליקציה
```python
# Generate complete application
result = await coding_system.generate_application(
    app_name="My Web App",
    app_type="web_app",
    language="python",
    description="A modern web application with user authentication",
    features=["authentication", "database", "api"],
    frameworks=["flask"]
)
print(result['app_structure'])
```

### AI Chat Assistant / עוזר צ'אט AI
```python
# Chat with AI about programming
result = await coding_system.chat_with_ai(
    session_id="coding_session_1",
    message="איך אני יכול לשפר את הביצועים של הקוד שלי?"
)
print(result['ai_response'])
```

## API Reference / תיעוד API

### Core Methods / מתודות יסוד

#### `execute_code(language, code, **kwargs)`
Execute code securely with monitoring.
הרצת קוד בטוחה עם ניטור.

**Parameters:**
- `language`: Programming language
- `code`: Code to execute
- `execution_mode`: Security level ('safe', 'sandboxed', 'full_access')
- `timeout_seconds`: Execution timeout
- `memory_limit_mb`: Memory limit

#### `analyze_code(language, code)`
Analyze code for issues and suggestions.
ניתוח קוד לבעיות והצעות.

### AI-Powered Methods / מתודות מונעות AI

#### `generate_code(language, task, context="")`
Generate code using local AI model.
יצירת קוד באמצעות מודל AI מקומי.

#### `fix_code(language, code, error_message="")`
Fix code issues using AI.
תיקון בעיות בקוד באמצעות AI.

#### `optimize_code(language, code, goals=None)`
Optimize code for performance and readability.
אופטימיזציה של קוד לביצועים וקריאות.

#### `chat_with_ai(session_id, message)`
Chat with AI programming assistant.
צ'אט עם עוזר תכנות AI.

### Application Methods / מתודות אפליקציה

#### `generate_application(app_name, app_type, language, description, **kwargs)`
Generate complete application structure.
יצירת מבנה אפליקציה מלא.

### Information Methods / מתודות מידע

#### `get_supported_languages()`
Get list of supported programming languages.

#### `get_language_info(language_name)`
Get detailed language information.

#### `get_status()`
Get module and engine status.

## Configuration / תצורה

### Local AI Settings / הגדרות AI מקומי
```python
# AI model configuration
AI_MODEL = "hudson/llama3.1-uncensored"
AI_HOST = "http://localhost:11434"
AI_TIMEOUT = 300
```

### Security Settings / הגדרות אבטחה
```python
# Execution security
DEFAULT_EXECUTION_MODE = "safe"
MAX_EXECUTION_TIME = 30
MAX_MEMORY_MB = 512
NETWORK_ACCESS = False
```

## Architecture / ארכיטקטורה

```
advanced_coding_system/
├── core/
│   └── advanced_coding_engine.py    # Main engine
├── models/
│   ├── __init__.py
│   └── programming_languages.py    # Language definitions
├── module.py                       # Module interface
└── README.md                      # This file
```

## Integration with Local AI / אינטגרציה עם AI מקומי

The module integrates seamlessly with the `local_ai_integration` module to provide:

המודול משתלב באופן חלק עם מודול `local_ai_integration` כדי לספק:

- **Private AI Processing** - עיבוד AI פרטי ומקומי
- **Hebrew Language Support** - תמיכה מלאה בעברית
- **No External Dependencies** - ללא תלות בשירותים חיצוניים
- **Optimized for Coding** - מותאם למשימות תכנות

## Performance / ביצועים

- **Multi-threaded Execution** - הרצה מרובת חוטים
- **Memory Optimization** - אופטימיזציית זיכרון
- **Caching System** - מערכת מטמון חכמה
- **Resource Monitoring** - ניטור משאבים

## Security / אבטחה

- **Sandboxed Execution** - הרצה מבודדת
- **Code Validation** - אימות קוד
- **Resource Limits** - הגבלות משאבים
- **Security Scanning** - סריקת אבטחה

## Contributing / תרומה

1. Fork the repository
2. Create feature branch
3. Follow Hebrew + English documentation
4. Test with local AI integration
5. Submit pull request

## License / רישיון

This module is part of the Effi AI Private System.
מודול זה הוא חלק ממערכת Effi AI הפרטית.

## Changelog / יומן שינויים

### Version 2.0.0
- **Added Local AI Integration** - הוספת אינטגרציית AI מקומית
- **Hudson/Llama3.1 Support** - תמיכה במודל Hudson/Llama3.1
- **Enhanced Code Generation** - יצירת קוד משופרת
- **AI-Powered Analysis** - ניתוח מונע AI
- **Hebrew Language Support** - תמיכה מלאה בעברית
- **Removed External API Dependencies** - הסרת תלות בAPI חיצוניים

### Version 1.0.0
- Initial release with basic coding features
- Multi-language support
- Code execution and analysis
- Application generation