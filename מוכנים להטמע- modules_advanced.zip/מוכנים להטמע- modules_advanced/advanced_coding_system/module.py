"""
Advanced Coding System Module
מודול מערכת קידוד מתקדמת

The ultimate programming and development system with local AI integration.
מערכת התכנות והפיתוח הסופית עם אינטגרציית בינה מלאכותית מקומית.
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

# Import the main engine
from .core.advanced_coding_engine import (
    AdvancedCodingEngine, 
    CodeExecutionRequest, 
    CodeExecutionResult,
    ApplicationGenerationRequest,
    ApplicationStructure,
    CodeExecutionMode,
    ApplicationType
)

logger = logging.getLogger(__name__)

class AdvancedCodingSystemModule:
    """
    Advanced Coding System Module with Local AI Integration
    מודול מערכת קידוד מתקדמת עם אינטגרציית בינה מלאכותית מקומית
    """
    
    def __init__(self):
        self.name = "advanced_coding_system"
        self.name_hebrew = "מערכת קידוד מתקדמת"
        self.version = "2.0.0"
        self.description = "The most comprehensive programming and development system with local AI support"
        self.description_hebrew = "מערכת התכנות והפיתוח הכי מקיפה עם תמיכה בבינה מלאכותית מקומית"
        
        # Initialize the main engine
        self.engine = AdvancedCodingEngine()
        
        # Module status
        self.is_initialized = True
        self.last_activity = datetime.now()
        
        logger.info(f"Advanced Coding System Module initialized with local AI support")
    
    # Core Code Execution Methods
    
    async def execute_code(self, language: str, code: str, **kwargs) -> Dict[str, Any]:
        """
        Execute code with security and monitoring
        הרצת קוד עם אבטחה וניטור
        """
        try:
            request = CodeExecutionRequest(
                request_id=kwargs.get('request_id', f"exec_{datetime.now().timestamp()}"),
                language=language,
                code=code,
                execution_mode=CodeExecutionMode(kwargs.get('execution_mode', 'safe')),
                timeout_seconds=kwargs.get('timeout_seconds', 30),
                memory_limit_mb=kwargs.get('memory_limit_mb', 512),
                input_data=kwargs.get('input_data'),
                working_directory=kwargs.get('working_directory', '/tmp'),
                environment_vars=kwargs.get('environment_vars', {}),
                network_access=kwargs.get('network_access', False)
            )
            
            result = await self.engine.execute_code(request)
            self.last_activity = datetime.now()
            
            return result.to_dict()
            
        except Exception as e:
            logger.error(f"Code execution error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בהרצת קוד: {str(e)}'
            }
    
    async def analyze_code(self, language: str, code: str) -> Dict[str, Any]:
        """
        Analyze code for syntax, patterns, and suggestions
        ניתוח קוד לתחביר, דפוסים והצעות
        """
        try:
            # Use both built-in analysis and AI analysis
            builtin_analysis = await self.engine._analyze_code(language, code)
            
            # Try AI analysis if available
            ai_analysis = await self.engine.analyze_code_local(language, code)
            
            self.last_activity = datetime.now()
            
            return {
                'success': True,
                'language': language,
                'code_length': len(code),
                'builtin_analysis': builtin_analysis,
                'ai_analysis': ai_analysis,
                'combined_suggestions': self._combine_suggestions(builtin_analysis, ai_analysis),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בניתוח קוד: {str(e)}'
            }
    
    # AI-Powered Methods
    
    async def generate_code(self, language: str, task: str, context: str = "") -> Dict[str, Any]:
        """
        Generate code using local AI model
        יצירת קוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            result = await self.engine.generate_code_local(language, task, context)
            self.last_activity = datetime.now()
            return result
            
        except Exception as e:
            logger.error(f"Code generation error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה ביצירת קוד: {str(e)}'
            }
    
    async def fix_code(self, language: str, code: str, error_message: str = "") -> Dict[str, Any]:
        """
        Fix code issues using local AI model
        תיקון בעיות בקוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            result = await self.engine.fix_code_local(language, code, error_message)
            self.last_activity = datetime.now()
            return result
            
        except Exception as e:
            logger.error(f"Code fixing error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בתיקון קוד: {str(e)}'
            }
    
    async def optimize_code(self, language: str, code: str, goals: List[str] = None) -> Dict[str, Any]:
        """
        Optimize code using local AI model
        אופטימיזציה של קוד באמצעות מודל בינה מלאכותית מקומי
        """
        try:
            result = await self.engine.optimize_code_local(language, code, goals)
            self.last_activity = datetime.now()
            return result
            
        except Exception as e:
            logger.error(f"Code optimization error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה באופטימיזציית קוד: {str(e)}'
            }
    
    async def chat_with_ai(self, session_id: str, message: str) -> Dict[str, Any]:
        """
        Chat with local AI about programming topics
        צ'אט עם בינה מלאכותית מקומית על נושאי תכנות
        """
        try:
            result = await self.engine.chat_with_local_ai(session_id, message)
            self.last_activity = datetime.now()
            return result
            
        except Exception as e:
            logger.error(f"AI chat error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה בצ\'אט עם AI: {str(e)}'
            }
    
    # Application Generation Methods
    
    async def generate_application(self, app_name: str, app_type: str, language: str, 
                                 description: str, **kwargs) -> Dict[str, Any]:
        """
        Generate complete application structure
        יצירת מבנה אפליקציה מלא
        """
        try:
            request = ApplicationGenerationRequest(
                app_name=app_name,
                app_type=ApplicationType(app_type),
                language=language,
                description=description,
                features=kwargs.get('features', []),
                frameworks=kwargs.get('frameworks', []),
                databases=kwargs.get('databases', []),
                ui_framework=kwargs.get('ui_framework', ''),
                authentication=kwargs.get('authentication', True),
                security_level=kwargs.get('security_level', 'high')
            )
            
            result = await self.engine.generate_application(request)
            self.last_activity = datetime.now()
            
            return {
                'success': True,
                'app_structure': {
                    'app_name': result.app_name,
                    'app_type': result.app_type.value,
                    'language': result.language,
                    'files': result.files,
                    'directories': result.directories,
                    'config_files': result.config_files,
                    'test_files': result.test_files,
                    'readme': result.readme,
                    'dockerfile': result.dockerfile,
                    'created_at': result.created_at.isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Application generation error: {e}")
            return {
                'success': False,
                'error': str(e),
                'error_hebrew': f'שגיאה ביצירת אפליקציה: {str(e)}'
            }
    
    # Information and Utility Methods
    
    def get_supported_languages(self) -> List[Dict[str, Any]]:
        """Get list of all supported programming languages"""
        return self.engine.get_supported_languages()
    
    def get_language_info(self, language_name: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific language"""
        return self.engine.get_language_info(language_name)
    
    def get_code_suggestions(self, language: str, context: str = "") -> List[Dict[str, Any]]:
        """Get code suggestions for a specific language and context"""
        return self.engine.get_code_suggestions(language, context)
    
    def get_execution_statistics(self) -> Dict[str, Any]:
        """Get execution statistics and performance metrics"""
        return self.engine.get_execution_statistics()
    
    def get_status(self) -> Dict[str, Any]:
        """Get module and engine status"""
        engine_status = self.engine.get_status()
        
        return {
            'module': {
                'name': self.name,
                'name_hebrew': self.name_hebrew,
                'version': self.version,
                'description': self.description,
                'description_hebrew': self.description_hebrew,
                'initialized': self.is_initialized,
                'last_activity': self.last_activity.isoformat()
            },
            'engine': engine_status,
            'capabilities': {
                'code_execution': True,
                'code_analysis': True,
                'ai_code_generation': engine_status['ai_integration']['enabled'],
                'ai_code_analysis': engine_status['ai_integration']['enabled'],
                'ai_code_fixing': engine_status['ai_integration']['enabled'],
                'ai_code_optimization': engine_status['ai_integration']['enabled'],
                'ai_chat_assistance': engine_status['ai_integration']['enabled'],
                'application_generation': True,
                'multi_language_support': True,
                'security_scanning': True,
                'performance_monitoring': True
            }
        }
    
    # Helper Methods
    
    def _combine_suggestions(self, builtin_analysis: Dict[str, Any], 
                           ai_analysis: Dict[str, Any]) -> List[str]:
        """Combine suggestions from built-in analysis and AI analysis"""
        suggestions = []
        
        # Add built-in suggestions
        if 'suggestions' in builtin_analysis:
            suggestions.extend(builtin_analysis['suggestions'])
        
        # Add AI suggestions if available
        if ai_analysis.get('success') and 'suggestions' in ai_analysis:
            suggestions.extend(ai_analysis['suggestions'])
        
        # Remove duplicates and return
        return list(set(suggestions))[:10]  # Top 10 unique suggestions

# Module factory function
def create_module() -> AdvancedCodingSystemModule:
    """Create an instance of the Advanced Coding System Module"""
    return AdvancedCodingSystemModule()

# Module metadata
MODULE_INFO = {
    'name': 'advanced_coding_system',
    'name_hebrew': 'מערכת קידוד מתקדמת',
    'version': '2.0.0',
    'description': 'The most comprehensive programming and development system with local AI support',
    'description_hebrew': 'מערכת התכנות והפיתוח הכי מקיפה עם תמיכה בבינה מלאכותית מקומית',
    'author': 'Effi AI System',
    'requires': ['local_ai_integration'],
    'capabilities': [
        'code_execution',
        'code_analysis', 
        'ai_code_generation',
        'ai_code_analysis',
        'ai_code_fixing',
        'ai_code_optimization',
        'ai_chat_assistance',
        'application_generation',
        'multi_language_support',
        'security_scanning',
        'performance_monitoring'
    ]
}