#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
אוטומציה ברשתות חברתיות - Examples
"""
