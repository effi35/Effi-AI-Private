"""
Memory Runtime Engine - מנוע זיכרון זמן אמת
מנוע חכם ואוטונומי לניהול זיכרון חי הלומד ומתפתח
"""

import asyncio
import threading
import sqlite3
import json
import pickle
import gzip
from typing import Dict, List, Optional, Any, Set, Tuple, Callable
from datetime import datetime, timedelta
from collections import defaultdict, deque
import logging
import uuid
import os
import hashlib
from concurrent.futures import ThreadPoolExecutor
import numpy as np

from ..models.runtime_memory import (
    RuntimeMemory, MemoryFragment, MemoryContext, MemoryAssociation,
    MemoryType, MemoryPriority, MemoryStatus, MemoryScope,
    MemoryCluster, MemoryIndex
)
from ..models.config import AutoMemoryConfig

class MemoryRuntime:
    """מנוע זיכרון זמן אמת מתקדם"""
    
    def __init__(self, config: AutoMemoryConfig = None):
        self.config = config or AutoMemoryConfig()
        self.logger = self._setup_logger()
        
        # מאגר זיכרון ראשי
        self.active_memories: Dict[str, RuntimeMemory] = {}
        self.dormant_memories: Dict[str, RuntimeMemory] = {}
        self.archived_memories: Dict[str, str] = {}  # memory_id -> file_path
        
        # אשכולות זיכרון
        self.memory_clusters: Dict[str, MemoryCluster] = {}
        
        # אינדקס חיפוש מתקדם
        self.memory_index = MemoryIndex()
        
        # מטמון וביצועים
        self.memory_cache: Dict[str, Any] = {}
        self.cache_hits = 0
        self.cache_misses = 0
        
        # מסד נתונים
        self.db_connection = self._init_database()
        
        # עיבוד אסינכרוני
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.event_loop = None
        self.background_tasks: Set[asyncio.Task] = set()
        
        # ניטור ואופטימיזציה
        self.memory_stats = {
            'total_memories': 0,
            'active_memories': 0,
            'dormant_memories': 0,
            'archived_memories': 0,
            'total_clusters': 0,
            'last_optimization': None,
            'memory_usage_mb': 0
        }
        
        # מנגנון למידה
        self.learning_patterns: Dict[str, Any] = {}
        self.behavioral_insights: List[str] = []
        self.predictive_models: Dict[str, Any] = {}
        
        # אירועים וקולבקים
        self.event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        
        # הפעלת מנוע הרקע
        self._start_background_engine()
        
        self.logger.info("מנוע זיכרון זמן אמת הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים מתקדמת"""
        logger = logging.getLogger("MemoryRuntime")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        # יצירת מטפל קובץ עם רוטציה
        log_dir = os.path.join(self.config.data_directory, "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        handler = logging.FileHandler(
            os.path.join(log_dir, f"memory_runtime_{datetime.now().strftime('%Y%m%d')}.log")
        )
        
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _init_database(self) -> sqlite3.Connection:
        """אתחול מסד נתונים מתקדם"""
        db_path = os.path.join(self.config.data_directory, "memory_runtime.db")
        os.makedirs(self.config.data_directory, exist_ok=True)
        
        conn = sqlite3.connect(db_path, check_same_thread=False)
        cursor = conn.cursor()
        
        # טבלת זיכרונות ראשית
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memories (
                memory_id TEXT PRIMARY KEY,
                memory_type TEXT NOT NULL,
                priority INTEGER NOT NULL,
                status TEXT NOT NULL,
                scope TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL,
                last_accessed TIMESTAMP NOT NULL,
                last_modified TIMESTAMP NOT NULL,
                access_count INTEGER DEFAULT 0,
                modification_count INTEGER DEFAULT 0,
                strength REAL DEFAULT 1.0,
                decay_rate REAL DEFAULT 0.01,
                predictive_value REAL DEFAULT 0.0,
                is_protected BOOLEAN DEFAULT FALSE,
                encryption_level INTEGER DEFAULT 0,
                data_compressed BLOB,
                file_path TEXT,
                checksum TEXT
            )
        ''')
        
        # טבלת פרגמנטים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_fragments (
                fragment_id TEXT PRIMARY KEY,
                memory_id TEXT NOT NULL,
                content_type TEXT NOT NULL,
                encoding TEXT NOT NULL,
                timestamp TIMESTAMP NOT NULL,
                source TEXT NOT NULL,
                confidence REAL NOT NULL,
                relevance REAL NOT NULL,
                emotional_weight REAL DEFAULT 0.0,
                content_compressed BLOB,
                FOREIGN KEY (memory_id) REFERENCES memories (memory_id)
            )
        ''')
        
        # טבלת הקשרים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_contexts (
                context_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                description TEXT,
                participants TEXT,  -- JSON array
                environment TEXT,   -- JSON object
                temporal_start TIMESTAMP NOT NULL,
                temporal_end TIMESTAMP,
                spatial_bounds TEXT,  -- JSON object
                emotional_tone REAL DEFAULT 0.0,
                importance REAL DEFAULT 0.5,
                tags TEXT  -- JSON array
            )
        ''')
        
        # טבלת קשרים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_associations (
                association_id TEXT PRIMARY KEY,
                from_memory_id TEXT NOT NULL,
                to_memory_id TEXT NOT NULL,
                association_type TEXT NOT NULL,
                strength REAL NOT NULL,
                bidirectional BOOLEAN DEFAULT TRUE,
                confidence REAL DEFAULT 1.0,
                created_at TIMESTAMP NOT NULL,
                FOREIGN KEY (from_memory_id) REFERENCES memories (memory_id),
                FOREIGN KEY (to_memory_id) REFERENCES memories (memory_id)
            )
        ''')
        
        # טבלת אשכולות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_clusters (
                cluster_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                description TEXT,
                cluster_type TEXT NOT NULL,
                cohesion_score REAL DEFAULT 0.0,
                created_at TIMESTAMP NOT NULL,
                last_updated TIMESTAMP NOT NULL,
                memory_ids TEXT,  -- JSON array
                central_themes TEXT,  -- JSON array
                key_insights TEXT,  -- JSON array
                behavioral_implications TEXT,  -- JSON array
                emotional_signature TEXT  -- JSON object
            )
        ''')
        
        # טבלת סטטיסטיקות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_statistics (
                stat_date DATE PRIMARY KEY,
                total_memories INTEGER,
                active_memories INTEGER,
                dormant_memories INTEGER,
                archived_memories INTEGER,
                total_clusters INTEGER,
                average_strength REAL,
                total_access_count INTEGER,
                memory_usage_mb REAL,
                learning_insights_count INTEGER
            )
        ''')
        
        # אינדקסים לביצועים
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_type ON memories (memory_type)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_priority ON memories (priority)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_status ON memories (status)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_created ON memories (created_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_accessed ON memories (last_accessed)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_fragments_memory ON memory_fragments (memory_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_associations_from ON memory_associations (from_memory_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_associations_to ON memory_associations (to_memory_id)')
        
        conn.commit()
        
        # טעינת נתונים קיימים
        self._load_existing_memories()
        
        return conn
    
    def _start_background_engine(self):
        """הפעלת מנוע רקע אסינכרוני"""
        def run_background():
            """פונקציה להרצת לולאת אירועים ברקע"""
            self.event_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.event_loop)
            
            # הוספת משימות רקע
            self.event_loop.create_task(self._background_optimization_loop())
            self.event_loop.create_task(self._background_learning_loop())
            self.event_loop.create_task(self._background_cleanup_loop())
            
            try:
                self.event_loop.run_forever()
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת רקע: {e}")
        
        self.background_thread = threading.Thread(target=run_background, daemon=True)
        self.background_thread.start()
    
    async def _background_optimization_loop(self):
        """לולאת אופטימיזציה ברקע"""
        while True:
            try:
                await asyncio.sleep(self.config.optimization_interval)
                await self._optimize_memory_structure()
                await self._update_memory_clusters()
                await self._decay_unused_memories()
                
            except Exception as e:
                self.logger.error(f"שגיאה באופטימיזציה: {e}")
    
    async def _background_learning_loop(self):
        """לולאת למידה ברקע"""
        while True:
            try:
                await asyncio.sleep(self.config.learning_interval)
                await self._analyze_usage_patterns()
                await self._generate_behavioral_insights()
                await self._update_predictive_models()
                
            except Exception as e:
                self.logger.error(f"שגיאה בלמידה: {e}")
    
    async def _background_cleanup_loop(self):
        """לולאת ניקוי ברקע"""
        while True:
            try:
                await asyncio.sleep(self.config.cleanup_interval)
                await self._cleanup_expired_memories()
                await self._compress_old_data()
                await self._backup_critical_memories()
                
            except Exception as e:
                self.logger.error(f"שגיאה בניקוי: {e}")
    
    def store_memory(self, content: Any, context: MemoryContext,
                    memory_type: MemoryType = MemoryType.EXPERIENTIAL,
                    priority: MemoryPriority = MemoryPriority.MEDIUM,
                    source: str = "manual") -> str:
        """שמירת זיכרון חדש"""
        
        memory_id = str(uuid.uuid4())
        timestamp = datetime.now()
        
        # יצירת פרגמנט תוכן
        fragment = MemoryFragment(
            id=str(uuid.uuid4()),
            content=content,
            content_type=self._detect_content_type(content),
            encoding="utf-8",
            timestamp=timestamp,
            source=source,
            confidence=1.0,
            relevance=1.0
        )
        
        # יצירת זיכרון
        memory = RuntimeMemory(
            memory_id=memory_id,
            memory_type=memory_type,
            priority=priority,
            status=MemoryStatus.ACTIVE,
            scope=MemoryScope.PERSONAL,
            fragments=[fragment],
            context=context,
            created_at=timestamp,
            last_accessed=timestamp,
            last_modified=timestamp
        )
        
        # שמירה לזיכרון פעיל
        self.active_memories[memory_id] = memory
        
        # עדכון אינדקס
        self.memory_index.add_memory(memory)
        
        # שמירה למסד נתונים
        self._save_memory_to_db(memory)
        
        # זיהוי קשרים אוטומטי
        self._auto_create_associations(memory)
        
        # הפעלת אירועים
        self._trigger_event('memory_stored', memory)
        
        # עדכון סטטיסטיקות
        self._update_statistics()
        
        self.logger.info(f"זיכרון חדש נשמר: {memory_id} (סוג: {memory_type.value})")
        return memory_id
    
    def retrieve_memory(self, memory_id: str) -> Optional[RuntimeMemory]:
        """שליפת זיכרון לפי מזהה"""
        
        # בדיקה במטמון
        if memory_id in self.memory_cache:
            self.cache_hits += 1
            memory = self.memory_cache[memory_id]
            memory.access()
            return memory
        
        self.cache_misses += 1
        
        # בדיקה בזיכרון פעיל
        if memory_id in self.active_memories:
            memory = self.active_memories[memory_id]
            memory.access()
            
            # שמירה במטמון
            self.memory_cache[memory_id] = memory
            return memory
        
        # בדיקה בזיכרון רדום
        if memory_id in self.dormant_memories:
            memory = self.dormant_memories[memory_id]
            memory.access()
            
            # העברה לזיכרון פעיל אם נגש אליו
            self._activate_memory(memory)
            return memory
        
        # בדיקה בארכיון
        if memory_id in self.archived_memories:
            memory = self._load_memory_from_archive(memory_id)
            if memory:
                memory.access()
                self._activate_memory(memory)
                return memory
        
        # חיפוש במסד נתונים
        memory = self._load_memory_from_db(memory_id)
        if memory:
            memory.access()
            self.active_memories[memory_id] = memory
            self.memory_index.add_memory(memory)
            return memory
        
        return None
    
    def search_memories(self, query: str = None,
                       memory_type: MemoryType = None,
                       priority: MemoryPriority = None,
                       date_range: Tuple[datetime, datetime] = None,
                       participant: str = None,
                       emotional_range: str = None,
                       max_results: int = 50) -> List[RuntimeMemory]:
        """חיפוש זיכרונות מתקדם"""
        
        candidate_ids = set()
        
        # חיפוש לפי שאילתה טקסטואלית
        if query:
            keywords = query.lower().split()
            keyword_results = self.memory_index.search_by_keywords(keywords)
            if not candidate_ids:
                candidate_ids = keyword_results
            else:
                candidate_ids &= keyword_results
        
        # סינון לפי סוג זיכרון
        if memory_type:
            type_results = self.memory_index.type_index[memory_type]
            if not candidate_ids:
                candidate_ids = type_results
            else:
                candidate_ids &= type_results
        
        # סינון לפי עדיפות
        if priority:
            priority_results = self.memory_index.priority_index[priority]
            if not candidate_ids:
                candidate_ids = priority_results
            else:
                candidate_ids &= priority_results
        
        # סינון לפי טווח זמן
        if date_range:
            temporal_results = self.memory_index.search_by_timeframe(date_range[0], date_range[1])
            if not candidate_ids:
                candidate_ids = temporal_results
            else:
                candidate_ids &= temporal_results
        
        # סינון לפי משתתף
        if participant:
            participant_results = self.memory_index.participant_index[participant]
            if not candidate_ids:
                candidate_ids = participant_results
            else:
                candidate_ids &= participant_results
        
        # סינון לפי טווח רגשי
        if emotional_range:
            emotional_results = self.memory_index.emotional_index[emotional_range]
            if not candidate_ids:
                candidate_ids = emotional_results
            else:
                candidate_ids &= emotional_results
        
        # אם אין קריטריונים - החזר הכל
        if not candidate_ids and not any([query, memory_type, priority, date_range, participant, emotional_range]):
            candidate_ids = set(self.active_memories.keys()) | set(self.dormant_memories.keys())
        
        # שליפת זיכרונות וחישוב רלוונטיות
        memories_with_scores = []
        
        for memory_id in candidate_ids:
            memory = self.retrieve_memory(memory_id)
            if memory:
                # חישוב ניקוד רלוונטיות
                context = {'query': query} if query else {}
                relevance_score = memory.get_relevance_score(context)
                memories_with_scores.append((memory, relevance_score))
        
        # מיון לפי רלוונטיות
        memories_with_scores.sort(key=lambda x: x[1], reverse=True)
        
        # החזרת התוצאות
        results = [memory for memory, _ in memories_with_scores[:max_results]]
        
        self.logger.info(f"חיפוש זיכרונות החזיר {len(results)} תוצאות")
        return results
    
    def get_related_memories(self, memory_id: str, max_depth: int = 2) -> List[RuntimeMemory]:
        """קבלת זיכרונות קשורים"""
        related_ids = self.memory_index.get_related_memories(memory_id, max_depth)
        
        related_memories = []
        for related_id in related_ids:
            memory = self.retrieve_memory(related_id)
            if memory:
                related_memories.append(memory)
        
        return related_memories
    
    def create_memory_cluster(self, memory_ids: List[str], 
                            cluster_name: str,
                            cluster_type: str = "thematic") -> str:
        """יצירת אשכול זיכרונות"""
        
        cluster_id = str(uuid.uuid4())
        
        cluster = MemoryCluster(
            cluster_id=cluster_id,
            name=cluster_name,
            hebrew_name=cluster_name,
            description=f"אשכול זיכרונות: {cluster_name}",
            memory_ids=set(memory_ids),
            cluster_type=cluster_type,
            cohesion_score=0.0,
            created_at=datetime.now(),
            last_updated=datetime.now()
        )
        
        # חישוב לכידות
        cluster.calculate_cohesion(self.active_memories)
        
        # ניתוח נושאים מרכזיים
        self._analyze_cluster_themes(cluster)
        
        self.memory_clusters[cluster_id] = cluster
        
        # שמירה למסד נתונים
        self._save_cluster_to_db(cluster)
        
        self.logger.info(f"אשכול זיכרונות נוצר: {cluster_name} ({len(memory_ids)} זיכרונות)")
        return cluster_id
    
    def add_memory_association(self, from_memory_id: str, to_memory_id: str,
                             association_type: str, strength: float):
        """הוספת קשר בין זיכרונות"""
        
        from_memory = self.retrieve_memory(from_memory_id)
        to_memory = self.retrieve_memory(to_memory_id)
        
        if not from_memory or not to_memory:
            self.logger.warning(f"לא ניתן ליצור קשר בין זיכרונות לא קיימים")
            return False
        
        # יצירת קשר
        from_memory.add_association(to_memory_id, association_type, strength)
        
        # עדכון אינדקס
        self.memory_index.association_graph[from_memory_id].add(to_memory_id)
        self.memory_index.association_graph[to_memory_id].add(from_memory_id)
        
        # שמירה למסד נתונים
        self._save_association_to_db(from_memory_id, to_memory_id, association_type, strength)
        
        self.logger.info(f"קשר נוצר: {from_memory_id} -> {to_memory_id} ({association_type})")
        return True
    
    def get_memory_insights(self, memory_id: str = None) -> List[str]:
        """קבלת תובנות על זיכרון או על כל המערכת"""
        
        insights = []
        
        if memory_id:
            # תובנות על זיכרון ספציפי
            memory = self.retrieve_memory(memory_id)
            if memory:
                insights.extend(memory.derived_insights)
                
                # תובנות על קשרים
                related_count = len(memory.related_memories)
                if related_count > 10:
                    insights.append(f"זיכרון זה קשור ל-{related_count} זיכרונות אחרים - חשיבות גבוהה")
                
                # תובנות על תדירות גישה
                if memory.access_count > 50:
                    insights.append("זיכרון נגיש בתדירות גבוהה - מידע חשוב")
        
        else:
            # תובנות כלליות על המערכת
            insights.extend(self.behavioral_insights)
            
            # סטטיסטיקות כלליות
            total_memories = len(self.active_memories) + len(self.dormant_memories)
            insights.append(f"המערכת מכילה {total_memories} זיכרונות פעילים")
            
            # ניתוח מגמות
            recent_memories = [m for m in self.active_memories.values() 
                             if (datetime.now() - m.created_at).days <= 7]
            
            if recent_memories:
                insights.append(f"נוצרו {len(recent_memories)} זיכרונות חדשים השבוע")
        
        return insights
    
    def optimize_memory_system(self):
        """אופטימיזציה ידנית של מערכת הזיכרון"""
        
        self.logger.info("מתחיל אופטימיזציה ידנית של מערכת הזיכרון")
        
        # העברת זיכרונות ישנים לרדום
        self._move_old_memories_to_dormant()
        
        # ארכיון זיכרונות לא חשובים
        self._archive_unimportant_memories()
        
        # עדכון אשכולות
        self._update_all_clusters()
        
        # ניקוי מטמון
        self._cleanup_cache()
        
        # דחיסת נתונים
        self._compress_data()
        
        # עדכון אינדקס
        self._rebuild_index()
        
        self.memory_stats['last_optimization'] = datetime.now()
        
        self.logger.info("אופטימיזציה הושלמה בהצלחה")
    
    def export_memories(self, file_path: str, format: str = "json",
                       memory_ids: List[str] = None):
        """ייצוא זיכרונות לקובץ"""
        
        if memory_ids:
            memories_to_export = [self.retrieve_memory(mid) for mid in memory_ids]
            memories_to_export = [m for m in memories_to_export if m]
        else:
            memories_to_export = list(self.active_memories.values())
        
        if format == "json":
            data = {
                'export_date': datetime.now().isoformat(),
                'total_memories': len(memories_to_export),
                'memories': [memory.to_dict() for memory in memories_to_export]
            }
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        
        elif format == "pickle":
            with open(file_path, 'wb') as f:
                pickle.dump(memories_to_export, f)
        
        self.logger.info(f"ייצוא {len(memories_to_export)} זיכרונות לקובץ: {file_path}")
    
    def import_memories(self, file_path: str, format: str = "json"):
        """ייבוא זיכרונות מקובץ"""
        
        imported_count = 0
        
        try:
            if format == "json":
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for memory_data in data.get('memories', []):
                    memory = self._dict_to_memory(memory_data)
                    if memory:
                        self.active_memories[memory.memory_id] = memory
                        self.memory_index.add_memory(memory)
                        self._save_memory_to_db(memory)
                        imported_count += 1
            
            elif format == "pickle":
                with open(file_path, 'rb') as f:
                    memories = pickle.load(f)
                
                for memory in memories:
                    self.active_memories[memory.memory_id] = memory
                    self.memory_index.add_memory(memory)
                    self._save_memory_to_db(memory)
                    imported_count += 1
        
        except Exception as e:
            self.logger.error(f"שגיאה בייבוא זיכרונות: {e}")
            return 0
        
        self.logger.info(f"יובאו {imported_count} זיכרונות מקובץ: {file_path}")
        return imported_count
    
    def get_system_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות מערכת מפורטות"""
        
        stats = self.memory_stats.copy()
        
        # עדכון סטטיסטיקות נוכחיות
        stats.update({
            'active_memories': len(self.active_memories),
            'dormant_memories': len(self.dormant_memories),
            'archived_memories': len(self.archived_memories),
            'total_clusters': len(self.memory_clusters),
            'cache_hit_rate': self.cache_hits / (self.cache_hits + self.cache_misses) if (self.cache_hits + self.cache_misses) > 0 else 0,
            'memory_usage_mb': self._calculate_memory_usage(),
            'average_strength': self._calculate_average_strength(),
            'most_accessed_memory': self._get_most_accessed_memory(),
            'learning_patterns_count': len(self.learning_patterns),
            'behavioral_insights_count': len(self.behavioral_insights)
        })
        
        return stats
    
    # פונקציות עזר פרטיות
    
    def _detect_content_type(self, content: Any) -> str:
        """זיהוי סוג תוכן"""
        if isinstance(content, str):
            return "text"
        elif isinstance(content, bytes):
            return "binary"
        elif isinstance(content, dict):
            return "json"
        elif isinstance(content, list):
            return "array"
        elif isinstance(content, (int, float)):
            return "number"
        else:
            return "object"
    
    def _auto_create_associations(self, memory: RuntimeMemory):
        """יצירת קשרים אוטומטית"""
        # חיפוש זיכרונות דומים
        similar_memories = self.search_memories(
            query=str(memory.fragments[0].content)[:100] if memory.fragments else "",
            memory_type=memory.memory_type,
            max_results=5
        )
        
        for similar_memory in similar_memories:
            if similar_memory.memory_id != memory.memory_id:
                # חישוב חוזק קשר על בסיס דמיון
                similarity = self._calculate_memory_similarity(memory, similar_memory)
                
                if similarity > 0.3:  # סף דמיון
                    memory.add_association(
                        similar_memory.memory_id,
                        "semantic",
                        similarity
                    )
    
    def _calculate_memory_similarity(self, memory1: RuntimeMemory, memory2: RuntimeMemory) -> float:
        """חישוב דמיון בין זיכרונות"""
        # דמיון בסיסי על בסיס מילות מפתח
        keywords1 = memory1.extract_keywords()
        keywords2 = memory2.extract_keywords()
        
        if not keywords1 or not keywords2:
            return 0.0
        
        intersection = keywords1.intersection(keywords2)
        union = keywords1.union(keywords2)
        
        jaccard_similarity = len(intersection) / len(union) if union else 0.0
        
        # התאמת דמיון על בסיס סוג זיכרון
        type_bonus = 0.1 if memory1.memory_type == memory2.memory_type else 0.0
        
        # התאמת דמיון על בסיס זמן
        time_diff = abs((memory1.created_at - memory2.created_at).total_seconds())
        time_similarity = max(0, 1.0 - (time_diff / (7 * 24 * 3600)))  # שבוע
        
        return min(1.0, jaccard_similarity + type_bonus + (time_similarity * 0.1))
    
    def _save_memory_to_db(self, memory: RuntimeMemory):
        """שמירת זיכרון למסד נתונים"""
        # דחיסת נתונים
        memory_data = json.dumps(memory.to_dict(), ensure_ascii=False)
        compressed_data = gzip.compress(memory_data.encode('utf-8'))
        checksum = hashlib.md5(compressed_data).hexdigest()
        
        cursor = self.db_connection.cursor()
        
        # שמירת זיכרון ראשי
        cursor.execute('''
            INSERT OR REPLACE INTO memories (
                memory_id, memory_type, priority, status, scope,
                created_at, last_accessed, last_modified,
                access_count, modification_count, strength, decay_rate,
                predictive_value, is_protected, encryption_level,
                data_compressed, checksum
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            memory.memory_id, memory.memory_type.value, memory.priority.value,
            memory.status.value, memory.scope.value, memory.created_at,
            memory.last_accessed, memory.last_modified, memory.access_count,
            memory.modification_count, memory.strength, memory.decay_rate,
            memory.predictive_value, memory.is_protected, memory.encryption_level,
            compressed_data, checksum
        ))
        
        # שמירת הקשר
        cursor.execute('''
            INSERT OR REPLACE INTO memory_contexts (
                context_id, name, hebrew_name, description, participants,
                environment, temporal_start, temporal_end, spatial_bounds,
                emotional_tone, importance, tags
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            memory.context.context_id, memory.context.name, memory.context.hebrew_name,
            memory.context.description, json.dumps(memory.context.participants),
            json.dumps(memory.context.environment), memory.context.temporal_bounds[0],
            memory.context.temporal_bounds[1], json.dumps(memory.context.spatial_bounds),
            memory.context.emotional_tone, memory.context.importance,
            json.dumps(list(memory.context.tags))
        ))
        
        self.db_connection.commit()
    
    def _load_memory_from_db(self, memory_id: str) -> Optional[RuntimeMemory]:
        """טעינת זיכרון ממסד נתונים"""
        cursor = self.db_connection.cursor()
        cursor.execute('SELECT data_compressed FROM memories WHERE memory_id = ?', (memory_id,))
        
        result = cursor.fetchone()
        if result:
            try:
                compressed_data = result[0]
                memory_data = gzip.decompress(compressed_data).decode('utf-8')
                memory_dict = json.loads(memory_data)
                return self._dict_to_memory(memory_dict)
            except Exception as e:
                self.logger.error(f"שגיאה בטעינת זיכרון {memory_id}: {e}")
        
        return None
    
    async def _optimize_memory_structure(self):
        """אופטימיזציה מתקדמת של מבנה הזיכרון"""
        # העברת זיכרונות ישנים לרדום
        cutoff_date = datetime.now() - timedelta(days=self.config.dormant_threshold_days)
        
        memories_to_move = []
        for memory_id, memory in self.active_memories.items():
            if (memory.last_accessed < cutoff_date and 
                memory.priority not in [MemoryPriority.CRITICAL, MemoryPriority.VERY_HIGH]):
                memories_to_move.append(memory_id)
        
        for memory_id in memories_to_move:
            memory = self.active_memories.pop(memory_id)
            memory.status = MemoryStatus.DORMANT
            self.dormant_memories[memory_id] = memory
        
        if memories_to_move:
            self.logger.info(f"הועברו {len(memories_to_move)} זיכרונות למצב רדום")
    
    async def _analyze_usage_patterns(self):
        """ניתוח דפוסי שימוש"""
        # ניתוח זמני גישה
        access_times = []
        for memory in self.active_memories.values():
            if memory.access_count > 0:
                access_times.append(memory.last_accessed.hour)
        
        if access_times:
            peak_hour = max(set(access_times), key=access_times.count)
            self.learning_patterns['peak_usage_hour'] = peak_hour
    
    def _trigger_event(self, event_type: str, data: Any):
        """הפעלת אירוע"""
        if event_type in self.event_handlers:
            for handler in self.event_handlers[event_type]:
                try:
                    handler(data)
                except Exception as e:
                    self.logger.error(f"שגיאה במטפל אירוע {event_type}: {e}")
    
    def _update_statistics(self):
        """עדכון סטטיסטיקות"""
        self.memory_stats.update({
            'total_memories': len(self.active_memories) + len(self.dormant_memories) + len(self.archived_memories),
            'active_memories': len(self.active_memories),
            'dormant_memories': len(self.dormant_memories),
            'archived_memories': len(self.archived_memories),
            'total_clusters': len(self.memory_clusters),
            'memory_usage_mb': self._calculate_memory_usage()
        })
    
    def _calculate_memory_usage(self) -> float:
        """חישוב צריכת זיכרון במגהבייט"""
        total_size = 0
        
        # חישוב גודל זיכרונות פעילים
        for memory in self.active_memories.values():
            memory_size = len(str(memory.to_dict()).encode('utf-8'))
            total_size += memory_size
        
        return total_size / (1024 * 1024)  # המרה למגהבייט
    
    def close(self):
        """סגירת המנוע"""
        self.logger.info("סוגר מנוע זיכרון זמן אמת...")
        
        # עצירת לולאת רקע
        if self.event_loop and not self.event_loop.is_closed():
            self.event_loop.call_soon_threadsafe(self.event_loop.stop)
        
        # שמירת כל הזיכרונות
        for memory in self.active_memories.values():
            self._save_memory_to_db(memory)
        
        # סגירת מסד נתונים
        if self.db_connection:
            self.db_connection.close()
        
        # סגירת executor
        self.executor.shutdown(wait=True)
        
        self.logger.info("מנוע זיכרון זמן אמת נסגר בהצלחה")