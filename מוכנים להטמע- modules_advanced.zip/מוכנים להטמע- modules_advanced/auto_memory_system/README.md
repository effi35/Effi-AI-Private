# מערכת זיכרון אוטומטית - Auto Memory System

מערכת זיכרון חכמה ומתקדמת עם למידה אוטומטית ואופטימיזציה רציפה לבינה מלאכותית פרטית.

## 🎯 תכונות עיקריות

### 🧠 זיכרון חי ורציף
- **RuntimeMemory**: זיכרון פעיל עם חוזק משתנה ודעיכה טבעית
- **MemoryFragments**: פיסות זיכרון עם קשרים דינמיים
- **MemoryContext**: הקשרים חכמים לזיכרונות
- **MemoryIndex**: אינדקסים מהירים לחיפוש וגישה

### ⚡ מנוע זיכרון מתקדם
- **MemoryRuntime**: מנוע זיכרון רציף עם לולאות אופטימיזציה
- **אופטימיזציה אוטומטית**: ניקוי, איחוד ויצירת קשרים חדשים
- **למידה רציפה**: הסתגלות לדפוסי שימוש והתנהגות
- **ביצועים גבוהים**: עיבוד מקבילי ומהיר

### 🎨 ממשק משתמש מתקדם
- **MemoryDashboard**: לוח בקרה מקיף עם גרפים וניטור
- **חיפוש מתקדם**: אפשרויות חיפוש מורכבות ופילטרים
- **ניתוח ויזואלי**: גרפי זיכרון וסטטיסטיקות בזמן אמת
- **ניהול זיכרונות**: עריכה, מחיקה ועדכון זיכרונות

### 🔧 כלים שימושיים
- **MemoryUtils**: חישוב דמיון, hash וחילוץ מילות מפתח
- **MemoryCompressor**: דחיסת זיכרונות לחיסכון במקום
- **MemoryDatabase**: ניהול בסיס נתונים מתקדם עם SQLite
- **MemoryOptimizer**: אלגוריתמי אופטימיזציה חכמים
- **MemoryMonitor**: ניטור ביצועים ושימוש משאבים

## 🏗️ ארכיטקטורה

```
auto_memory_system/
├── models/                 # מבני נתונים וקונפיגורציה
│   ├── runtime_memory.py  # זיכרון זמן ריצה
│   ├── memory_fragment.py # פיסות זיכרון
│   ├── memory_context.py  # הקשרי זיכרון
│   ├── memory_index.py    # אינדקסי זיכרון
│   └── config.py          # הגדרות מערכת
├── core/                   # מנועי ליבה
│   └── memory_runtime.py  # מנוע זיכרון ראשי
├── ui/                     # ממשק משתמש
│   └── memory_dashboard.py # לוח בקרה ראשי
├── utils/                  # כלים שימושיים
│   └── memory_utils.py     # פונקציות עזר
├── module.py              # נקודת כניסה למודול
├── requirements.txt       # תלויות
└── README.md             # תיעוד זה
```

## 🚀 התקנה ושימוש

### דרישות מערכת
```bash
pip install numpy pandas sqlite3 matplotlib psutil
```

### הפעלה בסיסית
```python
from auto_memory_system import AutoMemorySystem

# אתחול המערכת
memory_system = AutoMemorySystem()

# הוספת זיכרון חדש
memory_id = memory_system.add_memory(
    content="זיכרון חשוב למערכת",
    memory_type="knowledge",
    strength=0.8
)

# חיפוש זיכרונות
results = memory_system.search_memories("זיכרון")

# אופטימיזציה ידנית
memory_system.optimize_memories()
```

### הפעלת לוח הבקרה
```python
from auto_memory_system.ui.memory_dashboard import main

# הפעלת ממשק גרפי
main()
```

## 📊 יכולות מתקדמות

### אופטימיזציה אוטומטית
- **זיהוי זיכרונות חלשים**: מחיקה אוטומטית של זיכרונות ישנים
- **מיזוג זיכרונות דומים**: איחוד תוכן דומה לזיכרון משולב
- **יצירת קשרים**: בניית רשת קשרים בין זיכרונות
- **עדכון חוזקים**: התאמה לפי תדירות גישה

### למידה רציפה
- **דפוסי גישה**: זיהוי דפוסי שימוש נפוצים
- **התאמת חוזק**: עדכון אוטומטי לפי חשיבות
- **יצירת אסוציאציות**: קשרים חכמים בין נושאים
- **אופטימיזציה דינמית**: שיפור ביצועים מתמיד

### ניטור וביצועים
- **מעקב שימוש זיכרון**: ניטור צריכת RAM
- **מדידת מהירות**: זמני תגובה ועיבוד
- **סטטיסטיקות מפורטות**: דוחות מקיפים על המערכת
- **התראות חכמות**: הודעות על בעיות ואירועים

## ⚙️ הגדרות מתקדמות

### קובץ config.py
```python
MEMORY_CONFIG = {
    "max_memory_size": 1000,        # מספר זיכרונות מקסימלי
    "default_strength": 0.5,        # חוזק ברירת מחדל
    "decay_rate": 0.01,            # קצב דעיכה יומי
    "optimization_interval": 30,    # דקות בין אופטימיזציות
    "auto_learning": True,          # למידה אוטומטית
    "compression_enabled": True,    # דחיסת זיכרונות
    "backup_interval": 60          # דקות בין גיבויים
}
```

### התאמות ביצועים
```python
PERFORMANCE_CONFIG = {
    "max_cpu_usage": 50,           # שימוש מקסימלי ב-CPU
    "max_memory_mb": 512,          # זיכרון מקסימלי במגה-בייט
    "background_threads": 2,       # מספר תהליכי רקע
    "cache_size": 100,            # גודל מטמון
    "index_update_interval": 10   # דקות בין עדכוני אינדקס
}
```

## 🔍 דוגמאות שימוש

### יצירת זיכרונות מורכבים
```python
# זיכרון עם מטא-דטה
memory_system.add_memory(
    content="מידע טכני חשוב על המערכת",
    memory_type="technical",
    strength=0.9,
    keywords=["טכני", "מערכת", "חשוב"],
    metadata={
        "source": "documentation",
        "category": "system",
        "priority": "high"
    }
)
```

### חיפוש מתקדם
```python
# חיפוש עם פילטרים
results = memory_system.search_memories(
    query="מערכת",
    memory_type="technical",
    min_strength=0.7,
    max_results=10,
    include_similar=True
)
```

### ניטור ביצועים
```python
# קבלת סטטיסטיקות מערכת
stats = memory_system.get_system_stats()
print(f"זיכרונות פעילים: {stats['active_memories']}")
print(f"שימוש זיכרון: {stats['memory_usage_mb']} MB")
print(f"מהירות עיבוד: {stats['processing_speed']} ops/sec")
```

## 🛠️ פיתוח והרחבה

### הוספת סוגי זיכרון חדשים
```python
class CustomMemoryType(RuntimeMemory):
    def __init__(self, content, **kwargs):
        super().__init__(content, memory_type="custom", **kwargs)
        self.custom_property = kwargs.get('custom_property', None)
    
    def process_content(self):
        # עיבוד מותאם אישית
        pass
```

### יצירת אופטימיזציות מותאמות
```python
class CustomOptimizer(MemoryOptimizer):
    def custom_optimization(self):
        # אלגוריתם אופטימיזציה מותאם
        pass
```

## 📈 מדדי ביצועים

### יעדי ביצועים
- **זמן תגובה**: < 50ms לחיפוש בסיסי
- **זמן אופטימיזציה**: < 5 שניות ל-1000 זיכרונות
- **שימוש זיכרון**: < 512MB לזיכרון פעיל
- **דיוק חיפוש**: > 95% עבור תוכן דומה

### בדיקות איכות
```bash
# הרצת בדיקות
python -m pytest tests/

# בדיקת ביצועים
python tests/performance_tests.py

# בדיקת זיכרון
python tests/memory_leak_tests.py
```

## 🔒 אבטחה ופרטיות

### הצפנת נתונים
- **הצפנת תוכן**: AES-256 לתכנים רגישים
- **הגנת גישה**: אימות ויתורים למשתמשים
- **ביקורת**: מעקב אחר כל הפעולות
- **גיבוי מאובטח**: הצפנת קבצי גיבוי

### ניהול הרשאות
```python
SECURITY_CONFIG = {
    "encryption_enabled": True,
    "access_control": True,
    "audit_logging": True,
    "secure_backup": True,
    "data_retention_days": 90
}
```

## 🌐 תמיכה בעברית

המערכת מותאמת במלואה לעבודה עם טקסט עברי:
- **עיבוד טקסט עברי**: ניתוח ועיבוד מתקדם
- **חיפוש בעברית**: תמיכה מלאה בחיפוש עברי
- **ממשק בעברית**: כל הממשקים בעברית
- **RTL**: תמיכה בכיוון כתיבה מימין לשמאל

## 📞 תמיכה ועזרה

### קבלת עזרה
- **תיעוד מפורט**: ב-`docs/` directory
- **דוגמאות**: ב-`examples/` directory  
- **FAQ**: שאלות נפוצות ותשובות
- **Community**: פורום מפתחים

### פתרון בעיות נפוצות
1. **זיכרון גבוה**: הגדל את `max_memory_mb`
2. **ביצועים איטיים**: הפעל אופטימיזציה
3. **שגיאות חיפוש**: בדוק אינדקסים
4. **קבצים פגומים**: שחזר מגיבוי

## 🔄 עדכונים ושדרוגים

### מהדורה נוכחית: v1.0.0
- יכולות זיכרון מלאות
- ממשק משתמש גרפי
- אופטימיזציה אוטומטית
- תמיכה מלאה בעברית

### תכונות מתוכננות v1.1.0
- שילוב עם מודולים נוספים
- AI למידה מתקדמת
- ממשק Web
- תמיכה במבני נתונים נוספים

---

**מערכת זיכרון אוטומטית** - פותח במסגרת **Effi AI Private System**  
© 2024 Effi AI Systems - כל הזכויות שמורות  

זיכרון חי לבינה מלאכותית מתקדמת 🧠✨