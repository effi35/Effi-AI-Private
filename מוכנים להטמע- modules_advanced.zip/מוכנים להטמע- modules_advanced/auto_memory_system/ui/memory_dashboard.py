"""
מסך ניהול זיכרון אוטומטי - לוח בקרה מרכזי
ממשק משתמש מתקדם לניהול מערכת הזיכרון החי
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

class MemoryDashboard:
    """לוח בקרה מתקדם למערכת הזיכרון האוטומטית"""
    
    def __init__(self, memory_engine=None):
        self.memory_engine = memory_engine
        self.root = None
        self.running = False
        self.update_thread = None
        
        # רכיבי UI
        self.memory_tree = None
        self.stats_labels = {}
        self.memory_graph = None
        self.log_text = None
        
        # נתונים לתצוגה
        self.memory_stats = {}
        self.memory_timeline = []
        self.search_results = []
        
    def create_ui(self):
        """יצירת ממשק המשתמש הראשי"""
        self.root = tk.Tk()
        self.root.title("מערכת זיכרון אוטומטית - לוח בקרה")
        self.root.geometry("1400x900")
        self.root.configure(bg='#2b2b2b')
        
        # יצירת תפריט עליון
        self._create_menu()
        
        # יצירת פריים ראשי
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # חלוקה לשלושה חלקים
        self._create_control_panel(main_frame)
        self._create_memory_view(main_frame)
        self._create_analytics_panel(main_frame)
        
        # התחלת עדכון אוטומטי
        self.start_auto_update()
        
        return self.root
    
    def _create_menu(self):
        """יצירת תפריט עליון"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # תפריט זיכרון
        memory_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="זיכרון", menu=memory_menu)
        memory_menu.add_command(label="חיפוש מתקדם", command=self.open_advanced_search)
        memory_menu.add_command(label="ייצוא זיכרון", command=self.export_memory)
        memory_menu.add_command(label="ייבוא זיכרון", command=self.import_memory)
        memory_menu.add_separator()
        memory_menu.add_command(label="אופטימיזציה ידנית", command=self.manual_optimization)
        
        # תפריט הגדרות
        settings_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="הגדרות", menu=settings_menu)
        settings_menu.add_command(label="הגדרות זיכרון", command=self.open_memory_settings)
        settings_menu.add_command(label="הגדרות אופטימיזציה", command=self.open_optimization_settings)
        
        # תפריט עזרה
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="עזרה", menu=help_menu)
        help_menu.add_command(label="מדריך שימוש", command=self.show_help)
        help_menu.add_command(label="אודות", command=self.show_about)
    
    def _create_control_panel(self, parent):
        """יצירת פאנל בקרה עליון"""
        control_frame = ttk.LabelFrame(parent, text="בקרת מערכת", padding=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # שורה ראשונה - כפתורי בקרה
        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        # כפתורי בקרה
        ttk.Button(button_frame, text="הפעל זיכרון", 
                  command=self.start_memory_system).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="עצור זיכרון", 
                  command=self.stop_memory_system).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="רענן", 
                  command=self.refresh_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="נקה זיכרון", 
                  command=self.clear_memory).pack(side=tk.LEFT, padx=5)
        
        # סטטיסטיקות מהירות
        stats_frame = ttk.Frame(control_frame)
        stats_frame.pack(fill=tk.X)
        
        self._create_quick_stats(stats_frame)
    
    def _create_quick_stats(self, parent):
        """יצירת סטטיסטיקות מהירות"""
        stats = [
            ("זיכרונות פעילים", "active_memories", "0"),
            ("חוזק ממוצע", "avg_strength", "0.0"),
            ("אופטימיזציות היום", "optimizations_today", "0"),
            ("זמן פעילות", "uptime", "00:00:00"),
            ("שימוש זיכרון", "memory_usage", "0 MB"),
            ("מהירות עיבוד", "processing_speed", "0 ops/sec")
        ]
        
        for i, (label, key, default) in enumerate(stats):
            frame = ttk.Frame(parent)
            frame.grid(row=i//3, column=i%3, padx=10, pady=5, sticky=tk.W)
            
            ttk.Label(frame, text=f"{label}:", font=('Arial', 9, 'bold')).pack(anchor=tk.W)
            stat_label = ttk.Label(frame, text=default, font=('Arial', 12))
            stat_label.pack(anchor=tk.W)
            self.stats_labels[key] = stat_label
    
    def _create_memory_view(self, parent):
        """יצירת תצוגת זיכרונות"""
        memory_frame = ttk.LabelFrame(parent, text="תצוגת זיכרונות", padding=10)
        memory_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # פאנל חיפוש
        search_frame = ttk.Frame(memory_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(search_frame, text="חיפוש:").pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        search_entry.pack(side=tk.LEFT, padx=(0, 5))
        search_entry.bind('<KeyRelease>', self.on_search_change)
        
        ttk.Button(search_frame, text="חיפוש מתקדם", 
                  command=self.open_advanced_search).pack(side=tk.LEFT, padx=5)
        
        # טבלת זיכרונות
        columns = ('id', 'type', 'content', 'strength', 'created', 'accessed')
        self.memory_tree = ttk.Treeview(memory_frame, columns=columns, show='headings', height=15)
        
        # הגדרת כותרות
        headers = {
            'id': 'מזהה',
            'type': 'סוג',
            'content': 'תוכן',
            'strength': 'חוזק',
            'created': 'נוצר',
            'accessed': 'נגש'
        }
        
        for col, header in headers.items():
            self.memory_tree.heading(col, text=header, anchor=tk.CENTER)
            self.memory_tree.column(col, width=120, anchor=tk.CENTER)
        
        # רוחב מיוחד לתוכן
        self.memory_tree.column('content', width=300)
        
        # סרגל גלילה
        scrollbar = ttk.Scrollbar(memory_frame, orient=tk.VERTICAL, command=self.memory_tree.yview)
        self.memory_tree.configure(yscrollcommand=scrollbar.set)
        
        self.memory_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # אירועים
        self.memory_tree.bind('<Double-1>', self.on_memory_double_click)
        self.memory_tree.bind('<Button-3>', self.on_memory_right_click)
    
    def _create_analytics_panel(self, parent):
        """יצירת פאנל אנליטיקה"""
        analytics_frame = ttk.LabelFrame(parent, text="אנליטיקה וגרפים", padding=10)
        analytics_frame.pack(fill=tk.X)
        
        # נוטבוק לטאבים
        notebook = ttk.Notebook(analytics_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב גרף זיכרון
        graph_frame = ttk.Frame(notebook)
        notebook.add(graph_frame, text="גרף זיכרון")
        self._create_memory_graph(graph_frame)
        
        # טאב לוגים
        log_frame = ttk.Frame(notebook)
        notebook.add(log_frame, text="לוגים")
        self._create_log_view(log_frame)
        
        # טאב הגדרות
        settings_frame = ttk.Frame(notebook)
        notebook.add(settings_frame, text="הגדרות")
        self._create_settings_view(settings_frame)
    
    def _create_memory_graph(self, parent):
        """יצירת גרף זיכרון"""
        # יצירת גרף matplotlib
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6))
        fig.patch.set_facecolor('#2b2b2b')
        
        # גרף חוזק זיכרון לאורך זמן
        ax1.set_title('חוזק זיכרון לאורך זמן', color='white')
        ax1.set_facecolor('#3b3b3b')
        ax1.tick_params(colors='white')
        
        # גרף סוגי זיכרון
        ax2.set_title('התפלגות סוגי זיכרון', color='white')
        ax2.set_facecolor('#3b3b3b')
        ax2.tick_params(colors='white')
        
        # הטמעה ב-Tkinter
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.memory_graph = (fig, ax1, ax2, canvas)
    
    def _create_log_view(self, parent):
        """יצירת תצוגת לוגים"""
        log_frame = ttk.Frame(parent)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # כפתורי בקרת לוגים
        button_frame = ttk.Frame(log_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(button_frame, text="נקה לוגים", 
                  command=self.clear_logs).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="שמור לוגים", 
                  command=self.save_logs).pack(side=tk.LEFT, padx=5)
        
        # רמת לוג
        ttk.Label(button_frame, text="רמת לוג:").pack(side=tk.LEFT, padx=(20, 5))
        self.log_level_var = tk.StringVar(value="INFO")
        log_level_combo = ttk.Combobox(button_frame, textvariable=self.log_level_var,
                                      values=["DEBUG", "INFO", "WARNING", "ERROR"],
                                      state="readonly", width=10)
        log_level_combo.pack(side=tk.LEFT, padx=5)
        log_level_combo.bind('<<ComboboxSelected>>', self.on_log_level_change)
        
        # תיבת טקסט ללוגים
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, width=80,
                                                 bg='#1e1e1e', fg='#ffffff',
                                                 font=('Consolas', 10))
        self.log_text.pack(fill=tk.BOTH, expand=True)
    
    def _create_settings_view(self, parent):
        """יצירת תצוגת הגדרות"""
        settings_frame = ttk.Frame(parent)
        settings_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # הגדרות זיכרון
        memory_group = ttk.LabelFrame(settings_frame, text="הגדרות זיכרון", padding=10)
        memory_group.pack(fill=tk.X, pady=(0, 10))
        
        # גודל זיכרון מקסימלי
        ttk.Label(memory_group, text="גודל זיכרון מקסימלי (MB):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.max_memory_var = tk.StringVar(value="1024")
        ttk.Entry(memory_group, textvariable=self.max_memory_var, width=10).grid(row=0, column=1, padx=10, pady=5)
        
        # זמן דעיכה
        ttk.Label(memory_group, text="זמן דעיכה (שעות):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.decay_time_var = tk.StringVar(value="24")
        ttk.Entry(memory_group, textvariable=self.decay_time_var, width=10).grid(row=1, column=1, padx=10, pady=5)
        
        # הגדרות אופטימיזציה
        opt_group = ttk.LabelFrame(settings_frame, text="הגדרות אופטימיזציה", padding=10)
        opt_group.pack(fill=tk.X, pady=(0, 10))
        
        # תדירות אופטימיזציה
        ttk.Label(opt_group, text="תדירות אופטימיזציה (דקות):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.opt_frequency_var = tk.StringVar(value="30")
        ttk.Entry(opt_group, textvariable=self.opt_frequency_var, width=10).grid(row=0, column=1, padx=10, pady=5)
        
        # אופטימיזציה אוטומטית
        self.auto_opt_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(opt_group, text="אופטימיזציה אוטומטית", 
                       variable=self.auto_opt_var).grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        # כפתור שמירה
        ttk.Button(settings_frame, text="שמור הגדרות", 
                  command=self.save_settings).pack(pady=20)
    
    # ========== פונקציות עדכון נתונים ==========
    
    def start_auto_update(self):
        """התחלת עדכון אוטומטי של הנתונים"""
        self.running = True
        self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
        self.update_thread.start()
    
    def _update_loop(self):
        """לולאת עדכון רציפה"""
        while self.running:
            try:
                self.root.after(0, self.update_display)
                threading.Event().wait(2)  # עדכון כל 2 שניות
            except Exception as e:
                self.log_message(f"שגיאה בעדכון: {e}", "ERROR")
    
    def update_display(self):
        """עדכון תצוגת הנתונים"""
        if not self.memory_engine:
            return
            
        try:
            # עדכון סטטיסטיקות
            self._update_stats()
            
            # עדכון טבלת זיכרונות
            self._update_memory_table()
            
            # עדכון גרפים
            self._update_graphs()
            
        except Exception as e:
            self.log_message(f"שגיאה בעדכון תצוגה: {e}", "ERROR")
    
    def _update_stats(self):
        """עדכון סטטיסטיקות מהירות"""
        if not self.memory_engine:
            return
            
        # סימולציה של נתונים (יש להחליף בנתונים אמיתיים)
        stats = {
            'active_memories': len(getattr(self.memory_engine, 'active_memories', [])),
            'avg_strength': "0.75",
            'optimizations_today': "12",
            'uptime': self._calculate_uptime(),
            'memory_usage': "256 MB",
            'processing_speed': "150 ops/sec"
        }
        
        for key, value in stats.items():
            if key in self.stats_labels:
                self.stats_labels[key].config(text=str(value))
    
    def _update_memory_table(self):
        """עדכון טבלת הזיכרונות"""
        # ניקוי הטבלה הקיימת
        for item in self.memory_tree.get_children():
            self.memory_tree.delete(item)
        
        # הוספת זיכרונות חדשים (סימולציה)
        sample_memories = [
            ("mem_001", "משימה", "תזכורת לפגישה חשובה", "0.95", "2024-01-15 10:30", "2024-01-15 14:20"),
            ("mem_002", "ידע", "מידע על פרויקט חדש", "0.87", "2024-01-15 09:15", "2024-01-15 14:18"),
            ("mem_003", "רגש", "תחושה חיובית מהצלחה", "0.92", "2024-01-15 11:45", "2024-01-15 14:15"),
        ]
        
        for memory in sample_memories:
            self.memory_tree.insert('', 'end', values=memory)
    
    def _update_graphs(self):
        """עדכון הגרפים"""
        if not self.memory_graph:
            return
            
        fig, ax1, ax2, canvas = self.memory_graph
        
        # נתונים לדוגמא
        times = np.linspace(0, 24, 100)
        strengths = 0.8 + 0.2 * np.sin(times / 4) * np.exp(-times / 24)
        
        ax1.clear()
        ax1.plot(times, strengths, color='#4CAF50', linewidth=2)
        ax1.set_title('חוזק זיכרון לאורך זמן', color='white')
        ax1.set_xlabel('זמן (שעות)', color='white')
        ax1.set_ylabel('חוזק זיכרון', color='white')
        ax1.set_facecolor('#3b3b3b')
        ax1.tick_params(colors='white')
        
        # גרף עוגה
        ax2.clear()
        sizes = [30, 25, 20, 15, 10]
        labels = ['משימות', 'ידע', 'רגשות', 'חוויות', 'אחר']
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']
        
        ax2.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', textprops={'color': 'white'})
        ax2.set_title('התפלגות סוגי זיכרון', color='white')
        
        canvas.draw()
    
    # ========== פונקציות UI ==========
    
    def on_search_change(self, event):
        """טיפול בשינוי חיפוש"""
        search_term = self.search_var.get().lower()
        if len(search_term) >= 2:
            self._filter_memories(search_term)
    
    def _filter_memories(self, search_term):
        """סינון זיכרונות לפי מונח חיפוש"""
        # יישום סינון בטבלה
        pass
    
    def on_memory_double_click(self, event):
        """טיפול בקליק כפול על זיכרון"""
        selection = self.memory_tree.selection()
        if selection:
            memory_id = self.memory_tree.item(selection[0])['values'][0]
            self.open_memory_details(memory_id)
    
    def on_memory_right_click(self, event):
        """טיפול בקליק ימני על זיכרון"""
        # יצירת תפריט הקשר
        context_menu = tk.Menu(self.root, tearoff=0)
        context_menu.add_command(label="הצג פרטים", command=self.show_memory_details)
        context_menu.add_command(label="חזק זיכרון", command=self.strengthen_memory)
        context_menu.add_command(label="מחק זיכרון", command=self.delete_memory)
        
        try:
            context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            context_menu.grab_release()
    
    # ========== פונקציות פעולה ==========
    
    def start_memory_system(self):
        """הפעלת מערכת הזיכרון"""
        if self.memory_engine:
            # הפעלת המערכת
            self.log_message("מערכת הזיכרון הופעלה", "INFO")
        else:
            messagebox.showwarning("אזהרה", "מנוע הזיכרון לא מחובר")
    
    def stop_memory_system(self):
        """עצירת מערכת הזיכרון"""
        if self.memory_engine:
            # עצירת המערכת
            self.log_message("מערכת הזיכרון נעצרה", "INFO")
    
    def refresh_data(self):
        """רענון הנתונים"""
        self.update_display()
        self.log_message("הנתונים רוענו", "INFO")
    
    def clear_memory(self):
        """ניקוי זיכרון"""
        if messagebox.askyesno("אישור", "האם אתה בטוח שברצונך לנקות את הזיכרון?"):
            # ניקוי הזיכרון
            self.log_message("הזיכרון נוקה", "WARNING")
    
    def manual_optimization(self):
        """אופטימיזציה ידנית"""
        self.log_message("מתבצעת אופטימיזציה ידנית...", "INFO")
        # יישום אופטימיזציה
        self.log_message("אופטימיזציה הושלמה", "INFO")
    
    def open_advanced_search(self):
        """פתיחת חיפוש מתקדם"""
        # יצירת חלון חיפוש מתקדם
        search_window = tk.Toplevel(self.root)
        search_window.title("חיפוש מתקדם")
        search_window.geometry("600x400")
        # הוספת רכיבים...
    
    def open_memory_details(self, memory_id):
        """פתיחת פרטי זיכרון"""
        # יצירת חלון פרטים
        details_window = tk.Toplevel(self.root)
        details_window.title(f"פרטי זיכרון: {memory_id}")
        details_window.geometry("500x600")
        # הוספת רכיבים...
    
    def export_memory(self):
        """ייצוא זיכרון"""
        from tkinter import filedialog
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            # ייצוא לקובץ
            self.log_message(f"זיכרון יוצא ל: {filename}", "INFO")
    
    def import_memory(self):
        """ייבוא זיכרון"""
        from tkinter import filedialog
        filename = filedialog.askopenfilename(
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            # ייבוא מקובץ
            self.log_message(f"זיכרון יובא מ: {filename}", "INFO")
    
    def save_settings(self):
        """שמירת הגדרות"""
        settings = {
            'max_memory': self.max_memory_var.get(),
            'decay_time': self.decay_time_var.get(),
            'opt_frequency': self.opt_frequency_var.get(),
            'auto_optimization': self.auto_opt_var.get()
        }
        # שמירת ההגדרות
        self.log_message("הגדרות נשמרו", "INFO")
    
    def log_message(self, message, level="INFO"):
        """הוספת הודעה ללוג"""
        if self.log_text:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = f"[{timestamp}] {level}: {message}\n"
            
            self.log_text.insert(tk.END, log_entry)
            self.log_text.see(tk.END)
    
    def _calculate_uptime(self):
        """חישוב זמן פעילות"""
        # סימולציה - יש להחליף בחישוב אמיתי
        return "12:34:56"
    
    def clear_logs(self):
        """ניקוי לוגים"""
        if self.log_text:
            self.log_text.delete(1.0, tk.END)
    
    def save_logs(self):
        """שמירת לוגים"""
        from tkinter import filedialog
        filename = filedialog.asksaveasfilename(
            defaultextension=".log",
            filetypes=[("Log files", "*.log"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename and self.log_text:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.log_text.get(1.0, tk.END))
            self.log_message(f"לוגים נשמרו ל: {filename}", "INFO")
    
    def on_log_level_change(self, event):
        """שינוי רמת לוג"""
        level = self.log_level_var.get()
        self.log_message(f"רמת לוג שונתה ל: {level}", "INFO")
    
    def show_memory_details(self):
        """הצגת פרטי זיכרון נבחר"""
        selection = self.memory_tree.selection()
        if selection:
            memory_id = self.memory_tree.item(selection[0])['values'][0]
            self.open_memory_details(memory_id)
    
    def strengthen_memory(self):
        """חיזוק זיכרון נבחר"""
        selection = self.memory_tree.selection()
        if selection:
            memory_id = self.memory_tree.item(selection[0])['values'][0]
            self.log_message(f"מחזק זיכרון: {memory_id}", "INFO")
    
    def delete_memory(self):
        """מחיקת זיכרון נבחר"""
        selection = self.memory_tree.selection()
        if selection:
            memory_id = self.memory_tree.item(selection[0])['values'][0]
            if messagebox.askyesno("אישור מחיקה", f"האם למחוק זיכרון {memory_id}?"):
                self.memory_tree.delete(selection[0])
                self.log_message(f"זיכרון נמחק: {memory_id}", "WARNING")
    
    def show_help(self):
        """הצגת עזרה"""
        help_text = """
        מערכת זיכרון אוטומטית - מדריך שימוש
        
        1. הפעלת המערכת: לחץ על "הפעל זיכרון"
        2. חיפוש זיכרונות: השתמש בשורת החיפוש
        3. ניהול זיכרונות: קליק ימני על זיכרון לפעולות
        4. אופטימיזציה: המערכת מבצעת אופטימיזציה אוטומטית
        5. הגדרות: ניתן לשנות בטאב "הגדרות"
        
        לעזרה נוספת פנה למפתח המערכת.
        """
        
        messagebox.showinfo("עזרה", help_text)
    
    def show_about(self):
        """הצגת מידע על המערכת"""
        about_text = """
        מערכת זיכרון אוטומטית
        גרסה 1.0
        
        פותח במסגרת Effi AI Private System
        מערכת זיכרון חכמה עם למידה אוטומטית
        
        © 2024 Effi AI Systems
        """
        
        messagebox.showinfo("אודות", about_text)
    
    def shutdown(self):
        """כיבוי המערכת"""
        self.running = False
        if self.update_thread:
            self.update_thread.join(timeout=1)
        if self.root:
            self.root.destroy()

def main():
    """פונקציה ראשית להפעלת הממשק"""
    app = MemoryDashboard()
    root = app.create_ui()
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("סגירת המערכת...")
    finally:
        app.shutdown()

if __name__ == "__main__":
    main()