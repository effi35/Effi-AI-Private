"""
מודול מערכת זיכרון אוטומטית - Auto Memory System
נקודת כניסה ראשית למערכת זיכרון חכמה ומתקדמת
"""

import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from pathlib import Path

# ייבוא רכיבי המערכת
from .models.runtime_memory import RuntimeMemory, MemoryStrength
from .models.memory_fragment import MemoryFragment
from .models.memory_context import MemoryContext
from .models.memory_index import MemoryIndex
from .models.config import MemoryConfig

from .core.memory_runtime import MemoryRuntime

from .utils.memory_utils import (
    MemoryUtils, MemoryCompressor, MemoryDatabase, 
    MemoryOptimizer, MemoryMonitor
)

class AutoMemorySystem:
    """
    מערכת זיכרון אוטומטית מתקדמת
    מנהלת זיכרון חי עם למידה אוטומטית ואופטימיזציה רציפה
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        אתחול מערכת הזיכרון
        
        Args:
            config_path: נתיב לקובץ הגדרות (אופציונלי)
        """
        # טעינת הגדרות
        self.config = MemoryConfig()
        if config_path:
            self.config.load_from_file(config_path)
        
        # אתחול רכיבי המערכת
        self._init_components()
        
        # אתחול מנוע הזיכרון
        self.memory_runtime = MemoryRuntime(
            database=self.database,
            config=self.config
        )
        
        # אתחול ניטור
        self.monitor = MemoryMonitor()
        
        # מצב המערכת
        self.is_running = False
        self.background_tasks = []
        
        # לוגינג
        self.logger = logging.getLogger(__name__)
        self.logger.info("מערכת זיכרון אוטומטית אותחלה בהצלחה")
    
    def _init_components(self):
        """אתחול רכיבי המערכת"""
        # בסיס נתונים
        db_path = self.config.get('database_path', 'memory_system.db')
        self.database = MemoryDatabase(db_path)
        
        # אופטימיזציה
        self.optimizer = MemoryOptimizer(self.database)
        
        # אינדקס זיכרון
        self.memory_index = MemoryIndex()
        
        # מטמון זיכרונות פעילים
        self.active_memories = {}
        
        self.logger.info("רכיבי המערכת אותחלו")
    
    async def start_system(self) -> bool:
        """
        הפעלת המערכת
        
        Returns:
            bool: True אם ההפעלה הצליחה
        """
        try:
            if self.is_running:
                self.logger.warning("המערכת כבר פועלת")
                return True
            
            # הפעלת מנוע הזיכרון
            await self.memory_runtime.start()
            
            # הפעלת ניטור
            self.monitor.start_monitoring()
            
            # הפעלת משימות רקע
            self._start_background_tasks()
            
            self.is_running = True
            self.logger.info("מערכת הזיכרון הופעלה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת המערכת: {e}")
            return False
    
    async def stop_system(self) -> bool:
        """
        עצירת המערכת
        
        Returns:
            bool: True אם העצירה הצליחה
        """
        try:
            if not self.is_running:
                self.logger.warning("המערכת כבר מועצרת")
                return True
            
            # עצירת משימות רקע
            await self._stop_background_tasks()
            
            # עצירת מנוע הזיכרון
            await self.memory_runtime.shutdown()
            
            # עצירת ניטור
            self.monitor.stop_monitoring()
            
            # שמירה אחרונה
            await self._save_all_memories()
            
            self.is_running = False
            self.logger.info("מערכת הזיכרון נעצרה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת המערכת: {e}")
            return False
    
    def _start_background_tasks(self):
        """הפעלת משימות רקע"""
        # משימת אופטימיזציה
        optimization_task = asyncio.create_task(self._optimization_loop())
        self.background_tasks.append(optimization_task)
        
        # משימת גיבוי
        backup_task = asyncio.create_task(self._backup_loop())
        self.background_tasks.append(backup_task)
        
        # משימת ניקוי
        cleanup_task = asyncio.create_task(self._cleanup_loop())
        self.background_tasks.append(cleanup_task)
        
        self.logger.info("משימות רקע הופעלו")
    
    async def _stop_background_tasks(self):
        """עצירת משימות רקע"""
        for task in self.background_tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        self.background_tasks.clear()
        self.logger.info("משימות רקע נעצרו")
    
    async def _optimization_loop(self):
        """לולאת אופטימיזציה רציפה"""
        interval = self.config.get('optimization_interval', 30) * 60  # דקות לשניות
        
        while self.is_running:
            try:
                await asyncio.sleep(interval)
                
                if self.is_running:
                    self.logger.info("מתחיל אופטימיזציה אוטומטית")
                    optimization_results = self.optimizer.optimize_memories()
                    self.logger.info(f"אופטימיזציה הושלמה: {optimization_results}")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה באופטימיזציה: {e}")
    
    async def _backup_loop(self):
        """לולאת גיבוי רציפה"""
        interval = self.config.get('backup_interval', 60) * 60  # דקות לשניות
        
        while self.is_running:
            try:
                await asyncio.sleep(interval)
                
                if self.is_running:
                    self.logger.info("מתחיל גיבוי אוטומטי")
                    await self._create_backup()
                    self.logger.info("גיבוי הושלם")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה בגיבוי: {e}")
    
    async def _cleanup_loop(self):
        """לולאת ניקוי רציפה"""
        interval = 24 * 60 * 60  # יום בשניות
        
        while self.is_running:
            try:
                await asyncio.sleep(interval)
                
                if self.is_running:
                    self.logger.info("מתחיל ניקוי יומי")
                    cleaned_count = self.optimizer.cleanup_completed_processes()
                    self.logger.info(f"ניקוי הושלם: {cleaned_count} פריטים נוקו")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"שגיאה בניקוי: {e}")
    
    # ========== פעולות זיכרון ==========
    
    def add_memory(self, content: str, memory_type: str = "general", 
                  strength: float = None, **kwargs) -> str:
        """
        הוספת זיכרון חדש
        
        Args:
            content: תוכן הזיכרון
            memory_type: סוג הזיכרון
            strength: חוזק התחלתי (אופציונלי)
            **kwargs: נתונים נוספים
        
        Returns:
            str: מזהה הזיכרון החדש
        """
        try:
            # יצירת זיכרון חדש
            if strength is None:
                strength = self.config.get('default_strength', 0.5)
            
            memory = RuntimeMemory(
                content=content,
                memory_type=memory_type,
                strength=strength,
                **kwargs
            )
            
            # שמירה בבסיס הנתונים
            memory_data = memory.to_dict()
            success = self.database.save_memory(memory_data)
            
            if success:
                # הוספה למטמון הפעיל
                self.active_memories[memory.memory_id] = memory
                
                # עדכון אינדקס
                self.memory_index.add_memory(memory)
                
                self.logger.info(f"זיכרון חדש נוסף: {memory.memory_id}")
                return memory.memory_id
            else:
                self.logger.error("שגיאה בשמירת זיכרון")
                return None
                
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת זיכרון: {e}")
            return None
    
    def get_memory(self, memory_id: str) -> Optional[RuntimeMemory]:
        """
        קבלת זיכרון לפי מזהה
        
        Args:
            memory_id: מזהה הזיכרון
        
        Returns:
            Optional[RuntimeMemory]: הזיכרון או None
        """
        try:
            # בדיקה במטמון הפעיל
            if memory_id in self.active_memories:
                memory = self.active_memories[memory_id]
                memory.access()  # עדכון גישה
                return memory
            
            # טעינה מבסיס הנתונים
            memory_data = self.database.load_memory(memory_id)
            if memory_data:
                memory = RuntimeMemory.from_dict(memory_data)
                memory.access()  # עדכון גישה
                
                # הוספה למטמון
                self.active_memories[memory_id] = memory
                
                # עדכון בבסיס הנתונים
                self.database.save_memory(memory.to_dict())
                
                return memory
            
            return None
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת זיכרון: {e}")
            return None
    
    def search_memories(self, query: str, memory_type: str = None,
                       min_strength: float = 0.0, max_results: int = 10,
                       include_similar: bool = True) -> List[Dict[str, Any]]:
        """
        חיפוש זיכרונות
        
        Args:
            query: מונח החיפוש
            memory_type: סוג זיכרון לסינון (אופציונלי)
            min_strength: חוזק מינימלי
            max_results: מספר תוצאות מקסימלי
            include_similar: האם לכלול תוצאות דומות
        
        Returns:
            List[Dict[str, Any]]: רשימת תוצאות חיפוש
        """
        try:
            # חיפוש בבסיס הנתונים
            results = self.database.search_memories(
                query=query,
                memory_type=memory_type,
                min_strength=min_strength,
                limit=max_results
            )
            
            # חיפוש זיכרונות דומים אם נדרש
            if include_similar and results:
                similar_results = []
                for result in results[:3]:  # בדיקת דמיון ל-3 הראשונים
                    similar_memories = self._find_similar_memories(
                        result['content'], exclude_id=result['id']
                    )
                    similar_results.extend(similar_memories[:2])  # 2 דומים לכל תוצאה
                
                results.extend(similar_results)
            
            # מיון לפי רלוונטיות וחוזק
            results.sort(key=lambda x: x['strength'], reverse=True)
            
            self.logger.info(f"חיפוש '{query}' החזיר {len(results)} תוצאות")
            return results[:max_results]
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש: {e}")
            return []
    
    def _find_similar_memories(self, content: str, exclude_id: str = None,
                              similarity_threshold: float = 0.7) -> List[Dict[str, Any]]:
        """חיפוש זיכרונות דומים"""
        try:
            similar_memories = []
            
            # בדיקת זיכרונות פעילים
            for memory_id, memory in self.active_memories.items():
                if memory_id == exclude_id:
                    continue
                
                similarity = MemoryUtils.calculate_similarity(content, memory.content)
                if similarity >= similarity_threshold:
                    similar_memories.append({
                        'id': memory_id,
                        'content': memory.content,
                        'strength': memory.strength,
                        'similarity': similarity,
                        'memory_type': memory.memory_type
                    })
            
            return sorted(similar_memories, key=lambda x: x['similarity'], reverse=True)
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש זיכרונות דומים: {e}")
            return []
    
    def update_memory(self, memory_id: str, **updates) -> bool:
        """
        עדכון זיכרון קיים
        
        Args:
            memory_id: מזהה הזיכרון
            **updates: שדות לעדכון
        
        Returns:
            bool: True אם העדכון הצליח
        """
        try:
            memory = self.get_memory(memory_id)
            if not memory:
                self.logger.warning(f"זיכרון לא נמצא: {memory_id}")
                return False
            
            # עדכון השדות
            for key, value in updates.items():
                if hasattr(memory, key):
                    setattr(memory, key, value)
            
            # שמירה בבסיס הנתונים
            success = self.database.save_memory(memory.to_dict())
            
            if success:
                self.logger.info(f"זיכרון עודכן: {memory_id}")
                return True
            else:
                self.logger.error(f"שגיאה בעדכון זיכרון: {memory_id}")
                return False
                
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון זיכרון: {e}")
            return False
    
    def delete_memory(self, memory_id: str) -> bool:
        """
        מחיקת זיכרון
        
        Args:
            memory_id: מזהה הזיכרון
        
        Returns:
            bool: True אם המחיקה הצליחה
        """
        try:
            # הסרה מהמטמון
            if memory_id in self.active_memories:
                del self.active_memories[memory_id]
            
            # הסרה מהאינדקס
            self.memory_index.remove_memory(memory_id)
            
            # מחיקה מבסיס הנתונים (יישום בהמשך)
            # success = self.database.delete_memory(memory_id)
            
            self.logger.info(f"זיכרון נמחק: {memory_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה במחיקת זיכרון: {e}")
            return False
    
    # ========== אופטימיזציה וניהול ==========
    
    def optimize_memories(self) -> Dict[str, Any]:
        """
        אופטימיזציה ידנית של זיכרונות
        
        Returns:
            Dict[str, Any]: תוצאות האופטימיזציה
        """
        try:
            self.logger.info("מתחיל אופטימיזציה ידנית")
            results = self.optimizer.optimize_memories()
            
            # עדכון מטמון פעיל
            self._refresh_active_cache()
            
            return results
            
        except Exception as e:
            self.logger.error(f"שגיאה באופטימיזציה: {e}")
            return {'error': str(e)}
    
    def _refresh_active_cache(self):
        """רענון מטמון זיכרונות פעילים"""
        try:
            # ניקוי מטמון ישן
            self.active_memories.clear()
            
            # טעינת זיכרונות חזקים למטמון
            cache_size = self.config.get('cache_size', 100)
            # יישום טעינה מבסיס הנתונים...
            
            self.logger.info("מטמון זיכרונות רוענן")
            
        except Exception as e:
            self.logger.error(f"שגיאה ברענון מטמון: {e}")
    
    def get_system_stats(self) -> Dict[str, Any]:
        """
        קבלת סטטיסטיקות מערכת
        
        Returns:
            Dict[str, Any]: סטטיסטיקות מערכת
        """
        try:
            # סטטיסטיקות בסיסיות
            stats = self.database.get_memory_stats()
            
            # סטטיסטיקות ביצועים
            performance = self.monitor.get_performance_summary()
            stats.update(performance)
            
            # מידע על המטמון
            stats['active_cache_size'] = len(self.active_memories)
            stats['system_running'] = self.is_running
            
            # זמן פעילות
            if hasattr(self, 'start_time'):
                uptime = datetime.now() - self.start_time
                stats['uptime_seconds'] = uptime.total_seconds()
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    async def _save_all_memories(self):
        """שמירת כל הזיכרונות הפעילים"""
        try:
            saved_count = 0
            
            for memory_id, memory in self.active_memories.items():
                success = self.database.save_memory(memory.to_dict())
                if success:
                    saved_count += 1
            
            self.logger.info(f"נשמרו {saved_count} זיכרונות")
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת זיכרונות: {e}")
    
    async def _create_backup(self):
        """יצירת גיבוי של המערכת"""
        try:
            backup_path = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            # יישום גיבוי...
            self.logger.info(f"גיבוי נוצר: {backup_path}")
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת גיבוי: {e}")
    
    # ========== ממשקי API ==========
    
    def get_memory_by_content(self, content_pattern: str) -> List[RuntimeMemory]:
        """חיפוש זיכרונות לפי תבנית תוכן"""
        results = self.search_memories(content_pattern)
        memories = []
        
        for result in results:
            memory = self.get_memory(result['id'])
            if memory:
                memories.append(memory)
        
        return memories
    
    def get_memories_by_type(self, memory_type: str) -> List[RuntimeMemory]:
        """קבלת כל הזיכרונות מסוג מסוים"""
        results = self.search_memories("", memory_type=memory_type, max_results=1000)
        memories = []
        
        for result in results:
            memory = self.get_memory(result['id'])
            if memory:
                memories.append(memory)
        
        return memories
    
    def get_recent_memories(self, hours: int = 24) -> List[RuntimeMemory]:
        """קבלת זיכרונות אחרונים"""
        # יישום לפי זמן יצירה...
        return list(self.active_memories.values())[:10]  # זמני
    
    def get_strong_memories(self, min_strength: float = 0.8) -> List[RuntimeMemory]:
        """קבלת זיכרונות חזקים"""
        results = self.search_memories("", min_strength=min_strength, max_results=1000)
        memories = []
        
        for result in results:
            memory = self.get_memory(result['id'])
            if memory:
                memories.append(memory)
        
        return memories
    
    # ========== הגדרות ותצורה ==========
    
    def update_config(self, **config_updates):
        """עדכון הגדרות מערכת"""
        try:
            for key, value in config_updates.items():
                self.config.set(key, value)
            
            self.logger.info(f"הגדרות עודכנו: {config_updates}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון הגדרות: {e}")
    
    def get_config(self) -> Dict[str, Any]:
        """קבלת הגדרות נוכחיות"""
        return self.config.to_dict()
    
    def reset_system(self) -> bool:
        """איפוס מערכת לברירות מחדל"""
        try:
            self.logger.warning("מאפס מערכת - זיכרונות יימחקו!")
            
            # ניקוי מטמון
            self.active_memories.clear()
            
            # איפוס אינדקס
            self.memory_index = MemoryIndex()
            
            # איפוס בסיס נתונים (זהירות!)
            # self.database.reset()
            
            self.logger.info("מערכת אופסה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה באיפוס מערכת: {e}")
            return False

# ========== פונקציות עזר למודול ==========

def create_memory_system(config_path: str = None) -> AutoMemorySystem:
    """
    יצירת מערכת זיכרון חדשה
    
    Args:
        config_path: נתיב לקובץ הגדרות
    
    Returns:
        AutoMemorySystem: מערכת זיכרון מאותחלת
    """
    return AutoMemorySystem(config_path)

async def run_memory_system(config_path: str = None):
    """
    הפעלת מערכת זיכרון כמו תהליך עצמאי
    
    Args:
        config_path: נתיב לקובץ הגדרות
    """
    system = create_memory_system(config_path)
    
    try:
        # הפעלת המערכת
        success = await system.start_system()
        if not success:
            logging.error("כשל בהפעלת מערכת הזיכרון")
            return
        
        logging.info("מערכת זיכרון פועלת - לחץ Ctrl+C לעצירה")
        
        # המתנה לסיגנל עצירה
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            logging.info("התקבל סיגנל עצירה")
    
    finally:
        # עצירת המערכת
        await system.stop_system()
        logging.info("מערכת זיכרון נעצרה")

# ========== נקודת כניסה ראשית ==========

if __name__ == "__main__":
    import sys
    
    # הגדרת לוגינג
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('memory_system.log', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # הפעלת מערכת זיכרון
    config_file = sys.argv[1] if len(sys.argv) > 1 else None
    asyncio.run(run_memory_system(config_file))