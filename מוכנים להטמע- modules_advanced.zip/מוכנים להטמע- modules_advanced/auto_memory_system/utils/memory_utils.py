"""
כלים שימושיים למערכת הזיכרון האוטומטית
פונקציות עזר לעיבוד, אנליזה ואופטימיזציה של זיכרונות
"""

import asyncio
import hashlib
import json
import pickle
import gzip
import sqlite3
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import asdict
import logging
import threading
from pathlib import Path
import psutil
import gc
from collections import defaultdict, Counter
import re
from difflib import SequenceMatcher

class MemoryUtils:
    """כלים שימושיים למערכת הזיכרון"""
    
    @staticmethod
    def calculate_memory_hash(content: str) -> str:
        """חישוב hash עבור תוכן זיכרון"""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()[:16]
    
    @staticmethod
    def calculate_similarity(content1: str, content2: str) -> float:
        """חישוב דמיון בין שני תכנים"""
        return SequenceMatcher(None, content1.lower(), content2.lower()).ratio()
    
    @staticmethod
    def extract_keywords(content: str, max_keywords: int = 10) -> List[str]:
        """חילוץ מילות מפתח מתוכן"""
        # הסרת סימני פיסוק ותווים מיוחדים
        clean_content = re.sub(r'[^\w\s]', '', content)
        words = clean_content.split()
        
        # הסרת מילות עצירה בעברית ואנגלית
        stop_words = {
            'את', 'של', 'על', 'אל', 'לא', 'אם', 'כי', 'או', 'גם', 'רק', 'עוד',
            'כל', 'יש', 'היה', 'הוא', 'היא', 'אני', 'אתה', 'זה', 'מה', 'איך',
            'the', 'is', 'at', 'which', 'on', 'and', 'a', 'to', 'are', 'as',
            'was', 'for', 'with', 'be', 'by', 'an', 'have', 'it', 'this'
        }
        
        # סינון וספירה
        filtered_words = [word.lower() for word in words 
                         if len(word) > 2 and word.lower() not in stop_words]
        
        word_counts = Counter(filtered_words)
        return [word for word, count in word_counts.most_common(max_keywords)]
    
    @staticmethod
    def calculate_content_importance(content: str, keywords: List[str] = None) -> float:
        """חישוב חשיבות תוכן בהתבסס על מילות מפתח ואורך"""
        if not content:
            return 0.0
        
        importance = 0.0
        
        # חשיבות בהתבסס על אורך
        length_score = min(len(content) / 1000, 1.0)  # נרמול לפי 1000 תווים
        importance += length_score * 0.3
        
        # חשיבות בהתבסס על מילות מפתח
        if keywords:
            content_lower = content.lower()
            keyword_matches = sum(1 for keyword in keywords if keyword in content_lower)
            keyword_score = min(keyword_matches / len(keywords), 1.0)
            importance += keyword_score * 0.4
        
        # חשיבות בהתבסס על סימני פיסוק (שאלות, קריאות)
        punctuation_score = 0.0
        if '?' in content:
            punctuation_score += 0.1
        if '!' in content:
            punctuation_score += 0.1
        importance += punctuation_score * 0.3
        
        return min(importance, 1.0)
    
    @staticmethod
    def calculate_decay_factor(created_time: datetime, 
                             last_accessed: datetime,
                             half_life_hours: float = 24.0) -> float:
        """חישוב גורם דעיכה של זיכרון"""
        now = datetime.now()
        
        # זמן מאז יצירה
        time_since_creation = (now - created_time).total_seconds() / 3600
        
        # זמן מאז גישה אחרונה
        time_since_access = (now - last_accessed).total_seconds() / 3600
        
        # חישוב דעיכה אקספוננציאלית
        creation_decay = np.exp(-time_since_creation / half_life_hours)
        access_decay = np.exp(-time_since_access / (half_life_hours * 0.5))
        
        # משקל משולב
        return (creation_decay * 0.3 + access_decay * 0.7)

class MemoryCompressor:
    """מחלקה לדחיסת ושחזור זיכרונות"""
    
    @staticmethod
    def compress_memory(memory_data: Dict[str, Any]) -> bytes:
        """דחיסת נתוני זיכרון"""
        # המרה ל-JSON ודחיסה
        json_data = json.dumps(memory_data, ensure_ascii=False, default=str)
        json_bytes = json_data.encode('utf-8')
        return gzip.compress(json_bytes)
    
    @staticmethod
    def decompress_memory(compressed_data: bytes) -> Dict[str, Any]:
        """שחזור נתוני זיכרון דחוסים"""
        # ביטול דחיסה והמרה חזרה ל-Dict
        json_bytes = gzip.decompress(compressed_data)
        json_data = json_bytes.decode('utf-8')
        return json.loads(json_data)
    
    @staticmethod
    def compress_batch(memories: List[Dict[str, Any]]) -> bytes:
        """דחיסת רשימת זיכרונות"""
        return MemoryCompressor.compress_memory({'memories': memories})
    
    @staticmethod
    def decompress_batch(compressed_data: bytes) -> List[Dict[str, Any]]:
        """שחזור רשימת זיכרונות דחוסה"""
        data = MemoryCompressor.decompress_memory(compressed_data)
        return data.get('memories', [])

class MemoryDatabase:
    """מחלקה לניהול בסיס נתונים של זיכרונות"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.connection = None
        self._init_database()
    
    def _init_database(self):
        """אתחול בסיס הנתונים"""
        self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
        self.connection.execute('PRAGMA foreign_keys = ON')
        
        # יצירת טבלאות
        self._create_tables()
    
    def _create_tables(self):
        """יצירת טבלאות בסיס הנתונים"""
        cursor = self.connection.cursor()
        
        # טבלת זיכרונות ראשית
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                memory_type TEXT NOT NULL,
                strength REAL NOT NULL,
                importance REAL NOT NULL,
                created_at TIMESTAMP NOT NULL,
                last_accessed TIMESTAMP NOT NULL,
                access_count INTEGER DEFAULT 0,
                keywords TEXT,
                compressed_data BLOB,
                metadata TEXT
            )
        ''')
        
        # טבלת קשרי זיכרון
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_associations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id1 TEXT NOT NULL,
                memory_id2 TEXT NOT NULL,
                association_strength REAL NOT NULL,
                association_type TEXT,
                created_at TIMESTAMP NOT NULL,
                FOREIGN KEY (memory_id1) REFERENCES memories (id),
                FOREIGN KEY (memory_id2) REFERENCES memories (id),
                UNIQUE(memory_id1, memory_id2)
            )
        ''')
        
        # טבלת סטטיסטיקות
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_stats (
                date TEXT PRIMARY KEY,
                total_memories INTEGER,
                total_associations INTEGER,
                avg_strength REAL,
                optimizations_count INTEGER,
                created_at TIMESTAMP NOT NULL
            )
        ''')
        
        # אינדקסים לביצועים
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_type ON memories (memory_type)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_strength ON memories (strength)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_memories_created ON memories (created_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_associations_strength ON memory_associations (association_strength)')
        
        self.connection.commit()
    
    def save_memory(self, memory_data: Dict[str, Any]) -> bool:
        """שמירת זיכרון בבסיס הנתונים"""
        try:
            cursor = self.connection.cursor()
            
            # דחיסת נתונים נוספים
            compressed_data = MemoryCompressor.compress_memory(memory_data)
            
            cursor.execute('''
                INSERT OR REPLACE INTO memories 
                (id, content, memory_type, strength, importance, created_at, 
                 last_accessed, access_count, keywords, compressed_data, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                memory_data['id'],
                memory_data['content'],
                memory_data['memory_type'],
                memory_data['strength'],
                memory_data.get('importance', 0.5),
                memory_data['created_at'],
                memory_data['last_accessed'],
                memory_data.get('access_count', 0),
                json.dumps(memory_data.get('keywords', [])),
                compressed_data,
                json.dumps(memory_data.get('metadata', {}))
            ))
            
            self.connection.commit()
            return True
        except Exception as e:
            logging.error(f"שגיאה בשמירת זיכרון: {e}")
            return False
    
    def load_memory(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """טעינת זיכרון מבסיס הנתונים"""
        try:
            cursor = self.connection.cursor()
            cursor.execute('SELECT * FROM memories WHERE id = ?', (memory_id,))
            row = cursor.fetchone()
            
            if row:
                # המרה חזרה למבנה נתונים
                return {
                    'id': row[0],
                    'content': row[1],
                    'memory_type': row[2],
                    'strength': row[3],
                    'importance': row[4],
                    'created_at': datetime.fromisoformat(row[5]),
                    'last_accessed': datetime.fromisoformat(row[6]),
                    'access_count': row[7],
                    'keywords': json.loads(row[8]) if row[8] else [],
                    'compressed_data': row[9],
                    'metadata': json.loads(row[10]) if row[10] else {}
                }
            return None
        except Exception as e:
            logging.error(f"שגיאה בטעינת זיכרון: {e}")
            return None
    
    def search_memories(self, query: str, memory_type: str = None, 
                       min_strength: float = 0.0, limit: int = 100) -> List[Dict[str, Any]]:
        """חיפוש זיכרונות"""
        try:
            cursor = self.connection.cursor()
            sql = '''
                SELECT * FROM memories 
                WHERE (content LIKE ? OR keywords LIKE ?)
                AND strength >= ?
            '''
            params = [f'%{query}%', f'%{query}%', min_strength]
            
            if memory_type:
                sql += ' AND memory_type = ?'
                params.append(memory_type)
            
            sql += ' ORDER BY strength DESC LIMIT ?'
            params.append(limit)
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            
            results = []
            for row in rows:
                results.append({
                    'id': row[0],
                    'content': row[1],
                    'memory_type': row[2],
                    'strength': row[3],
                    'importance': row[4],
                    'created_at': datetime.fromisoformat(row[5]),
                    'last_accessed': datetime.fromisoformat(row[6]),
                    'access_count': row[7],
                    'keywords': json.loads(row[8]) if row[8] else [],
                    'metadata': json.loads(row[10]) if row[10] else {}
                })
            
            return results
        except Exception as e:
            logging.error(f"שגיאה בחיפוש זיכרונות: {e}")
            return []
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות זיכרון"""
        try:
            cursor = self.connection.cursor()
            
            # סטטיסטיקות כלליות
            cursor.execute('SELECT COUNT(*), AVG(strength), MAX(created_at) FROM memories')
            total, avg_strength, latest = cursor.fetchone()
            
            # סטטיסטיקות לפי סוג
            cursor.execute('''
                SELECT memory_type, COUNT(*), AVG(strength) 
                FROM memories 
                GROUP BY memory_type
            ''')
            type_stats = cursor.fetchall()
            
            return {
                'total_memories': total or 0,
                'average_strength': avg_strength or 0.0,
                'latest_memory': latest,
                'type_distribution': {row[0]: {'count': row[1], 'avg_strength': row[2]} 
                                    for row in type_stats}
            }
        except Exception as e:
            logging.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    def close(self):
        """סגירת חיבור לבסיס הנתונים"""
        if self.connection:
            self.connection.close()

class MemoryOptimizer:
    """מחלקה לאופטימיזציה של זיכרונות"""
    
    def __init__(self, database: MemoryDatabase):
        self.database = database
        self.optimization_stats = {
            'optimizations_run': 0,
            'memories_optimized': 0,
            'memories_archived': 0,
            'associations_created': 0
        }
    
    def optimize_memories(self, target_memory_mb: int = 100) -> Dict[str, Any]:
        """אופטימיזציה כללית של זיכרונות"""
        optimization_results = {
            'actions_taken': [],
            'memories_processed': 0,
            'space_saved_mb': 0.0,
            'performance_improvement': 0.0
        }
        
        try:
            # 1. זיהוי זיכרונות חלשים
            weak_memories = self._identify_weak_memories()
            if weak_memories:
                archived = self._archive_weak_memories(weak_memories)
                optimization_results['actions_taken'].append(f"ארכוב {archived} זיכרונות חלשים")
            
            # 2. זיהוי זיכרונות דומים
            similar_groups = self._identify_similar_memories()
            if similar_groups:
                merged = self._merge_similar_memories(similar_groups)
                optimization_results['actions_taken'].append(f"מיזוג {merged} קבוצות זיכרונות דומים")
            
            # 3. יצירת קשרים חדשים
            new_associations = self._create_memory_associations()
            if new_associations:
                optimization_results['actions_taken'].append(f"יצירת {new_associations} קשרים חדשים")
            
            # 4. עדכון חוזקים
            updated_strengths = self._update_memory_strengths()
            optimization_results['actions_taken'].append(f"עדכון חוזק ל-{updated_strengths} זיכרונות")
            
            # עדכון סטטיסטיקות
            self.optimization_stats['optimizations_run'] += 1
            
            return optimization_results
            
        except Exception as e:
            logging.error(f"שגיאה באופטימיזציה: {e}")
            return optimization_results
    
    def _identify_weak_memories(self, weakness_threshold: float = 0.1) -> List[str]:
        """זיהוי זיכרונות חלשים למחיקה/ארכוב"""
        try:
            cursor = self.database.connection.cursor()
            cursor.execute('''
                SELECT id FROM memories 
                WHERE strength < ? 
                AND last_accessed < datetime('now', '-7 days')
                ORDER BY strength ASC
            ''', (weakness_threshold,))
            
            return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logging.error(f"שגיאה בזיהוי זיכרונות חלשים: {e}")
            return []
    
    def _identify_similar_memories(self, similarity_threshold: float = 0.8) -> List[List[str]]:
        """זיהוי קבוצות של זיכרונות דומים"""
        similar_groups = []
        
        try:
            cursor = self.database.connection.cursor()
            cursor.execute('SELECT id, content FROM memories ORDER BY created_at DESC LIMIT 1000')
            memories = cursor.fetchall()
            
            processed = set()
            
            for i, (id1, content1) in enumerate(memories):
                if id1 in processed:
                    continue
                
                similar_group = [id1]
                processed.add(id1)
                
                for j, (id2, content2) in enumerate(memories[i+1:], i+1):
                    if id2 in processed:
                        continue
                    
                    similarity = MemoryUtils.calculate_similarity(content1, content2)
                    if similarity >= similarity_threshold:
                        similar_group.append(id2)
                        processed.add(id2)
                
                if len(similar_group) > 1:
                    similar_groups.append(similar_group)
            
            return similar_groups
            
        except Exception as e:
            logging.error(f"שגיאה בזיהוי זיכרונות דומים: {e}")
            return []
    
    def _archive_weak_memories(self, weak_memory_ids: List[str]) -> int:
        """ארכוב זיכרונות חלשים"""
        archived_count = 0
        
        try:
            cursor = self.database.connection.cursor()
            
            for memory_id in weak_memory_ids:
                # העברה לטבלת ארכיון (אם קיימת) או מחיקה
                cursor.execute('DELETE FROM memories WHERE id = ?', (memory_id,))
                archived_count += 1
            
            self.database.connection.commit()
            self.optimization_stats['memories_archived'] += archived_count
            
        except Exception as e:
            logging.error(f"שגיאה בארכוב זיכרונות: {e}")
        
        return archived_count
    
    def _merge_similar_memories(self, similar_groups: List[List[str]]) -> int:
        """מיזוג זיכרונות דומים"""
        merged_count = 0
        
        try:
            for group in similar_groups:
                if len(group) < 2:
                    continue
                
                # טעינת כל הזיכרונות בקבוצה
                memories = []
                for memory_id in group:
                    memory = self.database.load_memory(memory_id)
                    if memory:
                        memories.append(memory)
                
                if len(memories) < 2:
                    continue
                
                # יצירת זיכרון מאוחד
                merged_memory = self._create_merged_memory(memories)
                
                # שמירת הזיכרון המאוחד
                self.database.save_memory(merged_memory)
                
                # מחיקת הזיכרונות המקוריים (למעט הראשון)
                cursor = self.database.connection.cursor()
                for memory_id in group[1:]:
                    cursor.execute('DELETE FROM memories WHERE id = ?', (memory_id,))
                
                self.database.connection.commit()
                merged_count += 1
                
        except Exception as e:
            logging.error(f"שגיאה במיזוג זיכרונות: {e}")
        
        return merged_count
    
    def _create_merged_memory(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """יצירת זיכרון מאוחד ממספר זיכרונות"""
        # זיכרון החזק ביותר כבסיס
        base_memory = max(memories, key=lambda m: m['strength'])
        
        # איחוד תכנים
        combined_content = base_memory['content']
        for memory in memories:
            if memory['id'] != base_memory['id']:
                combined_content += f"\n\n--- מאוחד מזיכרון {memory['id']} ---\n{memory['content']}"
        
        # איחוד מילות מפתח
        all_keywords = []
        for memory in memories:
            all_keywords.extend(memory.get('keywords', []))
        unique_keywords = list(set(all_keywords))
        
        # חישוב חוזק משולב
        combined_strength = sum(m['strength'] for m in memories) / len(memories)
        combined_strength = min(combined_strength * 1.1, 1.0)  # בונוס למיזוג
        
        return {
            'id': base_memory['id'],
            'content': combined_content,
            'memory_type': base_memory['memory_type'],
            'strength': combined_strength,
            'importance': max(m.get('importance', 0.5) for m in memories),
            'created_at': min(m['created_at'] for m in memories),
            'last_accessed': max(m['last_accessed'] for m in memories),
            'access_count': sum(m.get('access_count', 0) for m in memories),
            'keywords': unique_keywords,
            'metadata': {
                'merged_from': [m['id'] for m in memories],
                'merge_date': datetime.now().isoformat()
            }
        }
    
    def _create_memory_associations(self) -> int:
        """יצירת קשרים חדשים בין זיכרונות"""
        associations_created = 0
        
        try:
            cursor = self.database.connection.cursor()
            
            # קבלת זיכרונות ללא קשרים
            cursor.execute('''
                SELECT m1.id, m1.content, m1.keywords 
                FROM memories m1
                LEFT JOIN memory_associations ma ON (m1.id = ma.memory_id1 OR m1.id = ma.memory_id2)
                WHERE ma.id IS NULL
                ORDER BY m1.strength DESC
                LIMIT 100
            ''')
            
            unconnected_memories = cursor.fetchall()
            
            # חיפוש קשרים פוטנציאליים
            for i, (id1, content1, keywords1_json) in enumerate(unconnected_memories):
                keywords1 = json.loads(keywords1_json) if keywords1_json else []
                
                for j, (id2, content2, keywords2_json) in enumerate(unconnected_memories[i+1:], i+1):
                    keywords2 = json.loads(keywords2_json) if keywords2_json else []
                    
                    # חישוב חוזק קשר
                    association_strength = self._calculate_association_strength(
                        content1, content2, keywords1, keywords2
                    )
                    
                    if association_strength >= 0.3:  # סף מינימלי לקשר
                        # יצירת קשר
                        cursor.execute('''
                            INSERT OR IGNORE INTO memory_associations 
                            (memory_id1, memory_id2, association_strength, association_type, created_at)
                            VALUES (?, ?, ?, ?, ?)
                        ''', (id1, id2, association_strength, 'semantic', datetime.now()))
                        
                        associations_created += 1
            
            self.database.connection.commit()
            self.optimization_stats['associations_created'] += associations_created
            
        except Exception as e:
            logging.error(f"שגיאה ביצירת קשרים: {e}")
        
        return associations_created
    
    def _calculate_association_strength(self, content1: str, content2: str,
                                      keywords1: List[str], keywords2: List[str]) -> float:
        """חישוב חוזק קשר בין שני זיכרונות"""
        # דמיון תוכן
        content_similarity = MemoryUtils.calculate_similarity(content1, content2)
        
        # דמיון מילות מפתח
        keyword_similarity = 0.0
        if keywords1 and keywords2:
            common_keywords = set(keywords1) & set(keywords2)
            total_keywords = set(keywords1) | set(keywords2)
            keyword_similarity = len(common_keywords) / len(total_keywords) if total_keywords else 0.0
        
        # משקל משולב
        return content_similarity * 0.7 + keyword_similarity * 0.3
    
    def _update_memory_strengths(self) -> int:
        """עדכון חוזקי זיכרון בהתבסס על פעילות"""
        updated_count = 0
        
        try:
            cursor = self.database.connection.cursor()
            
            # עדכון חוזקים בהתבסס על גישות אחרונות
            cursor.execute('''
                UPDATE memories 
                SET strength = CASE 
                    WHEN last_accessed > datetime('now', '-1 day') THEN 
                        MIN(strength * 1.05, 1.0)
                    WHEN last_accessed > datetime('now', '-7 days') THEN 
                        strength * 1.02
                    WHEN last_accessed < datetime('now', '-30 days') THEN 
                        strength * 0.95
                    ELSE strength * 0.98
                END
                WHERE id IN (
                    SELECT id FROM memories 
                    WHERE last_accessed < datetime('now', '-1 hour')
                )
            ''')
            
            updated_count = cursor.rowcount
            self.database.connection.commit()
            
        except Exception as e:
            logging.error(f"שגיאה בעדכון חוזקים: {e}")
        
        return updated_count

class MemoryMonitor:
    """מחלקה לניטור ביצועי מערכת הזיכרון"""
    
    def __init__(self):
        self.monitoring_active = False
        self.stats_history = []
        self.performance_metrics = {
            'memory_usage_mb': 0.0,
            'cpu_usage_percent': 0.0,
            'operation_times': defaultdict(list),
            'error_count': 0
        }
    
    def start_monitoring(self):
        """התחלת ניטור"""
        self.monitoring_active = True
        threading.Thread(target=self._monitoring_loop, daemon=True).start()
    
    def stop_monitoring(self):
        """עצירת ניטור"""
        self.monitoring_active = False
    
    def _monitoring_loop(self):
        """לולאת ניטור רציפה"""
        while self.monitoring_active:
            try:
                # ניטור שימוש זיכרון
                process = psutil.Process()
                memory_info = process.memory_info()
                self.performance_metrics['memory_usage_mb'] = memory_info.rss / (1024 * 1024)
                
                # ניטור שימוש CPU
                self.performance_metrics['cpu_usage_percent'] = process.cpu_percent()
                
                # שמירת סטטיסטיקות
                self.stats_history.append({
                    'timestamp': datetime.now(),
                    'memory_mb': self.performance_metrics['memory_usage_mb'],
                    'cpu_percent': self.performance_metrics['cpu_usage_percent']
                })
                
                # שמירה של 1000 רשומות אחרונות בלבד
                if len(self.stats_history) > 1000:
                    self.stats_history = self.stats_history[-1000:]
                
                threading.Event().wait(5)  # ניטור כל 5 שניות
                
            except Exception as e:
                logging.error(f"שגיאה בניטור: {e}")
                self.performance_metrics['error_count'] += 1
    
    def record_operation_time(self, operation: str, duration: float):
        """רישום זמן ביצוע פעולה"""
        self.performance_metrics['operation_times'][operation].append(duration)
        
        # שמירה של 100 מדידות אחרונות בלבד
        if len(self.performance_metrics['operation_times'][operation]) > 100:
            self.performance_metrics['operation_times'][operation] = \
                self.performance_metrics['operation_times'][operation][-100:]
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """קבלת סיכום ביצועים"""
        summary = {
            'current_memory_mb': self.performance_metrics['memory_usage_mb'],
            'current_cpu_percent': self.performance_metrics['cpu_usage_percent'],
            'error_count': self.performance_metrics['error_count'],
            'operation_averages': {}
        }
        
        # חישוב זמני ביצוע ממוצעים
        for operation, times in self.performance_metrics['operation_times'].items():
            if times:
                summary['operation_averages'][operation] = {
                    'avg_time': np.mean(times),
                    'min_time': np.min(times),
                    'max_time': np.max(times),
                    'operation_count': len(times)
                }
        
        return summary
    
    def get_memory_trend(self, hours: int = 24) -> List[Dict[str, Any]]:
        """קבלת מגמת שימוש זיכרון"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        return [
            {
                'timestamp': stat['timestamp'],
                'memory_mb': stat['memory_mb'],
                'cpu_percent': stat['cpu_percent']
            }
            for stat in self.stats_history
            if stat['timestamp'] >= cutoff_time
        ]

# פונקציות עזר גלובליות
def cleanup_memory():
    """ניקוי זיכרון מערכת"""
    gc.collect()

def format_memory_size(size_bytes: int) -> str:
    """פורמט גודל זיכרון לקריאה"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"

def validate_memory_data(memory_data: Dict[str, Any]) -> bool:
    """אימות תקינות נתוני זיכרון"""
    required_fields = ['id', 'content', 'memory_type', 'strength', 'created_at', 'last_accessed']
    
    for field in required_fields:
        if field not in memory_data:
            return False
    
    # אימות טווחי ערכים
    if not (0.0 <= memory_data['strength'] <= 1.0):
        return False
    
    return True

def generate_memory_report(database: MemoryDatabase) -> str:
    """יצירת דוח זיכרון מפורט"""
    stats = database.get_memory_stats()
    
    report = f"""
דוח מערכת זיכרון אוטומטית
============================

סטטיסטיקות כלליות:
- סה"כ זיכרונות: {stats.get('total_memories', 0)}
- חוזק ממוצע: {stats.get('average_strength', 0.0):.3f}
- זיכרון אחרון: {stats.get('latest_memory', 'לא זמין')}

התפלגות לפי סוגים:
"""
    
    for memory_type, type_data in stats.get('type_distribution', {}).items():
        report += f"- {memory_type}: {type_data['count']} זיכרונות, חוזק ממוצע: {type_data['avg_strength']:.3f}\n"
    
    report += f"\nהדוח נוצר בתאריך: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    return report