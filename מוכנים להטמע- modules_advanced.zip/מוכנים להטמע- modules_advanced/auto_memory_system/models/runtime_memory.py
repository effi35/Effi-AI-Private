"""
Runtime Memory - זיכרון זמן אמת חי ואוטונומי
מערכת זיכרון מתקדמת הלומדת, מסיקה ומתפתחת באופן עצמאי
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union, Set, Tuple
from datetime import datetime, timedelta
import json
import hashlib
import numpy as np
from collections import defaultdict, deque
import threading
import asyncio

class MemoryType(Enum):
    """סוגי זיכרון"""
    EXPERIENTIAL = "experiential"       # זיכרון חוויתי
    CONVERSATIONAL = "conversational"   # זיכרון שיחות
    PROCEDURAL = "procedural"           # זיכרון פרוצדורלי
    DECLARATIVE = "declarative"         # זיכרון הצהרתי
    EPISODIC = "episodic"               # זיכרון אפיזודי
    SEMANTIC = "semantic"               # זיכרון סמנטי
    EMOTIONAL = "emotional"             # זיכרון רגשי
    BEHAVIORAL = "behavioral"           # זיכרון התנהגותי
    CONTEXTUAL = "contextual"           # זיכרון הקשרי
    PREDICTIVE = "predictive"           # זיכרון חיזוי
    META_COGNITIVE = "meta_cognitive"   # זיכרון מטא-קוגניטיבי
    SENSORY = "sensory"                 # זיכרון חושי

class MemoryPriority(Enum):
    """עדיפות זיכרון"""
    CRITICAL = 10      # קריטי - לעולם לא נמחק
    VERY_HIGH = 8      # גבוה מאוד
    HIGH = 6           # גבוה
    MEDIUM = 4         # בינוני
    LOW = 2            # נמוך
    TEMPORARY = 1      # זמני

class MemoryStatus(Enum):
    """סטטוס זיכרון"""
    ACTIVE = "active"               # פעיל
    DORMANT = "dormant"             # רדום
    ARCHIVED = "archived"           # בארכיון
    REINFORCED = "reinforced"       # מחוזק
    WEAKENING = "weakening"         # נחלש
    CONFLICTING = "conflicting"     # מתנגש
    INTEGRATING = "integrating"     # בתהליך שילוב
    TRANSFORMING = "transforming"   # בתהליך טרנספורמציה

class MemoryScope(Enum):
    """היקף זיכרון"""
    PERSONAL = "personal"           # אישי
    CONTEXTUAL = "contextual"       # הקשרי
    UNIVERSAL = "universal"         # אוניברסלי
    SYSTEM = "system"              # מערכתי
    SESSION = "session"            # סשן
    PERSISTENT = "persistent"       # מתמיד
    SHARED = "shared"              # משותף
    PRIVATE = "private"            # פרטי

@dataclass
class MemoryFragment:
    """פרגמנט זיכרון בסיסי"""
    id: str
    content: Any
    content_type: str  # text, image, audio, video, data, code
    encoding: str      # utf-8, base64, binary, json
    timestamp: datetime
    source: str        # conversation, file, system, inference
    confidence: float  # 0.0-1.0
    relevance: float   # 0.0-1.0
    emotional_weight: float = 0.0  # -1.0 to 1.0
    
    def get_hash(self) -> str:
        """מחזיר hash ייחודי לפרגמנט"""
        content_str = str(self.content) if not isinstance(self.content, str) else self.content
        return hashlib.sha256(f"{content_str}{self.timestamp}".encode()).hexdigest()[:16]

@dataclass
class MemoryContext:
    """הקשר זיכרון"""
    context_id: str
    name: str
    hebrew_name: str
    description: str
    participants: List[str]  # מי מעורב בהקשר
    environment: Dict[str, Any]  # סביבת ההקשר
    temporal_bounds: Tuple[datetime, Optional[datetime]]  # גבולות זמן
    spatial_bounds: Optional[Dict[str, Any]] = None  # גבולות מקום
    emotional_tone: float = 0.0  # טון רגשי כללי
    importance: float = 0.5      # חשיבות ההקשר
    tags: Set[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = set()

@dataclass
class MemoryAssociation:
    """קשר בין זיכרונות"""
    from_memory_id: str
    to_memory_id: str
    association_type: str  # causal, temporal, semantic, emotional, logical
    strength: float        # 0.0-1.0
    bidirectional: bool = True
    confidence: float = 1.0
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()

@dataclass
class RuntimeMemory:
    """זיכרון זמן אמת מתקדם"""
    memory_id: str
    memory_type: MemoryType
    priority: MemoryPriority
    status: MemoryStatus
    scope: MemoryScope
    
    # תוכן הזיכרון
    fragments: List[MemoryFragment]
    context: MemoryContext
    
    # מטא-דטה
    created_at: datetime
    last_accessed: datetime
    last_modified: datetime
    access_count: int = 0
    modification_count: int = 0
    
    # חיזוק וחולשה
    strength: float = 1.0        # חוזק הזיכרון (0.0-2.0)
    decay_rate: float = 0.01     # קצב דעיכה יומי
    reinforcement_events: List[datetime] = None
    
    # קשרים
    associations: List[MemoryAssociation] = None
    related_memories: Set[str] = None
    
    # תובנות וניתוח
    derived_insights: List[str] = None
    behavioral_patterns: List[str] = None
    predictive_value: float = 0.0
    
    # בקרה וביטחון
    is_protected: bool = False
    encryption_level: int = 0    # 0=none, 1=basic, 2=advanced, 3=military
    access_restrictions: List[str] = None
    
    def __post_init__(self):
        if self.reinforcement_events is None:
            self.reinforcement_events = []
        if self.associations is None:
            self.associations = []
        if self.related_memories is None:
            self.related_memories = set()
        if self.derived_insights is None:
            self.derived_insights = []
        if self.behavioral_patterns is None:
            self.behavioral_patterns = []
        if self.access_restrictions is None:
            self.access_restrictions = []
    
    def access(self):
        """רישום גישה לזיכרון"""
        self.last_accessed = datetime.now()
        self.access_count += 1
        
        # חיזוק אוטומטי בגישה
        self.reinforce(0.1)
    
    def modify(self, new_fragment: MemoryFragment = None):
        """עדכון זיכרון"""
        self.last_modified = datetime.now()
        self.modification_count += 1
        
        if new_fragment:
            self.fragments.append(new_fragment)
        
        # חיזוק בעת עדכון
        self.reinforce(0.2)
    
    def reinforce(self, amount: float = 0.1):
        """חיזוק זיכרון"""
        self.strength = min(2.0, self.strength + amount)
        self.reinforcement_events.append(datetime.now())
        
        # הסרת אירועי חיזוק ישנים (מעל שנה)
        cutoff = datetime.now() - timedelta(days=365)
        self.reinforcement_events = [
            event for event in self.reinforcement_events 
            if event > cutoff
        ]
    
    def decay(self, days_passed: float = 1.0):
        """דעיכת זיכרון לפי זמן"""
        if not self.is_protected and self.priority != MemoryPriority.CRITICAL:
            decay_amount = self.decay_rate * days_passed
            
            # זיכרונות בעדיפות גבוהה דועכים לאט יותר
            priority_factor = {
                MemoryPriority.VERY_HIGH: 0.3,
                MemoryPriority.HIGH: 0.5,
                MemoryPriority.MEDIUM: 1.0,
                MemoryPriority.LOW: 1.5,
                MemoryPriority.TEMPORARY: 2.0
            }.get(self.priority, 1.0)
            
            decay_amount *= priority_factor
            self.strength = max(0.0, self.strength - decay_amount)
            
            # עדכון סטטוס לפי חוזק
            if self.strength < 0.1:
                self.status = MemoryStatus.WEAKENING
            elif self.strength < 0.3:
                self.status = MemoryStatus.DORMANT
    
    def add_association(self, other_memory_id: str, 
                       association_type: str, 
                       strength: float):
        """הוספת קשר לזיכרון אחר"""
        association = MemoryAssociation(
            from_memory_id=self.memory_id,
            to_memory_id=other_memory_id,
            association_type=association_type,
            strength=strength
        )
        
        self.associations.append(association)
        self.related_memories.add(other_memory_id)
    
    def get_relevance_score(self, query_context: Dict[str, Any]) -> float:
        """חישוב רלוונטיות לשאילתה"""
        score = 0.0
        
        # בסיס על חוזק הזיכרון
        score += self.strength * 0.3
        
        # בסיס על עדיפות
        priority_weights = {
            MemoryPriority.CRITICAL: 1.0,
            MemoryPriority.VERY_HIGH: 0.9,
            MemoryPriority.HIGH: 0.7,
            MemoryPriority.MEDIUM: 0.5,
            MemoryPriority.LOW: 0.3,
            MemoryPriority.TEMPORARY: 0.1
        }
        score += priority_weights.get(self.priority, 0.5) * 0.2
        
        # בסיס על זמניות (זיכרונות עדכניים יותר רלוונטיים)
        time_diff = datetime.now() - self.last_accessed
        recency_score = max(0, 1.0 - (time_diff.total_seconds() / (30 * 24 * 3600)))  # 30 ימים
        score += recency_score * 0.2
        
        # בסיס על תדירות גישה
        access_score = min(1.0, self.access_count / 100.0)
        score += access_score * 0.1
        
        # בסיס על רלוונטיות פרגמנטים
        if self.fragments:
            avg_relevance = sum(f.relevance for f in self.fragments) / len(self.fragments)
            score += avg_relevance * 0.2
        
        return min(1.0, score)
    
    def extract_keywords(self) -> Set[str]:
        """חילוץ מילות מפתח מהזיכרון"""
        keywords = set()
        
        for fragment in self.fragments:
            if fragment.content_type == "text" and isinstance(fragment.content, str):
                # חילוץ פשוט של מילים (ניתן לשפר עם NLP)
                words = fragment.content.lower().split()
                keywords.update(word.strip('.,!?;:"()[]{}') for word in words if len(word) > 3)
        
        # הוספת תגיות מההקשר
        keywords.update(self.context.tags)
        
        return keywords
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון לשמירה"""
        return {
            'memory_id': self.memory_id,
            'memory_type': self.memory_type.value,
            'priority': self.priority.value,
            'status': self.status.value,
            'scope': self.scope.value,
            'fragments': [
                {
                    'id': f.id,
                    'content': f.content,
                    'content_type': f.content_type,
                    'encoding': f.encoding,
                    'timestamp': f.timestamp.isoformat(),
                    'source': f.source,
                    'confidence': f.confidence,
                    'relevance': f.relevance,
                    'emotional_weight': f.emotional_weight
                }
                for f in self.fragments
            ],
            'context': {
                'context_id': self.context.context_id,
                'name': self.context.name,
                'hebrew_name': self.context.hebrew_name,
                'description': self.context.description,
                'participants': self.context.participants,
                'environment': self.context.environment,
                'temporal_bounds': [
                    self.context.temporal_bounds[0].isoformat(),
                    self.context.temporal_bounds[1].isoformat() if self.context.temporal_bounds[1] else None
                ],
                'spatial_bounds': self.context.spatial_bounds,
                'emotional_tone': self.context.emotional_tone,
                'importance': self.context.importance,
                'tags': list(self.context.tags)
            },
            'created_at': self.created_at.isoformat(),
            'last_accessed': self.last_accessed.isoformat(),
            'last_modified': self.last_modified.isoformat(),
            'access_count': self.access_count,
            'modification_count': self.modification_count,
            'strength': self.strength,
            'decay_rate': self.decay_rate,
            'reinforcement_events': [event.isoformat() for event in self.reinforcement_events],
            'associations': [
                {
                    'from_memory_id': assoc.from_memory_id,
                    'to_memory_id': assoc.to_memory_id,
                    'association_type': assoc.association_type,
                    'strength': assoc.strength,
                    'bidirectional': assoc.bidirectional,
                    'confidence': assoc.confidence,
                    'created_at': assoc.created_at.isoformat()
                }
                for assoc in self.associations
            ],
            'related_memories': list(self.related_memories),
            'derived_insights': self.derived_insights,
            'behavioral_patterns': self.behavioral_patterns,
            'predictive_value': self.predictive_value,
            'is_protected': self.is_protected,
            'encryption_level': self.encryption_level,
            'access_restrictions': self.access_restrictions
        }

@dataclass
class MemoryCluster:
    """אשכול זיכרונות קשורים"""
    cluster_id: str
    name: str
    hebrew_name: str
    description: str
    memory_ids: Set[str]
    cluster_type: str  # thematic, temporal, causal, emotional, behavioral
    cohesion_score: float  # 0.0-1.0
    created_at: datetime
    last_updated: datetime
    
    # מאפיינים מרכזיים של האשכול
    central_themes: List[str] = None
    key_insights: List[str] = None
    behavioral_implications: List[str] = None
    emotional_signature: Dict[str, float] = None
    
    # סטטיסטיקות
    access_frequency: float = 0.0
    modification_frequency: float = 0.0
    growth_rate: float = 0.0
    
    def __post_init__(self):
        if self.central_themes is None:
            self.central_themes = []
        if self.key_insights is None:
            self.key_insights = []
        if self.behavioral_implications is None:
            self.behavioral_implications = []
        if self.emotional_signature is None:
            self.emotional_signature = {}
    
    def add_memory(self, memory_id: str):
        """הוספת זיכרון לאשכול"""
        self.memory_ids.add(memory_id)
        self.last_updated = datetime.now()
        self.growth_rate += 0.1
    
    def remove_memory(self, memory_id: str):
        """הסרת זיכרון מהאשכול"""
        self.memory_ids.discard(memory_id)
        self.last_updated = datetime.now()
    
    def calculate_cohesion(self, memories: Dict[str, RuntimeMemory]) -> float:
        """חישוב לכידות האשכול"""
        if len(self.memory_ids) < 2:
            return 1.0
        
        total_associations = 0
        possible_associations = len(self.memory_ids) * (len(self.memory_ids) - 1)
        
        for memory_id in self.memory_ids:
            if memory_id in memories:
                memory = memories[memory_id]
                cluster_related = self.memory_ids.intersection(memory.related_memories)
                total_associations += len(cluster_related)
        
        self.cohesion_score = total_associations / possible_associations if possible_associations > 0 else 0.0
        return self.cohesion_score

class MemoryIndex:
    """אינדקס זיכרון מתקדם"""
    
    def __init__(self):
        # אינדקסים שונים לחיפוש מהיר
        self.keyword_index: Dict[str, Set[str]] = defaultdict(set)
        self.temporal_index: Dict[str, List[str]] = defaultdict(list)  # date -> memory_ids
        self.type_index: Dict[MemoryType, Set[str]] = defaultdict(set)
        self.priority_index: Dict[MemoryPriority, Set[str]] = defaultdict(set)
        self.context_index: Dict[str, Set[str]] = defaultdict(set)
        self.participant_index: Dict[str, Set[str]] = defaultdict(set)
        self.emotional_index: Dict[str, Set[str]] = defaultdict(set)  # emotion_range -> memory_ids
        
        # אינדקס קשרים
        self.association_graph: Dict[str, Set[str]] = defaultdict(set)
    
    def add_memory(self, memory: RuntimeMemory):
        """הוספת זיכרון לאינדקס"""
        memory_id = memory.memory_id
        
        # אינדקס מילות מפתח
        keywords = memory.extract_keywords()
        for keyword in keywords:
            self.keyword_index[keyword].add(memory_id)
        
        # אינדקס זמני
        date_key = memory.created_at.strftime('%Y-%m-%d')
        self.temporal_index[date_key].append(memory_id)
        
        # אינדקס סוג
        self.type_index[memory.memory_type].add(memory_id)
        
        # אינדקס עדיפות
        self.priority_index[memory.priority].add(memory_id)
        
        # אינדקס הקשר
        self.context_index[memory.context.context_id].add(memory_id)
        
        # אינדקס משתתפים
        for participant in memory.context.participants:
            self.participant_index[participant].add(memory_id)
        
        # אינדקס רגשי
        emotional_range = self._get_emotional_range(memory.context.emotional_tone)
        self.emotional_index[emotional_range].add(memory_id)
        
        # אינדקס קשרים
        for association in memory.associations:
            self.association_graph[memory_id].add(association.to_memory_id)
            if association.bidirectional:
                self.association_graph[association.to_memory_id].add(memory_id)
    
    def remove_memory(self, memory_id: str, memory: RuntimeMemory):
        """הסרת זיכרון מהאינדקס"""
        # ניקוי מכל האינדקסים
        keywords = memory.extract_keywords()
        for keyword in keywords:
            self.keyword_index[keyword].discard(memory_id)
        
        date_key = memory.created_at.strftime('%Y-%m-%d')
        if memory_id in self.temporal_index[date_key]:
            self.temporal_index[date_key].remove(memory_id)
        
        self.type_index[memory.memory_type].discard(memory_id)
        self.priority_index[memory.priority].discard(memory_id)
        self.context_index[memory.context.context_id].discard(memory_id)
        
        for participant in memory.context.participants:
            self.participant_index[participant].discard(memory_id)
        
        emotional_range = self._get_emotional_range(memory.context.emotional_tone)
        self.emotional_index[emotional_range].discard(memory_id)
        
        # ניקוי קשרים
        for related_id in self.association_graph[memory_id]:
            self.association_graph[related_id].discard(memory_id)
        del self.association_graph[memory_id]
    
    def search_by_keywords(self, keywords: List[str]) -> Set[str]:
        """חיפוש לפי מילות מפתח"""
        if not keywords:
            return set()
        
        result_sets = [self.keyword_index[keyword.lower()] for keyword in keywords]
        return set.intersection(*result_sets) if result_sets else set()
    
    def search_by_timeframe(self, start_date: datetime, end_date: datetime) -> Set[str]:
        """חיפוש לפי טווח זמן"""
        memory_ids = set()
        current_date = start_date
        
        while current_date <= end_date:
            date_key = current_date.strftime('%Y-%m-%d')
            memory_ids.update(self.temporal_index[date_key])
            current_date += timedelta(days=1)
        
        return memory_ids
    
    def get_related_memories(self, memory_id: str, max_depth: int = 2) -> Set[str]:
        """קבלת זיכרונות קשורים עד עומק מסוים"""
        visited = set()
        to_visit = deque([(memory_id, 0)])
        
        while to_visit:
            current_id, depth = to_visit.popleft()
            
            if current_id in visited or depth > max_depth:
                continue
            
            visited.add(current_id)
            
            if depth < max_depth:
                for related_id in self.association_graph[current_id]:
                    if related_id not in visited:
                        to_visit.append((related_id, depth + 1))
        
        visited.discard(memory_id)  # הסרת הזיכרון המקורי
        return visited
    
    def _get_emotional_range(self, emotional_tone: float) -> str:
        """מיפוי טון רגשי לטווח"""
        if emotional_tone >= 0.7:
            return "very_positive"
        elif emotional_tone >= 0.3:
            return "positive"
        elif emotional_tone >= -0.3:
            return "neutral"
        elif emotional_tone >= -0.7:
            return "negative"
        else:
            return "very_negative"