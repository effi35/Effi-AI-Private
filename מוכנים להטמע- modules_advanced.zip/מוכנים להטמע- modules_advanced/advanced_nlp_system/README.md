# מערכת NLP מתקדמת - Advanced NLP System

מערכת עיבוד שפה טבעית ויצירת תוכן מתקדמת עם תמיכה מלאה בעברית ויכולות AI מתקדמות.

## 🎯 תכונות עיקריות

### 📝 יצירת תוכן מתקדמת
- **ContentEngine**: מנוע יצירת תוכן חכם עם AI
- **ContentGeneration**: מודלי יצירה מותאמים לסוגי תוכן שונים
- **GenerationTask**: משימות יצירה עם הגדרות מפורטות
- **GenerationResult**: תוצאות עם מדדי איכות ו-SEO

### 🧠 עיבוד שפה טבעית
- **HebrewTextProcessor**: עיבוד טקסט עברי מתקדם
- **TextAnalyzer**: ניתוח טקסט מקיף (סנטימנט, נושאים, ישויות)
- **ContentGenerator**: יצירת תוכן באופן אוטומטי
- **SEOAnalyzer**: ניתוח ואופטימיזציה לקידום אתרים

### 🎨 ממשק יצירה מקצועי
- **ContentStudio**: סטודיו יצירת תוכן מתקדם
- **עורך תוכן**: עורך עם הדגשת syntax ועיצוב
- **תצוגה מקדימה**: HTML ו-mobile preview
- **תבניות מוכנות**: תבניות למאמרים, בלוגים ורשתות חברתיות

### 🔧 כלים מתקדמים
- **TextUtils**: כלים לעיבוד טקסט ועברית
- **TextComparator**: השוואת טקסטים ובדיקת גניבה ספרותית
- **כלי SEO**: ניתוח מילות מפתח וקריאות
- **כלי תרגום**: תמיכה בשפות מרובות

## 🏗️ ארכיטקטורה

```
advanced_nlp_system/
├── models/                          # מבני נתונים וקונפיגורציה
│   ├── content_generation.py       # מודלי יצירת תוכן
│   ├── generation_task.py          # משימות יצירה
│   ├── generation_result.py        # תוצאות יצירה
│   ├── text_analysis.py           # ניתוח טקסט
│   └── config.py                   # הגדרות מערכת
├── core/                            # מנועי ליבה
│   └── content_engine.py          # מנוע יצירת תוכן ראשי
├── ui/                              # ממשק משתמש
│   └── content_studio.py          # סטודיו יצירת תוכן
├── utils/                           # כלים שימושיים
│   └── text_utils.py               # פונקציות עיבוד טקסט
├── module.py                       # נקודת כניסה למודול
├── requirements.txt                # תלויות
└── README.md                      # תיעוד זה
```

## 🚀 התקנה ושימוש

### דרישות מערכת
```bash
pip install nltk numpy pandas scikit-learn matplotlib tkinter textstat
```

### הפעלה בסיסית
```python
from advanced_nlp_system import AdvancedNLPSystem

# אתחול המערכת
nlp_system = AdvancedNLPSystem()

# יצירת תוכן
result = nlp_system.generate_content(
    prompt="כתוב מאמר על יתרונות הבינה המלאכותית",
    content_type="article",
    quality_level="high",
    language="hebrew"
)

print(f"תוכן שנוצר: {result['content']}")
print(f"ציון איכות: {result['quality_score']}")
```

### הפעלת סטודיו התוכן
```python
from advanced_nlp_system.ui.content_studio import main

# הפעלת ממשק גרפי
main()
```

## 📊 סוגי תוכן נתמכים

### תוכן שיווקי
- **מאמרי בלוג**: תוכן עמוק ומעניין
- **פוסטים לרשתות חברתיות**: תוכן קצר ואטרקטיבי
- **מיילים שיווקיים**: תוכן משכנע ומעורר פעולה
- **דפי נחיתה**: תוכן ממוקד המרות

### תוכן טכני
- **מאמרים טכניים**: הסברים מעמיקים
- **תיעוד**: מדריכים וטיפים
- **מדריכי הוראה**: הדרכה שלב אחר שלב
- **FAQ**: שאלות נפוצות ותשובות

### תוכן יצירתי
- **סיפורים קצרים**: נרטיב מעניין
- **שירים**: יצירה ספרותית
- **תסריטים**: דיאלוגים ותסריטי וידאו
- **תוכן בידורי**: חומר קל ומבדר

## 🔍 יכולות ניתוח מתקדמות

### ניתוח טקסט עברי
```python
from advanced_nlp_system.utils.text_utils import HebrewTextProcessor, TextAnalyzer

# עיבוד טקסט עברי
processor = HebrewTextProcessor()
cleaned_text = processor.clean_hebrew_text("טקסט עברי עם ניקוד")
tokens = processor.tokenize_hebrew(cleaned_text)
roots = processor.extract_hebrew_roots("כותבים")

# ניתוח מקיף
analyzer = TextAnalyzer()
analysis = analyzer.analyze_text("זהו טקסט לדוגמה לניתוח")

print(f"מספר מילים: {analysis.word_count}")
print(f"ציון קריאות: {analysis.readability_score}")
print(f"סנטימנט: {analysis.sentiment_score}")
print(f"נושאים: {analysis.topics}")
```

### ניתוח SEO
```python
from advanced_nlp_system.utils.text_utils import SEOAnalyzer

# ניתוח SEO מקיף
seo_analyzer = SEOAnalyzer()
seo_results = seo_analyzer.analyze_seo(
    content="תוכן המאמר כאן...",
    target_keywords=["בינה מלאכותית", "טכנולוגיה"],
    title="כותרת המאמר",
    meta_description="תיאור המאמר"
)

print(f"ציון SEO כולל: {seo_results['overall_score']}")
print(f"המלצות: {seo_results['recommendations']}")
```

## ⚡ דוגמאות שימוש מתקדמות

### יצירת מאמר בלוג מקיף
```python
generation_request = {
    'prompt': 'כתוב מאמר מקיף על השפעת הבינה המלאכותית על שוק העבודה',
    'content_type': 'blog_post',
    'quality_level': 'expert',
    'target_audience': 'professionals',
    'content_length': 'long',
    'include_seo': True,
    'keywords': ['בינה מלאכותית', 'שוק עבודה', 'אוטומציה'],
    'tone': 'professional',
    'language': 'hebrew'
}

result = nlp_system.generate_content(generation_request)
```

### יצירת תוכן לרשתות חברתיות
```python
social_media_request = {
    'prompt': 'צור פוסט אטרקטיבי על טיפים לשיפור הפרודוקטיביות',
    'content_type': 'social_media',
    'platform': 'facebook',
    'include_hashtags': True,
    'include_emojis': True,
    'max_length': 280,
    'tone': 'casual',
    'call_to_action': True
}

social_result = nlp_system.generate_content(social_media_request)
```

### יצירת מייל שיווקי
```python
email_request = {
    'prompt': 'כתוב מייל שיווקי למוצר טכנולוגי חדש',
    'content_type': 'marketing_email',
    'include_subject': True,
    'personalization': True,
    'call_to_action': 'schedule_demo',
    'tone': 'persuasive',
    'urgency_level': 'medium'
}

email_result = nlp_system.generate_content(email_request)
```

## 🛠️ הגדרות מתקדמות

### קובץ config.py
```python
NLP_CONFIG = {
    "default_language": "hebrew",        # שפת ברירת מחדל
    "max_content_length": 5000,          # אורך תוכן מקסימלי
    "quality_threshold": 0.7,            # סף איכות מינימלי
    "enable_seo_analysis": True,         # הפעלת ניתוח SEO
    "creativity_level": 0.7,             # רמת יצירתיות (0-1)
    "enable_plagiarism_check": True,     # בדיקת גניבה ספרותית
    "max_generation_time": 60,           # זמן יצירה מקסימלי בשניות
    "enable_auto_correction": True       # תיקון אוטומטי
}
```

### הגדרות יצירת תוכן
```python
GENERATION_CONFIG = {
    "templates": {
        "blog_post": {
            "structure": ["intro", "body", "conclusion"],
            "min_paragraphs": 5,
            "include_subheadings": True
        },
        "social_media": {
            "max_length": 280,
            "include_hashtags": True,
            "optimal_engagement": True
        },
        "email": {
            "include_subject": True,
            "personalization_tokens": True,
            "call_to_action_required": True
        }
    }
}
```

## 📈 מדדי איכות וביצועים

### מדדי איכות תוכן
- **ציון קריאות**: 0-100 (גבוה יותר = קל יותר לקריאה)
- **ציון SEO**: 0-100 (התאמה למנועי חיפוש)
- **ציון יצירתיות**: 0-1 (רמת חדשנות התוכן)
- **ציון רלוונטיות**: 0-1 (התאמה לפרומפט)

### ביצועי מערכת
```python
# קבלת סטטיסטיקות ביצועים
performance_stats = nlp_system.get_performance_stats()

print(f"זמן יצירה ממוצע: {performance_stats['avg_generation_time']} שניות")
print(f"איכות ממוצעת: {performance_stats['avg_quality_score']}")
print(f"תוכן שנוצר היום: {performance_stats['content_generated_today']}")
```

## 🎨 תבניות ועיצוב

### תבניות מוכנות
```python
# טעינת תבנית מוכנה
template_manager = nlp_system.get_template_manager()

# תבניות זמינות
templates = template_manager.get_available_templates()
print("תבניות זמינות:", templates)

# שימוש בתבנית
result = nlp_system.generate_from_template(
    template_name="tech_article",
    variables={
        "topic": "בינה מלאכותית",
        "audience": "מקצועי",
        "length": "medium"
    }
)
```

### יצירת תבנית מותאמת
```python
custom_template = {
    "name": "product_review",
    "structure": [
        "product_introduction",
        "features_analysis", 
        "pros_and_cons",
        "verdict_and_rating"
    ],
    "required_variables": ["product_name", "category"],
    "optional_variables": ["price", "brand"],
    "tone": "objective",
    "length": "medium"
}

template_manager.add_template(custom_template)
```

## 🔧 פיתוח והרחבה

### הוספת מנוע יצירה מותאם
```python
from advanced_nlp_system.core.content_engine import ContentEngine

class CustomContentEngine(ContentEngine):
    def custom_generation_method(self, prompt, **kwargs):
        # יישום מותאם אישית
        pass
    
    def process_with_custom_ai(self, content):
        # עיבוד עם AI מותאם
        pass
```

### יצירת מנתח טקסט מותאם
```python
from advanced_nlp_system.utils.text_utils import TextAnalyzer

class CustomTextAnalyzer(TextAnalyzer):
    def analyze_custom_metrics(self, text):
        # ניתוח מותאם אישית
        return {
            'custom_score': 0.85,
            'special_features': []
        }
```

### הוספת תמיכה בשפה חדשה
```python
class NewLanguageProcessor:
    def __init__(self):
        self.language_code = "new_lang"
    
    def tokenize(self, text):
        # פיצול לטוקנים
        pass
    
    def analyze_sentiment(self, text):
        # ניתוח סנטימנט
        pass
    
    def extract_keywords(self, text):
        # חילוץ מילות מפתח
        pass

# רישום השפה החדשה
nlp_system.register_language_processor("new_lang", NewLanguageProcessor())
```

## 🧪 בדיקות ואיכות

### הרצת בדיקות
```bash
# בדיקות יחידה
python -m pytest tests/unit/

# בדיקות יצירת תוכן
python tests/test_content_generation.py

# בדיקות עיבוד עברית
python tests/test_hebrew_processing.py

# בדיקות ביצועים
python tests/performance_tests.py
```

### בדיקת איכות תוכן
```python
from advanced_nlp_system.utils.text_utils import validate_text_quality

# בדיקת איכות טקסט
quality_result = validate_text_quality("טקסט לבדיקה...")

if quality_result['is_valid']:
    print(f"ציון איכות: {quality_result['score']}")
else:
    print(f"בעיות: {quality_result['issues']}")
```

## 🌐 תמיכה בעברית וRTL

### עיבוד טקסט עברי מתקדם
```python
from advanced_nlp_system.utils.text_utils import HebrewTextProcessor

# עיבוד עברית מתקדם
processor = HebrewTextProcessor()

# הסרת ניקוד
text_without_nikud = processor.remove_nikud("טֶקְסְט עִם נִקּוּד")

# פיצול למילים
hebrew_words = processor.tokenize_hebrew("זה טקסט בעברית")

# חילוץ שורשים
roots = processor.extract_hebrew_roots("כותבים")  # ['כתב']

# בדיקה אם טקסט הוא עברי
is_hebrew = processor.is_hebrew_text("זה טקסט בעברית")  # True
```

### תמיכה בכיוון כתיבה RTL
- ממשק המשתמש מותאם לכיוון ימין-לשמאל
- עיבוד טקסט עברי מתקדם
- תמיכה בפיסוק ועיצוב עברי
- ניתוח דקדוק עברי בסיסי

## 📊 API ושילובים

### REST API
```python
from flask import Flask, request, jsonify

app = Flask(__name__)
nlp_system = AdvancedNLPSystem()

@app.route('/generate', methods=['POST'])
def generate_content():
    data = request.json
    result = nlp_system.generate_content(**data)
    return jsonify(result)

@app.route('/analyze', methods=['POST'])
def analyze_text():
    data = request.json
    analysis = nlp_system.analyze_text(data['text'])
    return jsonify(analysis.to_dict())

@app.route('/seo', methods=['POST'])
def analyze_seo():
    data = request.json
    seo_results = nlp_system.analyze_seo(**data)
    return jsonify(seo_results)
```

### WebSocket לעדכונים בזמן אמת
```python
import socketio

sio = socketio.Server()

@sio.event
def generate_content(sid, data):
    def progress_callback(progress):
        sio.emit('generation_progress', {'progress': progress}, room=sid)
    
    result = nlp_system.generate_content(
        progress_callback=progress_callback,
        **data
    )
    sio.emit('generation_complete', result, room=sid)
```

## 📞 תמיכה ועזרה

### פתרון בעיות נפוצות

1. **שגיאות NLTK**
   ```python
   import nltk
   nltk.download('punkt')
   nltk.download('stopwords')
   ```

2. **בעיות עם עברית**
   ```bash
   pip install hebrew-tokenizer bidi
   ```

3. **זיכרון גבוה**
   ```python
   # הקטנת מטמון
   nlp_system.reduce_cache_size()
   
   # הגבלת אורך תוכן
   nlp_system.set_max_content_length(1000)
   ```

4. **ביצועים איטיים**
   ```python
   # הפעלת מצב ביצועים
   nlp_system.enable_performance_mode()
   
   # הגדלת thread pool
   nlp_system.set_worker_threads(4)
   ```

### לוגים ודיבוג
```python
import logging

# הפעלת דיבוג מפורט
logging.basicConfig(level=logging.DEBUG)

# קבלת לוגי יצירה
generation_logs = nlp_system.get_generation_logs()
for log in generation_logs:
    print(f"[{log['timestamp']}] {log['message']}")
```

## 🔄 עדכונים ושדרוגים

### מהדורה נוכחית: v1.0.0
- יצירת תוכן בעברית ואנגלית
- ניתוח SEO מתקדם
- ממשק משתמש גרפי
- תמיכה מלאה בעברית

### תכונות מתוכננות v1.1.0
- שילוב עם GPT ו-AI מתקדמים
- תבניות נוספות
- ממשק Web responsive
- יצירת תמונות וגרפיקה

### תכונות מתוכננות v1.2.0
- זיהוי קול ודיבור
- תרגום אוטומטי
- אנליטיקה מתקדמת
- שיתוף פעולה מרובה משתמשים

---

**מערכת NLP מתקדמת** - פותח במסגרת **Effi AI Private System**  
© 2024 Effi AI Systems - כל הזכויות שמורות  

יצירת תוכן חכם בעברית ובשפות נוספות 📝🧠✨