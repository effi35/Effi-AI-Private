"""
מודול מערכת NLP מתקדמת - Advanced NLP System
נקודת כניסה ראשית למערכת עיבוד שפה טבעית ויצירת תוכן
"""

import asyncio
import logging
import threading
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Callable
from pathlib import Path
import numpy as np
from collections import defaultdict, Counter

# ייבוא רכיבי המערכת
from .models.content_generation import ContentGeneration, GenerationMetrics, QualityLevel
from .models.generation_task import GenerationTask, TaskStatus, TaskPriority
from .models.generation_result import GenerationResult
from .models.text_analysis import TextAnalysis, SentimentResult
from .models.config import NLPConfig

from .core.content_engine import ContentEngine

from .utils.text_utils import (
    HebrewTextProcessor, TextAnalyzer, ContentGenerator, 
    SEOAnalyzer, TextComparator, clean_text, extract_keywords,
    calculate_readability, analyze_sentiment, generate_summary
)

class AdvancedNLPSystem:
    """
    מערכת NLP מתקדמת לעיבוד שפה טבעית ויצירת תוכן
    מנהלת יצירת תוכן, ניתוח טקסט ואופטימיזציה
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        אתחול מערכת ה-NLP
        
        Args:
            config_path: נתיב לקובץ הגדרות (אופציונלי)
        """
        # טעינת הגדרות
        self.config = NLPConfig()
        if config_path:
            self.config.load_from_file(config_path)
        
        # אתחול רכיבי המערכת
        self._init_components()
        
        # אתחול מנוע התוכן
        self.content_engine = ContentEngine(
            config=self.config,
            hebrew_processor=self.hebrew_processor,
            text_analyzer=self.text_analyzer
        )
        
        # מצב המערכת
        self.is_running = False
        self.start_time = None
        self.generation_history = []
        self.active_tasks = {}
        self.template_manager = None
        
        # סטטיסטיקות
        self.stats = {
            'total_generations': 0,
            'successful_generations': 0,
            'total_words_generated': 0,
            'avg_quality_score': 0.0,
            'avg_generation_time': 0.0
        }
        
        # לוגינג
        self.logger = logging.getLogger(__name__)
        self.logger.info("מערכת NLP מתקדמת אותחלה בהצלחה")
    
    def _init_components(self):
        """אתחול רכיבי המערכת"""
        # מעבד טקסט עברי
        self.hebrew_processor = HebrewTextProcessor()
        
        # מנתח טקסט
        self.text_analyzer = TextAnalyzer()
        
        # מחולל תוכן
        self.content_generator = ContentGenerator()
        
        # מנתח SEO
        self.seo_analyzer = SEOAnalyzer()
        
        # משווה טקסטים
        self.text_comparator = TextComparator()
        
        # מנהל תבניות
        self._init_template_manager()
        
        self.logger.info("רכיבי המערכת אותחלו")
    
    def _init_template_manager(self):
        """אתחול מנהל התבניות"""
        self.templates = {
            'blog_post': {
                'structure': ['introduction', 'main_content', 'conclusion'],
                'min_length': 500,
                'include_headings': True,
                'seo_optimized': True
            },
            'social_media': {
                'max_length': 280,
                'include_hashtags': True,
                'engaging_tone': True,
                'call_to_action': True
            },
            'email_marketing': {
                'include_subject': True,
                'personalization': True,
                'call_to_action': True,
                'professional_tone': True
            },
            'technical_article': {
                'structure': ['abstract', 'introduction', 'methodology', 'results', 'conclusion'],
                'include_references': True,
                'formal_tone': True,
                'detailed_explanations': True
            }
        }
        
        self.logger.info(f"נטענו {len(self.templates)} תבניות")
    
    async def start_system(self) -> bool:
        """
        הפעלת המערכת
        
        Returns:
            bool: True אם ההפעלה הצליחה
        """
        try:
            if self.is_running:
                self.logger.warning("המערכת כבר פועלת")
                return True
            
            # הפעלת מנוע התוכן
            await self.content_engine.start()
            
            # הפעלת משימות רקע
            self._start_background_tasks()
            
            self.is_running = True
            self.start_time = datetime.now()
            
            self.logger.info("מערכת NLP מתקדמת הופעלה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת המערכת: {e}")
            return False
    
    async def stop_system(self) -> bool:
        """
        עצירת המערכת
        
        Returns:
            bool: True אם העצירה הצליחה
        """
        try:
            if not self.is_running:
                self.logger.warning("המערכת כבר מועצרת")
                return True
            
            # עצירת כל המשימות הפעילות
            await self._stop_all_tasks()
            
            # עצירת מנוע התוכן
            self.content_engine.shutdown()
            
            # שמירת סטטיסטיקות
            self._save_statistics()
            
            self.is_running = False
            
            self.logger.info("מערכת NLP מתקדמת נעצרה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת המערכת: {e}")
            return False
    
    def _start_background_tasks(self):
        """הפעלת משימות רקע"""
        # משימת עדכון סטטיסטיקות
        stats_thread = threading.Thread(
            target=self._statistics_loop, 
            daemon=True
        )
        stats_thread.start()
        
        # משימת ניקוי היסטוריה
        cleanup_thread = threading.Thread(
            target=self._cleanup_loop, 
            daemon=True
        )
        cleanup_thread.start()
        
        self.logger.info("משימות רקע הופעלו")
    
    def _statistics_loop(self):
        """לולאת עדכון סטטיסטיקות"""
        while self.is_running:
            try:
                self._update_statistics()
                threading.Event().wait(300)  # כל 5 דקות
                
            except Exception as e:
                self.logger.error(f"שגיאה בעדכון סטטיסטיקות: {e}")
    
    def _cleanup_loop(self):
        """לולאת ניקוי היסטוריה"""
        while self.is_running:
            try:
                self._cleanup_old_history()
                threading.Event().wait(3600)  # כל שעה
                
            except Exception as e:
                self.logger.error(f"שגיאה בניקוי היסטוריה: {e}")
    
    # ========== יצירת תוכן ==========
    
    async def generate_content(self, prompt: str = None,
                             content_type: str = "general",
                             quality_level: str = "high",
                             language: str = "hebrew",
                             target_audience: str = "general",
                             tone: str = "neutral",
                             length: str = "medium",
                             keywords: List[str] = None,
                             include_seo: bool = False,
                             template_name: str = None,
                             custom_instructions: str = None,
                             progress_callback: Callable = None) -> Dict[str, Any]:
        """
        יצירת תוכן מתקדמת
        
        Args:
            prompt: הנושא או הפרומפט ליצירה
            content_type: סוג התוכן (blog_post, social_media, email, etc.)
            quality_level: רמת איכות (basic, good, high, expert)
            language: שפה (hebrew, english, etc.)
            target_audience: קהל יעד
            tone: טון הכתיבה (formal, casual, professional, etc.)
            length: אורך התוכן (short, medium, long)
            keywords: מילות מפתח לשילוב
            include_seo: האם לכלול אופטימיזצית SEO
            template_name: שם תבנית לשימוש
            custom_instructions: הוראות מותאמות אישית
            progress_callback: פונקציה לעדכון התקדמות
        
        Returns:
            Dict[str, Any]: תוצאות יצירת התוכן
        """
        try:
            if not prompt and not template_name:
                return {
                    'success': False,
                    'error': 'נדרש פרומפט או שם תבנית',
                    'content': '',
                    'generation_time': 0
                }
            
            start_time = datetime.now()
            
            # יצירת אובייקט יצירה
            generation = ContentGeneration(
                prompt=prompt or f"יצירת תוכן מסוג {content_type}",
                content_type=content_type,
                quality_level=QualityLevel[quality_level.upper()],
                language=language,
                target_audience=target_audience,
                tone=tone,
                max_length=self._get_length_limit(length),
                keywords=keywords or [],
                seo_optimization=include_seo,
                custom_instructions=custom_instructions
            )
            
            # יצירת משימה
            task = GenerationTask(
                generation=generation,
                template_name=template_name,
                priority=TaskPriority.NORMAL
            )
            
            # הוספת callback להתקדמות
            if progress_callback:
                task.progress_callback = progress_callback
            
            # רישום משימה פעילה
            self.active_tasks[task.task_id] = task
            
            try:
                # ביצוע היצירה
                if template_name and template_name in self.templates:
                    result = await self._generate_from_template(task)
                else:
                    result = await self._generate_free_form(task)
                
                # חישוב זמן יצירה
                generation_time = (datetime.now() - start_time).total_seconds()
                result.generation_time = generation_time
                
                # הוספה להיסטוריה
                self._add_to_history(task, result)
                
                # עדכון סטטיסטיקות
                self._update_generation_stats(result)
                
                return result.to_dict()
                
            finally:
                # הסרת משימה מרשימת פעילות
                if task.task_id in self.active_tasks:
                    del self.active_tasks[task.task_id]
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת תוכן: {e}")
            return {
                'success': False,
                'error': f'שגיאה פנימית: {str(e)}',
                'content': '',
                'generation_time': 0
            }
    
    async def _generate_from_template(self, task: GenerationTask) -> GenerationResult:
        """יצירת תוכן מתבנית"""
        template = self.templates[task.template_name]
        generation = task.generation
        
        # התאמת הגדרות לפי התבנית
        if 'max_length' in template:
            generation.max_length = min(generation.max_length, template['max_length'])
        
        # יצירת תוכן בעזרת המנוע
        result = await self.content_engine.generate_content(generation)
        
        # עיבוד נוסף לפי התבנית
        if template.get('include_headings'):
            result.content = self._add_headings(result.content)
        
        if template.get('include_hashtags') and generation.content_type == 'social_media':
            result.content = self._add_hashtags(result.content, generation.keywords)
        
        if template.get('seo_optimized'):
            result = await self._optimize_for_seo(result, generation)
        
        return result
    
    async def _generate_free_form(self, task: GenerationTask) -> GenerationResult:
        """יצירת תוכן חופשי"""
        generation = task.generation
        
        # יצירת תוכן בעזרת המנוע
        result = await self.content_engine.generate_content(generation)
        
        # עיבודים נוספים
        if generation.seo_optimization:
            result = await self._optimize_for_seo(result, generation)
        
        return result
    
    def _get_length_limit(self, length: str) -> int:
        """קבלת מגבלת אורך לפי הגדרה"""
        length_limits = {
            'short': 200,
            'medium': 800,
            'long': 2000,
            'very_long': 5000
        }
        return length_limits.get(length, 800)
    
    def _add_headings(self, content: str) -> str:
        """הוספת כותרות משנה לתוכן"""
        paragraphs = content.split('\n\n')
        if len(paragraphs) < 3:
            return content
        
        # הוספת כותרות לפסקאות ארוכות
        enhanced_content = []
        for i, paragraph in enumerate(paragraphs):
            if i > 0 and len(paragraph.split()) > 50:
                # יצירת כותרת בהתבסס על התוכן
                first_sentence = paragraph.split('.')[0]
                if len(first_sentence.split()) < 8:
                    heading = f"## {first_sentence}\n\n"
                    paragraph = paragraph[len(first_sentence)+1:].strip()
                    enhanced_content.append(heading + paragraph)
                else:
                    enhanced_content.append(paragraph)
            else:
                enhanced_content.append(paragraph)
        
        return '\n\n'.join(enhanced_content)
    
    def _add_hashtags(self, content: str, keywords: List[str]) -> str:
        """הוספת hashtags לתוכן רשתות חברתיות"""
        if not keywords:
            keywords = extract_keywords(content, max_keywords=3)
        
        hashtags = []
        for keyword in keywords[:5]:  # מקסימום 5 hashtags
            # ניקוי מילת המפתח ויצירת hashtag
            clean_keyword = ''.join(keyword.split())
            if clean_keyword:
                hashtags.append(f"#{clean_keyword}")
        
        if hashtags:
            content += f"\n\n{' '.join(hashtags)}"
        
        return content
    
    async def _optimize_for_seo(self, result: GenerationResult, 
                              generation: ContentGeneration) -> GenerationResult:
        """אופטימיזציה לקידום אתרים"""
        try:
            # ניתוח SEO
            seo_analysis = self.seo_analyzer.analyze_seo(
                content=result.content,
                target_keywords=generation.keywords
            )
            
            # שיפורים אוטומטיים
            improved_content = result.content
            
            # הוספת מילות מפתח אם חסרות
            if seo_analysis['keyword_analysis']['score'] < 70:
                improved_content = self._enhance_keywords(
                    improved_content, generation.keywords
                )
            
            # שיפור מבנה אם נדרש
            if not seo_analysis['content_analysis']['has_headings']:
                improved_content = self._add_headings(improved_content)
            
            # עדכון התוצאה
            result.content = improved_content
            result.seo_score = seo_analysis['overall_score']
            result.seo_recommendations = seo_analysis['recommendations']
            
            return result
            
        except Exception as e:
            self.logger.error(f"שגיאה באופטימיזצית SEO: {e}")
            return result
    
    def _enhance_keywords(self, content: str, keywords: List[str]) -> str:
        """שיפור שילוב מילות מפתח בתוכן"""
        if not keywords:
            return content
        
        paragraphs = content.split('\n\n')
        enhanced_paragraphs = []
        
        for i, paragraph in enumerate(paragraphs):
            enhanced_paragraph = paragraph
            
            # הוספת מילת מפתח לפסקה אם היא ארוכה מספיק
            if len(paragraph.split()) > 30 and i < len(keywords):
                keyword = keywords[i % len(keywords)]
                if keyword.lower() not in paragraph.lower():
                    # הוספת המילה באופן טבעי
                    sentences = paragraph.split('.')
                    if len(sentences) > 1:
                        enhanced_paragraph = f"{sentences[0]}. בהקשר של {keyword}, {'. '.join(sentences[1:])}"
            
            enhanced_paragraphs.append(enhanced_paragraph)
        
        return '\n\n'.join(enhanced_paragraphs)
    
    def generate_content_sync(self, **kwargs) -> Dict[str, Any]:
        """יצירת תוכן סינכרונית (wrapper לפונקציה אסינכרונית)"""
        return asyncio.run(self.generate_content(**kwargs))
    
    # ========== ניתוח טקסט ==========
    
    def analyze_text(self, text: str, language: str = "auto") -> TextAnalysis:
        """
        ניתוח מקיף של טקסט
        
        Args:
            text: הטקסט לניתוח
            language: שפה (auto לזיהוי אוטומטי)
        
        Returns:
            TextAnalysis: תוצאות הניתוח
        """
        try:
            return self.text_analyzer.analyze_text(text)
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח טקסט: {e}")
            return TextAnalysis(
                text="", word_count=0, sentence_count=0, paragraph_count=0,
                avg_words_per_sentence=0.0, readability_score=0.0,
                sentiment_score=0.0, language="unknown", topics=[], keywords=[], entities=[]
            )
    
    def analyze_sentiment(self, text: str, language: str = "auto") -> float:
        """ניתוח סנטימנט"""
        try:
            return analyze_sentiment(text, language)
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח סנטימנט: {e}")
            return 0.0
    
    def extract_keywords(self, text: str, max_keywords: int = 10,
                        language: str = "auto") -> List[str]:
        """חילוץ מילות מפתח"""
        try:
            return extract_keywords(text, max_keywords, language)
        except Exception as e:
            self.logger.error(f"שגיאה בחילוץ מילות מפתח: {e}")
            return []
    
    def calculate_readability(self, text: str, language: str = "auto") -> float:
        """חישוב ציון קריאות"""
        try:
            return calculate_readability(text, language)
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב קריאות: {e}")
            return 0.0
    
    def generate_summary(self, text: str, max_sentences: int = 3) -> str:
        """יצירת תקציר"""
        try:
            return generate_summary(text, max_sentences)
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת תקציר: {e}")
            return ""
    
    # ========== ניתוח SEO ==========
    
    def analyze_seo(self, content: str, title: str = "",
                   meta_description: str = "", keywords: List[str] = None) -> Dict[str, Any]:
        """ניתוח SEO מקיף"""
        try:
            return self.seo_analyzer.analyze_seo(
                content=content,
                target_keywords=keywords or [],
                title=title,
                meta_description=meta_description
            )
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח SEO: {e}")
            return {
                'overall_score': 0,
                'recommendations': [f'שגיאה בניתוח: {str(e)}']
            }
    
    def suggest_keywords(self, topic: str, count: int = 10) -> List[str]:
        """הצעת מילות מפתח לנושא"""
        try:
            # יצירת תוכן קצר על הנושא
            sample_content = self.content_generator.generate_content(
                content_type="article",
                topic=topic,
                length=200
            )
            
            # חילוץ מילות מפתח מהתוכן שנוצר
            keywords = self.extract_keywords(sample_content, count)
            
            return keywords
            
        except Exception as e:
            self.logger.error(f"שגיאה בהצעת מילות מפתח: {e}")
            return []
    
    def optimize_content_for_seo(self, content: str, target_keywords: List[str]) -> str:
        """אופטימיזציה של תוכן קיים ל-SEO"""
        try:
            # ניתוח SEO נוכחי
            current_seo = self.analyze_seo(content, keywords=target_keywords)
            
            optimized_content = content
            
            # שיפורים בהתבסס על הניתוח
            if current_seo['keyword_analysis']['score'] < 70:
                optimized_content = self._enhance_keywords(optimized_content, target_keywords)
            
            if not current_seo['content_analysis']['has_headings']:
                optimized_content = self._add_headings(optimized_content)
            
            return optimized_content
            
        except Exception as e:
            self.logger.error(f"שגיאה באופטימיזציה: {e}")
            return content
    
    # ========== השוואת טקסטים ==========
    
    def compare_texts(self, text1: str, text2: str) -> Dict[str, Any]:
        """השוואת שני טקסטים"""
        try:
            similarity = self.text_comparator.calculate_similarity(text1, text2)
            differences = self.text_comparator.find_differences(text1, text2)
            
            return {
                'similarity': similarity,
                'similarity_percent': similarity * 100,
                'differences': differences,
                'is_similar': similarity > 0.8
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בהשוואת טקסטים: {e}")
            return {
                'similarity': 0.0,
                'similarity_percent': 0.0,
                'differences': {'additions': [], 'deletions': []},
                'is_similar': False,
                'error': str(e)
            }
    
    def check_plagiarism(self, text: str, reference_texts: List[str],
                        threshold: float = 0.8) -> Dict[str, Any]:
        """בדיקת גניבה ספרותית"""
        try:
            return self.text_comparator.check_plagiarism(text, reference_texts, threshold)
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת גניבה ספרותית: {e}")
            return {
                'is_plagiarized': False,
                'max_similarity': 0.0,
                'similar_texts': [],
                'error': str(e)
            }
    
    # ========== ניהול תבניות ==========
    
    def get_available_templates(self) -> List[str]:
        """קבלת רשימת תבניות זמינות"""
        return list(self.templates.keys())
    
    def get_template_info(self, template_name: str) -> Optional[Dict[str, Any]]:
        """קבלת מידע על תבנית"""
        return self.templates.get(template_name)
    
    def add_template(self, name: str, template_config: Dict[str, Any]) -> bool:
        """הוספת תבנית חדשה"""
        try:
            self.templates[name] = template_config
            self.logger.info(f"תבנית '{name}' נוספה")
            return True
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת תבנית: {e}")
            return False
    
    def remove_template(self, name: str) -> bool:
        """הסרת תבנית"""
        try:
            if name in self.templates:
                del self.templates[name]
                self.logger.info(f"תבנית '{name}' הוסרה")
                return True
            return False
        except Exception as e:
            self.logger.error(f"שגיאה בהסרת תבנית: {e}")
            return False
    
    # ========== סטטיסטיקות וניטור ==========
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות ביצועים"""
        try:
            stats = self.stats.copy()
            
            # הוספת מידע נוסף
            stats.update({
                'system_running': self.is_running,
                'active_tasks': len(self.active_tasks),
                'total_templates': len(self.templates),
                'history_size': len(self.generation_history)
            })
            
            # זמן פעילות
            if self.start_time:
                uptime = datetime.now() - self.start_time
                stats['uptime_hours'] = uptime.total_seconds() / 3600
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    def get_generation_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """קבלת היסטוריית יצירה"""
        try:
            return self.generation_history[-limit:] if limit else self.generation_history
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת היסטוריה: {e}")
            return []
    
    def get_generation_logs(self) -> List[Dict[str, Any]]:
        """קבלת לוגי יצירה"""
        # יישום פשוט - ניתן להרחיב
        return [
            {
                'timestamp': datetime.now(),
                'level': 'INFO',
                'message': 'מערכת פועלת תקין'
            }
        ]
    
    def _update_statistics(self):
        """עדכון סטטיסטיקות"""
        try:
            if self.generation_history:
                # חישוב ממוצעים
                successful = [h for h in self.generation_history if h.get('success', False)]
                
                if successful:
                    self.stats['successful_generations'] = len(successful)
                    self.stats['avg_quality_score'] = np.mean([
                        h.get('quality_score', 0) for h in successful
                    ])
                    self.stats['avg_generation_time'] = np.mean([
                        h.get('generation_time', 0) for h in successful
                    ])
                    self.stats['total_words_generated'] = sum([
                        h.get('word_count', 0) for h in successful
                    ])
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון סטטיסטיקות: {e}")
    
    def _add_to_history(self, task: GenerationTask, result: GenerationResult):
        """הוספה להיסטוריית יצירה"""
        try:
            history_entry = {
                'timestamp': datetime.now(),
                'task_id': task.task_id,
                'content_type': task.generation.content_type,
                'language': task.generation.language,
                'success': result.success,
                'quality_score': result.quality_score,
                'generation_time': result.generation_time,
                'word_count': len(result.content.split()) if result.content else 0,
                'template_used': task.template_name,
                'error': result.error if not result.success else None
            }
            
            self.generation_history.append(history_entry)
            
            # שמירה של 1000 רשומות אחרונות
            if len(self.generation_history) > 1000:
                self.generation_history = self.generation_history[-1000:]
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספה להיסטוריה: {e}")
    
    def _update_generation_stats(self, result: GenerationResult):
        """עדכון סטטיסטיקות יצירה"""
        try:
            self.stats['total_generations'] += 1
            
            if result.success:
                self.stats['successful_generations'] += 1
                
                # עדכון ממוצעים
                total_successful = self.stats['successful_generations']
                
                # ציון איכות ממוצע
                current_avg_quality = self.stats['avg_quality_score']
                new_avg_quality = (current_avg_quality * (total_successful - 1) + result.quality_score) / total_successful
                self.stats['avg_quality_score'] = new_avg_quality
                
                # זמן יצירה ממוצע
                current_avg_time = self.stats['avg_generation_time']
                new_avg_time = (current_avg_time * (total_successful - 1) + result.generation_time) / total_successful
                self.stats['avg_generation_time'] = new_avg_time
                
                # סה"כ מילים
                word_count = len(result.content.split()) if result.content else 0
                self.stats['total_words_generated'] += word_count
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון סטטיסטיקות יצירה: {e}")
    
    def _cleanup_old_history(self):
        """ניקוי היסטוריה ישנה"""
        try:
            if len(self.generation_history) > 500:
                # שמירת 500 רשומות אחרונות בלבד
                self.generation_history = self.generation_history[-500:]
                self.logger.info("היסטוריה ישנה נוקתה")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי היסטוריה: {e}")
    
    def _save_statistics(self):
        """שמירת סטטיסטיקות לקובץ"""
        try:
            stats_file = Path("nlp_system_stats.json")
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(self.stats, f, ensure_ascii=False, indent=2, default=str)
            
            self.logger.info("סטטיסטיקות נשמרו")
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת סטטיסטיקות: {e}")
    
    async def _stop_all_tasks(self):
        """עצירת כל המשימות הפעילות"""
        try:
            task_ids = list(self.active_tasks.keys())
            
            for task_id in task_ids:
                if task_id in self.active_tasks:
                    task = self.active_tasks[task_id]
                    task.status = TaskStatus.CANCELLED
                    del self.active_tasks[task_id]
            
            self.logger.info(f"נעצרו {len(task_ids)} משימות")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת משימות: {e}")
    
    # ========== הגדרות ותצורה ==========
    
    def update_config(self, **config_updates):
        """עדכון הגדרות מערכת"""
        try:
            for key, value in config_updates.items():
                self.config.set(key, value)
            
            self.logger.info(f"הגדרות עודכנו: {config_updates}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון הגדרות: {e}")
    
    def get_config(self) -> Dict[str, Any]:
        """קבלת הגדרות נוכחיות"""
        return self.config.to_dict()
    
    # ========== פונקציות נוספות ==========
    
    def reduce_cache_size(self):
        """הקטנת גודל מטמון"""
        try:
            # ניקוי היסטוריה
            if len(self.generation_history) > 100:
                self.generation_history = self.generation_history[-100:]
            
            # ניקוי מטמון במנוע התוכן
            if hasattr(self.content_engine, 'clear_cache'):
                self.content_engine.clear_cache()
            
            self.logger.info("מטמון הוקטן")
            
        except Exception as e:
            self.logger.error(f"שגיאה בהקטנת מטמון: {e}")
    
    def set_max_content_length(self, max_length: int):
        """הגדרת אורך תוכן מקסימלי"""
        self.config.set('max_content_length', max_length)
        self.logger.info(f"אורך תוכן מקסימלי עודכן ל-{max_length}")
    
    def enable_performance_mode(self):
        """הפעלת מצב ביצועים"""
        self.config.set('performance_mode', True)
        self.config.set('quality_threshold', 0.5)  # הורדת סף איכות
        self.logger.info("מצב ביצועים הופעל")
    
    def set_worker_threads(self, thread_count: int):
        """הגדרת מספר threads למעבדים"""
        if hasattr(self.content_engine, 'set_thread_count'):
            self.content_engine.set_thread_count(thread_count)
            self.logger.info(f"מספר threads עודכן ל-{thread_count}")

# ========== פונקציות עזר למודול ==========

def create_nlp_system(config_path: str = None) -> AdvancedNLPSystem:
    """
    יצירת מערכת NLP חדשה
    
    Args:
        config_path: נתיב לקובץ הגדרות
    
    Returns:
        AdvancedNLPSystem: מערכת NLP מאותחלת
    """
    return AdvancedNLPSystem(config_path)

async def run_nlp_system(config_path: str = None):
    """
    הפעלת מערכת NLP כתהליך עצמאי
    
    Args:
        config_path: נתיב לקובץ הגדרות
    """
    system = create_nlp_system(config_path)
    
    try:
        # הפעלת המערכת
        success = await system.start_system()
        if not success:
            logging.error("כשל בהפעלת מערכת NLP")
            return
        
        logging.info("מערכת NLP מתקדמת פועלת - לחץ Ctrl+C לעצירה")
        
        # לולאת פעילות ראשית
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            logging.info("התקבל סיגנל עצירה")
    
    finally:
        # עצירת המערכת
        await system.stop_system()
        logging.info("מערכת NLP מתקדמת נעצרה")

def generate_content_cli():
    """ממשק שורת פקודה ליצירת תוכן"""
    import argparse
    
    parser = argparse.ArgumentParser(description='מערכת NLP מתקדמת - יצירת תוכן')
    parser.add_argument('--prompt', '-p', required=True, help='הפרומפט ליצירה')
    parser.add_argument('--type', '-t', default='general', help='סוג התוכן')
    parser.add_argument('--quality', '-q', default='high', 
                       choices=['basic', 'good', 'high', 'expert'],
                       help='רמת איכות')
    parser.add_argument('--language', '-l', default='hebrew', help='שפה')
    parser.add_argument('--length', default='medium', 
                       choices=['short', 'medium', 'long'],
                       help='אורך התוכן')
    parser.add_argument('--keywords', '-k', nargs='*', help='מילות מפתח')
    parser.add_argument('--seo', action='store_true', help='אופטימיזצית SEO')
    
    args = parser.parse_args()
    
    # יצירת מערכת NLP
    system = create_nlp_system()
    
    try:
        # הפעלת המערכת
        asyncio.run(system.start_system())
        
        # יצירת התוכן
        result = system.generate_content_sync(
            prompt=args.prompt,
            content_type=args.type,
            quality_level=args.quality,
            language=args.language,
            length=args.length,
            keywords=args.keywords or [],
            include_seo=args.seo
        )
        
        # הצגת התוצאות
        print("=" * 50)
        print(f"נושא: {args.prompt}")
        print(f"סוג: {args.type}")
        print(f"איכות: {args.quality}")
        print(f"הצלחה: {'כן' if result['success'] else 'לא'}")
        print(f"זמן יצירה: {result['generation_time']:.2f} שניות")
        print("=" * 50)
        
        if result['success']:
            print("תוכן שנוצר:")
            print(result['content'])
            
            if result.get('quality_score'):
                print(f"\nציון איכות: {result['quality_score']:.2f}")
            
            if result.get('seo_score'):
                print(f"ציון SEO: {result['seo_score']:.2f}")
        else:
            print("שגיאה:")
            print(result['error'])
    
    finally:
        # עצירת המערכת
        asyncio.run(system.stop_system())

# ========== נקודת כניסה ראשית ==========

if __name__ == "__main__":
    import sys
    
    # הגדרת לוגינג
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('nlp_system.log', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # בדיקת אופן הפעלה
    if len(sys.argv) > 1 and sys.argv[1] == '--cli':
        # מצב שורת פקודה
        generate_content_cli()
    else:
        # מצב שרת
        config_file = sys.argv[1] if len(sys.argv) > 1 else None
        asyncio.run(run_nlp_system(config_file))