"""
כלים שימושיים למערכת NLP מתקדמת
פונקציות עזר לעיבוד טקסט, ניתוח תוכן ויצירת תוכן
"""

import re
import string
import unicodedata
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import SnowballStemmer
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Any, Tuple, Union
import hashlib
import datetime
import json
from pathlib import Path
import logging
from dataclasses import dataclass
import difflib
import requests
from urllib.parse import urljoin, urlparse
import sqlite3
import pickle
import gzip
from textstat import flesch_reading_ease, flesch_kincaid_grade

# ניסיון להוריד נתוני NLTK הנדרשים
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

@dataclass
class TextAnalysis:
    """מבנה נתונים לניתוח טקסט"""
    text: str
    word_count: int
    sentence_count: int
    paragraph_count: int
    avg_words_per_sentence: float
    readability_score: float
    sentiment_score: float
    language: str
    topics: List[str]
    keywords: List[str]
    entities: List[str]

class HebrewTextProcessor:
    """מעבד טקסט עברי מתקדם"""
    
    # מילות עצירה בעברית
    HEBREW_STOPWORDS = {
        'את', 'של', 'על', 'אל', 'לא', 'אם', 'כי', 'או', 'גם', 'רק', 'עוד',
        'כל', 'יש', 'היה', 'הוא', 'היא', 'אני', 'אתה', 'אתם', 'אתן', 'זה', 
        'זו', 'זות', 'מה', 'איך', 'למה', 'מי', 'איפה', 'מתי', 'כמה', 'למען',
        'בגלל', 'לכן', 'אבל', 'בעוד', 'במקום', 'בזמן', 'אחרי', 'לפני',
        'תחת', 'מעל', 'ליד', 'בתוך', 'מחוץ', 'בין', 'נגד', 'עם', 'בלי',
        'אליו', 'אליה', 'אלינו', 'אליכם', 'אליהם', 'אליהן', 'ממנו', 'ממנה',
        'ממני', 'ממך', 'ממנו', 'ממכם', 'ממהם', 'ממהן', 'אותו', 'אותה', 'אותי',
        'אותך', 'אותנו', 'אותכם', 'אותם', 'אותן', 'שלו', 'שלה', 'שלי', 'שלך',
        'שלנו', 'שלכם', 'שלהם', 'שלהן', 'שמא', 'פן', 'אולי', 'יתכן',
        'אמנם', 'ואכן', 'לכאורה', 'כביכול', 'כנראה', 'אכן', 'בכל', 'זאת',
        'וזה', 'הזה', 'הזו', 'ההוא', 'ההיא', 'הללו', 'האלה', 'האלו'
    }
    
    # תבניות דקדוקיות בעברית
    HEBREW_PATTERNS = {
        'prefix': ['ה', 'ו', 'ב', 'כ', 'ל', 'מ', 'ש'],
        'suffix': ['ים', 'ות', 'ה', 'ך', 'נו', 'כם', 'הם', 'הן'],
        'common_roots': ['כתב', 'אמר', 'עבד', 'למד', 'שמר', 'הלך', 'בוא', 'יצא']
    }
    
    @staticmethod
    def clean_hebrew_text(text: str) -> str:
        """ניקוי טקסט עברי"""
        if not text:
            return ""
        
        # הסרת סימני ניקוד
        text = HebrewTextProcessor.remove_nikud(text)
        
        # הסרת תווים לא רצויים אבל שמירה על עברית ופיסוק
        cleaned_text = re.sub(r'[^\u0590-\u05FF\s\.,!?;:()\[\]"\'0-9a-zA-Z-]', '', text)
        
        # נרמול רווחים
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
        
        return cleaned_text.strip()
    
    @staticmethod
    def remove_nikud(text: str) -> str:
        """הסרת סימני ניקוד מטקסט עברי"""
        # טווח סימני הניקוד ב-Unicode
        nikud_pattern = r'[\u0591-\u05C7]'
        return re.sub(nikud_pattern, '', text)
    
    @staticmethod
    def tokenize_hebrew(text: str) -> List[str]:
        """פיצול טקסט עברי למילים"""
        text = HebrewTextProcessor.clean_hebrew_text(text)
        
        # פיצול בסיסי לפי רווחים ופיסוק
        tokens = re.findall(r'[\u0590-\u05FF]+|[a-zA-Z]+|\d+', text)
        
        return [token for token in tokens if token.strip()]
    
    @staticmethod
    def extract_hebrew_roots(word: str) -> List[str]:
        """חילוץ שורשים עבריים (בסיסי)"""
        if len(word) < 3:
            return []
        
        word = HebrewTextProcessor.remove_nikud(word)
        
        # הסרת קידומות נפוצות
        for prefix in HebrewTextProcessor.HEBREW_PATTERNS['prefix']:
            if word.startswith(prefix) and len(word) > len(prefix) + 2:
                word = word[len(prefix):]
                break
        
        # הסרת סיומות נפוצות
        for suffix in HebrewTextProcessor.HEBREW_PATTERNS['suffix']:
            if word.endswith(suffix) and len(word) > len(suffix) + 2:
                word = word[:-len(suffix)]
                break
        
        # זיהוי שורש תלת אותיות (בסיסי)
        if len(word) >= 3:
            return [word[:3]]
        
        return []
    
    @staticmethod
    def is_hebrew_text(text: str) -> bool:
        """בדיקה אם הטקסט הוא עברי"""
        if not text:
            return False
        
        hebrew_chars = len(re.findall(r'[\u0590-\u05FF]', text))
        total_chars = len(re.findall(r'[^\s\W\d]', text))
        
        return total_chars > 0 and (hebrew_chars / total_chars) > 0.5
    
    @staticmethod
    def count_hebrew_words(text: str) -> int:
        """ספירת מילים עבריות"""
        tokens = HebrewTextProcessor.tokenize_hebrew(text)
        hebrew_words = [token for token in tokens if re.match(r'[\u0590-\u05FF]+', token)]
        return len(hebrew_words)

class TextAnalyzer:
    """מנתח טקסט מתקדם"""
    
    def __init__(self):
        self.stemmer_hebrew = None
        self.stemmer_english = SnowballStemmer('english')
        self.sentiment_lexicon = self._load_sentiment_lexicon()
    
    def _load_sentiment_lexicon(self) -> Dict[str, float]:
        """טעינת מילון סנטימנט"""
        # מילון סנטימנט בסיסי עבור עברית
        hebrew_sentiment = {
            'טוב': 1.0, 'רע': -1.0, 'יפה': 0.8, 'כעור': -0.8,
            'שמח': 1.0, 'עצוב': -1.0, 'נהדר': 1.0, 'נורא': -1.0,
            'מצוין': 1.0, 'גרוע': -1.0, 'אוהב': 0.8, 'שונא': -0.8,
            'מעולה': 1.0, 'איום': -1.0, 'נפלא': 1.0, 'נוראי': -1.0,
            'חיובי': 0.6, 'שלילי': -0.6, 'מדהים': 1.0, 'מבאס': -0.8,
            'מושלם': 1.0, 'גרוע': -1.0, 'בסדר': 0.2, 'לא בסדר': -0.5
        }
        
        return hebrew_sentiment
    
    def analyze_text(self, text: str) -> TextAnalysis:
        """ניתוח מקיף של טקסט"""
        if not text or not text.strip():
            return TextAnalysis(
                text="", word_count=0, sentence_count=0, paragraph_count=0,
                avg_words_per_sentence=0.0, readability_score=0.0,
                sentiment_score=0.0, language="unknown", topics=[], keywords=[], entities=[]
            )
        
        # זיהוי שפה
        language = self._detect_language(text)
        
        # ניתוח בסיסי
        word_count = self._count_words(text)
        sentence_count = self._count_sentences(text)
        paragraph_count = self._count_paragraphs(text)
        
        avg_words_per_sentence = word_count / sentence_count if sentence_count > 0 else 0
        
        # ניתוח קריאות
        readability_score = self._calculate_readability(text, language)
        
        # ניתוח סנטימנט
        sentiment_score = self._analyze_sentiment(text, language)
        
        # חילוץ נושאים
        topics = self._extract_topics(text, language)
        
        # חילוץ מילות מפתח
        keywords = self._extract_keywords(text, language)
        
        # זיהוי ישויות
        entities = self._extract_entities(text, language)
        
        return TextAnalysis(
            text=text,
            word_count=word_count,
            sentence_count=sentence_count,
            paragraph_count=paragraph_count,
            avg_words_per_sentence=avg_words_per_sentence,
            readability_score=readability_score,
            sentiment_score=sentiment_score,
            language=language,
            topics=topics,
            keywords=keywords,
            entities=entities
        )
    
    def _detect_language(self, text: str) -> str:
        """זיהוי שפת הטקסט"""
        if HebrewTextProcessor.is_hebrew_text(text):
            return "hebrew"
        
        # בדיקה בסיסית לאנגלית
        english_chars = len(re.findall(r'[a-zA-Z]', text))
        total_chars = len(re.findall(r'[^\s\W\d]', text))
        
        if total_chars > 0 and (english_chars / total_chars) > 0.7:
            return "english"
        
        return "mixed"
    
    def _count_words(self, text: str) -> int:
        """ספירת מילים"""
        language = self._detect_language(text)
        
        if language == "hebrew":
            return HebrewTextProcessor.count_hebrew_words(text)
        else:
            # ספירה כללית
            words = re.findall(r'\b\w+\b', text)
            return len(words)
    
    def _count_sentences(self, text: str) -> int:
        """ספירת משפטים"""
        # שימוש ב-NLTK לזיהוי משפטים
        try:
            sentences = sent_tokenize(text)
            return len(sentences)
        except:
            # חלופה בסיסית
            sentences = re.split(r'[.!?]+', text)
            return len([s for s in sentences if s.strip()])
    
    def _count_paragraphs(self, text: str) -> int:
        """ספירת פסקאות"""
        paragraphs = text.split('\n\n')
        return len([p for p in paragraphs if p.strip()])
    
    def _calculate_readability(self, text: str, language: str) -> float:
        """חישוב ציון קריאות"""
        try:
            if language == "english":
                return flesch_reading_ease(text)
            else:
                # חישוב בסיסי לעברית
                word_count = self._count_words(text)
                sentence_count = self._count_sentences(text)
                
                if sentence_count == 0:
                    return 0.0
                
                avg_sentence_length = word_count / sentence_count
                
                # נוסחה מותאמת לעברית (בסיסית)
                readability = 100 - (1.015 * avg_sentence_length)
                return max(0, min(100, readability))
        except:
            return 50.0  # ברירת מחדל
    
    def _analyze_sentiment(self, text: str, language: str) -> float:
        """ניתוח סנטימנט"""
        if language == "hebrew":
            return self._analyze_hebrew_sentiment(text)
        else:
            return self._analyze_english_sentiment(text)
    
    def _analyze_hebrew_sentiment(self, text: str) -> float:
        """ניתוח סנטימנט עברי"""
        words = HebrewTextProcessor.tokenize_hebrew(text)
        sentiment_scores = []
        
        for word in words:
            if word in self.sentiment_lexicon:
                sentiment_scores.append(self.sentiment_lexicon[word])
        
        if sentiment_scores:
            return np.mean(sentiment_scores)
        
        return 0.0
    
    def _analyze_english_sentiment(self, text: str) -> float:
        """ניתוח סנטימנט אנגלי (בסיסי)"""
        # ניתוח בסיסי לפי מילים חיוביות ושליליות
        positive_words = {'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'love', 'like', 'best'}
        negative_words = {'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'worst', 'poor', 'disappointing'}
        
        words = word_tokenize(text.lower())
        
        positive_count = sum(1 for word in words if word in positive_words)
        negative_count = sum(1 for word in words if word in negative_words)
        
        total_sentiment_words = positive_count + negative_count
        
        if total_sentiment_words == 0:
            return 0.0
        
        return (positive_count - negative_count) / total_sentiment_words
    
    def _extract_topics(self, text: str, language: str, max_topics: int = 5) -> List[str]:
        """חילוץ נושאים מהטקסט"""
        # ניתוח בסיסי לפי מילות מפתח נפוצות
        if language == "hebrew":
            words = HebrewTextProcessor.tokenize_hebrew(text)
            # הסרת מילות עצירה
            words = [w for w in words if w not in HebrewTextProcessor.HEBREW_STOPWORDS]
        else:
            words = word_tokenize(text.lower())
            # הסרת מילות עצירה אנגלית
            try:
                stop_words = set(stopwords.words('english'))
                words = [w for w in words if w not in stop_words and w.isalpha()]
            except:
                words = [w for w in words if w.isalpha()]
        
        # ספירת תדירויות
        word_freq = Counter(words)
        
        # החזרת המילים הנפוצות ביותר כנושאים
        topics = [word for word, count in word_freq.most_common(max_topics)]
        
        return topics
    
    def _extract_keywords(self, text: str, language: str, max_keywords: int = 10) -> List[str]:
        """חילוץ מילות מפתח"""
        return self._extract_topics(text, language, max_keywords)
    
    def _extract_entities(self, text: str, language: str) -> List[str]:
        """זיהוי ישויות (בסיסי)"""
        entities = []
        
        # זיהוי תאריכים
        date_patterns = [
            r'\d{1,2}/\d{1,2}/\d{4}',
            r'\d{1,2}\.\d{1,2}\.\d{4}',
            r'\d{4}-\d{1,2}-\d{1,2}'
        ]
        
        for pattern in date_patterns:
            dates = re.findall(pattern, text)
            entities.extend([f"DATE:{date}" for date in dates])
        
        # זיהוי מספרים
        numbers = re.findall(r'\b\d+\b', text)
        entities.extend([f"NUMBER:{num}" for num in numbers[:5]])  # רק 5 ראשונים
        
        # זיהוי כתובות מייל
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        entities.extend([f"EMAIL:{email}" for email in emails])
        
        # זיהוי URLs
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
        entities.extend([f"URL:{url}" for url in urls])
        
        return entities

class ContentGenerator:
    """מחולל תוכן מתקדם"""
    
    def __init__(self):
        self.templates = self._load_templates()
        self.style_guides = self._load_style_guides()
    
    def _load_templates(self) -> Dict[str, str]:
        """טעינת תבניות תוכן"""
        return {
            'blog_intro': 'בעולם של היום, {topic} הפך לנושא חשוב ביותר. במאמר זה נבחן את הנושא לעומק.',
            'blog_conclusion': 'לסיכום, {topic} הוא תחום מרתק שמשפיע על כולנו. חשוב להמשיך ללמוד ולהתעדכן.',
            'social_media': '🔥 {topic} - מה שכולם צריכים לדעת! #trending #content',
            'email_subject': '{topic} - המידע החשוב ביותר שתרצו לדעת',
            'headline': '{adjective} {topic}: {benefit}'
        }
    
    def _load_style_guides(self) -> Dict[str, Dict]:
        """טעינת מדריכי סגנון"""
        return {
            'formal': {
                'tone': 'formal',
                'person': 'third',
                'length': 'detailed'
            },
            'casual': {
                'tone': 'casual',
                'person': 'second',
                'length': 'medium'
            },
            'marketing': {
                'tone': 'persuasive',
                'person': 'second',
                'length': 'concise'
            }
        }
    
    def generate_content(self, content_type: str, topic: str, 
                        style: str = 'casual', length: int = 200) -> str:
        """יצירת תוכן לפי סוג ונושא"""
        
        if content_type == 'blog_post':
            return self._generate_blog_post(topic, style, length)
        elif content_type == 'social_media':
            return self._generate_social_media_post(topic, style)
        elif content_type == 'email':
            return self._generate_email(topic, style, length)
        elif content_type == 'headline':
            return self._generate_headlines(topic, count=5)
        else:
            return self._generate_generic_content(topic, length)
    
    def _generate_blog_post(self, topic: str, style: str, length: int) -> str:
        """יצירת פוסט בלוג"""
        intro = self.templates['blog_intro'].format(topic=topic)
        conclusion = self.templates['blog_conclusion'].format(topic=topic)
        
        # יצירת תוכן אמצע (בסיסי)
        middle_paragraphs = []
        
        # פסקת הגדרה
        middle_paragraphs.append(f"{topic} הוא תחום שמעסיק רבים מאתנו בימים אלה.")
        
        # פסקת יתרונות
        middle_paragraphs.append(f"היתרונות של {topic} כוללים שיפור איכות החיים והגברת היעילות.")
        
        # פסקת אתגרים
        middle_paragraphs.append(f"עם זאת, יש גם אתגרים בתחום {topic} שחשוב להכיר.")
        
        content = intro + "\n\n" + "\n\n".join(middle_paragraphs) + "\n\n" + conclusion
        
        # התאמת אורך
        if len(content.split()) > length:
            words = content.split()
            content = " ".join(words[:length]) + "..."
        
        return content
    
    def _generate_social_media_post(self, topic: str, style: str) -> str:
        """יצירת פוסט לרשתות חברתיות"""
        template = self.templates['social_media']
        return template.format(topic=topic)
    
    def _generate_email(self, topic: str, style: str, length: int) -> str:
        """יצירת מייל"""
        subject = self.templates['email_subject'].format(topic=topic)
        body = f"שלום,\n\nרציתי לשתף אתכם מידע חשוב על {topic}.\n\n"
        body += f"{topic} הוא נושא שחשוב לכולנו להכיר ולהבין.\n\n"
        body += "בברכה,\nהצוות"
        
        return f"נושא: {subject}\n\n{body}"
    
    def _generate_headlines(self, topic: str, count: int = 5) -> str:
        """יצירת כותרות"""
        adjectives = ['מדהים', 'חדשני', 'מהפכני', 'חשוב', 'מרתק']
        benefits = ['שישנה את חייכם', 'שכולם מדברים עליו', 'לעתיד טוב יותר']
        
        headlines = []
        template = self.templates['headline']
        
        for i in range(count):
            adjective = adjectives[i % len(adjectives)]
            benefit = benefits[i % len(benefits)]
            headline = template.format(adjective=adjective, topic=topic, benefit=benefit)
            headlines.append(f"{i+1}. {headline}")
        
        return "\n".join(headlines)
    
    def _generate_generic_content(self, topic: str, length: int) -> str:
        """יצירת תוכן כללי"""
        content = f"במאמר זה נדון ב{topic}. "
        content += f"{topic} הוא נושא חשוב ומעניין שראוי לבחינה מעמיקה. "
        content += f"נבחן את ההיבטים השונים של {topic} ונלמד כיצד הוא משפיע על חיי היום יום שלנו."
        
        return content

class SEOAnalyzer:
    """מנתח SEO לתוכן"""
    
    def __init__(self):
        self.optimal_title_length = (50, 60)
        self.optimal_meta_length = (150, 160)
        self.optimal_keyword_density = (1, 3)  # אחוזים
    
    def analyze_seo(self, content: str, target_keywords: List[str] = None, 
                   title: str = "", meta_description: str = "") -> Dict[str, Any]:
        """ניתוח SEO מקיף"""
        
        analysis = {
            'overall_score': 0,
            'title_analysis': self._analyze_title(title),
            'meta_analysis': self._analyze_meta_description(meta_description),
            'content_analysis': self._analyze_content(content, target_keywords),
            'keyword_analysis': self._analyze_keywords(content, target_keywords),
            'readability_analysis': self._analyze_readability(content),
            'recommendations': []
        }
        
        # חישוב ציון כללי
        scores = [
            analysis['title_analysis']['score'],
            analysis['meta_analysis']['score'],
            analysis['content_analysis']['score'],
            analysis['keyword_analysis']['score'],
            analysis['readability_analysis']['score']
        ]
        
        analysis['overall_score'] = sum(scores) / len(scores)
        
        # המלצות
        analysis['recommendations'] = self._generate_seo_recommendations(analysis)
        
        return analysis
    
    def _analyze_title(self, title: str) -> Dict[str, Any]:
        """ניתוח כותרת"""
        if not title:
            return {'score': 0, 'issues': ['אין כותרת'], 'length': 0}
        
        length = len(title)
        score = 100
        issues = []
        
        if length < self.optimal_title_length[0]:
            score -= 30
            issues.append('כותרת קצרה מדי')
        elif length > self.optimal_title_length[1]:
            score -= 20
            issues.append('כותרת ארוכה מדי')
        
        # בדיקת מילות מפתח בכותרת
        if not re.search(r'[\u0590-\u05FF]', title):
            score -= 10
            issues.append('מומלץ להוסיף מילות מפתח בעברית')
        
        return {
            'score': max(0, score),
            'length': length,
            'issues': issues,
            'optimal_range': f"{self.optimal_title_length[0]}-{self.optimal_title_length[1]} תווים"
        }
    
    def _analyze_meta_description(self, meta: str) -> Dict[str, Any]:
        """ניתוח תיאור מטא"""
        if not meta:
            return {'score': 0, 'issues': ['אין תיאור מטא'], 'length': 0}
        
        length = len(meta)
        score = 100
        issues = []
        
        if length < self.optimal_meta_length[0]:
            score -= 30
            issues.append('תיאור מטא קצר מדי')
        elif length > self.optimal_meta_length[1]:
            score -= 20
            issues.append('תיאור מטא ארוך מדי')
        
        return {
            'score': max(0, score),
            'length': length,
            'issues': issues,
            'optimal_range': f"{self.optimal_meta_length[0]}-{self.optimal_meta_length[1]} תווים"
        }
    
    def _analyze_content(self, content: str, keywords: List[str] = None) -> Dict[str, Any]:
        """ניתוח תוכן"""
        if not content:
            return {'score': 0, 'issues': ['אין תוכן'], 'word_count': 0}
        
        word_count = len(content.split())
        score = 100
        issues = []
        
        # בדיקת אורך תוכן
        if word_count < 300:
            score -= 20
            issues.append('תוכן קצר מדי (מומלץ לפחות 300 מילים)')
        
        # בדיקת מבנה
        if not self._has_headings(content):
            score -= 15
            issues.append('חסרות כותרות משנה')
        
        if not self._has_lists(content):
            score -= 10
            issues.append('מומלץ להוסיף רשימות')
        
        return {
            'score': max(0, score),
            'word_count': word_count,
            'issues': issues,
            'has_headings': self._has_headings(content),
            'has_lists': self._has_lists(content)
        }
    
    def _analyze_keywords(self, content: str, keywords: List[str] = None) -> Dict[str, Any]:
        """ניתוח מילות מפתח"""
        if not keywords:
            return {'score': 50, 'issues': ['לא הוגדרו מילות מפתח'], 'density': {}}
        
        content_lower = content.lower()
        total_words = len(content.split())
        density = {}
        score = 100
        issues = []
        
        for keyword in keywords:
            keyword_lower = keyword.lower()
            count = content_lower.count(keyword_lower)
            keyword_density = (count / total_words) * 100 if total_words > 0 else 0
            density[keyword] = {
                'count': count,
                'density': keyword_density
            }
            
            if keyword_density < self.optimal_keyword_density[0]:
                score -= 20
                issues.append(f'צפיפות נמוכה למילת המפתח "{keyword}"')
            elif keyword_density > self.optimal_keyword_density[1]:
                score -= 15
                issues.append(f'צפיפות גבוהה מדי למילת המפתח "{keyword}"')
        
        return {
            'score': max(0, score),
            'density': density,
            'issues': issues,
            'optimal_density': f"{self.optimal_keyword_density[0]}-{self.optimal_keyword_density[1]}%"
        }
    
    def _analyze_readability(self, content: str) -> Dict[str, Any]:
        """ניתוח קריאות"""
        analyzer = TextAnalyzer()
        analysis = analyzer.analyze_text(content)
        
        score = 100
        issues = []
        
        # בדיקת אורך משפט ממוצע
        if analysis.avg_words_per_sentence > 20:
            score -= 20
            issues.append('משפטים ארוכים מדי')
        
        # בדיקת ציון קריאות
        if analysis.readability_score < 30:
            score -= 30
            issues.append('קריאות נמוכה')
        elif analysis.readability_score < 50:
            score -= 15
            issues.append('קריאות בינונית')
        
        return {
            'score': max(0, score),
            'readability_score': analysis.readability_score,
            'avg_words_per_sentence': analysis.avg_words_per_sentence,
            'issues': issues
        }
    
    def _has_headings(self, content: str) -> bool:
        """בדיקה אם יש כותרות בתוכן"""
        heading_patterns = [
            r'^#{1,6}\s+.+$',  # Markdown headings
            r'<h[1-6]>.+</h[1-6]>',  # HTML headings
            r'.+\n=+$',  # Underlined headings
            r'.+\n-+$'   # Underlined headings
        ]
        
        for pattern in heading_patterns:
            if re.search(pattern, content, re.MULTILINE):
                return True
        
        return False
    
    def _has_lists(self, content: str) -> bool:
        """בדיקה אם יש רשימות בתוכן"""
        list_patterns = [
            r'^\s*[\*\-\+]\s+.+$',  # Markdown lists
            r'^\s*\d+\.\s+.+$',     # Numbered lists
            r'<[uo]l>.+</[uo]l>',   # HTML lists
        ]
        
        for pattern in list_patterns:
            if re.search(pattern, content, re.MULTILINE):
                return True
        
        return False
    
    def _generate_seo_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """יצירת המלצות SEO"""
        recommendations = []
        
        # המלצות לכותרת
        if analysis['title_analysis']['score'] < 70:
            recommendations.extend(analysis['title_analysis']['issues'])
        
        # המלצות לתיאור מטא
        if analysis['meta_analysis']['score'] < 70:
            recommendations.extend(analysis['meta_analysis']['issues'])
        
        # המלצות לתוכן
        if analysis['content_analysis']['score'] < 70:
            recommendations.extend(analysis['content_analysis']['issues'])
        
        # המלצות למילות מפתח
        if analysis['keyword_analysis']['score'] < 70:
            recommendations.extend(analysis['keyword_analysis']['issues'])
        
        # המלצות לקריאות
        if analysis['readability_analysis']['score'] < 70:
            recommendations.extend(analysis['readability_analysis']['issues'])
        
        return recommendations

class TextComparator:
    """משווה טקסטים"""
    
    @staticmethod
    def calculate_similarity(text1: str, text2: str) -> float:
        """חישוב דמיון בין שני טקסטים"""
        if not text1 or not text2:
            return 0.0
        
        return difflib.SequenceMatcher(None, text1.lower(), text2.lower()).ratio()
    
    @staticmethod
    def find_differences(text1: str, text2: str) -> Dict[str, List[str]]:
        """מציאת הבדלים בין טקסטים"""
        differ = difflib.unified_diff(
            text1.splitlines(keepends=True),
            text2.splitlines(keepends=True),
            fromfile='טקסט 1',
            tofile='טקסט 2'
        )
        
        additions = []
        deletions = []
        
        for line in differ:
            if line.startswith('+') and not line.startswith('+++'):
                additions.append(line[1:].strip())
            elif line.startswith('-') and not line.startswith('---'):
                deletions.append(line[1:].strip())
        
        return {
            'additions': additions,
            'deletions': deletions
        }
    
    @staticmethod
    def check_plagiarism(text: str, reference_texts: List[str], 
                        threshold: float = 0.8) -> Dict[str, Any]:
        """בדיקת גניבה ספרותית"""
        results = {
            'is_plagiarized': False,
            'max_similarity': 0.0,
            'similar_texts': [],
            'suspicious_segments': []
        }
        
        for i, ref_text in enumerate(reference_texts):
            similarity = TextComparator.calculate_similarity(text, ref_text)
            
            if similarity > results['max_similarity']:
                results['max_similarity'] = similarity
            
            if similarity >= threshold:
                results['is_plagiarized'] = True
                results['similar_texts'].append({
                    'index': i,
                    'similarity': similarity,
                    'text_preview': ref_text[:100] + '...'
                })
        
        return results

# פונקציות עזר גלובליות
def clean_text(text: str, language: str = "auto") -> str:
    """ניקוי טקסט כללי"""
    if not text:
        return ""
    
    if language == "auto":
        language = "hebrew" if HebrewTextProcessor.is_hebrew_text(text) else "english"
    
    if language == "hebrew":
        return HebrewTextProcessor.clean_hebrew_text(text)
    else:
        # ניקוי כללי
        text = re.sub(r'[^\w\s\.,!?;:()\[\]"\'-]', '', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

def extract_keywords(text: str, max_keywords: int = 10, language: str = "auto") -> List[str]:
    """חילוץ מילות מפתח מטקסט"""
    analyzer = TextAnalyzer()
    
    if language == "auto":
        language = analyzer._detect_language(text)
    
    return analyzer._extract_keywords(text, language, max_keywords)

def calculate_readability(text: str, language: str = "auto") -> float:
    """חישוב ציון קריאות"""
    analyzer = TextAnalyzer()
    
    if language == "auto":
        language = analyzer._detect_language(text)
    
    return analyzer._calculate_readability(text, language)

def analyze_sentiment(text: str, language: str = "auto") -> float:
    """ניתוח סנטימנט"""
    analyzer = TextAnalyzer()
    
    if language == "auto":
        language = analyzer._detect_language(text)
    
    return analyzer._analyze_sentiment(text, language)

def generate_summary(text: str, max_sentences: int = 3) -> str:
    """יצירת תקציר"""
    if not text:
        return ""
    
    sentences = sent_tokenize(text)
    
    if len(sentences) <= max_sentences:
        return text
    
    # אלגוריתם בסיסי לבחירת משפטים חשובים
    sentence_scores = {}
    
    # ניקוד לפי אורך ומיקום
    for i, sentence in enumerate(sentences):
        score = len(sentence.split())  # ניקוד לפי אורך
        
        # בונוס למשפטים בתחילת הטקסט
        if i < len(sentences) * 0.3:
            score *= 1.5
        
        sentence_scores[sentence] = score
    
    # בחירת המשפטים בעלי הניקוד הגבוה ביותר
    top_sentences = sorted(sentence_scores.items(), key=lambda x: x[1], reverse=True)[:max_sentences]
    
    # שמירה על סדר המקורי
    summary_sentences = []
    for sentence in sentences:
        if any(sentence == s[0] for s in top_sentences):
            summary_sentences.append(sentence)
        if len(summary_sentences) >= max_sentences:
            break
    
    return " ".join(summary_sentences)

def improve_text_readability(text: str, target_language: str = "hebrew") -> str:
    """שיפור קריאות טקסט"""
    if not text:
        return text
    
    # פיצול למשפטים
    sentences = sent_tokenize(text)
    improved_sentences = []
    
    for sentence in sentences:
        words = sentence.split()
        
        # קיצור משפטים ארוכים
        if len(words) > 25:
            # חיפוש נקודת חיתוך טבעית
            mid_point = len(words) // 2
            conjunctions = ['ו', 'אבל', 'כי', 'אם', 'או', 'גם']
            
            for i in range(mid_point - 3, mid_point + 3):
                if i < len(words) and words[i] in conjunctions:
                    first_part = " ".join(words[:i])
                    second_part = " ".join(words[i:])
                    improved_sentences.extend([first_part + ".", second_part])
                    break
            else:
                # אם לא נמצא חיבור, פשוט חתוך באמצע
                first_part = " ".join(words[:mid_point])
                second_part = " ".join(words[mid_point:])
                improved_sentences.extend([first_part + ".", second_part])
        else:
            improved_sentences.append(sentence)
    
    return " ".join(improved_sentences)

def format_text_for_web(text: str) -> str:
    """פורמט טקסט לאינטרנט"""
    if not text:
        return text
    
    # פיצול לפסקאות
    paragraphs = text.split('\n\n')
    formatted_paragraphs = []
    
    for paragraph in paragraphs:
        if not paragraph.strip():
            continue
        
        # הוספת כותרות אוטומטיות לפסקאות ארוכות
        if len(paragraph.split()) > 100:
            # ניסיון לזהות נושא הפסקה
            first_sentence = paragraph.split('.')[0]
            if len(first_sentence.split()) < 10:
                heading = f"## {first_sentence}\n\n"
                rest = paragraph[len(first_sentence):].strip()
                formatted_paragraphs.append(heading + rest)
            else:
                formatted_paragraphs.append(paragraph)
        else:
            formatted_paragraphs.append(paragraph)
    
    return '\n\n'.join(formatted_paragraphs)

def count_reading_time(text: str, words_per_minute: int = 200) -> int:
    """חישוב זמן קריאה בדקות"""
    if not text:
        return 0
    
    word_count = len(text.split())
    reading_time = word_count / words_per_minute
    
    return max(1, round(reading_time))

def validate_text_quality(text: str) -> Dict[str, Any]:
    """אימות איכות טקסט"""
    if not text:
        return {
            'is_valid': False,
            'issues': ['טקסט ריק'],
            'score': 0
        }
    
    issues = []
    score = 100
    
    # בדיקת אורך מינימלי
    if len(text.split()) < 10:
        issues.append('טקסט קצר מדי')
        score -= 30
    
    # בדיקת איכות שפה
    if text.count('...') > 3:
        issues.append('יותר מדי נקודות השעיה')
        score -= 10
    
    # בדיקת איות בסיסית (חיפוש מילים חזורות)
    words = text.lower().split()
    word_freq = Counter(words)
    repeated_words = [word for word, count in word_freq.items() if count > len(words) * 0.05]
    
    if repeated_words:
        issues.append('חזרה מוגזמת על מילים')
        score -= 15
    
    # בדיקת פיסוק
    sentences = text.split('.')
    sentences_without_punctuation = [s for s in sentences if not s.strip().endswith(('.', '!', '?'))]
    
    if len(sentences_without_punctuation) > len(sentences) * 0.3:
        issues.append('בעיות פיסוק')
        score -= 20
    
    return {
        'is_valid': score >= 50,
        'issues': issues,
        'score': max(0, score),
        'word_count': len(text.split()),
        'reading_time': count_reading_time(text)
    }