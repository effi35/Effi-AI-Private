"""
Content Generation Models - מודלים ליצירת תוכן מתקדם
מערכת יצירת תוכן חכמה עם יכולות AI מתקדמות
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union, Set, Tuple
from datetime import datetime, timedelta
import json
import uuid

class LanguageType(Enum):
    """שפות נתמכות"""
    HEBREW = "he"
    ENGLISH = "en"
    ARABIC = "ar"
    SPANISH = "es"
    FRENCH = "fr"
    GERMAN = "de"
    RUSSIAN = "ru"
    CHINESE = "zh"
    JAPANESE = "ja"
    KOREAN = "ko"
    ITALIAN = "it"
    PORTUGUESE = "pt"

class ContentType(Enum):
    """סוגי תוכן"""
    MARKETING_COPY = "marketing_copy"       # תוכן שיווקי
    TECHNICAL_DOC = "technical_doc"         # תיעוד טכני
    CREATIVE_WRITING = "creative_writing"   # כתיבה יצירתית
    BUSINESS_PLAN = "business_plan"         # תכנית עסקית
    ACADEMIC_PAPER = "academic_paper"       # מאמר אקדמי
    NEWS_ARTICLE = "news_article"           # כתבה חדשותית
    BLOG_POST = "blog_post"                 # פוסט בלוג
    SOCIAL_MEDIA = "social_media"           # תוכן רשתות חברתיות
    EMAIL_TEMPLATE = "email_template"       # תבנית אימייל
    PRODUCT_DESC = "product_desc"           # תיאור מוצר
    SCRIPT_SCENARIO = "script_scenario"     # תסריט/תרחיש
    EDUCATIONAL = "educational"             # תוכן חינוכי
    LEGAL_DOC = "legal_doc"                 # מסמך משפטי
    MEDICAL_TEXT = "medical_text"           # טקסט רפואי
    POETRY = "poetry"                       # שירה
    STORYTELLING = "storytelling"           # סיפור
    PRESENTATION = "presentation"           # מצגת

class ProcessingType(Enum):
    """סוגי עיבוד"""
    GENERATION = "generation"               # יצירה מאפס
    SUMMARIZATION = "summarization"         # סיכום
    EXPANSION = "expansion"                 # הרחבה
    REWRITING = "rewriting"                 # כתיבה מחדש
    TRANSLATION = "translation"             # תרגום
    PROOFREADING = "proofreading"          # הגהה
    STYLE_TRANSFER = "style_transfer"       # העברת סגנון
    FACT_CHECK = "fact_check"              # בדיקת עובדות
    SENTIMENT_ANALYSIS = "sentiment"        # ניתוח רגש
    KEYWORD_EXTRACTION = "keywords"         # חילוץ מילות מפתח
    TOPIC_MODELING = "topic_modeling"       # מידול נושאים
    CLASSIFICATION = "classification"        # סיווג
    ENTITY_RECOGNITION = "entity_recognition" # זיהוי ישויות

class AnalysisDepth(Enum):
    """עומק ניתוח"""
    SURFACE = 1      # ניתוח שטחי
    MEDIUM = 2       # ניתוח בינוני
    DEEP = 3         # ניתוח עמוק
    COMPREHENSIVE = 4 # ניתוח מקיף
    EXPERT = 5       # ניתוח מומחה

class GenerationPriority(Enum):
    """עדיפות יצירה"""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    URGENT = 4
    CRITICAL = 5

class QualityLevel(Enum):
    """רמת איכות"""
    DRAFT = 1        # טיוטה
    GOOD = 2         # טוב
    PROFESSIONAL = 3  # מקצועי
    EXPERT = 4       # מומחה
    MASTER = 5       # מאסטר

@dataclass
class ContentRequirements:
    """דרישות תוכן"""
    target_audience: str                    # קהל יעד
    tone: str                              # טון כתיבה
    style: str                             # סגנון
    length_words: Tuple[int, int]          # טווח אורך במילים
    key_points: List[str]                  # נקודות מפתח
    keywords: List[str]                    # מילות מפתח נדרשות
    avoid_topics: List[str] = None         # נושאים להימנעות
    include_examples: bool = True          # כלול דוגמאות
    include_statistics: bool = False       # כלול סטטיסטיקות
    call_to_action: str = ""              # קריאה לפעולה
    brand_voice: str = ""                 # קול המותג
    legal_compliance: List[str] = None    # דרישות חוקיות
    
    def __post_init__(self):
        if self.avoid_topics is None:
            self.avoid_topics = []
        if self.legal_compliance is None:
            self.legal_compliance = []

@dataclass
class ContentGeneration:
    """משימת יצירת תוכן"""
    generation_id: str
    content_type: ContentType
    processing_type: ProcessingType
    language: LanguageType
    requirements: ContentRequirements
    
    # תוכן מקור (עבור עיבוד קיים)
    source_content: str = ""
    source_language: Optional[LanguageType] = None
    
    # הגדרות יצירה
    priority: GenerationPriority = GenerationPriority.MEDIUM
    quality_level: QualityLevel = QualityLevel.PROFESSIONAL
    creativity_level: float = 0.7          # 0.0-1.0
    factual_accuracy: float = 0.9          # 0.0-1.0
    
    # מטא-דטה
    title: str = ""
    description: str = ""
    requester: str = ""
    deadline: Optional[datetime] = None
    created_at: datetime = None
    
    # הגדרות מתקדמות
    use_templates: bool = True
    enable_fact_checking: bool = True
    enable_plagiarism_check: bool = True
    enable_seo_optimization: bool = False
    
    # קונטקסט נוסף
    context_documents: List[str] = None    # מסמכי רקע
    reference_materials: List[str] = None  # חומרי עזר
    competitor_analysis: List[str] = None  # ניתוח מתחרים
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.context_documents is None:
            self.context_documents = []
        if self.reference_materials is None:
            self.reference_materials = []
        if self.competitor_analysis is None:
            self.competitor_analysis = []
    
    def estimate_generation_time(self) -> int:
        """הערכת זמן יצירה בדקות"""
        base_time = {
            ContentType.SOCIAL_MEDIA: 5,
            ContentType.EMAIL_TEMPLATE: 10,
            ContentType.BLOG_POST: 30,
            ContentType.MARKETING_COPY: 20,
            ContentType.TECHNICAL_DOC: 60,
            ContentType.BUSINESS_PLAN: 120,
            ContentType.ACADEMIC_PAPER: 180,
            ContentType.CREATIVE_WRITING: 45
        }.get(self.content_type, 30)
        
        # התאמה לפי אורך
        word_count = sum(self.requirements.length_words) // 2
        time_multiplier = max(1.0, word_count / 500)  # כל 500 מילים
        
        # התאמה לפי איכות
        quality_multiplier = {
            QualityLevel.DRAFT: 0.5,
            QualityLevel.GOOD: 0.8,
            QualityLevel.PROFESSIONAL: 1.0,
            QualityLevel.EXPERT: 1.5,
            QualityLevel.MASTER: 2.0
        }[self.quality_level]
        
        # התאמה לפי מורכבות
        complexity_multiplier = 1.0
        if self.enable_fact_checking:
            complexity_multiplier += 0.3
        if self.enable_seo_optimization:
            complexity_multiplier += 0.2
        if len(self.requirements.key_points) > 5:
            complexity_multiplier += 0.2
        
        total_time = base_time * time_multiplier * quality_multiplier * complexity_multiplier
        return max(5, int(total_time))
    
    def validate_requirements(self) -> List[str]:
        """בדיקת תקינות דרישות"""
        issues = []
        
        # בדיקת אורך
        min_words, max_words = self.requirements.length_words
        if min_words <= 0:
            issues.append("מספר מילים מינימלי חייב להיות חיובי")
        if max_words < min_words:
            issues.append("מספר מילים מקסימלי חייב להיות גדול מהמינימלי")
        
        # בדיקת נקודות מפתח
        if not self.requirements.key_points:
            issues.append("חייבות להיות לפחות נקודת מפתח אחת")
        
        # בדיקת קהל יעד
        if not self.requirements.target_audience.strip():
            issues.append("חייב להגדיר קהל יעד")
        
        # בדיקת דדליין
        if self.deadline and self.deadline < datetime.now():
            issues.append("דדליין לא יכול להיות בעבר")
        
        return issues

@dataclass
class GenerationMetrics:
    """מדדי יצירה"""
    word_count: int = 0
    character_count: int = 0
    sentence_count: int = 0
    paragraph_count: int = 0
    
    # מדדי איכות
    readability_score: float = 0.0         # 0.0-1.0
    coherence_score: float = 0.0           # 0.0-1.0
    creativity_score: float = 0.0          # 0.0-1.0
    accuracy_score: float = 0.0            # 0.0-1.0
    
    # SEO
    keyword_density: Dict[str, float] = None
    seo_score: float = 0.0                 # 0.0-1.0
    
    # זמן יצירה
    generation_time_seconds: float = 0.0
    
    # מדדי שפה
    language_confidence: float = 0.0       # ביטחון בזיהוי שפה
    grammar_score: float = 0.0             # ניקוד דקדוק
    vocabulary_richness: float = 0.0       # עושר אוצר מילים
    
    def __post_init__(self):
        if self.keyword_density is None:
            self.keyword_density = {}
    
    def calculate_overall_quality(self) -> float:
        """חישוב איכות כוללת"""
        scores = [
            self.readability_score,
            self.coherence_score,
            self.accuracy_score,
            self.grammar_score
        ]
        
        valid_scores = [s for s in scores if s > 0]
        return sum(valid_scores) / len(valid_scores) if valid_scores else 0.0

@dataclass
class GenerationResult:
    """תוצאת יצירת תוכן"""
    generation_id: str
    generated_content: str
    
    # מטא-דטה
    generated_at: datetime
    generation_time: float                 # זמן יצירה בשניות
    
    # מדדים
    metrics: GenerationMetrics
    
    # אלטרנטיבות
    alternative_versions: List[str] = None
    
    # הערות ושיפורים
    suggestions: List[str] = None
    warnings: List[str] = None
    fact_check_results: List[Dict[str, Any]] = None
    
    # SEO ואופטימיזציה
    seo_recommendations: List[str] = None
    keyword_optimization: Dict[str, Any] = None
    
    # ניתוח תוכן
    sentiment_analysis: Dict[str, float] = None  # חיובי, שלילי, ניטרלי
    topic_classification: List[str] = None
    named_entities: List[Dict[str, str]] = None
    
    # השוואה לדרישות
    requirements_compliance: Dict[str, bool] = None
    
    def __post_init__(self):
        if self.alternative_versions is None:
            self.alternative_versions = []
        if self.suggestions is None:
            self.suggestions = []
        if self.warnings is None:
            self.warnings = []
        if self.fact_check_results is None:
            self.fact_check_results = []
        if self.seo_recommendations is None:
            self.seo_recommendations = []
        if self.keyword_optimization is None:
            self.keyword_optimization = {}
        if self.sentiment_analysis is None:
            self.sentiment_analysis = {}
        if self.topic_classification is None:
            self.topic_classification = []
        if self.named_entities is None:
            self.named_entities = []
        if self.requirements_compliance is None:
            self.requirements_compliance = {}
    
    def is_successful(self) -> bool:
        """בדיקת הצלחת היצירה"""
        return (
            len(self.generated_content.strip()) > 0 and
            self.metrics.calculate_overall_quality() >= 0.6 and
            len(self.warnings) == 0
        )
    
    def get_summary(self) -> Dict[str, Any]:
        """סיכום התוצאה"""
        return {
            'word_count': self.metrics.word_count,
            'quality_score': self.metrics.calculate_overall_quality(),
            'generation_time': self.generation_time,
            'is_successful': self.is_successful(),
            'has_alternatives': len(self.alternative_versions) > 0,
            'warnings_count': len(self.warnings),
            'suggestions_count': len(self.suggestions)
        }

@dataclass
class GenerationTask:
    """משימת יצירה מורכבת"""
    task_id: str
    name: str
    hebrew_name: str
    description: str
    
    # משימות משנה
    sub_generations: List[ContentGeneration]
    
    # הגדרות כלליות
    overall_requirements: ContentRequirements
    coordination_rules: List[str]          # חוקי תיאום בין חלקים
    
    # זמנים
    created_at: datetime
    deadline: Optional[datetime] = None
    
    # סטטוס
    status: str = "pending"                # pending, running, completed, failed
    progress: float = 0.0                  # 0.0-1.0
    
    # תוצאות
    completed_generations: Dict[str, GenerationResult] = None
    final_result: Optional[str] = None     # תוצאה מאוחדת
    
    def __post_init__(self):
        if self.completed_generations is None:
            self.completed_generations = {}
    
    def get_completion_percentage(self) -> float:
        """אחוז השלמה"""
        if not self.sub_generations:
            return 0.0
        
        completed = len(self.completed_generations)
        total = len(self.sub_generations)
        
        return (completed / total) * 100
    
    def is_completed(self) -> bool:
        """בדיקת השלמה"""
        return len(self.completed_generations) == len(self.sub_generations)
    
    def add_completed_generation(self, generation_id: str, result: GenerationResult):
        """הוספת יצירה שהושלמה"""
        self.completed_generations[generation_id] = result
        self.progress = self.get_completion_percentage() / 100

class ContentTemplateLibrary:
    """ספריית תבניות תוכן מוכנות"""
    
    @staticmethod
    def get_marketing_templates() -> Dict[str, Dict[str, Any]]:
        """תבניות שיווק"""
        return {
            'product_launch': {
                'title': 'השקת מוצר חדש',
                'structure': [
                    'כותרת מושכת',
                    'בעיה שהמוצר פותר',
                    'פתרון ייחודי',
                    'יתרונות מפתח',
                    'עדויות לקוחות',
                    'קריאה לפעולה'
                ],
                'tone': 'נלהב ומקצועי',
                'keywords': ['חדש', 'מהפכני', 'פתרון', 'יתרונות']
            },
            
            'email_campaign': {
                'title': 'קמפיין אימייל',
                'structure': [
                    'כותרת נושא מושכת',
                    'פתיחה אישית',
                    'ערך ללקוח',
                    'הוכחה חברתית',
                    'קריאה לפעולה ברורה'
                ],
                'tone': 'ידידותי ואישי',
                'keywords': ['ממוקד', 'אישי', 'ערך', 'הזדמנות']
            },
            
            'social_media_post': {
                'title': 'פוסט רשתות חברתיות',
                'structure': [
                    'hook מושך תשומת לב',
                    'תוכן בעל ערך',
                    'השתתפות קהילה',
                    'hashtags רלוונטיים'
                ],
                'tone': 'קליל ומעניין',
                'keywords': ['מעניין', 'שיתוף', 'קהילה', 'השראה']
            }
        }
    
    @staticmethod
    def get_technical_templates() -> Dict[str, Dict[str, Any]]:
        """תבניות טכניות"""
        return {
            'api_documentation': {
                'title': 'תיעוד API',
                'structure': [
                    'סקירה כללית',
                    'התחלה מהירה',
                    'endpoints ושיטות',
                    'דוגמאות קוד',
                    'טיפול בשגיאות',
                    'מגבלות וחגיגות'
                ],
                'tone': 'מדויק וברור',
                'keywords': ['API', 'endpoint', 'request', 'response']
            },
            
            'user_manual': {
                'title': 'מדריך משתמש',
                'structure': [
                    'מבוא למערכת',
                    'התקנה והגדרה',
                    'שימוש בסיסי',
                    'תכונות מתקדמות',
                    'פתרון בעיות נפוצות',
                    'מקורות עזרה'
                ],
                'tone': 'ברור ומנחה',
                'keywords': ['מדריך', 'שלבים', 'הוראות', 'עזרה']
            },
            
            'technical_blog': {
                'title': 'פוסט טכני',
                'structure': [
                    'הקדמה לבעיה',
                    'ניתוח טכני',
                    'פתרון מוצע',
                    'יישום מעשי',
                    'מסקנות',
                    'קריאות נוספות'
                ],
                'tone': 'מקצועי ומעמיק',
                'keywords': ['טכני', 'פתרון', 'יישום', 'מעמיק']
            }
        }
    
    @staticmethod
    def get_creative_templates() -> Dict[str, Dict[str, Any]]:
        """תבניות יצירתיות"""
        return {
            'short_story': {
                'title': 'סיפור קצר',
                'structure': [
                    'הקמת תפאורה ודמויות',
                    'עלילה ועימות',
                    'שיא',
                    'פתרון ומסקנות'
                ],
                'tone': 'יצירתי ומעניין',
                'keywords': ['סיפור', 'דמויות', 'עלילה', 'רגש']
            },
            
            'blog_narrative': {
                'title': 'סיפור אישי לבלוג',
                'structure': [
                    'רקע אישי',
                    'האתגר או הבעיה',
                    'המסע והלמידה',
                    'התובנות שנרכשו',
                    'מסר ללקוחות'
                ],
                'tone': 'אישי ומעורר השראה',
                'keywords': ['אישי', 'מסע', 'למידה', 'השראה']
            },
            
            'poetry': {
                'title': 'שיר',
                'structure': [
                    'בית פתיחה',
                    'פיתוח הנושא',
                    'שיא רגשי',
                    'סיום מרנן'
                ],
                'tone': 'רגשי ואמנותי',
                'keywords': ['שיר', 'רגש', 'דימויים', 'קצב']
            }
        }
    
    @staticmethod
    def get_business_templates() -> Dict[str, Dict[str, Any]]:
        """תבניות עסקיות"""
        return {
            'business_proposal': {
                'title': 'הצעה עסקית',
                'structure': [
                    'תקציר מנהלים',
                    'הגדרת הבעיה',
                    'פתרון מוצע',
                    'יתרונות ותועלות',
                    'עלויות ותזמונים',
                    'סיכונים והמלצות'
                ],
                'tone': 'מקצועי ומשכנע',
                'keywords': ['הצעה', 'פתרון', 'יתרונות', 'ROI']
            },
            
            'market_analysis': {
                'title': 'ניתוח שוק',
                'structure': [
                    'סקירת השוק',
                    'ניתוח מתחרים',
                    'קהל יעד',
                    'הזדמנויות ואיומים',
                    'מגמות עתידיות',
                    'המלצות אסטרטגיות'
                ],
                'tone': 'אנליטי ומבוסס נתונים',
                'keywords': ['שוק', 'ניתוח', 'מתחרים', 'מגמות']
            },
            
            'executive_summary': {
                'title': 'תקציר מנהלים',
                'structure': [
                    'מטרת המסמך',
                    'ממצאים עיקריים',
                    'המלצות',
                    'צעדים הבאים'
                ],
                'tone': 'תמציתי ולעניין',
                'keywords': ['תקציר', 'ממצאים', 'המלצות', 'פעולה']
            }
        }