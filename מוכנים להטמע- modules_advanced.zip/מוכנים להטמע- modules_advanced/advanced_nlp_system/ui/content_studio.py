"""
סטודיו יצירת תוכן מתקדם - ממשק ליצירה ועיבוד תוכן
ממשק משתמש מקצועי ליצירת תוכן באמצעות AI
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
from collections import Counter
import re
import webbrowser
from pathlib import Path

class ContentStudio:
    """סטודיו יצירת תוכן מתקדם"""
    
    def __init__(self, content_engine=None):
        self.content_engine = content_engine
        self.root = None
        self.running = False
        
        # רכיבי UI
        self.content_editor = None
        self.preview_area = None
        self.templates_tree = None
        self.analytics_canvas = None
        self.log_text = None
        
        # נתונים
        self.current_project = None
        self.generation_history = []
        self.templates = {}
        self.content_analytics = {}
        
        # הגדרות
        self.settings = {
            'auto_save': True,
            'quality_level': 'high',
            'creativity_level': 0.7,
            'language': 'hebrew',
            'target_audience': 'general',
            'content_length': 'medium'
        }
    
    def create_ui(self):
        """יצירת ממשק המשתמש הראשי"""
        self.root = tk.Tk()
        self.root.title("סטודיו יצירת תוכן מתקדם - Effi AI")
        self.root.geometry("1800x1000")
        self.root.configure(bg='#f0f0f0')
        
        # יצירת תפריט
        self._create_menu()
        
        # יצירת סרגל כלים
        self._create_toolbar()
        
        # יצירת אזור העבודה הראשי
        self._create_main_workspace()
        
        # יצירת סרגל סטטוס
        self._create_status_bar()
        
        # טעינת תבניות ראשוניות
        self.load_default_templates()
        
        # התחלת ניטור
        self.start_monitoring()
        
        return self.root
    
    def _create_menu(self):
        """יצירת תפריט עליון"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # תפריט פרויקט
        project_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="פרויקט", menu=project_menu)
        project_menu.add_command(label="פרויקט חדש", accelerator="Ctrl+N", command=self.new_project)
        project_menu.add_command(label="פתח פרויקט", accelerator="Ctrl+O", command=self.open_project)
        project_menu.add_command(label="שמור פרויקט", accelerator="Ctrl+S", command=self.save_project)
        project_menu.add_command(label="שמור בשם", accelerator="Ctrl+Shift+S", command=self.save_as_project)
        project_menu.add_separator()
        project_menu.add_command(label="ייצוא לWord", command=self.export_to_word)
        project_menu.add_command(label="ייצוא ל-PDF", command=self.export_to_pdf)
        project_menu.add_command(label="ייצוא ל-HTML", command=self.export_to_html)
        
        # תפריט יצירה
        create_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="יצירה", menu=create_menu)
        create_menu.add_command(label="יצור תוכן", accelerator="F5", command=self.generate_content)
        create_menu.add_command(label="יצור כותרות", command=self.generate_headlines)
        create_menu.add_command(label="יצור תקציר", command=self.generate_summary)
        create_menu.add_command(label="יצור רשימה", command=self.generate_list)
        create_menu.add_separator()
        create_menu.add_command(label="שפר תוכן", command=self.improve_content)
        create_menu.add_command(label="תרגם תוכן", command=self.translate_content)
        create_menu.add_command(label="בדוק דקדוק", command=self.check_grammar)
        
        # תפריט תבניות
        templates_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="תבניות", menu=templates_menu)
        templates_menu.add_command(label="תבנית חדשה", command=self.create_template)
        templates_menu.add_command(label="ערוך תבנית", command=self.edit_template)
        templates_menu.add_command(label="מחק תבנית", command=self.delete_template)
        templates_menu.add_separator()
        templates_menu.add_command(label="ייבוא תבניות", command=self.import_templates)
        templates_menu.add_command(label="ייצוא תבניות", command=self.export_templates)
        
        # תפריט כלים
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="כלים", menu=tools_menu)
        tools_menu.add_command(label="מנתח תוכן", command=self.open_content_analyzer)
        tools_menu.add_command(label="בודק SEO", command=self.open_seo_checker)
        tools_menu.add_command(label="מחולל מילות מפתח", command=self.open_keyword_generator)
        tools_menu.add_separator()
        tools_menu.add_command(label="סטטיסטיקות", command=self.show_statistics)
        tools_menu.add_command(label="היסטוריה", command=self.show_history)
        
        # תפריט הגדרות
        settings_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="הגדרות", menu=settings_menu)
        settings_menu.add_command(label="הגדרות יצירה", command=self.open_generation_settings)
        settings_menu.add_command(label="הגדרות שפה", command=self.open_language_settings)
        settings_menu.add_command(label="הגדרות עיצוב", command=self.open_design_settings)
        
        # תפריט עזרה
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="עזרה", menu=help_menu)
        help_menu.add_command(label="מדריך מהיר", command=self.show_quick_guide)
        help_menu.add_command(label="דוגמאות", command=self.show_examples)
        help_menu.add_command(label="טיפים ללכתיבה", command=self.show_writing_tips)
        help_menu.add_command(label="אודות", command=self.show_about)
        
        # קיצורי מקלדת
        self.root.bind('<Control-n>', lambda e: self.new_project())
        self.root.bind('<Control-o>', lambda e: self.open_project())
        self.root.bind('<Control-s>', lambda e: self.save_project())
        self.root.bind('<F5>', lambda e: self.generate_content())
    
    def _create_toolbar(self):
        """יצירת סרגל כלים"""
        toolbar_frame = ttk.Frame(self.root, relief=tk.RAISED)
        toolbar_frame.pack(fill=tk.X, pady=(0, 5))
        
        # כפתורי פעולה מהירה
        ttk.Button(toolbar_frame, text="🆕 חדש", 
                  command=self.new_project).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="📁 פתח", 
                  command=self.open_project).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="💾 שמור", 
                  command=self.save_project).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        ttk.Button(toolbar_frame, text="✨ יצור", 
                  command=self.generate_content).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="🔧 שפר", 
                  command=self.improve_content).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_frame, text="🌐 תרגם", 
                  command=self.translate_content).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # בחירת סוג תוכן
        ttk.Label(toolbar_frame, text="סוג תוכן:").pack(side=tk.LEFT, padx=(0, 5))
        self.content_type_var = tk.StringVar(value="article")
        content_type_combo = ttk.Combobox(toolbar_frame, textvariable=self.content_type_var,
                                         values=["article", "blog_post", "social_media", "email", "marketing", "technical"],
                                         state="readonly", width=12)
        content_type_combo.pack(side=tk.LEFT, padx=2)
        
        # בחירת איכות
        ttk.Label(toolbar_frame, text="איכות:").pack(side=tk.LEFT, padx=(10, 5))
        self.quality_var = tk.StringVar(value="high")
        quality_combo = ttk.Combobox(toolbar_frame, textvariable=self.quality_var,
                                    values=["basic", "good", "high", "expert"],
                                    state="readonly", width=8)
        quality_combo.pack(side=tk.LEFT, padx=2)
        
        # מחוון סטטוס
        self.status_indicator = tk.Label(toolbar_frame, text="●", fg="green", font=('Arial', 12))
        self.status_indicator.pack(side=tk.RIGHT, padx=10)
        
        ttk.Label(toolbar_frame, text="מערכת AI:").pack(side=tk.RIGHT, padx=(0, 5))
    
    def _create_main_workspace(self):
        """יצירת אזור העבודה הראשי"""
        # פאנל ראשי עם חלוקה אופקית
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # פאנל שמאל - תבניות וכלים
        left_frame = ttk.Frame(main_paned, width=300)
        main_paned.add(left_frame, weight=1)
        
        self._create_left_panel(left_frame)
        
        # פאנל מרכז - עורך תוכן
        center_paned = ttk.PanedWindow(main_paned, orient=tk.VERTICAL)
        main_paned.add(center_paned, weight=3)
        
        # עורך תוכן
        editor_frame = ttk.LabelFrame(center_paned, text="עורך תוכן", padding=10)
        center_paned.add(editor_frame, weight=2)
        
        self._create_content_editor(editor_frame)
        
        # אזור תצוגה מקדימה
        preview_frame = ttk.LabelFrame(center_paned, text="תצוגה מקדימה", padding=10)
        center_paned.add(preview_frame, weight=1)
        
        self._create_preview_area(preview_frame)
        
        # פאנל ימין - אנליטיקה וכלים
        right_frame = ttk.Frame(main_paned, width=350)
        main_paned.add(right_frame, weight=1)
        
        self._create_right_panel(right_frame)
    
    def _create_left_panel(self, parent):
        """יצירת הפאנל השמאלי"""
        # נוטבוק לטאבים
        left_notebook = ttk.Notebook(parent)
        left_notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב תבניות
        templates_frame = ttk.Frame(left_notebook)
        left_notebook.add(templates_frame, text="תבניות")
        
        self._create_templates_panel(templates_frame)
        
        # טאב פרומפטים
        prompts_frame = ttk.Frame(left_notebook)
        left_notebook.add(prompts_frame, text="פרומפטים")
        
        self._create_prompts_panel(prompts_frame)
        
        # טאב היסטוריה
        history_frame = ttk.Frame(left_notebook)
        left_notebook.add(history_frame, text="היסטוריה")
        
        self._create_history_panel(history_frame)
    
    def _create_templates_panel(self, parent):
        """יצירת פאנל התבניות"""
        # כלי בקרה
        templates_toolbar = ttk.Frame(parent)
        templates_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(templates_toolbar, text="+ חדש", 
                  command=self.create_template).pack(side=tk.LEFT, padx=2)
        ttk.Button(templates_toolbar, text="✏ ערוך", 
                  command=self.edit_template).pack(side=tk.LEFT, padx=2)
        ttk.Button(templates_toolbar, text="🗑 מחק", 
                  command=self.delete_template).pack(side=tk.LEFT, padx=2)
        
        # רשימת תבניות
        self.templates_tree = ttk.Treeview(parent, columns=('type', 'description'), show='tree headings')
        self.templates_tree.heading('#0', text='שם תבנית')
        self.templates_tree.heading('type', text='סוג')
        self.templates_tree.heading('description', text='תיאור')
        
        self.templates_tree.column('#0', width=120)
        self.templates_tree.column('type', width=80)
        self.templates_tree.column('description', width=100)
        
        # סקרול לתבניות
        templates_scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.templates_tree.yview)
        self.templates_tree.configure(yscrollcommand=templates_scroll.set)
        
        self.templates_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        templates_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # אירועים
        self.templates_tree.bind('<Double-1>', self.on_template_double_click)
        self.templates_tree.bind('<Button-3>', self.on_template_right_click)
    
    def _create_prompts_panel(self, parent):
        """יצירת פאנל הפרומפטים"""
        # שדה חיפוש
        search_frame = ttk.Frame(parent)
        search_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(search_frame, text="חיפוש:").pack(side=tk.LEFT)
        self.prompt_search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.prompt_search_var, width=20)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        search_entry.bind('<KeyRelease>', self.on_prompt_search)
        
        # רשימת פרומפטים
        self.prompts_listbox = tk.Listbox(parent, height=15)
        self.prompts_listbox.pack(fill=tk.BOTH, expand=True)
        
        # פרומפטים מוכנים
        prompts = [
            "כתוב מאמר על...",
            "צור רשימה של...",
            "הסבר באופן פשוט...",
            "כתוב פוסט לרשתות חברתיות על...",
            "צור כותרות אטרקטיביות ל...",
            "כתוב מייל שיווקי עבור...",
            "תן טיפים ל...",
            "צור תקציר של...",
            "כתוב ביקורת על...",
            "הצע רעיונות ל..."
        ]
        
        for prompt in prompts:
            self.prompts_listbox.insert(tk.END, prompt)
        
        self.prompts_listbox.bind('<Double-1>', self.on_prompt_double_click)
    
    def _create_history_panel(self, parent):
        """יצירת פאנל ההיסטוריה"""
        # כלי בקרה
        history_toolbar = ttk.Frame(parent)
        history_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(history_toolbar, text="רענן", 
                  command=self.refresh_history).pack(side=tk.LEFT, padx=2)
        ttk.Button(history_toolbar, text="נקה", 
                  command=self.clear_history).pack(side=tk.LEFT, padx=2)
        
        # רשימת היסטוריה
        self.history_listbox = tk.Listbox(parent, height=15)
        self.history_listbox.pack(fill=tk.BOTH, expand=True)
        
        self.history_listbox.bind('<Double-1>', self.on_history_double_click)
    
    def _create_content_editor(self, parent):
        """יצירת עורך התוכן"""
        # כלי עורך
        editor_toolbar = ttk.Frame(parent)
        editor_toolbar.pack(fill=tk.X, pady=(0, 10))
        
        # כפתורי עיצוב
        ttk.Button(editor_toolbar, text="B", 
                  command=self.format_bold).pack(side=tk.LEFT, padx=2)
        ttk.Button(editor_toolbar, text="I", 
                  command=self.format_italic).pack(side=tk.LEFT, padx=2)
        ttk.Button(editor_toolbar, text="U", 
                  command=self.format_underline).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(editor_toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # גודל גופן
        ttk.Label(editor_toolbar, text="גודל:").pack(side=tk.LEFT, padx=(0, 5))
        self.font_size_var = tk.StringVar(value="12")
        font_size_combo = ttk.Combobox(editor_toolbar, textvariable=self.font_size_var,
                                      values=["8", "10", "12", "14", "16", "18", "20", "24"],
                                      state="readonly", width=5)
        font_size_combo.pack(side=tk.LEFT, padx=2)
        font_size_combo.bind('<<ComboboxSelected>>', self.on_font_size_change)
        
        # סטטיסטיקות תוכן
        self.content_stats_label = ttk.Label(editor_toolbar, text="מילים: 0 | תווים: 0")
        self.content_stats_label.pack(side=tk.RIGHT, padx=10)
        
        # עורך הטקסט הראשי
        editor_container = ttk.Frame(parent)
        editor_container.pack(fill=tk.BOTH, expand=True)
        
        self.content_editor = scrolledtext.ScrolledText(
            editor_container,
            font=('Arial', 12),
            wrap=tk.WORD,
            undo=True,
            height=20
        )
        self.content_editor.pack(fill=tk.BOTH, expand=True)
        
        # אירועים
        self.content_editor.bind('<KeyRelease>', self.on_content_change)
        self.content_editor.bind('<Button-1>', self.on_content_change)
    
    def _create_preview_area(self, parent):
        """יצירת אזור התצוגה המקדימה"""
        # כלי תצוגה מקדימה
        preview_toolbar = ttk.Frame(parent)
        preview_toolbar.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(preview_toolbar, text="🔄 רענן", 
                  command=self.refresh_preview).pack(side=tk.LEFT, padx=2)
        ttk.Button(preview_toolbar, text="🌐 HTML", 
                  command=self.preview_html).pack(side=tk.LEFT, padx=2)
        ttk.Button(preview_toolbar, text="📱 מובייל", 
                  command=self.preview_mobile).pack(side=tk.LEFT, padx=2)
        
        # אזור התצוגה המקדימה
        self.preview_area = scrolledtext.ScrolledText(
            parent,
            font=('Arial', 11),
            wrap=tk.WORD,
            state='disabled',
            height=10,
            bg='#f8f8f8'
        )
        self.preview_area.pack(fill=tk.BOTH, expand=True)
    
    def _create_right_panel(self, parent):
        """יצירת הפאנל הימני"""
        # נוטבוק לטאבים
        right_notebook = ttk.Notebook(parent)
        right_notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב אנליטיקה
        analytics_frame = ttk.Frame(right_notebook)
        right_notebook.add(analytics_frame, text="אנליטיקה")
        
        self._create_analytics_panel(analytics_frame)
        
        # טאב SEO
        seo_frame = ttk.Frame(right_notebook)
        right_notebook.add(seo_frame, text="SEO")
        
        self._create_seo_panel(seo_frame)
        
        # טאב כלים
        tools_frame = ttk.Frame(right_notebook)
        right_notebook.add(tools_frame, text="כלים")
        
        self._create_tools_panel(tools_frame)
        
        # טאב לוגים
        logs_frame = ttk.Frame(right_notebook)
        right_notebook.add(logs_frame, text="לוגים")
        
        self._create_logs_panel(logs_frame)
    
    def _create_analytics_panel(self, parent):
        """יצירת פאנל האנליטיקה"""
        # גרף ניתוח תוכן
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6, 8))
        fig.patch.set_facecolor('#f0f0f0')
        
        # גרף זמן יצירה
        ax1.set_title('זמן יצירה לאורך זמן', fontsize=10)
        ax1.set_xlabel('זמן')
        ax1.set_ylabel('שניות')
        
        # גרף איכות תוכן
        ax2.set_title('ציון איכות תוכן', fontsize=10)
        ax2.set_xlabel('יום')
        ax2.set_ylabel('ציון (1-100)')
        
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.analytics_canvas = (fig, ax1, ax2, canvas)
        
        # סטטיסטיקות מהירות
        stats_frame = ttk.LabelFrame(parent, text="סטטיסטיקות", padding=5)
        stats_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.stats_labels = {}
        stats = [
            ('total_generated', 'סה"כ יצר:', '0'),
            ('avg_quality', 'איכות ממוצעת:', '0'),
            ('total_words', 'סה"כ מילים:', '0'),
            ('avg_time', 'זמן ממוצע:', '0s')
        ]
        
        for i, (key, label, default) in enumerate(stats):
            frame = ttk.Frame(stats_frame)
            frame.pack(fill=tk.X, pady=2)
            
            ttk.Label(frame, text=label, font=('Arial', 9)).pack(side=tk.LEFT)
            stat_label = ttk.Label(frame, text=default, font=('Arial', 9, 'bold'))
            stat_label.pack(side=tk.RIGHT)
            self.stats_labels[key] = stat_label
    
    def _create_seo_panel(self, parent):
        """יצירת פאנל ה-SEO"""
        # ניקוד SEO כללי
        seo_score_frame = ttk.LabelFrame(parent, text="ניקוד SEO", padding=5)
        seo_score_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.seo_score_var = tk.StringVar(value="0")
        seo_score_label = ttk.Label(seo_score_frame, textvariable=self.seo_score_var, 
                                   font=('Arial', 24, 'bold'), foreground='green')
        seo_score_label.pack()
        
        ttk.Label(seo_score_frame, text="מתוך 100", font=('Arial', 10)).pack()
        
        # רכיבי SEO
        seo_components_frame = ttk.LabelFrame(parent, text="רכיבי SEO", padding=5)
        seo_components_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.seo_components = {}
        components = [
            ('title_length', 'אורך כותרת:', '❌'),
            ('meta_description', 'תיאור מטא:', '❌'),
            ('keyword_density', 'צפיפות מילות מפתח:', '❌'),
            ('readability', 'קריאות:', '❌'),
            ('internal_links', 'קישורים פנימיים:', '❌'),
            ('image_alt', 'תיאור תמונות:', '❌')
        ]
        
        for key, label, default in components:
            frame = ttk.Frame(seo_components_frame)
            frame.pack(fill=tk.X, pady=1)
            
            ttk.Label(frame, text=label, font=('Arial', 9)).pack(side=tk.LEFT)
            status_label = ttk.Label(frame, text=default, font=('Arial', 9))
            status_label.pack(side=tk.RIGHT)
            self.seo_components[key] = status_label
        
        # מילות מפתח מוצעות
        keywords_frame = ttk.LabelFrame(parent, text="מילות מפתח מוצעות", padding=5)
        keywords_frame.pack(fill=tk.BOTH, expand=True)
        
        self.keywords_listbox = tk.Listbox(keywords_frame, height=8)
        self.keywords_listbox.pack(fill=tk.BOTH, expand=True)
        
        # כפתור עדכון SEO
        ttk.Button(parent, text="נתח SEO", command=self.analyze_seo).pack(fill=tk.X, pady=5)
    
    def _create_tools_panel(self, parent):
        """יצירת פאנל הכלים"""
        # כלי ניתוח תוכן
        analysis_frame = ttk.LabelFrame(parent, text="ניתוח תוכן", padding=5)
        analysis_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(analysis_frame, text="נתח סנטימנט", 
                  command=self.analyze_sentiment).pack(fill=tk.X, pady=2)
        ttk.Button(analysis_frame, text="זהה נושאים", 
                  command=self.detect_topics).pack(fill=tk.X, pady=2)
        ttk.Button(analysis_frame, text="בדוק ייחודיות", 
                  command=self.check_uniqueness).pack(fill=tk.X, pady=2)
        
        # כלי שיפור
        improvement_frame = ttk.LabelFrame(parent, text="שיפור תוכן", padding=5)
        improvement_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(improvement_frame, text="שפר קריאות", 
                  command=self.improve_readability).pack(fill=tk.X, pady=2)
        ttk.Button(improvement_frame, text="הוסף מילות מפתח", 
                  command=self.add_keywords).pack(fill=tk.X, pady=2)
        ttk.Button(improvement_frame, text="קצר טקסט", 
                  command=self.shorten_text).pack(fill=tk.X, pady=2)
        
        # כלי פורמט
        format_frame = ttk.LabelFrame(parent, text="פורמט", padding=5)
        format_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(format_frame, text="הוסף כותרות", 
                  command=self.add_headings).pack(fill=tk.X, pady=2)
        ttk.Button(format_frame, text="הוסף רשימות", 
                  command=self.add_lists).pack(fill=tk.X, pady=2)
        ttk.Button(format_frame, text="הוסף קישורים", 
                  command=self.add_links).pack(fill=tk.X, pady=2)
        
        # תוצאות ניתוח
        results_frame = ttk.LabelFrame(parent, text="תוצאות", padding=5)
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        self.results_text = scrolledtext.ScrolledText(results_frame, height=8, font=('Arial', 9))
        self.results_text.pack(fill=tk.BOTH, expand=True)
    
    def _create_logs_panel(self, parent):
        """יצירת פאנל הלוגים"""
        # כלי בקרה ללוגים
        logs_toolbar = ttk.Frame(parent)
        logs_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(logs_toolbar, text="נקה", 
                  command=self.clear_logs).pack(side=tk.LEFT, padx=2)
        ttk.Button(logs_toolbar, text="שמור", 
                  command=self.save_logs).pack(side=tk.LEFT, padx=2)
        
        # רמת לוג
        ttk.Label(logs_toolbar, text="רמה:").pack(side=tk.LEFT, padx=(10, 5))
        self.log_level_var = tk.StringVar(value="INFO")
        log_combo = ttk.Combobox(logs_toolbar, textvariable=self.log_level_var,
                                values=["DEBUG", "INFO", "WARNING", "ERROR"],
                                state="readonly", width=8)
        log_combo.pack(side=tk.LEFT, padx=2)
        
        # אזור הלוגים
        self.log_text = scrolledtext.ScrolledText(
            parent,
            height=15,
            font=('Consolas', 9),
            bg='#1a1a1a',
            fg='#00ff00'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
    
    def _create_status_bar(self):
        """יצירת סרגל סטטוס"""
        status_frame = ttk.Frame(self.root)
        status_frame.pack(fill=tk.X, pady=(5, 0))
        
        # סטטוס שמאל
        self.status_left = ttk.Label(status_frame, text="מוכן")
        self.status_left.pack(side=tk.LEFT)
        
        # פס התקדמות
        self.progress_bar = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress_bar.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # סטטוס ימין
        self.status_right = ttk.Label(status_frame, text="Hebrew | איכות גבוהה")
        self.status_right.pack(side=tk.RIGHT)
    
    # ========== פונקציות יצירת תוכן ==========
    
    def generate_content(self):
        """יצירת תוכן חדש"""
        if not self.content_engine:
            self.show_message("מנוע התוכן לא זמין", "error")
            return
        
        # שאל למידע נדרש
        prompt = self._get_generation_prompt()
        if not prompt:
            return
        
        # התחל יצירה באסינכרוני
        threading.Thread(target=self._generate_async, args=(prompt,), daemon=True).start()
    
    def _get_generation_prompt(self) -> str:
        """קבלת פרומפט ליצירת תוכן"""
        dialog = ContentPromptDialog(self.root)
        self.root.wait_window(dialog.dialog)
        return dialog.result
    
    def _generate_async(self, prompt: str):
        """יצירה אסינכרונית של תוכן"""
        try:
            # עדכון UI - התחלה
            self.root.after(0, lambda: self._update_generation_start())
            
            # הכנת בקשת יצירה
            generation_request = {
                'prompt': prompt,
                'content_type': self.content_type_var.get(),
                'quality_level': self.quality_var.get(),
                'language': self.settings['language'],
                'creativity_level': self.settings['creativity_level'],
                'target_audience': self.settings['target_audience'],
                'content_length': self.settings['content_length']
            }
            
            # יצירת התוכן
            if self.content_engine:
                result = asyncio.run(self.content_engine.generate_content(generation_request))
            else:
                result = self._simulate_generation(prompt)
            
            # עדכון תוצאות
            self.root.after(0, lambda: self._update_generation_result(result))
            
        except Exception as e:
            error_msg = f"שגיאה ביצירת תוכן: {str(e)}"
            self.root.after(0, lambda: self._update_generation_error(error_msg))
    
    def _simulate_generation(self, prompt: str) -> dict:
        """סימולציה של יצירת תוכן"""
        import time
        time.sleep(2)  # סימולציה של זמן יצירה
        
        return {
            'success': True,
            'content': f"תוכן שנוצר בהתבסס על: {prompt}\n\nזהו תוכן לדוגמה שנוצר במערכת AI מתקדמת.",
            'quality_score': 85,
            'generation_time': 2.1,
            'word_count': 15,
            'character_count': 95
        }
    
    def _update_generation_start(self):
        """עדכון תחילת יצירה"""
        self.progress_bar.start()
        self.status_left.config(text="יוצר תוכן...")
        self.status_indicator.config(fg="orange")
    
    def _update_generation_result(self, result: dict):
        """עדכון תוצאות יצירה"""
        if result['success']:
            # הוספת התוכן לעורך
            self.content_editor.delete("1.0", tk.END)
            self.content_editor.insert("1.0", result['content'])
            
            # עדכון סטטוס
            self.status_left.config(text=f"הושלם בהצלחה ({result['generation_time']:.1f}s)")
            self.status_indicator.config(fg="green")
            
            # הוספה להיסטוריה
            self._add_to_history(result)
            
            # עדכון אנליטיקה
            self._update_analytics(result)
            
            self.log_message(f"תוכן נוצר בהצלחה - {result['word_count']} מילים", "INFO")
        else:
            self.show_message(f"שגיאה ביצירת תוכן: {result.get('error', 'שגיאה לא ידועה')}", "error")
    
    def _update_generation_error(self, error_msg: str):
        """עדכון שגיאת יצירה"""
        self.show_message(error_msg, "error")
        self.status_left.config(text="שגיאה ביצירה")
        self.status_indicator.config(fg="red")
    
    def improve_content(self):
        """שיפור התוכן הקיים"""
        current_content = self.content_editor.get("1.0", tk.END).strip()
        if not current_content:
            self.show_message("אין תוכן לשיפור", "warning")
            return
        
        self.show_message("משפר תוכן...", "info")
        # יישום שיפור תוכן
    
    def translate_content(self):
        """תרגום התוכן"""
        current_content = self.content_editor.get("1.0", tk.END).strip()
        if not current_content:
            self.show_message("אין תוכן לתרגום", "warning")
            return
        
        # בחירת שפת יעד
        target_language = self._select_target_language()
        if target_language:
            self.show_message(f"מתרגם ל{target_language}...", "info")
            # יישום תרגום
    
    def check_grammar(self):
        """בדיקת דקדוק"""
        current_content = self.content_editor.get("1.0", tk.END).strip()
        if not current_content:
            self.show_message("אין תוכן לבדיקה", "warning")
            return
        
        self.show_message("בודק דקדוק...", "info")
        # יישום בדיקת דקדוק
    
    # ========== פונקציות UI ==========
    
    def on_content_change(self, event=None):
        """טיפול בשינוי תוכן"""
        content = self.content_editor.get("1.0", tk.END)
        words = len(content.split())
        chars = len(content)
        
        self.content_stats_label.config(text=f"מילים: {words} | תווים: {chars}")
        
        # עדכון תצוגה מקדימה
        self.root.after_idle(self.refresh_preview)
    
    def refresh_preview(self):
        """רענון תצוגה מקדימה"""
        content = self.content_editor.get("1.0", tk.END)
        
        self.preview_area.config(state='normal')
        self.preview_area.delete("1.0", tk.END)
        self.preview_area.insert("1.0", content)
        self.preview_area.config(state='disabled')
    
    def on_template_double_click(self, event):
        """טיפול בקליק כפול על תבנית"""
        selection = self.templates_tree.selection()
        if selection:
            template_name = self.templates_tree.item(selection[0])['text']
            self.load_template(template_name)
    
    def on_prompt_double_click(self, event):
        """טיפול בקליק כפול על פרומפט"""
        selection = self.prompts_listbox.curselection()
        if selection:
            prompt = self.prompts_listbox.get(selection[0])
            # הוספת הפרומפט לעורך או יצירה מיידית
            self.show_message(f"נבחר: {prompt}", "info")
    
    def on_history_double_click(self, event):
        """טיפול בקליק כפול על היסטוריה"""
        selection = self.history_listbox.curselection()
        if selection:
            # טעינת תוכן מההיסטוריה
            self.show_message("טוען מההיסטוריה...", "info")
    
    def show_message(self, message: str, msg_type: str = "info"):
        """הצגת הודעה"""
        self.status_left.config(text=message)
        self.log_message(message, msg_type.upper())
    
    def log_message(self, message: str, level: str = "INFO"):
        """הוספת הודעה ללוג"""
        if self.log_text:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {level}: {message}\n"
            
            self.log_text.insert(tk.END, log_entry)
            self.log_text.see(tk.END)
    
    # ========== פונקציות פרויקט ==========
    
    def new_project(self):
        """פרויקט חדש"""
        if self.content_editor.get("1.0", tk.END).strip():
            if not messagebox.askyesno("פרויקט חדש", "האם לשמור את הפרויקט הנוכחי?"):
                return
            self.save_project()
        
        self.content_editor.delete("1.0", tk.END)
        self.preview_area.config(state='normal')
        self.preview_area.delete("1.0", tk.END)
        self.preview_area.config(state='disabled')
        
        self.current_project = None
        self.show_message("פרויקט חדש נוצר", "info")
    
    def open_project(self):
        """פתיחת פרויקט"""
        filename = filedialog.askopenfilename(
            title="פתח פרויקט",
            filetypes=[
                ("JSON files", "*.json"),
                ("Text files", "*.txt"),
                ("All files", "*.*")
            ]
        )
        
        if filename:
            try:
                with open(filename, 'r', encoding='utf-8') as file:
                    if filename.endswith('.json'):
                        project_data = json.load(file)
                        content = project_data.get('content', '')
                        self.settings.update(project_data.get('settings', {}))
                    else:
                        content = file.read()
                
                self.content_editor.delete("1.0", tk.END)
                self.content_editor.insert("1.0", content)
                
                self.current_project = filename
                self.show_message(f"נפתח: {Path(filename).name}", "info")
                
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לפתוח פרויקט:\n{str(e)}")
    
    def save_project(self):
        """שמירת פרויקט"""
        if not self.current_project:
            self.save_as_project()
            return
        
        self._save_project_to_file(self.current_project)
    
    def save_as_project(self):
        """שמירת פרויקט בשם חדש"""
        filename = filedialog.asksaveasfilename(
            title="שמור פרויקט",
            defaultextension=".json",
            filetypes=[
                ("JSON files", "*.json"),
                ("Text files", "*.txt"),
                ("All files", "*.*")
            ]
        )
        
        if filename:
            self._save_project_to_file(filename)
            self.current_project = filename
    
    def _save_project_to_file(self, filename: str):
        """שמירת פרויקט לקובץ"""
        try:
            content = self.content_editor.get("1.0", tk.END)
            
            if filename.endswith('.json'):
                project_data = {
                    'content': content,
                    'settings': self.settings,
                    'metadata': {
                        'created': datetime.now().isoformat(),
                        'version': '1.0'
                    }
                }
                
                with open(filename, 'w', encoding='utf-8') as file:
                    json.dump(project_data, file, ensure_ascii=False, indent=2)
            else:
                with open(filename, 'w', encoding='utf-8') as file:
                    file.write(content)
            
            self.show_message(f"נשמר: {Path(filename).name}", "info")
            
        except Exception as e:
            messagebox.showerror("שגיאה", f"לא ניתן לשמור פרויקט:\n{str(e)}")
    
    # ========== פונקציות נוספות ==========
    
    def load_default_templates(self):
        """טעינת תבניות ברירת מחדל"""
        default_templates = {
            'מאמר בלוג': {'type': 'blog', 'description': 'תבנית למאמר בלוג'},
            'פוסט פייסבוק': {'type': 'social', 'description': 'תבנית לפוסט ברשתות חברתיות'},
            'מייל שיווקי': {'type': 'email', 'description': 'תבנית למייל שיווקי'},
            'מאמר טכני': {'type': 'technical', 'description': 'תבנית למאמר טכני'}
        }
        
        for name, data in default_templates.items():
            self.templates_tree.insert('', 'end', text=name, 
                                     values=(data['type'], data['description']))
    
    def start_monitoring(self):
        """התחלת ניטור מערכת"""
        self.running = True
        threading.Thread(target=self._monitoring_loop, daemon=True).start()
    
    def _monitoring_loop(self):
        """לולאת ניטור"""
        while self.running:
            try:
                # עדכון סטטיסטיקות
                self.root.after(0, self._update_statistics)
                threading.Event().wait(5)  # עדכון כל 5 שניות
            except Exception as e:
                self.log_message(f"שגיאה בניטור: {e}", "ERROR")
    
    def _update_statistics(self):
        """עדכון סטטיסטיקות"""
        # עדכון סטטיסטיקות בפאנל האנליטיקה
        if hasattr(self, 'stats_labels'):
            self.stats_labels['total_generated'].config(text=str(len(self.generation_history)))
    
    def _add_to_history(self, result: dict):
        """הוספה להיסטוריית יצירה"""
        history_entry = {
            'timestamp': datetime.now(),
            'content': result['content'][:50] + '...',  # תצוגה קצרה
            'quality_score': result.get('quality_score', 0),
            'generation_time': result.get('generation_time', 0)
        }
        
        self.generation_history.append(history_entry)
        
        # עדכון רשימת היסטוריה
        self.history_listbox.insert(0, f"{history_entry['timestamp'].strftime('%H:%M')} - {history_entry['content']}")
    
    def _update_analytics(self, result: dict):
        """עדכון נתוני אנליטיקה"""
        # עדכון הגרפים והנתונים
        pass
    
    def shutdown(self):
        """כיבוי המערכת"""
        self.running = False
        if self.root:
            self.root.destroy()
    
    # ========== פונקציות stub (יישום חלקי) ==========
    
    def format_bold(self): pass
    def format_italic(self): pass
    def format_underline(self): pass
    def on_font_size_change(self, event): pass
    def preview_html(self): pass
    def preview_mobile(self): pass
    def analyze_seo(self): pass
    def analyze_sentiment(self): pass
    def detect_topics(self): pass
    def check_uniqueness(self): pass
    def improve_readability(self): pass
    def add_keywords(self): pass
    def shorten_text(self): pass
    def add_headings(self): pass
    def add_lists(self): pass
    def add_links(self): pass
    def clear_logs(self): pass
    def save_logs(self): pass
    def create_template(self): pass
    def edit_template(self): pass
    def delete_template(self): pass
    def load_template(self, name): pass
    def import_templates(self): pass
    def export_templates(self): pass
    def export_to_word(self): pass
    def export_to_pdf(self): pass
    def export_to_html(self): pass
    def generate_headlines(self): pass
    def generate_summary(self): pass
    def generate_list(self): pass
    def on_prompt_search(self, event): pass
    def refresh_history(self): pass
    def clear_history(self): pass
    def on_template_right_click(self, event): pass
    def open_content_analyzer(self): pass
    def open_seo_checker(self): pass
    def open_keyword_generator(self): pass
    def show_statistics(self): pass
    def show_history(self): pass
    def open_generation_settings(self): pass
    def open_language_settings(self): pass
    def open_design_settings(self): pass
    def show_quick_guide(self): pass
    def show_examples(self): pass
    def show_writing_tips(self): pass
    def show_about(self): pass
    def _select_target_language(self): return "אנגלית"

class ContentPromptDialog:
    """דיאלוג לקבלת פרומפט יצירת תוכן"""
    
    def __init__(self, parent):
        self.result = None
        
        # יצירת חלון דיאלוג
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("יצירת תוכן חדש")
        self.dialog.geometry("500x400")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # מרכוז החלון
        self.dialog.geometry("+%d+%d" % (parent.winfo_rootx() + 50, parent.winfo_rooty() + 50))
        
        self._create_dialog_content()
    
    def _create_dialog_content(self):
        """יצירת תוכן הדיאלוג"""
        # כותרת
        title_label = ttk.Label(self.dialog, text="מה תרצה שיצור עבורך?", 
                               font=('Arial', 14, 'bold'))
        title_label.pack(pady=10)
        
        # שדה טקסט לפרומפט
        ttk.Label(self.dialog, text="תאר את התוכן שברצונך ליצור:").pack(anchor=tk.W, padx=20, pady=(10, 5))
        
        self.prompt_text = scrolledtext.ScrolledText(self.dialog, height=8, wrap=tk.WORD)
        self.prompt_text.pack(fill=tk.BOTH, expand=True, padx=20, pady=5)
        
        # דוגמאות מהירות
        examples_frame = ttk.LabelFrame(self.dialog, text="דוגמאות מהירות", padding=5)
        examples_frame.pack(fill=tk.X, padx=20, pady=10)
        
        examples = [
            "כתוב מאמר על יתרונות הבינה המלאכותית",
            "צור רשימה של 10 טיפים לשיפור הפרודוקטיביות",
            "כתוב תיאור מוצר למכירה באינטרנט"
        ]
        
        for example in examples:
            btn = ttk.Button(examples_frame, text=example[:40] + "...", 
                           command=lambda ex=example: self._use_example(ex))
            btn.pack(fill=tk.X, pady=1)
        
        # כפתורים
        buttons_frame = ttk.Frame(self.dialog)
        buttons_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Button(buttons_frame, text="יצור", command=self._on_generate).pack(side=tk.RIGHT, padx=(5, 0))
        ttk.Button(buttons_frame, text="ביטול", command=self._on_cancel).pack(side=tk.RIGHT)
        
        # פוקוס ראשוני
        self.prompt_text.focus_set()
    
    def _use_example(self, example: str):
        """שימוש בדוגמה"""
        self.prompt_text.delete("1.0", tk.END)
        self.prompt_text.insert("1.0", example)
    
    def _on_generate(self):
        """אישור יצירה"""
        self.result = self.prompt_text.get("1.0", tk.END).strip()
        if self.result:
            self.dialog.destroy()
        else:
            messagebox.showwarning("שגיאה", "נא להזין תיאור לתוכן")
    
    def _on_cancel(self):
        """ביטול"""
        self.result = None
        self.dialog.destroy()

def main():
    """פונקציה ראשית להפעלת הממשק"""
    app = ContentStudio()
    root = app.create_ui()
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("סגירת המערכת...")
    finally:
        app.shutdown()

if __name__ == "__main__":
    main()