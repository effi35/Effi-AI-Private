"""
Content Engine - מנוע יצירת תוכן מתקדם
מנוע AI מתקדם ליצירת תוכן איכותי במגוון שפות וסוגים
"""

import asyncio
import threading
import time
import re
import nltk
import spacy
from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM
from typing import Dict, List, Optional, Any, Callable, Union, Tuple
from datetime import datetime, timedelta
import logging
import uuid
import json
import numpy as np
from collections import Counter, defaultdict
import requests
from concurrent.futures import ThreadPoolExecutor

from ..models.content_generation import (
    ContentGeneration, GenerationResult, GenerationTask, GenerationMetrics,
    ContentType, ProcessingType, LanguageType, QualityLevel, AnalysisDepth,
    ContentRequirements, ContentTemplateLibrary
)
from ..models.config import AdvancedNLPConfig

class ContentEngine:
    """מנוע יצירת תוכן מתקדם עם AI"""
    
    def __init__(self, config: AdvancedNLPConfig = None):
        self.config = config or AdvancedNLPConfig()
        self.logger = self._setup_logger()
        
        # טעינת מודלי AI
        self.language_models = {}
        self.tokenizers = {}
        self.nlp_pipelines = {}
        
        # מטמון תוכן
        self.content_cache: Dict[str, Any] = {}
        self.template_cache: Dict[str, Any] = {}
        
        # סטטיסטיקות
        self.generation_stats = {
            'total_generations': 0,
            'successful_generations': 0,
            'failed_generations': 0,
            'average_generation_time': 0.0,
            'total_words_generated': 0,
            'languages_used': set(),
            'content_types_used': set()
        }
        
        # משימות פעילות
        self.active_tasks: Dict[str, GenerationTask] = {}
        self.active_generations: Dict[str, Dict[str, Any]] = {}
        
        # Thread pool לעיבוד מקבילי
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        # אתחול מודלים
        self._initialize_models()
        
        # טעינת תבניות
        self._load_templates()
        
        self.logger.info("מנוע יצירת תוכן הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים"""
        logger = logging.getLogger("ContentEngine")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _initialize_models(self):
        """אתחול מודלי AI"""
        
        self.logger.info("טוען מודלי AI...")
        
        try:
            # מודל יצירת טקסט רב-לשוני
            self.text_generator = pipeline(
                "text-generation",
                model="gpt2",
                tokenizer="gpt2",
                device=0 if self.config.use_gpu else -1
            )
            
            # מודל סיכום
            self.summarizer = pipeline(
                "summarization",
                model="facebook/bart-large-cnn",
                device=0 if self.config.use_gpu else -1
            )
            
            # מודל תרגום
            self.translator = pipeline(
                "translation",
                model="Helsinki-NLP/opus-mt-en-he",
                device=0 if self.config.use_gpu else -1
            )
            
            # מודל ניתוח רגשות
            self.sentiment_analyzer = pipeline(
                "sentiment-analysis",
                model="cardiffnlp/twitter-roberta-base-sentiment-latest",
                device=0 if self.config.use_gpu else -1
            )
            
            # מודל זיהוי ישויות
            self.ner_pipeline = pipeline(
                "ner",
                model="dbmdz/bert-large-cased-finetuned-conll03-english",
                aggregation_strategy="simple",
                device=0 if self.config.use_gpu else -1
            )
            
            # מודלי spaCy לעיבוד טקסט
            try:
                self.nlp_en = spacy.load("en_core_web_sm")
            except OSError:
                self.logger.warning("מודל spaCy אנגלית לא זמין")
                self.nlp_en = None
            
            try:
                self.nlp_he = spacy.load("he_core_news_sm")
            except OSError:
                self.logger.warning("מודל spaCy עברית לא זמין")
                self.nlp_he = None
            
            self.logger.info("מודלי AI נטענו בהצלחה")
            
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת מודלי AI: {e}")
            # fallback למודלים בסיסיים
            self._initialize_fallback_models()
    
    def _initialize_fallback_models(self):
        """אתחול מודלים בסיסיים כ-fallback"""
        self.logger.info("טוען מודלים בסיסיים...")
        
        # מודלים בסיסיים ללא GPU
        self.text_generator = None
        self.summarizer = None
        self.translator = None
        self.sentiment_analyzer = None
        self.ner_pipeline = None
    
    def _load_templates(self):
        """טעינת תבניות תוכן"""
        
        self.templates = {
            'marketing': ContentTemplateLibrary.get_marketing_templates(),
            'technical': ContentTemplateLibrary.get_technical_templates(),
            'creative': ContentTemplateLibrary.get_creative_templates(),
            'business': ContentTemplateLibrary.get_business_templates()
        }
        
        self.logger.info(f"נטענו {sum(len(templates) for templates in self.templates.values())} תבניות")
    
    async def generate_content(self, generation: ContentGeneration) -> GenerationResult:
        """יצירת תוכן אסינכרונית"""
        
        generation_id = generation.generation_id
        self.logger.info(f"מתחיל יצירת תוכן: {generation_id} ({generation.content_type.value})")
        
        start_time = time.time()
        
        # יצירת תוצאה ראשונית
        result = GenerationResult(
            generation_id=generation_id,
            generated_content="",
            generated_at=datetime.now(),
            generation_time=0.0,
            metrics=GenerationMetrics()
        )
        
        try:
            # רישום יצירה פעילה
            self.active_generations[generation_id] = {
                'generation': generation,
                'result': result,
                'start_time': start_time
            }
            
            # בדיקת תקינות דרישות
            validation_issues = generation.validate_requirements()
            if validation_issues:
                result.warnings.extend(validation_issues)
                self.logger.warning(f"בעיות בדרישות: {validation_issues}")
            
            # יצירת תוכן לפי סוג
            generated_text = await self._generate_by_type(generation)
            
            # עיבוד התוצאה
            processed_content = await self._post_process_content(generated_text, generation)
            result.generated_content = processed_content
            
            # חישוב מדדים
            result.metrics = self._calculate_metrics(processed_content, generation)
            
            # יצירת אלטרנטיבות
            if generation.quality_level in [QualityLevel.EXPERT, QualityLevel.MASTER]:
                alternatives = await self._generate_alternatives(generation, processed_content)
                result.alternative_versions = alternatives
            
            # בדיקות איכות
            await self._quality_checks(result, generation)
            
            # אופטימיזציה SEO (אם נדרש)
            if generation.enable_seo_optimization:
                await self._optimize_for_seo(result, generation)
            
            # בדיקת עובדות (אם נדרש)
            if generation.enable_fact_checking:
                await self._fact_check_content(result)
            
            # הצעות שיפור
            result.suggestions = self._generate_suggestions(result, generation)
            
            # ניתוח רגשות ונושאים
            await self._analyze_content(result)
            
            # עדכון סטטיסטיקות
            self._update_statistics(result, generation)
            
        except Exception as e:
            result.warnings.append(f"שגיאה ביצירת תוכן: {str(e)}")
            self.logger.error(f"שגיאה ביצירת תוכן {generation_id}: {e}")
            
        finally:
            # חישוב זמן יצירה
            result.generation_time = time.time() - start_time
            result.metrics.generation_time_seconds = result.generation_time
            
            # ניקוי יצירה פעילה
            self.active_generations.pop(generation_id, None)
        
        self.logger.info(f"יצירת תוכן הושלמה: {generation_id} ({result.generation_time:.2f}s)")
        return result
    
    async def _generate_by_type(self, generation: ContentGeneration) -> str:
        """יצירת תוכן לפי סוג"""
        
        content_type = generation.content_type
        processing_type = generation.processing_type
        
        if processing_type == ProcessingType.GENERATION:
            return await self._generate_from_scratch(generation)
        elif processing_type == ProcessingType.SUMMARIZATION:
            return await self._summarize_content(generation)
        elif processing_type == ProcessingType.EXPANSION:
            return await self._expand_content(generation)
        elif processing_type == ProcessingType.REWRITING:
            return await self._rewrite_content(generation)
        elif processing_type == ProcessingType.TRANSLATION:
            return await self._translate_content(generation)
        else:
            return await self._generate_from_scratch(generation)
    
    async def _generate_from_scratch(self, generation: ContentGeneration) -> str:
        """יצירת תוכן מאפס"""
        
        # בחירת תבנית מתאימה
        template = self._select_template(generation)
        
        # בניית פרומפט
        prompt = self._build_generation_prompt(generation, template)
        
        # יצירת תוכן בהתבסס על סוג התוכן
        if generation.content_type == ContentType.MARKETING_COPY:
            return await self._generate_marketing_content(generation, prompt)
        elif generation.content_type == ContentType.TECHNICAL_DOC:
            return await self._generate_technical_content(generation, prompt)
        elif generation.content_type == ContentType.CREATIVE_WRITING:
            return await self._generate_creative_content(generation, prompt)
        elif generation.content_type == ContentType.BUSINESS_PLAN:
            return await self._generate_business_content(generation, prompt)
        elif generation.content_type == ContentType.BLOG_POST:
            return await self._generate_blog_content(generation, prompt)
        else:
            return await self._generate_generic_content(generation, prompt)
    
    async def _generate_marketing_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן שיווקי"""
        
        requirements = generation.requirements
        
        # מבנה תוכן שיווקי
        sections = []
        
        # כותרת מושכת
        headline = await self._generate_headline(generation)
        sections.append(f"# {headline}\n")
        
        # פתיחה שמושכת תשומת לב
        hook = await self._generate_hook(generation)
        sections.append(f"{hook}\n")
        
        # הצגת הבעיה
        if "בעיה" in requirements.key_points or "problem" in [kp.lower() for kp in requirements.key_points]:
            problem_section = await self._generate_problem_section(generation)
            sections.append(f"## הבעיה\n{problem_section}\n")
        
        # הצגת הפתרון
        solution_section = await self._generate_solution_section(generation)
        sections.append(f"## הפתרון\n{solution_section}\n")
        
        # יתרונות מפתח
        benefits_section = await self._generate_benefits_section(generation)
        sections.append(f"## יתרונות מפתח\n{benefits_section}\n")
        
        # עדויות/המלצות (אם נדרש)
        if requirements.include_examples:
            testimonials = await self._generate_testimonials(generation)
            sections.append(f"## מה הלקוחות אומרים\n{testimonials}\n")
        
        # קריאה לפעולה
        if requirements.call_to_action:
            cta_section = f"## הצטרף אלינו עוד היום\n{requirements.call_to_action}\n"
            sections.append(cta_section)
        
        return "\n".join(sections)
    
    async def _generate_technical_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן טכני"""
        
        requirements = generation.requirements
        
        sections = []
        
        # סקירה כללית
        overview = await self._generate_technical_overview(generation)
        sections.append(f"# סקירה כללית\n{overview}\n")
        
        # דרישות מקדימות
        prerequisites = await self._generate_prerequisites(generation)
        sections.append(f"## דרישות מקדימות\n{prerequisites}\n")
        
        # הוראות שלב אחר שלב
        instructions = await self._generate_step_by_step(generation)
        sections.append(f"## הוראות יישום\n{instructions}\n")
        
        # דוגמאות קוד (אם רלוונטי)
        if requirements.include_examples:
            code_examples = await self._generate_code_examples(generation)
            sections.append(f"## דוגמאות קוד\n{code_examples}\n")
        
        # פתרון בעיות נפוצות
        troubleshooting = await self._generate_troubleshooting(generation)
        sections.append(f"## פתרון בעיות נפוצות\n{troubleshooting}\n")
        
        return "\n".join(sections)
    
    async def _generate_creative_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן יצירתי"""
        
        if generation.content_type == ContentType.STORYTELLING:
            return await self._generate_story(generation)
        elif generation.content_type == ContentType.POETRY:
            return await self._generate_poetry(generation)
        else:
            return await self._generate_creative_piece(generation)
    
    async def _generate_story(self, generation: ContentGeneration) -> str:
        """יצירת סיפור"""
        
        requirements = generation.requirements
        
        # מרכיבי סיפור
        sections = []
        
        # הקמת תפאורה ודמויות
        setting = await self._generate_story_setting(generation)
        sections.append(setting)
        
        # פיתוח עלילה
        plot_development = await self._generate_plot_development(generation)
        sections.append(plot_development)
        
        # שיא
        climax = await self._generate_story_climax(generation)
        sections.append(climax)
        
        # פתרון וסיום
        resolution = await self._generate_story_resolution(generation)
        sections.append(resolution)
        
        return "\n\n".join(sections)
    
    async def _generate_business_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן עסקי"""
        
        requirements = generation.requirements
        
        sections = []
        
        # תקציר מנהלים
        executive_summary = await self._generate_executive_summary(generation)
        sections.append(f"# תקציר מנהלים\n{executive_summary}\n")
        
        # ניתוח שוק
        market_analysis = await self._generate_market_analysis(generation)
        sections.append(f"## ניתוח שוק\n{market_analysis}\n")
        
        # אסטרטגיה
        strategy = await self._generate_strategy_section(generation)
        sections.append(f"## אסטרטגיה\n{strategy}\n")
        
        # תחזיות כספיות
        if requirements.include_statistics:
            financial_projections = await self._generate_financial_projections(generation)
            sections.append(f"## תחזיות כספיות\n{financial_projections}\n")
        
        # סיכונים והזדמנויות
        risks_opportunities = await self._generate_risks_opportunities(generation)
        sections.append(f"## סיכונים והזדמנויות\n{risks_opportunities}\n")
        
        return "\n".join(sections)
    
    async def _generate_blog_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן בלוג"""
        
        requirements = generation.requirements
        
        sections = []
        
        # כותרת מושכת
        title = await self._generate_blog_title(generation)
        sections.append(f"# {title}\n")
        
        # פתיחה מעניינת
        introduction = await self._generate_blog_introduction(generation)
        sections.append(f"{introduction}\n")
        
        # תוכן עיקרי מחולק לסעיפים
        for i, key_point in enumerate(requirements.key_points, 1):
            section_content = await self._generate_blog_section(generation, key_point)
            sections.append(f"## {key_point}\n{section_content}\n")
        
        # סיכום ומסקנות
        conclusion = await self._generate_blog_conclusion(generation)
        sections.append(f"## סיכום\n{conclusion}\n")
        
        return "\n".join(sections)
    
    async def _generate_generic_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן גנרי"""
        
        if self.text_generator:
            try:
                # שימוש במודל יצירת טקסט
                result = self.text_generator(
                    prompt,
                    max_length=generation.requirements.length_words[1],
                    num_return_sequences=1,
                    temperature=generation.creativity_level,
                    do_sample=True,
                    pad_token_id=50256
                )
                
                return result[0]['generated_text']
            except Exception as e:
                self.logger.warning(f"שגיאה במודל יצירת טקסט: {e}")
        
        # fallback ליצירה בסיסית
        return await self._generate_basic_content(generation, prompt)
    
    async def _generate_basic_content(self, generation: ContentGeneration, prompt: str) -> str:
        """יצירת תוכן בסיסית ללא מודלים מתקדמים"""
        
        requirements = generation.requirements
        
        # יצירה בסיסית עם תבניות
        template = self._select_template(generation)
        
        if template:
            structure = template.get('structure', [])
            content_parts = []
            
            for section in structure:
                section_content = await self._generate_section_basic(section, generation)
                content_parts.append(f"## {section}\n{section_content}\n")
            
            return "\n".join(content_parts)
        
        # fallback פשוט
        return self._generate_simple_content(generation)
    
    def _generate_simple_content(self, generation: ContentGeneration) -> str:
        """יצירת תוכן פשוט מאוד"""
        
        requirements = generation.requirements
        
        content = f"# {generation.title or 'תוכן חדש'}\n\n"
        
        for point in requirements.key_points:
            content += f"## {point}\n\n"
            content += f"כאן יפותח הנושא של {point} בהתאם לדרישות הלקוח.\n\n"
        
        if requirements.call_to_action:
            content += f"## קריאה לפעולה\n{requirements.call_to_action}\n"
        
        return content
    
    async def _post_process_content(self, content: str, generation: ContentGeneration) -> str:
        """עיבוד תוכן לאחר יצירה"""
        
        # ניקוי וטיוב
        processed = self._clean_content(content)
        
        # התאמה לדרישות אורך
        processed = await self._adjust_length(processed, generation.requirements.length_words)
        
        # הוספת מילות מפתח (אם נדרש)
        processed = self._integrate_keywords(processed, generation.requirements.keywords)
        
        # תיקון דקדוק בסיסי
        processed = self._basic_grammar_check(processed)
        
        # התאמה לטון הנדרש
        processed = await self._adjust_tone(processed, generation.requirements.tone)
        
        return processed
    
    def _clean_content(self, content: str) -> str:
        """ניקוי תוכן מבסיסי"""
        
        # הסרת רווחים מיותרים
        content = re.sub(r'\s+', ' ', content)
        
        # תיקון פיסוק בסיסי
        content = re.sub(r'\s+([.,!?;:])', r'\1', content)
        
        # הסרת שורות ריקות מיותרות
        content = re.sub(r'\n{3,}', '\n\n', content)
        
        return content.strip()
    
    async def _adjust_length(self, content: str, length_range: Tuple[int, int]) -> str:
        """התאמת אורך תוכן"""
        
        words = content.split()
        current_length = len(words)
        min_words, max_words = length_range
        
        if current_length < min_words:
            # הרחבת תוכן
            expansion_needed = min_words - current_length
            expanded = await self._expand_text(content, expansion_needed)
            return expanded
        
        elif current_length > max_words:
            # קיצור תוכן
            ratio = max_words / current_length
            truncated_words = words[:int(len(words) * ratio)]
            return ' '.join(truncated_words)
        
        return content
    
    async def _expand_text(self, text: str, additional_words: int) -> str:
        """הרחבת טקסט"""
        
        # הרחבה בסיסית - הוספת פיתוח לנקודות קיימות
        sentences = text.split('.')
        expanded_sentences = []
        
        for sentence in sentences:
            if sentence.strip():
                expanded_sentences.append(sentence.strip())
                
                # הוספת פירוט אם נדרש
                if additional_words > 0:
                    detail = self._generate_detail_for_sentence(sentence)
                    expanded_sentences.append(detail)
                    additional_words -= len(detail.split())
        
        return '. '.join(expanded_sentences) + '.'
    
    def _generate_detail_for_sentence(self, sentence: str) -> str:
        """יצירת פירוט למשפט"""
        
        details = [
            "נקודה זו מחזקת את הרעיון המרכזי",
            "כך ניתן להבטיח תוצאות אופטימליות",
            "זהו גורם חשוב להצלחה",
            "דבר זה תורם לשיפור הביצועים",
            "נושא זה ראוי להתייחסות מיוחדת"
        ]
        
        import random
        return random.choice(details)
    
    def _integrate_keywords(self, content: str, keywords: List[str]) -> str:
        """שילוב מילות מפתח בתוכן"""
        
        if not keywords:
            return content
        
        # בדיקת כיסוי מילות מפתח קיימות
        content_lower = content.lower()
        missing_keywords = [kw for kw in keywords if kw.lower() not in content_lower]
        
        # הוספת מילות מפתח חסרות בצורה טבעית
        if missing_keywords:
            for keyword in missing_keywords[:3]:  # מקסימום 3 מילות מפתח
                content += f" {keyword} הוא נושא חשוב בהקשר זה."
        
        return content
    
    def _basic_grammar_check(self, content: str) -> str:
        """בדיקת דקדוק בסיסית"""
        
        # תיקונים בסיסיים בעברית
        corrections = {
            r'\bאני היה\b': 'אני הייתי',
            r'\bאת יודע\b': 'אתה יודע',
            r'\bלא יכול\b': 'לא יכול',
            r'\bכל הזמן\b': 'כל הזמן'
        }
        
        for pattern, replacement in corrections.items():
            content = re.sub(pattern, replacement, content, flags=re.IGNORECASE)
        
        return content
    
    async def _adjust_tone(self, content: str, target_tone: str) -> str:
        """התאמת טון כתיבה"""
        
        # התאמות טון בסיסיות
        if target_tone.lower() in ['formal', 'פורמלי', 'רשמי']:
            # הפיכה לפורמלי יותר
            content = content.replace('אתה', 'אתם')
            content = content.replace('שלך', 'שלכם')
            
        elif target_tone.lower() in ['casual', 'קליל', 'חברותי']:
            # הפיכה לקליל יותר
            content = content.replace('אנו', 'אנחנו')
            content = content.replace('ניתן', 'אפשר')
        
        return content
    
    def _calculate_metrics(self, content: str, generation: ContentGeneration) -> GenerationMetrics:
        """חישוב מדדי תוכן"""
        
        metrics = GenerationMetrics()
        
        # מדדים בסיסיים
        metrics.word_count = len(content.split())
        metrics.character_count = len(content)
        metrics.sentence_count = len([s for s in content.split('.') if s.strip()])
        metrics.paragraph_count = len([p for p in content.split('\n\n') if p.strip()])
        
        # מדדי איכות בסיסיים
        metrics.readability_score = self._calculate_readability(content)
        metrics.coherence_score = self._calculate_coherence(content)
        metrics.grammar_score = self._calculate_grammar_quality(content)
        
        # ניתוח מילות מפתח
        if generation.requirements.keywords:
            metrics.keyword_density = self._calculate_keyword_density(
                content, generation.requirements.keywords
            )
        
        # ניקוד יצירתיות בסיסי
        metrics.creativity_score = self._estimate_creativity(content)
        
        return metrics
    
    def _calculate_readability(self, text: str) -> float:
        """חישוב קריאות טקסט"""
        
        words = text.split()
        sentences = [s for s in text.split('.') if s.strip()]
        
        if not sentences or not words:
            return 0.0
        
        # פורמולה פשוטה לקריאות
        avg_words_per_sentence = len(words) / len(sentences)
        avg_syllables_per_word = self._estimate_syllables_per_word(words)
        
        # ניקוד קריאות פשוט (0-1)
        readability = max(0, min(1, 1 - (avg_words_per_sentence - 15) / 20))
        return readability
    
    def _estimate_syllables_per_word(self, words: List[str]) -> float:
        """הערכת מספר הברות ממוצע למילה"""
        
        # הערכה פשוטה בהתבסס על אורך מילה
        total_syllables = sum(max(1, len(word) // 2) for word in words)
        return total_syllables / len(words) if words else 0
    
    def _calculate_coherence(self, text: str) -> float:
        """חישוב לכידות טקסט"""
        
        # מדד לכידות בסיסי - חזרה על מילות מפתח
        words = text.lower().split()
        word_freq = Counter(words)
        
        # חישוב חזרה על מילים משמעותיות
        significant_words = [w for w in words if len(w) > 3]
        if not significant_words:
            return 0.5
        
        repeated_words = sum(1 for w, count in Counter(significant_words).items() if count > 1)
        coherence = repeated_words / len(set(significant_words))
        
        return min(1.0, coherence)
    
    def _calculate_grammar_quality(self, text: str) -> float:
        """הערכת איכות דקדוק"""
        
        # בדיקות דקדוק בסיסיות
        grammar_score = 1.0
        
        # בדיקת סימני פיסוק
        sentences = text.split('.')
        for sentence in sentences:
            if sentence.strip() and not sentence.strip()[-1] in '.!?':
                grammar_score -= 0.1
        
        # בדיקת אותיות גדולות בתחילת משפטים
        for sentence in sentences:
            if sentence.strip() and not sentence.strip()[0].isupper():
                grammar_score -= 0.05
        
        return max(0.0, grammar_score)
    
    def _calculate_keyword_density(self, text: str, keywords: List[str]) -> Dict[str, float]:
        """חישוב צפיפות מילות מפתח"""
        
        text_lower = text.lower()
        words = text_lower.split()
        total_words = len(words)
        
        density = {}
        for keyword in keywords:
            count = text_lower.count(keyword.lower())
            density[keyword] = (count / total_words) * 100 if total_words > 0 else 0.0
        
        return density
    
    def _estimate_creativity(self, text: str) -> float:
        """הערכת יצירתיות"""
        
        # מדדי יצירתיות בסיסיים
        creativity_score = 0.0
        
        # מגוון אוצר מילים
        words = text.lower().split()
        unique_words = len(set(words))
        vocabulary_diversity = unique_words / len(words) if words else 0
        creativity_score += vocabulary_diversity * 0.4
        
        # שימוש בדימויים ובמטפורות (בדיקה בסיסית)
        metaphor_indicators = ['כמו', 'כאילו', 'דומה ל', 'נראה כמו']
        metaphor_count = sum(text.lower().count(indicator) for indicator in metaphor_indicators)
        creativity_score += min(0.3, metaphor_count * 0.1)
        
        # מורכבות משפטים
        sentences = [s for s in text.split('.') if s.strip()]
        avg_sentence_length = sum(len(s.split()) for s in sentences) / len(sentences) if sentences else 0
        complexity_score = min(0.3, avg_sentence_length / 20)
        creativity_score += complexity_score
        
        return min(1.0, creativity_score)
    
    async def _quality_checks(self, result: GenerationResult, generation: ContentGeneration):
        """בדיקות איכות מתקדמות"""
        
        content = result.generated_content
        
        # בדיקת אורך
        words = content.split()
        required_range = generation.requirements.length_words
        
        if len(words) < required_range[0]:
            result.warnings.append(f"התוכן קצר מהנדרש ({len(words)} מילים, נדרש {required_range[0]})")
        elif len(words) > required_range[1]:
            result.warnings.append(f"התוכן ארוך מהנדרש ({len(words)} מילים, מקסימום {required_range[1]})")
        
        # בדיקת כיסוי נקודות מפתח
        missing_points = []
        for point in generation.requirements.key_points:
            if point.lower() not in content.lower():
                missing_points.append(point)
        
        if missing_points:
            result.warnings.append(f"נקודות מפתח חסרות: {', '.join(missing_points)}")
        
        # בדיקת מילות מפתח
        missing_keywords = []
        for keyword in generation.requirements.keywords:
            if keyword.lower() not in content.lower():
                missing_keywords.append(keyword)
        
        if missing_keywords:
            result.warnings.append(f"מילות מפתח חסרות: {', '.join(missing_keywords)}")
    
    async def _optimize_for_seo(self, result: GenerationResult, generation: ContentGeneration):
        """אופטימיזציה SEO"""
        
        content = result.generated_content
        
        # המלצות SEO בסיסיות
        seo_recommendations = []
        
        # בדיקת כותרות
        h1_count = content.count('# ')
        if h1_count == 0:
            seo_recommendations.append("הוסף כותרת H1 ראשית")
        elif h1_count > 1:
            seo_recommendations.append("השתמש בכותרת H1 אחת בלבד")
        
        # בדיקת תת-כותרות
        h2_count = content.count('## ')
        if h2_count < 2:
            seo_recommendations.append("הוסף יותר תת-כותרות (H2) לשיפור המבנה")
        
        # בדיקת אורך תוכן
        word_count = len(content.split())
        if word_count < 300:
            seo_recommendations.append("הוסף תוכן נוסף - מינימום 300 מילים מומלץ")
        
        # בדיקת צפיפות מילות מפתח
        for keyword, density in result.metrics.keyword_density.items():
            if density < 1:
                seo_recommendations.append(f"הגבר את השימוש במילת המפתח '{keyword}'")
            elif density > 3:
                seo_recommendations.append(f"הפחת את השימוש במילת המפתח '{keyword}' (יותר מדי)")
        
        result.seo_recommendations = seo_recommendations
        
        # חישוב ניקוד SEO
        seo_score = 1.0
        if h1_count != 1:
            seo_score -= 0.2
        if h2_count < 2:
            seo_score -= 0.1
        if word_count < 300:
            seo_score -= 0.3
        
        result.metrics.seo_score = max(0.0, seo_score)
    
    async def _fact_check_content(self, result: GenerationResult):
        """בדיקת עובדות בסיסית"""
        
        # בדיקת עובדות פשוטה - חיפוש טענות שניתן לבדוק
        content = result.generated_content
        
        # זיהוי מספרים וסטטיסטיקות
        import re
        numbers = re.findall(r'\d+(?:\.\d+)?%?', content)
        
        fact_check_results = []
        
        for number in numbers[:5]:  # מקסימום 5 בדיקות
            fact_check_results.append({
                'claim': f"הנתון {number}",
                'status': 'requires_verification',
                'source': 'זקוק לאימות מקור אמין'
            })
        
        result.fact_check_results = fact_check_results
    
    def _generate_suggestions(self, result: GenerationResult, generation: ContentGeneration) -> List[str]:
        """יצירת הצעות שיפור"""
        
        suggestions = []
        
        # הצעות על בסיס מדדי איכות
        if result.metrics.readability_score < 0.7:
            suggestions.append("שפר את הקריאות על ידי קיצור משפטים")
        
        if result.metrics.coherence_score < 0.6:
            suggestions.append("הוסף מילות קישור בין פסקאות לשיפור הלכידות")
        
        if result.metrics.creativity_score < 0.5:
            suggestions.append("הוסף דימויים ודוגמאות לשיפור היצירתיות")
        
        # הצעות על בסיס תוכן
        word_count = result.metrics.word_count
        if word_count < generation.requirements.length_words[0]:
            suggestions.append("הרחב את התוכן עם פרטים ודוגמאות נוספות")
        
        if not result.metrics.keyword_density:
            suggestions.append("שלב מילות מפתח בצורה טבעית יותר")
        
        # הצעות לפי סוג תוכן
        if generation.content_type == ContentType.MARKETING_COPY:
            if 'קריאה לפעולה' not in result.generated_content:
                suggestions.append("הוסף קריאה לפעולה ברורה יותר")
        
        return suggestions
    
    async def _analyze_content(self, result: GenerationResult):
        """ניתוח תוכן מתקדם"""
        
        content = result.generated_content
        
        # ניתוח רגשות בסיסי
        positive_words = ['טוב', 'מעולה', 'נהדר', 'מושלם', 'יפה', 'חדש', 'משופר']
        negative_words = ['רע', 'גרוע', 'קשה', 'בעיה', 'שגיאה', 'כישלון']
        
        content_lower = content.lower()
        
        positive_count = sum(content_lower.count(word) for word in positive_words)
        negative_count = sum(content_lower.count(word) for word in negative_words)
        total_sentiment_words = positive_count + negative_count
        
        if total_sentiment_words > 0:
            result.sentiment_analysis = {
                'positive': positive_count / total_sentiment_words,
                'negative': negative_count / total_sentiment_words,
                'neutral': 1 - (positive_count + negative_count) / total_sentiment_words
            }
        else:
            result.sentiment_analysis = {'positive': 0.0, 'negative': 0.0, 'neutral': 1.0}
        
        # זיהוי ישויות בסיסי (שמות, מקומות, וכו')
        if self.ner_pipeline:
            try:
                entities = self.ner_pipeline(content)
                result.named_entities = [
                    {'text': entity['word'], 'label': entity['entity_group']}
                    for entity in entities
                ]
            except Exception as e:
                self.logger.warning(f"שגיאה בזיהוי ישויות: {e}")
        
        # סיווג נושאים בסיסי
        topic_keywords = {
            'טכנולוגיה': ['טכנולוגיה', 'מחשב', 'תוכנה', 'אינטרנט', 'דיגיטלי'],
            'עסקים': ['עסק', 'חברה', 'רווח', 'שיווק', 'מכירות'],
            'חינוך': ['חינוך', 'למידה', 'בית ספר', 'סטודנט', 'הוראה'],
            'בריאות': ['בריאות', 'רפואה', 'רופא', 'טיפול', 'מחלה']
        }
        
        detected_topics = []
        for topic, keywords in topic_keywords.items():
            if any(keyword in content_lower for keyword in keywords):
                detected_topics.append(topic)
        
        result.topic_classification = detected_topics
    
    def _update_statistics(self, result: GenerationResult, generation: ContentGeneration):
        """עדכון סטטיסטיקות"""
        
        self.generation_stats['total_generations'] += 1
        
        if result.is_successful():
            self.generation_stats['successful_generations'] += 1
        else:
            self.generation_stats['failed_generations'] += 1
        
        self.generation_stats['total_words_generated'] += result.metrics.word_count
        self.generation_stats['languages_used'].add(generation.language.value)
        self.generation_stats['content_types_used'].add(generation.content_type.value)
        
        # עדכון זמן ממוצע
        total_time = (self.generation_stats['average_generation_time'] * 
                     (self.generation_stats['total_generations'] - 1) + 
                     result.generation_time)
        self.generation_stats['average_generation_time'] = total_time / self.generation_stats['total_generations']
    
    # פונקציות עזר ליצירת חלקי תוכן ספציפיים
    
    def _select_template(self, generation: ContentGeneration) -> Optional[Dict[str, Any]]:
        """בחירת תבנית מתאימה"""
        
        content_type = generation.content_type
        
        if content_type in [ContentType.MARKETING_COPY, ContentType.SOCIAL_MEDIA]:
            return self.templates['marketing'].get('product_launch', {})
        elif content_type == ContentType.TECHNICAL_DOC:
            return self.templates['technical'].get('user_manual', {})
        elif content_type in [ContentType.CREATIVE_WRITING, ContentType.STORYTELLING]:
            return self.templates['creative'].get('short_story', {})
        elif content_type == ContentType.BUSINESS_PLAN:
            return self.templates['business'].get('business_proposal', {})
        
        return None
    
    def _build_generation_prompt(self, generation: ContentGeneration, template: Dict[str, Any]) -> str:
        """בניית פרומפט ליצירה"""
        
        requirements = generation.requirements
        
        prompt_parts = []
        
        # הוראות בסיסיות
        prompt_parts.append(f"צור תוכן מסוג {generation.content_type.value}")
        
        # קהל יעד
        if requirements.target_audience:
            prompt_parts.append(f"עבור קהל יעד: {requirements.target_audience}")
        
        # טון וסגנון
        if requirements.tone:
            prompt_parts.append(f"בטון {requirements.tone}")
        
        if requirements.style:
            prompt_parts.append(f"בסגנון {requirements.style}")
        
        # נקודות מפתח
        if requirements.key_points:
            prompt_parts.append(f"כלול את הנקודות: {', '.join(requirements.key_points)}")
        
        # מילות מפתח
        if requirements.keywords:
            prompt_parts.append(f"השתמש במילות המפתח: {', '.join(requirements.keywords)}")
        
        # אורך
        prompt_parts.append(f"באורך של {requirements.length_words[0]}-{requirements.length_words[1]} מילים")
        
        return ". ".join(prompt_parts) + "."
    
    async def _generate_alternatives(self, generation: ContentGeneration, main_content: str) -> List[str]:
        """יצירת גרסאות אלטרנטיביות"""
        
        alternatives = []
        
        # גרסה עם טון שונה
        alt_generation = generation.__class__(**generation.__dict__)
        alt_generation.requirements.tone = "פורמלי" if generation.requirements.tone != "פורמלי" else "קליל"
        
        try:
            alt_content = await self._generate_by_type(alt_generation)
            alternatives.append(alt_content)
        except Exception as e:
            self.logger.warning(f"שגיאה ביצירת אלטרנטיבה: {e}")
        
        # גרסה קצרה יותר
        short_version = self._create_short_version(main_content)
        if short_version != main_content:
            alternatives.append(short_version)
        
        return alternatives
    
    def _create_short_version(self, content: str) -> str:
        """יצירת גרסה מקוצרת"""
        
        paragraphs = content.split('\n\n')
        
        # שמירת הפסקאות החשובות ביותר (ראשונה ואחרונה + חצי מהאמצע)
        if len(paragraphs) > 3:
            important_paragraphs = [paragraphs[0]]  # פתיחה
            middle_count = max(1, len(paragraphs[1:-1]) // 2)
            important_paragraphs.extend(paragraphs[1:1+middle_count])  # חלק מהאמצע
            important_paragraphs.append(paragraphs[-1])  # סיום
            
            return '\n\n'.join(important_paragraphs)
        
        return content
    
    # פונקציות ליצירת חלקים ספציפיים
    
    async def _generate_headline(self, generation: ContentGeneration) -> str:
        """יצירת כותרת"""
        
        key_points = generation.requirements.key_points
        if key_points:
            return f"{key_points[0]} - הפתרון המושלם עבורכם"
        
        return "גלו את הפתרון המתקדם ביותר"
    
    async def _generate_hook(self, generation: ContentGeneration) -> str:
        """יצירת פתיחה מושכת"""
        
        hooks = [
            "האם גם אתם מתמודדים עם האתגר הזה?",
            "תארו לעצמכם פתרון שמשנה הכל...",
            "הגיע הזמן לפתרון אמיתי שעובד.",
            "מה שעמד לקרות יכול לשנות הכל."
        ]
        
        import random
        return random.choice(hooks)
    
    async def _generate_problem_section(self, generation: ContentGeneration) -> str:
        """יצירת סעיף בעיה"""
        
        return ("רבים מאתנו מתמודדים עם אותו האתגר - צורך בפתרון יעיל, מהיר ואמין. "
                "הפתרונות הקיימים לא תמיד עונים על הצרכים המיוחדים שלנו, "
                "ולעיתים הם מורכבים מדי או יקרים מדי.")
    
    async def _generate_solution_section(self, generation: ContentGeneration) -> str:
        """יצירת סעיף פתרון"""
        
        return ("הפתרון שלנו מציע גישה חדשנית המשלבת טכנולוגיה מתקדמת עם פשטות בשימוש. "
                "פיתחנו מערכת שמתאימה בדיוק לצרכים שלכם, "
                "תוך שמירה על איכות גבוהה ומחיר הוגן.")
    
    async def _generate_benefits_section(self, generation: ContentGeneration) -> str:
        """יצירת סעיף יתרונות"""
        
        key_points = generation.requirements.key_points
        
        benefits = []
        if key_points:
            for point in key_points[:3]:
                benefits.append(f"• {point} - יתרון ברור ומיידי")
        else:
            benefits = [
                "• חיסכון בזמן ובכסף",
                "• פשטות בשימוש",
                "• תוצאות מוכחות"
            ]
        
        return "\n".join(benefits)
    
    async def _generate_testimonials(self, generation: ContentGeneration) -> str:
        """יצירת עדויות"""
        
        testimonials = [
            '"השירות שלהם שינה לנו את החיים. פשוט מדהים!" - לקוח מרוצה',
            '"לא האמנתי שזה אפשרי עד שראיתי בעצמי." - משתמש קבוע',
            '"הפתרון הטוב ביותר שניסינו עד היום." - מנהל פרויקט'
        ]
        
        return "\n\n".join(testimonials[:2])
    
    # פונקציות נוספות ליצירת תוכן טכני, יצירתי ועסקי...
    
    async def _generate_technical_overview(self, generation: ContentGeneration) -> str:
        """יצירת סקירה טכנית"""
        return "מסמך זה מספק הדרכה מקיפה לשימוש במערכת, כולל הוראות התקנה, הגדרה ושימוש."
    
    async def _generate_prerequisites(self, generation: ContentGeneration) -> str:
        """יצירת דרישות מקדימות"""
        return ("• מערכת הפעלה עדכנית\n"
                "• חיבור לאינטרנט\n"
                "• זיכרון פנוי של לפחות 1GB\n"
                "• הרשאות מנהל במערכת")
    
    async def _generate_step_by_step(self, generation: ContentGeneration) -> str:
        """יצירת הוראות שלב אחר שלב"""
        
        steps = []
        for i, point in enumerate(generation.requirements.key_points, 1):
            steps.append(f"{i}. {point} - בצע את השלבים המפורטים")
        
        if not steps:
            steps = [
                "1. הורד את הקובץ מהאתר הרשמי",
                "2. הפעל את תהליך ההתקנה",
                "3. בצע את ההגדרות הראשוניות",
                "4. בדוק שהמערכת פועלת כראוי"
            ]
        
        return "\n".join(steps)
    
    async def _generate_code_examples(self, generation: ContentGeneration) -> str:
        """יצירת דוגמאות קוד"""
        return """```python
# דוגמה בסיסית לשימוש
import example_module

# יצירת חיבור
connection = example_module.connect()

# ביצוע פעולה
result = connection.execute("example_command")

# הדפסת תוצאה
print(f"התוצאה: {result}")
```"""
    
    async def _generate_troubleshooting(self, generation: ContentGeneration) -> str:
        """יצירת פתרון בעיות"""
        return ("**שגיאה נפוצה 1:** הודעת שגיאה X\n"
                "**פתרון:** בדוק את הגדרות החיבור\n\n"
                "**שגיאה נפוצה 2:** המערכת לא מגיבה\n"
                "**פתרון:** אתחל את השירות")
    
    # פונקציות יצירת תוכן יצירתי...
    
    async def _generate_story_setting(self, generation: ContentGeneration) -> str:
        """יצירת תפאורת סיפור"""
        return ("בעיר הקסומה, שם הזמן זורם לאחור ובני האדם חולמים בצבע, "
                "חי גיבור סיפורנו - דמות מיוחדת עם יכולות יוצאות דופן.")
    
    async def _generate_plot_development(self, generation: ContentGeneration) -> str:
        """יצירת פיתוח עלילה"""
        return ("יום אחד קרה משהו שהכל השתנה. האתגר שעמד בפני הגיבור "
                "דרש ממנו לגלות כוחות שלא ידע שיש לו ולהתמודד עם מכשולים "
                "שנראו בלתי עבירים.")
    
    async def _generate_story_climax(self, generation: ContentGeneration) -> str:
        """יצירת שיא סיפור"""
        return ("ברגע המכריע, כאשר הכל תלה על כף המאזניים, "
                "הגיבור שלנו גילה את האמת שהייתה נסתרה מעיניו כל הזמן. "
                "זה היה הרגע לפעול.")
    
    async def _generate_story_resolution(self, generation: ContentGeneration) -> str:
        """יצירת פתרון סיפור"""
        return ("בסופו של דבר, הגיבור הבין שהפתרון היה בתוכו כל הזמן. "
                "הוא חזר הביתה שונה, חכם יותר, ועם סיפור לספר לדורות הבאים.")
    
    # פונקציות תוכן עסקי...
    
    async def _generate_executive_summary(self, generation: ContentGeneration) -> str:
        """יצירת תקציר מנהלים"""
        return ("תכנית זו מציגה הזדמנות עסקית משמעותית בשוק המתפתח. "
                "על בסיס ניתוח מעמיק, אנו מציעים אסטרטגיה מקיפה "
                "להשגת יתרון תחרותי ורווחיות לטווח ארוך.")
    
    async def _generate_market_analysis(self, generation: ContentGeneration) -> str:
        """יצירת ניתוח שוק"""
        return ("השוק הנוכחי מציג מגמות צמיחה חיוביות עם ביקוש גובר "
                "לפתרונות חדשניים. המתחרים הקיימים לא מספקים מענה מלא "
                "לצרכי הלקוחות, מה שיוצר הזדמנות למוצר שלנו.")
    
    async def _generate_strategy_section(self, generation: ContentGeneration) -> str:
        """יצירת סעיף אסטרטגיה"""
        return ("האסטרטגיה המוצעת מבוססת על שלושה עמודי תווך: "
                "חדשנות טכנולוגית, שירות לקוחות מעולה, ותמחור תחרותי. "
                "נתמקד בפיתוח יתרונות ייחודיים שקשה לחקות.")
    
    async def _generate_financial_projections(self, generation: ContentGeneration) -> str:
        """יצירת תחזיות כספיות"""
        return ("תחזיות הרווח לשלוש השנים הקרובות מציגות צמיחה עקבית:\n"
                "• שנה 1: הכנסות צפויות 1M ₪\n"
                "• שנה 2: הכנסות צפויות 2.5M ₪\n"
                "• שנה 3: הכנסות צפויות 4M ₪")
    
    async def _generate_risks_opportunities(self, generation: ContentGeneration) -> str:
        """יצירת סיכונים והזדמנויות"""
        return ("**הזדמנויות:**\n"
                "• שוק צומח במהירות\n"
                "• ביקוש גובר לפתרונות חדשניים\n\n"
                "**סיכונים:**\n"
                "• כניסת מתחרים חדשים\n"
                "• שינויים רגולטוריים")
    
    # פונקציות תוכן בלוג...
    
    async def _generate_blog_title(self, generation: ContentGeneration) -> str:
        """יצירת כותרת בלוג"""
        key_points = generation.requirements.key_points
        if key_points:
            return f"המדריך המלא ל{key_points[0]}: כל מה שצריך לדעת"
        return "גלו את הסודות שמומחים לא רוצים שתדעו"
    
    async def _generate_blog_introduction(self, generation: ContentGeneration) -> str:
        """יצירת פתיחת בלוג"""
        return ("בעולם המשתנה במהירות, חשוב להישאר מעודכן בטרנדים החדשים. "
                "במאמר זה נחקור יחד את הנושאים הרלוונטיים ביותר "
                "ונספק לכם כלים מעשיים שתוכלו ליישם מיד.")
    
    async def _generate_blog_section(self, generation: ContentGeneration, key_point: str) -> str:
        """יצירת סעיף בלוג"""
        return (f"{key_point} הוא נושא חשוב שראוי לתשומת לב מיוחדת. "
                f"כאשר מתמודדים עם {key_point}, חשוב לקחת בחשבון מספר גורמים: "
                f"הסביבה, הכלים הזמינים, והמטרות שלכם. "
                f"בחלק זה נתעמק בדרכים המעשיות ביותר להתמודד עם {key_point}.")
    
    async def _generate_blog_conclusion(self, generation: ContentGeneration) -> str:
        """יצירת סיכום בלוג"""
        return ("לסיכום, הנושאים שדנו בהם במאמר זה מהווים בסיס חשוב "
                "להבנה מעמיקה של התחום. היישום המעשי של העקרונות האלה "
                "יכול להוביל לתוצאות משמעותיות. אנו מעודדים אתכם לנסות "
                "ולשתף אותנו בתוצאות.")
    
    async def _generate_section_basic(self, section_name: str, generation: ContentGeneration) -> str:
        """יצירת סעיף בסיסי"""
        return (f"בסעיף זה נתייחס ל{section_name} ונספק מידע רלוונטי "
                f"ושימושי. {section_name} הוא נושא חשוב שמשפיע על "
                f"היבטים רבים ולכן ראוי להתייחסות מיוחדת.")
    
    def get_generation_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות יצירה"""
        
        stats = self.generation_stats.copy()
        
        # המרת sets למילות רשימה לשמיכה ב-JSON
        stats['languages_used'] = list(stats['languages_used'])
        stats['content_types_used'] = list(stats['content_types_used'])
        
        # הוספת מידע נוכחי
        stats['active_generations'] = len(self.active_generations)
        stats['active_tasks'] = len(self.active_tasks)
        stats['templates_loaded'] = sum(len(templates) for templates in self.templates.values())
        
        return stats
    
    def get_active_generations(self) -> List[Dict[str, Any]]:
        """קבלת רשימת יצירות פעילות"""
        
        active_list = []
        
        for generation_id, generation_data in self.active_generations.items():
            generation = generation_data['generation']
            elapsed_time = time.time() - generation_data['start_time']
            
            active_list.append({
                'generation_id': generation_id,
                'content_type': generation.content_type.value,
                'language': generation.language.value,
                'title': generation.title or 'ללא כותרת',
                'elapsed_time': elapsed_time,
                'estimated_remaining': max(0, generation.estimate_generation_time() * 60 - elapsed_time)
            })
        
        return active_list
    
    def shutdown(self):
        """כיבוי מנוע התוכן"""
        
        self.logger.info("כיבוי מנוע יצירת תוכן...")
        
        # כיבוי thread pool
        self.executor.shutdown(wait=True)
        
        # שמירת סטטיסטיקות אחרונות
        self.logger.info(f"סטטיסטיקות סופיות: {self.generation_stats}")
        
        self.logger.info("מנוע יצירת תוכן נכבה בהצלחה")