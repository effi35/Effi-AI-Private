"""
Advanced Agent Creation System - המודול הראשי
מערכת יצירת וניהול 25+ סוכני AI עם מודל Hudson/Llama מקומי
"""

import asyncio
import json
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging

from .core.agent_manager import AgentManager
from .core.ollama_integration import (
    OllamaClient, AgentOllamaInterface, AgentModelConfig,
    OllamaModelManager, create_default_ollama_client
)
from .models.agent_types import (
    AgentProfile, AgentTask, AgentConversation,
    AgentRole, AgentPersonality, TaskPriority,
    AgentFactory, create_default_agent_config
)

class AdvancedAgentCreationSystem:
    """מערכת מתקדמת ליצירת וניהול סוכני AI"""
    
    def __init__(self):
        self.name = "agent_creation_advanced"
        self.version = "1.0.0"
        self.description = "מערכת מתקדמת ליצירת וניהול 25+ סוכני AI עם מודל Hudson/Llama מקומי"
        
        # רכיבי המערכת
        self.agent_manager: Optional[AgentManager] = None
        self.ollama_client: Optional[OllamaClient] = None
        self.ollama_interface: Optional[AgentOllamaInterface] = None
        self.model_manager: Optional[OllamaModelManager] = None
        
        # מצב המערכת
        self.is_initialized = False
        self.is_running = False
        
        # הגדרות
        self.config = {
            "ollama_url": "http://localhost:11434",
            "default_model": "hudson/llama3.1-uncensored:8b",
            "max_agents": 25,
            "max_concurrent_tasks": 50,
            "auto_create_defaults": True,
            "privacy_mode": True,
            "local_only": True
        }
        
        # לוגים ומטריקות
        self.system_logs = []
        self.performance_metrics = {
            "system_start_time": None,
            "total_agents_created": 0,
            "total_tasks_executed": 0,
            "total_conversations": 0,
            "ollama_requests": 0,
            "average_response_time": 0.0
        }
    
    async def initialize(self, config: Dict[str, Any] = None) -> bool:
        """אתחול המערכת"""
        try:
            self._log("info", "Starting Advanced Agent Creation System initialization...")
            
            # עדכון הגדרות
            if config:
                self.config.update(config)
            
            # יצירת לקוח Ollama
            self.ollama_client = OllamaClient(self.config["ollama_url"])
            await self.ollama_client.connect()
            
            # בדיקת זמינות המודל
            if not await self._ensure_hudson_model():
                self._log("error", "Hudson model not available")
                return False
            
            # יצירת מנהל מודלים
            self.model_manager = OllamaModelManager(self.ollama_client)
            
            # יצירת ממשק Ollama
            self.ollama_interface = AgentOllamaInterface(self.ollama_client)
            
            # יצירת מנהל סוכנים
            self.agent_manager = AgentManager(
                max_agents=self.config["max_agents"],
                max_concurrent_tasks=self.config["max_concurrent_tasks"]
            )
            
            # חיבור האירועים
            await self._setup_event_handlers()
            
            # סימון שהמערכת מאותחלת
            self.is_initialized = True
            self.is_running = True
            self.performance_metrics["system_start_time"] = datetime.now()
            
            self._log("info", "Advanced Agent Creation System initialized successfully")
            return True
            
        except Exception as e:
            self._log("error", f"Initialization failed: {str(e)}")
            await self._cleanup()
            return False
    
    async def _ensure_hudson_model(self) -> bool:
        """וידוא זמינות מודל Hudson"""
        model_name = self.config["default_model"]
        
        if model_name not in self.ollama_client.available_models:
            self._log("warning", f"Model {model_name} not found. Attempting to download...")
            
            # ניסיון הורדה (בפועל זה יהיה תהליך ארוך)
            success = await self.model_manager.download_model(model_name)
            if not success:
                return False
        
        return await self.ollama_client.ensure_model_loaded(model_name)
    
    async def _setup_event_handlers(self):
        """הגדרת מטפלי אירועים"""
        # מטפל יצירת סוכן
        self.agent_manager.add_event_listener("agent_registered", self._on_agent_created)
        
        # מטפל השלמת משימה
        self.agent_manager.add_event_listener("task_completed", self._on_task_completed)
        
        # מטפל תחילת שיחה
        self.agent_manager.add_event_listener("conversation_started", self._on_conversation_started)
    
    async def _on_agent_created(self, data: Dict[str, Any]):
        """מטפל יצירת סוכן"""
        agent_id = data["agent_id"]
        agent = self.agent_manager.get_agent(agent_id)
        
        if agent:
            # יצירת הגדרות מודל לסוכן
            model_config = self.model_manager.create_agent_config(
                agent.role.value,
                agent.personality.value,
                agent.specializations[0] if agent.specializations else None
            )
            
            # אתחול הסוכן בממשק Ollama
            await self.ollama_interface.initialize_agent(agent_id, model_config)
            
            self.performance_metrics["total_agents_created"] += 1
            self._log("info", f"Agent {agent.name} initialized with Ollama interface")
    
    async def _on_task_completed(self, data: Dict[str, Any]):
        """מטפל השלמת משימה"""
        self.performance_metrics["total_tasks_executed"] += 1
        execution_time = data.get("execution_time", 0)
        
        # עדכון זמן תגובה ממוצע
        current_avg = self.performance_metrics["average_response_time"]
        total_tasks = self.performance_metrics["total_tasks_executed"]
        
        if total_tasks > 1:
            new_avg = ((current_avg * (total_tasks - 1)) + execution_time) / total_tasks
            self.performance_metrics["average_response_time"] = round(new_avg, 3)
        else:
            self.performance_metrics["average_response_time"] = execution_time
    
    async def _on_conversation_started(self, data: Dict[str, Any]):
        """מטפל תחילת שיחה"""
        self.performance_metrics["total_conversations"] += 1
    
    # ===== API פונקציות ליצירת סוכנים =====
    
    async def create_agent(
        self,
        name: str,
        role: str,
        personality: str = "professional",
        specializations: List[str] = None,
        custom_prompt: str = None
    ) -> Optional[str]:
        """יוצר סוכן חדש"""
        try:
            # המרת strings לenums
            agent_role = AgentRole(role)
            agent_personality = AgentPersonality(personality)
            
            # יצירת סוכן לפי סוג
            if agent_role == AgentRole.ASSISTANT:
                agent = AgentFactory.create_assistant_agent(
                    name, 
                    specializations[0] if specializations else None
                )
            elif agent_role == AgentRole.DEVELOPER:
                agent = AgentFactory.create_developer_agent(name, specializations)
            elif agent_role == AgentRole.RESEARCHER:
                agent = AgentFactory.create_researcher_agent(name, specializations)
            elif agent_role == AgentRole.CREATIVE:
                agent = AgentFactory.create_creative_agent(name, specializations)
            else:
                agent = AgentFactory.create_specialist_agent(
                    name,
                    specializations[0] if specializations else "כללי"
                )
            
            # עדכון אישיות ופרטים
            agent.personality = agent_personality
            if specializations:
                agent.specializations.extend(specializations)
            if custom_prompt:
                agent.system_prompt = custom_prompt
            
            # רישום הסוכן
            success = await self.agent_manager.register_agent(agent)
            
            if success:
                self._log("info", f"Created new agent: {name} ({role})")
                return agent.agent_id
            else:
                self._log("error", f"Failed to register agent: {name}")
                return None
                
        except Exception as e:
            self._log("error", f"Error creating agent {name}: {str(e)}")
            return None
    
    async def create_agent_team(
        self,
        team_name: str,
        agent_configs: List[Dict[str, Any]],
        leader_role: str = None
    ) -> Optional[str]:
        """יוצר צוות של סוכנים"""
        try:
            created_agent_ids = []
            leader_id = None
            
            # יצירת כל הסוכנים
            for config in agent_configs:
                agent_id = await self.create_agent(**config)
                if agent_id:
                    created_agent_ids.append(agent_id)
                    
                    # קביעת מנהיג
                    if leader_role and config.get("role") == leader_role:
                        leader_id = agent_id
            
            if not created_agent_ids:
                return None
            
            # אם לא נבחר מנהיג, הראשון ברשימה יהיה המנהיג
            if not leader_id:
                leader_id = created_agent_ids[0]
            
            # יצירת הצוות
            team_id = await self.agent_manager.create_team(
                team_name,
                created_agent_ids,
                leader_id
            )
            
            if team_id:
                self._log("info", f"Created team: {team_name} with {len(created_agent_ids)} agents")
            
            return team_id
            
        except Exception as e:
            self._log("error", f"Error creating team {team_name}: {str(e)}")
            return None
    
    # ===== API פונקציות למשימות =====
    
    async def assign_task(
        self,
        title: str,
        description: str,
        priority: str = "normal",
        preferred_agent_role: str = None,
        deadline: datetime = None
    ) -> Optional[str]:
        """מקצה משימה לסוכן מתאים"""
        try:
            from .models.agent_types import AgentTask, TaskPriority
            
            # יצירת המשימה
            task = AgentTask(
                title=title,
                description=description,
                priority=TaskPriority(priority),
                deadline=deadline
            )
            
            # אם צוין תפקיד מועדף, נתייג את המשימה
            if preferred_agent_role:
                task.tags.append(f"preferred_role:{preferred_agent_role}")
            
            # יצירת המשימה במערכת
            success = await self.agent_manager.create_task(task)
            
            if success:
                self._log("info", f"Created task: {title}")
                return task.task_id
            else:
                return None
                
        except Exception as e:
            self._log("error", f"Error creating task {title}: {str(e)}")
            return None
    
    async def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """מחזיר סטטוס משימה"""
        if task_id in self.agent_manager.tasks:
            task = self.agent_manager.tasks[task_id]
            return {
                "task_id": task.task_id,
                "title": task.title,
                "status": task.status.value,
                "progress": task.progress,
                "assigned_agent": task.assigned_agent_id,
                "created_at": task.created_at.isoformat(),
                "started_at": task.started_at.isoformat() if task.started_at else None,
                "completed_at": task.completed_at.isoformat() if task.completed_at else None,
                "result": task.result
            }
        return None
    
    # ===== API פונקציות לשיחות =====
    
    async def start_conversation(
        self,
        agent_id: str,
        user_id: str,
        title: str = ""
    ) -> Optional[str]:
        """מתחיל שיחה עם סוכן"""
        try:
            conv_id = await self.agent_manager.start_conversation(agent_id, user_id, title)
            if conv_id:
                self._log("info", f"Started conversation with agent {agent_id}")
            return conv_id
        except Exception as e:
            self._log("error", f"Error starting conversation: {str(e)}")
            return None
    
    async def send_message(
        self,
        conversation_id: str,
        message: str
    ) -> Optional[str]:
        """שולח הודעה ומחזיר תגובה מהסוכן"""
        try:
            if conversation_id not in self.agent_manager.conversations:
                return None
            
            conversation = self.agent_manager.conversations[conversation_id]
            agent_id = conversation.agent_id
            
            # קבלת תגובה דרך Ollama
            response = await self.ollama_interface.send_message_to_agent(
                agent_id,
                message
            )
            
            # עדכון השיחה במנהל
            conversation.add_message("user", message)
            conversation.add_message("agent", response)
            
            self.performance_metrics["ollama_requests"] += 1
            
            return response
            
        except Exception as e:
            self._log("error", f"Error sending message: {str(e)}")
            return "מצטער, אירעה שגיאה בעת עיבוד ההודעה"
    
    async def get_conversation_history(
        self,
        conversation_id: str,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """מחזיר היסטוריית שיחה"""
        if conversation_id in self.agent_manager.conversations:
            conversation = self.agent_manager.conversations[conversation_id]
            return conversation.get_recent_messages(limit)
        return []
    
    # ===== API פונקציות מידע =====
    
    def get_agent_list(self) -> List[Dict[str, Any]]:
        """מחזיר רשימת כל הסוכנים"""
        if not self.agent_manager:
            return []
        
        return [
            {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "display_name": agent.display_name,
                "role": agent.role.value,
                "personality": agent.personality.value,
                "status": agent.status.value,
                "specializations": agent.specializations,
                "active_tasks": len(agent.active_tasks),
                "active_conversations": len(agent.active_conversations),
                "success_rate": agent.calculate_success_rate(),
                "average_rating": agent.calculate_average_rating(),
                "created_at": agent.created_at.isoformat()
            }
            for agent in self.agent_manager.agents.values()
        ]
    
    def get_available_roles(self) -> List[str]:
        """מחזיר רשימת תפקידים זמינים"""
        return [role.value for role in AgentRole]
    
    def get_available_personalities(self) -> List[str]:
        """מחזיר רשימת אישיויות זמינות"""
        return [personality.value for personality in AgentPersonality]
    
    def get_system_status(self) -> Dict[str, Any]:
        """מחזיר סטטוס המערכת"""
        status = {
            "is_running": self.is_running,
            "is_initialized": self.is_initialized,
            "system_info": {
                "name": self.name,
                "version": self.version,
                "description": self.description
            },
            "performance_metrics": self.performance_metrics.copy(),
            "config": self.config.copy()
        }
        
        if self.agent_manager:
            status.update(self.agent_manager.get_system_status())
        
        if self.ollama_client:
            status["ollama_stats"] = self.ollama_client.get_performance_stats()
        
        return status
    
    def get_agent_details(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """מחזיר פרטי סוכן מלאים"""
        agent = self.agent_manager.get_agent(agent_id) if self.agent_manager else None
        
        if not agent:
            return None
        
        return {
            "profile": {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "display_name": agent.display_name,
                "role": agent.role.value,
                "personality": agent.personality.value,
                "status": agent.status.value,
                "description": agent.description,
                "specializations": agent.specializations,
                "languages": agent.languages,
                "created_at": agent.created_at.isoformat(),
                "last_active": agent.last_active.isoformat()
            },
            "capabilities": [
                {
                    "name": cap.name,
                    "description": cap.description,
                    "skill_level": cap.skill_level,
                    "category": cap.category
                }
                for cap in agent.capabilities
            ],
            "performance": {
                "completed_tasks": agent.completed_tasks,
                "failed_tasks": agent.failed_tasks,
                "success_rate": agent.calculate_success_rate(),
                "average_rating": agent.calculate_average_rating(),
                "experience_level": agent.experience_level
            },
            "current_activity": {
                "active_tasks": len(agent.active_tasks),
                "active_conversations": len(agent.active_conversations),
                "status": agent.status.value
            },
            "settings": {
                "learning_enabled": agent.learning_enabled,
                "max_tokens": agent.max_tokens,
                "temperature": agent.temperature,
                "model_config": agent.model_config
            }
        }
    
    # ===== פונקציות ניהול =====
    
    async def remove_agent(self, agent_id: str) -> bool:
        """מסיר סוכן מהמערכת"""
        try:
            if self.agent_manager:
                success = await self.agent_manager.unregister_agent(agent_id)
                if success:
                    # ניקוי מממשק Ollama
                    if self.ollama_interface and agent_id in self.ollama_interface.agent_sessions:
                        del self.ollama_interface.agent_sessions[agent_id]
                        del self.ollama_interface.agent_configs[agent_id]
                    
                    self._log("info", f"Removed agent {agent_id}")
                return success
            return False
        except Exception as e:
            self._log("error", f"Error removing agent {agent_id}: {str(e)}")
            return False
    
    async def update_agent_config(
        self,
        agent_id: str,
        updates: Dict[str, Any]
    ) -> bool:
        """מעדכן הגדרות סוכן"""
        try:
            agent = self.agent_manager.get_agent(agent_id) if self.agent_manager else None
            if not agent:
                return False
            
            # עדכון פרופיל הסוכן
            for key, value in updates.items():
                if hasattr(agent, key):
                    setattr(agent, key, value)
            
            # עדכון הגדרות Ollama אם נדרש
            if any(key in updates for key in ['system_prompt', 'temperature', 'max_tokens']):
                if self.ollama_interface and agent_id in self.ollama_interface.agent_configs:
                    config = self.ollama_interface.agent_configs[agent_id]
                    
                    if 'system_prompt' in updates:
                        config.system_prompt = updates['system_prompt']
                    if 'temperature' in updates:
                        config.temperature = updates['temperature']
                    if 'max_tokens' in updates:
                        config.max_tokens = updates['max_tokens']
                    
                    self.ollama_interface.update_agent_config(agent_id, config)
            
            self._log("info", f"Updated agent {agent_id} configuration")
            return True
            
        except Exception as e:
            self._log("error", f"Error updating agent {agent_id}: {str(e)}")
            return False
    
    async def shutdown(self):
        """כיבוי המערכת"""
        try:
            self._log("info", "Shutting down Advanced Agent Creation System...")
            
            self.is_running = False
            
            # כיבוי מנהל הסוכנים
            if self.agent_manager:
                self.agent_manager.shutdown()
            
            # סגירת חיבור Ollama
            if self.ollama_client:
                await self.ollama_client.disconnect()
            
            self._log("info", "System shutdown completed")
            
        except Exception as e:
            self._log("error", f"Error during shutdown: {str(e)}")
    
    async def _cleanup(self):
        """ניקוי במקרה של שגיאה"""
        try:
            if self.ollama_client:
                await self.ollama_client.disconnect()
        except:
            pass
    
    def _log(self, level: str, message: str):
        """רישום לוג"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "message": message
        }
        self.system_logs.append(log_entry)
        
        # שמירה על גודל הלוג
        if len(self.system_logs) > 1000:
            self.system_logs = self.system_logs[-500:]
        
        # הדפסה לקונסול
        print(f"[{level.upper()}] {message}")

# יצירת instance גלובלי
agent_system = AdvancedAgentCreationSystem()

# פונקציות API חיצוניות
async def initialize_agent_system(config: Dict[str, Any] = None) -> bool:
    """אתחול מערכת הסוכנים"""
    return await agent_system.initialize(config)

async def create_agent(name: str, role: str, **kwargs) -> Optional[str]:
    """יצירת סוכן חדש"""
    return await agent_system.create_agent(name, role, **kwargs)

async def chat_with_agent(agent_id: str, message: str, user_id: str = "user") -> Optional[str]:
    """שיחה עם סוכן"""
    # חיפוש שיחה פעילה או יצירת חדשה
    active_conversations = [
        conv for conv in agent_system.agent_manager.conversations.values()
        if conv.agent_id == agent_id and conv.user_id == user_id and conv.is_active
    ]
    
    conversation_id = None
    if active_conversations:
        conversation_id = active_conversations[0].conversation_id
    else:
        conversation_id = await agent_system.start_conversation(agent_id, user_id)
    
    if conversation_id:
        return await agent_system.send_message(conversation_id, message)
    
    return None

def get_all_agents() -> List[Dict[str, Any]]:
    """קבלת כל הסוכנים"""
    return agent_system.get_agent_list()

def get_system_info() -> Dict[str, Any]:
    """מידע על המערכת"""
    return agent_system.get_system_status()

# פונקציות למודול העיקרי
async def module_startup():
    """הפעלת המודול"""
    success = await initialize_agent_system()
    if success:
        logging.info("Advanced Agent Creation System started successfully")
    return success

async def module_shutdown():
    """כיבוי המודול"""
    await agent_system.shutdown()
    logging.info("Advanced Agent Creation System stopped")

def get_module_info():
    """מידע על המודול"""
    return {
        "name": "agent_creation_advanced",
        "version": "1.0.0",
        "description": "מערכת מתקדמת ליצירת וניהול 25+ סוכני AI עם מודל Hudson/Llama מקומי",
        "capabilities": [
            "יצירת וניהול עד 25 סוכנים במקביל",
            "חיבור למודל Hudson/Llama מקומי",
            "ניהול משימות ושיחות",
            "צוותי עבודה של סוכנים",
            "ביצועים בזמן אמת",
            "פרטיות מלאה - ללא APIs חיצוניים"
        ],
        "status": "ready" if agent_system.is_initialized else "stopped"
    }