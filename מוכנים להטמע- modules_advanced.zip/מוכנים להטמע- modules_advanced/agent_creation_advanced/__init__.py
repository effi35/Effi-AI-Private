"""
Advanced Agent Creation Module
============================

This module provides advanced AI agent management capabilities with support for 20+ AI agents
using the local Hudson/Llama model integration.

Features:
- Multi-agent orchestration
- Advanced personality systems
- Local model integration
- Agent lifecycle management
- Performance monitoring
- Agent communication protocols

Author: Effi AI Team
Version: 1.0.0
"""

from .core.agent_manager import AgentManager
from .core.agent_orchestrator import AgentOrchestrator
from .core.local_model_integration import LocalModelIntegration
from .models.agent_types import *
from .models.personality_types import *
from .utils.agent_utils import *

__version__ = "1.0.0"
__author__ = "Effi AI Team"

# Module configuration
MODULE_INFO = {
    "name": "agent_creation_advanced",
    "version": __version__,
    "description": "Advanced AI Agent Creation and Management System",
    "author": __author__,
    "dependencies": [
        "ollama",
        "langchain",
        "asyncio",
        "sqlite3",
        "json",
        "datetime",
        "logging"
    ],
    "max_agents": 25,
    "supported_models": ["llama3", "llama3.1", "llama3.2", "hudson", "qwen2.5"],
    "features": [
        "multi_agent_orchestration",
        "personality_system",
        "local_model_integration",
        "agent_monitoring",
        "conversation_management",
        "task_delegation"
    ]
}

# Export main classes
__all__ = [
    "AgentManager",
    "AgentOrchestrator", 
    "LocalModelIntegration",
    "MODULE_INFO"
]