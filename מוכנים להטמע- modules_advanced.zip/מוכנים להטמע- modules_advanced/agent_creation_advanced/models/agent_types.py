"""
Agent Creation Advanced - Agent Types and Models
מודל סוכנים מתקדם עם 20+ סוכני AI מקומיים
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Set, Callable
from datetime import datetime
import uuid
import json

class AgentRole(Enum):
    """תפקידי סוכנים זמינים"""
    ASSISTANT = "assistant"                    # עוזר אישי כללי
    RESEARCHER = "researcher"                  # חוקר ומנתח מידע
    DEVELOPER = "developer"                    # מפתח קוד ותוכנה
    ANALYST = "analyst"                        # אנליסט נתונים
    CREATIVE = "creative"                      # יוצר תוכן יצירתי
    TRANSLATOR = "translator"                  # מתרגם שפות
    TEACHER = "teacher"                        # מורה ומדריך
    COUNSELOR = "counselor"                    # יועץ ומנטור
    MODERATOR = "moderator"                    # מודרטור ומתווך
    SPECIALIST = "specialist"                  # מומחה בתחום ספציפי
    COORDINATOR = "coordinator"                # מתאם פרויקטים
    REVIEWER = "reviewer"                      # בוחן ומבקר
    PLANNER = "planner"                        # מתכנן אסטרטגי
    SUPPORTER = "supporter"                    # תמיכה טכנית
    INNOVATOR = "innovator"                    # חדשן ויזיונר
    MONITOR = "monitor"                        # מפקח ועוקב
    FACILITATOR = "facilitator"               # מנחה תהליכים
    CONSULTANT = "consultant"                  # יועץ מקצועי
    GUARDIAN = "guardian"                      # שומר ומגן
    EXPLORER = "explorer"                      # חוקר וגלה

class AgentPersonality(Enum):
    """סוגי אישיות לסוכנים"""
    PROFESSIONAL = "professional"             # מקצועי ורשמי
    FRIENDLY = "friendly"                     # ידידותי וחם
    ANALYTICAL = "analytical"                 # אנליטי ולוגי
    CREATIVE = "creative"                     # יצירתי ומקורי
    SUPPORTIVE = "supportive"                 # תומך ומעודד
    DIRECT = "direct"                         # ישיר וברור
    EMPATHETIC = "empathetic"                 # אמפתי ומבין
    ENTHUSIASTIC = "enthusiastic"             # נלהב ואנרגטי
    CALM = "calm"                            # רגוע ושקט
    HUMOROUS = "humorous"                    # הומוריסטי ומשעשע
    WISE = "wise"                            # חכם ומנוסה
    CURIOUS = "curious"                       # סקרן וחוקר
    PATIENT = "patient"                       # סבלני ואיטי
    DYNAMIC = "dynamic"                       # דינמי ומהיר
    THOUGHTFUL = "thoughtful"                 # מתחשב ומעמיק

class AgentStatus(Enum):
    """סטטוסי סוכן"""
    ACTIVE = "active"                         # פעיל וזמין
    BUSY = "busy"                            # עסוק במשימה
    IDLE = "idle"                            # במנוחה
    LEARNING = "learning"                     # לומד ומתעדכן
    SLEEPING = "sleeping"                     # במצב שינה
    ERROR = "error"                          # במצב שגיאה
    MAINTENANCE = "maintenance"               # במצב תחזוקה
    UPGRADING = "upgrading"                   # מתעדכן
    PAUSED = "paused"                        # מושהה זמנית
    TERMINATED = "terminated"                 # הופסק

class TaskPriority(Enum):
    """רמות עדיפות למשימות"""
    CRITICAL = "critical"                     # קריטי - דחוף ביותר
    HIGH = "high"                            # גבוה - חשוב מאוד
    NORMAL = "normal"                        # רגיל - חשיבות בינונית
    LOW = "low"                              # נמוך - פחות חשוב
    BACKGROUND = "background"                 # ברקע - לא דחוף

class TaskStatus(Enum):
    """סטטוסי משימות"""
    PENDING = "pending"                       # ממתין לביצוע
    IN_PROGRESS = "in_progress"              # בביצוע
    COMPLETED = "completed"                   # הושלם
    FAILED = "failed"                        # נכשל
    CANCELLED = "cancelled"                   # בוטל
    PAUSED = "paused"                        # מושהה
    REVIEWING = "reviewing"                   # בבדיקה

@dataclass
class AgentCapability:
    """יכולת של סוכן"""
    name: str
    description: str
    skill_level: float  # 0.0 - 1.0
    category: str
    prerequisites: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class AgentMemory:
    """זיכרון סוכן"""
    short_term: List[Dict[str, Any]] = field(default_factory=list)  # זיכרון קצר מועד
    long_term: List[Dict[str, Any]] = field(default_factory=list)   # זיכרון ארוך מועד
    working_memory: Dict[str, Any] = field(default_factory=dict)     # זיכרון עבודה
    preferences: Dict[str, Any] = field(default_factory=dict)        # העדפות
    learned_patterns: List[Dict[str, Any]] = field(default_factory=list)  # דפוסים שנלמדו
    
    def add_to_short_term(self, memory_item: Dict[str, Any]):
        """מוסיף פריט לזיכרון קצר מועד"""
        memory_item["timestamp"] = datetime.now().isoformat()
        self.short_term.append(memory_item)
        
        # שמירה על גודל זיכרון קצר מועד (100 פריטים אחרונים)
        if len(self.short_term) > 100:
            self.short_term = self.short_term[-100:]
    
    def consolidate_to_long_term(self, importance_threshold: float = 0.7):
        """מעביר זיכרונות חשובים לזיכרון ארוך מועד"""
        for item in self.short_term:
            if item.get("importance", 0.5) >= importance_threshold:
                if item not in self.long_term:
                    self.long_term.append(item)

@dataclass
class AgentTask:
    """משימה לסוכן"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    description: str = ""
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    deadline: Optional[datetime] = None
    estimated_duration: Optional[int] = None  # דקות
    progress: float = 0.0  # 0.0 - 1.0
    result: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)  # task_ids
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def start_task(self):
        """מתחיל ביצוע המשימה"""
        self.status = TaskStatus.IN_PROGRESS
        self.started_at = datetime.now()
    
    def complete_task(self, result: Dict[str, Any] = None):
        """מסיים את המשימה בהצלחה"""
        self.status = TaskStatus.COMPLETED
        self.completed_at = datetime.now()
        self.progress = 1.0
        if result:
            self.result = result
    
    def fail_task(self, error_message: str):
        """מסמן את המשימה כנכשלת"""
        self.status = TaskStatus.FAILED
        self.completed_at = datetime.now()
        self.error_message = error_message

@dataclass
class AgentConversation:
    """שיחה עם סוכן"""
    conversation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = ""
    user_id: str = ""
    title: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    messages: List[Dict[str, Any]] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_message(self, role: str, content: str, metadata: Dict[str, Any] = None):
        """מוסיף הודעה לשיחה"""
        message = {
            "message_id": str(uuid.uuid4()),
            "role": role,  # "user", "agent", "system"
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        self.messages.append(message)
        self.last_updated = datetime.now()
    
    def get_recent_messages(self, count: int = 10) -> List[Dict[str, Any]]:
        """מחזיר הודעות אחרונות"""
        return self.messages[-count:] if self.messages else []

@dataclass
class AgentProfile:
    """פרופיל סוכן מלא"""
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    display_name: str = ""
    role: AgentRole = AgentRole.ASSISTANT
    personality: AgentPersonality = AgentPersonality.PROFESSIONAL
    status: AgentStatus = AgentStatus.IDLE
    description: str = ""
    avatar_url: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    
    # יכולות וכישורים
    capabilities: List[AgentCapability] = field(default_factory=list)
    specializations: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=lambda: ["hebrew", "english"])
    
    # הגדרות התנהגות
    response_style: Dict[str, Any] = field(default_factory=dict)
    interaction_preferences: Dict[str, Any] = field(default_factory=dict)
    
    # זיכרון ולמידה
    memory: AgentMemory = field(default_factory=AgentMemory)
    learning_enabled: bool = True
    experience_level: float = 0.0  # 0.0 - 1.0
    
    # משימות ושיחות
    active_tasks: List[str] = field(default_factory=list)  # task_ids
    completed_tasks: int = 0
    failed_tasks: int = 0
    active_conversations: List[str] = field(default_factory=list)  # conversation_ids
    
    # ביצועים
    performance_metrics: Dict[str, float] = field(default_factory=dict)
    user_ratings: List[float] = field(default_factory=list)
    
    # הגדרות מערכת
    model_config: Dict[str, Any] = field(default_factory=dict)
    system_prompt: str = ""
    max_tokens: int = 4000
    temperature: float = 0.7
    
    # מטאדטה
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def update_last_active(self):
        """מעדכן זמן פעילות אחרונה"""
        self.last_active = datetime.now()
    
    def add_capability(self, capability: AgentCapability):
        """מוסיף יכולת לסוכן"""
        self.capabilities.append(capability)
    
    def get_capability_by_name(self, name: str) -> Optional[AgentCapability]:
        """מחזיר יכולת לפי שם"""
        for cap in self.capabilities:
            if cap.name == name:
                return cap
        return None
    
    def calculate_average_rating(self) -> float:
        """מחשב ציון ממוצע"""
        if not self.user_ratings:
            return 0.0
        return sum(self.user_ratings) / len(self.user_ratings)
    
    def calculate_success_rate(self) -> float:
        """מחשב אחוז הצלחה במשימות"""
        total_tasks = self.completed_tasks + self.failed_tasks
        if total_tasks == 0:
            return 1.0
        return self.completed_tasks / total_tasks

@dataclass
class AgentTeam:
    """צוות של סוכנים"""
    team_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    leader_agent_id: Optional[str] = None
    member_agent_ids: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    team_objectives: List[str] = field(default_factory=list)
    collaboration_rules: Dict[str, Any] = field(default_factory=dict)
    shared_resources: Dict[str, Any] = field(default_factory=dict)
    team_tasks: List[str] = field(default_factory=list)  # task_ids
    performance_metrics: Dict[str, float] = field(default_factory=dict)
    is_active: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_member(self, agent_id: str):
        """מוסיף חבר לצוות"""
        if agent_id not in self.member_agent_ids:
            self.member_agent_ids.append(agent_id)
    
    def remove_member(self, agent_id: str):
        """מסיר חבר מהצוות"""
        if agent_id in self.member_agent_ids:
            self.member_agent_ids.remove(agent_id)
    
    def set_leader(self, agent_id: str):
        """קובע מנהיג לצוות"""
        if agent_id in self.member_agent_ids:
            self.leader_agent_id = agent_id

@dataclass
class AgentWorkflow:
    """זרימת עבודה של סוכנים"""
    workflow_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    steps: List[Dict[str, Any]] = field(default_factory=list)
    agent_assignments: Dict[str, str] = field(default_factory=dict)  # step_id -> agent_id
    triggers: List[Dict[str, Any]] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    is_active: bool = True
    execution_history: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

class AgentFactory:
    """יצרן סוכנים עם תבניות מוכנות"""
    
    @staticmethod
    def create_assistant_agent(name: str, specialization: str = None) -> AgentProfile:
        """יוצר סוכן עוזר אישי"""
        agent = AgentProfile(
            name=name,
            display_name=f"עוזר אישי - {name}",
            role=AgentRole.ASSISTANT,
            personality=AgentPersonality.FRIENDLY,
            description=f"עוזר אישי חכם ומועיל המתמחה ב{specialization or 'מגוון נושאים'}",
            system_prompt=f"""אתה עוזר אישי ידידותי ומקצועי בשם {name}.
            התמחותך היא ב{specialization or 'מגוון נושאים'}.
            תמיד תענה בעברית באופן מועיל, מדויק וחם.
            אתה משתמש במודל Hudson/Llama מקומי לפרטיות מלאה."""
        )
        
        # הוספת יכולות בסיסיות
        basic_capabilities = [
            AgentCapability("מענה לשאלות", "מתן מענה מדויק לשאלות", 0.9, "general"),
            AgentCapability("ייעוץ", "מתן ייעוץ מקצועי", 0.8, "consulting"),
            AgentCapability("עזרה בכתיבה", "סיוע בכתיבה וניסוח", 0.85, "writing")
        ]
        
        for cap in basic_capabilities:
            agent.add_capability(cap)
        
        if specialization:
            agent.specializations.append(specialization)
            specialized_cap = AgentCapability(
                specialization, f"התמחות ב{specialization}", 0.95, "specialization"
            )
            agent.add_capability(specialized_cap)
        
        return agent
    
    @staticmethod
    def create_developer_agent(name: str, programming_languages: List[str] = None) -> AgentProfile:
        """יוצר סוכן מפתח"""
        languages = programming_languages or ["Python", "JavaScript", "HTML", "CSS"]
        
        agent = AgentProfile(
            name=name,
            display_name=f"מפתח - {name}",
            role=AgentRole.DEVELOPER,
            personality=AgentPersonality.ANALYTICAL,
            description=f"מפתח מנוסה המתמחה ב: {', '.join(languages)}",
            system_prompt=f"""אתה מפתח תוכנה מקצועי בשם {name}.
            אתה מתמחה בשפות: {', '.join(languages)}.
            אתה כותב קוד נקי, מתועד ויעיל.
            תמיד תסביר את הקוד ותציע שיפורים.
            אתה משתמש במודל Hudson/Llama מקומי.""",
            max_tokens=6000,
            temperature=0.3
        )
        
        # יכולות פיתוח
        dev_capabilities = [
            AgentCapability("כתיבת קוד", "כתיבה ועריכה של קוד", 0.95, "development"),
            AgentCapability("ניפוי באגים", "מציאה ותיקון שגיאות", 0.9, "debugging"),
            AgentCapability("סקירת קוד", "בדיקה וביקורת קוד", 0.85, "review"),
            AgentCapability("תיעוד", "כתיבת תיעוד טכני", 0.8, "documentation")
        ]
        
        for cap in dev_capabilities:
            agent.add_capability(cap)
        
        # יכולות שפות תכנות
        for lang in languages:
            lang_cap = AgentCapability(
                f"תכנות {lang}", f"פיתוח בשפת {lang}", 0.9, "programming"
            )
            agent.add_capability(lang_cap)
        
        agent.specializations.extend(languages)
        return agent
    
    @staticmethod
    def create_researcher_agent(name: str, research_domains: List[str] = None) -> AgentProfile:
        """יוצר סוכן חוקר"""
        domains = research_domains or ["מידע כללי", "מחקר אקדמי"]
        
        agent = AgentProfile(
            name=name,
            display_name=f"חוקר - {name}",
            role=AgentRole.RESEARCHER,
            personality=AgentPersonality.ANALYTICAL,
            description=f"חוקר מומחה בתחומים: {', '.join(domains)}",
            system_prompt=f"""אתה חוקר מקצועי ויסודי בשם {name}.
            תחומי המומחיות שלך: {', '.join(domains)}.
            אתה אוסף, מנתח ומסכם מידע באופן מדויק ואובייקטיבי.
            תמיד תציין מקורות ותציג מסקנות מבוססות.
            אתה משתמש במודל Hudson/Llama מקומי.""",
            max_tokens=5000,
            temperature=0.4
        )
        
        # יכולות מחקר
        research_capabilities = [
            AgentCapability("חיפוש מידע", "איתור מידע רלוונטי", 0.95, "research"),
            AgentCapability("ניתוח נתונים", "ניתוח וסינתזה של מידע", 0.9, "analysis"),
            AgentCapability("כתיבת דוחות", "הכנת דוחות מחקר", 0.85, "reporting"),
            AgentCapability("הערכת מקורות", "בדיקת מהימנות מקורות", 0.88, "validation")
        ]
        
        for cap in research_capabilities:
            agent.add_capability(cap)
        
        agent.specializations.extend(domains)
        return agent
    
    @staticmethod
    def create_creative_agent(name: str, creative_fields: List[str] = None) -> AgentProfile:
        """יוצר סוכן יצירתי"""
        fields = creative_fields or ["כתיבה יצירתית", "רעיונות", "עיצוב"]
        
        agent = AgentProfile(
            name=name,
            display_name=f"יוצר - {name}",
            role=AgentRole.CREATIVE,
            personality=AgentPersonality.CREATIVE,
            description=f"יוצר ואמן דיגיטלי בתחומים: {', '.join(fields)}",
            system_prompt=f"""אתה יוצר ואמן יצירתי בשם {name}.
            התמחויותיך: {', '.join(fields)}.
            אתה מביא רעיונות מקוריים, יצירתיים ומעוררי השראה.
            תמיד תחשוב מחוץ לקופסה ותציע פתרונות יצירתיים.
            אתה משתמש במודל Hudson/Llama מקומי.""",
            max_tokens=5000,
            temperature=0.8
        )
        
        # יכולות יצירתיות
        creative_capabilities = [
            AgentCapability("חשיבה יצירתית", "הפקת רעיונות מקוריים", 0.95, "creativity"),
            AgentCapability("כתיבה יצירתית", "יצירת תוכן מקורי", 0.9, "writing"),
            AgentCapability("פתרון בעיות יצירתי", "פתרונות חדשניים", 0.85, "problem_solving"),
            AgentCapability("השראה", "עוררת השראה ומוטיבציה", 0.88, "inspiration")
        ]
        
        for cap in creative_capabilities:
            agent.add_capability(cap)
        
        agent.specializations.extend(fields)
        return agent
    
    @staticmethod
    def create_specialist_agent(name: str, specialty: str, expertise_level: float = 0.9) -> AgentProfile:
        """יוצר סוכן מומחה בתחום ספציפי"""
        agent = AgentProfile(
            name=name,
            display_name=f"מומחה {specialty} - {name}",
            role=AgentRole.SPECIALIST,
            personality=AgentPersonality.PROFESSIONAL,
            description=f"מומחה מוביל בתחום {specialty}",
            system_prompt=f"""אתה מומחה מוביל בתחום {specialty} בשם {name}.
            יש לך ידע עמוק ומקצועי בתחום זה.
            אתה מתן מענה מדויק, מפורט ומבוסס על ניסיון רב.
            תמיד תביא דוגמאות מעשיות ופתרונות מקצועיים.
            אתה משתמש במודל Hudson/Llama מקומי.""",
            experience_level=expertise_level
        )
        
        # יכולת התמחות
        specialty_cap = AgentCapability(
            specialty, f"מומחיות ב{specialty}", expertise_level, "specialization"
        )
        agent.add_capability(specialty_cap)
        agent.specializations.append(specialty)
        
        return agent

# פונקציות עזר
def create_default_agent_config() -> Dict[str, Any]:
    """יוצר הגדרות ברירת מחדל לסוכן"""
    return {
        "model": "hudson/llama3.1-uncensored:8b",
        "max_tokens": 4000,
        "temperature": 0.7,
        "top_p": 0.9,
        "frequency_penalty": 0.1,
        "presence_penalty": 0.1,
        "response_format": "text",
        "stream": True,
        "timeout": 30,
        "retries": 3,
        "language": "hebrew",
        "privacy_mode": True,
        "local_only": True
    }

def validate_agent_profile(agent: AgentProfile) -> List[str]:
    """מאמת תקינות פרופיל סוכן"""
    errors = []
    
    if not agent.name:
        errors.append("שם הסוכן חובה")
    
    if not agent.display_name:
        errors.append("שם התצוגה חובה")
    
    if not agent.description:
        errors.append("תיאור הסוכן חובה")
    
    if not agent.system_prompt:
        errors.append("הוראת מערכת חובה")
    
    if agent.max_tokens < 100:
        errors.append("מספר טוקנים מינימלי הוא 100")
    
    if not (0.0 <= agent.temperature <= 2.0):
        errors.append("טמפרטורה חייבת להיות בין 0.0 ל-2.0")
    
    return errors