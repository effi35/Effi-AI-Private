"""
Advanced Agent Manager - ניהול מתקדם של סוכני AI
מנהל עד 25 סוכנים במקביל עם מודל Hudson/Llama מקומי
"""

import asyncio
import json
from typing import Dict, List, Any, Optional, Set, Tuple
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import threading
import weakref
from collections import defaultdict, deque

from ..models.agent_types import (
    AgentProfile, AgentTask, AgentConversation, AgentTeam,
    AgentStatus, TaskStatus, TaskPriority, AgentRole,
    AgentFactory, create_default_agent_config
)

class AgentManager:
    """מנהל מתקדם לסוכני AI עם יכולות מקבילות וניהול משאבים"""
    
    def __init__(self, max_agents: int = 25, max_concurrent_tasks: int = 50):
        # הגדרות בסיסיות
        self.max_agents = max_agents
        self.max_concurrent_tasks = max_concurrent_tasks
        
        # אחסון נתונים
        self.agents: Dict[str, AgentProfile] = {}
        self.tasks: Dict[str, AgentTask] = {}
        self.conversations: Dict[str, AgentConversation] = {}
        self.teams: Dict[str, AgentTeam] = {}
        
        # ניהול משאבים
        self.active_tasks: Set[str] = set()
        self.task_queue: deque = deque()
        self.conversation_sessions: Dict[str, Dict[str, Any]] = {}
        
        # מוני ביצועים
        self.performance_metrics = {
            "total_tasks_completed": 0,
            "total_tasks_failed": 0,
            "total_conversations": 0,
            "average_response_time": 0.0,
            "agents_created": 0,
            "system_uptime": datetime.now()
        }
        
        # אירועים וניטור
        self.event_listeners: Dict[str, List[callable]] = defaultdict(list)
        self.system_logs: List[Dict[str, Any]] = []
        
        # חוטי עבודה
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.is_running = True
        
        # התחלת לולאות פעילות
        self._start_background_tasks()
        
        # יצירת סוכנים ברירת מחדל
        self._create_default_agents()
        
        self._log_system_event("system_startup", "Agent Manager started successfully")
    
    def _start_background_tasks(self):
        """מתחיל משימות רקע"""
        # לולאה לעיבוד משימות
        threading.Thread(target=self._task_processing_loop, daemon=True).start()
        
        # לולאה לניטור מערכת
        threading.Thread(target=self._system_monitoring_loop, daemon=True).start()
        
        # לולאה לניקוי זיכרון
        threading.Thread(target=self._memory_cleanup_loop, daemon=True).start()
    
    def _create_default_agents(self):
        """יוצר סוכנים ברירת מחדל"""
        default_agents = [
            ("אלכס", AgentRole.ASSISTANT, "עוזר כללי"),
            ("דני", AgentRole.DEVELOPER, "פיתוח תוכנה"),
            ("מיה", AgentRole.RESEARCHER, "מחקר ואנליזה"),
            ("רון", AgentRole.CREATIVE, "יצירתיות ועיצוב"),
            ("לינה", AgentRole.TRANSLATOR, "תרגום שפות")
        ]
        
        for name, role, specialty in default_agents:
            try:
                if role == AgentRole.ASSISTANT:
                    agent = AgentFactory.create_assistant_agent(name, specialty)
                elif role == AgentRole.DEVELOPER:
                    agent = AgentFactory.create_developer_agent(name)
                elif role == AgentRole.RESEARCHER:
                    agent = AgentFactory.create_researcher_agent(name)
                elif role == AgentRole.CREATIVE:
                    agent = AgentFactory.create_creative_agent(name)
                else:
                    agent = AgentFactory.create_specialist_agent(name, specialty)
                
                self.register_agent(agent)
                self._log_system_event("agent_created", f"Default agent {name} created")
                
            except Exception as e:
                self._log_system_event("error", f"Failed to create default agent {name}: {str(e)}")
    
    # ===== ניהול סוכנים =====
    
    async def register_agent(self, agent: AgentProfile) -> bool:
        """רושם סוכן חדש במערכת"""
        try:
            if len(self.agents) >= self.max_agents:
                self._log_system_event("warning", f"Maximum agents limit reached ({self.max_agents})")
                return False
            
            if agent.agent_id in self.agents:
                self._log_system_event("warning", f"Agent {agent.agent_id} already exists")
                return False
            
            # הגדרת קונפיגורציה ברירת מחדל
            if not agent.model_config:
                agent.model_config = create_default_agent_config()
            
            # רישום הסוכן
            self.agents[agent.agent_id] = agent
            agent.status = AgentStatus.IDLE
            
            # עדכון מוני ביצועים
            self.performance_metrics["agents_created"] += 1
            
            # שליחת אירוע
            await self._emit_event("agent_registered", {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "role": agent.role.value
            })
            
            self._log_system_event("agent_registered", f"Agent {agent.name} registered successfully")
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to register agent: {str(e)}")
            return False
    
    async def unregister_agent(self, agent_id: str) -> bool:
        """מבטל רישום סוכן"""
        try:
            if agent_id not in self.agents:
                return False
            
            agent = self.agents[agent_id]
            
            # ביטול משימות פעילות
            for task_id in agent.active_tasks.copy():
                await self.cancel_task(task_id)
            
            # סגירת שיחות פעילות
            for conv_id in agent.active_conversations.copy():
                await self.end_conversation(conv_id)
            
            # הסרה מצוותים
            for team in self.teams.values():
                if agent_id in team.member_agent_ids:
                    team.remove_member(agent_id)
                if team.leader_agent_id == agent_id:
                    team.leader_agent_id = None
            
            # הסרת הסוכן
            del self.agents[agent_id]
            
            await self._emit_event("agent_unregistered", {"agent_id": agent_id})
            self._log_system_event("agent_unregistered", f"Agent {agent.name} unregistered")
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to unregister agent {agent_id}: {str(e)}")
            return False
    
    def get_agent(self, agent_id: str) -> Optional[AgentProfile]:
        """מחזיר סוכן לפי ID"""
        return self.agents.get(agent_id)
    
    def get_agents_by_role(self, role: AgentRole) -> List[AgentProfile]:
        """מחזיר סוכנים לפי תפקיד"""
        return [agent for agent in self.agents.values() if agent.role == role]
    
    def get_available_agents(self) -> List[AgentProfile]:
        """מחזיר סוכנים זמינים למשימות"""
        return [agent for agent in self.agents.values() 
                if agent.status in [AgentStatus.IDLE, AgentStatus.ACTIVE]]
    
    async def update_agent_status(self, agent_id: str, status: AgentStatus) -> bool:
        """מעדכן סטטוס סוכן"""
        if agent_id in self.agents:
            old_status = self.agents[agent_id].status
            self.agents[agent_id].status = status
            self.agents[agent_id].update_last_active()
            
            await self._emit_event("agent_status_changed", {
                "agent_id": agent_id,
                "old_status": old_status.value,
                "new_status": status.value
            })
            return True
        return False
    
    # ===== ניהול משימות =====
    
    async def create_task(self, task: AgentTask) -> bool:
        """יוצר משימה חדשה"""
        try:
            if len(self.active_tasks) >= self.max_concurrent_tasks:
                self.task_queue.append(task)
                self._log_system_event("task_queued", f"Task {task.task_id} queued")
                return True
            
            self.tasks[task.task_id] = task
            
            # חיפוש סוכן מתאים
            suitable_agent = await self._find_suitable_agent(task)
            
            if suitable_agent:
                await self.assign_task(task.task_id, suitable_agent.agent_id)
            else:
                self.task_queue.append(task)
                self._log_system_event("task_queued", f"No suitable agent for task {task.task_id}")
            
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to create task: {str(e)}")
            return False
    
    async def assign_task(self, task_id: str, agent_id: str) -> bool:
        """מקצה משימה לסוכן"""
        try:
            if task_id not in self.tasks or agent_id not in self.agents:
                return False
            
            task = self.tasks[task_id]
            agent = self.agents[agent_id]
            
            # בדיקת זמינות
            if agent.status not in [AgentStatus.IDLE, AgentStatus.ACTIVE]:
                return False
            
            # הקצאה
            task.assigned_agent_id = agent_id
            task.start_task()
            
            agent.active_tasks.append(task_id)
            await self.update_agent_status(agent_id, AgentStatus.BUSY)
            
            self.active_tasks.add(task_id)
            
            # התחלת ביצוע
            asyncio.create_task(self._execute_task(task_id))
            
            await self._emit_event("task_assigned", {
                "task_id": task_id,
                "agent_id": agent_id,
                "task_title": task.title
            })
            
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to assign task {task_id}: {str(e)}")
            return False
    
    async def _execute_task(self, task_id: str):
        """מבצע משימה"""
        try:
            task = self.tasks[task_id]
            agent = self.agents[task.assigned_agent_id]
            
            start_time = datetime.now()
            
            # בנייה של prompt למשימה
            task_prompt = f"""
            משימה: {task.title}
            תיאור: {task.description}
            עדיפות: {task.priority.value}
            
            הוראות:
            - בצע את המשימה בקפידה ובדיוק
            - ספק תוצאה מפורטת ומועילה
            - אם יש בעיות, דווח עליהן בפירוט
            
            התחל בביצוע המשימה:
            """
            
            # יצירת קונטקסט למשימה
            context = {
                "task_id": task_id,
                "agent_id": agent.agent_id,
                "priority": task.priority.value,
                "metadata": task.metadata
            }
            
            # ביצוע המשימה (סימולציה - בפועל יקרא למודל AI)
            result = await self._simulate_task_execution(task_prompt, agent, context)
            
            # עדכון תוצאה
            execution_time = (datetime.now() - start_time).total_seconds()
            
            if result.get("success", False):
                task.complete_task(result)
                self.performance_metrics["total_tasks_completed"] += 1
                
                await self._emit_event("task_completed", {
                    "task_id": task_id,
                    "agent_id": agent.agent_id,
                    "execution_time": execution_time,
                    "result": result
                })
            else:
                task.fail_task(result.get("error", "Unknown error"))
                self.performance_metrics["total_tasks_failed"] += 1
                
                await self._emit_event("task_failed", {
                    "task_id": task_id,
                    "agent_id": agent.agent_id,
                    "error": result.get("error")
                })
            
            # עדכון סטטוס סוכן
            agent.active_tasks.remove(task_id)
            if not agent.active_tasks:
                await self.update_agent_status(agent.agent_id, AgentStatus.IDLE)
            
            self.active_tasks.remove(task_id)
            
            # עדכון ביצועים
            self._update_performance_metrics(execution_time)
            
            # בדיקה אם יש משימות בתור
            await self._process_task_queue()
            
        except Exception as e:
            self._log_system_event("error", f"Task execution failed for {task_id}: {str(e)}")
            task.fail_task(str(e))
            if task_id in self.active_tasks:
                self.active_tasks.remove(task_id)
    
    async def _simulate_task_execution(self, prompt: str, agent: AgentProfile, context: Dict[str, Any]) -> Dict[str, Any]:
        """סימולציה של ביצוע משימה - בפועל יחובר למודל AI"""
        # כאן יהיה החיבור האמיתי למודל Hudson/Llama
        # זוהי סימולציה לצורך הדוגמה
        
        await asyncio.sleep(1)  # סימולציה של זמן עיבוד
        
        # סימולציה של תוצאה מוצלחת ברוב המקרים
        import random
        success_rate = 0.9  # 90% הצלחה
        
        if random.random() < success_rate:
            return {
                "success": True,
                "result": f"משימה הושלמה בהצלחה על ידי {agent.name}",
                "details": {
                    "agent_response": f"ביצעתי את המשימה כפי שהתבקשתי. התוצאה מוכנה.",
                    "processing_time": random.uniform(0.5, 3.0),
                    "confidence": random.uniform(0.8, 1.0)
                }
            }
        else:
            return {
                "success": False,
                "error": "שגיאה בביצוע המשימה - לא הצלחתי להשלים אותה"
            }
    
    async def cancel_task(self, task_id: str) -> bool:
        """מבטל משימה"""
        try:
            if task_id not in self.tasks:
                return False
            
            task = self.tasks[task_id]
            
            if task.status == TaskStatus.IN_PROGRESS:
                task.status = TaskStatus.CANCELLED
                
                if task.assigned_agent_id:
                    agent = self.agents[task.assigned_agent_id]
                    if task_id in agent.active_tasks:
                        agent.active_tasks.remove(task_id)
                    
                    if not agent.active_tasks:
                        await self.update_agent_status(task.assigned_agent_id, AgentStatus.IDLE)
                
                if task_id in self.active_tasks:
                    self.active_tasks.remove(task_id)
                
                await self._emit_event("task_cancelled", {"task_id": task_id})
            
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to cancel task {task_id}: {str(e)}")
            return False
    
    async def _find_suitable_agent(self, task: AgentTask) -> Optional[AgentProfile]:
        """מוצא סוכן מתאים למשימה"""
        available_agents = self.get_available_agents()
        
        if not available_agents:
            return None
        
        # ניקוד סוכנים לפי התאמה
        scored_agents = []
        
        for agent in available_agents:
            score = 0.0
            
            # ניקוד לפי יכולות
            for capability in agent.capabilities:
                if any(keyword in task.description.lower() or keyword in task.title.lower() 
                      for keyword in capability.name.lower().split()):
                    score += capability.skill_level * 10
            
            # ניקוד לפי התמחויות
            for spec in agent.specializations:
                if spec.lower() in task.description.lower() or spec.lower() in task.title.lower():
                    score += 15
            
            # ניקוד לפי ביצועים קודמים
            score += agent.calculate_success_rate() * 5
            
            # עונש על עומס עבודה
            score -= len(agent.active_tasks) * 2
            
            scored_agents.append((agent, score))
        
        # מיון לפי ניקוד
        scored_agents.sort(key=lambda x: x[1], reverse=True)
        
        return scored_agents[0][0] if scored_agents else None
    
    # ===== ניהול שיחות =====
    
    async def start_conversation(self, agent_id: str, user_id: str, title: str = "") -> Optional[str]:
        """מתחיל שיחה עם סוכן"""
        try:
            if agent_id not in self.agents:
                return None
            
            agent = self.agents[agent_id]
            
            conversation = AgentConversation(
                agent_id=agent_id,
                user_id=user_id,
                title=title or f"שיחה עם {agent.display_name}"
            )
            
            self.conversations[conversation.conversation_id] = conversation
            agent.active_conversations.append(conversation.conversation_id)
            
            # יצירת session
            self.conversation_sessions[conversation.conversation_id] = {
                "context": {},
                "history": [],
                "last_activity": datetime.now()
            }
            
            self.performance_metrics["total_conversations"] += 1
            
            await self._emit_event("conversation_started", {
                "conversation_id": conversation.conversation_id,
                "agent_id": agent_id,
                "user_id": user_id
            })
            
            return conversation.conversation_id
            
        except Exception as e:
            self._log_system_event("error", f"Failed to start conversation: {str(e)}")
            return None
    
    async def send_message(self, conversation_id: str, user_message: str) -> Optional[str]:
        """שולח הודעה בשיחה ומחזיר תגובת הסוכן"""
        try:
            if conversation_id not in self.conversations:
                return None
            
            conversation = self.conversations[conversation_id]
            agent = self.agents[conversation.agent_id]
            
            # הוספת הודעת המשתמש
            conversation.add_message("user", user_message)
            
            # בניית קונטקסט לסוכן
            context = self._build_conversation_context(conversation, agent)
            
            # קבלת תגובה מהסוכן (סימולציה)
            agent_response = await self._get_agent_response(agent, user_message, context)
            
            # הוספת תגובת הסוכן
            conversation.add_message("agent", agent_response)
            
            # עדכון session
            if conversation_id in self.conversation_sessions:
                self.conversation_sessions[conversation_id]["last_activity"] = datetime.now()
                self.conversation_sessions[conversation_id]["history"].append({
                    "user": user_message,
                    "agent": agent_response,
                    "timestamp": datetime.now().isoformat()
                })
            
            await self._emit_event("message_sent", {
                "conversation_id": conversation_id,
                "user_message": user_message,
                "agent_response": agent_response
            })
            
            return agent_response
            
        except Exception as e:
            self._log_system_event("error", f"Failed to send message: {str(e)}")
            return None
    
    def _build_conversation_context(self, conversation: AgentConversation, agent: AgentProfile) -> Dict[str, Any]:
        """בונה קונטקסט לשיחה"""
        recent_messages = conversation.get_recent_messages(10)
        
        return {
            "agent_name": agent.name,
            "agent_role": agent.role.value,
            "agent_personality": agent.personality.value,
            "conversation_history": recent_messages,
            "agent_specializations": agent.specializations,
            "system_prompt": agent.system_prompt,
            "conversation_context": conversation.context
        }
    
    async def _get_agent_response(self, agent: AgentProfile, user_message: str, context: Dict[str, Any]) -> str:
        """מקבל תגובה מהסוכן - סימולציה"""
        # כאן יהיה החיבור האמיתי למודל Hudson/Llama
        # זוהי סימולציה לצורך הדוגמה
        
        await asyncio.sleep(0.5)  # סימולציה של זמן עיבוד
        
        # תגובות לדוגמה לפי תפקיד הסוכן
        if agent.role == AgentRole.ASSISTANT:
            return f"שלום! אני {agent.name}, העוזר האישי שלך. איך אוכל לעזור לך היום?"
        elif agent.role == AgentRole.DEVELOPER:
            return f"היי! אני {agent.name}, המפתח שלך. איזה פרויקט תכנות תרצה שנעבוד עליו?"
        elif agent.role == AgentRole.RESEARCHER:
            return f"שלום! אני {agent.name}, החוקר שלך. על איזה נושא תרצה שאחקור עבורך?"
        elif agent.role == AgentRole.CREATIVE:
            return f"היי! אני {agent.name}, הצוות היצירתי שלך. איזה רעיון יצירתי נפתח היום?"
        else:
            return f"שלום! אני {agent.name}. איך אוכל לסייע לך בהתמחותי?"
    
    async def end_conversation(self, conversation_id: str) -> bool:
        """מסיים שיחה"""
        try:
            if conversation_id not in self.conversations:
                return False
            
            conversation = self.conversations[conversation_id]
            agent = self.agents[conversation.agent_id]
            
            conversation.is_active = False
            
            if conversation_id in agent.active_conversations:
                agent.active_conversations.remove(conversation_id)
            
            if conversation_id in self.conversation_sessions:
                del self.conversation_sessions[conversation_id]
            
            await self._emit_event("conversation_ended", {"conversation_id": conversation_id})
            return True
            
        except Exception as e:
            self._log_system_event("error", f"Failed to end conversation: {str(e)}")
            return False
    
    # ===== ניהול צוותים =====
    
    async def create_team(self, team_name: str, agent_ids: List[str], leader_id: str = None) -> Optional[str]:
        """יוצר צוות של סוכנים"""
        try:
            # בדיקת תקינות
            for agent_id in agent_ids:
                if agent_id not in self.agents:
                    return None
            
            if leader_id and leader_id not in agent_ids:
                return None
            
            team = AgentTeam(
                name=team_name,
                member_agent_ids=agent_ids,
                leader_agent_id=leader_id
            )
            
            self.teams[team.team_id] = team
            
            await self._emit_event("team_created", {
                "team_id": team.team_id,
                "team_name": team_name,
                "members": agent_ids
            })
            
            return team.team_id
            
        except Exception as e:
            self._log_system_event("error", f"Failed to create team: {str(e)}")
            return None
    
    # ===== לולאות רקע =====
    
    def _task_processing_loop(self):
        """לולאה לעיבוד תור המשימות"""
        while self.is_running:
            try:
                if self.task_queue and len(self.active_tasks) < self.max_concurrent_tasks:
                    asyncio.create_task(self._process_task_queue())
                
                time.sleep(1)
                
            except Exception as e:
                self._log_system_event("error", f"Task processing loop error: {str(e)}")
    
    async def _process_task_queue(self):
        """מעבד משימות מהתור"""
        while self.task_queue and len(self.active_tasks) < self.max_concurrent_tasks:
            task = self.task_queue.popleft()
            suitable_agent = await self._find_suitable_agent(task)
            
            if suitable_agent:
                await self.assign_task(task.task_id, suitable_agent.agent_id)
            else:
                # חזרה לתור אם אין סוכן זמין
                self.task_queue.appendleft(task)
                break
    
    def _system_monitoring_loop(self):
        """לולאה לניטור מערכת"""
        import time
        
        while self.is_running:
            try:
                # בדיקת בריאות סוכנים
                self._check_agents_health()
                
                # בדיקת שיחות פעילות
                self._check_active_conversations()
                
                # עדכון מטריקות
                self._update_system_metrics()
                
                time.sleep(30)  # בדיקה כל 30 שניות
                
            except Exception as e:
                self._log_system_event("error", f"System monitoring error: {str(e)}")
    
    def _memory_cleanup_loop(self):
        """לולאה לניקוי זיכרון"""
        import time
        
        while self.is_running:
            try:
                # ניקוי שיחות ישנות
                self._cleanup_old_conversations()
                
                # ניקוי משימות ישנות
                self._cleanup_old_tasks()
                
                # ניקוי לוגים ישנים
                self._cleanup_old_logs()
                
                time.sleep(3600)  # ניקוי כל שעה
                
            except Exception as e:
                self._log_system_event("error", f"Memory cleanup error: {str(e)}")
    
    # ===== פונקציות עזר =====
    
    def _check_agents_health(self):
        """בודק בריאות הסוכנים"""
        for agent in self.agents.values():
            # בדיקת סוכנים שלא פעילים זמן רב
            if agent.status == AgentStatus.BUSY:
                time_since_active = datetime.now() - agent.last_active
                if time_since_active > timedelta(minutes=30):
                    self._log_system_event("warning", f"Agent {agent.name} stuck in busy state")
    
    def _check_active_conversations(self):
        """בודק שיחות פעילות"""
        current_time = datetime.now()
        
        for conv_id, session in list(self.conversation_sessions.items()):
            time_since_activity = current_time - session["last_activity"]
            
            # סגירת שיחות לא פעילות
            if time_since_activity > timedelta(hours=2):
                asyncio.create_task(self.end_conversation(conv_id))
    
    def _cleanup_old_conversations(self):
        """מנקה שיחות ישנות"""
        cutoff_time = datetime.now() - timedelta(days=7)
        
        old_conversations = [
            conv_id for conv_id, conv in self.conversations.items()
            if conv.last_updated < cutoff_time and not conv.is_active
        ]
        
        for conv_id in old_conversations:
            del self.conversations[conv_id]
    
    def _cleanup_old_tasks(self):
        """מנקה משימות ישנות"""
        cutoff_time = datetime.now() - timedelta(days=30)
        
        old_tasks = [
            task_id for task_id, task in self.tasks.items()
            if task.completed_at and task.completed_at < cutoff_time
        ]
        
        for task_id in old_tasks:
            del self.tasks[task_id]
    
    def _cleanup_old_logs(self):
        """מנקה לוגים ישנים"""
        if len(self.system_logs) > 1000:
            self.system_logs = self.system_logs[-500:]  # שמירה על 500 אחרונים
    
    def _update_system_metrics(self):
        """מעדכן מדדי מערכת"""
        self.performance_metrics.update({
            "active_agents": len([a for a in self.agents.values() if a.status == AgentStatus.ACTIVE]),
            "busy_agents": len([a for a in self.agents.values() if a.status == AgentStatus.BUSY]),
            "idle_agents": len([a for a in self.agents.values() if a.status == AgentStatus.IDLE]),
            "active_tasks": len(self.active_tasks),
            "queued_tasks": len(self.task_queue),
            "active_conversations": len([c for c in self.conversations.values() if c.is_active]),
            "total_teams": len(self.teams)
        })
    
    def _update_performance_metrics(self, execution_time: float):
        """מעדכן מדדי ביצועים"""
        # עדכון זמן תגובה ממוצע
        current_avg = self.performance_metrics["average_response_time"]
        total_completed = self.performance_metrics["total_tasks_completed"]
        
        if total_completed > 0:
            new_avg = ((current_avg * (total_completed - 1)) + execution_time) / total_completed
            self.performance_metrics["average_response_time"] = round(new_avg, 3)
    
    async def _emit_event(self, event_type: str, data: Dict[str, Any]):
        """שולח אירוע למאזינים"""
        if event_type in self.event_listeners:
            for listener in self.event_listeners[event_type]:
                try:
                    await listener(data)
                except Exception as e:
                    self._log_system_event("error", f"Event listener error: {str(e)}")
    
    def add_event_listener(self, event_type: str, listener: callable):
        """מוסיף מאזין לאירועים"""
        self.event_listeners[event_type].append(listener)
    
    def _log_system_event(self, event_type: str, message: str):
        """רושם אירוע מערכת"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "message": message
        }
        self.system_logs.append(log_entry)
        
        # הדפסה לקונסול במקרה של שגיאות
        if event_type == "error":
            print(f"[ERROR] {message}")
    
    # ===== API פונקציות =====
    
    def get_system_status(self) -> Dict[str, Any]:
        """מחזיר סטטוס מערכת"""
        return {
            "total_agents": len(self.agents),
            "active_agents": len([a for a in self.agents.values() if a.status == AgentStatus.ACTIVE]),
            "performance_metrics": self.performance_metrics,
            "system_health": "healthy" if self.is_running else "stopped",
            "uptime": str(datetime.now() - self.performance_metrics["system_uptime"])
        }
    
    def get_agent_list(self) -> List[Dict[str, Any]]:
        """מחזיר רשימת סוכנים"""
        return [
            {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "display_name": agent.display_name,
                "role": agent.role.value,
                "status": agent.status.value,
                "active_tasks": len(agent.active_tasks),
                "success_rate": agent.calculate_success_rate()
            }
            for agent in self.agents.values()
        ]
    
    def shutdown(self):
        """כיבוי מערכת"""
        self.is_running = False
        self.executor.shutdown(wait=True)
        self._log_system_event("system_shutdown", "Agent Manager shut down")