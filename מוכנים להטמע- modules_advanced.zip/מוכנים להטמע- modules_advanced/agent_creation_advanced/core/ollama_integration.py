"""
Ollama Integration for Agent System
חיבור מודל Hudson/Llama מקומי למערכת הסוכנים
"""

import asyncio
import aiohttp
import json
from typing import Dict, List, Any, Optional, AsyncGenerator
from datetime import datetime
import logging
from dataclasses import dataclass

@dataclass
class ChatMessage:
    """הודעת צ'אט"""
    role: str  # "system", "user", "assistant"
    content: str
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

@dataclass
class AgentModelConfig:
    """הגדרות מודל לסוכן"""
    model_name: str = "hudson/llama3.1-uncensored:8b"
    temperature: float = 0.7
    max_tokens: int = 4000
    top_p: float = 0.9
    frequency_penalty: float = 0.1
    presence_penalty: float = 0.1
    stop_sequences: List[str] = None
    system_prompt: str = ""
    
    def __post_init__(self):
        if self.stop_sequences is None:
            self.stop_sequences = []

class OllamaClient:
    """לקוח מתקדם לשירות Ollama המקומי"""
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url.rstrip('/')
        self.session = None
        self.is_connected = False
        self.available_models = []
        self.performance_stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "average_response_time": 0.0,
            "total_tokens_generated": 0
        }
    
    async def __aenter__(self):
        """כניסה לconttext manager"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """יציאה מcontext manager"""
        await self.disconnect()
    
    async def connect(self):
        """התחברות לשירות Ollama"""
        try:
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=300)  # 5 דקות timeout
            )
            
            # בדיקת חיבור
            await self.health_check()
            await self.load_available_models()
            
            self.is_connected = True
            logging.info("Connected to Ollama service successfully")
            
        except Exception as e:
            logging.error(f"Failed to connect to Ollama: {str(e)}")
            if self.session:
                await self.session.close()
            raise
    
    async def disconnect(self):
        """ניתוק מהשירות"""
        if self.session:
            await self.session.close()
        self.is_connected = False
        logging.info("Disconnected from Ollama service")
    
    async def health_check(self) -> bool:
        """בדיקת בריאות השירות"""
        try:
            async with self.session.get(f"{self.base_url}/api/version") as response:
                if response.status == 200:
                    version_info = await response.json()
                    logging.info(f"Ollama version: {version_info.get('version', 'unknown')}")
                    return True
                return False
        except Exception as e:
            logging.error(f"Health check failed: {str(e)}")
            return False
    
    async def load_available_models(self):
        """טעינת רשימת מודלים זמינים"""
        try:
            async with self.session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    self.available_models = [model['name'] for model in data.get('models', [])]
                    logging.info(f"Available models: {self.available_models}")
                else:
                    logging.warning("Failed to load available models")
        except Exception as e:
            logging.error(f"Error loading models: {str(e)}")
    
    async def ensure_model_loaded(self, model_name: str) -> bool:
        """וידוא שהמודל טעון"""
        try:
            # בדיקה אם המודל קיים
            if model_name not in self.available_models:
                logging.warning(f"Model {model_name} not found in available models")
                return False
            
            # שליחת בקשה פשוטה לוודא שהמודל טעון
            test_request = {
                "model": model_name,
                "prompt": "היי",
                "stream": False,
                "options": {
                    "num_predict": 10
                }
            }
            
            async with self.session.post(
                f"{self.base_url}/api/generate",
                json=test_request
            ) as response:
                if response.status == 200:
                    logging.info(f"Model {model_name} is loaded and ready")
                    return True
                else:
                    logging.error(f"Model {model_name} loading failed: {response.status}")
                    return False
                    
        except Exception as e:
            logging.error(f"Error ensuring model loaded: {str(e)}")
            return False
    
    async def chat_completion(
        self,
        messages: List[ChatMessage],
        config: AgentModelConfig,
        stream: bool = False
    ) -> str:
        """השלמת צ'אט עם המודל"""
        try:
            start_time = datetime.now()
            self.performance_stats["total_requests"] += 1
            
            # בניית prompt מההודעות
            prompt = self._build_prompt_from_messages(messages, config.system_prompt)
            
            # הכנת בקשה
            request_data = {
                "model": config.model_name,
                "prompt": prompt,
                "stream": stream,
                "options": {
                    "temperature": config.temperature,
                    "num_predict": config.max_tokens,
                    "top_p": config.top_p,
                    "frequency_penalty": config.frequency_penalty,
                    "presence_penalty": config.presence_penalty,
                    "stop": config.stop_sequences
                }
            }
            
            if stream:
                return await self._handle_streaming_response(request_data)
            else:
                return await self._handle_regular_response(request_data, start_time)
                
        except Exception as e:
            self.performance_stats["failed_requests"] += 1
            logging.error(f"Chat completion error: {str(e)}")
            raise
    
    async def _handle_regular_response(self, request_data: Dict, start_time: datetime) -> str:
        """טיפול בתגובה רגילה"""
        async with self.session.post(
            f"{self.base_url}/api/generate",
            json=request_data
        ) as response:
            if response.status == 200:
                data = await response.json()
                
                # עדכון סטטיסטיקות
                response_time = (datetime.now() - start_time).total_seconds()
                self._update_performance_stats(response_time, True, data.get('response', ''))
                
                return data.get('response', '')
            else:
                error_text = await response.text()
                raise Exception(f"API Error {response.status}: {error_text}")
    
    async def _handle_streaming_response(self, request_data: Dict) -> AsyncGenerator[str, None]:
        """טיפול בתגובה מזרמת"""
        async with self.session.post(
            f"{self.base_url}/api/generate",
            json=request_data
        ) as response:
            if response.status == 200:
                async for line in response.content:
                    if line:
                        try:
                            data = json.loads(line.decode('utf-8'))
                            if 'response' in data:
                                yield data['response']
                        except json.JSONDecodeError:
                            continue
            else:
                error_text = await response.text()
                raise Exception(f"Streaming API Error {response.status}: {error_text}")
    
    def _build_prompt_from_messages(self, messages: List[ChatMessage], system_prompt: str) -> str:
        """בניית prompt מרשימת הודעות"""
        prompt_parts = []
        
        # הוספת system prompt
        if system_prompt:
            prompt_parts.append(f"System: {system_prompt}")
        
        # הוספת הודעות
        for message in messages:
            role_hebrew = {
                "user": "משתמש",
                "assistant": "עוזר",
                "system": "מערכת"
            }.get(message.role, message.role)
            
            prompt_parts.append(f"{role_hebrew}: {message.content}")
        
        # הוספת prompt לתגובה
        prompt_parts.append("עוזר:")
        
        return "\n\n".join(prompt_parts)
    
    def _update_performance_stats(self, response_time: float, success: bool, response_text: str):
        """עדכון סטטיסטיקות ביצועים"""
        if success:
            self.performance_stats["successful_requests"] += 1
            
            # עדכון זמן תגובה ממוצע
            total_successful = self.performance_stats["successful_requests"]
            current_avg = self.performance_stats["average_response_time"]
            new_avg = ((current_avg * (total_successful - 1)) + response_time) / total_successful
            self.performance_stats["average_response_time"] = round(new_avg, 3)
            
            # ספירת טוקנים משוערת
            estimated_tokens = len(response_text.split())
            self.performance_stats["total_tokens_generated"] += estimated_tokens
        else:
            self.performance_stats["failed_requests"] += 1
    
    async def get_model_info(self, model_name: str) -> Optional[Dict[str, Any]]:
        """קבלת מידע על מודל"""
        try:
            async with self.session.post(
                f"{self.base_url}/api/show",
                json={"name": model_name}
            ) as response:
                if response.status == 200:
                    return await response.json()
                return None
        except Exception as e:
            logging.error(f"Error getting model info: {str(e)}")
            return None
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות ביצועים"""
        return self.performance_stats.copy()

class AgentOllamaInterface:
    """ממשק בין סוכנים למודל Ollama"""
    
    def __init__(self, ollama_client: OllamaClient):
        self.ollama_client = ollama_client
        self.agent_sessions: Dict[str, List[ChatMessage]] = {}
        self.agent_configs: Dict[str, AgentModelConfig] = {}
    
    async def initialize_agent(self, agent_id: str, config: AgentModelConfig):
        """אתחול סוכן עם הגדרות מודל"""
        self.agent_configs[agent_id] = config
        self.agent_sessions[agent_id] = []
        
        # בדיקה שהמודל זמין
        await self.ollama_client.ensure_model_loaded(config.model_name)
        
        # הוספת הודעת מערכת
        if config.system_prompt:
            system_message = ChatMessage("system", config.system_prompt)
            self.agent_sessions[agent_id].append(system_message)
    
    async def send_message_to_agent(
        self,
        agent_id: str,
        user_message: str,
        context: Dict[str, Any] = None
    ) -> str:
        """שליחת הודעה לסוכן וקבלת תגובה"""
        if agent_id not in self.agent_configs:
            raise ValueError(f"Agent {agent_id} not initialized")
        
        config = self.agent_configs[agent_id]
        session = self.agent_sessions[agent_id]
        
        # הוספת הודעת משתמש
        user_msg = ChatMessage("user", user_message)
        session.append(user_msg)
        
        # שמירה על גודל session (50 הודעות אחרונות)
        if len(session) > 50:
            # שמירה על הודעת המערכת הראשונה
            system_msg = session[0] if session[0].role == "system" else None
            session = session[-49:]  # 49 הודעות אחרונות
            if system_msg:
                session.insert(0, system_msg)
            self.agent_sessions[agent_id] = session
        
        # קבלת תגובה מהמודל
        try:
            response = await self.ollama_client.chat_completion(session, config)
            
            # הוספת תגובת הסוכן לsession
            agent_msg = ChatMessage("assistant", response)
            session.append(agent_msg)
            
            return response
            
        except Exception as e:
            logging.error(f"Error getting response for agent {agent_id}: {str(e)}")
            return f"מצטער, אירעה שגיאה בעת עיבוד הבקשה: {str(e)}"
    
    async def send_streaming_message(
        self,
        agent_id: str,
        user_message: str
    ) -> AsyncGenerator[str, None]:
        """שליחת הודעה עם תגובה מזרמת"""
        if agent_id not in self.agent_configs:
            raise ValueError(f"Agent {agent_id} not initialized")
        
        config = self.agent_configs[agent_id]
        session = self.agent_sessions[agent_id]
        
        # הוספת הודעת משתמש
        user_msg = ChatMessage("user", user_message)
        session.append(user_msg)
        
        full_response = ""
        
        try:
            async for chunk in self.ollama_client._handle_streaming_response({
                "model": config.model_name,
                "prompt": self.ollama_client._build_prompt_from_messages(session, config.system_prompt),
                "stream": True,
                "options": {
                    "temperature": config.temperature,
                    "num_predict": config.max_tokens,
                    "top_p": config.top_p
                }
            }):
                full_response += chunk
                yield chunk
            
            # שמירת התגובה המלאה
            agent_msg = ChatMessage("assistant", full_response)
            session.append(agent_msg)
            
        except Exception as e:
            logging.error(f"Streaming error for agent {agent_id}: {str(e)}")
            yield f"שגיאה: {str(e)}"
    
    def get_agent_conversation_history(self, agent_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        """קבלת היסטוריית שיחה של סוכן"""
        if agent_id not in self.agent_sessions:
            return []
        
        session = self.agent_sessions[agent_id]
        recent_messages = session[-limit:] if len(session) > limit else session
        
        return [
            {
                "role": msg.role,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat()
            }
            for msg in recent_messages
        ]
    
    def clear_agent_session(self, agent_id: str, keep_system: bool = True):
        """ניקוי session של סוכן"""
        if agent_id in self.agent_sessions:
            session = self.agent_sessions[agent_id]
            
            if keep_system and session and session[0].role == "system":
                # שמירה על הודעת המערכת
                self.agent_sessions[agent_id] = [session[0]]
            else:
                self.agent_sessions[agent_id] = []
    
    def update_agent_config(self, agent_id: str, new_config: AgentModelConfig):
        """עדכון הגדרות סוכן"""
        self.agent_configs[agent_id] = new_config
        
        # עדכון הודעת מערכת אם השתנתה
        if agent_id in self.agent_sessions:
            session = self.agent_sessions[agent_id]
            if session and session[0].role == "system":
                session[0].content = new_config.system_prompt
            elif new_config.system_prompt:
                # הוספת הודעת מערכת חדשה
                system_msg = ChatMessage("system", new_config.system_prompt)
                session.insert(0, system_msg)
    
    def get_agent_stats(self, agent_id: str) -> Dict[str, Any]:
        """קבלת סטטיסטיקות סוכן"""
        if agent_id not in self.agent_sessions:
            return {}
        
        session = self.agent_sessions[agent_id]
        
        user_messages = [msg for msg in session if msg.role == "user"]
        assistant_messages = [msg for msg in session if msg.role == "assistant"]
        
        return {
            "total_messages": len(session),
            "user_messages": len(user_messages),
            "assistant_messages": len(assistant_messages),
            "session_start": session[0].timestamp.isoformat() if session else None,
            "last_activity": session[-1].timestamp.isoformat() if session else None,
            "average_response_length": sum(len(msg.content) for msg in assistant_messages) / len(assistant_messages) if assistant_messages else 0
        }

class OllamaModelManager:
    """מנהל מודלים של Ollama"""
    
    def __init__(self, ollama_client: OllamaClient):
        self.ollama_client = ollama_client
        self.model_configs = {}
    
    async def get_available_models(self) -> List[str]:
        """קבלת רשימת מודלים זמינים"""
        return self.ollama_client.available_models
    
    async def download_model(self, model_name: str) -> bool:
        """הורדת מודל חדש"""
        try:
            async with self.ollama_client.session.post(
                f"{self.ollama_client.base_url}/api/pull",
                json={"name": model_name}
            ) as response:
                if response.status == 200:
                    # עדכון רשימת המודלים
                    await self.ollama_client.load_available_models()
                    return True
                return False
        except Exception as e:
            logging.error(f"Error downloading model {model_name}: {str(e)}")
            return False
    
    async def delete_model(self, model_name: str) -> bool:
        """מחיקת מודל"""
        try:
            async with self.ollama_client.session.delete(
                f"{self.ollama_client.base_url}/api/delete",
                json={"name": model_name}
            ) as response:
                if response.status == 200:
                    # עדכון רשימת המודלים
                    await self.ollama_client.load_available_models()
                    return True
                return False
        except Exception as e:
            logging.error(f"Error deleting model {model_name}: {str(e)}")
            return False
    
    def create_agent_config(
        self,
        agent_role: str,
        personality: str,
        specialization: str = None
    ) -> AgentModelConfig:
        """יצירת הגדרות מותאמות לסוכן"""
        
        # הגדרות בסיסיות לפי תפקיד
        base_configs = {
            "assistant": {
                "temperature": 0.7,
                "system_prompt": f"אתה עוזר אישי ידידותי ומועיל. תמיד תענה בעברית בצורה חמה ומקצועית."
            },
            "developer": {
                "temperature": 0.3,
                "system_prompt": f"אתה מפתח תוכנה מקצועי. תכתוב קוד נקי ויעיל ותסביר אותו בפירוט."
            },
            "researcher": {
                "temperature": 0.4,
                "system_prompt": f"אתה חוקר מקצועי. תמיד תספק מידע מדויק ומבוסס ותציין מקורות."
            },
            "creative": {
                "temperature": 0.8,
                "system_prompt": f"אתה יוצר יצירתי. תביא רעיונות מקוריים ומעוררי השראה."
            }
        }
        
        config_template = base_configs.get(agent_role, base_configs["assistant"])
        
        # התאמה אישית
        system_prompt = config_template["system_prompt"]
        if specialization:
            system_prompt += f" התמחותך היא ב{specialization}."
        
        return AgentModelConfig(
            model_name="hudson/llama3.1-uncensored:8b",
            temperature=config_template["temperature"],
            system_prompt=system_prompt,
            max_tokens=4000
        )

# פונקציות עזר

def create_default_ollama_client() -> OllamaClient:
    """יצירת לקוח Ollama ברירת מחדל"""
    return OllamaClient("http://localhost:11434")

async def test_ollama_connection() -> bool:
    """בדיקת חיבור לOllama"""
    try:
        async with create_default_ollama_client() as client:
            return await client.health_check()
    except:
        return False

async def ensure_hudson_model_ready() -> bool:
    """וידוא שמודל Hudson מוכן לשימוש"""
    try:
        async with create_default_ollama_client() as client:
            return await client.ensure_model_loaded("hudson/llama3.1-uncensored:8b")
    except:
        return False