"""
Main Performance Engine
מנוע ביצועים ואופטימיזציה ראשי
"""

import sqlite3
from typing import List, Dict, Optional, Any, Tuple
from datetime import datetime, timedelta
import logging
import uuid
import threading
import time

from ..models.performance_types import PerformanceMetric, PerformanceTarget, PerformanceSnapshot, PerformanceReport
from ..models.optimization_types import OptimizationTask, OptimizationResult
from ..models.bottlenecks import Bottleneck
from ..models.config import PerformanceEngineConfig

from .metrics_collector import MetricsCollector
from .bottleneck_detector import BottleneckDetector
from .optimizer import Optimizer
from .benchmark_runner import BenchmarkRunner

class PerformanceEngine:
    """מנוע ביצועים ואופטימיזציה ראשי"""
    
    def __init__(self, config: PerformanceEngineConfig = None):
        self.config = config or PerformanceEngineConfig()
        self.logger = self._setup_logger()
        self.db_connection = self._init_database()
        
        # מנועי המשנה
        self.metrics_collector = MetricsCollector(self.config)
        self.bottleneck_detector = BottleneckDetector(self.config)
        self.optimizer = Optimizer(self.config)
        self.benchmark_runner = BenchmarkRunner(self.config)
        
        # רישום מדדים פעילים
        self.active_metrics: Dict[str, PerformanceMetric] = {}
        self.performance_targets: Dict[str, PerformanceTarget] = {}
        
        # מטמון נתונים
        self.metrics_cache: Dict[str, List[Tuple[datetime, float]]] = {}
        self.snapshots_cache: List[PerformanceSnapshot] = []
        
        # חוט איסוף נתונים
        self.collection_thread = None
        self.is_collecting = False
        
        self.logger.info("מנוע ביצועים ואופטימיזציה הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים"""
        logger = logging.getLogger("PerformanceEngine")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _init_database(self) -> sqlite3.Connection:
        """אתחול מסד נתונים"""
        conn = sqlite3.connect(self.config.database_path)
        cursor = conn.cursor()
        
        # טבלת מדדי ביצועים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                category TEXT,
                metric_type TEXT,
                unit TEXT,
                current_value REAL,
                baseline_value REAL,
                last_updated TIMESTAMP,
                is_active BOOLEAN,
                metadata TEXT
            )
        ''')
        
        # טבלת היסטוריית מדדים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS metrics_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_id TEXT,
                timestamp TIMESTAMP,
                value REAL,
                snapshot_id TEXT,
                FOREIGN KEY (metric_id) REFERENCES performance_metrics (id)
            )
        ''')
        
        # טבלת יעדי ביצועים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_targets (
                target_id TEXT PRIMARY KEY,
                metric_id TEXT,
                target_value REAL,
                target_date TIMESTAMP,
                baseline_value REAL,
                current_progress REAL,
                is_achieved BOOLEAN,
                priority INTEGER,
                owner TEXT,
                FOREIGN KEY (metric_id) REFERENCES performance_metrics (id)
            )
        ''')
        
        # טבלת צמצמי ביצועים
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bottlenecks (
                bottleneck_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                hebrew_name TEXT NOT NULL,
                bottleneck_type TEXT,
                severity TEXT,
                detected_at TIMESTAMP,
                resolved_at TIMESTAMP,
                impact_score REAL,
                description TEXT,
                recommended_actions TEXT
            )
        ''')
        
        # טבלת משימות אופטימיזציה
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimization_tasks (
                task_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                optimization_type TEXT,
                status TEXT,
                created_at TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                expected_improvement REAL,
                actual_improvement REAL,
                configuration TEXT
            )
        ''')
        
        conn.commit()
        return conn
    
    def register_metric(self, metric: PerformanceMetric) -> bool:
        """רושם מדד ביצועים"""
        try:
            # שמירה לזיכרון
            self.active_metrics[metric.id] = metric
            
            # אתחול מטמון
            if metric.id not in self.metrics_cache:
                self.metrics_cache[metric.id] = []
            
            # שמירה למסד נתונים
            cursor = self.db_connection.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO performance_metrics
                (id, name, hebrew_name, category, metric_type, unit, 
                 current_value, baseline_value, last_updated, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                metric.id, metric.name, metric.hebrew_name,
                metric.category.value, metric.metric_type.value, metric.unit.value,
                metric.current_value, metric.baseline_value, 
                metric.last_updated, metric.is_active
            ))
            self.db_connection.commit()
            
            self.logger.info(f"מדד ביצועים נרשם: {metric.hebrew_name} (ID: {metric.id})")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה ברישום מדד ביצועים: {e}")
            return False
    
    def set_performance_target(self, target: PerformanceTarget) -> bool:
        """קובע יעד ביצועים"""
        try:
            # בדיקת קיום המדד
            if target.metric_id not in self.active_metrics:
                self.logger.error(f"מדד לא נמצא: {target.metric_id}")
                return False
            
            # שמירה לזיכרון
            self.performance_targets[target.target_id] = target
            
            # שמירה למסד נתונים
            cursor = self.db_connection.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO performance_targets
                (target_id, metric_id, target_value, target_date, 
                 baseline_value, current_progress, is_achieved, priority, owner)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                target.target_id, target.metric_id, target.target_value,
                target.target_date, target.baseline_value, target.current_progress,
                target.is_achieved, target.priority, target.owner
            ))
            self.db_connection.commit()
            
            self.logger.info(f"יעד ביצועים נקבע: {target.hebrew_description}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בקביעת יעד ביצועים: {e}")
            return False
    
    def start_monitoring(self):
        """מתחיל ניטור ביצועים"""
        if self.is_collecting:
            self.logger.warning("ניטור כבר פועל")
            return
        
        self.is_collecting = True
        self.collection_thread = threading.Thread(target=self._monitoring_loop)
        self.collection_thread.daemon = True
        self.collection_thread.start()
        
        self.logger.info("ניטור ביצועים התחיל")
    
    def stop_monitoring(self):
        """עוצר ניטור ביצועים"""
        self.is_collecting = False
        if self.collection_thread:
            self.collection_thread.join(timeout=5)
        
        self.logger.info("ניטור ביצועים נעצר")
    
    def _monitoring_loop(self):
        """לולאת ניטור רציפה"""
        while self.is_collecting:
            try:
                # איסוף מדדים
                current_metrics = self.metrics_collector.collect_all_metrics(
                    list(self.active_metrics.values())
                )
                
                # עדכון מדדים
                for metric_id, value in current_metrics.items():
                    if metric_id in self.active_metrics:
                        self._update_metric_value(metric_id, value)
                
                # יצירת צילום מצב
                if self.config.enable_snapshots:
                    snapshot = self._create_performance_snapshot(current_metrics)
                    self._save_snapshot(snapshot)
                
                # זיהוי צמצמים
                if self.config.enable_bottleneck_detection:
                    bottlenecks = self.bottleneck_detector.detect_bottlenecks(
                        current_metrics, self.active_metrics
                    )
                    for bottleneck in bottlenecks:
                        self._handle_bottleneck(bottleneck)
                
                # עדכון יעדים
                self._update_targets_progress(current_metrics)
                
                # אופטימיזציה אוטומטית
                if self.config.enable_auto_optimization:
                    self._check_auto_optimization_triggers(current_metrics)
                
                time.sleep(self.config.collection_interval)
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת ניטור: {e}")
                time.sleep(self.config.collection_interval)
    
    def _update_metric_value(self, metric_id: str, new_value: float):
        """עדכון ערך מדד"""
        metric = self.active_metrics.get(metric_id)
        if not metric:
            return
        
        timestamp = datetime.now()
        metric.update_value(new_value, timestamp)
        
        # שמירת היסטוריה
        self.metrics_cache[metric_id].append((timestamp, new_value))
        
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            INSERT INTO metrics_history (metric_id, timestamp, value)
            VALUES (?, ?, ?)
        ''', (metric_id, timestamp, new_value))
        
        # עדכון מדד במסד נתונים
        cursor.execute('''
            UPDATE performance_metrics 
            SET current_value = ?, last_updated = ?
            WHERE id = ?
        ''', (new_value, timestamp, metric_id))
        
        self.db_connection.commit()
        
        # ניקוי מטמון ישן
        cutoff_time = timestamp - timedelta(hours=self.config.cache_retention_hours)
        self.metrics_cache[metric_id] = [
            (ts, val) for ts, val in self.metrics_cache[metric_id]
            if ts > cutoff_time
        ]
    
    def _create_performance_snapshot(self, current_metrics: Dict[str, float]) -> PerformanceSnapshot:
        """יוצר צילום מצב ביצועים"""
        snapshot = PerformanceSnapshot(
            snapshot_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            metrics=current_metrics.copy(),
            system_info=self.metrics_collector.get_system_info(),
            environment=self.config.environment
        )
        
        return snapshot
    
    def _save_snapshot(self, snapshot: PerformanceSnapshot):
        """שומר צילום מצב"""
        self.snapshots_cache.append(snapshot)
        
        # ניקוי צילומי מצב ישנים
        cutoff_time = datetime.now() - timedelta(hours=self.config.snapshot_retention_hours)
        self.snapshots_cache = [
            s for s in self.snapshots_cache 
            if s.timestamp > cutoff_time
        ]
    
    def _handle_bottleneck(self, bottleneck: Bottleneck):
        """מטפל בצוואר בקבוק שזוהה"""
        # שמירה למסד נתונים
        cursor = self.db_connection.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO bottlenecks
            (bottleneck_id, name, hebrew_name, bottleneck_type, severity,
             detected_at, impact_score, description, recommended_actions)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            bottleneck.bottleneck_id, bottleneck.name, bottleneck.hebrew_name,
            bottleneck.bottleneck_type.value, bottleneck.severity.value,
            bottleneck.detected_at, bottleneck.impact_score,
            bottleneck.description, '\n'.join(bottleneck.recommended_actions)
        ))
        self.db_connection.commit()
        
        self.logger.warning(f"זוהה צוואר בקבוק: {bottleneck.hebrew_name}")
        
        # הפעלת אופטימיזציה אוטומטית אם מוגדרת
        if (self.config.enable_auto_optimization and 
            bottleneck.severity.value >= self.config.auto_optimization_threshold):
            self._trigger_auto_optimization(bottleneck)
    
    def _update_targets_progress(self, current_metrics: Dict[str, float]):
        """עדכון התקדמות יעדים"""
        for target in self.performance_targets.values():
            if target.metric_id in current_metrics:
                current_value = current_metrics[target.metric_id]
                target.update_progress(current_value)
                
                # עדכון במסד נתונים
                cursor = self.db_connection.cursor()
                cursor.execute('''
                    UPDATE performance_targets
                    SET current_progress = ?, is_achieved = ?
                    WHERE target_id = ?
                ''', (target.current_progress, target.is_achieved, target.target_id))
                self.db_connection.commit()
    
    def run_optimization(self, 
                        optimization_type: str,
                        target_metrics: List[str] = None,
                        parameters: Dict[str, Any] = None) -> str:
        """מריץ אופטימיזציה"""
        
        task_id = str(uuid.uuid4())
        
        try:
            # יצירת משימת אופטימיזציה
            optimization_task = OptimizationTask(
                task_id=task_id,
                name=f"Optimization - {optimization_type}",
                hebrew_name=f"אופטימיזציה - {optimization_type}",
                optimization_type=optimization_type,
                target_metrics=target_metrics or [],
                parameters=parameters or {},
                created_at=datetime.now()
            )
            
            # שמירה למסד נתונים
            cursor = self.db_connection.cursor()
            cursor.execute('''
                INSERT INTO optimization_tasks
                (task_id, name, optimization_type, status, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                task_id, optimization_task.name, optimization_type,
                "pending", optimization_task.created_at
            ))
            self.db_connection.commit()
            
            # הרצת האופטימיזציה
            result = self.optimizer.optimize(optimization_task, self.active_metrics)
            
            # עדכון תוצאה
            cursor.execute('''
                UPDATE optimization_tasks
                SET status = ?, completed_at = ?, actual_improvement = ?
                WHERE task_id = ?
            ''', (
                "completed", datetime.now(), 
                result.actual_improvement, task_id
            ))
            self.db_connection.commit()
            
            self.logger.info(f"אופטימיזציה הושלמה: {optimization_type}")
            return task_id
            
        except Exception as e:
            # עדכון כישלון
            cursor = self.db_connection.cursor()
            cursor.execute('''
                UPDATE optimization_tasks
                SET status = ?, completed_at = ?
                WHERE task_id = ?
            ''', ("failed", datetime.now(), task_id))
            self.db_connection.commit()
            
            self.logger.error(f"שגיאה באופטימיזציה: {e}")
            return task_id
    
    def run_benchmark(self, 
                     benchmark_name: str,
                     configuration: Dict[str, Any] = None) -> Dict[str, Any]:
        """מריץ בנצ'מרק"""
        
        self.logger.info(f"מריץ בנצ'מרק: {benchmark_name}")
        
        # קבלת מצב בסיס
        baseline_metrics = {
            metric_id: metric.current_value 
            for metric_id, metric in self.active_metrics.items()
            if metric.current_value is not None
        }
        
        # הרצת בנצ'מרק
        benchmark_result = self.benchmark_runner.run_benchmark(
            benchmark_name, configuration or {}, self.active_metrics
        )
        
        # השוואה עם בסיס
        comparison = {
            'benchmark_name': benchmark_name,
            'baseline_metrics': baseline_metrics,
            'benchmark_metrics': benchmark_result.get('metrics', {}),
            'performance_comparison': self._compare_metrics(
                baseline_metrics, 
                benchmark_result.get('metrics', {})
            ),
            'timestamp': datetime.now()
        }
        
        return comparison
    
    def generate_performance_report(self, 
                                  period_start: datetime,
                                  period_end: datetime = None) -> PerformanceReport:
        """מייצר דוח ביצועים"""
        
        if period_end is None:
            period_end = datetime.now()
        
        # איסוף נתוני התקופה
        metrics_summary = self._analyze_period_metrics(period_start, period_end)
        targets_status = self._analyze_targets_status()
        
        # יצירת תובנות והמלצות
        insights = self._generate_insights(metrics_summary, targets_status)
        recommendations = self._generate_recommendations(metrics_summary, targets_status)
        
        report = PerformanceReport(
            report_id=str(uuid.uuid4()),
            title=f"Performance Report {period_start.strftime('%d/%m/%Y')} - {period_end.strftime('%d/%m/%Y')}",
            hebrew_title=f"דוח ביצועים {period_start.strftime('%d/%m/%Y')} - {period_end.strftime('%d/%m/%Y')}",
            period_start=period_start,
            period_end=period_end,
            metrics_summary=metrics_summary,
            targets_status=targets_status,
            key_insights=insights['english'],
            hebrew_insights=insights['hebrew'],
            recommendations=recommendations['english'],
            hebrew_recommendations=recommendations['hebrew'],
            generated_at=datetime.now()
        )
        
        return report
    
    def get_real_time_status(self) -> Dict[str, Any]:
        """מחזיר סטטוס ביצועים בזמן אמת"""
        current_status = {
            'timestamp': datetime.now(),
            'metrics': {},
            'overall_health': 'unknown',
            'active_bottlenecks': 0,
            'targets_on_track': 0,
            'targets_total': len(self.performance_targets)
        }
        
        excellent_count = 0
        total_metrics = 0
        
        for metric_id, metric in self.active_metrics.items():
            if metric.current_value is not None:
                status = metric.get_status()
                trend = metric.get_trend()
                
                current_status['metrics'][metric_id] = {
                    'name': metric.hebrew_name,
                    'value': metric.current_value,
                    'unit': metric.unit.value,
                    'status': status.value,
                    'trend': trend
                }
                
                if status.value == 'excellent':
                    excellent_count += 1
                total_metrics += 1
        
        # חישוב בריאות כללית
        if total_metrics > 0:
            health_ratio = excellent_count / total_metrics
            if health_ratio >= 0.8:
                current_status['overall_health'] = 'excellent'
            elif health_ratio >= 0.6:
                current_status['overall_health'] = 'good'
            elif health_ratio >= 0.4:
                current_status['overall_health'] = 'acceptable'
            else:
                current_status['overall_health'] = 'poor'
        
        # ספירת יעדים במסלול
        targets_on_track = sum(1 for target in self.performance_targets.values() if target.is_on_track())
        current_status['targets_on_track'] = targets_on_track
        
        return current_status
    
    # Helper methods
    def _compare_metrics(self, baseline: Dict[str, float], 
                        benchmark: Dict[str, float]) -> Dict[str, Dict]:
        """משווה מדדים"""
        comparison = {}
        
        for metric_id in set(baseline.keys()) | set(benchmark.keys()):
            baseline_val = baseline.get(metric_id, 0)
            benchmark_val = benchmark.get(metric_id, 0)
            
            if baseline_val != 0:
                improvement = ((benchmark_val - baseline_val) / baseline_val) * 100
            else:
                improvement = 0
            
            comparison[metric_id] = {
                'baseline': baseline_val,
                'benchmark': benchmark_val,
                'improvement_percentage': improvement,
                'better': improvement > 0
            }
        
        return comparison
    
    def _analyze_period_metrics(self, start: datetime, end: datetime) -> Dict[str, Any]:
        """מנתח מדדים לתקופה"""
        # כאן נממש ניתוח מפורט של המדדים לתקופה
        return {}
    
    def _analyze_targets_status(self) -> Dict[str, Any]:
        """מנתח סטטוס יעדים"""
        return {}
    
    def _generate_insights(self, metrics: Dict, targets: Dict) -> Dict[str, List[str]]:
        """מייצר תובנות"""
        return {'english': [], 'hebrew': []}
    
    def _generate_recommendations(self, metrics: Dict, targets: Dict) -> Dict[str, List[str]]:
        """מייצר המלצות"""
        return {'english': [], 'hebrew': []}
    
    def _check_auto_optimization_triggers(self, metrics: Dict[str, float]):
        """בודק הפעלת אופטימיזציה אוטומטית"""
        pass
    
    def _trigger_auto_optimization(self, bottleneck: Bottleneck):
        """מפעיל אופטימיזציה אוטומטית"""
        pass
    
    def close(self):
        """סגירת המנוע"""
        self.stop_monitoring()
        if self.db_connection:
            self.db_connection.close()
        self.logger.info("מנוע ביצועים ואופטימיזציה נסגר")