# Performance Engine - מנוע ביצועים ואופטימיזציה

## תיאור כללי
מנוע ביצועים ואופטימיזציה מתקדם המיועד לניטור, מדידה ושיפור ביצועי מערכות. המנוע מספק יכולות ניטור בזמן אמת, זיהוי צמצמים, ואופטימיזציה אוטומטית.

## ארכיטקטורה

### Models (מודלים)
- **performance_types.py** - סוגי ביצועים ומדדים
- **optimization_types.py** - סוגי אופטימיזציה ושיטות
- **bottlenecks.py** - צמצמי ביצועים ורמות חומרה
- **improvements.py** - שיפורים ועדיפויות
- **benchmarks.py** - בנצ'מרקים והשוואות
- **config.py** - הגדרות מנוע ביצועים

### Core (ליבה)
- **performance_engine.py** - מנוע ביצועים ראשי
- **metrics_collector.py** - אוסף מדדים
- **bottleneck_detector.py** - מזהה צמצמים
- **optimizer.py** - מנוע אופטימיזציה
- **benchmark_runner.py** - מריץ בנצ'מרקים

### UI (ממשק משתמש)
- **performance_dashboard.py** - דשבורד ביצועים
- **metrics_monitor.py** - מוניטור מדדים
- **optimization_panel.py** - פאנל אופטימיזציה
- **benchmark_viewer.py** - מציג בנצ'מרקים
- **alerts_manager.py** - מנהל התראות

### Utils (עזרים)
- **performance_utils.py** - עזרים לביצועים
- **optimization_utils.py** - עזרים לאופטימיזציה
- **monitoring_utils.py** - עזרים לניטור
- **benchmark_utils.py** - עזרים לבנצ'מרקים
- **hebrew_utils.py** - עזרים לעברית

## תכונות עיקריות

### 📊 קטגוריות ביצועים
- **מהירות** - זמני תגובה וביצוע
- **יעילות** - ניצול משאבים
- **תפוקה** - נפח עיבוד לזמן
- **זמן תגובה** - latency ו-response time
- **צריכת משאבים** - CPU, זיכרון, דיסק, רשת
- **מדרגיות** - יכולת התרחבות
- **אמינות** - יציבות ועמידות
- **זמינות** - uptime ו-availability

### 🔍 ניטור בזמן אמת
- איסוף מדדים אוטומטי
- התראות והודעות
- דשבורדים חיים
- מעקב מגמות
- זיהוי חריגים מיידי
- ניתוח השפעות

### 🚀 אופטימיזציה אוטומטית
- זיהוי צמצמי ביצועים
- הצעות שיפור ממוקדות
- אופטימיזציה מבוססת AI
- בדיקת השפעות שיפורים
- חזרה לאחור אוטומטית
- למידה ושיפור מתמיד

### 📈 בנצ'מרקים ובדיקות
- בנצ'מרקים סטנדרטיים
- השוואות ביצועים
- בדיקות עומס
- סימולציות תרחישים
- מדידת קיבולת מקסימלית
- ניתוח נקודות כשל

## דוגמת שימוש

```python
from performance_engine.core import PerformanceEngine
from performance_engine.models import PerformanceMetricLibrary, PerformanceTarget

# יצירת מנוע ביצועים
engine = PerformanceEngine()

# רישום מדדי ביצועים
system_metrics = PerformanceMetricLibrary.get_system_metrics()
for metric in system_metrics:
    engine.register_metric(metric)

# קביעת יעדי ביצועים
cpu_target = PerformanceTarget(
    target_id="cpu_target",
    metric_id="cpu_usage",
    target_value=60.0,  # מטרה: מתחת ל-60% CPU
    target_date=datetime.now() + timedelta(days=30),
    description="Keep CPU usage below 60%",
    hebrew_description="שמירה על צריכת CPU מתחת ל-60%"
)

engine.set_performance_target(cpu_target)

# התחלת ניטור
engine.start_monitoring()

# קבלת סטטוס נוכחי
status = engine.get_real_time_status()
print(f"בריאות מערכת: {status['overall_health']}")
print(f"יעדים במסלול: {status['targets_on_track']}/{status['targets_total']}")

# הרצת אופטימיזציה
optimization_task = engine.run_optimization(
    optimization_type="cpu_optimization",
    target_metrics=["cpu_usage", "memory_usage"]
)

# הרצת בנצ'מרק
benchmark_results = engine.run_benchmark(
    benchmark_name="stress_test",
    configuration={"duration": 300, "concurrent_users": 100}
)
```

## מדדי ביצועים מובנים

### מדדי מערכת
- **צריכת CPU** - אחוז ניצול מעבד
- **צריכת זיכרון** - אחוז ניצול זיכרון
- **צריכת דיסק** - I/O ואחוסת שטח
- **צריכת רשת** - תעבורה ורוחב פס
- **טמפרטורה** - טמפרטורת רכיבים

### מדדי אפליקציה
- **זמן תגובה** - response time ממוצע
- **תפוקה** - requests per second
- **שיעור שגיאות** - error rate
- **זמינות** - uptime percentage
- **זמן שאילתות** - database query time

### מדדים עסקיים
- **שביעות רצון משתמשים** - user satisfaction
- **עלות לעסקה** - cost per transaction
- **זמן השלמת תהליכים** - process completion time

## סוגי אופטימיזציה

### אופטימיזציית משאבים
- הקצאת זיכרון דינמית
- איזון עומסים
- מטמון חכם
- דחיסת נתונים
- ניקוי זיכרון אוטומטי

### אופטימיזציית ביצועים
- אופטימיזציית שאילתות
- אינדקסים דינמיים
- connection pooling
- אופטימיזציית אלגוריתמים
- מקביליות ואסינכרוניות

### אופטימיזציית רשת
- דחיסת תוכן
- CDN ומטמון קצה
- אופטימיזציית פרוטוקולים
- איזון עומסים גיאוגרפי

## זיהוי צמצמים

המנוע מזהה צמצמים מסוגים:
- **CPU Bound** - צמצם במעבד
- **Memory Bound** - צמצם בזיכרון
- **I/O Bound** - צמצם בקלט/פלט
- **Network Bound** - צמצם ברשת
- **Database Bound** - צמצם במסד נתונים
- **Application Logic** - צמצם בלוגיקה

## התראות ורמות חומרה

### רמות חומרה
- **מידע** - הודעות אינפורמטיביות
- **אזהרה** - מצבים הדורשים תשומת לב
- **שגיאה** - בעיות הדורשות פעולה
- **קריטי** - מצבים חירום

### ערוצי התראות
- אימייל
- SMS
- Slack/Teams
- Push notifications
- לוגים מובנים

## קבצי הגדרה

### performance_engine_config.json
```json
{
    "collection_interval": 30,
    "enable_auto_optimization": true,
    "auto_optimization_threshold": 4,
    "enable_bottleneck_detection": true,
    "enable_snapshots": true,
    "snapshot_retention_hours": 168,
    "cache_retention_hours": 24,
    "environment": "production",
    "log_level": "INFO"
}
```

## API Reference

### PerformanceEngine

#### register_metric(metric)
רושם מדד ביצועים חדש

#### set_performance_target(target)
קובע יעד ביצועים

#### start_monitoring()
מתחיל ניטור בזמן אמת

#### run_optimization(type, metrics, parameters)
מריץ תהליך אופטימיזציה

#### run_benchmark(name, configuration)
מריץ בנצ'מרק ביצועים

#### get_real_time_status()
מחזיר סטטוס ביצועים נוכחי

#### generate_performance_report(period_start, period_end)
מייצר דוח ביצועים לתקופה

## בנצ'מרקים מובנים

### בדיקות עומס
- **Stress Test** - בדיקת עומס קיצוני
- **Load Test** - בדיקת עומס רגיל
- **Spike Test** - בדיקת עומס פתאומי
- **Volume Test** - בדיקת נפח נתונים
- **Endurance Test** - בדיקת סיבולת

### בנצ'מרקים ספציפיים
- **CPU Benchmark** - בדיקת ביצועי CPU
- **Memory Benchmark** - בדיקת ביצועי זיכרון
- **Disk I/O Benchmark** - בדיקת ביצועי דיסק
- **Network Benchmark** - בדיקת ביצועי רשת
- **Database Benchmark** - בדיקת ביצועי מסד נתונים

## דוחות וויזואליזציות

### דוחות זמינים
- דוח ביצועים תקופתי
- דוח צמצמים ופתרונות
- דוח התקדמות יעדים
- דוח השוואת בנצ'מרקים
- דוח אופטימיזציות

### ויזואליזציות
- גרפי זמן אמת
- מפות חום ביצועים
- התפלגויות מדדים
- מגמות היסטוריות
- השוואות לפני/אחרי

## אבטחה ופרטיות

- הצפנת נתוני ביצועים
- בקרת גישה לדוחות
- מעקב שינויים
- גיבוי קבוע
- ביקורת ולוגים

## התקנה

```bash
# התקנת תלויות
pip install -r requirements.txt

# הגדרת ניטור מערכת
sudo python setup_monitoring.py

# התחלת שירותים
python start_performance_engine.py
```

## אינטגרציות

### פלטפורמות ניטור
- Prometheus
- Grafana
- New Relic
- DataDog
- AppDynamics

### מסדי נתונים
- InfluxDB (זמן אמת)
- Elasticsearch (חיפוש)
- PostgreSQL (ביקורת)
- Redis (מטמון)

## רישיון
MIT License

## יוצר
מערכת AI מתקדמת - Effi AI Private

---

*מנוע ביצועים זה מותאם לסביבת עבודה ישראלית ותומך במלואו בשפה העברית ובפורמטים מקומיים.*