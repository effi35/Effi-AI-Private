"""
Performance Engine Module
מודול מנוע ביצועים ואופטימיזציה
"""

from .core.performance_engine import PerformanceEngine
from .models import *
from .ui.performance_dashboard import PerformanceDashboard
from .utils import *

__version__ = "1.0.0"
__author__ = "Effi AI Private"
__description__ = "Advanced Performance Monitoring and Optimization Engine"

class PerformanceEngineModule:
    """מודול מנוע ביצועים ואופטימיזציה"""
    
    def __init__(self, config=None):
        self.engine = PerformanceEngine(config)
        self.dashboard = PerformanceDashboard()
        
    def get_info(self):
        return {
            'name': 'Performance Engine',
            'hebrew_name': 'מנוע ביצועים ואופטימיזציה',
            'version': __version__,
            'description': __description__,
            'author': __author__,
            'capabilities': [
                'Real-time performance monitoring',
                'Bottleneck detection',
                'Automated optimization',
                'Benchmark testing',
                'Predictive performance analysis',
                'Resource usage optimization',
                'Hebrew language support'
            ]
        }

# Main module interface
def create_engine(config=None):
    """יוצר מופע של מנוע ביצועים"""
    return PerformanceEngineModule(config)