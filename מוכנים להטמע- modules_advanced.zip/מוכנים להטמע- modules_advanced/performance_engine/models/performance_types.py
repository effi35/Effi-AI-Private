"""
Performance Types and Metrics
סוגי ביצועים ומדדים
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import numpy as np

class PerformanceCategory(Enum):
    """קטגוריות ביצועים"""
    SPEED = "speed"                     # מהירות
    EFFICIENCY = "efficiency"           # יעילות
    THROUGHPUT = "throughput"           # תפוקה
    LATENCY = "latency"                 # זמן תגובה
    RESOURCE_USAGE = "resource_usage"   # צריכת משאבים
    SCALABILITY = "scalability"         # מדרגיות
    RELIABILITY = "reliability"         # אמינות
    AVAILABILITY = "availability"       # זמינות
    QUALITY = "quality"                 # איכות
    USER_EXPERIENCE = "user_experience" # חוויית משתמש
    COST = "cost"                       # עלות
    ENERGY = "energy"                   # צריכת אנרגיה

class MetricType(Enum):
    """סוגי מדדים"""
    COUNTER = "counter"         # מונה (תמיד עולה)
    GAUGE = "gauge"            # מד (יכול לעלות ולרדת)  
    HISTOGRAM = "histogram"     # היסטוגרמה
    RATE = "rate"              # קצב (לזמן)
    PERCENTAGE = "percentage"   # אחוז
    RATIO = "ratio"            # יחס
    DURATION = "duration"      # משך זמן
    SIZE = "size"              # גודל
    FREQUENCY = "frequency"    # תדירות

class MetricUnit(Enum):
    """יחידות מדידה"""
    # זמן
    NANOSECONDS = "ns"
    MICROSECONDS = "μs" 
    MILLISECONDS = "ms"
    SECONDS = "s"
    MINUTES = "min"
    HOURS = "h"
    DAYS = "d"
    
    # גודל/זיכרון
    BYTES = "B"
    KILOBYTES = "KB"
    MEGABYTES = "MB"
    GIGABYTES = "GB"
    TERABYTES = "TB"
    
    # תפוקה
    REQUESTS_PER_SECOND = "rps"
    TRANSACTIONS_PER_SECOND = "tps"
    OPERATIONS_PER_SECOND = "ops"
    BITS_PER_SECOND = "bps"
    
    # אחוזים ויחסים
    PERCENT = "%"
    RATIO = "ratio"
    COUNT = "count"
    
    # משאבים
    CPU_PERCENT = "cpu%"
    MEMORY_PERCENT = "mem%"
    DISK_PERCENT = "disk%"
    NETWORK_PERCENT = "net%"

class PerformanceStatus(Enum):
    """סטטוס ביצועים"""
    EXCELLENT = "excellent"     # מעולה
    GOOD = "good"              # טוב
    ACCEPTABLE = "acceptable"   # מקובל
    POOR = "poor"              # גרוע
    CRITICAL = "critical"       # קריטי
    UNKNOWN = "unknown"         # לא ידוע

@dataclass
class PerformanceThreshold:
    """סף ביצועים"""
    warning_threshold: float    # סף אזהרה
    critical_threshold: float   # סף קריטי
    target_value: Optional[float] = None      # ערך יעד
    optimal_range_min: Optional[float] = None # טווח אופטימלי מינימום
    optimal_range_max: Optional[float] = None # טווח אופטימלי מקסימום
    
    def evaluate_status(self, current_value: float) -> PerformanceStatus:
        """מעריך סטטוס לפי ערך נוכחי"""
        if self.critical_threshold is not None:
            if current_value >= self.critical_threshold:
                return PerformanceStatus.CRITICAL
        
        if self.warning_threshold is not None:
            if current_value >= self.warning_threshold:
                return PerformanceStatus.POOR
        
        if (self.optimal_range_min is not None and 
            self.optimal_range_max is not None):
            if self.optimal_range_min <= current_value <= self.optimal_range_max:
                return PerformanceStatus.EXCELLENT
            else:
                return PerformanceStatus.ACCEPTABLE
        
        if self.target_value is not None:
            diff_percentage = abs(current_value - self.target_value) / self.target_value
            if diff_percentage < 0.05:  # תוך 5%
                return PerformanceStatus.EXCELLENT
            elif diff_percentage < 0.15:  # תוך 15%
                return PerformanceStatus.GOOD
            else:
                return PerformanceStatus.ACCEPTABLE
        
        return PerformanceStatus.UNKNOWN

@dataclass
class PerformanceMetric:
    """מדד ביצועים"""
    id: str
    name: str
    hebrew_name: str
    description: str
    hebrew_description: str
    category: PerformanceCategory
    metric_type: MetricType
    unit: MetricUnit
    threshold: PerformanceThreshold
    
    # ערכים נוכחיים
    current_value: Optional[float] = None
    previous_value: Optional[float] = None
    baseline_value: Optional[float] = None
    
    # מטא-דטה
    source: str = ""              # מקור המדד
    collection_method: str = ""   # שיטת איסוף
    update_frequency: int = 60    # תדירות עדכון (שניות)
    last_updated: Optional[datetime] = None
    
    # הגדרות נוספות
    is_higher_better: bool = True  # האם ערך גבוה יותר טוב יותר
    is_active: bool = True
    tags: List[str] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.metadata is None:
            self.metadata = {}
    
    def update_value(self, new_value: float, timestamp: datetime = None):
        """עדכון ערך המדד"""
        self.previous_value = self.current_value
        self.current_value = new_value
        self.last_updated = timestamp or datetime.now()
    
    def get_status(self) -> PerformanceStatus:
        """מחזיר סטטוס ביצועים נוכחי"""
        if self.current_value is None:
            return PerformanceStatus.UNKNOWN
        
        return self.threshold.evaluate_status(self.current_value)
    
    def get_trend(self) -> str:
        """מחזיר מגמת שינוי"""
        if self.current_value is None or self.previous_value is None:
            return "stable"
        
        change = self.current_value - self.previous_value
        
        if abs(change) < 0.01:  # שינוי זניח
            return "stable"
        
        if self.is_higher_better:
            return "improving" if change > 0 else "declining"
        else:
            return "improving" if change < 0 else "declining"
    
    def calculate_improvement_percentage(self) -> Optional[float]:
        """מחשב אחוז שיפור מהבסיס"""
        if self.current_value is None or self.baseline_value is None:
            return None
        
        if self.baseline_value == 0:
            return None
        
        change = self.current_value - self.baseline_value
        improvement = change / abs(self.baseline_value) * 100
        
        # התאמה לכיוון השיפור
        if not self.is_higher_better:
            improvement = -improvement
        
        return improvement

@dataclass 
class PerformanceTarget:
    """יעד ביצועים"""
    target_id: str
    metric_id: str
    target_value: float
    target_date: datetime
    description: str
    hebrew_description: str
    
    # סוג יעד
    target_type: str = "absolute"  # absolute, percentage, range
    
    # מעקב התקדמות
    baseline_value: Optional[float] = None
    current_progress: float = 0.0  # אחוז התקדמות (0.0-1.0)
    is_achieved: bool = False
    achieved_date: Optional[datetime] = None
    
    # הגדרות נוספות
    priority: int = 3  # 1-5, 5 הכי גבוה
    owner: str = ""    # אחראי ליעד
    milestones: List[Dict] = None  # אבני דרך
    
    def __post_init__(self):
        if self.milestones is None:
            self.milestones = []
    
    def update_progress(self, current_metric_value: float):
        """עדכון התקדמות ליעד"""
        if self.baseline_value is None:
            return
        
        if self.target_type == "absolute":
            if self.baseline_value == self.target_value:
                self.current_progress = 1.0
            else:
                progress = (current_metric_value - self.baseline_value) / (self.target_value - self.baseline_value)
                self.current_progress = max(0.0, min(1.0, progress))
        
        # בדיקת השגת יעד
        if not self.is_achieved:
            if self.target_type == "absolute" and current_metric_value >= self.target_value:
                self.is_achieved = True
                self.achieved_date = datetime.now()
    
    def get_time_remaining(self) -> Optional[timedelta]:
        """מחזיר זמן שנותר ליעד"""
        now = datetime.now()
        if self.target_date > now:
            return self.target_date - now
        return None
    
    def is_on_track(self) -> bool:
        """בודק אם היעד בדרך להתגשם בזמן"""
        time_remaining = self.get_time_remaining()
        if time_remaining is None:  # יעד כבר עבר
            return self.is_achieved
        
        total_time = self.target_date - (self.target_date - timedelta(days=365))  # משערים שנה
        time_passed = total_time - time_remaining
        expected_progress = time_passed.total_seconds() / total_time.total_seconds()
        
        return self.current_progress >= expected_progress * 0.8  # 80% מהצפוי

@dataclass
class PerformanceSnapshot:
    """צילום מצב ביצועים"""
    snapshot_id: str
    timestamp: datetime
    metrics: Dict[str, float]  # metric_id -> value
    system_info: Dict[str, Any]
    environment: str  # production, staging, development
    version: str = ""
    tags: List[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []

@dataclass
class PerformanceReport:
    """דוח ביצועים"""
    report_id: str
    title: str
    hebrew_title: str
    period_start: datetime
    period_end: datetime
    metrics_summary: Dict[str, Any]
    targets_status: Dict[str, Any]
    key_insights: List[str]
    hebrew_insights: List[str]
    recommendations: List[str]
    hebrew_recommendations: List[str]
    generated_at: datetime
    generated_by: str = "PerformanceEngine"
    
    def get_overall_score(self) -> float:
        """מחזיר ניקוד ביצועים כולל"""
        if not self.metrics_summary:
            return 0.0
        
        status_weights = {
            PerformanceStatus.EXCELLENT: 1.0,
            PerformanceStatus.GOOD: 0.8,
            PerformanceStatus.ACCEPTABLE: 0.6,
            PerformanceStatus.POOR: 0.3,
            PerformanceStatus.CRITICAL: 0.0
        }
        
        total_score = 0.0
        total_metrics = 0
        
        for metric_data in self.metrics_summary.values():
            if 'status' in metric_data:
                status = PerformanceStatus(metric_data['status'])
                total_score += status_weights.get(status, 0.0)
                total_metrics += 1
        
        return total_score / total_metrics if total_metrics > 0 else 0.0

class PerformanceMetricLibrary:
    """ספריית מדדי ביצועים מוכנים"""
    
    @staticmethod
    def get_system_metrics() -> List[PerformanceMetric]:
        """מדדי ביצועי מערכת"""
        return [
            PerformanceMetric(
                id="cpu_usage",
                name="CPU Usage",
                hebrew_name="צריכת מעבד",
                description="CPU utilization percentage",
                hebrew_description="אחוז ניצול המעבד",
                category=PerformanceCategory.RESOURCE_USAGE,
                metric_type=MetricType.PERCENTAGE,
                unit=MetricUnit.CPU_PERCENT,
                threshold=PerformanceThreshold(
                    warning_threshold=70.0,
                    critical_threshold=90.0,
                    optimal_range_min=10.0,
                    optimal_range_max=60.0
                ),
                is_higher_better=False
            ),
            PerformanceMetric(
                id="memory_usage",
                name="Memory Usage",
                hebrew_name="צריכת זיכרון",
                description="Memory utilization percentage",
                hebrew_description="אחוז ניצול הזיכרון",
                category=PerformanceCategory.RESOURCE_USAGE,
                metric_type=MetricType.PERCENTAGE,
                unit=MetricUnit.MEMORY_PERCENT,
                threshold=PerformanceThreshold(
                    warning_threshold=80.0,
                    critical_threshold=95.0,
                    optimal_range_min=20.0,
                    optimal_range_max=70.0
                ),
                is_higher_better=False
            ),
            PerformanceMetric(
                id="response_time",
                name="Response Time",
                hebrew_name="זמן תגובה",
                description="Average response time",
                hebrew_description="זמן תגובה ממוצע",
                category=PerformanceCategory.LATENCY,
                metric_type=MetricType.DURATION,
                unit=MetricUnit.MILLISECONDS,
                threshold=PerformanceThreshold(
                    warning_threshold=1000.0,
                    critical_threshold=5000.0,
                    target_value=200.0
                ),
                is_higher_better=False
            ),
            PerformanceMetric(
                id="throughput",
                name="Throughput",
                hebrew_name="תפוקה",
                description="Requests per second",
                hebrew_description="בקשות לשנייה",
                category=PerformanceCategory.THROUGHPUT,
                metric_type=MetricType.RATE,
                unit=MetricUnit.REQUESTS_PER_SECOND,
                threshold=PerformanceThreshold(
                    warning_threshold=50.0,  # מתחת ל-50 רק"ש
                    critical_threshold=10.0,  # מתחת ל-10 רק"ש
                    target_value=100.0
                ),
                is_higher_better=True
            )
        ]
    
    @staticmethod
    def get_application_metrics() -> List[PerformanceMetric]:
        """מדדי ביצועי אפליקציה"""
        return [
            PerformanceMetric(
                id="error_rate",
                name="Error Rate",
                hebrew_name="שיעור שגיאות",
                description="Percentage of failed requests",
                hebrew_description="אחוז בקשות כושלות",
                category=PerformanceCategory.RELIABILITY,
                metric_type=MetricType.PERCENTAGE,
                unit=MetricUnit.PERCENT,
                threshold=PerformanceThreshold(
                    warning_threshold=1.0,
                    critical_threshold=5.0,
                    target_value=0.1
                ),
                is_higher_better=False
            ),
            PerformanceMetric(
                id="availability",
                name="Availability",
                hebrew_name="זמינות",
                description="System uptime percentage",
                hebrew_description="אחוז זמן פעילות המערכת",
                category=PerformanceCategory.AVAILABILITY,
                metric_type=MetricType.PERCENTAGE,
                unit=MetricUnit.PERCENT,
                threshold=PerformanceThreshold(
                    warning_threshold=99.0,
                    critical_threshold=95.0,
                    target_value=99.9
                ),
                is_higher_better=True
            ),
            PerformanceMetric(
                id="database_query_time",
                name="Database Query Time",
                hebrew_name="זמן שאילתת מסד נתונים",
                description="Average database query execution time",
                hebrew_description="זמן ביצוע ממוצע של שאילתות למסד נתונים",
                category=PerformanceCategory.LATENCY,
                metric_type=MetricType.DURATION,
                unit=MetricUnit.MILLISECONDS,
                threshold=PerformanceThreshold(
                    warning_threshold=500.0,
                    critical_threshold=2000.0,
                    target_value=100.0
                ),
                is_higher_better=False
            )
        ]
    
    @staticmethod
    def get_business_metrics() -> List[PerformanceMetric]:
        """מדדי ביצועים עסקיים"""
        return [
            PerformanceMetric(
                id="user_satisfaction",
                name="User Satisfaction",
                hebrew_name="שביעות רצון משתמשים",
                description="User satisfaction score",
                hebrew_description="ניקוד שביעות רצון משתמשים",
                category=PerformanceCategory.USER_EXPERIENCE,
                metric_type=MetricType.GAUGE,
                unit=MetricUnit.RATIO,
                threshold=PerformanceThreshold(
                    warning_threshold=3.5,
                    critical_threshold=2.5,
                    target_value=4.5,
                    optimal_range_min=4.0,
                    optimal_range_max=5.0
                ),
                is_higher_better=True
            ),
            PerformanceMetric(
                id="cost_per_transaction",
                name="Cost Per Transaction",
                hebrew_name="עלות לעסקה",
                description="Average cost per transaction",
                hebrew_description="עלות ממוצעת לעסקה",
                category=PerformanceCategory.COST,
                metric_type=MetricType.GAUGE,
                unit=MetricUnit.COUNT,  # יחידות מטבע
                threshold=PerformanceThreshold(
                    warning_threshold=10.0,
                    critical_threshold=20.0,
                    target_value=5.0
                ),
                is_higher_better=False
            )
        ]