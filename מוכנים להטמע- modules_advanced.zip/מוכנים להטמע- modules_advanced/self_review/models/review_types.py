"""
Self Review Types
סוגי סקירה עצמית

Comprehensive models for AI self-assessment and continuous improvement.
מודלים מקיפים להערכה עצמית של בינה מלאכותית ושיפור מתמיד.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from enum import Enum
import json

class ReviewCategory(Enum):
    """Review categories for assessment"""
    ACCURACY = "accuracy"                    # דיוק
    RELEVANCE = "relevance"                 # רלוונטיות
    COMPLETENESS = "completeness"           # שלמות
    CLARITY = "clarity"                     # בהירות
    EFFICIENCY = "efficiency"               # יעילות
    CREATIVITY = "creativity"               # יצירתיות
    PROFESSIONALISM = "professionalism"     # מקצועיות
    CULTURAL_SENSITIVITY = "cultural_sensitivity"  # רגישות תרבותית
    USER_SATISFACTION = "user_satisfaction" # שביעות רצון משתמש
    TECHNICAL_QUALITY = "technical_quality" # איכות טכנית

class QualityLevel(Enum):
    """Quality assessment levels"""
    EXCELLENT = "excellent"     # מצוין
    GOOD = "good"              # טוב
    SATISFACTORY = "satisfactory"  # מספק
    NEEDS_IMPROVEMENT = "needs_improvement"  # זקוק שיפור
    POOR = "poor"              # גרוע

class ImprovementPriority(Enum):
    """Improvement priority levels"""
    CRITICAL = "critical"      # קריטי
    HIGH = "high"             # גבוה
    MEDIUM = "medium"         # בינוני
    LOW = "low"               # נמוך
    OPTIONAL = "optional"     # אופציונלי

class ReviewDepth(Enum):
    """Review analysis depth"""
    SURFACE = "surface"        # שטחי
    MODERATE = "moderate"      # בינוני
    DEEP = "deep"             # עמוק
    COMPREHENSIVE = "comprehensive"  # מקיף

@dataclass
class ReviewCriteria:
    """
    Criteria for self-assessment
    קריטריונים להערכה עצמית
    """
    criteria_id: str
    name: str
    name_hebrew: str
    description: str
    description_hebrew: str
    category: ReviewCategory
    weight: float = 1.0  # Importance weight (0.0 - 1.0)
    min_score: float = 0.0
    max_score: float = 10.0
    
    # Assessment questions
    assessment_questions: List[str] = field(default_factory=list)
    assessment_questions_hebrew: List[str] = field(default_factory=list)
    
    # Benchmarks
    excellent_threshold: float = 9.0
    good_threshold: float = 7.0
    satisfactory_threshold: float = 5.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'criteria_id': self.criteria_id,
            'name': self.name,
            'name_hebrew': self.name_hebrew,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'category': self.category.value,
            'weight': self.weight,
            'min_score': self.min_score,
            'max_score': self.max_score,
            'assessment_questions': self.assessment_questions,
            'assessment_questions_hebrew': self.assessment_questions_hebrew,
            'excellent_threshold': self.excellent_threshold,
            'good_threshold': self.good_threshold,
            'satisfactory_threshold': self.satisfactory_threshold
        }

@dataclass
class ReviewScore:
    """
    Individual review score with reasoning
    ציון סקירה בודד עם נימוק
    """
    criteria: ReviewCriteria
    score: float
    confidence: float = 1.0  # Confidence in the score (0.0 - 1.0)
    reasoning: str = ""
    reasoning_hebrew: str = ""
    evidence: List[str] = field(default_factory=list)  # Supporting evidence
    evidence_hebrew: List[str] = field(default_factory=list)
    
    # Context
    reviewer_confidence: float = 1.0
    review_timestamp: datetime = field(default_factory=datetime.now)
    
    def get_quality_level(self) -> QualityLevel:
        """Get quality level based on score"""
        if self.score >= self.criteria.excellent_threshold:
            return QualityLevel.EXCELLENT
        elif self.score >= self.criteria.good_threshold:
            return QualityLevel.GOOD
        elif self.score >= self.criteria.satisfactory_threshold:
            return QualityLevel.SATISFACTORY
        else:
            return QualityLevel.NEEDS_IMPROVEMENT
    
    def get_hebrew_quality_level(self) -> str:
        """Get quality level in Hebrew"""
        level_map = {
            QualityLevel.EXCELLENT: "מצוין",
            QualityLevel.GOOD: "טוב",
            QualityLevel.SATISFACTORY: "מספק",
            QualityLevel.NEEDS_IMPROVEMENT: "זקוק שיפור",
            QualityLevel.POOR: "גרוע"
        }
        return level_map.get(self.get_quality_level(), "לא ידוע")
    
    def is_satisfactory(self) -> bool:
        """Check if score meets satisfactory threshold"""
        return self.score >= self.criteria.satisfactory_threshold
    
    def get_weighted_score(self) -> float:
        """Get score weighted by criteria importance"""
        return self.score * self.criteria.weight
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'criteria': self.criteria.to_dict(),
            'score': self.score,
            'confidence': self.confidence,
            'reasoning': self.reasoning,
            'reasoning_hebrew': self.reasoning_hebrew,
            'evidence': self.evidence,
            'evidence_hebrew': self.evidence_hebrew,
            'reviewer_confidence': self.reviewer_confidence,
            'review_timestamp': self.review_timestamp.isoformat(),
            'quality_level': self.get_quality_level().value,
            'quality_level_hebrew': self.get_hebrew_quality_level(),
            'is_satisfactory': self.is_satisfactory(),
            'weighted_score': self.get_weighted_score()
        }

@dataclass
class ImprovementSuggestion:
    """
    Specific improvement suggestion with action plan
    הצעת שיפור ספציפית עם תוכנית פעולה
    """
    suggestion_id: str
    title: str
    title_hebrew: str
    description: str
    description_hebrew: str
    category: ReviewCategory
    priority: ImprovementPriority
    
    # Impact assessment
    estimated_impact: float = 0.0  # Expected improvement (0.0 - 1.0)
    effort_required: float = 0.0   # Effort needed (0.0 - 1.0)
    implementation_time: float = 0.0  # Estimated hours
    
    # Action plan
    action_steps: List[str] = field(default_factory=list)
    action_steps_hebrew: List[str] = field(default_factory=list)
    required_resources: List[str] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)
    
    # Tracking
    implementation_status: str = "proposed"  # proposed, in_progress, completed, rejected
    created_date: datetime = field(default_factory=datetime.now)
    target_completion_date: Optional[datetime] = None
    actual_completion_date: Optional[datetime] = None
    
    # Results tracking
    effectiveness_score: Optional[float] = None  # Post-implementation assessment
    lessons_learned: List[str] = field(default_factory=list)
    lessons_learned_hebrew: List[str] = field(default_factory=list)
    
    def get_roi_estimate(self) -> float:
        """Get estimated return on investment"""
        if self.effort_required == 0:
            return float('inf') if self.estimated_impact > 0 else 0
        return self.estimated_impact / self.effort_required
    
    def get_hebrew_priority(self) -> str:
        """Get priority in Hebrew"""
        priority_map = {
            ImprovementPriority.CRITICAL: "קריטי",
            ImprovementPriority.HIGH: "גבוה",
            ImprovementPriority.MEDIUM: "בינוני",
            ImprovementPriority.LOW: "נמוך",
            ImprovementPriority.OPTIONAL: "אופציונלי"
        }
        return priority_map.get(self.priority, "לא ידוע")
    
    def mark_completed(self, effectiveness_score: float = None):
        """Mark suggestion as completed"""
        self.implementation_status = "completed"
        self.actual_completion_date = datetime.now()
        if effectiveness_score is not None:
            self.effectiveness_score = effectiveness_score
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'suggestion_id': self.suggestion_id,
            'title': self.title,
            'title_hebrew': self.title_hebrew,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'category': self.category.value,
            'priority': self.priority.value,
            'priority_hebrew': self.get_hebrew_priority(),
            'estimated_impact': self.estimated_impact,
            'effort_required': self.effort_required,
            'implementation_time': self.implementation_time,
            'roi_estimate': self.get_roi_estimate(),
            'action_steps': self.action_steps,
            'action_steps_hebrew': self.action_steps_hebrew,
            'required_resources': self.required_resources,
            'prerequisites': self.prerequisites,
            'implementation_status': self.implementation_status,
            'created_date': self.created_date.isoformat(),
            'target_completion_date': self.target_completion_date.isoformat() if self.target_completion_date else None,
            'actual_completion_date': self.actual_completion_date.isoformat() if self.actual_completion_date else None,
            'effectiveness_score': self.effectiveness_score,
            'lessons_learned': self.lessons_learned,
            'lessons_learned_hebrew': self.lessons_learned_hebrew
        }

@dataclass
class QualityMetric:
    """
    Quality metric with historical tracking
    מדד איכות עם מעקב היסטורי
    """
    metric_name: str
    metric_name_hebrew: str
    category: ReviewCategory
    current_value: float
    target_value: float
    unit: str = ""
    
    # Historical tracking
    historical_values: List[Tuple[datetime, float]] = field(default_factory=list)
    baseline_value: Optional[float] = None
    best_value: Optional[float] = None
    worst_value: Optional[float] = None
    
    # Trends
    trend_direction: str = "stable"  # improving, degrading, stable
    trend_confidence: float = 0.0
    
    def add_measurement(self, value: float, timestamp: Optional[datetime] = None):
        """Add new measurement"""
        if timestamp is None:
            timestamp = datetime.now()
        
        self.historical_values.append((timestamp, value))
        self.current_value = value
        
        # Update best/worst
        if self.best_value is None or value > self.best_value:
            self.best_value = value
        if self.worst_value is None or value < self.worst_value:
            self.worst_value = value
        
        # Update trend
        self._calculate_trend()
    
    def _calculate_trend(self):
        """Calculate trend direction"""
        if len(self.historical_values) < 5:
            self.trend_direction = "insufficient_data"
            return
        
        recent_values = [value for _, value in self.historical_values[-5:]]
        older_values = [value for _, value in self.historical_values[-10:-5]] if len(self.historical_values) >= 10 else recent_values
        
        if not older_values:
            self.trend_direction = "insufficient_data"
            return
        
        recent_avg = sum(recent_values) / len(recent_values)
        older_avg = sum(older_values) / len(older_values)
        
        change = (recent_avg - older_avg) / older_avg if older_avg != 0 else 0
        
        if change > 0.05:  # 5% improvement
            self.trend_direction = "improving"
            self.trend_confidence = min(1.0, abs(change))
        elif change < -0.05:  # 5% degradation
            self.trend_direction = "degrading"
            self.trend_confidence = min(1.0, abs(change))
        else:
            self.trend_direction = "stable"
            self.trend_confidence = 1.0 - abs(change)
    
    def get_progress_percentage(self) -> float:
        """Get progress towards target as percentage"""
        if self.baseline_value is None or self.target_value == self.baseline_value:
            return 0.0
        
        progress = (self.current_value - self.baseline_value) / (self.target_value - self.baseline_value)
        return max(0.0, min(100.0, progress * 100))
    
    def is_target_met(self) -> bool:
        """Check if target is met"""
        return self.current_value >= self.target_value
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'metric_name': self.metric_name,
            'metric_name_hebrew': self.metric_name_hebrew,
            'category': self.category.value,
            'current_value': self.current_value,
            'target_value': self.target_value,
            'unit': self.unit,
            'baseline_value': self.baseline_value,
            'best_value': self.best_value,
            'worst_value': self.worst_value,
            'trend_direction': self.trend_direction,
            'trend_confidence': self.trend_confidence,
            'progress_percentage': self.get_progress_percentage(),
            'is_target_met': self.is_target_met(),
            'measurement_count': len(self.historical_values)
        }

@dataclass
class TaskAnalysis:
    """
    Analysis of specific task execution
    ניתוח ביצוע משימה ספציפית
    """
    task_id: str
    task_name: str
    task_description: str
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    
    # Execution context
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    duration: float = 0.0
    success: bool = True
    
    # Quality assessment
    expected_outcome: str = ""
    actual_outcome: str = ""
    outcome_match_score: float = 0.0  # How well actual matches expected
    
    # User feedback
    user_satisfaction: Optional[float] = None  # User rating 1-10
    user_feedback: str = ""
    user_feedback_hebrew: str = ""
    
    # Self-assessment
    self_satisfaction: float = 0.0  # AI's own assessment 1-10
    confidence_level: float = 0.0   # Confidence in the result
    
    # Improvement opportunities
    identified_issues: List[str] = field(default_factory=list)
    identified_issues_hebrew: List[str] = field(default_factory=list)
    alternative_approaches: List[str] = field(default_factory=list)
    alternative_approaches_hebrew: List[str] = field(default_factory=list)
    
    def mark_completed(self, success: bool = True):
        """Mark task as completed"""
        self.end_time = datetime.now()
        self.success = success
        if self.start_time:
            self.duration = (self.end_time - self.start_time).total_seconds()
    
    def calculate_overall_score(self) -> float:
        """Calculate overall task performance score"""
        factors = []
        
        # Outcome match score
        factors.append(self.outcome_match_score)
        
        # User satisfaction (if available)
        if self.user_satisfaction is not None:
            factors.append(self.user_satisfaction / 10.0)  # Normalize to 0-1
        
        # Self satisfaction
        factors.append(self.self_satisfaction / 10.0)
        
        # Success factor
        factors.append(1.0 if self.success else 0.0)
        
        # Confidence factor
        factors.append(self.confidence_level)
        
        return sum(factors) / len(factors) if factors else 0.0
    
    def add_issue(self, issue: str, issue_hebrew: str = ""):
        """Add identified issue"""
        self.identified_issues.append(issue)
        if issue_hebrew:
            self.identified_issues_hebrew.append(issue_hebrew)
    
    def add_alternative(self, alternative: str, alternative_hebrew: str = ""):
        """Add alternative approach"""
        self.alternative_approaches.append(alternative)
        if alternative_hebrew:
            self.alternative_approaches_hebrew.append(alternative_hebrew)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'task_id': self.task_id,
            'task_name': self.task_name,
            'task_description': self.task_description,
            'input_data': self.input_data,
            'output_data': self.output_data,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': self.duration,
            'success': self.success,
            'expected_outcome': self.expected_outcome,
            'actual_outcome': self.actual_outcome,
            'outcome_match_score': self.outcome_match_score,
            'user_satisfaction': self.user_satisfaction,
            'user_feedback': self.user_feedback,
            'user_feedback_hebrew': self.user_feedback_hebrew,
            'self_satisfaction': self.self_satisfaction,
            'confidence_level': self.confidence_level,
            'identified_issues': self.identified_issues,
            'identified_issues_hebrew': self.identified_issues_hebrew,
            'alternative_approaches': self.alternative_approaches,
            'alternative_approaches_hebrew': self.alternative_approaches_hebrew,
            'overall_score': self.calculate_overall_score()
        }

@dataclass
class OutputQuality:
    """
    Quality assessment of AI output
    הערכת איכות פלט בינה מלאכותית
    """
    output_id: str
    output_type: str  # text, code, analysis, recommendation, etc.
    content: str
    
    # Quality dimensions
    accuracy_score: float = 0.0      # Factual correctness
    relevance_score: float = 0.0     # Relevance to request
    completeness_score: float = 0.0  # How complete the answer is
    clarity_score: float = 0.0       # How clear and understandable
    creativity_score: float = 0.0    # Creative/innovative aspects
    
    # Technical quality
    grammar_score: float = 0.0       # Grammar and language quality
    structure_score: float = 0.0     # Organization and structure
    tone_appropriateness: float = 0.0 # Appropriate tone for context
    
    # Cultural aspects
    cultural_sensitivity: float = 0.0 # Cultural appropriateness
    hebrew_quality: float = 0.0      # Hebrew language quality
    
    # Meta assessment
    assessment_confidence: float = 0.0
    assessment_timestamp: datetime = field(default_factory=datetime.now)
    
    def calculate_overall_quality(self) -> float:
        """Calculate overall quality score"""
        scores = [
            self.accuracy_score, self.relevance_score, self.completeness_score,
            self.clarity_score, self.grammar_score, self.structure_score,
            self.tone_appropriateness, self.cultural_sensitivity
        ]
        
        # Filter out zero scores (not assessed)
        valid_scores = [score for score in scores if score > 0]
        
        return sum(valid_scores) / len(valid_scores) if valid_scores else 0.0
    
    def get_quality_level(self) -> QualityLevel:
        """Get overall quality level"""
        overall = self.calculate_overall_quality()
        
        if overall >= 9.0:
            return QualityLevel.EXCELLENT
        elif overall >= 7.0:
            return QualityLevel.GOOD
        elif overall >= 5.0:
            return QualityLevel.SATISFACTORY
        elif overall >= 3.0:
            return QualityLevel.NEEDS_IMPROVEMENT
        else:
            return QualityLevel.POOR
    
    def get_weak_areas(self, threshold: float = 6.0) -> List[str]:
        """Get areas that need improvement"""
        weak_areas = []
        
        if self.accuracy_score < threshold:
            weak_areas.append("accuracy")
        if self.relevance_score < threshold:
            weak_areas.append("relevance")
        if self.completeness_score < threshold:
            weak_areas.append("completeness")
        if self.clarity_score < threshold:
            weak_areas.append("clarity")
        if self.grammar_score < threshold:
            weak_areas.append("grammar")
        if self.structure_score < threshold:
            weak_areas.append("structure")
        if self.tone_appropriateness < threshold:
            weak_areas.append("tone")
        if self.cultural_sensitivity < threshold:
            weak_areas.append("cultural_sensitivity")
        
        return weak_areas
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'output_id': self.output_id,
            'output_type': self.output_type,
            'content': self.content,
            'accuracy_score': self.accuracy_score,
            'relevance_score': self.relevance_score,
            'completeness_score': self.completeness_score,
            'clarity_score': self.clarity_score,
            'creativity_score': self.creativity_score,
            'grammar_score': self.grammar_score,
            'structure_score': self.structure_score,
            'tone_appropriateness': self.tone_appropriateness,
            'cultural_sensitivity': self.cultural_sensitivity,
            'hebrew_quality': self.hebrew_quality,
            'overall_quality': self.calculate_overall_quality(),
            'quality_level': self.get_quality_level().value,
            'weak_areas': self.get_weak_areas(),
            'assessment_confidence': self.assessment_confidence,
            'assessment_timestamp': self.assessment_timestamp.isoformat()
        }

@dataclass
class SelfAssessment:
    """
    Complete self-assessment with scores and improvements
    הערכה עצמית מלאה עם ציונים ושיפורים
    """
    assessment_id: str
    name: str
    description: str
    timestamp: datetime = field(default_factory=datetime.now)
    depth: ReviewDepth = ReviewDepth.MODERATE
    
    # Assessment results
    review_scores: List[ReviewScore] = field(default_factory=list)
    task_analyses: List[TaskAnalysis] = field(default_factory=list)
    output_qualities: List[OutputQuality] = field(default_factory=list)
    quality_metrics: List[QualityMetric] = field(default_factory=list)
    
    # Improvement plan
    improvement_suggestions: List[ImprovementSuggestion] = field(default_factory=list)
    
    # Overall assessment
    overall_score: float = 0.0
    confidence_level: float = 0.0
    assessment_summary: str = ""
    assessment_summary_hebrew: str = ""
    
    # Context
    module_name: str = ""
    session_context: Dict[str, Any] = field(default_factory=dict)
    
    def add_review_score(self, score: ReviewScore):
        """Add review score"""
        self.review_scores.append(score)
        self._recalculate_overall_score()
    
    def add_task_analysis(self, analysis: TaskAnalysis):
        """Add task analysis"""
        self.task_analyses.append(analysis)
    
    def add_output_quality(self, quality: OutputQuality):
        """Add output quality assessment"""
        self.output_qualities.append(quality)
    
    def add_improvement_suggestion(self, suggestion: ImprovementSuggestion):
        """Add improvement suggestion"""
        self.improvement_suggestions.append(suggestion)
    
    def _recalculate_overall_score(self):
        """Recalculate overall assessment score"""
        if not self.review_scores:
            self.overall_score = 0.0
            return
        
        total_weighted_score = sum(score.get_weighted_score() for score in self.review_scores)
        total_weights = sum(score.criteria.weight for score in self.review_scores)
        
        self.overall_score = total_weighted_score / total_weights if total_weights > 0 else 0.0
    
    def get_scores_by_category(self, category: ReviewCategory) -> List[ReviewScore]:
        """Get scores for specific category"""
        return [score for score in self.review_scores if score.criteria.category == category]
    
    def get_suggestions_by_priority(self, priority: ImprovementPriority) -> List[ImprovementSuggestion]:
        """Get suggestions by priority level"""
        return [suggestion for suggestion in self.improvement_suggestions 
                if suggestion.priority == priority]
    
    def get_critical_improvements(self) -> List[ImprovementSuggestion]:
        """Get critical improvement suggestions"""
        return self.get_suggestions_by_priority(ImprovementPriority.CRITICAL)
    
    def get_weak_categories(self, threshold: float = 6.0) -> List[ReviewCategory]:
        """Get categories with low scores"""
        weak_categories = []
        
        for category in ReviewCategory:
            category_scores = self.get_scores_by_category(category)
            if category_scores:
                avg_score = sum(score.score for score in category_scores) / len(category_scores)
                if avg_score < threshold:
                    weak_categories.append(category)
        
        return weak_categories
    
    def generate_summary(self):
        """Generate assessment summary"""
        quality_level = self.get_overall_quality_level()
        weak_areas = self.get_weak_categories()
        critical_improvements = len(self.get_critical_improvements())
        
        self.assessment_summary = f"""
Self-Assessment Summary:
Overall Score: {self.overall_score:.1f}/10
Quality Level: {quality_level.value}
Areas needing improvement: {len(weak_areas)}
Critical improvements needed: {critical_improvements}
Confidence in assessment: {self.confidence_level:.1f}
"""
        
        quality_hebrew = {
            QualityLevel.EXCELLENT: "מצוין",
            QualityLevel.GOOD: "טוב", 
            QualityLevel.SATISFACTORY: "מספק",
            QualityLevel.NEEDS_IMPROVEMENT: "זקוק שיפור",
            QualityLevel.POOR: "גרוע"
        }.get(quality_level, "לא ידוע")
        
        self.assessment_summary_hebrew = f"""
סיכום הערכה עצמית:
ציון כללי: {self.overall_score:.1f}/10
רמת איכות: {quality_hebrew}
תחומים לשיפור: {len(weak_areas)}
שיפורים קריטיים: {critical_improvements}
ביטחון בהערכה: {self.confidence_level:.1f}
"""
    
    def get_overall_quality_level(self) -> QualityLevel:
        """Get overall quality level"""
        if self.overall_score >= 9.0:
            return QualityLevel.EXCELLENT
        elif self.overall_score >= 7.0:
            return QualityLevel.GOOD
        elif self.overall_score >= 5.0:
            return QualityLevel.SATISFACTORY
        elif self.overall_score >= 3.0:
            return QualityLevel.NEEDS_IMPROVEMENT
        else:
            return QualityLevel.POOR
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to comprehensive dictionary"""
        return {
            'assessment_id': self.assessment_id,
            'name': self.name,
            'description': self.description,
            'timestamp': self.timestamp.isoformat(),
            'depth': self.depth.value,
            'review_scores': [score.to_dict() for score in self.review_scores],
            'task_analyses': [analysis.to_dict() for analysis in self.task_analyses],
            'output_qualities': [quality.to_dict() for quality in self.output_qualities],
            'quality_metrics': [metric.to_dict() for metric in self.quality_metrics],
            'improvement_suggestions': [suggestion.to_dict() for suggestion in self.improvement_suggestions],
            'overall_score': self.overall_score,
            'confidence_level': self.confidence_level,
            'assessment_summary': self.assessment_summary,
            'assessment_summary_hebrew': self.assessment_summary_hebrew,
            'module_name': self.module_name,
            'session_context': self.session_context,
            'overall_quality_level': self.get_overall_quality_level().value,
            'weak_categories': [cat.value for cat in self.get_weak_categories()],
            'critical_improvements_count': len(self.get_critical_improvements()),
            'total_scores': len(self.review_scores),
            'total_suggestions': len(self.improvement_suggestions)
        }

@dataclass
class ReviewSession:
    """
    Review session containing multiple assessments
    סשן סקירה המכיל מספר הערכות
    """
    session_id: str
    name: str
    start_time: datetime
    end_time: Optional[datetime] = None
    
    assessments: List[SelfAssessment] = field(default_factory=list)
    
    # Session summary
    total_tasks_reviewed: int = 0
    total_improvements_identified: int = 0
    average_quality_score: float = 0.0
    session_insights: List[str] = field(default_factory=list)
    session_insights_hebrew: List[str] = field(default_factory=list)
    
    def add_assessment(self, assessment: SelfAssessment):
        """Add assessment to session"""
        self.assessments.append(assessment)
        self._update_session_summary()
    
    def _update_session_summary(self):
        """Update session summary statistics"""
        if not self.assessments:
            return
        
        self.total_tasks_reviewed = sum(len(assessment.task_analyses) for assessment in self.assessments)
        self.total_improvements_identified = sum(len(assessment.improvement_suggestions) for assessment in self.assessments)
        
        scores = [assessment.overall_score for assessment in self.assessments if assessment.overall_score > 0]
        self.average_quality_score = sum(scores) / len(scores) if scores else 0.0
    
    def complete_session(self):
        """Mark session as completed"""
        self.end_time = datetime.now()
        self._update_session_summary()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'session_id': self.session_id,
            'name': self.name,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'assessments': [assessment.to_dict() for assessment in self.assessments],
            'total_tasks_reviewed': self.total_tasks_reviewed,
            'total_improvements_identified': self.total_improvements_identified,
            'average_quality_score': self.average_quality_score,
            'session_insights': self.session_insights,
            'session_insights_hebrew': self.session_insights_hebrew,
            'assessment_count': len(self.assessments)
        }