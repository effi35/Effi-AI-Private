"""
Memory Runtime UI Dashboard
מחוללת לוח בקרה מתקדם למערכת הזיכרון והתודעה
"""

from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import json
import asyncio
from ..models.memory_types import (
    MemoryType, EmotionalState, MemoryNode, 
    ConversationMemory, LearningInsight
)
from ..core.memory_engine import MemoryRuntimeEngine

class MemoryDashboard:
    """לוח בקרה מתקדם למעקב אחר מערכת הזיכרון והתודעה"""
    
    def __init__(self, memory_engine: MemoryRuntimeEngine):
        self.memory_engine = memory_engine
        self.dashboard_data = {}
        
    async def get_dashboard_data(self) -> Dict[str, Any]:
        """יוצר נתוני לוח בקרה מקיפים"""
        try:
            # סטטיסטיקות זיכרון בסיסיות
            memory_stats = await self._get_memory_statistics()
            
            # ניתוח רגשי
            emotional_analysis = await self._get_emotional_analysis()
            
            # תובנות למידה
            learning_insights = await self._get_learning_insights()
            
            # ביצועי מערכת
            performance_metrics = await self._get_performance_metrics()
            
            # זיכרונות אחרונים
            recent_memories = await self._get_recent_memories()
            
            # מפת קשרים
            connection_map = await self._generate_connection_map()
            
            return {
                "timestamp": datetime.now().isoformat(),
                "memory_statistics": memory_stats,
                "emotional_analysis": emotional_analysis,
                "learning_insights": learning_insights,
                "performance_metrics": performance_metrics,
                "recent_memories": recent_memories,
                "connection_map": connection_map,
                "system_health": await self._check_system_health()
            }
            
        except Exception as e:
            return {"error": f"שגיאה ביצירת נתוני לוח הבקרה: {str(e)}"}
    
    async def _get_memory_statistics(self) -> Dict[str, Any]:
        """מחשב סטטיסטיקות זיכרון מפורטות"""
        stats = {
            "total_memories": len(self.memory_engine.memory_store),
            "by_type": {},
            "by_emotional_state": {},
            "memory_clusters": len(self.memory_engine.memory_clusters),
            "learning_insights": len(self.memory_engine.learning_insights)
        }
        
        # ספירה לפי סוג זיכרון
        for memory_type in MemoryType:
            count = sum(1 for mem in self.memory_engine.memory_store.values() 
                       if mem.memory_type == memory_type)
            stats["by_type"][memory_type.value] = count
        
        # ספירה לפי מצב רגשי
        for emotional_state in EmotionalState:
            count = sum(1 for mem in self.memory_engine.memory_store.values() 
                       if hasattr(mem, 'emotional_context') and 
                       mem.emotional_context and
                       mem.emotional_context.primary_emotion == emotional_state)
            stats["by_emotional_state"][emotional_state.value] = count
        
        return stats
    
    async def _get_emotional_analysis(self) -> Dict[str, Any]:
        """מנתח מצבים רגשיים ומגמות"""
        recent_memories = [
            mem for mem in self.memory_engine.memory_store.values()
            if mem.timestamp > datetime.now() - timedelta(hours=24)
        ]
        
        if not recent_memories:
            return {"status": "אין זיכרונות אחרונים למחנוח"}
        
        # חישוב התפלגות רגשית
        emotional_distribution = {}
        total_intensity = 0
        
        for memory in recent_memories:
            if hasattr(memory, 'emotional_context') and memory.emotional_context:
                emotion = memory.emotional_context.primary_emotion.value
                intensity = memory.emotional_context.intensity
                
                if emotion not in emotional_distribution:
                    emotional_distribution[emotion] = {"count": 0, "total_intensity": 0}
                
                emotional_distribution[emotion]["count"] += 1
                emotional_distribution[emotion]["total_intensity"] += intensity
                total_intensity += intensity
        
        # חישוב מצב רגשי כללי
        dominant_emotion = max(emotional_distribution.items(), 
                              key=lambda x: x[1]["total_intensity"])[0] if emotional_distribution else "נייטרלי"
        
        average_intensity = total_intensity / len(recent_memories) if recent_memories else 0
        
        return {
            "dominant_emotion": dominant_emotion,
            "average_intensity": round(average_intensity, 2),
            "emotional_distribution": emotional_distribution,
            "emotional_stability": await self._calculate_emotional_stability(recent_memories),
            "mood_trend": await self._calculate_mood_trend()
        }
    
    async def _get_learning_insights(self) -> List[Dict[str, Any]]:
        """מחזיר תובנות למידה אחרונות"""
        recent_insights = sorted(
            self.memory_engine.learning_insights.values(),
            key=lambda x: x.created_at,
            reverse=True
        )[:10]
        
        return [
            {
                "id": insight.insight_id,
                "type": insight.insight_type.value,
                "content": insight.content,
                "confidence": insight.confidence_score,
                "created_at": insight.created_at.isoformat(),
                "related_memories": len(insight.related_memory_ids)
            }
            for insight in recent_insights
        ]
    
    async def _get_performance_metrics(self) -> Dict[str, Any]:
        """מחשב מדדי ביצועים של מערכת הזיכרון"""
        return {
            "memory_efficiency": await self._calculate_memory_efficiency(),
            "learning_rate": await self._calculate_learning_rate(),
            "connection_strength": await self._calculate_average_connection_strength(),
            "processing_speed": self.memory_engine.performance_metrics.get("avg_processing_time", 0),
            "cache_hit_rate": self.memory_engine.performance_metrics.get("cache_hit_rate", 0),
            "system_responsiveness": await self._measure_system_responsiveness()
        }
    
    async def _get_recent_memories(self, limit: int = 20) -> List[Dict[str, Any]]:
        """מחזיר זיכרונות אחרונים"""
        recent = sorted(
            self.memory_engine.memory_store.values(),
            key=lambda x: x.timestamp,
            reverse=True
        )[:limit]
        
        return [
            {
                "id": mem.memory_id,
                "type": mem.memory_type.value,
                "content_preview": mem.content[:100] + "..." if len(mem.content) > 100 else mem.content,
                "importance": mem.importance_score,
                "emotional_state": mem.emotional_context.primary_emotion.value if hasattr(mem, 'emotional_context') and mem.emotional_context else None,
                "timestamp": mem.timestamp.isoformat(),
                "connections": len(mem.connections)
            }
            for mem in recent
        ]
    
    async def _generate_connection_map(self) -> Dict[str, Any]:
        """יוצר מפת קשרים בין זיכרונות"""
        nodes = []
        edges = []
        
        # יצירת צמתים
        for memory in list(self.memory_engine.memory_store.values())[:50]:  # מגביל ל-50 לביצועים
            nodes.append({
                "id": memory.memory_id,
                "label": memory.content[:30] + "..." if len(memory.content) > 30 else memory.content,
                "type": memory.memory_type.value,
                "importance": memory.importance_score,
                "size": min(memory.importance_score * 10, 50)
            })
        
        # יצירת קשרים
        for memory in list(self.memory_engine.memory_store.values())[:50]:
            for connection in memory.connections:
                if connection.connected_memory_id in [n["id"] for n in nodes]:
                    edges.append({
                        "from": memory.memory_id,
                        "to": connection.connected_memory_id,
                        "strength": connection.connection_strength,
                        "type": connection.connection_type.value
                    })
        
        return {
            "nodes": nodes,
            "edges": edges,
            "total_connections": sum(len(mem.connections) for mem in self.memory_engine.memory_store.values())
        }
    
    async def _check_system_health(self) -> Dict[str, Any]:
        """בודק בריאות המערכת"""
        return {
            "status": "תקין",
            "memory_usage": len(self.memory_engine.memory_store),
            "last_cleanup": self.memory_engine.last_cleanup_time.isoformat() if hasattr(self.memory_engine, 'last_cleanup_time') else None,
            "ai_connection": await self._test_ai_connection(),
            "learning_active": len(self.memory_engine.learning_insights) > 0,
            "emotional_processing": True
        }
    
    async def _calculate_emotional_stability(self, memories: List[MemoryNode]) -> float:
        """מחשב יציבות רגשית"""
        if len(memories) < 2:
            return 1.0
        
        intensities = []
        for memory in memories:
            if hasattr(memory, 'emotional_context') and memory.emotional_context:
                intensities.append(memory.emotional_context.intensity)
        
        if not intensities:
            return 1.0
        
        # חישוב סטיית תקן
        avg = sum(intensities) / len(intensities)
        variance = sum((x - avg) ** 2 for x in intensities) / len(intensities)
        stability = max(0, 1 - (variance ** 0.5))
        
        return round(stability, 3)
    
    async def _calculate_mood_trend(self) -> str:
        """מחשב מגמת מצב רוח"""
        recent_hours = []
        for i in range(6):  # 6 שעות אחרונות
            hour_start = datetime.now() - timedelta(hours=i+1)
            hour_end = datetime.now() - timedelta(hours=i)
            
            hour_memories = [
                mem for mem in self.memory_engine.memory_store.values()
                if hour_start <= mem.timestamp <= hour_end and
                hasattr(mem, 'emotional_context') and mem.emotional_context
            ]
            
            if hour_memories:
                avg_intensity = sum(mem.emotional_context.intensity for mem in hour_memories) / len(hour_memories)
                recent_hours.append(avg_intensity)
        
        if len(recent_hours) < 2:
            return "יציב"
        
        trend = sum(recent_hours[i] - recent_hours[i+1] for i in range(len(recent_hours)-1))
        
        if trend > 0.2:
            return "משתפר"
        elif trend < -0.2:
            return "מתדרדר"
        else:
            return "יציב"
    
    async def _calculate_memory_efficiency(self) -> float:
        """מחשב יעילות זיכרון"""
        if not self.memory_engine.memory_store:
            return 1.0
        
        important_memories = sum(1 for mem in self.memory_engine.memory_store.values() 
                               if mem.importance_score > 0.7)
        total_memories = len(self.memory_engine.memory_store)
        
        return round(important_memories / total_memories, 3)
    
    async def _calculate_learning_rate(self) -> float:
        """מחשב קצב למידה"""
        recent_insights = [
            insight for insight in self.memory_engine.learning_insights.values()
            if insight.created_at > datetime.now() - timedelta(hours=24)
        ]
        
        return len(recent_insights)
    
    async def _calculate_average_connection_strength(self) -> float:
        """מחשב חוזק ממוצע של קשרים"""
        all_connections = []
        for memory in self.memory_engine.memory_store.values():
            all_connections.extend([conn.connection_strength for conn in memory.connections])
        
        return round(sum(all_connections) / len(all_connections), 3) if all_connections else 0.0
    
    async def _measure_system_responsiveness(self) -> float:
        """מודד זמן תגובה של המערכת"""
        start_time = datetime.now()
        # סימולציה של פעולה
        await asyncio.sleep(0.01)
        response_time = (datetime.now() - start_time).total_seconds()
        
        return round(response_time * 1000, 2)  # במילישניות
    
    async def _test_ai_connection(self) -> bool:
        """בודק חיבור למודל AI המקומי"""
        try:
            # בדיקה פשוטה של החיבור
            return hasattr(self.memory_engine, 'ai_client') and self.memory_engine.ai_client is not None
        except:
            return False

class MemoryVisualization:
    """כלי ויזואליזציה למערכת הזיכרון"""
    
    def __init__(self, memory_engine: MemoryRuntimeEngine):
        self.memory_engine = memory_engine
    
    async def generate_memory_timeline(self, days: int = 7) -> Dict[str, Any]:
        """יוצר ציר זמן של זיכרונות"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        timeline_data = []
        
        for day in range(days):
            day_start = start_date + timedelta(days=day)
            day_end = day_start + timedelta(days=1)
            
            day_memories = [
                mem for mem in self.memory_engine.memory_store.values()
                if day_start <= mem.timestamp < day_end
            ]
            
            if day_memories:
                timeline_data.append({
                    "date": day_start.strftime("%Y-%m-%d"),
                    "memory_count": len(day_memories),
                    "average_importance": sum(mem.importance_score for mem in day_memories) / len(day_memories),
                    "emotional_summary": await self._summarize_day_emotions(day_memories)
                })
        
        return {
            "timeline": timeline_data,
            "total_days": days,
            "total_memories": sum(item["memory_count"] for item in timeline_data)
        }
    
    async def _summarize_day_emotions(self, memories: List[MemoryNode]) -> Dict[str, Any]:
        """מסכם רגשות של יום"""
        emotions = {}
        
        for memory in memories:
            if hasattr(memory, 'emotional_context') and memory.emotional_context:
                emotion = memory.emotional_context.primary_emotion.value
                emotions[emotion] = emotions.get(emotion, 0) + 1
        
        dominant = max(emotions.items(), key=lambda x: x[1])[0] if emotions else "נייטרלי"
        
        return {
            "dominant_emotion": dominant,
            "emotion_distribution": emotions
        }