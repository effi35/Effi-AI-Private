"""
Memory Runtime Types - סוגי זיכרון רץ
מודלי נתונים למערכת הזיכרון החי והמתמשך

מערכת זיכרון מתקדמת עם 5 שכבות תודעה ולמידה מתמשכת
"""

import json
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Set
from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib

class MemoryType(Enum):
    """סוגי זיכרון"""
    CORE = "core"                    # זיכרון ליבה - יציב ועמוק
    EPISODIC = "episodic"           # זיכרון אפיזודי - חוויות
    SEMANTIC = "semantic"           # זיכרון סמנטי - ידע
    PROCEDURAL = "procedural"       # זיכרון פרוצדורלי - מיומנויות
    META_COGNITIVE = "meta_cognitive" # זיכרון מטא-קוגניטיבי - חשיבה עצמית

class EmotionalState(Enum):
    """מצבים רגשיים מורכבים"""
    JOY = "joy"                     # שמחה
    SADNESS = "sadness"             # עצב
    ANGER = "anger"                 # כעס
    FEAR = "fear"                   # פחד
    SURPRISE = "surprise"           # הפתעה
    DISGUST = "disgust"             # גועל
    ANTICIPATION = "anticipation"   # ציפייה
    TRUST = "trust"                 # אמון
    LOVE = "love"                   # אהבה
    CURIOSITY = "curiosity"         # סקרנות
    PRIDE = "pride"                 # גאווה
    SHAME = "shame"                 # בושה
    HOPE = "hope"                   # תקווה
    DESPAIR = "despair"             # ייאוש
    EXCITEMENT = "excitement"       # התרגשות

class MemoryPriority(Enum):
    """עדיפות זיכרון"""
    CRITICAL = "critical"           # קריטי
    HIGH = "high"                   # גבוה
    MEDIUM = "medium"               # בינוני
    LOW = "low"                     # נמוך
    ARCHIVE = "archive"             # ארכיון

@dataclass
class EmotionalContext:
    """הקשר רגשי"""
    primary_emotion: EmotionalState
    secondary_emotions: List[EmotionalState] = field(default_factory=list)
    intensity: float = 0.5          # 0.0 - 1.0
    valence: float = 0.0            # -1.0 (שלילי) to 1.0 (חיובי)
    arousal: float = 0.5            # 0.0 (רגוע) to 1.0 (מעורר)
    confidence: float = 0.8         # ביטחון בזיהוי הרגש
    context_tags: List[str] = field(default_factory=list)

@dataclass
class MemoryNode:
    """צומת זיכרון יחיד"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    memory_type: MemoryType = MemoryType.EPISODIC
    priority: MemoryPriority = MemoryPriority.MEDIUM
    
    # הקשר זמן
    created_at: datetime = field(default_factory=datetime.now)
    last_accessed: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    
    # הקשר רגשי
    emotional_context: Optional[EmotionalContext] = None
    
    # קשרים וחיבורים
    related_memories: List[str] = field(default_factory=list)  # IDs של זיכרונות קשורים
    tags: Set[str] = field(default_factory=set)
    keywords: List[str] = field(default_factory=list)
    
    # מטאדאטה
    source: str = "user_interaction"  # מקור הזיכרון
    context: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0           # רמת ביטחון בזיכרון
    decay_rate: float = 0.001         # קצב דעיכה
    
    # דירוג וחשיבות
    relevance_score: float = 0.5
    emotional_weight: float = 0.0
    practical_value: float = 0.0
    
    def update_access(self):
        """עדכון נתוני גישה"""
        self.last_accessed = datetime.now()
        self.access_count += 1
        
    def calculate_strength(self) -> float:
        """חישוב עוצמת הזיכרון"""
        # חישוב מורכב של עוצמת זיכרון
        time_factor = 1.0 - (datetime.now() - self.created_at).total_seconds() * self.decay_rate
        access_factor = min(1.0, self.access_count / 10.0)
        emotional_factor = self.emotional_weight
        
        return max(0.0, (time_factor * 0.4 + access_factor * 0.3 + 
                        emotional_factor * 0.2 + self.confidence * 0.1))
    
    def get_hash(self) -> str:
        """חישוב hash ייחודי לזיכרון"""
        content_hash = hashlib.md5(self.content.encode()).hexdigest()
        return f"{self.memory_type.value}_{content_hash[:8]}"

@dataclass
class ConversationMemory:
    """זיכרון שיחה"""
    conversation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_message: str = ""
    ai_response: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    
    # הקשר שיחה
    context: Dict[str, Any] = field(default_factory=dict)
    session_id: str = ""
    user_mood: Optional[EmotionalState] = None
    ai_mood: Optional[EmotionalState] = None
    
    # ניתוח השיחה
    satisfaction_score: float = 0.0    # שביעות רצון משוערת
    complexity_level: int = 1          # רמת מורכבות 1-5
    topics: List[str] = field(default_factory=list)
    entities: List[str] = field(default_factory=list)
    
    # למידה מהשיחה
    learned_facts: List[str] = field(default_factory=list)
    improvements_needed: List[str] = field(default_factory=list)
    successful_patterns: List[str] = field(default_factory=list)

@dataclass
class LearningInsight:
    """תובנת למידה"""
    insight_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    description: str = ""
    
    # סוג התובנה
    category: str = "general"          # general, behavioral, emotional, technical
    confidence: float = 0.5
    impact_level: int = 1              # 1-5 רמת השפעה
    
    # מקורות התובנה
    source_memories: List[str] = field(default_factory=list)
    trigger_event: str = ""
    
    # יישום התובנה
    actionable_steps: List[str] = field(default_factory=list)
    applied: bool = False
    application_results: Dict[str, Any] = field(default_factory=dict)
    
    # זמנים
    discovered_at: datetime = field(default_factory=datetime.now)
    applied_at: Optional[datetime] = None

@dataclass
class MemoryCluster:
    """אשכול זיכרונות"""
    cluster_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    theme: str = ""
    description: str = ""
    
    # זיכרונות באשכול
    memory_ids: List[str] = field(default_factory=list)
    central_memory_id: str = ""        # זיכרון מרכזי
    
    # מאפיינים
    coherence_score: float = 0.0       # רמת קוהרנטיות
    emotional_signature: Dict[EmotionalState, float] = field(default_factory=dict)
    importance: float = 0.0
    
    # זמנים
    formed_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)

@dataclass
class KnowledgeGraph:
    """גרף ידע"""
    nodes: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # צמתים
    edges: List[Dict[str, Any]] = field(default_factory=list)       # קשרים
    
    def add_node(self, node_id: str, data: Dict[str, Any]):
        """הוספת צומת לגרף"""
        self.nodes[node_id] = data
        
    def add_edge(self, from_node: str, to_node: str, relation: str, weight: float = 1.0):
        """הוספת קשר בין צמתים"""
        edge = {
            "from": from_node,
            "to": to_node,
            "relation": relation,
            "weight": weight,
            "created_at": datetime.now().isoformat()
        }
        self.edges.append(edge)
        
    def get_related_nodes(self, node_id: str, max_depth: int = 2) -> List[str]:
        """קבלת צמתים קשורים"""
        related = set()
        current_level = {node_id}
        
        for depth in range(max_depth):
            next_level = set()
            for current_node in current_level:
                for edge in self.edges:
                    if edge["from"] == current_node:
                        next_level.add(edge["to"])
                        related.add(edge["to"])
                    elif edge["to"] == current_node:
                        next_level.add(edge["from"])
                        related.add(edge["from"])
            current_level = next_level
            
        return list(related)

@dataclass
class RuntimeMemoryState:
    """מצב זיכרון רץ"""
    state_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    # זיכרונות פעילים
    active_memories: List[MemoryNode] = field(default_factory=list)
    working_memory: List[str] = field(default_factory=list)  # זיכרון עבודה
    
    # הקשר נוכחי
    current_context: Dict[str, Any] = field(default_factory=dict)
    active_emotions: List[EmotionalState] = field(default_factory=list)
    
    # מדדים
    cognitive_load: float = 0.0        # עומס קוגניטיבי
    attention_focus: str = ""          # מיקוד תשומת לב
    processing_depth: int = 1          # עומק עיבוד 1-5
    
    # זמנים
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)

# פונקציות עזר
def create_memory_from_interaction(content: str, 
                                 memory_type: MemoryType = MemoryType.EPISODIC,
                                 emotional_context: Optional[EmotionalContext] = None,
                                 tags: Optional[Set[str]] = None) -> MemoryNode:
    """יצירת זיכרון מאינטראקציה"""
    memory = MemoryNode(
        content=content,
        memory_type=memory_type,
        emotional_context=emotional_context,
        tags=tags or set()
    )
    
    # הוספת תגיות אוטומטיות
    if "שאלה" in content or "?" in content:
        memory.tags.add("question")
    if "תודה" in content:
        memory.tags.add("gratitude")
    if "בעיה" in content or "שגיאה" in content:
        memory.tags.add("problem")
        
    return memory

def analyze_emotional_content(text: str) -> EmotionalContext:
    """ניתוח רגשי של טקסט"""
    # מילות מפתח רגשיות
    emotion_keywords = {
        EmotionalState.JOY: ["שמח", "מרוצה", "נהדר", "מעולה", "כיף"],
        EmotionalState.SADNESS: ["עצוב", "מצטער", "קשה", "בעיה"],
        EmotionalState.ANGER: ["כועס", "מעצבן", "זעם", "מתוסכל"],
        EmotionalState.FEAR: ["פחד", "חרדה", "דאגה", "מפחיד"],
        EmotionalState.EXCITEMENT: ["מתרגש", "נלהב", "וואו", "מדהים"],
        EmotionalState.LOVE: ["אהבה", "אוהב", "יקר", "חבר"],
        EmotionalState.CURIOSITY: ["מעניין", "איך", "מה", "למה"],
        EmotionalState.PRIDE: ["גאה", "הצלחתי", "מושלם", "אלוף"]
    }
    
    detected_emotions = []
    max_intensity = 0.0
    primary_emotion = EmotionalState.JOY
    
    text_lower = text.lower()
    
    for emotion, keywords in emotion_keywords.items():
        intensity = sum(1 for keyword in keywords if keyword in text_lower)
        if intensity > 0:
            detected_emotions.append(emotion)
            if intensity > max_intensity:
                max_intensity = intensity
                primary_emotion = emotion
    
    # חישוב valence ו-arousal
    positive_emotions = {EmotionalState.JOY, EmotionalState.LOVE, EmotionalState.PRIDE, EmotionalState.EXCITEMENT}
    negative_emotions = {EmotionalState.SADNESS, EmotionalState.ANGER, EmotionalState.FEAR}
    
    valence = 0.0
    if primary_emotion in positive_emotions:
        valence = 0.7
    elif primary_emotion in negative_emotions:
        valence = -0.7
        
    arousal = 0.5
    if primary_emotion in {EmotionalState.EXCITEMENT, EmotionalState.ANGER, EmotionalState.FEAR}:
        arousal = 0.8
    elif primary_emotion in {EmotionalState.SADNESS}:
        arousal = 0.2
    
    return EmotionalContext(
        primary_emotion=primary_emotion,
        secondary_emotions=detected_emotions[1:],
        intensity=min(1.0, max_intensity / 3.0),
        valence=valence,
        arousal=arousal,
        confidence=0.8 if detected_emotions else 0.3
    )

def consolidate_memories(memories: List[MemoryNode]) -> List[MemoryCluster]:
    """איחוד זיכרונות לאשכולות"""
    clusters = []
    processed_memories = set()
    
    for memory in memories:
        if memory.id in processed_memories:
            continue
            
        # חיפוש זיכרונות דומים
        similar_memories = [memory]
        for other_memory in memories:
            if (other_memory.id != memory.id and 
                other_memory.id not in processed_memories and
                _are_memories_similar(memory, other_memory)):
                similar_memories.append(other_memory)
                processed_memories.add(other_memory.id)
        
        if len(similar_memories) >= 2:  # לפחות 2 זיכרונות לאשכול
            cluster = MemoryCluster(
                theme=_extract_theme(similar_memories),
                description=f"אשכול של {len(similar_memories)} זיכרונות קשורים",
                memory_ids=[m.id for m in similar_memories],
                central_memory_id=memory.id,
                coherence_score=_calculate_coherence(similar_memories),
                importance=max(m.relevance_score for m in similar_memories)
            )
            clusters.append(cluster)
        
        processed_memories.add(memory.id)
    
    return clusters

def _are_memories_similar(memory1: MemoryNode, memory2: MemoryNode) -> bool:
    """בדיקת דמיון בין זיכרונות"""
    # בדיקת תגיות משותפות
    common_tags = memory1.tags.intersection(memory2.tags)
    if len(common_tags) >= 2:
        return True
    
    # בדיקת מילות מפתח משותפות
    common_keywords = set(memory1.keywords).intersection(set(memory2.keywords))
    if len(common_keywords) >= 3:
        return True
    
    # בדיקת רגש דומה
    if (memory1.emotional_context and memory2.emotional_context and
        memory1.emotional_context.primary_emotion == memory2.emotional_context.primary_emotion):
        return True
    
    return False

def _extract_theme(memories: List[MemoryNode]) -> str:
    """חילוץ נושא מרכזי מזיכרונות"""
    all_tags = set()
    for memory in memories:
        all_tags.update(memory.tags)
    
    # מציאת התג הנפוץ ביותר
    tag_counts = {}
    for memory in memories:
        for tag in memory.tags:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
    
    if tag_counts:
        most_common_tag = max(tag_counts.items(), key=lambda x: x[1])[0]
        return most_common_tag
    
    return "נושא כללי"

def _calculate_coherence(memories: List[MemoryNode]) -> float:
    """חישוב קוהרנטיות אשכול"""
    if len(memories) < 2:
        return 1.0
    
    # חישוב דמיון ממוצע בין כל הזוגות
    similarities = []
    for i in range(len(memories)):
        for j in range(i + 1, len(memories)):
            if _are_memories_similar(memories[i], memories[j]):
                similarities.append(1.0)
            else:
                similarities.append(0.0)
    
    return sum(similarities) / len(similarities) if similarities else 0.0