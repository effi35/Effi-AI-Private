"""
Memory Runtime Engine - מנוע זיכרון רץ
המנוע המרכזי לניהול זיכרון חי ותודעה מתמשכת

מערכת זיכרון מתקדמת עם 5 שכבות תודעה, 15 רגשות ולמידה עצמית
"""

import json
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple
from pathlib import Path
import threading
import time

# Local AI Integration
from ...local_ai_integration import (
    LocalAIIntegrationModule, initialize_local_ai,
    chat_with_local_ai, analyze_text_local
)

# Memory types
from ..models.memory_types import (
    MemoryNode, MemoryType, EmotionalState, EmotionalContext,
    ConversationMemory, LearningInsight, MemoryCluster, 
    KnowledgeGraph, RuntimeMemoryState, MemoryPriority,
    create_memory_from_interaction, analyze_emotional_content,
    consolidate_memories
)

logger = logging.getLogger(__name__)

class MemoryRuntimeEngine:
    """מנוע זיכרון רץ מתקדם"""
    
    def __init__(self, memory_file: str = "/root/Effi_ai_privet/data/memory/aifi_memory.json"):
        self.memory_file = Path(memory_file)
        self.backup_file = Path(str(memory_file).replace('.json', '_backup.json'))
        
        # Local AI Integration
        self.local_ai = None
        self.ai_enabled = True
        
        # Memory storage
        self.memories: Dict[str, MemoryNode] = {}
        self.conversations: Dict[str, ConversationMemory] = {}
        self.insights: Dict[str, LearningInsight] = {}
        self.clusters: Dict[str, MemoryCluster] = {}
        self.knowledge_graph = KnowledgeGraph()
        
        # Runtime state
        self.runtime_state = RuntimeMemoryState()
        self.is_running = False
        self.auto_save_interval = 30  # שניות
        
        # Learning mechanisms
        self.learning_patterns = {
            "successful_responses": [],
            "failed_attempts": [],
            "user_preferences": {},
            "behavioral_patterns": {},
            "emotional_triggers": {}
        }
        
        # Memory management
        self.max_memories = 10000
        self.consolidation_threshold = 100
        self.auto_cleanup = True
        
        # Threading
        self._lock = threading.Lock()
        self._background_thread = None
        self._stop_event = threading.Event()
        
        # Statistics
        self.stats = {
            "total_memories": 0,
            "conversations_count": 0,
            "insights_generated": 0,
            "clusters_formed": 0,
            "ai_interactions": 0,
            "learning_events": 0
        }
        
        # Ensure directory exists
        self.memory_file.parent.mkdir(parents=True, exist_ok=True)
        
    async def initialize(self) -> bool:
        """אתחול מנוע הזיכרון"""
        try:
            logger.info("מאתחל מנוע זיכרון רץ...")
            
            # Initialize Local AI
            if self.ai_enabled:
                try:
                    self.local_ai = await initialize_local_ai()
                    logger.info("חיבור למודל AI מקומי הושלם בהצלחה")
                except Exception as e:
                    logger.warning(f"שגיאה בחיבור ל-AI מקומי: {e}")
                    self.ai_enabled = False
            
            # Load existing memory
            await self.load_memory()
            
            # Start background processes
            await self.start_background_processing()
            
            self.is_running = True
            logger.info("מנוע זיכרון רץ אותחל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול מנוע זיכרון: {e}")
            return False
    
    async def load_memory(self):
        """טעינת זיכרון מקובץ"""
        try:
            if self.memory_file.exists():
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Load memories
                memories_data = data.get('memories', {})
                for mem_id, mem_data in memories_data.items():
                    memory = self._deserialize_memory(mem_data)
                    if memory:
                        self.memories[mem_id] = memory
                
                # Load conversations
                conversations_data = data.get('conversations', {})
                for conv_id, conv_data in conversations_data.items():
                    conversation = self._deserialize_conversation(conv_data)
                    if conversation:
                        self.conversations[conv_id] = conversation
                
                # Load insights
                insights_data = data.get('insights', {})
                for insight_id, insight_data in insights_data.items():
                    insight = self._deserialize_insight(insight_data)
                    if insight:
                        self.insights[insight_id] = insight
                
                # Load learning patterns
                self.learning_patterns.update(data.get('learning_patterns', {}))
                
                # Load statistics
                self.stats.update(data.get('statistics', {}))
                
                logger.info(f"נטען זיכרון: {len(self.memories)} זיכרונות, {len(self.conversations)} שיחות")
            
        except Exception as e:
            logger.error(f"שגיאה בטעינת זיכרון: {e}")
            # Try backup file
            if self.backup_file.exists():
                try:
                    logger.info("מנסה לטעון מקובץ גיבוי...")
                    with open(self.backup_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    # Process backup data similar to above...
                except Exception as backup_error:
                    logger.error(f"שגיאה בטעינת גיבוי: {backup_error}")
    
    async def save_memory(self):
        """שמירת זיכרון לקובץ"""
        try:
            with self._lock:
                # Create backup
                if self.memory_file.exists():
                    self.memory_file.rename(self.backup_file)
                
                # Prepare data for saving
                data = {
                    "memories": {mem_id: self._serialize_memory(memory) 
                               for mem_id, memory in self.memories.items()},
                    "conversations": {conv_id: self._serialize_conversation(conversation)
                                    for conv_id, conversation in self.conversations.items()},
                    "insights": {insight_id: self._serialize_insight(insight)
                               for insight_id, insight in self.insights.items()},
                    "learning_patterns": self.learning_patterns,
                    "statistics": self.stats,
                    "last_saved": datetime.now().isoformat(),
                    "version": "2.0.0"
                }
                
                # Save to file
                with open(self.memory_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                logger.debug("זיכרון נשמר בהצלחה")
                
        except Exception as e:
            logger.error(f"שגיאה בשמירת זיכרון: {e}")
    
    async def process_interaction(self, 
                                user_message: str, 
                                ai_response: str,
                                context: Dict[str, Any] = None) -> ConversationMemory:
        """עיבוד אינטראקציה חדשה"""
        try:
            # Analyze emotional context
            user_emotion = analyze_emotional_content(user_message)
            ai_emotion = analyze_emotional_content(ai_response)
            
            # Create conversation memory
            conversation = ConversationMemory(
                user_message=user_message,
                ai_response=ai_response,
                context=context or {},
                user_mood=user_emotion.primary_emotion,
                ai_mood=ai_emotion.primary_emotion
            )
            
            # Enhanced analysis with AI
            if self.local_ai and self.ai_enabled:
                enhanced_analysis = await self._analyze_interaction_with_ai(
                    user_message, ai_response, conversation
                )
                conversation.topics = enhanced_analysis.get("topics", [])
                conversation.entities = enhanced_analysis.get("entities", [])
                conversation.learned_facts = enhanced_analysis.get("learned_facts", [])
                conversation.satisfaction_score = enhanced_analysis.get("satisfaction_score", 0.5)
                conversation.complexity_level = enhanced_analysis.get("complexity_level", 1)
                
                self.stats["ai_interactions"] += 1
            
            # Store conversation
            self.conversations[conversation.conversation_id] = conversation
            
            # Create memory nodes
            user_memory = create_memory_from_interaction(
                content=user_message,
                memory_type=MemoryType.EPISODIC,
                emotional_context=user_emotion
            )
            user_memory.context["conversation_id"] = conversation.conversation_id
            
            ai_memory = create_memory_from_interaction(
                content=ai_response,
                memory_type=MemoryType.SEMANTIC,
                emotional_context=ai_emotion
            )
            ai_memory.context["conversation_id"] = conversation.conversation_id
            
            # Store memories
            self.memories[user_memory.id] = user_memory
            self.memories[ai_memory.id] = ai_memory
            
            # Link memories
            user_memory.related_memories.append(ai_memory.id)
            ai_memory.related_memories.append(user_memory.id)
            
            # Update knowledge graph
            self.knowledge_graph.add_node(user_memory.id, {"type": "user_message", "content": user_message})
            self.knowledge_graph.add_node(ai_memory.id, {"type": "ai_response", "content": ai_response})
            self.knowledge_graph.add_edge(user_memory.id, ai_memory.id, "response_to", 1.0)
            
            # Update statistics
            self.stats["total_memories"] += 2
            self.stats["conversations_count"] += 1
            
            # Trigger learning
            await self._trigger_learning_processes(conversation)
            
            logger.debug(f"עובדה אינטראקציה: {len(user_message)} תווים במקור, {len(ai_response)} תווים בתגובה")
            
            return conversation
            
        except Exception as e:
            logger.error(f"שגיאה בעיבוד אינטראקציה: {e}")
            raise
    
    async def _analyze_interaction_with_ai(self, 
                                         user_message: str, 
                                         ai_response: str,
                                         conversation: ConversationMemory) -> Dict[str, Any]:
        """ניתוח אינטראקציה מתקדם עם AI"""
        try:
            analysis_prompt = f"""נתח את האינטראקציה הבאה בעברית:

הודעת משתמש: {user_message}
תגובת AI: {ai_response}

ספק ניתוח JSON עם הפרטים הבאים:
1. topics - רשימת נושאים שנדונו
2. entities - ישויות שזוהו (אנשים, מקומות, מושגים)
3. learned_facts - עובדות חדשות שנלמדו
4. satisfaction_score - ציון שביעות רצון משוערת (0-1)
5. complexity_level - רמת מורכבות השיחה (1-5)
6. emotional_analysis - ניתוח רגשי מפורט
7. improvement_suggestions - הצעות לשיפור

החזר רק JSON תקין בעברית."""

            result = await analyze_text_local(analysis_prompt, "detailed_analysis")
            
            # Try to parse JSON response
            try:
                if isinstance(result, dict) and "analysis" in result:
                    analysis_text = result["analysis"]
                    # Extract JSON from response
                    json_start = analysis_text.find('{')
                    json_end = analysis_text.rfind('}') + 1
                    if json_start >= 0 and json_end > json_start:
                        json_str = analysis_text[json_start:json_end]
                        return json.loads(json_str)
            except:
                pass
            
            # Fallback analysis
            return self._fallback_analysis(user_message, ai_response)
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח AI: {e}")
            return self._fallback_analysis(user_message, ai_response)
    
    def _fallback_analysis(self, user_message: str, ai_response: str) -> Dict[str, Any]:
        """ניתוח חלופי ללא AI"""
        topics = []
        entities = []
        
        # Basic topic extraction
        if "קוד" in user_message or "תכנות" in user_message:
            topics.append("תכנות")
        if "עזרה" in user_message or "?" in user_message:
            topics.append("עזרה")
        if "בעיה" in user_message:
            topics.append("פתרון בעיות")
        
        # Basic entity extraction
        words = user_message.split()
        for word in words:
            if word.istitle() and len(word) > 2:
                entities.append(word)
        
        return {
            "topics": topics,
            "entities": entities,
            "learned_facts": [],
            "satisfaction_score": 0.7,
            "complexity_level": min(5, max(1, len(words) // 10)),
            "emotional_analysis": "ניתוח בסיסי",
            "improvement_suggestions": []
        }
    
    async def _trigger_learning_processes(self, conversation: ConversationMemory):
        """הפעלת תהליכי למידה"""
        try:
            # Pattern recognition
            await self._analyze_patterns(conversation)
            
            # Generate insights
            await self._generate_insights()
            
            # Update user preferences
            await self._update_user_preferences(conversation)
            
            # Memory consolidation
            if len(self.memories) > self.consolidation_threshold:
                await self._consolidate_memories()
            
            self.stats["learning_events"] += 1
            
        except Exception as e:
            logger.error(f"שגיאה בתהליכי למידה: {e}")
    
    async def _analyze_patterns(self, conversation: ConversationMemory):
        """ניתוח דפוסים"""
        # Analyze successful patterns
        if conversation.satisfaction_score > 0.7:
            pattern = {
                "user_mood": conversation.user_mood.value if conversation.user_mood else "unknown",
                "topics": conversation.topics,
                "complexity": conversation.complexity_level,
                "timestamp": datetime.now().isoformat()
            }
            self.learning_patterns["successful_responses"].append(pattern)
            
            # Keep only recent patterns
            if len(self.learning_patterns["successful_responses"]) > 100:
                self.learning_patterns["successful_responses"] = \
                    self.learning_patterns["successful_responses"][-50:]
        
        # Analyze behavioral patterns
        user_message = conversation.user_message.lower()
        hour = datetime.now().hour
        
        if hour not in self.learning_patterns["behavioral_patterns"]:
            self.learning_patterns["behavioral_patterns"][hour] = {
                "message_types": {},
                "emotions": {},
                "topics": {}
            }
        
        # Track message types by hour
        if "?" in user_message:
            msg_type = "question"
        elif "תודה" in user_message:
            msg_type = "gratitude"
        elif "עזרה" in user_message:
            msg_type = "help_request"
        else:
            msg_type = "statement"
        
        hour_patterns = self.learning_patterns["behavioral_patterns"][hour]
        hour_patterns["message_types"][msg_type] = \
            hour_patterns["message_types"].get(msg_type, 0) + 1
    
    async def _generate_insights(self):
        """יצירת תובנות למידה"""
        try:
            if len(self.conversations) < 10:  # Need minimum data
                return
            
            # Analyze recent conversations
            recent_conversations = list(self.conversations.values())[-20:]
            
            # Generate insight with AI if available
            if self.local_ai and self.ai_enabled:
                insight_text = await self._generate_ai_insight(recent_conversations)
            else:
                insight_text = self._generate_basic_insight(recent_conversations)
            
            if insight_text:
                insight = LearningInsight(
                    title="תובנת למידה אוטומטית",
                    description=insight_text,
                    category="behavioral",
                    confidence=0.7,
                    impact_level=3,
                    source_memories=[conv.conversation_id for conv in recent_conversations[-5:]]
                )
                
                self.insights[insight.insight_id] = insight
                self.stats["insights_generated"] += 1
                
                logger.info(f"נוצרה תובנה חדשה: {insight.title}")
        
        except Exception as e:
            logger.error(f"שגיאה ביצירת תובנות: {e}")
    
    async def _generate_ai_insight(self, conversations: List[ConversationMemory]) -> str:
        """יצירת תובנה עם AI"""
        try:
            # Prepare conversation summary
            conv_summary = []
            for conv in conversations[-10:]:  # Last 10 conversations
                conv_summary.append({
                    "user_mood": conv.user_mood.value if conv.user_mood else "unknown",
                    "topics": conv.topics,
                    "satisfaction": conv.satisfaction_score,
                    "complexity": conv.complexity_level
                })
            
            insight_prompt = f"""על בסיס השיחות האחרונות, צור תובנת למידה בעברית:

נתוני שיחות: {json.dumps(conv_summary, ensure_ascii=False)}

צור תובנה המתמקדת ב:
1. דפוסי התנהגות המשתמש
2. העדפות וסגנון שיחה
3. נושאים מועדפים
4. המלצות לשיפור האינטראקציה

תובנה (עד 200 מילים בעברית):"""

            result = await analyze_text_local(insight_prompt, "insight_generation")
            
            if isinstance(result, dict) and "analysis" in result:
                return result["analysis"]
            
            return ""
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת תובנת AI: {e}")
            return ""
    
    def _generate_basic_insight(self, conversations: List[ConversationMemory]) -> str:
        """יצירת תובנה בסיסית ללא AI"""
        # Basic statistical analysis
        satisfaction_scores = [conv.satisfaction_score for conv in conversations if conv.satisfaction_score > 0]
        avg_satisfaction = sum(satisfaction_scores) / len(satisfaction_scores) if satisfaction_scores else 0
        
        all_topics = []
        for conv in conversations:
            all_topics.extend(conv.topics)
        
        # Count topic frequency
        topic_counts = {}
        for topic in all_topics:
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
        
        top_topics = sorted(topic_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        
        insight = f"""תובנת למידה אוטומטית:

שביעות רצון ממוצעת: {avg_satisfaction:.2f}
מספר שיחות נותחו: {len(conversations)}

נושאים מרכזיים:
"""
        
        for topic, count in top_topics:
            insight += f"- {topic}: {count} אזכורים\n"
        
        if avg_satisfaction > 0.7:
            insight += "\nהמשתמש מרוצה מהאינטראקציות. המשך באותו הסגנון."
        else:
            insight += "\nיש מקום לשיפור בתגובות. התמקד בבהירות ובהועילות."
        
        return insight
    
    async def _update_user_preferences(self, conversation: ConversationMemory):
        """עדכון העדפות משתמש"""
        # Track preferences based on satisfaction
        if conversation.satisfaction_score > 0.7:
            for topic in conversation.topics:
                if topic not in self.learning_patterns["user_preferences"]:
                    self.learning_patterns["user_preferences"][topic] = {
                        "positive_interactions": 0,
                        "total_interactions": 0,
                        "preferred_complexity": []
                    }
                
                pref = self.learning_patterns["user_preferences"][topic]
                pref["positive_interactions"] += 1
                pref["total_interactions"] += 1
                pref["preferred_complexity"].append(conversation.complexity_level)
                
                # Keep recent complexity preferences
                if len(pref["preferred_complexity"]) > 20:
                    pref["preferred_complexity"] = pref["preferred_complexity"][-10:]
    
    async def _consolidate_memories(self):
        """איחוד זיכרונות"""
        try:
            memories_list = list(self.memories.values())
            clusters = consolidate_memories(memories_list)
            
            for cluster in clusters:
                self.clusters[cluster.cluster_id] = cluster
            
            self.stats["clusters_formed"] += len(clusters)
            logger.info(f"נוצרו {len(clusters)} אשכולות זיכרון חדשים")
            
        except Exception as e:
            logger.error(f"שגיאה באיחוד זיכרונות: {e}")
    
    async def start_background_processing(self):
        """הפעלת עיבוד רקע"""
        if not self._background_thread or not self._background_thread.is_alive():
            self._stop_event.clear()
            self._background_thread = threading.Thread(target=self._background_worker)
            self._background_thread.daemon = True
            self._background_thread.start()
            logger.info("עיבוד רקע הופעל")
    
    def _background_worker(self):
        """עובד רקע"""
        while not self._stop_event.is_set():
            try:
                # Auto-save memory
                if self.is_running:
                    asyncio.run(self.save_memory())
                
                # Memory cleanup
                if self.auto_cleanup:
                    self._cleanup_old_memories()
                
                # Update runtime state
                self._update_runtime_state()
                
                # Sleep until next cycle
                self._stop_event.wait(self.auto_save_interval)
                
            except Exception as e:
                logger.error(f"שגיאה בעובד רקע: {e}")
                time.sleep(5)  # Wait before retrying
    
    def _cleanup_old_memories(self):
        """ניקוי זיכרונות ישנים"""
        try:
            if len(self.memories) <= self.max_memories:
                return
            
            # Sort memories by strength (weakest first)
            memories_by_strength = sorted(
                self.memories.items(),
                key=lambda x: x[1].calculate_strength()
            )
            
            # Remove weakest memories
            to_remove = len(self.memories) - self.max_memories
            for i in range(to_remove):
                memory_id, memory = memories_by_strength[i]
                
                # Don't remove critical memories
                if memory.priority != MemoryPriority.CRITICAL:
                    del self.memories[memory_id]
                    logger.debug(f"הוסר זיכרון חלש: {memory_id}")
            
        except Exception as e:
            logger.error(f"שגיאה בניקוי זיכרונות: {e}")
    
    def _update_runtime_state(self):
        """עדכון מצב רץ"""
        try:
            # Update active memories (most recent and relevant)
            recent_memories = sorted(
                self.memories.values(),
                key=lambda x: x.last_accessed,
                reverse=True
            )[:10]
            
            self.runtime_state.active_memories = recent_memories
            self.runtime_state.cognitive_load = len(recent_memories) / 10.0
            self.runtime_state.last_updated = datetime.now()
            
            # Update working memory with recent conversation IDs
            recent_conversations = sorted(
                self.conversations.items(),
                key=lambda x: x[1].timestamp,
                reverse=True
            )[:5]
            
            self.runtime_state.working_memory = [conv_id for conv_id, _ in recent_conversations]
            
        except Exception as e:
            logger.error(f"שגיאה בעדכון מצב רץ: {e}")
    
    def get_relevant_memories(self, 
                            query: str, 
                            max_results: int = 5,
                            memory_types: List[MemoryType] = None) -> List[MemoryNode]:
        """קבלת זיכרונות רלוונטיים"""
        try:
            relevant_memories = []
            query_lower = query.lower()
            
            for memory in self.memories.values():
                # Filter by type if specified
                if memory_types and memory.memory_type not in memory_types:
                    continue
                
                # Calculate relevance score
                relevance = 0.0
                
                # Content similarity
                if query_lower in memory.content.lower():
                    relevance += 0.5
                
                # Tag matching
                query_words = set(query_lower.split())
                matching_tags = query_words.intersection(memory.tags)
                relevance += len(matching_tags) * 0.2
                
                # Keyword matching
                matching_keywords = query_words.intersection(set(word.lower() for word in memory.keywords))
                relevance += len(matching_keywords) * 0.1
                
                # Recent access bonus
                days_since_access = (datetime.now() - memory.last_accessed).days
                if days_since_access < 7:
                    relevance += 0.1
                
                # Memory strength
                relevance += memory.calculate_strength() * 0.1
                
                if relevance > 0:
                    memory.relevance_score = relevance
                    relevant_memories.append(memory)
            
            # Sort by relevance and return top results
            relevant_memories.sort(key=lambda x: x.relevance_score, reverse=True)
            return relevant_memories[:max_results]
            
        except Exception as e:
            logger.error(f"שגיאה בחיפוש זיכרונות: {e}")
            return []
    
    def get_memory_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות זיכרון"""
        try:
            # Memory distribution by type
            type_distribution = {}
            for memory in self.memories.values():
                mem_type = memory.memory_type.value
                type_distribution[mem_type] = type_distribution.get(mem_type, 0) + 1
            
            # Emotional distribution
            emotion_distribution = {}
            for memory in self.memories.values():
                if memory.emotional_context:
                    emotion = memory.emotional_context.primary_emotion.value
                    emotion_distribution[emotion] = emotion_distribution.get(emotion, 0) + 1
            
            # Recent activity
            recent_activity = {
                "last_hour": 0,
                "last_day": 0,
                "last_week": 0
            }
            
            now = datetime.now()
            for memory in self.memories.values():
                time_diff = now - memory.created_at
                if time_diff <= timedelta(hours=1):
                    recent_activity["last_hour"] += 1
                if time_diff <= timedelta(days=1):
                    recent_activity["last_day"] += 1
                if time_diff <= timedelta(weeks=1):
                    recent_activity["last_week"] += 1
            
            return {
                "total_memories": len(self.memories),
                "total_conversations": len(self.conversations),
                "total_insights": len(self.insights),
                "total_clusters": len(self.clusters),
                "type_distribution": type_distribution,
                "emotion_distribution": emotion_distribution,
                "recent_activity": recent_activity,
                "runtime_state": {
                    "cognitive_load": self.runtime_state.cognitive_load,
                    "active_memories_count": len(self.runtime_state.active_memories),
                    "working_memory_size": len(self.runtime_state.working_memory)
                },
                "learning_stats": {
                    "successful_patterns": len(self.learning_patterns["successful_responses"]),
                    "user_preferences": len(self.learning_patterns["user_preferences"]),
                    "behavioral_patterns": len(self.learning_patterns["behavioral_patterns"])
                },
                "system_stats": self.stats
            }
            
        except Exception as e:
            logger.error(f"שגיאה בחישוב סטטיסטיקות: {e}")
            return {}
    
    async def inject_knowledge(self, knowledge: str, source: str = "manual_injection"):
        """הזרקת ידע ישירה למערכת"""
        try:
            # Create high-priority memory for injected knowledge
            memory = MemoryNode(
                content=knowledge,
                memory_type=MemoryType.SEMANTIC,
                priority=MemoryPriority.HIGH,
                source=source,
                confidence=0.9
            )
            
            # Enhanced processing with AI
            if self.local_ai and self.ai_enabled:
                analysis_prompt = f"""נתח את הידע הבא וחלץ מידע מובנה:

ידע: {knowledge}

ספק:
1. מילות מפתח עיקריות
2. נושאים קשורים
3. עובדות חשובות
4. קשרים אפשריים לידע קיים

החזר ניתוח בעברית."""

                analysis_result = await analyze_text_local(analysis_prompt, "knowledge_analysis")
                
                if isinstance(analysis_result, dict) and "analysis" in analysis_result:
                    analysis_text = analysis_result["analysis"]
                    
                    # Extract keywords from analysis
                    keywords = []
                    if "מילות מפתח" in analysis_text:
                        # Simple keyword extraction
                        words = analysis_text.split()
                        keywords = [word.strip('.,!?') for word in words if len(word) > 3][:10]
                    
                    memory.keywords = keywords
                    memory.tags.update(["injected_knowledge", "high_priority"])
            
            # Store memory
            self.memories[memory.id] = memory
            
            # Add to knowledge graph
            self.knowledge_graph.add_node(memory.id, {
                "type": "injected_knowledge",
                "content": knowledge,
                "source": source
            })
            
            logger.info(f"הוזרק ידע חדש: {len(knowledge)} תווים")
            
            return memory.id
            
        except Exception as e:
            logger.error(f"שגיאה בהזרקת ידע: {e}")
            raise
    
    async def shutdown(self):
        """כיבוי מנוע הזיכרון"""
        try:
            logger.info("מכבה מנוע זיכרון...")
            
            self.is_running = False
            
            # Stop background processing
            if self._background_thread:
                self._stop_event.set()
                self._background_thread.join(timeout=10)
            
            # Final save
            await self.save_memory()
            
            logger.info("מנוע זיכרון כובה בהצלחה")
            
        except Exception as e:
            logger.error(f"שגיאה בכיבוי מנוע זיכרון: {e}")
    
    # Serialization methods
    def _serialize_memory(self, memory: MemoryNode) -> Dict[str, Any]:
        """המרת זיכרון לפורמט JSON"""
        data = {
            "id": memory.id,
            "content": memory.content,
            "memory_type": memory.memory_type.value,
            "priority": memory.priority.value,
            "created_at": memory.created_at.isoformat(),
            "last_accessed": memory.last_accessed.isoformat(),
            "access_count": memory.access_count,
            "related_memories": memory.related_memories,
            "tags": list(memory.tags),
            "keywords": memory.keywords,
            "source": memory.source,
            "context": memory.context,
            "confidence": memory.confidence,
            "decay_rate": memory.decay_rate,
            "relevance_score": memory.relevance_score,
            "emotional_weight": memory.emotional_weight,
            "practical_value": memory.practical_value
        }
        
        if memory.emotional_context:
            data["emotional_context"] = {
                "primary_emotion": memory.emotional_context.primary_emotion.value,
                "secondary_emotions": [e.value for e in memory.emotional_context.secondary_emotions],
                "intensity": memory.emotional_context.intensity,
                "valence": memory.emotional_context.valence,
                "arousal": memory.emotional_context.arousal,
                "confidence": memory.emotional_context.confidence,
                "context_tags": memory.emotional_context.context_tags
            }
        
        return data
    
    def _deserialize_memory(self, data: Dict[str, Any]) -> Optional[MemoryNode]:
        """המרת נתוני JSON לזיכרון"""
        try:
            memory = MemoryNode(
                id=data["id"],
                content=data["content"],
                memory_type=MemoryType(data["memory_type"]),
                priority=MemoryPriority(data["priority"]),
                created_at=datetime.fromisoformat(data["created_at"]),
                last_accessed=datetime.fromisoformat(data["last_accessed"]),
                access_count=data["access_count"],
                related_memories=data["related_memories"],
                tags=set(data["tags"]),
                keywords=data["keywords"],
                source=data["source"],
                context=data["context"],
                confidence=data["confidence"],
                decay_rate=data["decay_rate"],
                relevance_score=data["relevance_score"],
                emotional_weight=data["emotional_weight"],
                practical_value=data["practical_value"]
            )
            
            if "emotional_context" in data and data["emotional_context"]:
                ec_data = data["emotional_context"]
                memory.emotional_context = EmotionalContext(
                    primary_emotion=EmotionalState(ec_data["primary_emotion"]),
                    secondary_emotions=[EmotionalState(e) for e in ec_data["secondary_emotions"]],
                    intensity=ec_data["intensity"],
                    valence=ec_data["valence"],
                    arousal=ec_data["arousal"],
                    confidence=ec_data["confidence"],
                    context_tags=ec_data["context_tags"]
                )
            
            return memory
            
        except Exception as e:
            logger.error(f"שגיאה בהמרת זיכרון: {e}")
            return None
    
    def _serialize_conversation(self, conversation: ConversationMemory) -> Dict[str, Any]:
        """המרת שיחה לפורמט JSON"""
        return {
            "conversation_id": conversation.conversation_id,
            "user_message": conversation.user_message,
            "ai_response": conversation.ai_response,
            "timestamp": conversation.timestamp.isoformat(),
            "context": conversation.context,
            "session_id": conversation.session_id,
            "user_mood": conversation.user_mood.value if conversation.user_mood else None,
            "ai_mood": conversation.ai_mood.value if conversation.ai_mood else None,
            "satisfaction_score": conversation.satisfaction_score,
            "complexity_level": conversation.complexity_level,
            "topics": conversation.topics,
            "entities": conversation.entities,
            "learned_facts": conversation.learned_facts,
            "improvements_needed": conversation.improvements_needed,
            "successful_patterns": conversation.successful_patterns
        }
    
    def _deserialize_conversation(self, data: Dict[str, Any]) -> Optional[ConversationMemory]:
        """המרת נתוני JSON לשיחה"""
        try:
            conversation = ConversationMemory(
                conversation_id=data["conversation_id"],
                user_message=data["user_message"],
                ai_response=data["ai_response"],
                timestamp=datetime.fromisoformat(data["timestamp"]),
                context=data["context"],
                session_id=data["session_id"],
                user_mood=EmotionalState(data["user_mood"]) if data["user_mood"] else None,
                ai_mood=EmotionalState(data["ai_mood"]) if data["ai_mood"] else None,
                satisfaction_score=data["satisfaction_score"],
                complexity_level=data["complexity_level"],
                topics=data["topics"],
                entities=data["entities"],
                learned_facts=data["learned_facts"],
                improvements_needed=data["improvements_needed"],
                successful_patterns=data["successful_patterns"]
            )
            
            return conversation
            
        except Exception as e:
            logger.error(f"שגיאה בהמרת שיחה: {e}")
            return None
    
    def _serialize_insight(self, insight: LearningInsight) -> Dict[str, Any]:
        """המרת תובנה לפורמט JSON"""
        return {
            "insight_id": insight.insight_id,
            "title": insight.title,
            "description": insight.description,
            "category": insight.category,
            "confidence": insight.confidence,
            "impact_level": insight.impact_level,
            "source_memories": insight.source_memories,
            "trigger_event": insight.trigger_event,
            "actionable_steps": insight.actionable_steps,
            "applied": insight.applied,
            "application_results": insight.application_results,
            "discovered_at": insight.discovered_at.isoformat(),
            "applied_at": insight.applied_at.isoformat() if insight.applied_at else None
        }
    
    def _deserialize_insight(self, data: Dict[str, Any]) -> Optional[LearningInsight]:
        """המרת נתוני JSON לתובנה"""
        try:
            insight = LearningInsight(
                insight_id=data["insight_id"],
                title=data["title"],
                description=data["description"],
                category=data["category"],
                confidence=data["confidence"],
                impact_level=data["impact_level"],
                source_memories=data["source_memories"],
                trigger_event=data["trigger_event"],
                actionable_steps=data["actionable_steps"],
                applied=data["applied"],
                application_results=data["application_results"],
                discovered_at=datetime.fromisoformat(data["discovered_at"]),
                applied_at=datetime.fromisoformat(data["applied_at"]) if data["applied_at"] else None
            )
            
            return insight
            
        except Exception as e:
            logger.error(f"שגיאה בהמרת תובנה: {e}")
            return None