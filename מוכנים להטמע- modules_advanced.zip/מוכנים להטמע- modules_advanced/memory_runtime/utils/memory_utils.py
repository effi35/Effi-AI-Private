"""
Memory Runtime Utilities
כלי עזר מתקדמים למערכת הזיכרון והתודעה
"""

import json
import uuid
import hashlib
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set
from datetime import datetime, timedelta
from dataclasses import asdict
import numpy as np
from collections import defaultdict, Counter

from ..models.memory_types import (
    MemoryType, EmotionalState, ConnectionType,
    MemoryNode, ConversationMemory, LearningInsight,
    MemoryConnection, EmotionalContext
)

class MemoryAnalytics:
    """כלי אנליטיקה מתקדמים למערכת הזיכרון"""
    
    @staticmethod
    def calculate_memory_similarity(mem1: MemoryNode, mem2: MemoryNode) -> float:
        """מחשב דמיון בין שני זיכרונות"""
        try:
            # דמיון תוכן (בסיסי)
            content_sim = MemoryAnalytics._text_similarity(mem1.content, mem2.content)
            
            # דמיון רגשי
            emotional_sim = MemoryAnalytics._emotional_similarity(
                getattr(mem1, 'emotional_context', None),
                getattr(mem2, 'emotional_context', None)
            )
            
            # דמיון זמני
            temporal_sim = MemoryAnalytics._temporal_similarity(mem1.timestamp, mem2.timestamp)
            
            # דמיון חשיבות
            importance_sim = 1.0 - abs(mem1.importance_score - mem2.importance_score)
            
            # ממוצע משוקלל
            total_similarity = (
                content_sim * 0.4 +
                emotional_sim * 0.3 +
                temporal_sim * 0.2 +
                importance_sim * 0.1
            )
            
            return round(total_similarity, 3)
            
        except Exception as e:
            return 0.0
    
    @staticmethod
    def _text_similarity(text1: str, text2: str) -> float:
        """מחשב דמיון טקסט פשוט"""
        if not text1 or not text2:
            return 0.0
        
        # פיצול למילים
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        # חישוב Jaccard similarity
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        return intersection / union if union > 0 else 0.0
    
    @staticmethod
    def _emotional_similarity(ctx1: Optional[EmotionalContext], 
                            ctx2: Optional[EmotionalContext]) -> float:
        """מחשב דמיון רגשי"""
        if not ctx1 or not ctx2:
            return 0.5  # נייטרלי אם אין מידע רגשי
        
        # דמיון רגש ראשי
        emotion_match = 1.0 if ctx1.primary_emotion == ctx2.primary_emotion else 0.0
        
        # דמיון עוצמה
        intensity_sim = 1.0 - abs(ctx1.intensity - ctx2.intensity)
        
        # דמיון רגשות משניים
        secondary_sim = 0.0
        if ctx1.secondary_emotions and ctx2.secondary_emotions:
            common_emotions = set(ctx1.secondary_emotions).intersection(set(ctx2.secondary_emotions))
            total_emotions = set(ctx1.secondary_emotions).union(set(ctx2.secondary_emotions))
            secondary_sim = len(common_emotions) / len(total_emotions) if total_emotions else 0.0
        
        return (emotion_match * 0.5 + intensity_sim * 0.3 + secondary_sim * 0.2)
    
    @staticmethod
    def _temporal_similarity(time1: datetime, time2: datetime) -> float:
        """מחשב דמיון זמני"""
        time_diff = abs((time1 - time2).total_seconds())
        
        # זיכרונות קרובים בזמן יותר דומים
        if time_diff < 3600:  # שעה
            return 1.0
        elif time_diff < 86400:  # יום
            return 0.8
        elif time_diff < 604800:  # שבוע
            return 0.6
        elif time_diff < 2592000:  # חודש
            return 0.4
        else:
            return 0.2
    
    @staticmethod
    def find_memory_patterns(memories: List[MemoryNode]) -> Dict[str, Any]:
        """מוצא דפוסים בזיכרונות"""
        patterns = {
            "temporal_patterns": MemoryAnalytics._find_temporal_patterns(memories),
            "emotional_patterns": MemoryAnalytics._find_emotional_patterns(memories),
            "content_patterns": MemoryAnalytics._find_content_patterns(memories),
            "importance_patterns": MemoryAnalytics._find_importance_patterns(memories)
        }
        
        return patterns
    
    @staticmethod
    def _find_temporal_patterns(memories: List[MemoryNode]) -> Dict[str, Any]:
        """מוצא דפוסים זמניים"""
        if not memories:
            return {}
        
        # חלוקה לפי שעות ביום
        hours_distribution = defaultdict(int)
        days_distribution = defaultdict(int)
        
        for memory in memories:
            hours_distribution[memory.timestamp.hour] += 1
            days_distribution[memory.timestamp.strftime("%A")] += 1
        
        peak_hour = max(hours_distribution.items(), key=lambda x: x[1])[0] if hours_distribution else None
        peak_day = max(days_distribution.items(), key=lambda x: x[1])[0] if days_distribution else None
        
        return {
            "peak_hour": peak_hour,
            "peak_day": peak_day,
            "hours_distribution": dict(hours_distribution),
            "days_distribution": dict(days_distribution)
        }
    
    @staticmethod
    def _find_emotional_patterns(memories: List[MemoryNode]) -> Dict[str, Any]:
        """מוצא דפוסים רגשיים"""
        emotional_sequences = []
        emotion_transitions = defaultdict(int)
        
        for i, memory in enumerate(memories):
            if hasattr(memory, 'emotional_context') and memory.emotional_context:
                current_emotion = memory.emotional_context.primary_emotion
                emotional_sequences.append(current_emotion)
                
                if i > 0 and hasattr(memories[i-1], 'emotional_context') and memories[i-1].emotional_context:
                    prev_emotion = memories[i-1].emotional_context.primary_emotion
                    transition = f"{prev_emotion.value} -> {current_emotion.value}"
                    emotion_transitions[transition] += 1
        
        most_common_transition = max(emotion_transitions.items(), key=lambda x: x[1])[0] if emotion_transitions else None
        
        return {
            "emotional_sequences": [e.value for e in emotional_sequences],
            "most_common_transition": most_common_transition,
            "transition_patterns": dict(emotion_transitions)
        }
    
    @staticmethod
    def _find_content_patterns(memories: List[MemoryNode]) -> Dict[str, Any]:
        """מוצא דפוסים בתוכן"""
        all_words = []
        for memory in memories:
            words = memory.content.lower().split()
            all_words.extend(words)
        
        word_freq = Counter(all_words)
        common_words = word_freq.most_common(10)
        
        return {
            "most_common_words": common_words,
            "total_words": len(all_words),
            "unique_words": len(set(all_words))
        }
    
    @staticmethod
    def _find_importance_patterns(memories: List[MemoryNode]) -> Dict[str, Any]:
        """מוצא דפוסים בחשיבות"""
        importance_scores = [mem.importance_score for mem in memories]
        
        if not importance_scores:
            return {}
        
        avg_importance = sum(importance_scores) / len(importance_scores)
        high_importance = sum(1 for score in importance_scores if score > 0.8)
        low_importance = sum(1 for score in importance_scores if score < 0.3)
        
        return {
            "average_importance": round(avg_importance, 3),
            "high_importance_count": high_importance,
            "low_importance_count": low_importance,
            "importance_distribution": {
                "high": high_importance,
                "medium": len(importance_scores) - high_importance - low_importance,
                "low": low_importance
            }
        }

class MemoryOptimizer:
    """מטמח ביצועי מערכת הזיכרון"""
    
    @staticmethod
    async def optimize_memory_connections(memories: Dict[str, MemoryNode]) -> Dict[str, MemoryNode]:
        """מטמח קשרים בין זיכרונות"""
        optimized_memories = {}
        
        for memory_id, memory in memories.items():
            optimized_memory = memory
            
            # הסרת קשרים חלשים
            strong_connections = [
                conn for conn in memory.connections 
                if conn.connection_strength > 0.3
            ]
            
            optimized_memory.connections = strong_connections
            optimized_memories[memory_id] = optimized_memory
        
        return optimized_memories
    
    @staticmethod
    async def consolidate_similar_memories(memories: List[MemoryNode], 
                                         threshold: float = 0.8) -> List[MemoryNode]:
        """מאחד זיכרונות דומים"""
        consolidated = []
        processed_ids = set()
        
        for i, memory1 in enumerate(memories):
            if memory1.memory_id in processed_ids:
                continue
            
            similar_memories = [memory1]
            
            for j, memory2 in enumerate(memories[i+1:], i+1):
                if memory2.memory_id in processed_ids:
                    continue
                
                similarity = MemoryAnalytics.calculate_memory_similarity(memory1, memory2)
                
                if similarity >= threshold:
                    similar_memories.append(memory2)
                    processed_ids.add(memory2.memory_id)
            
            if len(similar_memories) > 1:
                # יצירת זיכרון מאוחד
                consolidated_memory = await MemoryOptimizer._create_consolidated_memory(similar_memories)
                consolidated.append(consolidated_memory)
            else:
                consolidated.append(memory1)
            
            processed_ids.add(memory1.memory_id)
        
        return consolidated
    
    @staticmethod
    async def _create_consolidated_memory(memories: List[MemoryNode]) -> MemoryNode:
        """יוצר זיכרון מאוחד ממספר זיכרונות"""
        # משלב תוכן
        combined_content = " | ".join([mem.content for mem in memories])
        
        # ממוצע חשיבות
        avg_importance = sum(mem.importance_score for mem in memories) / len(memories)
        
        # זמן הזיכרון הראשון
        earliest_time = min(mem.timestamp for mem in memories)
        
        # זיכרון הכי חשוב כבסיס
        base_memory = max(memories, key=lambda m: m.importance_score)
        
        # יצירת זיכרון מאוחד
        consolidated = MemoryNode(
            memory_id=str(uuid.uuid4()),
            content=combined_content,
            memory_type=base_memory.memory_type,
            importance_score=avg_importance,
            timestamp=earliest_time,
            connections=[],
            metadata={
                "consolidated": True,
                "original_memory_ids": [mem.memory_id for mem in memories],
                "consolidation_time": datetime.now().isoformat()
            }
        )
        
        return consolidated

class MemoryExporter:
    """יצוא וגיבוי זיכרונות"""
    
    @staticmethod
    async def export_memories_to_json(memories: Dict[str, MemoryNode], 
                                    filepath: str) -> bool:
        """מייצא זיכרונות לקובץ JSON"""
        try:
            exportable_data = {
                "export_timestamp": datetime.now().isoformat(),
                "memories_count": len(memories),
                "memories": {}
            }
            
            for memory_id, memory in memories.items():
                memory_dict = {
                    "memory_id": memory.memory_id,
                    "content": memory.content,
                    "memory_type": memory.memory_type.value,
                    "importance_score": memory.importance_score,
                    "timestamp": memory.timestamp.isoformat(),
                    "connections": [
                        {
                            "connected_memory_id": conn.connected_memory_id,
                            "connection_type": conn.connection_type.value,
                            "connection_strength": conn.connection_strength,
                            "created_at": conn.created_at.isoformat()
                        }
                        for conn in memory.connections
                    ],
                    "metadata": memory.metadata or {}
                }
                
                # הוספת מידע רגשי אם קיים
                if hasattr(memory, 'emotional_context') and memory.emotional_context:
                    memory_dict["emotional_context"] = {
                        "primary_emotion": memory.emotional_context.primary_emotion.value,
                        "intensity": memory.emotional_context.intensity,
                        "secondary_emotions": [e.value for e in memory.emotional_context.secondary_emotions] if memory.emotional_context.secondary_emotions else [],
                        "triggers": memory.emotional_context.triggers or [],
                        "context_metadata": memory.emotional_context.context_metadata or {}
                    }
                
                exportable_data["memories"][memory_id] = memory_dict
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(exportable_data, f, ensure_ascii=False, indent=2)
            
            return True
            
        except Exception as e:
            print(f"שגיאה בייצוא זיכרונות: {str(e)}")
            return False
    
    @staticmethod
    async def import_memories_from_json(filepath: str) -> Optional[Dict[str, MemoryNode]]:
        """מייבא זיכרונות מקובץ JSON"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            imported_memories = {}
            
            for memory_id, memory_data in data.get("memories", {}).items():
                # יצירת חיבורים
                connections = []
                for conn_data in memory_data.get("connections", []):
                    connection = MemoryConnection(
                        connected_memory_id=conn_data["connected_memory_id"],
                        connection_type=ConnectionType(conn_data["connection_type"]),
                        connection_strength=conn_data["connection_strength"],
                        created_at=datetime.fromisoformat(conn_data["created_at"])
                    )
                    connections.append(connection)
                
                # יצירת הקשר רגשי אם קיים
                emotional_context = None
                if "emotional_context" in memory_data:
                    ec_data = memory_data["emotional_context"]
                    emotional_context = EmotionalContext(
                        primary_emotion=EmotionalState(ec_data["primary_emotion"]),
                        intensity=ec_data["intensity"],
                        secondary_emotions=[EmotionalState(e) for e in ec_data.get("secondary_emotions", [])],
                        triggers=ec_data.get("triggers", []),
                        context_metadata=ec_data.get("context_metadata", {})
                    )
                
                # יצירת זיכרון
                memory = MemoryNode(
                    memory_id=memory_data["memory_id"],
                    content=memory_data["content"],
                    memory_type=MemoryType(memory_data["memory_type"]),
                    importance_score=memory_data["importance_score"],
                    timestamp=datetime.fromisoformat(memory_data["timestamp"]),
                    connections=connections,
                    metadata=memory_data.get("metadata", {})
                )
                
                # הוספת הקשר רגשי
                if emotional_context:
                    memory.emotional_context = emotional_context
                
                imported_memories[memory_id] = memory
            
            return imported_memories
            
        except Exception as e:
            print(f"שגיאה בייבוא זיכרונות: {str(e)}")
            return None

class MemorySearch:
    """חיפוש מתקדם בזיכרונות"""
    
    @staticmethod
    async def search_memories(memories: Dict[str, MemoryNode], 
                            query: str,
                            filters: Optional[Dict[str, Any]] = None) -> List[MemoryNode]:
        """חיפוש מתקדם בזיכרונות"""
        results = []
        query_lower = query.lower()
        
        for memory in memories.values():
            # חיפוש בתוכן
            content_match = query_lower in memory.content.lower()
            
            # בדיקת פילטרים
            if filters:
                if not MemorySearch._apply_filters(memory, filters):
                    continue
            
            if content_match:
                # חישוב ציון רלוונטיות
                relevance_score = MemorySearch._calculate_relevance(memory, query)
                memory.metadata = memory.metadata or {}
                memory.metadata["search_relevance"] = relevance_score
                results.append(memory)
        
        # מיון לפי רלוונטיות וחשיבות
        results.sort(key=lambda m: (
            m.metadata.get("search_relevance", 0),
            m.importance_score
        ), reverse=True)
        
        return results
    
    @staticmethod
    def _apply_filters(memory: MemoryNode, filters: Dict[str, Any]) -> bool:
        """מיישם פילטרים על זיכרון"""
        # פילטר סוג זיכרון
        if "memory_type" in filters and memory.memory_type.value not in filters["memory_type"]:
            return False
        
        # פילטר חשיבות
        if "min_importance" in filters and memory.importance_score < filters["min_importance"]:
            return False
        
        # פילטר זמן
        if "start_date" in filters:
            start_date = datetime.fromisoformat(filters["start_date"])
            if memory.timestamp < start_date:
                return False
        
        if "end_date" in filters:
            end_date = datetime.fromisoformat(filters["end_date"])
            if memory.timestamp > end_date:
                return False
        
        # פילטר רגשי
        if "emotional_state" in filters and hasattr(memory, 'emotional_context') and memory.emotional_context:
            if memory.emotional_context.primary_emotion.value not in filters["emotional_state"]:
                return False
        
        return True
    
    @staticmethod
    def _calculate_relevance(memory: MemoryNode, query: str) -> float:
        """מחשב ציון רלוונטיות"""
        query_words = set(query.lower().split())
        content_words = set(memory.content.lower().split())
        
        # חישוב overlap
        overlap = len(query_words.intersection(content_words))
        query_coverage = overlap / len(query_words) if query_words else 0
        
        # שילוב עם חשיבות הזיכרון
        relevance = (query_coverage * 0.7) + (memory.importance_score * 0.3)
        
        return round(relevance, 3)

class MemoryCache:
    """מטמון לביצועים מהירים"""
    
    def __init__(self, max_size: int = 1000):
        self.cache = {}
        self.access_times = {}
        self.max_size = max_size
    
    async def get(self, key: str) -> Optional[Any]:
        """מחזיר פריט מהמטמון"""
        if key in self.cache:
            self.access_times[key] = datetime.now()
            return self.cache[key]
        return None
    
    async def set(self, key: str, value: Any) -> None:
        """מוסיף פריט למטמון"""
        if len(self.cache) >= self.max_size:
            await self._evict_oldest()
        
        self.cache[key] = value
        self.access_times[key] = datetime.now()
    
    async def _evict_oldest(self) -> None:
        """מסיר הפריט הישן ביותר"""
        if self.access_times:
            oldest_key = min(self.access_times.items(), key=lambda x: x[1])[0]
            del self.cache[oldest_key]
            del self.access_times[oldest_key]
    
    async def clear(self) -> None:
        """מנקה את המטמון"""
        self.cache.clear()
        self.access_times.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """מחזיר סטטיסטיקות מטמון"""
        return {
            "cache_size": len(self.cache),
            "max_size": self.max_size,
            "cache_usage": len(self.cache) / self.max_size
        }