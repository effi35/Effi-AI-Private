#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מנוע אופטימיזציה Types - סוגי נתונים עבור מנוע אופטימיזציה
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum


@dataclass
class OptimizationEngineConfig:
    """תצורת מנוע אופטימיזציה"""
    enabled: bool = True
    max_concurrent_operations: int = 10
    timeout_seconds: int = 30
    logging_level: str = "INFO"
    custom_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OptimizationEngineResult:
    """תוצאת פעולה של מנוע אופטימיזציה"""
    success: bool
    data: Any = None
    error_message: str = ""
    execution_time: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class OptimizationEngineStatistics:
    """סטטיסטיקות מנוע אופטימיזציה"""
    total_operations: int = 0
    successful_operations: int = 0
    failed_operations: int = 0
    average_execution_time: float = 0.0
    uptime_seconds: int = 0
    last_operation: Optional[str] = None
