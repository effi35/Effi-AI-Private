"""
System Control Models
מודלי שליטת מערכת

Complete system control capabilities for Raspberry Pi and general systems.
יכולות שליטת מערכת מלאות עבור Raspberry Pi ומערכות כלליות.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
from enum import Enum
import json

class SystemResourceType(Enum):
    """System resource types"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK = "disk"
    NETWORK = "network"
    GPU = "gpu"
    GPIO = "gpio"
    CAMERA = "camera"
    MICROPHONE = "microphone"
    SENSORS = "sensors"

class ProcessState(Enum):
    """Process states"""
    RUNNING = "running"      # רץ
    SLEEPING = "sleeping"    # ישן
    STOPPED = "stopped"      # עצור
    ZOMBIE = "zombie"        # זומבי
    DEAD = "dead"           # מת

class ServiceState(Enum):
    """Service states"""
    ACTIVE = "active"        # פעיל
    INACTIVE = "inactive"    # לא פעיל
    FAILED = "failed"        # נכשל
    STARTING = "starting"    # מתחיל
    STOPPING = "stopping"    # נעצר

@dataclass
class SystemResource:
    """
    System resource information
    מידע משאב מערכת
    """
    resource_type: SystemResourceType
    current_usage: float  # percentage or absolute value
    max_capacity: float
    available: float
    unit: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    last_updated: datetime = field(default_factory=datetime.now)
    
    def get_usage_percentage(self) -> float:
        """Get usage as percentage"""
        if self.max_capacity > 0:
            return (self.current_usage / self.max_capacity) * 100
        return 0.0
    
    def is_critical(self, threshold: float = 90.0) -> bool:
        """Check if usage is critical"""
        return self.get_usage_percentage() > threshold
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'resource_type': self.resource_type.value,
            'current_usage': self.current_usage,
            'max_capacity': self.max_capacity,
            'available': self.available,
            'unit': self.unit,
            'usage_percentage': self.get_usage_percentage(),
            'is_critical': self.is_critical(),
            'details': self.details,
            'last_updated': self.last_updated.isoformat()
        }

@dataclass
class ProcessInfo:
    """
    Process information
    מידע תהליך
    """
    pid: int
    name: str
    state: ProcessState
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_mb: float = 0.0
    started_at: Optional[datetime] = None
    command_line: str = ""
    user: str = ""
    parent_pid: Optional[int] = None
    children_pids: List[int] = field(default_factory=list)
    open_files: List[str] = field(default_factory=list)
    network_connections: List[Dict[str, Any]] = field(default_factory=list)
    environment: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'pid': self.pid,
            'name': self.name,
            'state': self.state.value,
            'cpu_percent': self.cpu_percent,
            'memory_percent': self.memory_percent,
            'memory_mb': self.memory_mb,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'command_line': self.command_line,
            'user': self.user,
            'parent_pid': self.parent_pid,
            'children_pids': self.children_pids,
            'open_files': self.open_files,
            'network_connections': self.network_connections,
            'environment': self.environment
        }

@dataclass
class ServiceInfo:
    """
    System service information
    מידע שירות מערכת
    """
    name: str
    state: ServiceState
    enabled: bool = False
    description: str = ""
    main_pid: Optional[int] = None
    load_state: str = ""
    active_state: str = ""
    sub_state: str = ""
    unit_file_state: str = ""
    started_at: Optional[datetime] = None
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    restart_count: int = 0
    dependencies: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'name': self.name,
            'state': self.state.value,
            'enabled': self.enabled,
            'description': self.description,
            'main_pid': self.main_pid,
            'load_state': self.load_state,
            'active_state': self.active_state,
            'sub_state': self.sub_state,
            'unit_file_state': self.unit_file_state,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'memory_usage': self.memory_usage,
            'cpu_usage': self.cpu_usage,
            'restart_count': self.restart_count,
            'dependencies': self.dependencies,
            'conflicts': self.conflicts
        }

@dataclass
class NetworkInterface:
    """
    Network interface information
    מידע ממשק רשת
    """
    name: str
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    is_up: bool = False
    speed: Optional[int] = None  # Mbps
    duplex: str = ""
    mtu: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    packets_sent: int = 0
    packets_received: int = 0
    errors_in: int = 0
    errors_out: int = 0
    drops_in: int = 0
    drops_out: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'name': self.name,
            'ip_address': self.ip_address,
            'mac_address': self.mac_address,
            'is_up': self.is_up,
            'speed': self.speed,
            'duplex': self.duplex,
            'mtu': self.mtu,
            'bytes_sent': self.bytes_sent,
            'bytes_received': self.bytes_received,
            'packets_sent': self.packets_sent,
            'packets_received': self.packets_received,
            'errors_in': self.errors_in,
            'errors_out': self.errors_out,
            'drops_in': self.drops_in,
            'drops_out': self.drops_out
        }

@dataclass
class SystemController:
    """
    Main system controller for comprehensive system management
    בקר מערכת ראשי לניהול מערכת מקיף
    """
    system_info: Dict[str, Any] = field(default_factory=dict)
    resources: Dict[SystemResourceType, SystemResource] = field(default_factory=dict)
    processes: Dict[int, ProcessInfo] = field(default_factory=dict)
    services: Dict[str, ServiceInfo] = field(default_factory=dict)
    network_interfaces: Dict[str, NetworkInterface] = field(default_factory=dict)
    last_updated: datetime = field(default_factory=datetime.now)
    
    def add_resource(self, resource: SystemResource):
        """Add or update system resource"""
        self.resources[resource.resource_type] = resource
        self.last_updated = datetime.now()
    
    def add_process(self, process: ProcessInfo):
        """Add or update process"""
        self.processes[process.pid] = process
        self.last_updated = datetime.now()
    
    def add_service(self, service: ServiceInfo):
        """Add or update service"""
        self.services[service.name] = service
        self.last_updated = datetime.now()
    
    def add_network_interface(self, interface: NetworkInterface):
        """Add or update network interface"""
        self.network_interfaces[interface.name] = interface
        self.last_updated = datetime.now()
    
    def get_critical_resources(self, threshold: float = 90.0) -> List[SystemResource]:
        """Get resources with critical usage"""
        return [resource for resource in self.resources.values() 
                if resource.is_critical(threshold)]
    
    def get_running_processes(self) -> List[ProcessInfo]:
        """Get all running processes"""
        return [proc for proc in self.processes.values() 
                if proc.state == ProcessState.RUNNING]
    
    def get_active_services(self) -> List[ServiceInfo]:
        """Get all active services"""
        return [service for service in self.services.values() 
                if service.state == ServiceState.ACTIVE]
    
    def get_network_traffic_summary(self) -> Dict[str, int]:
        """Get network traffic summary"""
        total_sent = sum(iface.bytes_sent for iface in self.network_interfaces.values())
        total_received = sum(iface.bytes_received for iface in self.network_interfaces.values())
        total_errors = sum(iface.errors_in + iface.errors_out for iface in self.network_interfaces.values())
        
        return {
            'total_sent': total_sent,
            'total_received': total_received,
            'total_errors': total_errors,
            'active_interfaces': len([iface for iface in self.network_interfaces.values() if iface.is_up])
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'system_info': self.system_info,
            'resources': {k.value: v.to_dict() for k, v in self.resources.items()},
            'processes': {k: v.to_dict() for k, v in self.processes.items()},
            'services': {k: v.to_dict() for k, v in self.services.items()},
            'network_interfaces': {k: v.to_dict() for k, v in self.network_interfaces.items()},
            'last_updated': self.last_updated.isoformat(),
            'summary': {
                'critical_resources': len(self.get_critical_resources()),
                'running_processes': len(self.get_running_processes()),
                'active_services': len(self.get_active_services()),
                'network_traffic': self.get_network_traffic_summary()
            }
        }

@dataclass
class ProcessManager:
    """
    Process management operations
    פעולות ניהול תהליכים
    """
    managed_processes: Dict[str, ProcessInfo] = field(default_factory=dict)
    process_history: List[Dict[str, Any]] = field(default_factory=list)
    
    def start_process(self, command: str, name: str = "", background: bool = False) -> Dict[str, Any]:
        """Start new process"""
        operation = {
            'action': 'start_process',
            'command': command,
            'name': name,
            'background': background,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.process_history.append(operation)
        return operation
    
    def stop_process(self, pid: int, force: bool = False) -> Dict[str, Any]:
        """Stop process"""
        operation = {
            'action': 'stop_process',
            'pid': pid,
            'force': force,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.process_history.append(operation)
        return operation
    
    def restart_process(self, pid: int) -> Dict[str, Any]:
        """Restart process"""
        operation = {
            'action': 'restart_process',
            'pid': pid,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.process_history.append(operation)
        return operation

@dataclass
class ServiceManager:
    """
    System service management
    ניהול שירותי מערכת
    """
    managed_services: Dict[str, ServiceInfo] = field(default_factory=dict)
    service_history: List[Dict[str, Any]] = field(default_factory=list)
    
    def start_service(self, service_name: str) -> Dict[str, Any]:
        """Start system service"""
        operation = {
            'action': 'start_service',
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.service_history.append(operation)
        return operation
    
    def stop_service(self, service_name: str) -> Dict[str, Any]:
        """Stop system service"""
        operation = {
            'action': 'stop_service',
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.service_history.append(operation)
        return operation
    
    def restart_service(self, service_name: str) -> Dict[str, Any]:
        """Restart system service"""
        operation = {
            'action': 'restart_service',
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.service_history.append(operation)
        return operation
    
    def enable_service(self, service_name: str) -> Dict[str, Any]:
        """Enable service to start on boot"""
        operation = {
            'action': 'enable_service',
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.service_history.append(operation)
        return operation
    
    def disable_service(self, service_name: str) -> Dict[str, Any]:
        """Disable service from starting on boot"""
        operation = {
            'action': 'disable_service',
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        self.service_history.append(operation)
        return operation