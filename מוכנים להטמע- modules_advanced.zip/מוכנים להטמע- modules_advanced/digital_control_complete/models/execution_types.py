"""
Execution Types for Digital Control
סוגי הרצה לשליטה דיגיטלית

Comprehensive execution types for complete digital control capabilities.
סוגי הרצה מקיפים ליכולות שליטה דיגיטלית מלאה.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
from enum import Enum
import json

class ExecutionLanguage(Enum):
    """Supported execution languages"""
    PYTHON = "python"
    BASH = "bash"
    JAVASCRIPT = "javascript"
    HTML = "html"
    CSS = "css"
    SQL = "sql"
    POWERSHELL = "powershell"
    BATCH = "batch"

class ExecutionMode(Enum):
    """Execution modes"""
    SAFE = "safe"           # בטוח
    INTERACTIVE = "interactive"  # אינטרקטיבי
    BACKGROUND = "background"    # רקע
    REAL_TIME = "real_time"     # זמן אמת
    SCHEDULED = "scheduled"     # מתוזמן

class ExecutionPriority(Enum):
    """Execution priorities"""
    LOW = "low"         # נמוך
    NORMAL = "normal"   # רגיל
    HIGH = "high"       # גבוה
    URGENT = "urgent"   # דחוף
    CRITICAL = "critical"  # קריטי

@dataclass
class ExecutionContext:
    """
    Execution context with environment and constraints
    הקשר הרצה עם סביבה ומגבלות
    """
    working_directory: str = "/"
    environment_variables: Dict[str, str] = field(default_factory=dict)
    resource_limits: Dict[str, Any] = field(default_factory=dict)
    security_constraints: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 300
    max_memory_mb: int = 1024
    max_cpu_percent: float = 80.0
    allow_network: bool = True
    allow_file_system: bool = True
    allow_system_calls: bool = False
    sandbox_enabled: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'working_directory': self.working_directory,
            'environment_variables': self.environment_variables,
            'resource_limits': self.resource_limits,
            'security_constraints': self.security_constraints,
            'timeout_seconds': self.timeout_seconds,
            'max_memory_mb': self.max_memory_mb,
            'max_cpu_percent': self.max_cpu_percent,
            'allow_network': self.allow_network,
            'allow_file_system': self.allow_file_system,
            'allow_system_calls': self.allow_system_calls,
            'sandbox_enabled': self.sandbox_enabled
        }

@dataclass
class ExecutionRequest:
    """
    Complete execution request with full control
    בקשת הרצה מלאה עם שליטה מלאה
    """
    request_id: str
    language: ExecutionLanguage
    code: str
    mode: ExecutionMode = ExecutionMode.SAFE
    priority: ExecutionPriority = ExecutionPriority.NORMAL
    context: ExecutionContext = field(default_factory=ExecutionContext)
    description: str = ""
    description_hebrew: str = ""
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    expected_output: Optional[str] = None
    input_data: Optional[Dict[str, Any]] = None
    schedule_time: Optional[datetime] = None
    repeat_interval: Optional[int] = None  # seconds
    max_retries: int = 3
    on_success: Optional[str] = None  # callback code
    on_failure: Optional[str] = None  # callback code
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'request_id': self.request_id,
            'language': self.language.value,
            'code': self.code,
            'mode': self.mode.value,
            'priority': self.priority.value,
            'context': self.context.to_dict(),
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'tags': self.tags,
            'dependencies': self.dependencies,
            'expected_output': self.expected_output,
            'input_data': self.input_data,
            'schedule_time': self.schedule_time.isoformat() if self.schedule_time else None,
            'repeat_interval': self.repeat_interval,
            'max_retries': self.max_retries,
            'on_success': self.on_success,
            'on_failure': self.on_failure,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExecutionRequest':
        """Create from dictionary"""
        context_data = data.get('context', {})
        context = ExecutionContext(**context_data)
        
        return cls(
            request_id=data['request_id'],
            language=ExecutionLanguage(data['language']),
            code=data['code'],
            mode=ExecutionMode(data.get('mode', 'safe')),
            priority=ExecutionPriority(data.get('priority', 'normal')),
            context=context,
            description=data.get('description', ''),
            description_hebrew=data.get('description_hebrew', ''),
            tags=data.get('tags', []),
            dependencies=data.get('dependencies', []),
            expected_output=data.get('expected_output'),
            input_data=data.get('input_data'),
            schedule_time=datetime.fromisoformat(data['schedule_time']) if data.get('schedule_time') else None,
            repeat_interval=data.get('repeat_interval'),
            max_retries=data.get('max_retries', 3),
            on_success=data.get('on_success'),
            on_failure=data.get('on_failure'),
            metadata=data.get('metadata', {}),
            created_at=datetime.fromisoformat(data['created_at'])
        )

@dataclass
class ExecutionMetrics:
    """
    Execution performance metrics
    מדדי ביצועי הרצה
    """
    execution_time: float = 0.0
    cpu_usage: float = 0.0
    memory_usage: int = 0  # bytes
    network_usage: int = 0  # bytes
    disk_usage: int = 0    # bytes
    api_calls: int = 0
    file_operations: int = 0
    system_calls: int = 0
    error_count: int = 0
    warning_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'execution_time': self.execution_time,
            'cpu_usage': self.cpu_usage,
            'memory_usage': self.memory_usage,
            'network_usage': self.network_usage,
            'disk_usage': self.disk_usage,
            'api_calls': self.api_calls,
            'file_operations': self.file_operations,
            'system_calls': self.system_calls,
            'error_count': self.error_count,
            'warning_count': self.warning_count
        }

@dataclass
class ExecutionResult:
    """
    Complete execution result with metrics and analysis
    תוצאת הרצה מלאה עם מדדים וניתוח
    """
    request_id: str
    success: bool
    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""
    output_data: Optional[Dict[str, Any]] = None
    execution_metrics: ExecutionMetrics = field(default_factory=ExecutionMetrics)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    duration: float = 0.0
    error_message: str = ""
    warning_messages: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)  # created files, images, etc
    logs: List[str] = field(default_factory=list)
    security_violations: List[str] = field(default_factory=list)
    resource_violations: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    next_actions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def mark_completed(self, success: bool = True):
        """Mark execution as completed"""
        self.end_time = datetime.now()
        self.duration = (self.end_time - self.start_time).total_seconds()
        self.success = success
    
    def add_artifact(self, file_path: str, description: str = ""):
        """Add created artifact"""
        self.artifacts.append({
            'path': file_path,
            'description': description,
            'created_at': datetime.now().isoformat()
        })
    
    def add_log(self, message: str, level: str = "info"):
        """Add log message"""
        self.logs.append({
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message
        })
    
    def add_security_violation(self, violation: str):
        """Add security violation"""
        self.security_violations.append({
            'timestamp': datetime.now().isoformat(),
            'violation': violation
        })
    
    def add_suggestion(self, suggestion: str):
        """Add improvement suggestion"""
        self.suggestions.append(suggestion)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'request_id': self.request_id,
            'success': self.success,
            'exit_code': self.exit_code,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'output_data': self.output_data,
            'execution_metrics': self.execution_metrics.to_dict(),
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': self.duration,
            'error_message': self.error_message,
            'warning_messages': self.warning_messages,
            'artifacts': self.artifacts,
            'logs': self.logs,
            'security_violations': self.security_violations,
            'resource_violations': self.resource_violations,
            'suggestions': self.suggestions,
            'next_actions': self.next_actions,
            'metadata': self.metadata
        }
    
    def get_summary(self) -> str:
        """Get execution summary in Hebrew"""
        status = "הצליח" if self.success else "נכשל"
        duration_str = f"{self.duration:.2f}s"
        
        summary = f"הרצה {status} תוך {duration_str}"
        
        if self.execution_metrics.cpu_usage > 0:
            summary += f" | CPU: {self.execution_metrics.cpu_usage:.1f}%"
        
        if self.execution_metrics.memory_usage > 0:
            memory_mb = self.execution_metrics.memory_usage / 1024 / 1024
            summary += f" | זיכרון: {memory_mb:.1f}MB"
        
        if self.error_message:
            summary += f" | שגיאה: {self.error_message}"
        
        return summary

# Utility functions for execution types
def create_python_request(code: str, description: str = "", **kwargs) -> ExecutionRequest:
    """Create Python execution request"""
    return ExecutionRequest(
        request_id=f"python_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        language=ExecutionLanguage.PYTHON,
        code=code,
        description=description,
        **kwargs
    )

def create_bash_request(command: str, description: str = "", **kwargs) -> ExecutionRequest:
    """Create Bash execution request"""
    return ExecutionRequest(
        request_id=f"bash_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        language=ExecutionLanguage.BASH,
        code=command,
        description=description,
        **kwargs
    )

def create_web_interface_request(html: str, css: str = "", js: str = "", 
                                description: str = "", **kwargs) -> ExecutionRequest:
    """Create web interface execution request"""
    code = f"""
<!DOCTYPE html>
<html>
<head>
    <style>{css}</style>
</head>
<body>
    {html}
    <script>{js}</script>
</body>
</html>
"""
    return ExecutionRequest(
        request_id=f"web_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        language=ExecutionLanguage.HTML,
        code=code,
        description=description,
        **kwargs
    )