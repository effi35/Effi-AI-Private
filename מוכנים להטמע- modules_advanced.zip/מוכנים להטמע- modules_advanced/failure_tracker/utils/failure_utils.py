"""
כלי ניתוח כשלים - Failure Analysis Utils
כלים מתקדמים לניתוח, זיהוי דפוסים ויצירת דוחות על כשלים במערכת
"""

import re
import json
import smtplib
import logging
import statistics
import numpy as np
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from dataclasses import dataclass, field
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob
from sklearn.cluster import DBSCAN
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd

from ..models.failure_types import (
    FailureEvent, FailureCategory, FailureSeverity, FailurePattern,
    RecoveryAction, SystemState, FailureContext
)


@dataclass
class AnalysisResult:
    """תוצאות ניתוח כשלים"""
    analysis_type: str
    timestamp: datetime
    summary: str
    insights: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    confidence_score: float = 0.0
    priority: str = "medium"


@dataclass
class AlertRule:
    """חוק התראה"""
    id: str
    name: str
    description: str
    condition: str  # Python expression
    severity: FailureSeverity
    enabled: bool = True
    cooldown_minutes: int = 60
    last_triggered: Optional[datetime] = None
    recipients: List[str] = field(default_factory=list)


class HebrewLocalizer:
    """מקמח עברית"""
    
    def __init__(self):
        self.translations = {
            # ימים ושעות
            'Monday': 'יום שני',
            'Tuesday': 'יום שלישי', 
            'Wednesday': 'יום רביעי',
            'Thursday': 'יום חמישי',
            'Friday': 'יום שישי',
            'Saturday': 'שבת',
            'Sunday': 'יום ראשון',
            
            # חודשים
            'January': 'ינואר',
            'February': 'פברואר',
            'March': 'מרץ',
            'April': 'אפריל',
            'May': 'מאי',
            'June': 'יוני',
            'July': 'יולי',
            'August': 'אוגוסט',
            'September': 'ספטמבר',
            'October': 'אוקטובר',
            'November': 'נובמבר',
            'December': 'דצמבר',
            
            # קטגוריות כשלים
            'CODE_EXECUTION': 'ביצוע קוד',
            'API_CALL': 'קריאת API',
            'SYSTEM_OPERATION': 'פעולת מערכת',
            'PERFORMANCE': 'ביצועים',
            'RESOURCE_EXHAUSTION': 'תשישות משאבים',
            'COMMUNICATION': 'תקשורת',
            'DATA_PROCESSING': 'עיבוד נתונים',
            'AUTHENTICATION': 'אימות',
            'CONFIGURATION': 'תצורה',
            'NETWORK': 'רשת',
            'DATABASE': 'בסיס נתונים',
            'FILE_SYSTEM': 'מערכת קבצים',
            'MEMORY': 'זיכרון',
            'TIMEOUT': 'פסק זמן',
            
            # חומרות
            'CRITICAL': 'קריטי',
            'HIGH': 'גבוה', 
            'MEDIUM': 'בינוני',
            'LOW': 'נמוך',
            'WARNING': 'אזהרה',
            
            # מונחים כלליים
            'failure': 'כשל',
            'error': 'שגיאה',
            'warning': 'אזהרה',
            'success': 'הצלחה',
            'resolved': 'נפתר',
            'active': 'פעיל',
            'pending': 'ממתין',
            'analysis': 'ניתוח',
            'pattern': 'דפוס',
            'recommendation': 'המלצה',
            'recovery': 'התאוששות',
            'system': 'מערכת',
            'performance': 'ביצועים',
            'metric': 'מטריקה',
            'alert': 'התראה',
            'notification': 'הודעה'
        }
    
    def translate(self, text: str) -> str:
        """תרגום טקסט לעברית"""
        if not text:
            return text
        
        # תרגום מדויק
        if text in self.translations:
            return self.translations[text]
        
        # תרגום חלקי
        for eng, heb in self.translations.items():
            text = text.replace(eng, heb)
        
        return text
    
    def format_datetime(self, dt: datetime) -> str:
        """עיצוב תאריך ושעה בעברית"""
        day_name = self.translate(dt.strftime('%A'))
        month_name = self.translate(dt.strftime('%B'))
        
        return f"{day_name}, {dt.day} ב{month_name} {dt.year}, {dt.strftime('%H:%M')}"
    
    def format_duration(self, duration: timedelta) -> str:
        """עיצוב משך זמן בעברית"""
        total_seconds = int(duration.total_seconds())
        
        if total_seconds < 60:
            return f"{total_seconds} שניות"
        elif total_seconds < 3600:
            minutes = total_seconds // 60
            return f"{minutes} דקות"
        elif total_seconds < 86400:
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            if minutes > 0:
                return f"{hours} שעות ו-{minutes} דקות"
            return f"{hours} שעות"
        else:
            days = total_seconds // 86400
            hours = (total_seconds % 86400) // 3600
            if hours > 0:
                return f"{days} ימים ו-{hours} שעות"
            return f"{days} ימים"


class FailureAnalyzer:
    """מנתח כשלים מתקדם"""
    
    def __init__(self):
        self.localizer = HebrewLocalizer()
        self.analysis_cache: Dict[str, AnalysisResult] = {}
        self.similarity_threshold = 0.8
        
    def analyze_failure_trends(self, failures: List[FailureEvent], 
                             time_window: timedelta = timedelta(days=7)) -> AnalysisResult:
        """ניתוח מגמות כשלים"""
        if not failures:
            return AnalysisResult(
                analysis_type="trends",
                timestamp=datetime.now(),
                summary="אין כשלים לניתוח",
                confidence_score=0.0
            )
        
        # סינון לפי חלון זמן
        cutoff_time = datetime.now() - time_window
        recent_failures = [f for f in failures if f.timestamp >= cutoff_time]
        
        if not recent_failures:
            return AnalysisResult(
                analysis_type="trends",
                timestamp=datetime.now(),
                summary="אין כשלים בחלון הזמן שנבחר",
                confidence_score=0.0
            )
        
        insights = []
        recommendations = []
        metrics = {}
        
        # ניתוח תדירות
        total_failures = len(recent_failures)
        daily_average = total_failures / time_window.days
        metrics['total_failures'] = total_failures
        metrics['daily_average'] = daily_average
        
        insights.append(f"נרשמו {total_failures} כשלים בתקופה האחרונה")
        insights.append(f"ממוצע יומי של {daily_average:.1f} כשלים")
        
        # ניתוח לפי חומרה
        severity_counts = Counter(f.severity for f in recent_failures)
        critical_count = severity_counts.get(FailureSeverity.CRITICAL, 0)
        high_count = severity_counts.get(FailureSeverity.HIGH, 0)
        
        if critical_count > 0:
            insights.append(f"זוהו {critical_count} כשלים קריטיים")
            recommendations.append("נדרש תשומת לב מיידית לכשלים הקריטיים")
        
        if high_count > daily_average:
            insights.append(f"זוהו {high_count} כשלים בחומרה גבוהה")
            recommendations.append("מומלץ לבחון את הגורמים לכשלים בחומרה גבוהה")
        
        # ניתוח לפי קטגוריות
        category_counts = Counter(f.category for f in recent_failures)
        most_common_category = category_counts.most_common(1)[0] if category_counts else None
        
        if most_common_category:
            cat_name = self.localizer.translate(most_common_category[0].value)
            insights.append(f"הקטגוריה השכיחה ביותר: {cat_name} ({most_common_category[1]} כשלים)")
            recommendations.append(f"מומלץ להתמקד באופטימיזציה של {cat_name}")
        
        # ניתוח זמני פתרון
        resolved_failures = [f for f in recent_failures if f.resolved and f.resolution_duration]
        if resolved_failures:
            resolution_times = [f.resolution_duration.total_seconds() / 60 for f in resolved_failures]
            avg_resolution = statistics.mean(resolution_times)
            metrics['avg_resolution_minutes'] = avg_resolution
            
            insights.append(f"זמן פתרון ממוצע: {self.localizer.format_duration(timedelta(minutes=avg_resolution))}")
            
            if avg_resolution > 60:  # יותר משעה
                recommendations.append("זמני הפתרון גבוהים - מומלץ לשפר תהליכי התאוששות")
        
        # ניתוח דפוסים יומיים
        hourly_distribution = defaultdict(int)
        for failure in recent_failures:
            hourly_distribution[failure.timestamp.hour] += 1
        
        if hourly_distribution:
            peak_hour = max(hourly_distribution, key=hourly_distribution.get)
            peak_count = hourly_distribution[peak_hour]
            metrics['peak_hour'] = peak_hour
            metrics['peak_hour_count'] = peak_count
            
            insights.append(f"שעת השיא לכשלים: {peak_hour:02d}:00 ({peak_count} כשלים)")
            
            if peak_count > daily_average * 0.3:  # יותר מ-30% מהכשלים בשעה אחת
                recommendations.append(f"ריכוז גבוה של כשלים בשעה {peak_hour:02d}:00 - נדרשת בדיקה")
        
        # חישוב ציון אמינות
        confidence_score = min(1.0, total_failures / 50)  # אמינות גבוהה עם יותר נתונים
        
        summary = f"ניתוח מגמות כשלים עבור {time_window.days} ימים אחרונים: {total_failures} כשלים, ממוצע יומי של {daily_average:.1f}"
        
        return AnalysisResult(
            analysis_type="trends",
            timestamp=datetime.now(),
            summary=summary,
            insights=insights,
            recommendations=recommendations,
            metrics=metrics,
            confidence_score=confidence_score,
            priority="high" if critical_count > 0 else "medium"
        )
    
    def analyze_failure_correlation(self, failures: List[FailureEvent]) -> AnalysisResult:
        """ניתוח קורלציות בין כשלים"""
        if len(failures) < 2:
            return AnalysisResult(
                analysis_type="correlation",
                timestamp=datetime.now(),
                summary="אין מספיק כשלים לניתוח קורלציות",
                confidence_score=0.0
            )
        
        insights = []
        recommendations = []
        metrics = {}
        
        # קורלציה בין קטגוריות וחומרות
        category_severity_pairs = [(f.category, f.severity) for f in failures]
        category_severity_counter = Counter(category_severity_pairs)
        
        # זיהוי צירופים חריגים
        total_failures = len(failures)
        for (category, severity), count in category_severity_counter.most_common(5):
            percentage = (count / total_failures) * 100
            if percentage > 20:  # יותר מ-20% מהכשלים
                cat_name = self.localizer.translate(category.value)
                sev_name = self.localizer.translate(severity.value)
                insights.append(f"צירוף שכיח: {cat_name} בחומרה {sev_name} ({percentage:.1f}%)")
        
        # קורלציה זמנית
        time_clustered_failures = self._find_time_clusters(failures)
        if time_clustered_failures:
            insights.append(f"זוהו {len(time_clustered_failures)} אשכולות כשלים בזמן")
            recommendations.append("בדיקת אירועים מערכתיים בזמנים המקובצים")
            metrics['time_clusters'] = len(time_clustered_failures)
        
        # קורלציה בין הקשרים
        context_correlation = self._analyze_context_correlation(failures)
        if context_correlation:
            insights.extend(context_correlation['insights'])
            recommendations.extend(context_correlation['recommendations'])
            metrics.update(context_correlation['metrics'])
        
        confidence_score = min(1.0, len(failures) / 100)
        
        return AnalysisResult(
            analysis_type="correlation",
            timestamp=datetime.now(),
            summary=f"ניתוח קורלציות עבור {len(failures)} כשלים",
            insights=insights,
            recommendations=recommendations,
            metrics=metrics,
            confidence_score=confidence_score
        )
    
    def _find_time_clusters(self, failures: List[FailureEvent], 
                           time_threshold: timedelta = timedelta(minutes=10)) -> List[List[FailureEvent]]:
        """זיהוי אשכולות כשלים בזמן"""
        if not failures:
            return []
        
        # מיון לפי זמן
        sorted_failures = sorted(failures, key=lambda f: f.timestamp)
        
        clusters = []
        current_cluster = [sorted_failures[0]]
        
        for i in range(1, len(sorted_failures)):
            time_diff = sorted_failures[i].timestamp - sorted_failures[i-1].timestamp
            
            if time_diff <= time_threshold:
                current_cluster.append(sorted_failures[i])
            else:
                if len(current_cluster) > 1:  # רק אשכולות עם יותר מכשל אחד
                    clusters.append(current_cluster)
                current_cluster = [sorted_failures[i]]
        
        # הוספת האשכול האחרון
        if len(current_cluster) > 1:
            clusters.append(current_cluster)
        
        return clusters
    
    def _analyze_context_correlation(self, failures: List[FailureEvent]) -> Dict[str, Any]:
        """ניתוח קורלציות בהקשר"""
        insights = []
        recommendations = []
        metrics = {}
        
        # כשלים עם הקשר
        failures_with_context = [f for f in failures if f.context]
        
        if not failures_with_context:
            return {'insights': [], 'recommendations': [], 'metrics': {}}
        
        # קורלציה בין מודולים
        module_failures = Counter(f.context.module_name for f in failures_with_context)
        if module_failures:
            most_problematic_module = module_failures.most_common(1)[0]
            module_name, module_count = most_problematic_module
            
            if module_count > len(failures_with_context) * 0.3:
                insights.append(f"מודול בעייתי: {module_name} ({module_count} כשלים)")
                recommendations.append(f"בדיקה מעמיקה של מודול {module_name}")
                metrics['problematic_module'] = module_name
                metrics['problematic_module_count'] = module_count
        
        # קורלציה בין פעולות
        operation_failures = Counter(f.context.operation_name for f in failures_with_context)
        if operation_failures:
            most_problematic_operation = operation_failures.most_common(1)[0]
            operation_name, operation_count = most_problematic_operation
            
            if operation_count > len(failures_with_context) * 0.25:
                insights.append(f"פעולה בעייתית: {operation_name} ({operation_count} כשלים)")
                recommendations.append(f"אופטימיזציה של פעולה {operation_name}")
                metrics['problematic_operation'] = operation_name
                metrics['problematic_operation_count'] = operation_count
        
        return {
            'insights': insights,
            'recommendations': recommendations,
            'metrics': metrics
        }
    
    def predict_failure_risk(self, current_metrics: SystemState, 
                           historical_failures: List[FailureEvent]) -> AnalysisResult:
        """חיזוי סיכון לכשלים"""
        insights = []
        recommendations = []
        metrics = {}
        risk_score = 0.0
        
        # ניתוח מטריקות נוכחיות
        if current_metrics.cpu_usage > 80:
            risk_score += 0.2
            insights.append(f"שימוש CPU גבוה: {current_metrics.cpu_usage:.1f}%")
            recommendations.append("מעקב צמוד אחר שימוש CPU")
        
        if current_metrics.memory_usage > 85:
            risk_score += 0.3
            insights.append(f"שימוש זיכרון גבוה: {current_metrics.memory_usage:.1f}%")
            recommendations.append("ניקוי זיכרון או הגדלת הקצאה")
        
        if current_metrics.error_rate > 1.0:
            risk_score += 0.4
            insights.append(f"שיעור שגיאות גבוה: {current_metrics.error_rate:.2f}/דקה")
            recommendations.append("בדיקה מיידית של מקור השגיאות")
        
        # ניתוח דפוסים היסטוריים
        if historical_failures:
            similar_conditions = self._find_similar_conditions(current_metrics, historical_failures)
            if similar_conditions:
                risk_score += 0.3
                insights.append(f"תנאים דומים לכשלים קודמים ({len(similar_conditions)} מקרים)")
                recommendations.append("הכנות למצב כשל אפשרי")
        
        # חישוב רמת סיכון
        if risk_score < 0.3:
            risk_level = "נמוך"
            priority = "low"
        elif risk_score < 0.6:
            risk_level = "בינוני"
            priority = "medium"
        else:
            risk_level = "גבוה"
            priority = "high"
        
        metrics['risk_score'] = risk_score
        metrics['risk_level'] = risk_level
        
        summary = f"רמת סיכון לכשלים: {risk_level} (ציון: {risk_score:.2f})"
        
        return AnalysisResult(
            analysis_type="risk_prediction",
            timestamp=datetime.now(),
            summary=summary,
            insights=insights,
            recommendations=recommendations,
            metrics=metrics,
            confidence_score=min(1.0, len(historical_failures) / 50),
            priority=priority
        )
    
    def _find_similar_conditions(self, current_metrics: SystemState, 
                               historical_failures: List[FailureEvent]) -> List[FailureEvent]:
        """חיפוש תנאים דומים בהיסטוריה"""
        similar_failures = []
        
        for failure in historical_failures:
            if not failure.system_state:
                continue
            
            # השוואת מטריקות עם סטייה של 10%
            cpu_diff = abs(failure.system_state.cpu_usage - current_metrics.cpu_usage)
            memory_diff = abs(failure.system_state.memory_usage - current_metrics.memory_usage)
            error_rate_diff = abs(failure.system_state.error_rate - current_metrics.error_rate)
            
            if (cpu_diff < 10 and memory_diff < 10 and error_rate_diff < 1.0):
                similar_failures.append(failure)
        
        return similar_failures


class PatternDetector:
    """גלאי דפוסי כשלים מתקדם"""
    
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.localizer = HebrewLocalizer()
        
    def detect_anomalous_patterns(self, failures: List[FailureEvent]) -> List[AnalysisResult]:
        """זיהוי דפוסים חריגים"""
        if len(failures) < 5:
            return []
        
        results = []
        
        # זיהוי דפוסים לפי תוכן השגיאה
        text_patterns = self._detect_text_patterns(failures)
        if text_patterns:
            results.append(text_patterns)
        
        # זיהוי דפוסים זמניים
        temporal_patterns = self._detect_temporal_patterns(failures)
        if temporal_patterns:
            results.append(temporal_patterns)
        
        # זיהוי דפוסים בהקשר
        context_patterns = self._detect_context_patterns(failures)
        if context_patterns:
            results.append(context_patterns)
        
        return results
    
    def _detect_text_patterns(self, failures: List[FailureEvent]) -> Optional[AnalysisResult]:
        """זיהוי דפוסים בטקסט השגיאות"""
        error_messages = [f.error_message for f in failures if f.error_message]
        
        if len(error_messages) < 3:
            return None
        
        try:
            # וקטוריזציה של הודעות השגיאה
            tfidf_matrix = self.vectorizer.fit_transform(error_messages)
            
            # חישוב דמיון
            similarity_matrix = cosine_similarity(tfidf_matrix)
            
            # זיהוי קבוצות דומות
            clustering = DBSCAN(eps=0.3, min_samples=2, metric='precomputed')
            clusters = clustering.fit_predict(1 - similarity_matrix)
            
            # ניתוח תוצאות
            unique_clusters = set(clusters)
            unique_clusters.discard(-1)  # הסרת רעש
            
            if len(unique_clusters) == 0:
                return None
            
            insights = []
            recommendations = []
            
            for cluster_id in unique_clusters:
                cluster_indices = [i for i, c in enumerate(clusters) if c == cluster_id]
                cluster_messages = [error_messages[i] for i in cluster_indices]
                
                if len(cluster_messages) >= 2:
                    insights.append(f"זוהה דפוס של {len(cluster_messages)} הודעות שגיאה דומות")
                    
                    # זיהוי מילות מפתח משותפות
                    common_words = self._extract_common_words(cluster_messages)
                    if common_words:
                        insights.append(f"מילות מפתח: {', '.join(common_words[:5])}")
                        recommendations.append(f"בדיקת בעיות הקשורות ל: {', '.join(common_words[:3])}")
            
            return AnalysisResult(
                analysis_type="text_patterns",
                timestamp=datetime.now(),
                summary=f"זוהו {len(unique_clusters)} דפוסי טקסט בהודעות שגיאה",
                insights=insights,
                recommendations=recommendations,
                metrics={'clusters_found': len(unique_clusters)},
                confidence_score=0.8
            )
            
        except Exception as e:
            logging.error(f"שגיאה בזיהוי דפוסי טקסט: {e}")
            return None
    
    def _detect_temporal_patterns(self, failures: List[FailureEvent]) -> Optional[AnalysisResult]:
        """זיהוי דפוסים זמניים"""
        if len(failures) < 5:
            return None
        
        insights = []
        recommendations = []
        metrics = {}
        
        # ניתוח דפוסים יומיים
        hours = [f.timestamp.hour for f in failures]
        hour_counts = Counter(hours)
        
        # זיהוי שעות שיא
        max_count = max(hour_counts.values())
        peak_hours = [hour for hour, count in hour_counts.items() if count == max_count and count > 1]
        
        if peak_hours:
            insights.append(f"שעות שיא לכשלים: {', '.join(f'{h:02d}:00' for h in peak_hours)}")
            recommendations.append("בדיקת עומסים ותהליכים בשעות השיא")
            metrics['peak_hours'] = peak_hours
        
        # ניתוח דפוסים שבועיים
        weekdays = [f.timestamp.weekday() for f in failures]
        weekday_counts = Counter(weekdays)
        
        weekday_names = ['יום שני', 'יום שלישי', 'יום רביעי', 'יום חמישי', 'יום שישי', 'שבת', 'יום ראשון']
        max_weekday_count = max(weekday_counts.values())
        peak_weekdays = [weekday_names[day] for day, count in weekday_counts.items() 
                        if count == max_weekday_count and count > 1]
        
        if peak_weekdays:
            insights.append(f"ימים בעייתיים: {', '.join(peak_weekdays)}")
            metrics['peak_weekdays'] = peak_weekdays
        
        # זיהוי דפוסים עונתיים (אם יש מספיק נתונים)
        if len(failures) > 50:
            months = [f.timestamp.month for f in failures]
            month_counts = Counter(months)
            
            month_names = ['ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני',
                          'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר']
            
            max_month_count = max(month_counts.values())
            if max_month_count > len(failures) / 12 * 1.5:  # 50% יותר מהממוצע
                peak_months = [month_names[month-1] for month, count in month_counts.items() 
                              if count == max_month_count]
                insights.append(f"חודשים בעייתיים: {', '.join(peak_months)}")
                metrics['peak_months'] = peak_months
        
        if insights:
            return AnalysisResult(
                analysis_type="temporal_patterns",
                timestamp=datetime.now(),
                summary=f"זוהו דפוסים זמניים בכשלים",
                insights=insights,
                recommendations=recommendations,
                metrics=metrics,
                confidence_score=0.7
            )
        
        return None
    
    def _detect_context_patterns(self, failures: List[FailureEvent]) -> Optional[AnalysisResult]:
        """זיהוי דפוסים בהקשר"""
        failures_with_context = [f for f in failures if f.context]
        
        if len(failures_with_context) < 3:
            return None
        
        insights = []
        recommendations = []
        metrics = {}
        
        # דפוסים במודולים
        modules = [f.context.module_name for f in failures_with_context]
        module_counts = Counter(modules)
        
        total_with_context = len(failures_with_context)
        problematic_modules = [(module, count) for module, count in module_counts.items() 
                              if count > total_with_context * 0.2]  # יותר מ-20%
        
        if problematic_modules:
            for module, count in problematic_modules:
                percentage = (count / total_with_context) * 100
                insights.append(f"מודול בעייתי: {module} ({count} כשלים, {percentage:.1f}%)")
                recommendations.append(f"בדיקה מעמיקה של מודול {module}")
            
            metrics['problematic_modules'] = [module for module, _ in problematic_modules]
        
        # דפוסים בפעולות
        operations = [f.context.operation_name for f in failures_with_context]
        operation_counts = Counter(operations)
        
        problematic_operations = [(op, count) for op, count in operation_counts.items() 
                                 if count > total_with_context * 0.15]  # יותר מ-15%
        
        if problematic_operations:
            for operation, count in problematic_operations:
                percentage = (count / total_with_context) * 100
                insights.append(f"פעולה בעייתית: {operation} ({count} כשלים, {percentage:.1f}%)")
                recommendations.append(f"אופטימיזציה של פעולה {operation}")
            
            metrics['problematic_operations'] = [op for op, _ in problematic_operations]
        
        # דפוסים בסביבות
        environments = [f.context.environment for f in failures_with_context]
        env_counts = Counter(environments)
        
        if len(env_counts) > 1:  # יש יותר מסביבה אחת
            most_problematic_env = env_counts.most_common(1)[0]
            env_name, env_count = most_problematic_env
            env_percentage = (env_count / total_with_context) * 100
            
            if env_percentage > 60:  # יותר מ-60% בסביבה אחת
                insights.append(f"סביבה בעייתית: {env_name} ({env_percentage:.1f}% מהכשלים)")
                recommendations.append(f"בדיקת תצורה וביצועים בסביבת {env_name}")
                metrics['problematic_environment'] = env_name
        
        if insights:
            return AnalysisResult(
                analysis_type="context_patterns",
                timestamp=datetime.now(),
                summary="זוהו דפוסים בהקשר הכשלים",
                insights=insights,
                recommendations=recommendations,
                metrics=metrics,
                confidence_score=0.8
            )
        
        return None
    
    def _extract_common_words(self, messages: List[str]) -> List[str]:
        """חילוץ מילים משותפות מהודעות"""
        if not messages:
            return []
        
        # ניקוי ועיבוד טקסט
        all_words = []
        for message in messages:
            # הסרת תווים מיוחדים ופיצול למילים
            words = re.findall(r'\b[a-zA-Z]+\b', message.lower())
            all_words.extend(words)
        
        # ספירת מילים
        word_counts = Counter(all_words)
        
        # מילים נפוצות לסינון
        common_words = {'error', 'failed', 'exception', 'the', 'and', 'or', 'in', 'at', 'to', 'of'}
        
        # חזרת המילים השכיחות (לא כולל מילים נפוצות)
        filtered_words = [(word, count) for word, count in word_counts.items() 
                         if word not in common_words and count > 1]
        
        return [word for word, _ in sorted(filtered_words, key=lambda x: x[1], reverse=True)]


class AlertManager:
    """מנהל התראות חכם"""
    
    def __init__(self):
        self.rules: Dict[str, AlertRule] = {}
        self.alert_history: List[Dict[str, Any]] = []
        self.email_config = {}
        self.localizer = HebrewLocalizer()
        
    def add_alert_rule(self, rule: AlertRule) -> None:
        """הוספת כלל התראה"""
        self.rules[rule.id] = rule
        logging.info(f"נוסף כלל התראה: {rule.name}")
    
    def remove_alert_rule(self, rule_id: str) -> bool:
        """הסרת כלל התראה"""
        if rule_id in self.rules:
            del self.rules[rule_id]
            logging.info(f"הוסר כלל התראה: {rule_id}")
            return True
        return False
    
    def check_alert_conditions(self, failure: FailureEvent, 
                             system_state: Optional[SystemState] = None) -> List[str]:
        """בדיקת תנאי התראות"""
        triggered_alerts = []
        
        for rule in self.rules.values():
            if not rule.enabled:
                continue
            
            # בדיקת cooldown
            if self._is_in_cooldown(rule):
                continue
            
            # בדיקת תנאי
            if self._evaluate_condition(rule, failure, system_state):
                triggered_alerts.append(rule.id)
                self._trigger_alert(rule, failure, system_state)
        
        return triggered_alerts
    
    def _is_in_cooldown(self, rule: AlertRule) -> bool:
        """בדיקת מצב cooldown"""
        if not rule.last_triggered:
            return False
        
        cooldown_end = rule.last_triggered + timedelta(minutes=rule.cooldown_minutes)
        return datetime.now() < cooldown_end
    
    def _evaluate_condition(self, rule: AlertRule, failure: FailureEvent, 
                           system_state: Optional[SystemState]) -> bool:
        """הערכת תנאי כלל התראה"""
        try:
            # הכנת משתנים להערכה
            context = {
                'failure': failure,
                'system_state': system_state,
                'severity': failure.severity,
                'category': failure.category,
                'resolved': failure.resolved,
                'datetime': datetime,
                'timedelta': timedelta,
                'FailureSeverity': FailureSeverity,
                'FailureCategory': FailureCategory
            }
            
            # הוספת מטריקות מערכת אם זמינות
            if system_state:
                context.update({
                    'cpu_usage': system_state.cpu_usage,
                    'memory_usage': system_state.memory_usage,
                    'disk_usage': system_state.disk_usage,
                    'error_rate': system_state.error_rate,
                    'response_time': system_state.api_response_time
                })
            
            # הערכת התנאי
            return eval(rule.condition, {"__builtins__": {}}, context)
            
        except Exception as e:
            logging.error(f"שגיאה בהערכת תנאי התראה {rule.id}: {e}")
            return False
    
    def _trigger_alert(self, rule: AlertRule, failure: FailureEvent, 
                      system_state: Optional[SystemState]) -> None:
        """הפעלת התראה"""
        rule.last_triggered = datetime.now()
        
        # יצירת הודעת התראה
        alert_message = self._create_alert_message(rule, failure, system_state)
        
        # שמירה בהיסטוריה
        alert_record = {
            'timestamp': datetime.now(),
            'rule_id': rule.id,
            'rule_name': rule.name,
            'failure_id': failure.id,
            'message': alert_message,
            'severity': rule.severity.value
        }
        self.alert_history.append(alert_record)
        
        # שליחת התראה
        self._send_alert(rule, alert_message, failure)
        
        logging.warning(f"הופעלה התראה: {rule.name} - {alert_message}")
    
    def _create_alert_message(self, rule: AlertRule, failure: FailureEvent, 
                            system_state: Optional[SystemState]) -> str:
        """יצירת הודעת התראה"""
        timestamp_str = self.localizer.format_datetime(failure.timestamp)
        severity_str = self.localizer.translate(failure.severity.value)
        category_str = self.localizer.translate(failure.category.value)
        
        message = f"""
🚨 התראת כשל - {rule.name}

📝 פרטי הכשל:
• זמן: {timestamp_str}
• חומרה: {severity_str}
• קטגוריה: {category_str}
• כותרת: {failure.title}
• תיאור: {failure.description}

🔗 מזהה כשל: {failure.id}
"""
        
        if system_state:
            message += f"""
💻 מצב מערכת:
• שימוש CPU: {system_state.cpu_usage:.1f}%
• שימוש זיכרון: {system_state.memory_usage:.1f}%
• שימוש דיסק: {system_state.disk_usage:.1f}%
• שיעור שגיאות: {system_state.error_rate:.2f}/דקה
"""
        
        if failure.context:
            message += f"""
🎯 הקשר:
• מודול: {failure.context.module_name}
• פעולה: {failure.context.operation_name}
• סביבה: {failure.context.environment}
"""
        
        return message.strip()
    
    def _send_alert(self, rule: AlertRule, message: str, failure: FailureEvent) -> None:
        """שליחת התראה"""
        # שליחה למערכת logging
        logging.critical(f"התראה: {rule.name}")
        
        # שליחת אימייל (אם מוגדר)
        if rule.recipients and self.email_config:
            self._send_email_alert(rule, message, failure)
        
        # כאן אפשר להוסיף שליחה לערוצים נוספים (Slack, SMS וכו')
    
    def _send_email_alert(self, rule: AlertRule, message: str, failure: FailureEvent) -> None:
        """שליחת התראה באימייל"""
        try:
            if not self.email_config:
                return
            
            smtp_server = self.email_config.get('smtp_server')
            smtp_port = self.email_config.get('smtp_port', 587)
            username = self.email_config.get('username')
            password = self.email_config.get('password')
            from_email = self.email_config.get('from_email', username)
            
            if not all([smtp_server, username, password]):
                logging.error("תצורת אימייל לא שלמה")
                return
            
            # יצירת הודעה
            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = ', '.join(rule.recipients)
            msg['Subject'] = f"🚨 התראת כשל: {rule.name}"
            
            # הוספת תוכן
            msg.attach(MIMEText(message, 'plain', 'utf-8'))
            
            # שליחה
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(username, password)
                server.sendmail(from_email, rule.recipients, msg.as_string())
            
            logging.info(f"נשלחה התראה באימייל עבור {rule.name}")
            
        except Exception as e:
            logging.error(f"שגיאה בשליחת אימייל עבור {rule.name}: {e}")
    
    def configure_email(self, smtp_server: str, smtp_port: int, 
                       username: str, password: str, from_email: str = None) -> None:
        """הגדרת תצורת אימייל"""
        self.email_config = {
            'smtp_server': smtp_server,
            'smtp_port': smtp_port,
            'username': username,
            'password': password,
            'from_email': from_email or username
        }
        logging.info("תצורת אימייל הוגדרה בהצלחה")
    
    def get_alert_history(self, hours: int = 24) -> List[Dict[str, Any]]:
        """קבלת היסטוריית התראות"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        return [alert for alert in self.alert_history 
                if alert['timestamp'] >= cutoff_time]
    
    def create_default_rules(self) -> None:
        """יצירת כללי התראה ברירת מחדל"""
        default_rules = [
            AlertRule(
                id="critical_failure",
                name="כשל קריטי",
                description="התראה על כשלים קריטיים",
                condition="severity == FailureSeverity.CRITICAL",
                severity=FailureSeverity.CRITICAL,
                cooldown_minutes=5
            ),
            AlertRule(
                id="high_cpu_usage",
                name="שימוש CPU גבוה",
                description="התראה על שימוש CPU גבוה",
                condition="system_state and cpu_usage > 90",
                severity=FailureSeverity.HIGH,
                cooldown_minutes=15
            ),
            AlertRule(
                id="high_memory_usage", 
                name="שימוש זיכרון גבוה",
                description="התראה על שימוש זיכרון גבוה",
                condition="system_state and memory_usage > 85",
                severity=FailureSeverity.HIGH,
                cooldown_minutes=15
            ),
            AlertRule(
                id="high_error_rate",
                name="שיעור שגיאות גבוה",
                description="התראה על שיעור שגיאות גבוה",
                condition="system_state and error_rate > 5.0",
                severity=FailureSeverity.MEDIUM,
                cooldown_minutes=30
            ),
            AlertRule(
                id="repeated_failures",
                name="כשלים חוזרים",
                description="התראה על כשלים חוזרים באותה קטגוריה",
                condition="category == FailureCategory.API_CALL and not resolved",
                severity=FailureSeverity.MEDIUM,
                cooldown_minutes=60
            )
        ]
        
        for rule in default_rules:
            self.add_alert_rule(rule)
        
        logging.info(f"נוצרו {len(default_rules)} כללי התראה ברירת מחדל")


class ReportGenerator:
    """מחולל דוחות כשלים"""
    
    def __init__(self):
        self.localizer = HebrewLocalizer()
        
    def generate_daily_report(self, failures: List[FailureEvent], 
                             date: datetime = None) -> str:
        """יצירת דוח יומי"""
        if date is None:
            date = datetime.now()
        
        date_str = self.localizer.format_datetime(date)
        
        # סינון כשלים ליום
        start_of_day = date.replace(hour=0, minute=0, second=0, microsecond=0)
        end_of_day = start_of_day + timedelta(days=1)
        
        daily_failures = [f for f in failures 
                         if start_of_day <= f.timestamp < end_of_day]
        
        if not daily_failures:
            return f"דוח יומי - {date_str}\n\n✅ לא נרשמו כשלים היום!"
        
        # סטטיסטיקות בסיסיות
        total_failures = len(daily_failures)
        resolved_failures = len([f for f in daily_failures if f.resolved])
        critical_failures = len([f for f in daily_failures if f.severity == FailureSeverity.CRITICAL])
        
        # התפלגות לפי חומרה
        severity_counts = Counter(f.severity for f in daily_failures)
        
        # התפלגות לפי קטגוריה
        category_counts = Counter(f.category for f in daily_failures)
        
        # בניית הדוח
        report = f"""
📊 דוח כשלים יומי - {date_str}

🔢 סטטיסטיקות כלליות:
• סה"כ כשלים: {total_failures}
• כשלים נפתרים: {resolved_failures} ({(resolved_failures/total_failures)*100:.1f}%)
• כשלים קריטיים: {critical_failures}
• כשלים פעילים: {total_failures - resolved_failures}

⚠️ התפלגות לפי חומרה:
"""
        
        for severity, count in severity_counts.most_common():
            severity_name = self.localizer.translate(severity.value)
            percentage = (count / total_failures) * 100
            report += f"• {severity_name}: {count} ({percentage:.1f}%)\n"
        
        report += "\n📋 התפלגות לפי קטגוריה:\n"
        
        for category, count in category_counts.most_common():
            category_name = self.localizer.translate(category.value)
            percentage = (count / total_failures) * 100
            report += f"• {category_name}: {count} ({percentage:.1f}%)\n"
        
        # כשלים חמורים
        severe_failures = [f for f in daily_failures 
                          if f.severity in [FailureSeverity.CRITICAL, FailureSeverity.HIGH]]
        
        if severe_failures:
            report += "\n🚨 כשלים חמורים:\n"
            for failure in severe_failures[:5]:  # הצגת 5 הראשונים
                time_str = failure.timestamp.strftime('%H:%M')
                severity_name = self.localizer.translate(failure.severity.value)
                report += f"• {time_str} - {severity_name}: {failure.title}\n"
        
        # המלצות
        report += "\n💡 המלצות:\n"
        
        if critical_failures > 0:
            report += "• טיפול מיידי בכשלים הקריטיים\n"
        
        if (total_failures - resolved_failures) > total_failures * 0.3:
            report += "• שיפור תהליכי פתרון כשלים\n"
        
        most_common_category = category_counts.most_common(1)[0] if category_counts else None
        if most_common_category and most_common_category[1] > total_failures * 0.4:
            cat_name = self.localizer.translate(most_common_category[0].value)
            report += f"• התמקדות באופטימיזציה של {cat_name}\n"
        
        return report.strip()
    
    def generate_weekly_report(self, failures: List[FailureEvent], 
                              start_date: datetime = None) -> str:
        """יצירת דוח שבועי"""
        if start_date is None:
            start_date = datetime.now() - timedelta(days=7)
        
        end_date = start_date + timedelta(days=7)
        
        # סינון כשלים לשבוע
        weekly_failures = [f for f in failures 
                          if start_date <= f.timestamp < end_date]
        
        if not weekly_failures:
            return f"דוח שבועי - {start_date.strftime('%d/%m/%Y')} - {end_date.strftime('%d/%m/%Y')}\n\n✅ לא נרשמו כשלים השבוע!"
        
        # סטטיסטיקות
        total_failures = len(weekly_failures)
        daily_average = total_failures / 7
        resolved_failures = len([f for f in weekly_failures if f.resolved])
        
        # מגמות יומיות
        daily_counts = defaultdict(int)
        for failure in weekly_failures:
            day_key = failure.timestamp.date()
            daily_counts[day_key] += 1
        
        # יום הבעייתי ביותר
        worst_day = max(daily_counts, key=daily_counts.get) if daily_counts else None
        
        # דפוסים זמניים
        hourly_distribution = Counter(f.timestamp.hour for f in weekly_failures)
        peak_hour = hourly_distribution.most_common(1)[0] if hourly_distribution else None
        
        # בניית הדוח
        report = f"""
📈 דוח כשלים שבועי
תקופה: {start_date.strftime('%d/%m/%Y')} - {end_date.strftime('%d/%m/%Y')}

🔢 סיכום שבועי:
• סה"כ כשלים: {total_failures}
• ממוצע יומי: {daily_average:.1f}
• אחוז פתרון: {(resolved_failures/total_failures)*100:.1f}%
"""
        
        if worst_day:
            worst_day_count = daily_counts[worst_day]
            day_name = self.localizer.translate(worst_day.strftime('%A'))
            report += f"• היום הבעייתי ביותר: {day_name} ({worst_day_count} כשלים)\n"
        
        if peak_hour:
            hour, count = peak_hour
            report += f"• שעת השיא: {hour:02d}:00 ({count} כשלים)\n"
        
        # מגמות יומיות
        report += "\n📅 פירוט יומי:\n"
        for day in sorted(daily_counts.keys()):
            day_name = self.localizer.translate(day.strftime('%A'))
            count = daily_counts[day]
            report += f"• {day_name} ({day.strftime('%d/%m')}): {count} כשלים\n"
        
        # זיהוי מגמות
        daily_values = list(daily_counts.values())
        if len(daily_values) >= 3:
            # בדיקת מגמה עולה/יורדת
            first_half = sum(daily_values[:len(daily_values)//2])
            second_half = sum(daily_values[len(daily_values)//2:])
            
            report += "\n📊 מגמות:\n"
            if second_half > first_half * 1.2:
                report += "• מגמה עולה בכשלים - נדרשת תשומת לב\n"
            elif second_half < first_half * 0.8:
                report += "• מגמה יורדת בכשלים - שיפור מתמשך\n"
            else:
                report += "• מגמה יציבה\n"
        
        return report.strip()
    
    def generate_pattern_report(self, patterns: Dict[str, FailurePattern]) -> str:
        """יצירת דוח דפוסים"""
        if not patterns:
            return "דוח דפוסי כשלים\n\n✅ לא נמצאו דפוסים!"
        
        # מיון דפוסים לפי תדירות
        sorted_patterns = sorted(patterns.values(), key=lambda p: p.frequency, reverse=True)
        
        report = f"""
🔍 דוח דפוסי כשלים

📊 סיכום:
• מספר דפוסים: {len(patterns)}
• סה"כ התרחשויות: {sum(p.frequency for p in patterns.values())}

🏆 הדפוסים השכיחים ביותר:
"""
        
        for i, pattern in enumerate(sorted_patterns[:5], 1):
            category_name = self.localizer.translate(pattern.category.value)
            first_seen = pattern.first_occurrence.strftime('%d/%m/%Y') if pattern.first_occurrence else "לא ידוע"
            last_seen = pattern.last_occurrence.strftime('%d/%m/%Y') if pattern.last_occurrence else "לא ידוע"
            
            report += f"""
{i}. {pattern.name}
   • קטגוריה: {category_name}
   • תדירות: {pattern.frequency}
   • התרחשות ראשונה: {first_seen}
   • התרחשות אחרונה: {last_seen}
   • שיעור הצלחה: {pattern.success_rate:.1%}
"""
            
            if pattern.recommended_actions:
                report += f"   • פעולות מומלצות: {', '.join(pattern.recommended_actions[:3])}\n"
        
        # המלצות כלליות
        report += "\n💡 המלצות כלליות:\n"
        
        high_frequency_patterns = [p for p in patterns.values() if p.frequency > 5]
        if high_frequency_patterns:
            report += f"• {len(high_frequency_patterns)} דפוסים בתדירות גבוהה - נדרש טיפול מיידי\n"
        
        low_success_patterns = [p for p in patterns.values() if p.success_rate < 0.5]
        if low_success_patterns:
            report += f"• {len(low_success_patterns)} דפוסים עם שיעור הצלחה נמוך - נדרש שיפור\n"
        
        recent_patterns = [p for p in patterns.values() 
                          if p.last_occurrence and 
                          p.last_occurrence > datetime.now() - timedelta(days=7)]
        if recent_patterns:
            report += f"• {len(recent_patterns)} דפוסים פעילים בשבוע האחרון\n"
        
        return report.strip()
    
    def export_report_to_file(self, report: str, filename: str, 
                             format: str = 'txt') -> bool:
        """ייצוא דוח לקובץ"""
        try:
            filepath = Path(filename)
            
            if format.lower() == 'txt':
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(report)
            elif format.lower() == 'html':
                html_report = self._convert_to_html(report)
                with open(filepath.with_suffix('.html'), 'w', encoding='utf-8') as f:
                    f.write(html_report)
            
            logging.info(f"דוח יוצא לקובץ: {filepath}")
            return True
            
        except Exception as e:
            logging.error(f"שגיאה בייצוא דוח: {e}")
            return False
    
    def _convert_to_html(self, report: str) -> str:
        """המרת דוח ל-HTML"""
        # המרה בסיסית של טקסט ל-HTML עם עיצוב RTL
        html = f"""
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>דוח כשלים</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            direction: rtl;
            text-align: right;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
        }}
        h1, h2, h3 {{ color: #333; }}
        pre {{ 
            background: #f5f5f5; 
            padding: 15px; 
            border-radius: 5px; 
            white-space: pre-wrap;
        }}
        .emoji {{ font-size: 1.2em; }}
    </style>
</head>
<body>
    <pre>{report}</pre>
</body>
</html>
"""
        return html


class MetricsCollector:
    """אספן מטריקות מערכת"""
    
    def __init__(self):
        self.metrics_history: List[SystemState] = []
        self.max_history_size = 1000
        
    def collect_current_metrics(self) -> SystemState:
        """איסוף מטריקות נוכחיות"""
        try:
            import psutil
            
            # מטריקות בסיסיות
            cpu_usage = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # מטריקות נוספות
            processes = len(psutil.pids())
            load_avg = psutil.getloadavg()[0] if hasattr(psutil, 'getloadavg') else 0.0
            
            # יצירת אובייקט מצב מערכת
            system_state = SystemState(
                timestamp=datetime.now(),
                cpu_usage=cpu_usage,
                memory_usage=memory.percent,
                disk_usage=disk.percent,
                active_processes=processes,
                system_load=load_avg,
                network_status=self._check_network_status(),
                database_status=self._check_database_status(),
                api_response_time=self._measure_api_response_time(),
                error_rate=0.0,  # יעודכן על ידי מערכת המעקב
                active_users=1,  # יעודכן על ידי מערכת המעקב
                system_uptime=timedelta(seconds=time.time() - psutil.boot_time())
            )
            
            # הוספה להיסטוריה
            self.metrics_history.append(system_state)
            
            # ניקוי היסטוריה אם נדרש
            if len(self.metrics_history) > self.max_history_size:
                self.metrics_history = self.metrics_history[-self.max_history_size:]
            
            return system_state
            
        except Exception as e:
            logging.error(f"שגיאה באיסוף מטריקות: {e}")
            return SystemState(
                timestamp=datetime.now(),
                cpu_usage=0.0,
                memory_usage=0.0,
                disk_usage=0.0,
                active_processes=0,
                system_load=0.0,
                network_status=False,
                database_status=False,
                api_response_time=0.0,
                error_rate=0.0,
                active_users=0,
                system_uptime=timedelta()
            )
    
    def _check_network_status(self) -> bool:
        """בדיקת סטטוס רשת"""
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False
    
    def _check_database_status(self) -> bool:
        """בדיקת סטטוס בסיס נתונים"""
        # כאן יבוא קוד לבדיקת חיבור לבסיס נתונים
        # לעת עתה מחזיר True
        return True
    
    def _measure_api_response_time(self) -> float:
        """מדידת זמן תגובה API"""
        # כאן יבוא קוד למדידת זמן תגובה אמיתי
        # לעת עתה מחזיר ערך קבוע
        return 100.0
    
    def get_metrics_trend(self, metric_name: str, hours: int = 24) -> List[Tuple[datetime, float]]:
        """קבלת מגמת מטריקה"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_metrics = [m for m in self.metrics_history if m.timestamp >= cutoff_time]
        
        trends = []
        for metrics in recent_metrics:
            value = getattr(metrics, metric_name, 0.0)
            trends.append((metrics.timestamp, value))
        
        return trends
    
    def calculate_metrics_statistics(self, metric_name: str, hours: int = 24) -> Dict[str, float]:
        """חישוב סטטיסטיקות מטריקה"""
        trend = self.get_metrics_trend(metric_name, hours)
        
        if not trend:
            return {}
        
        values = [value for _, value in trend]
        
        return {
            'average': statistics.mean(values),
            'median': statistics.median(values),
            'min': min(values),
            'max': max(values),
            'std_dev': statistics.stdev(values) if len(values) > 1 else 0.0,
            'count': len(values)
        }


# פונקציות עזר נוספות
def create_sample_alert_rules() -> List[AlertRule]:
    """יצירת כללי התראה לדוגמה"""
    return [
        AlertRule(
            id="api_timeout",
            name="API Timeout",
            description="התראה על timeout בקריאות API",
            condition="category == FailureCategory.TIMEOUT and 'api' in failure.error_message.lower()",
            severity=FailureSeverity.HIGH
        ),
        AlertRule(
            id="database_connection",
            name="בעיית חיבור למסד נתונים",
            description="התראה על בעיות חיבור למסד נתונים",
            condition="category == FailureCategory.DATABASE and 'connection' in failure.error_message.lower()",
            severity=FailureSeverity.CRITICAL
        ),
        AlertRule(
            id="memory_leak",
            name="חשד לדליפת זיכרון",
            description="התראה על חשד לדליפת זיכרון",
            condition="system_state and memory_usage > 90 and category == FailureCategory.MEMORY",
            severity=FailureSeverity.HIGH,
            cooldown_minutes=30
        )
    ]


def analyze_failure_batch(failures: List[FailureEvent]) -> Dict[str, AnalysisResult]:
    """ניתוח אצווה של כשלים"""
    analyzer = FailureAnalyzer()
    pattern_detector = PatternDetector()
    
    results = {}
    
    # ניתוח מגמות
    trends_result = analyzer.analyze_failure_trends(failures)
    results['trends'] = trends_result
    
    # ניתוח קורלציות
    correlation_result = analyzer.analyze_failure_correlation(failures)
    results['correlation'] = correlation_result
    
    # זיהוי דפוסים
    pattern_results = pattern_detector.detect_anomalous_patterns(failures)
    for i, pattern_result in enumerate(pattern_results):
        results[f'pattern_{i}'] = pattern_result
    
    return results


def generate_comprehensive_report(failures: List[FailureEvent], 
                                patterns: Dict[str, FailurePattern]) -> str:
    """יצירת דוח מקיף"""
    generator = ReportGenerator()
    
    # דוח יומי
    daily_report = generator.generate_daily_report(failures)
    
    # דוח שבועי
    weekly_report = generator.generate_weekly_report(failures)
    
    # דוח דפוסים
    pattern_report = generator.generate_pattern_report(patterns)
    
    # דוח מקיף
    comprehensive_report = f"""
🔍 דוח כשלים מקיף
תאריך יצירה: {datetime.now().strftime('%d/%m/%Y %H:%M')}

{'='*60}
{daily_report}

{'='*60}
{weekly_report}

{'='*60}
{pattern_report}

{'='*60}
💡 סיכום והמלצות כלליות:

1. מעקב צמוד אחר כשלים קריטיים
2. שיפור תהליכי התאוששות אוטומטית
3. אופטימיזציה של רכיבים בעייתיים
4. הגברת מעקב בזמנים בעייתיים
5. שדרוג מערכות לפי הצורך
"""
    
    return comprehensive_report