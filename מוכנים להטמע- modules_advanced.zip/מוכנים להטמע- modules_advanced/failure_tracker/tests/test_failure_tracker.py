"""
בדיקות יחידה למעקב כשלים - Failure Tracker Unit Tests
בדיקות מקיפות לכל רכיבי המערכת
"""

import pytest
import tempfile
import os
import json
from datetime import datetime, timedelta
from pathlib import Path
import sys

# הוספת נתיב המודול
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

from models.failure_types import *
from core.failure_tracker import FailureTracker, DatabaseManager
from utils.failure_utils import *
from module import FailureTrackerModule


class TestFailureTypes:
    """בדיקות מודלי נתונים"""
    
    def test_failure_event_creation(self):
        """בדיקת יצירת אירוע כשל"""
        failure = FailureEvent(
            title="בדיקת כשל",
            description="זוהי בדיקת יחידה",
            category=FailureCategory.CODE_EXECUTION,
            severity=FailureSeverity.MEDIUM,
            error_message="Test error message"
        )
        
        assert failure.title == "בדיקת כשל"
        assert failure.category == FailureCategory.CODE_EXECUTION
        assert failure.severity == FailureSeverity.MEDIUM
        assert not failure.resolved
        assert failure.id is not None
        assert isinstance(failure.timestamp, datetime)
    
    def test_failure_context(self):
        """בדיקת הקשר כשל"""
        context = FailureContext(
            operation_name="test_operation",
            module_name="test_module",
            function_name="test_function",
            parameters={"param1": "value1"},
            user_id="test_user",
            environment="test",
            version="1.0.0"
        )
        
        assert context.operation_name == "test_operation"
        assert context.parameters["param1"] == "value1"
        
        # בדיקת המרה למילון
        context_dict = context.to_dict()
        assert context_dict["operation_name"] == "test_operation"
        
        # בדיקת יצירה ממילון
        new_context = FailureContext.from_dict(context_dict)
        assert new_context.operation_name == context.operation_name
    
    def test_recovery_action(self):
        """בדיקת פעולת התאוששות"""
        action = RecoveryAction(
            name="ניסיון חוזר",
            description="ניסיון שוב לביצוע הפעולה",
            action_type="retry",
            parameters={"max_attempts": 3}
        )
        
        assert action.name == "ניסיון חוזר"
        assert action.parameters["max_attempts"] == 3
        assert action.success is None  # לא בוצע עדיין
        
        # בדיקת ביצוע
        success = action.execute()
        assert action.execution_time is not None
        assert action.execution_duration is not None
    
    def test_system_state(self):
        """בדיקת מצב מערכת"""
        state = SystemState(
            timestamp=datetime.now(),
            cpu_usage=75.5,
            memory_usage=60.2,
            disk_usage=45.0,
            active_processes=150,
            system_load=1.5,
            network_status=True,
            database_status=True,
            api_response_time=120.0,
            error_rate=0.5,
            active_users=10,
            system_uptime=timedelta(hours=24)
        )
        
        assert state.cpu_usage == 75.5
        assert state.network_status == True
        
        # בדיקת המרה
        state_dict = state.to_dict()
        new_state = SystemState.from_dict(state_dict)
        assert new_state.cpu_usage == state.cpu_usage
    
    def test_create_failure_from_exception(self):
        """בדיקת יצירת כשל מחריגה"""
        try:
            x = 1 / 0
        except Exception as e:
            failure = create_failure_from_exception(
                e, 
                severity=FailureSeverity.HIGH,
                category=FailureCategory.CODE_EXECUTION
            )
            
            assert "ZeroDivisionError" in failure.title
            assert failure.severity == FailureSeverity.HIGH
            assert failure.category == FailureCategory.CODE_EXECUTION
            assert failure.stack_trace is not None


class TestDatabaseManager:
    """בדיקות מנהל בסיס נתונים"""
    
    @pytest.fixture
    def temp_db(self):
        """יצירת מסד נתונים זמני לבדיקות"""
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        temp_file.close()
        yield temp_file.name
        os.unlink(temp_file.name)
    
    def test_database_initialization(self, temp_db):
        """בדיקת אתחול מסד נתונים"""
        db_manager = DatabaseManager(temp_db)
        assert os.path.exists(temp_db)
    
    def test_save_and_retrieve_failure(self, temp_db):
        """בדיקת שמירה וקבלת כשל"""
        db_manager = DatabaseManager(temp_db)
        
        # יצירת כשל
        failure = FailureEvent(
            title="בדיקת שמירה",
            category=FailureCategory.DATABASE,
            severity=FailureSeverity.HIGH
        )
        
        # שמירה
        success = db_manager.save_failure(failure)
        assert success == True
        
        # קבלה
        retrieved = db_manager.get_failure_by_id(failure.id)
        assert retrieved is not None
        assert retrieved.title == failure.title
        assert retrieved.category == failure.category
    
    def test_get_failures_with_filters(self, temp_db):
        """בדיקת קבלת כשלים עם פילטרים"""
        db_manager = DatabaseManager(temp_db)
        
        # יצירת מספר כשלים
        failures = [
            FailureEvent(title="כשל 1", category=FailureCategory.API_CALL, severity=FailureSeverity.HIGH),
            FailureEvent(title="כשל 2", category=FailureCategory.DATABASE, severity=FailureSeverity.MEDIUM),
            FailureEvent(title="כשל 3", category=FailureCategory.API_CALL, severity=FailureSeverity.LOW)
        ]
        
        for failure in failures:
            db_manager.save_failure(failure)
        
        # בדיקת פילטר לפי קטגוריה
        api_failures = db_manager.get_failures(category=FailureCategory.API_CALL)
        assert len(api_failures) == 2
        
        # בדיקת פילטר לפי חומרה
        high_failures = db_manager.get_failures(limit=10)
        assert len(high_failures) == 3


class TestFailureTracker:
    """בדיקות מעקב כשלים ראשי"""
    
    @pytest.fixture
    def temp_tracker(self):
        """יצירת tracker זמני לבדיקות"""
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        temp_file.close()
        
        tracker = FailureTracker(temp_file.name)
        yield tracker
        
        tracker.stop_monitoring()
        os.unlink(temp_file.name)
    
    def test_track_failure(self, temp_tracker):
        """בדיקת מעקב כשל"""
        failure = FailureEvent(
            title="בדיקת מעקב",
            category=FailureCategory.SYSTEM_OPERATION,
            severity=FailureSeverity.MEDIUM
        )
        
        failure_id = temp_tracker.track_failure(failure)
        assert failure_id == failure.id
        
        # וידוא שהכשל נשמר
        tracked = temp_tracker.get_failure(failure_id)
        assert tracked is not None
        assert tracked.title == failure.title
    
    def test_track_exception(self, temp_tracker):
        """בדיקת מעקב חריגה"""
        context = FailureContext(
            operation_name="test_op",
            module_name="test_module",
            function_name="test_func",
            environment="test",
            version="1.0.0"
        )
        
        try:
            raise ValueError("שגיאת בדיקה")
        except Exception as e:
            failure_id = temp_tracker.track_exception(
                e, context, 
                FailureSeverity.HIGH,
                FailureCategory.CODE_EXECUTION
            )
            
            failure = temp_tracker.get_failure(failure_id)
            assert failure is not None
            assert "ValueError" in failure.title
            assert failure.context.operation_name == "test_op"
    
    def test_resolve_failure(self, temp_tracker):
        """בדיקת פתרון כשל"""
        failure = FailureEvent(title="כשל לפתרון")
        failure_id = temp_tracker.track_failure(failure)
        
        # פתרון הכשל
        success = temp_tracker.resolve_failure(failure_id)
        assert success == True
        
        # וידוא שהכשל סומן כנפתר
        resolved_failure = temp_tracker.get_failure(failure_id)
        assert resolved_failure.resolved == True
        assert resolved_failure.resolution_time is not None
    
    def test_get_statistics(self, temp_tracker):
        """בדיקת סטטיסטיקות"""
        # יצירת כמה כשלים
        for i in range(5):
            failure = FailureEvent(title=f"כשל {i}")
            temp_tracker.track_failure(failure)
        
        stats = temp_tracker.get_statistics()
        assert stats['total_failures'] == 5
        assert stats['resolved_failures'] == 0
        assert stats['active_failures'] == 5


class TestFailureAnalyzer:
    """בדיקות מנתח כשלים"""
    
    def test_analyze_failure_trends(self):
        """בדיקת ניתוח מגמות"""
        analyzer = FailureAnalyzer()
        
        # יצירת כשלים לדוגמה
        failures = []
        for i in range(10):
            failure = FailureEvent(
                title=f"כשל {i}",
                category=FailureCategory.API_CALL if i % 2 == 0 else FailureCategory.DATABASE,
                severity=FailureSeverity.HIGH if i < 3 else FailureSeverity.MEDIUM,
                timestamp=datetime.now() - timedelta(hours=i)
            )
            failures.append(failure)
        
        result = analyzer.analyze_failure_trends(failures)
        
        assert result.analysis_type == "trends"
        assert len(result.insights) > 0
        assert result.metrics['total_failures'] == 10
        assert result.confidence_score > 0
    
    def test_analyze_failure_correlation(self):
        """בדיקת ניתוח קורלציות"""
        analyzer = FailureAnalyzer()
        
        # יצירת כשלים עם קורלציות
        failures = []
        for i in range(5):
            context = FailureContext(
                operation_name="problematic_operation",
                module_name="test_module",
                function_name="test_func",
                environment="production",
                version="1.0.0"
            )
            
            failure = FailureEvent(
                title=f"כשל קורלציה {i}",
                category=FailureCategory.API_CALL,
                severity=FailureSeverity.HIGH,
                context=context,
                timestamp=datetime.now() - timedelta(minutes=i*5)
            )
            failures.append(failure)
        
        result = analyzer.analyze_failure_correlation(failures)
        
        assert result.analysis_type == "correlation"
        assert len(result.insights) > 0


class TestPatternDetector:
    """בדיקות גלאי דפוסים"""
    
    def test_detect_text_patterns(self):
        """בדיקת זיהוי דפוסי טקסט"""
        detector = PatternDetector()
        
        # יצירת כשלים עם הודעות שגיאה דומות
        failures = [
            FailureEvent(title="כשל 1", error_message="Connection timeout to database server"),
            FailureEvent(title="כשל 2", error_message="Connection timeout to database host"),
            FailureEvent(title="כשל 3", error_message="API rate limit exceeded"),
            FailureEvent(title="כשל 4", error_message="Connection timeout to database cluster"),
            FailureEvent(title="כשל 5", error_message="API rate limit reached")
        ]
        
        patterns = detector.detect_anomalous_patterns(failures)
        
        # צריך לזהות דפוסים
        assert len(patterns) >= 0  # יכול להיות 0 אם הסף גבוה מדי
    
    def test_detect_temporal_patterns(self):
        """בדיקת זיהוי דפוסים זמניים"""
        detector = PatternDetector()
        
        # יצירת כשלים בזמנים ספציפיים
        failures = []
        base_time = datetime.now().replace(hour=14, minute=0, second=0, microsecond=0)
        
        for i in range(10):
            failure = FailureEvent(
                title=f"כשל זמני {i}",
                timestamp=base_time + timedelta(hours=i*2)  # כל שעתיים
            )
            failures.append(failure)
        
        patterns = detector.detect_anomalous_patterns(failures)
        
        # בדיקה שהתהליך עובד ללא שגיאות
        assert isinstance(patterns, list)


class TestAlertManager:
    """בדיקות מנהל התראות"""
    
    def test_add_alert_rule(self):
        """בדיקת הוספת כלל התראה"""
        alert_manager = AlertManager()
        
        rule = AlertRule(
            id="test_rule",
            name="כלל בדיקה",
            description="זהו כלל בדיקה",
            condition="severity == FailureSeverity.CRITICAL",
            severity=FailureSeverity.HIGH
        )
        
        alert_manager.add_alert_rule(rule)
        
        assert "test_rule" in alert_manager.rules
        assert alert_manager.rules["test_rule"].name == "כלל בדיקה"
    
    def test_check_alert_conditions(self):
        """בדיקת תנאי התראות"""
        alert_manager = AlertManager()
        
        # יצירת כלל התראה
        rule = AlertRule(
            id="critical_alert",
            name="התראה קריטית",
            condition="severity == FailureSeverity.CRITICAL",
            severity=FailureSeverity.CRITICAL
        )
        
        alert_manager.add_alert_rule(rule)
        
        # יצירת כשל קריטי
        failure = FailureEvent(
            title="כשל קריטי",
            severity=FailureSeverity.CRITICAL
        )
        
        # בדיקת תנאים
        triggered = alert_manager.check_alert_conditions(failure)
        
        assert "critical_alert" in triggered
    
    def test_cooldown_mechanism(self):
        """בדיקת מנגנון cooldown"""
        alert_manager = AlertManager()
        
        rule = AlertRule(
            id="cooldown_test",
            name="בדיקת cooldown",
            condition="True",  # תמיד מופעל
            severity=FailureSeverity.MEDIUM,
            cooldown_minutes=1
        )
        
        alert_manager.add_alert_rule(rule)
        
        failure = FailureEvent(title="כשל ראשון")
        
        # הפעלה ראשונה
        triggered1 = alert_manager.check_alert_conditions(failure)
        assert "cooldown_test" in triggered1
        
        # הפעלה שנייה מיד - צריכה להיות חסומה
        triggered2 = alert_manager.check_alert_conditions(failure)
        assert "cooldown_test" not in triggered2


class TestReportGenerator:
    """בדיקות מחולל דוחות"""
    
    def test_generate_daily_report(self):
        """בדיקת יצירת דוח יומי"""
        generator = ReportGenerator()
        
        # יצירת כשלים לדוגמה
        today = datetime.now()
        failures = [
            FailureEvent(
                title="כשל יומי 1",
                category=FailureCategory.API_CALL,
                severity=FailureSeverity.HIGH,
                timestamp=today
            ),
            FailureEvent(
                title="כשל יומי 2", 
                category=FailureCategory.DATABASE,
                severity=FailureSeverity.MEDIUM,
                timestamp=today,
                resolved=True,
                resolution_time=today + timedelta(minutes=30)
            )
        ]
        
        report = generator.generate_daily_report(failures, today)
        
        assert "דוח כשלים יומי" in report
        assert "2" in report  # מספר הכשלים
        assert "API" in report or "קריאת" in report
    
    def test_generate_weekly_report(self):
        """בדיקת יצירת דוח שבועי"""
        generator = ReportGenerator()
        
        # יצירת כשלים לשבוע
        start_date = datetime.now() - timedelta(days=7)
        failures = []
        
        for i in range(7):
            failure = FailureEvent(
                title=f"כשל יום {i}",
                timestamp=start_date + timedelta(days=i)
            )
            failures.append(failure)
        
        report = generator.generate_weekly_report(failures, start_date)
        
        assert "דוח כשלים שבועי" in report
        assert "7" in report  # מספר הכשלים


class TestFailureTrackerModule:
    """בדיקות המודול הראשי"""
    
    @pytest.fixture
    def temp_module(self):
        """יצירת מודול זמני לבדיקות"""
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        temp_file.close()
        
        config = {
            'database_path': temp_file.name,
            'monitoring_interval': 60,
            'auto_analysis': True,
            'auto_recovery': False  # כיבוי לבדיקות
        }
        
        module = FailureTrackerModule()
        module.config.update(config)
        
        yield module
        
        module.stop()
        os.unlink(temp_file.name)
    
    def test_module_initialization(self, temp_module):
        """בדיקת אתחול המודול"""
        assert temp_module.module_name == "failure_tracker"
        assert temp_module.version == "1.0.0"
        assert temp_module.tracker is not None
        assert temp_module.alert_manager is not None
    
    def test_module_start_stop(self, temp_module):
        """בדיקת הפעלה ועצירה"""
        assert not temp_module.is_active
        
        temp_module.start()
        assert temp_module.is_active
        
        temp_module.stop()
        assert not temp_module.is_active
    
    def test_track_failure_through_module(self, temp_module):
        """בדיקת מעקב כשל דרך המודול"""
        failure = FailureEvent(
            title="בדיקת מודול",
            category=FailureCategory.SYSTEM_OPERATION
        )
        
        failure_id = temp_module.track_failure(failure)
        assert failure_id is not None
        
        # וידוא שהכשל נשמר
        stats = temp_module.get_failure_statistics()
        assert stats['total_failures'] == 1
    
    def test_health_check(self, temp_module):
        """בדיקת תקינות המודול"""
        health = temp_module.health_check()
        
        assert 'module_status' in health
        assert 'database_status' in health
        assert 'overall_status' in health
        assert isinstance(health['issues'], list)
    
    def test_module_info(self, temp_module):
        """בדיקת מידע המודול"""
        info = temp_module.get_module_info()
        
        assert info['name'] == "failure_tracker"
        assert info['version'] == "1.0.0"
        assert 'capabilities' in info
        assert 'real_time_monitoring' in info['capabilities']


class TestIntegration:
    """בדיקות אינטגרציה"""
    
    def test_end_to_end_failure_tracking(self):
        """בדיקת מעקב כשל מקצה לקצה"""
        # יצירת מודול
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        temp_file.close()
        
        try:
            module = FailureTrackerModule()
            module.config['database_path'] = temp_file.name
            module.start()
            
            # יצירת הקשר כשל
            context = FailureContext(
                operation_name="integration_test",
                module_name="test_module",
                function_name="test_function",
                environment="test",
                version="1.0.0"
            )
            
            # יצירת כשל
            try:
                raise RuntimeError("שגיאת בדיקה אינטגרציה")
            except Exception as e:
                failure_id = module.track_exception(
                    e, context,
                    FailureSeverity.HIGH,
                    FailureCategory.CODE_EXECUTION
                )
            
            # וידוא שהכשל נוסף
            failure = module.tracker.get_failure(failure_id)
            assert failure is not None
            assert "RuntimeError" in failure.title
            
            # ניסיון פתרון
            success = module.tracker.resolve_failure(failure_id)
            assert success == True
            
            # וידוא שהכשל נפתר
            resolved_failure = module.tracker.get_failure(failure_id)
            assert resolved_failure.resolved == True
            
            # יצירת דוח
            report = module.generate_daily_report()
            assert "RuntimeError" in report or "שגיאת בדיקה" in report
            
            # בדיקת סטטיסטיקות
            stats = module.get_failure_statistics()
            assert stats['total_failures'] == 1
            assert stats['resolved_failures'] == 1
            
            module.stop()
            
        finally:
            os.unlink(temp_file.name)


# הפעלת הבדיקות
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])