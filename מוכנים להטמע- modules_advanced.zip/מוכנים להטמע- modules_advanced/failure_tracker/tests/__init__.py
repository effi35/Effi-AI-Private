"""
בדיקות יחידה למודול מעקב כשלים - Failure Tracker Tests
"""