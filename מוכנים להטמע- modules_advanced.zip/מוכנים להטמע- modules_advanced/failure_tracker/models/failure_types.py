"""
סוגי כשלים ומבני נתונים - Failure Types and Data Structures
מודל נתונים מקיף למעקב אחר כשלים במערכת
"""

import json
import uuid
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any, Tuple
import traceback


class FailureSeverity(Enum):
    """רמות חומרה של כשלים"""
    CRITICAL = "קריטי"      # Critical
    HIGH = "גבוה"           # High
    MEDIUM = "בינוני"       # Medium
    LOW = "נמוך"            # Low
    WARNING = "אזהרה"       # Warning


class FailureCategory(Enum):
    """קטגוריות כשלים"""
    CODE_EXECUTION = "ביצוע_קוד"              # Code execution failures
    API_CALL = "קריאת_API"                   # API call failures
    SYSTEM_OPERATION = "פעולת_מערכת"          # System operation failures
    PERFORMANCE = "ביצועים"                   # Performance degradation
    RESOURCE_EXHAUSTION = "תשישות_משאבים"     # Resource exhaustion
    COMMUNICATION = "תקשורת"                  # Communication failures
    DATA_PROCESSING = "עיבוד_נתונים"          # Data processing errors
    AUTHENTICATION = "אימות"                  # Authentication failures
    CONFIGURATION = "תצורה"                   # Configuration errors
    NETWORK = "רשת"                          # Network issues
    DATABASE = "בסיס_נתונים"                 # Database errors
    FILE_SYSTEM = "מערכת_קבצים"              # File system errors
    MEMORY = "זיכרון"                        # Memory issues
    TIMEOUT = "פסק_זמן"                     # Timeout errors
    UNKNOWN = "לא_ידוע"                     # Unknown failures


@dataclass
class SystemState:
    """מצב המערכת בזמן הכשל"""
    timestamp: datetime
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    active_processes: int
    system_load: float
    network_status: bool
    database_status: bool
    api_response_time: float
    error_rate: float
    active_users: int
    system_uptime: timedelta
    custom_metrics: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        data = asdict(self)
        data['timestamp'] = self.timestamp.isoformat()
        data['system_uptime'] = str(self.system_uptime)
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SystemState':
        """יצירה ממילון"""
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        data['system_uptime'] = timedelta(seconds=float(data['system_uptime'].split(':')[-1]))
        return cls(**data)


@dataclass
class FailureContext:
    """הקשר הכשל"""
    operation_name: str
    module_name: str
    function_name: str
    parameters: Dict[str, Any]
    user_id: Optional[str]
    session_id: Optional[str]
    request_id: Optional[str]
    previous_operations: List[str]
    environment: str
    version: str
    configuration: Dict[str, Any] = field(default_factory=dict)
    user_agent: Optional[str] = None
    ip_address: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FailureContext':
        """יצירה ממילון"""
        return cls(**data)


@dataclass
class RecoveryAction:
    """פעולת התאוששות"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    action_type: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    execution_time: Optional[datetime] = None
    success: Optional[bool] = None
    result: Optional[str] = None
    error_message: Optional[str] = None
    execution_duration: Optional[timedelta] = None
    effectiveness_score: Optional[float] = None  # 0.0 - 1.0
    side_effects: List[str] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)
    rollback_possible: bool = True
    rollback_instructions: Optional[str] = None
    
    def execute(self, context: Dict[str, Any] = None) -> bool:
        """ביצוע פעולת ההתאוששות"""
        try:
            start_time = datetime.now()
            self.execution_time = start_time
            
            # כאן יבוא הלוגיקה לביצוע הפעולה
            # לדוגמה: restart service, clear cache, reset connection וכו'
            
            # סימולציה של ביצוע פעולה
            success = self._perform_action(context or {})
            
            end_time = datetime.now()
            self.execution_duration = end_time - start_time
            self.success = success
            
            if success:
                self.result = f"פעולת התאוששות '{self.name}' הושלמה בהצלחה"
            else:
                self.error_message = f"פעולת התאוששות '{self.name}' נכשלה"
                
            return success
            
        except Exception as e:
            self.success = False
            self.error_message = f"שגיאה בביצוע פעולת התאוששות: {str(e)}"
            return False
    
    def _perform_action(self, context: Dict[str, Any]) -> bool:
        """ביצוע הפעולה הממשית - לממש בקלאסים היורשים"""
        return True
    
    def calculate_effectiveness(self, failure_resolved: bool, 
                              time_to_resolution: timedelta,
                              side_effects_occurred: int) -> float:
        """חישוב יעילות הפעולה"""
        if not failure_resolved:
            self.effectiveness_score = 0.0
            return 0.0
        
        # ציון בסיס עבור פתרון הבעיה
        base_score = 0.8
        
        # בונוס לזמן התאוששות קצר
        if time_to_resolution < timedelta(minutes=5):
            base_score += 0.1
        elif time_to_resolution > timedelta(hours=1):
            base_score -= 0.2
        
        # קנס על תופעות לוואי
        if side_effects_occurred > 0:
            base_score -= (side_effects_occurred * 0.1)
        
        self.effectiveness_score = max(0.0, min(1.0, base_score))
        return self.effectiveness_score
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        data = asdict(self)
        if self.execution_time:
            data['execution_time'] = self.execution_time.isoformat()
        if self.execution_duration:
            data['execution_duration'] = str(self.execution_duration)
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RecoveryAction':
        """יצירה ממילון"""
        if 'execution_time' in data and data['execution_time']:
            data['execution_time'] = datetime.fromisoformat(data['execution_time'])
        if 'execution_duration' in data and data['execution_duration']:
            parts = data['execution_duration'].split(':')
            if len(parts) == 3:
                hours, minutes, seconds = map(float, parts)
                data['execution_duration'] = timedelta(hours=hours, minutes=minutes, seconds=seconds)
        return cls(**data)


@dataclass
class FailurePattern:
    """דפוס כשל"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    category: FailureCategory = FailureCategory.UNKNOWN
    conditions: List[str] = field(default_factory=list)
    frequency: int = 0
    first_occurrence: Optional[datetime] = None
    last_occurrence: Optional[datetime] = None
    affected_operations: List[str] = field(default_factory=list)
    common_contexts: List[str] = field(default_factory=list)
    success_rate: float = 0.0
    average_resolution_time: Optional[timedelta] = None
    recommended_actions: List[str] = field(default_factory=list)
    prevention_strategies: List[str] = field(default_factory=list)
    
    def update_statistics(self, new_failure: 'FailureEvent'):
        """עדכון סטטיסטיקות הדפוס"""
        self.frequency += 1
        
        if not self.first_occurrence:
            self.first_occurrence = new_failure.timestamp
        
        self.last_occurrence = new_failure.timestamp
        
        if new_failure.context.operation_name not in self.affected_operations:
            self.affected_operations.append(new_failure.context.operation_name)
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        data = asdict(self)
        data['category'] = self.category.value
        if self.first_occurrence:
            data['first_occurrence'] = self.first_occurrence.isoformat()
        if self.last_occurrence:
            data['last_occurrence'] = self.last_occurrence.isoformat()
        if self.average_resolution_time:
            data['average_resolution_time'] = str(self.average_resolution_time)
        return data


@dataclass
class FailureEvent:
    """אירוע כשל"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    category: FailureCategory = FailureCategory.UNKNOWN
    severity: FailureSeverity = FailureSeverity.MEDIUM
    title: str = ""
    description: str = ""
    error_message: str = ""
    stack_trace: Optional[str] = None
    context: Optional[FailureContext] = None
    system_state: Optional[SystemState] = None
    
    # מידע על הכשל
    duration: Optional[timedelta] = None
    resolved: bool = False
    resolution_time: Optional[datetime] = None
    resolution_duration: Optional[timedelta] = None
    
    # פעולות התאוששות
    attempted_actions: List[RecoveryAction] = field(default_factory=list)
    successful_action: Optional[RecoveryAction] = None
    
    # קישורים והיסטוריה
    related_failures: List[str] = field(default_factory=list)  # IDs של כשלים קשורים
    pattern_id: Optional[str] = None
    similar_historical_failures: List[str] = field(default_factory=list)
    
    # המלצות והצעות
    suggested_alternatives: List[str] = field(default_factory=list)
    prevention_suggestions: List[str] = field(default_factory=list)
    
    # מטא-דאטה
    tags: List[str] = field(default_factory=list)
    custom_data: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """אתחול לאחר יצירה"""
        if not self.title and self.error_message:
            self.title = self.error_message[:100] + "..." if len(self.error_message) > 100 else self.error_message
        
        if not self.stack_trace and self.error_message:
            # ניסיון לקבל stack trace אם זמין
            try:
                self.stack_trace = traceback.format_exc()
            except:
                pass
    
    def add_recovery_action(self, action: RecoveryAction) -> None:
        """הוספת פעולת התאוששות"""
        self.attempted_actions.append(action)
        
        if action.success:
            self.successful_action = action
            self.mark_resolved()
    
    def mark_resolved(self, resolution_time: Optional[datetime] = None) -> None:
        """סימון הכשל כנפתר"""
        self.resolved = True
        self.resolution_time = resolution_time or datetime.now()
        
        if self.resolution_time:
            self.resolution_duration = self.resolution_time - self.timestamp
    
    def add_similar_failure(self, failure_id: str) -> None:
        """הוספת כשל דומה"""
        if failure_id not in self.similar_historical_failures:
            self.similar_historical_failures.append(failure_id)
    
    def add_suggested_alternative(self, alternative: str) -> None:
        """הוספת חלופה מוצעת"""
        if alternative not in self.suggested_alternatives:
            self.suggested_alternatives.append(alternative)
    
    def calculate_impact_score(self) -> float:
        """חישוב ציון השפעה"""
        # ציון בסיס לפי חומרה
        severity_scores = {
            FailureSeverity.CRITICAL: 1.0,
            FailureSeverity.HIGH: 0.8,
            FailureSeverity.MEDIUM: 0.6,
            FailureSeverity.LOW: 0.4,
            FailureSeverity.WARNING: 0.2
        }
        
        base_score = severity_scores.get(self.severity, 0.5)
        
        # מקדם זמן פתרון
        if self.resolution_duration:
            if self.resolution_duration > timedelta(hours=4):
                base_score *= 1.5
            elif self.resolution_duration > timedelta(hours=1):
                base_score *= 1.2
        
        # מקדם כשלים קשורים
        if len(self.related_failures) > 0:
            base_score *= (1 + len(self.related_failures) * 0.1)
        
        return min(1.0, base_score)
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        data = asdict(self)
        data['timestamp'] = self.timestamp.isoformat()
        data['category'] = self.category.value
        data['severity'] = self.severity.value
        
        if self.duration:
            data['duration'] = str(self.duration)
        if self.resolution_time:
            data['resolution_time'] = self.resolution_time.isoformat()
        if self.resolution_duration:
            data['resolution_duration'] = str(self.resolution_duration)
        
        if self.context:
            data['context'] = self.context.to_dict()
        if self.system_state:
            data['system_state'] = self.system_state.to_dict()
        
        data['attempted_actions'] = [action.to_dict() for action in self.attempted_actions]
        if self.successful_action:
            data['successful_action'] = self.successful_action.to_dict()
        
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FailureEvent':
        """יצירה ממילון"""
        # המרת תאריכים
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        if 'resolution_time' in data and data['resolution_time']:
            data['resolution_time'] = datetime.fromisoformat(data['resolution_time'])
        
        # המרת זמנים
        if 'duration' in data and data['duration']:
            parts = data['duration'].split(':')
            if len(parts) >= 2:
                data['duration'] = timedelta(hours=int(parts[0]), minutes=int(parts[1]), 
                                           seconds=float(parts[2]) if len(parts) > 2 else 0)
        
        if 'resolution_duration' in data and data['resolution_duration']:
            parts = data['resolution_duration'].split(':')
            if len(parts) >= 2:
                data['resolution_duration'] = timedelta(hours=int(parts[0]), minutes=int(parts[1]),
                                                       seconds=float(parts[2]) if len(parts) > 2 else 0)
        
        # המרת enums
        data['category'] = FailureCategory(data['category'])
        data['severity'] = FailureSeverity(data['severity'])
        
        # המרת אובייקטים מקוננים
        if 'context' in data and data['context']:
            data['context'] = FailureContext.from_dict(data['context'])
        if 'system_state' in data and data['system_state']:
            data['system_state'] = SystemState.from_dict(data['system_state'])
        
        # המרת פעולות התאוששות
        if 'attempted_actions' in data:
            data['attempted_actions'] = [RecoveryAction.from_dict(action) 
                                       for action in data['attempted_actions']]
        if 'successful_action' in data and data['successful_action']:
            data['successful_action'] = RecoveryAction.from_dict(data['successful_action'])
        
        return cls(**data)
    
    def to_json(self) -> str:
        """המרה ל-JSON"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'FailureEvent':
        """יצירה מ-JSON"""
        data = json.loads(json_str)
        return cls.from_dict(data)


# קבועים ודוגמאות
DEFAULT_RECOVERY_ACTIONS = {
    FailureCategory.API_CALL: [
        RecoveryAction(
            name="ניסיון חוזר",
            description="ניסיון שוב לקריאת ה-API",
            action_type="retry",
            parameters={"max_attempts": 3, "delay": 1}
        ),
        RecoveryAction(
            name="שינוי endpoint",
            description="מעבר ל-endpoint חלופי",
            action_type="failover",
            parameters={"fallback_url": "backup_api"}
        )
    ],
    FailureCategory.DATABASE: [
        RecoveryAction(
            name="איפוס חיבור",
            description="איפוס חיבור למסד הנתונים",
            action_type="reconnect",
            parameters={"timeout": 30}
        ),
        RecoveryAction(
            name="מעבר לעותק",
            description="מעבר למסד נתונים גיבוי",
            action_type="failover",
            parameters={"backup_db": "replica"}
        )
    ],
    FailureCategory.MEMORY: [
        RecoveryAction(
            name="ניקוי cache",
            description="ניקוי זיכרון cache",
            action_type="cleanup",
            parameters={"cache_type": "all"}
        ),
        RecoveryAction(
            name="הפעלה מחדש",
            description="הפעלה מחדש של השירות",
            action_type="restart",
            parameters={"graceful": True}
        )
    ]
}


def create_failure_from_exception(exception: Exception, 
                                context: Optional[FailureContext] = None,
                                severity: FailureSeverity = FailureSeverity.MEDIUM,
                                category: FailureCategory = FailureCategory.UNKNOWN) -> FailureEvent:
    """יצירת אירוע כשל מחריגה"""
    
    failure = FailureEvent(
        title=f"{type(exception).__name__}: {str(exception)}",
        description=f"חריגה מסוג {type(exception).__name__} התרחשה במערכת",
        error_message=str(exception),
        stack_trace=traceback.format_exc(),
        category=category,
        severity=severity,
        context=context
    )
    
    # הוספת המלצות בהתבסס על סוג החריגה
    if isinstance(exception, ConnectionError):
        failure.category = FailureCategory.NETWORK
        failure.add_suggested_alternative("בדיקת חיבור הרשת")
        failure.add_suggested_alternative("ניסיון עם שרת חלופי")
        
    elif isinstance(exception, TimeoutError):
        failure.category = FailureCategory.TIMEOUT
        failure.add_suggested_alternative("הגדלת זמן המתנה")
        failure.add_suggested_alternative("אופטימיזציה של הפעולה")
        
    elif isinstance(exception, MemoryError):
        failure.category = FailureCategory.MEMORY
        failure.add_suggested_alternative("ניקוי זיכרון")
        failure.add_suggested_alternative("הגדלת הקצאת זיכרון")
        
    elif isinstance(exception, PermissionError):
        failure.category = FailureCategory.AUTHENTICATION
        failure.add_suggested_alternative("בדיקת הרשאות")
        failure.add_suggested_alternative("הפעלה עם הרשאות מנהל")
    
    return failure