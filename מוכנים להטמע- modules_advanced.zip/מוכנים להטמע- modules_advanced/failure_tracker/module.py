"""
מודול מעקב כשלים - Failure Tracker Module
מודול מקיף למעקב, ניתוח וטיפול בכשלים במערכת בזמן אמת
"""

import os
import sys
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

# הוספת נתיב המודול
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

from models.failure_types import (
    FailureEvent, FailureCategory, FailureSeverity, FailurePattern,
    RecoveryAction, SystemState, FailureContext, create_failure_from_exception
)
from core.failure_tracker import FailureTracker, RealTimeMonitor, PatternAnalyzer, RecoveryManager
from ui.failure_dashboard import FailureDashboard, create_dashboard_app
from utils.failure_utils import (
    FailureAnalyzer, PatternDetector, AlertManager, ReportGenerator,
    MetricsCollector, HebrewLocalizer, analyze_failure_batch,
    generate_comprehensive_report
)


class FailureTrackerModule:
    """מודול מעקב כשלים ראשי"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.module_name = "failure_tracker"
        self.version = "1.0.0"
        self.description = "מערכת מעקב וניתוח כשלים מתקדמת"
        
        # טעינת תצורה
        self.config = self._load_config(config_path)
        
        # אתחול רכיבים
        self.tracker = FailureTracker(self.config.get('database_path', 'failure_tracker.db'))
        self.alert_manager = AlertManager()
        self.report_generator = ReportGenerator()
        self.metrics_collector = MetricsCollector()
        self.localizer = HebrewLocalizer()
        
        # הגדרת logging
        self._setup_logging()
        
        # הגדרת התראות ברירת מחדל
        self._setup_default_alerts()
        
        # הגדרת callbacks
        self._setup_callbacks()
        
        # מצב פעילות
        self.is_active = False
        
        logging.info(f"מודול מעקב כשלים הותחל - גרסה {self.version}")
    
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """טעינת תצורה"""
        default_config = {
            'database_path': 'failure_tracker.db',
            'monitoring_interval': 30,
            'auto_analysis': True,
            'auto_recovery': True,
            'cache_size': 1000,
            'email_alerts': False,
            'log_level': 'INFO',
            'log_file': 'failure_tracker.log',
            'export_path': './exports',
            'alert_cooldown': 60,
            'pattern_similarity_threshold': 0.7,
            'max_recovery_attempts': 3,
            'hebrew_interface': True
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                default_config.update(user_config)
                logging.info(f"תצורה נטענה מ: {config_path}")
            except Exception as e:
                logging.warning(f"שגיאה בטעינת תצורה: {e}, משתמש בברירת מחדל")
        
        return default_config
    
    def _setup_logging(self):
        """הגדרת מערכת הלוגים"""
        log_level = getattr(logging, self.config.get('log_level', 'INFO'))
        log_file = self.config.get('log_file', 'failure_tracker.log')
        
        # הגדרת format עם תמיכה בעברית
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # קובץ לוג
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        
        # קונסול
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(log_level)
        
        # הגדרת logger
        logger = logging.getLogger(self.module_name)
        logger.setLevel(log_level)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    def _setup_default_alerts(self):
        """הגדרת התראות ברירת מחדל"""
        if self.config.get('create_default_alerts', True):
            self.alert_manager.create_default_rules()
        
        # הגדרת אימייל אם נדרש
        if self.config.get('email_alerts', False):
            email_config = self.config.get('email_config', {})
            if email_config:
                self.alert_manager.configure_email(**email_config)
    
    def _setup_callbacks(self):
        """הגדרת callbacks למערכת"""
        # callback למעקב אחר כשלים חדשים
        self.tracker.subscribe_to_events(self._on_failure_event)
        
        # callback להתראות
        self.tracker.add_alert_callback(self._on_system_alert)
    
    def _on_failure_event(self, event_type: str, data: Any):
        """טיפול באירוע כשל"""
        if event_type == 'failure_tracked':
            failure = data
            logging.info(f"כשל חדש נוסף למעקב: {failure.id}")
            
            # בדיקת תנאי התראות
            current_metrics = self.metrics_collector.collect_current_metrics()
            triggered_alerts = self.alert_manager.check_alert_conditions(failure, current_metrics)
            
            if triggered_alerts:
                logging.warning(f"הופעלו {len(triggered_alerts)} התראות עבור כשל {failure.id}")
        
        elif event_type == 'failure_resolved':
            failure = data
            logging.info(f"כשל נפתר: {failure.id}")
    
    def _on_system_alert(self, message: str, system_state: Any):
        """טיפול בהתראת מערכת"""
        logging.warning(f"התראת מערכת: {message}")
    
    def start(self):
        """הפעלת המודול"""
        if self.is_active:
            logging.warning("המודול כבר פעיל")
            return
        
        try:
            # הפעלת מעקב זמן אמת
            monitoring_interval = self.config.get('monitoring_interval', 30)
            self.tracker.start_monitoring(monitoring_interval)
            
            self.is_active = True
            logging.info("מודול מעקב כשלים הופעל בהצלחה")
            
        except Exception as e:
            logging.error(f"שגיאה בהפעלת המודול: {e}")
            raise
    
    def stop(self):
        """עצירת המודול"""
        if not self.is_active:
            logging.warning("המודול לא פעיל")
            return
        
        try:
            # עצירת מעקב זמן אמת
            self.tracker.stop_monitoring()
            
            self.is_active = False
            logging.info("מודול מעקב כשלים הופסק")
            
        except Exception as e:
            logging.error(f"שגיאה בעצירת המודול: {e}")
    
    def track_failure(self, failure: FailureEvent) -> str:
        """מעקב אחר כשל"""
        return self.tracker.track_failure(failure)
    
    def track_exception(self, exception: Exception, 
                       context: Optional[FailureContext] = None,
                       severity: FailureSeverity = FailureSeverity.MEDIUM,
                       category: FailureCategory = FailureCategory.UNKNOWN) -> str:
        """מעקב אחר חריגה"""
        return self.tracker.track_exception(exception, context, severity, category)
    
    def get_failure_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות כשלים"""
        stats = self.tracker.get_statistics()
        
        # הוספת מטריקות נוספות
        recent_failures = self.tracker.get_recent_failures(hours=24)
        stats['recent_failures_24h'] = len(recent_failures)
        
        # ניתוח מגמות
        analyzer = FailureAnalyzer()
        trends = analyzer.analyze_failure_trends(recent_failures)
        stats['trends_analysis'] = {
            'summary': trends.summary,
            'confidence': trends.confidence_score,
            'priority': trends.priority
        }
        
        return stats
    
    def generate_daily_report(self, date: Optional[datetime] = None) -> str:
        """יצירת דוח יומי"""
        failures = self.tracker.get_failures(limit=1000)
        return self.report_generator.generate_daily_report(failures, date)
    
    def generate_weekly_report(self, start_date: Optional[datetime] = None) -> str:
        """יצירת דוח שבועי"""
        failures = self.tracker.get_failures(limit=5000)
        return self.report_generator.generate_weekly_report(failures, start_date)
    
    def export_failures(self, filepath: str, format: str = 'json',
                       filters: Optional[Dict[str, Any]] = None) -> bool:
        """ייצוא כשלים"""
        try:
            # יצירת תיקיית ייצוא אם לא קיימת
            export_dir = Path(self.config.get('export_path', './exports'))
            export_dir.mkdir(exist_ok=True)
            
            # נתיב מלא
            full_path = export_dir / filepath
            
            return self.tracker.export_failures(str(full_path), format)
            
        except Exception as e:
            logging.error(f"שגיאה בייצוא כשלים: {e}")
            return False
    
    def run_analysis(self, analysis_type: str = 'comprehensive') -> Dict[str, Any]:
        """הרצת ניתוח כשלים"""
        recent_failures = self.tracker.get_recent_failures(hours=168)  # שבוע
        
        if analysis_type == 'trends':
            analyzer = FailureAnalyzer()
            result = analyzer.analyze_failure_trends(recent_failures)
            return {'trends': result}
        
        elif analysis_type == 'patterns':
            detector = PatternDetector()
            patterns = detector.detect_anomalous_patterns(recent_failures)
            return {'patterns': patterns}
        
        elif analysis_type == 'comprehensive':
            return analyze_failure_batch(recent_failures)
        
        else:
            raise ValueError(f"סוג ניתוח לא נתמך: {analysis_type}")
    
    def create_dashboard(self, port: int = 8501) -> None:
        """יצירת דשבורד אינטראקטיבי"""
        try:
            import streamlit.web.cli as stcli
            import sys
            
            # יצירת קובץ דשבורד זמני
            dashboard_file = Path(__file__).parent / "temp_dashboard.py"
            
            dashboard_code = f"""
import sys
sys.path.insert(0, r'{Path(__file__).parent}')

from ui.failure_dashboard import create_dashboard_app
from core.failure_tracker import FailureTracker

# יצירת tracker
tracker = FailureTracker(r'{self.tracker.db_manager.db_path}')

# הפעלת דשבורד
create_dashboard_app(tracker)
"""
            
            with open(dashboard_file, 'w', encoding='utf-8') as f:
                f.write(dashboard_code)
            
            # הפעלת streamlit
            sys.argv = ["streamlit", "run", str(dashboard_file), "--server.port", str(port)]
            stcli.main()
            
        except ImportError:
            logging.error("Streamlit לא מותקן. אנא התקן עם: pip install streamlit")
        except Exception as e:
            logging.error(f"שגיאה בהפעלת דשבורד: {e}")
        finally:
            # ניקוי קובץ זמני
            if 'dashboard_file' in locals() and dashboard_file.exists():
                dashboard_file.unlink()
    
    def get_module_info(self) -> Dict[str, Any]:
        """קבלת מידע על המודול"""
        return {
            'name': self.module_name,
            'version': self.version,
            'description': self.description,
            'is_active': self.is_active,
            'config': self.config,
            'statistics': self.get_failure_statistics(),
            'capabilities': [
                'real_time_monitoring',
                'failure_tracking',
                'pattern_analysis',
                'auto_recovery',
                'alerting',
                'reporting',
                'dashboard',
                'hebrew_support'
            ]
        }
    
    def health_check(self) -> Dict[str, Any]:
        """בדיקת תקינות המודול"""
        health = {
            'module_status': 'healthy' if self.is_active else 'inactive',
            'database_status': 'healthy',
            'monitoring_status': 'active' if self.tracker.monitor.monitoring else 'inactive',
            'last_check': datetime.now().isoformat(),
            'issues': []
        }
        
        try:
            # בדיקת בסיס נתונים
            test_failures = self.tracker.get_failures(limit=1)
            
            # בדיקת מטריקות
            current_metrics = self.metrics_collector.collect_current_metrics()
            
            # בדיקת דיסק
            if current_metrics.disk_usage > 90:
                health['issues'].append('שימוש דיסק גבוה')
            
            # בדיקת זיכרון
            if current_metrics.memory_usage > 85:
                health['issues'].append('שימוש זיכרון גבוה')
            
        except Exception as e:
            health['database_status'] = 'error'
            health['issues'].append(f'שגיאה בבסיס נתונים: {str(e)}')
        
        health['overall_status'] = 'healthy' if not health['issues'] else 'warning'
        
        return health


# פונקציות יצירה ואתחול
def create_failure_tracker_module(config_path: Optional[str] = None) -> FailureTrackerModule:
    """יצירת מודול מעקב כשלים"""
    return FailureTrackerModule(config_path)


def initialize_module(config: Dict[str, Any] = None) -> FailureTrackerModule:
    """אתחול המודול עם תצורה"""
    module = FailureTrackerModule()
    
    if config:
        module.config.update(config)
    
    module.start()
    return module


# דוגמאות שימוש
def demo_usage():
    """דוגמה לשימוש במודול"""
    print("🔍 דוגמה - מודול מעקב כשלים")
    
    # יצירת מודול
    module = create_failure_tracker_module()
    module.start()
    
    try:
        # יצירת כשל לדוגמה
        try:
            # יצירת שגיאה מכוונת
            result = 1 / 0
        except Exception as e:
            # מעקב אחר השגיאה
            context = FailureContext(
                operation_name="demo_division",
                module_name="failure_tracker_demo",
                function_name="demo_usage",
                parameters={"x": 1, "y": 0},
                user_id="demo_user",
                session_id="demo_session",
                request_id="demo_request",
                previous_operations=["demo_init"],
                environment="development",
                version="1.0.0"
            )
            
            failure_id = module.track_exception(
                e, 
                context, 
                FailureSeverity.MEDIUM,
                FailureCategory.CODE_EXECUTION
            )
            
            print(f"✅ כשל נוסף למעקב: {failure_id}")
        
        # קבלת סטטיסטיקות
        stats = module.get_failure_statistics()
        print(f"📊 סטטיסטיקות: {stats['total_failures']} כשלים סה\"כ")
        
        # יצירת דוח יומי
        daily_report = module.generate_daily_report()
        print("\n📋 דוח יומי:")
        print(daily_report)
        
        # הרצת ניתוח
        analysis = module.run_analysis('trends')
        print(f"\n🔍 ניתוח מגמות: {analysis['trends'].summary}")
        
        # בדיקת תקינות
        health = module.health_check()
        print(f"\n💊 בדיקת תקינות: {health['overall_status']}")
        
    finally:
        module.stop()


# נקודת כניסה ראשית
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='מודול מעקב כשלים')
    parser.add_argument('--demo', action='store_true', help='הרצת דוגמה')
    parser.add_argument('--dashboard', action='store_true', help='הפעלת דשבורד')
    parser.add_argument('--config', type=str, help='נתיב קובץ תצורה')
    parser.add_argument('--port', type=int, default=8501, help='פורט לדשבורד')
    
    args = parser.parse_args()
    
    if args.demo:
        demo_usage()
    elif args.dashboard:
        module = create_failure_tracker_module(args.config)
        module.start()
        try:
            module.create_dashboard(args.port)
        finally:
            module.stop()
    else:
        print("שימוש: python module.py [--demo] [--dashboard] [--config CONFIG]")
        print("לעזרה: python module.py --help")