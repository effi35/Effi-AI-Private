"""
ממשק משתמש למעקב כשלים - Failure Tracker UI
דשבורד ומסכים לצפייה, ניתוח וטיפול בכשלים
"""

from .failure_dashboard import (
    FailureDashboard,
    FailureViewer,
    PatternAnalysisPanel,
    RecoveryPanel,
    AlertsPanel
)

__all__ = [
    'FailureDashboard',
    'FailureViewer',
    'PatternAnalysisPanel', 
    'RecoveryPanel',
    'AlertsPanel'
]