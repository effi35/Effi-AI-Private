"""
דשבורד כשלים - Failure Dashboard
ממשק מקיף לצפייה, ניתוח וניהול כשלים במערכת
"""

import json
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import asdict
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh
import extra_streamlit_components as stx

from ..models.failure_types import (
    FailureEvent, FailureCategory, FailureSeverity, FailurePattern,
    RecoveryAction, SystemState
)
from ..core.failure_tracker import FailureTracker


class FailureDashboard:
    """דשבורד ראשי למעקב כשלים"""
    
    def __init__(self, tracker: FailureTracker):
        self.tracker = tracker
        self.page_config = {
            "page_title": "מעקב כשלים - Failure Tracker",
            "page_icon": "⚠️",
            "layout": "wide",
            "initial_sidebar_state": "expanded"
        }
        
        # צבעים ונושאים
        self.colors = {
            'critical': '#FF4444',
            'high': '#FF8800',
            'medium': '#FFAA00',
            'low': '#88BB00',
            'warning': '#0088BB',
            'success': '#00AA44',
            'background': '#F8F9FA',
            'text': '#2E3B4E'
        }
        
        # הגדרות רענון
        self.auto_refresh_interval = 30  # שניות
        
    def render(self):
        """רינדור הדשבורד"""
        # הגדרת עמוד
        st.set_page_config(**self.page_config)
        
        # CSS מותאם אישית
        self._inject_custom_css()
        
        # כותרת ראשית
        st.title("🔍 מעקב כשלים - Failure Tracker")
        st.markdown("---")
        
        # רענון אוטומטי
        count = st_autorefresh(interval=self.auto_refresh_interval * 1000, key="dashboard_refresh")
        
        # תפריט צד
        self._render_sidebar()
        
        # תוכן ראשי
        selected_tab = st.session_state.get('selected_tab', 'overview')
        
        if selected_tab == 'overview':
            self._render_overview()
        elif selected_tab == 'failures':
            self._render_failures_list()
        elif selected_tab == 'patterns':
            self._render_patterns_analysis()
        elif selected_tab == 'recovery':
            self._render_recovery_panel()
        elif selected_tab == 'alerts':
            self._render_alerts_panel()
        elif selected_tab == 'settings':
            self._render_settings()
    
    def _inject_custom_css(self):
        """הזרקת CSS מותאם אישית"""
        st.markdown("""
        <style>
        /* Hebrew RTL support */
        .hebrew-text {
            direction: rtl;
            text-align: right;
            font-family: 'Arial', sans-serif;
        }
        
        /* מטריקות */
        .metric-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 10px 0;
        }
        
        .metric-value {
            font-size: 2.5rem;
            font-weight: bold;
            margin: 0;
        }
        
        .metric-label {
            font-size: 1rem;
            color: #666;
            margin: 0;
        }
        
        /* חומרת כשלים */
        .severity-critical { color: #FF4444; }
        .severity-high { color: #FF8800; }
        .severity-medium { color: #FFAA00; }
        .severity-low { color: #88BB00; }
        .severity-warning { color: #0088BB; }
        
        /* סטטוס כשלים */
        .status-resolved { color: #00AA44; }
        .status-active { color: #FF4444; }
        
        /* כרטיסי כשלים */
        .failure-card {
            background: white;
            border-left: 4px solid #ccc;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .failure-card.critical { border-left-color: #FF4444; }
        .failure-card.high { border-left-color: #FF8800; }
        .failure-card.medium { border-left-color: #FFAA00; }
        .failure-card.low { border-left-color: #88BB00; }
        .failure-card.warning { border-left-color: #0088BB; }
        
        /* התראות */
        .alert-banner {
            background: #FFE6E6;
            border: 1px solid #FF4444;
            color: #CC0000;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        
        /* טבלאות */
        .dataframe {
            font-size: 0.9rem;
        }
        
        /* טאבים */
        .tab-container {
            margin: 20px 0;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def _render_sidebar(self):
        """רינדור תפריט צד"""
        with st.sidebar:
            st.header("🧭 ניווט")
            
            # בחירת טאב
            tabs = {
                'overview': '📊 סקירה כללית',
                'failures': '⚠️ רשימת כשלים',
                'patterns': '🔍 ניתוח דפוסים',
                'recovery': '🔧 התאוששות',
                'alerts': '🔔 התראות',
                'settings': '⚙️ הגדרות'
            }
            
            selected = st.radio("בחר מסך:", options=list(tabs.keys()), 
                              format_func=lambda x: tabs[x],
                              key="selected_tab")
            
            st.markdown("---")
            
            # סטטוס מערכת
            st.subheader("📈 סטטוס מערכת")
            stats = self.tracker.get_statistics()
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("כשלים פעילים", stats.get('active_failures', 0))
            with col2:
                st.metric("סה\"כ כשלים", stats.get('total_failures', 0))
            
            resolution_rate = stats.get('resolution_rate', 0) * 100
            st.metric("אחוז פתרון", f"{resolution_rate:.1f}%")
            
            # מעקב זמן אמת
            st.markdown("---")
            st.subheader("⏱️ מעקב זמן אמת")
            
            monitoring_status = "פעיל" if self.tracker.monitor.monitoring else "לא פעיל"
            st.info(f"מצב מעקב: {monitoring_status}")
            
            if st.button("🔄 רענון ידני"):
                st.rerun()
            
            # מטריקות מערכת אחרונות
            current_metrics = self.tracker.monitor.get_current_metrics()
            if current_metrics:
                st.subheader("💻 מטריקות מערכת")
                st.metric("שימוש CPU", f"{current_metrics.cpu_usage:.1f}%")
                st.metric("שימוש זיכרון", f"{current_metrics.memory_usage:.1f}%")
                st.metric("שימוש דיסק", f"{current_metrics.disk_usage:.1f}%")
    
    def _render_overview(self):
        """רינדור סקירה כללית"""
        st.header("📊 סקירה כללית")
        
        # מטריקות ראשיות
        self._render_main_metrics()
        
        st.markdown("---")
        
        # גרפים
        col1, col2 = st.columns(2)
        
        with col1:
            self._render_failures_timeline()
            self._render_category_distribution()
        
        with col2:
            self._render_severity_distribution()
            self._render_resolution_time_trend()
        
        # התראות פעילות
        self._render_active_alerts()
    
    def _render_main_metrics(self):
        """רינדור מטריקות ראשיות"""
        stats = self.tracker.get_statistics()
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric(
                label="📊 סה\"כ כשלים",
                value=stats.get('total_failures', 0),
                delta=self._get_metric_delta('total_failures')
            )
        
        with col2:
            active_failures = stats.get('active_failures', 0)
            st.metric(
                label="⚠️ כשלים פעילים",
                value=active_failures,
                delta=self._get_metric_delta('active_failures'),
                delta_color="inverse"
            )
        
        with col3:
            resolved = stats.get('resolved_failures', 0)
            st.metric(
                label="✅ כשלים נפתרים",
                value=resolved,
                delta=self._get_metric_delta('resolved_failures')
            )
        
        with col4:
            resolution_rate = stats.get('resolution_rate', 0) * 100
            st.metric(
                label="📈 אחוז פתרון",
                value=f"{resolution_rate:.1f}%",
                delta=self._get_metric_delta('resolution_rate', percentage=True)
            )
        
        with col5:
            auto_resolved = stats.get('auto_resolved', 0)
            st.metric(
                label="🤖 התאוששות אוטומטית",
                value=auto_resolved,
                delta=self._get_metric_delta('auto_resolved')
            )
    
    def _get_metric_delta(self, metric: str, percentage: bool = False) -> Optional[str]:
        """חישוב דלתא למטריקה"""
        # כאן אפשר לממש השוואה עם תקופה קודמת
        # לעת עתה מחזיר None
        return None
    
    def _render_failures_timeline(self):
        """רינדור ציר זמן כשלים"""
        st.subheader("📈 ציר זמן כשלים")
        
        # קבלת נתונים
        recent_failures = self.tracker.get_recent_failures(hours=24)
        
        if not recent_failures:
            st.info("אין כשלים ב-24 השעות האחרונות")
            return
        
        # עיבוד נתונים
        df_data = []
        for failure in recent_failures:
            df_data.append({
                'timestamp': failure.timestamp,
                'hour': failure.timestamp.hour,
                'severity': failure.severity.value,
                'category': failure.category.value,
                'resolved': failure.resolved
            })
        
        df = pd.DataFrame(df_data)
        
        # קיבוץ לפי שעות
        hourly_counts = df.groupby('hour').size().reset_index(name='count')
        
        # יצירת גרף
        fig = px.line(hourly_counts, x='hour', y='count',
                     title='כשלים לפי שעות',
                     labels={'hour': 'שעה', 'count': 'מספר כשלים'})
        
        fig.update_layout(
            xaxis=dict(tickmode='linear', tick0=0, dtick=2),
            height=300
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    def _render_category_distribution(self):
        """רינדור התפלגות לפי קטגוריות"""
        st.subheader("📊 התפלגות לפי קטגוריות")
        
        # קבלת נתונים
        recent_failures = self.tracker.get_recent_failures(hours=24)
        
        if not recent_failures:
            st.info("אין נתונים להצגה")
            return
        
        # עיבוד נתונים
        categories = {}
        for failure in recent_failures:
            cat = failure.category.value
            categories[cat] = categories.get(cat, 0) + 1
        
        if categories:
            # יצירת גרף עוגה
            fig = px.pie(
                values=list(categories.values()),
                names=list(categories.keys()),
                title='התפלגות כשלים לפי קטגוריה'
            )
            
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("אין נתונים להצגה")
    
    def _render_severity_distribution(self):
        """רינדור התפלגות לפי חומרה"""
        st.subheader("⚠️ התפלגות לפי חומרה")
        
        # קבלת נתונים
        recent_failures = self.tracker.get_recent_failures(hours=24)
        
        if not recent_failures:
            st.info("אין נתונים להצגה")
            return
        
        # עיבוד נתונים
        severities = {}
        for failure in recent_failures:
            sev = failure.severity.value
            severities[sev] = severities.get(sev, 0) + 1
        
        if severities:
            # מיון לפי חומרה
            severity_order = ['קריטי', 'גבוה', 'בינוני', 'נמוך', 'אזהרה']
            sorted_severities = {k: severities.get(k, 0) for k in severity_order if k in severities}
            
            # צבעים לפי חומרה
            colors = ['#FF4444', '#FF8800', '#FFAA00', '#88BB00', '#0088BB']
            
            fig = px.bar(
                x=list(sorted_severities.keys()),
                y=list(sorted_severities.values()),
                title='התפלגות כשלים לפי חומרה',
                labels={'x': 'חומרה', 'y': 'מספר כשלים'},
                color=list(sorted_severities.keys()),
                color_discrete_sequence=colors[:len(sorted_severities)]
            )
            
            fig.update_layout(height=300, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("אין נתונים להצגה")
    
    def _render_resolution_time_trend(self):
        """רינדור מגמת זמני פתרון"""
        st.subheader("⏱️ מגמת זמני פתרון")
        
        # קבלת כשלים נפתרים
        resolved_failures = self.tracker.get_failures(resolved=True, limit=100)
        
        if not resolved_failures:
            st.info("אין כשלים נפתרים להצגה")
            return
        
        # עיבוד נתונים
        df_data = []
        for failure in resolved_failures:
            if failure.resolution_duration:
                df_data.append({
                    'timestamp': failure.timestamp,
                    'resolution_minutes': failure.resolution_duration.total_seconds() / 60,
                    'severity': failure.severity.value
                })
        
        if df_data:
            df = pd.DataFrame(df_data)
            
            fig = px.scatter(
                df, x='timestamp', y='resolution_minutes',
                color='severity',
                title='זמני פתרון לאורך זמן',
                labels={'timestamp': 'זמן', 'resolution_minutes': 'זמן פתרון (דקות)'}
            )
            
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("אין נתונים להצגה")
    
    def _render_active_alerts(self):
        """רינדור התראות פעילות"""
        st.subheader("🔔 התראות פעילות")
        
        # קבלת כשלים פעילים בחומרה גבוהה
        active_failures = self.tracker.get_active_failures()
        critical_failures = [f for f in active_failures if f.severity in [
            FailureSeverity.CRITICAL, FailureSeverity.HIGH
        ]]
        
        if critical_failures:
            for failure in critical_failures[:5]:  # הצגת 5 הראשונים
                severity_class = failure.severity.value.lower()
                st.markdown(f"""
                <div class="alert-banner">
                    <strong>⚠️ {failure.severity.value}:</strong> {failure.title}<br>
                    <small>זמן: {failure.timestamp.strftime('%H:%M:%S')}</small>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("🎉 אין התראות פעילות!")
    
    def _render_failures_list(self):
        """רינדור רשימת כשלים"""
        st.header("⚠️ רשימת כשלים")
        
        # פילטרים
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            category_filter = st.selectbox(
                "קטגוריה:",
                options=['הכל'] + [cat.value for cat in FailureCategory],
                index=0
            )
        
        with col2:
            severity_filter = st.selectbox(
                "חומרה:",
                options=['הכל'] + [sev.value for sev in FailureSeverity],
                index=0
            )
        
        with col3:
            status_filter = st.selectbox(
                "סטטוס:",
                options=['הכל', 'פעיל', 'נפתר'],
                index=0
            )
        
        with col4:
            time_filter = st.selectbox(
                "תקופה:",
                options=['24 שעות', '7 ימים', '30 ימים', 'הכל'],
                index=0
            )
        
        # יישום פילטרים
        failures = self._apply_filters(category_filter, severity_filter, status_filter, time_filter)
        
        if not failures:
            st.info("לא נמצאו כשלים בהתאם לפילטרים שנבחרו")
            return
        
        # הצגת סטטיסטיקות מסוננות
        st.metric("מספר כשלים מסוננים", len(failures))
        
        # טבלת כשלים
        self._render_failures_table(failures)
        
        # פרטי כשל נבחר
        if 'selected_failure_id' in st.session_state:
            self._render_failure_details(st.session_state.selected_failure_id)
    
    def _apply_filters(self, category: str, severity: str, status: str, time_period: str) -> List[FailureEvent]:
        """יישום פילטרים על רשימת הכשלים"""
        # בחירת תקופת זמן
        if time_period == '24 שעות':
            failures = self.tracker.get_recent_failures(hours=24)
        elif time_period == '7 ימים':
            failures = self.tracker.get_recent_failures(hours=24*7)
        elif time_period == '30 ימים':
            failures = self.tracker.get_recent_failures(hours=24*30)
        else:
            failures = self.tracker.get_failures(limit=1000)
        
        # פילטר קטגוריה
        if category != 'הכל':
            failures = [f for f in failures if f.category.value == category]
        
        # פילטר חומרה
        if severity != 'הכל':
            failures = [f for f in failures if f.severity.value == severity]
        
        # פילטר סטטוס
        if status == 'פעיל':
            failures = [f for f in failures if not f.resolved]
        elif status == 'נפתר':
            failures = [f for f in failures if f.resolved]
        
        return failures
    
    def _render_failures_table(self, failures: List[FailureEvent]):
        """רינדור טבלת כשלים"""
        # הכנת נתונים לטבלה
        table_data = []
        for failure in failures:
            table_data.append({
                'ID': failure.id[:8] + '...',
                'זמן': failure.timestamp.strftime('%d/%m/%Y %H:%M'),
                'קטגוריה': failure.category.value,
                'חומרה': failure.severity.value,
                'כותרת': failure.title[:50] + '...' if len(failure.title) > 50 else failure.title,
                'סטטוס': 'נפתר' if failure.resolved else 'פעיל',
                'זמן פתרון': (
                    f"{failure.resolution_duration.total_seconds()/60:.1f} דק'"
                    if failure.resolution_duration else '-'
                ),
                'פעולות התאוששות': len(failure.attempted_actions)
            })
        
        df = pd.DataFrame(table_data)
        
        # הצגת הטבלה עם אפשרות בחירה
        selected_row = st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            selection_mode="single-row",
            on_select="rerun"
        )
        
        # טיפול בבחירת שורה
        if selected_row.selection.rows:
            selected_index = selected_row.selection.rows[0]
            selected_failure = failures[selected_index]
            st.session_state.selected_failure_id = selected_failure.id
    
    def _render_failure_details(self, failure_id: str):
        """רינדור פרטי כשל"""
        failure = self.tracker.get_failure(failure_id)
        if not failure:
            st.error("לא נמצא כשל עם ID זה")
            return
        
        st.subheader(f"🔍 פרטי כשל: {failure.id[:8]}...")
        
        # מידע בסיסי
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("חומרה", failure.severity.value)
            st.metric("קטגוריה", failure.category.value)
        
        with col2:
            st.metric("זמן התרחשות", failure.timestamp.strftime('%H:%M:%S'))
            status = "נפתר" if failure.resolved else "פעיל"
            st.metric("סטטוס", status)
        
        with col3:
            if failure.resolution_duration:
                resolution_time = f"{failure.resolution_duration.total_seconds()/60:.1f} דק'"
            else:
                resolution_time = "-"
            st.metric("זמן פתרון", resolution_time)
            
            st.metric("פעולות התאוששות", len(failure.attempted_actions))
        
        # תיאור הכשל
        st.subheader("📝 תיאור")
        st.text_area("כותרת:", value=failure.title, disabled=True)
        st.text_area("תיאור:", value=failure.description, disabled=True, height=100)
        st.text_area("הודעת שגיאה:", value=failure.error_message, disabled=True, height=80)
        
        # Stack trace
        if failure.stack_trace:
            with st.expander("📋 Stack Trace"):
                st.code(failure.stack_trace, language='python')
        
        # הקשר
        if failure.context:
            with st.expander("🔗 הקשר הכשל"):
                context_data = failure.context.to_dict()
                st.json(context_data)
        
        # מצב מערכת
        if failure.system_state:
            with st.expander("💻 מצב מערכת"):
                self._render_system_state(failure.system_state)
        
        # פעולות התאוששות
        if failure.attempted_actions:
            with st.expander("🔧 פעולות התאוששות"):
                for i, action in enumerate(failure.attempted_actions):
                    self._render_recovery_action(action, i + 1)
        
        # כפתורי פעולה
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if not failure.resolved:
                if st.button("✅ סמן כנפתר"):
                    self.tracker.resolve_failure(failure_id)
                    st.success("הכשל סומן כנפתר")
                    st.rerun()
        
        with col2:
            if st.button("🔄 נסה התאוששות"):
                success = self.tracker.recovery_manager.attempt_recovery(failure)
                if success:
                    st.success("התאוששות הצליחה!")
                else:
                    st.error("התאוששות נכשלה")
                st.rerun()
        
        with col3:
            if st.button("📤 ייצא כשל"):
                self._export_single_failure(failure)
    
    def _render_system_state(self, system_state: SystemState):
        """רינדור מצב מערכת"""
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("שימוש CPU", f"{system_state.cpu_usage:.1f}%")
            st.metric("שימוש זיכרון", f"{system_state.memory_usage:.1f}%")
        
        with col2:
            st.metric("שימוש דיסק", f"{system_state.disk_usage:.1f}%")
            st.metric("תהליכים פעילים", system_state.active_processes)
        
        with col3:
            st.metric("זמן תגובה API", f"{system_state.api_response_time:.1f}ms")
            st.metric("שיעור שגיאות", f"{system_state.error_rate:.2f}/דקה")
    
    def _render_recovery_action(self, action: RecoveryAction, index: int):
        """רינדור פעולת התאוששות"""
        status_icon = "✅" if action.success else ("❌" if action.success is False else "⏳")
        
        st.markdown(f"""
        **{index}. {status_icon} {action.name}**
        - תיאור: {action.description}
        - זמן ביצוע: {action.execution_time.strftime('%H:%M:%S') if action.execution_time else 'לא בוצע'}
        - תוצאה: {action.result or action.error_message or 'בתהליך'}
        """)
        
        if action.effectiveness_score is not None:
            st.progress(action.effectiveness_score, text=f"יעילות: {action.effectiveness_score:.2f}")
    
    def _export_single_failure(self, failure: FailureEvent):
        """ייצוא כשל בודד"""
        failure_json = failure.to_json()
        st.download_button(
            label="💾 הורד כ-JSON",
            data=failure_json,
            file_name=f"failure_{failure.id[:8]}.json",
            mime="application/json"
        )
    
    def _render_patterns_analysis(self):
        """רינדור ניתוח דפוסים"""
        st.header("🔍 ניתוח דפוסי כשלים")
        
        patterns = self.tracker.pattern_analyzer.patterns
        
        if not patterns:
            st.info("לא נמצאו דפוסי כשלים")
            return
        
        # סטטיסטיקות דפוסים
        st.subheader("📊 סטטיסטיקות דפוסים")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("מספר דפוסים", len(patterns))
        with col2:
            total_frequency = sum(p.frequency for p in patterns.values())
            st.metric("סה\"כ התרחשויות", total_frequency)
        with col3:
            avg_frequency = total_frequency / len(patterns) if patterns else 0
            st.metric("תדירות ממוצעת", f"{avg_frequency:.1f}")
        
        # רשימת דפוסים
        st.subheader("📋 רשימת דפוסים")
        
        pattern_data = []
        for pattern in patterns.values():
            pattern_data.append({
                'שם': pattern.name,
                'קטגוריה': pattern.category.value,
                'תדירות': pattern.frequency,
                'התרחשות ראשונה': pattern.first_occurrence.strftime('%d/%m/%Y') if pattern.first_occurrence else '-',
                'התרחשות אחרונה': pattern.last_occurrence.strftime('%d/%m/%Y') if pattern.last_occurrence else '-',
                'פעולות מושפעות': len(pattern.affected_operations),
                'המלצות': len(pattern.recommended_actions)
            })
        
        if pattern_data:
            df = pd.DataFrame(pattern_data)
            selected_pattern = st.dataframe(
                df,
                use_container_width=True,
                hide_index=True,
                selection_mode="single-row",
                on_select="rerun"
            )
            
            # פרטי דפוס נבחר
            if selected_pattern.selection.rows:
                selected_index = selected_pattern.selection.rows[0]
                pattern_list = list(patterns.values())
                selected_pattern_obj = pattern_list[selected_index]
                self._render_pattern_details(selected_pattern_obj)
    
    def _render_pattern_details(self, pattern: FailurePattern):
        """רינדור פרטי דפוס"""
        st.subheader(f"🔍 פרטי דפוס: {pattern.name}")
        
        # מידע בסיסי
        col1, col2 = st.columns(2)
        
        with col1:
            st.text_input("שם הדפוס:", value=pattern.name, disabled=True)
            st.text_input("קטגוריה:", value=pattern.category.value, disabled=True)
            st.number_input("תדירות:", value=pattern.frequency, disabled=True)
        
        with col2:
            if pattern.first_occurrence:
                st.date_input("התרחשות ראשונה:", value=pattern.first_occurrence.date(), disabled=True)
            if pattern.last_occurrence:
                st.date_input("התרחשות אחרונה:", value=pattern.last_occurrence.date(), disabled=True)
            st.number_input("שיעור הצלחה:", value=pattern.success_rate, disabled=True)
        
        # תיאור
        st.text_area("תיאור:", value=pattern.description, disabled=True, height=100)
        
        # תנאים
        if pattern.conditions:
            st.subheader("📋 תנאי הדפוס")
            for i, condition in enumerate(pattern.conditions, 1):
                st.text(f"{i}. {condition}")
        
        # פעולות מושפעות
        if pattern.affected_operations:
            st.subheader("⚙️ פעולות מושפעות")
            for operation in pattern.affected_operations:
                st.text(f"• {operation}")
        
        # המלצות
        if pattern.recommended_actions:
            st.subheader("💡 פעולות מומלצות")
            for action in pattern.recommended_actions:
                st.text(f"• {action}")
        
        # אסטרטגיות מניעה
        if pattern.prevention_strategies:
            st.subheader("🛡️ אסטרטגיות מניעה")
            for strategy in pattern.prevention_strategies:
                st.text(f"• {strategy}")
    
    def _render_recovery_panel(self):
        """רינדור פאנל התאוששות"""
        st.header("🔧 פאנל התאוששות")
        
        # כשלים הדורשים התאוששות
        active_failures = self.tracker.get_active_failures()
        critical_failures = [f for f in active_failures if f.severity in [
            FailureSeverity.CRITICAL, FailureSeverity.HIGH
        ]]
        
        if not critical_failures:
            st.success("🎉 אין כשלים הדורשים התאוששות מיידית!")
            return
        
        st.warning(f"⚠️ נמצאו {len(critical_failures)} כשלים הדורשים התאוששות")
        
        # רשימת כשלים לטיפול
        for failure in critical_failures:
            with st.expander(f"{failure.severity.value}: {failure.title}"):
                self._render_recovery_options(failure)
    
    def _render_recovery_options(self, failure: FailureEvent):
        """רינדור אפשרויות התאוששות"""
        col1, col2 = st.columns(2)
        
        with col1:
            st.text(f"זמן כשל: {failure.timestamp.strftime('%d/%m/%Y %H:%M')}")
            st.text(f"קטגוריה: {failure.category.value}")
            st.text(f"ניסיונות קודמים: {len(failure.attempted_actions)}")
        
        with col2:
            # אפשרויות התאוששות אוטומטית
            if st.button(f"🤖 התאוששות אוטומטית", key=f"auto_{failure.id}"):
                success = self.tracker.recovery_manager.attempt_recovery(failure)
                if success:
                    st.success("התאוששות אוטומטית הצליחה!")
                else:
                    st.error("התאוששות אוטומטית נכשלה")
                st.rerun()
            
            # אפשרויות התאוששות ידנית
            if st.button(f"👤 סמן כנפתר ידנית", key=f"manual_{failure.id}"):
                self.tracker.resolve_failure(failure.id)
                st.success("הכשל סומן כנפתר")
                st.rerun()
        
        # הצגת אסטרטגיות זמינות
        strategies = self.tracker.recovery_manager._get_recovery_strategies(failure)
        if strategies:
            st.subheader("🎯 אסטרטגיות זמינות:")
            for strategy in strategies:
                st.text(f"• {strategy.name}: {strategy.description}")
    
    def _render_alerts_panel(self):
        """רינדור פאנל התראות"""
        st.header("🔔 פאנל התראות")
        
        # הגדרות התראות
        st.subheader("⚙️ הגדרות התראות")
        
        col1, col2 = st.columns(2)
        
        with col1:
            cpu_threshold = st.slider("סף CPU (%)", 0, 100, 
                                     value=int(self.tracker.monitor.thresholds['cpu_usage']))
            memory_threshold = st.slider("סף זיכרון (%)", 0, 100,
                                       value=int(self.tracker.monitor.thresholds['memory_usage']))
        
        with col2:
            disk_threshold = st.slider("סף דיסק (%)", 0, 100,
                                     value=int(self.tracker.monitor.thresholds['disk_usage']))
            error_rate_threshold = st.slider("סף שיעור שגיאות", 0.0, 20.0,
                                            value=self.tracker.monitor.thresholds['error_rate'])
        
        # עדכון ספים
        if st.button("💾 שמור הגדרות"):
            self.tracker.monitor.thresholds.update({
                'cpu_usage': cpu_threshold,
                'memory_usage': memory_threshold,
                'disk_usage': disk_threshold,
                'error_rate': error_rate_threshold
            })
            st.success("הגדרות נשמרו בהצלחה!")
        
        # מצב מעקב זמן אמת
        st.subheader("⏱️ מצב מעקב זמן אמת")
        
        monitoring_status = self.tracker.monitor.monitoring
        status_text = "פעיל" if monitoring_status else "לא פעיל"
        status_color = "normal" if monitoring_status else "off"
        
        st.metric("מצב מעקב", status_text)
        
        col1, col2 = st.columns(2)
        
        with col1:
            if not monitoring_status:
                if st.button("▶️ התחל מעקב"):
                    self.tracker.start_monitoring()
                    st.success("מעקב זמן אמת התחיל!")
                    st.rerun()
        
        with col2:
            if monitoring_status:
                if st.button("⏹️ עצור מעקב"):
                    self.tracker.stop_monitoring()
                    st.success("מעקב זמן אמת הופסק!")
                    st.rerun()
        
        # היסטוריית התראות
        st.subheader("📜 היסטוריית התראות")
        
        # כאן אפשר להוסיף לוג של התראות שנשלחו
        recent_alerts = self._get_recent_alerts()
        if recent_alerts:
            for alert in recent_alerts:
                st.info(f"🔔 {alert['time']}: {alert['message']}")
        else:
            st.success("אין התראות אחרונות")
    
    def _get_recent_alerts(self) -> List[Dict[str, str]]:
        """קבלת התראות אחרונות"""
        # כאן אפשר לממש שליפה של התראות מהמערכת
        # לעת עתה מחזיר רשימה ריקה
        return []
    
    def _render_settings(self):
        """רינדור הגדרות"""
        st.header("⚙️ הגדרות מערכת")
        
        # הגדרות כלליות
        st.subheader("🔧 הגדרות כלליות")
        
        col1, col2 = st.columns(2)
        
        with col1:
            auto_analysis = st.checkbox("ניתוח דפוסים אוטומטי", 
                                      value=self.tracker.auto_analysis)
            auto_recovery = st.checkbox("התאוששות אוטומטית",
                                      value=self.tracker.auto_recovery)
        
        with col2:
            cache_size = st.number_input("גודל cache", value=self.tracker.cache_size,
                                       min_value=100, max_value=10000)
            refresh_interval = st.number_input("מרווח רענון (שניות)", 
                                             value=self.auto_refresh_interval,
                                             min_value=5, max_value=300)
        
        # הגדרות מסד נתונים
        st.subheader("💾 הגדרות מסד נתונים")
        
        db_path = st.text_input("נתיב מסד נתונים", 
                               value=self.tracker.db_manager.db_path)
        
        # פעולות מסד נתונים
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🧹 נקה כשלים ישנים"):
                if self._cleanup_old_failures():
                    st.success("כשלים ישנים נוקו בהצלחה!")
        
        with col2:
            if st.button("📊 אופטימיזציה של מסד נתונים"):
                if self._optimize_database():
                    st.success("מסד הנתונים אופטימל!")
        
        with col3:
            if st.button("🔄 גיבוי מסד נתונים"):
                if self._backup_database():
                    st.success("גיבוי נוצר בהצלחה!")
        
        # ייצוא ויבוא
        st.subheader("📤 ייצוא ויבוא")
        
        col1, col2 = st.columns(2)
        
        with col1:
            export_format = st.selectbox("פורמט ייצוא:", ['JSON', 'CSV'])
            if st.button("📤 ייצא כל הכשלים"):
                self._export_all_failures(export_format.lower())
        
        with col2:
            uploaded_file = st.file_uploader("📥 יבא כשלים", 
                                           type=['json', 'csv'])
            if uploaded_file and st.button("📥 יבא"):
                self._import_failures(uploaded_file)
        
        # שמירת הגדרות
        if st.button("💾 שמור כל הההגדרות"):
            self.tracker.auto_analysis = auto_analysis
            self.tracker.auto_recovery = auto_recovery
            self.tracker.cache_size = cache_size
            self.auto_refresh_interval = refresh_interval
            st.success("הגדרות נשמרו בהצלחה!")
    
    def _cleanup_old_failures(self) -> bool:
        """ניקוי כשלים ישנים"""
        try:
            # מחיקת כשלים מלפני 90 יום
            cutoff_date = datetime.now() - timedelta(days=90)
            # כאן יבוא הקוד למחיקה מבסיס הנתונים
            return True
        except Exception as e:
            st.error(f"שגיאה בניקוי: {e}")
            return False
    
    def _optimize_database(self) -> bool:
        """אופטימיזציה של מסד הנתונים"""
        try:
            # כאן יבוא הקוד לאופטימיזציה
            return True
        except Exception as e:
            st.error(f"שגיאה באופטימיזציה: {e}")
            return False
    
    def _backup_database(self) -> bool:
        """גיבוי מסד הנתונים"""
        try:
            # כאן יבוא הקוד לגיבוי
            return True
        except Exception as e:
            st.error(f"שגיאה בגיבוי: {e}")
            return False
    
    def _export_all_failures(self, format: str):
        """ייצוא כל הכשלים"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"failures_export_{timestamp}.{format}"
            
            success = self.tracker.export_failures(filename, format)
            if success:
                st.success(f"ייצוא הושלם: {filename}")
                
                # הורדה
                with open(filename, 'rb') as f:
                    st.download_button(
                        label="💾 הורד קובץ",
                        data=f.read(),
                        file_name=filename,
                        mime=f"application/{format}"
                    )
            else:
                st.error("ייצוא נכשל")
        except Exception as e:
            st.error(f"שגיאה בייצוא: {e}")
    
    def _import_failures(self, uploaded_file):
        """יבוא כשלים מקובץ"""
        try:
            # כאן יבוא הקוד ליבוא כשלים
            st.success("יבוא הושלם בהצלחה!")
        except Exception as e:
            st.error(f"שגיאה ביבוא: {e}")


# קלאסים נוספים לממשק
class FailureViewer:
    """מציג כשלים פרטני"""
    
    def __init__(self, tracker: FailureTracker):
        self.tracker = tracker
    
    def render_failure_card(self, failure: FailureEvent) -> None:
        """רינדור כרטיס כשל"""
        severity_class = failure.severity.value.lower()
        status_icon = "✅" if failure.resolved else "🔴"
        
        st.markdown(f"""
        <div class="failure-card {severity_class}">
            <h4>{status_icon} {failure.title}</h4>
            <p><strong>זמן:</strong> {failure.timestamp.strftime('%d/%m/%Y %H:%M')}</p>
            <p><strong>קטגוריה:</strong> {failure.category.value}</p>
            <p><strong>חומרה:</strong> {failure.severity.value}</p>
            <p><strong>תיאור:</strong> {failure.description[:100]}...</p>
        </div>
        """, unsafe_allow_html=True)


class PatternAnalysisPanel:
    """פאנל ניתוח דפוסים"""
    
    def __init__(self, tracker: FailureTracker):
        self.tracker = tracker
    
    def render_pattern_insights(self) -> None:
        """רינדור תובנות דפוסים"""
        patterns = self.tracker.pattern_analyzer.patterns
        
        if not patterns:
            st.info("אין מספיק נתונים לניתוח דפוסים")
            return
        
        # ניתוח מגמות
        st.subheader("📈 מגמות דפוסים")
        
        # דפוס השכיח ביותר
        most_frequent = max(patterns.values(), key=lambda p: p.frequency)
        st.metric("הדפוס השכיח ביותר", most_frequent.name, most_frequent.frequency)
        
        # דפוס הבעייתי ביותר
        most_problematic = min(patterns.values(), key=lambda p: p.success_rate)
        st.metric("הדפוס הבעייתי ביותר", most_problematic.name, 
                 f"{most_problematic.success_rate:.1%}")


class RecoveryPanel:
    """פאנל התאוששות"""
    
    def __init__(self, tracker: FailureTracker):
        self.tracker = tracker
    
    def render_recovery_dashboard(self) -> None:
        """רינדור דשבורד התאוששות"""
        st.subheader("🔧 דשבורד התאוששות")
        
        # סטטיסטיקות התאוששות
        stats = self._get_recovery_stats()
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("שיעור התאוששות אוטומטית", f"{stats['auto_recovery_rate']:.1%}")
        
        with col2:
            st.metric("זמן התאוששות ממוצע", f"{stats['avg_recovery_time']:.1f} דק'")
        
        with col3:
            st.metric("יעילות פעולות", f"{stats['action_effectiveness']:.1%}")
    
    def _get_recovery_stats(self) -> Dict[str, float]:
        """קבלת סטטיסטיקות התאוששות"""
        # כאן יבוא הקוד לחישוב סטטיסטיקות
        return {
            'auto_recovery_rate': 0.75,
            'avg_recovery_time': 15.2,
            'action_effectiveness': 0.85
        }


class AlertsPanel:
    """פאנל התראות"""
    
    def __init__(self, tracker: FailureTracker):
        self.tracker = tracker
    
    def render_alerts_summary(self) -> None:
        """רינדור סיכום התראות"""
        st.subheader("🔔 סיכום התראות")
        
        # התראות פעילות
        active_alerts = self._get_active_alerts()
        
        if active_alerts:
            for alert in active_alerts:
                self._render_alert(alert)
        else:
            st.success("🎉 אין התראות פעילות!")
    
    def _get_active_alerts(self) -> List[Dict[str, Any]]:
        """קבלת התראות פעילות"""
        # כאן יבוא הקוד לשליפת התראות
        return []
    
    def _render_alert(self, alert: Dict[str, Any]) -> None:
        """רינדור התראה"""
        st.warning(f"⚠️ {alert.get('message', 'התראה לא מזוהה')}")


# פונקציות עזר
def create_dashboard_app(tracker: FailureTracker) -> None:
    """יצירת אפליקציית דשבורד"""
    dashboard = FailureDashboard(tracker)
    dashboard.render()


def main():
    """פונקציה ראשית להפעלת הדשבורד"""
    # יצירת tracker
    tracker = FailureTracker()
    
    # הפעלת הדשבורד
    create_dashboard_app(tracker)