#!/bin/bash

# 🔍 FailTracker - סקריפט התקנה מודול מעקב כשלים
# Failure Tracker Module Installation Script

set -e  # יציאה במקרה של שגיאה

# צבעים להדפסה
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# פונקציות עזר
print_header() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║               🔍 FailTracker - מעקב כשלים                    ║"
    echo "║              Failure Tracker Module Installer               ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${YELLOW}▶ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# בדיקת דרישות מערכת
check_requirements() {
    print_step "בדיקת דרישות מערכת..."
    
    # בדיקת Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 לא מותקן. אנא התקן Python 3.7 ומעלה"
        exit 1
    fi
    
    # בדיקת גרסת Python
    python_version=$(python3 -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")
    required_version="3.7"
    
    if ! python3 -c "import sys; exit(0 if sys.version_info >= (3,7) else 1)"; then
        print_error "נדרש Python $required_version ומעלה. גרסה נוכחית: $python_version"
        exit 1
    fi
    
    print_success "Python $python_version נמצא"
    
    # בדיקת pip
    if ! command -v pip3 &> /dev/null; then
        print_error "pip3 לא מותקן. אנא התקן pip3"
        exit 1
    fi
    
    print_success "pip3 נמצא"
    
    # בדיקת זיכרון
    if command -v free &> /dev/null; then
        memory_mb=$(free -m | awk 'NR==2{printf "%.0f", $2/1}')
        if [ "$memory_mb" -lt 1024 ]; then
            print_error "נדרש לפחות 1GB זיכרון RAM. זמין: ${memory_mb}MB"
            exit 1
        fi
        print_success "זיכרון מספיק זמין: ${memory_mb}MB"
    fi
    
    # בדיקת מקום דיסק
    disk_space=$(df . | awk 'NR==2 {print $4}')
    if [ "$disk_space" -lt 1048576 ]; then  # 1GB ב-KB
        print_error "נדרש לפחות 1GB מקום דיסק פנוי"
        exit 1
    fi
    
    print_success "מקום דיסק מספיק זמין"
}

# יצירת סביבת ווירטואלית
create_virtual_environment() {
    print_step "יצירת סביבת ווירטואלית..."
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "סביבת ווירטואלית נוצרה"
    else
        print_info "סביבת ווירטואלית קיימת"
    fi
    
    # הפעלת הסביבה הווירטואלית
    source venv/bin/activate
    print_success "סביבת ווירטואלית הופעלה"
}

# התקנת תלויות
install_dependencies() {
    print_step "התקנת תלויות Python..."
    
    # שדרוג pip
    pip install --upgrade pip
    
    # התקנת תלויות בסיסיות
    print_info "מתקין תלויות בסיסיות..."
    pip install -r requirements.txt
    
    print_success "תלויות בסיסיות הותקנו"
    
    # התקנת תלויות אופציונליות
    print_step "התקנת תלויות אופציונליות..."
    
    optional_packages=(
        "streamlit-autorefresh"
        "extra-streamlit-components"
        "colorlog"
        "python-dotenv"
        "bidi"
        "rich"
        "tqdm"
    )
    
    for package in "${optional_packages[@]}"; do
        if pip install "$package" &> /dev/null; then
            print_success "הותקן: $package"
        else
            print_error "נכשל: $package (אופציונלי)"
        fi
    done
}

# יצירת תיקיות נדרשות
create_directories() {
    print_step "יצירת תיקיות מערכת..."
    
    directories=(
        "data"
        "logs" 
        "exports"
        "backups"
        "temp"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_success "תיקייה נוצרה: $dir"
        else
            print_info "תיקייה קיימת: $dir"
        fi
    done
}

# הגדרת הרשאות
setup_permissions() {
    print_step "הגדרת הרשאות קבצים..."
    
    # הרשאות ביצוע לסקריפטים
    chmod +x install.sh
    chmod +x module.py
    
    # הרשאות קריאה/כתיבה לתיקיות נתונים
    chmod -R 755 data logs exports backups temp 2>/dev/null || true
    
    print_success "הרשאות הוגדרו"
}

# יצירת קובץ תצורה
create_config() {
    print_step "יצירת קובץ תצורה..."
    
    config_file="config.json"
    
    if [ ! -f "$config_file" ]; then
        cat > "$config_file" << 'EOF'
{
    "database_path": "./data/failure_tracker.db",
    "monitoring_interval": 30,
    "auto_analysis": true,
    "auto_recovery": true,
    "cache_size": 1000,
    "email_alerts": false,
    "log_level": "INFO",
    "log_file": "./logs/failure_tracker.log",
    "export_path": "./exports",
    "alert_cooldown": 60,
    "pattern_similarity_threshold": 0.7,
    "max_recovery_attempts": 3,
    "hebrew_interface": true,
    "email_config": {
        "smtp_server": "",
        "smtp_port": 587,
        "username": "",
        "password": ""
    }
}
EOF
        print_success "קובץ תצורה נוצר: $config_file"
    else
        print_info "קובץ תצורה קיים: $config_file"
    fi
}

# יצירת סקריפט הפעלה
create_run_script() {
    print_step "יצירת סקריפט הפעלה..."
    
    cat > "run_failure_tracker.sh" << 'EOF'
#!/bin/bash
# סקריפט הפעלה למודול מעקב כשלים

# הפעלת סביבת ווירטואלית
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# הפעלת המודול
python3 module.py "$@"
EOF
    
    chmod +x run_failure_tracker.sh
    print_success "סקריפט הפעלה נוצר: run_failure_tracker.sh"
}

# בדיקת התקנה
test_installation() {
    print_step "בדיקת התקנה..."
    
    # בדיקה בסיסית
    if python3 -c "from module import FailureTrackerModule; print('✓ Import successful')" 2>/dev/null; then
        print_success "יבוא המודול הצליח"
    else
        print_error "יבוא המודול נכשל"
        return 1
    fi
    
    # בדיקת יצירת מודול
    if python3 -c "
from module import create_failure_tracker_module
module = create_failure_tracker_module()
health = module.health_check()
print(f'✓ Module health: {health[\"overall_status\"]}')
" 2>/dev/null; then
        print_success "בדיקת תקינות המודול הצליחה"
    else
        print_error "בדיקת תקינות המודול נכשלה"
        return 1
    fi
    
    # בדיקת בסיס נתונים
    if [ -f "data/failure_tracker.db" ]; then
        print_success "מסד נתונים נוצר בהצלחה"
    fi
    
    return 0
}

# הדפסת הוראות שימוש
print_usage_instructions() {
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                    🎉 התקנה הושלמה בהצלחה!                  ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "${BLUE}📚 הוראות שימוש:${NC}"
    echo ""
    echo -e "${YELLOW}1. הפעלת דמו:${NC}"
    echo "   ./run_failure_tracker.sh --demo"
    echo ""
    echo -e "${YELLOW}2. הפעלת דשבורד:${NC}"
    echo "   ./run_failure_tracker.sh --dashboard"
    echo "   לאחר מכן פתח דפדפן בכתובת: http://localhost:8501"
    echo ""
    echo -e "${YELLOW}3. הפעלה עם תצורה מותאמת:${NC}"
    echo "   ./run_failure_tracker.sh --config config.json"
    echo ""
    echo -e "${YELLOW}4. שימוש בקוד Python:${NC}"
    echo "   python3 -c \"from module import create_failure_tracker_module; module = create_failure_tracker_module(); module.start()\""
    echo ""
    echo -e "${BLUE}📁 קבצים חשובים:${NC}"
    echo "   • config.json - קובץ תצורה"
    echo "   • data/ - תיקיית מסד נתונים"
    echo "   • logs/ - תיקיית לוגים"
    echo "   • exports/ - תיקיית ייצוא דוחות"
    echo ""
    echo -e "${BLUE}📖 תיעוד נוסף:${NC}"
    echo "   README.md - מדריך מפורט בעברית"
    echo ""
}

# פונקציה לניקוי במקרה של שגיאה
cleanup_on_error() {
    print_error "התקנה נכשלה. מנקה קבצים זמניים..."
    
    # ניקוי סביבת ווירטואלית אם נוצרה
    if [ -d "venv" ] && [ ! -f "venv/.keep" ]; then
        rm -rf venv
    fi
    
    exit 1
}

# הגדרת trap לניקוי
trap cleanup_on_error ERR

# פונקציה ראשית
main() {
    print_header
    
    # בדיקה שהסקריפט רץ מהתיקייה הנכונה
    if [ ! -f "module.py" ] || [ ! -f "requirements.txt" ]; then
        print_error "אנא הרץ את הסקריפט מתיקיית המודול"
        exit 1
    fi
    
    print_info "מתחיל התקנה במיקום: $(pwd)"
    echo ""
    
    # שלבי ההתקנה
    check_requirements
    echo ""
    
    create_virtual_environment
    echo ""
    
    install_dependencies
    echo ""
    
    create_directories
    echo ""
    
    setup_permissions
    echo ""
    
    create_config
    echo ""
    
    create_run_script
    echo ""
    
    # בדיקת התקנה
    if test_installation; then
        echo ""
        print_usage_instructions
    else
        print_error "בדיקת התקנה נכשלה"
        exit 1
    fi
}

# בדיקת פרמטרים
case "${1:-}" in
    --help|-h)
        echo "סקריפט התקנה למודול מעקב כשלים"
        echo ""
        echo "שימוש: $0 [אפשרויות]"
        echo ""
        echo "אפשרויות:"
        echo "  --help, -h     הצגת עזרה זו"
        echo "  --clean        ניקוי קבצים לפני התקנה"
        echo "  --no-venv      התקנה ללא סביבת ווירטואלית"
        echo ""
        exit 0
        ;;
    --clean)
        print_step "מנקה קבצים קודמים..."
        rm -rf venv data logs exports backups temp config.json run_failure_tracker.sh
        print_success "ניקוי הושלם"
        echo ""
        ;;
    --no-venv)
        # הגדרת דגל לדילוג על סביבת ווירטואלית
        NO_VENV=true
        ;;
esac

# הרצת ההתקנה
main

print_success "ההתקנה הושלמה בהצלחה! 🎉"