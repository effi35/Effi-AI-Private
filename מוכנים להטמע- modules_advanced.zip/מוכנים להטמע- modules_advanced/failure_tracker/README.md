# 🔍 FailTracker - מערכת מעקב כשלים מתקדמת

מודול מקיף למעקב, ניתוח וטיפול בכשלים במערכת בזמן אמת עם תמיכה מלאה בעברית.

## ✨ תכונות עיקריות

### 📊 מעקב כשלים מתקדם
- **מעקב זמן אמת** - זיהוי וטיפול בכשלים בזמן אמת
- **קטגוריזציה חכמה** - סיווג אוטומטי של כשלים לפי סוג ומקור
- **רמות חומרה** - דירוג כשלים לפי רמת הקריטיות
- **הקשר מפורט** - איסוף מידע מקיף על הסביבה והתנאים

### 🔍 ניתוח דפוסים
- **זיהוי דפוסים אוטומטי** - גילוי דפוסי כשלים חוזרים
- **ניתוח מגמות** - זיהוי מגמות ושינויים בכשלים
- **קורלציות** - מציאת קשרים בין כשלים שונים
- **חיזוי סיכונים** - אזהרה מוקדמת על כשלים אפשריים

### 🤖 התאוששות אוטומטית
- **פעולות התאוששות חכמות** - ניסיון פתרון אוטומטי
- **למידה מהצלחות** - שיפור אסטרטגיות ההתאוששות
- **מעקב יעילות** - מדידת הצלחת פעולות ההתאוששות
- **rollback בטוח** - אפשרות לביטול פעולות התאוששות

### 📢 התראות חכמות
- **כללי התראה מותאמים** - הגדרת תנאי התראה גמישים
- **cooldown מניעתי** - מניעת הצפת התראות
- **ערוצי התראה מרובים** - אימייל, SMS, Slack ועוד
- **עדיפויות דינמיות** - התראות לפי חומרה ודחיפות

### 📊 דשבורד אינטראקטיבי
- **ממשק עברית מלא** - תמיכה מלאה בעברית ו-RTL
- **ויזואליזציות מתקדמות** - גרפים ותרשימים אינטראקטיביים
- **סינון וחיפוש** - כלים מתקדמים לניתוח נתונים
- **ייצוא דוחות** - יצירת דוחות מפורטים

## 🏗️ ארכיטקטורה

```
failure_tracker/
├── models/          # מודלי נתונים
│   └── failure_types.py
├── core/           # מנוע מעקב ראשי  
│   └── failure_tracker.py
├── ui/             # ממשק משתמש
│   └── failure_dashboard.py
├── utils/          # כלי עזר וניתוח
│   └── failure_utils.py
├── tests/          # בדיקות יחידה
├── module.py       # מודול ראשי
└── requirements.txt
```

## 🚀 התקנה מהירה

```bash
# התקנת התלויות
pip install -r requirements.txt

# הפעלת המודול
python module.py --demo

# הפעלת הדשבורד
python module.py --dashboard --port 8501
```

## 📝 שימוש בסיסי

### יצירת מודול

```python
from failure_tracker.module import create_failure_tracker_module

# יצירת מודול
module = create_failure_tracker_module()
module.start()
```

### מעקב אחר כשלים

```python
from failure_tracker.models.failure_types import *

# מעקב אחר חריגה
try:
    risky_operation()
except Exception as e:
    context = FailureContext(
        operation_name="risky_operation",
        module_name="my_module",
        function_name="process_data",
        parameters={"input": "data"},
        environment="production"
    )
    
    failure_id = module.track_exception(
        e, context, 
        FailureSeverity.HIGH,
        FailureCategory.CODE_EXECUTION
    )
```

### יצירת כשל מותאם

```python
failure = FailureEvent(
    title="שגיאה בחיבור למסד נתונים",
    description="החיבור למסד הנתונים נכשל לאחר 3 ניסיונות",
    category=FailureCategory.DATABASE,
    severity=FailureSeverity.CRITICAL,
    error_message="Connection timeout after 30 seconds"
)

failure_id = module.track_failure(failure)
```

## 🔧 תצורה מתקדמת

### קובץ תצורה JSON

```json
{
    "database_path": "./data/failures.db",
    "monitoring_interval": 30,
    "auto_analysis": true,
    "auto_recovery": true,
    "cache_size": 1000,
    "email_alerts": true,
    "email_config": {
        "smtp_server": "smtp.gmail.com",
        "smtp_port": 587,
        "username": "alerts@company.com",
        "password": "app_password"
    },
    "alert_cooldown": 60,
    "pattern_similarity_threshold": 0.7,
    "max_recovery_attempts": 3,
    "hebrew_interface": true
}
```

### הגדרת התראות מותאמות

```python
from failure_tracker.utils.failure_utils import AlertRule, AlertManager

# יצירת כלל התראה
rule = AlertRule(
    id="api_failures",
    name="כשלי API חוזרים",
    description="התראה על כשלי API חוזרים",
    condition="category == FailureCategory.API_CALL and not resolved",
    severity=FailureSeverity.HIGH,
    recipients=["admin@company.com"],
    cooldown_minutes=30
)

# הוספת הכלל למנהל התראות
module.alert_manager.add_alert_rule(rule)
```

## 📊 דוחות וניתוחים

### דוח יומי

```python
# יצירת דוח יומי
daily_report = module.generate_daily_report()
print(daily_report)

# ייצוא לקובץ
module.export_failures("daily_failures.json", "json")
```

### ניתוח מתקדם

```python
# הרצת ניתוח מקיף
analysis = module.run_analysis('comprehensive')

# ניתוח מגמות
trends = analysis['trends']
print(f"סיכום מגמות: {trends.summary}")
print(f"המלצות: {trends.recommendations}")

# ניתוח דפוסים
patterns = analysis.get('patterns', [])
for pattern in patterns:
    print(f"דפוס: {pattern.summary}")
```

## 🔍 סוגי כשלים נתמכים

### קטגוריות כשלים
- **CODE_EXECUTION** - כשלי ביצוע קוד
- **API_CALL** - כשלי קריאות API  
- **SYSTEM_OPERATION** - כשלי פעולות מערכת
- **PERFORMANCE** - בעיות ביצועים
- **RESOURCE_EXHAUSTION** - תשישות משאבים
- **COMMUNICATION** - כשלי תקשורת
- **DATA_PROCESSING** - שגיאות עיבוד נתונים
- **AUTHENTICATION** - בעיות אימות
- **CONFIGURATION** - שגיאות תצורה
- **NETWORK** - בעיות רשת
- **DATABASE** - כשלי מסד נתונים
- **FILE_SYSTEM** - בעיות מערכת קבצים
- **MEMORY** - בעיות זיכרון
- **TIMEOUT** - פסקי זמן

### רמות חומרה
- **CRITICAL** - קריטי (השפעה חמורה על המערכת)
- **HIGH** - גבוה (השפעה משמעותית)
- **MEDIUM** - בינוני (השפעה מוגבלת)
- **LOW** - נמוך (השפעה מינימלית)
- **WARNING** - אזהרה (אינדיקציה לבעיה אפשרית)

## 🤖 התאוששות אוטומטית

### פעולות התאוששות מובנות

```python
# הוספת פעולת התאוששות מותאמת
recovery_action = RecoveryAction(
    name="איפוס שירות",
    description="איפוס השירות הבעייתי",
    action_type="service_restart",
    parameters={"service_name": "my_service", "timeout": 30}
)

module.tracker.recovery_manager.add_recovery_strategy(
    FailureCategory.SYSTEM_OPERATION, 
    recovery_action
)
```

### מעקב יעילות התאוששות

```python
# קבלת סטטיסטיקות התאוששות
stats = module.get_failure_statistics()
auto_recovery_rate = stats.get('auto_resolution_rate', 0)
print(f"שיעור התאוששות אוטומטית: {auto_recovery_rate:.1%}")
```

## 📱 דשבורד אינטראקטיבי

### הפעלת הדשבורד

```bash
# הפעלה בסיסית
python module.py --dashboard

# הפעלה עם פורט מותאם
python module.py --dashboard --port 8080

# הפעלה עם תצורה מותאמת
python module.py --dashboard --config config.json
```

### תכונות הדשבורד
- **סקירה כללית** - מטריקות ראשיות וגרפי מגמות
- **רשימת כשלים** - טבלה מפורטת עם סינון וחיפוש
- **ניתוח דפוסים** - זיהוי וניתוח דפוסי כשלים
- **פאנל התאוששות** - ניהול והפעלת פעולות התאוששות
- **התראות** - הגדרת וניהול התראות
- **הגדרות** - תצורת המערכת וייצוא נתונים

## 🔧 API מתקדם

### מעקב מותאם

```python
# מעקב עם מידע מערכת
system_state = SystemState(
    timestamp=datetime.now(),
    cpu_usage=85.5,
    memory_usage=76.2,
    disk_usage=45.0,
    active_processes=156,
    system_load=2.1,
    error_rate=1.5
)

failure.system_state = system_state
module.track_failure(failure)
```

### חיפוש וסינון

```python
# חיפוש כשלים לפי קריטריונים
recent_critical = module.tracker.get_failures(
    category=FailureCategory.DATABASE,
    severity=FailureSeverity.CRITICAL,
    resolved=False,
    start_time=datetime.now() - timedelta(hours=24)
)

# קבלת כשלים פעילים
active_failures = module.tracker.get_active_failures()
```

### ניתוח חיזוי

```python
from failure_tracker.utils.failure_utils import FailureAnalyzer

analyzer = FailureAnalyzer()
current_metrics = module.metrics_collector.collect_current_metrics()
historical_failures = module.tracker.get_recent_failures(hours=168)

# חיזוי סיכון לכשלים
risk_analysis = analyzer.predict_failure_risk(
    current_metrics, 
    historical_failures
)

print(f"רמת סיכון: {risk_analysis.metrics['risk_level']}")
print(f"המלצות: {risk_analysis.recommendations}")
```

## 📧 אינטגרציות

### אימייל
```python
# הגדרת התראות אימייל
module.alert_manager.configure_email(
    smtp_server="smtp.company.com",
    smtp_port=587,
    username="alerts@company.com", 
    password="secure_password"
)
```

### Slack (בפיתוח)
```python
# אינטגרציה עם Slack - בקרוב
# module.alert_manager.configure_slack(webhook_url="...")
```

### Webhooks (בפיתוח)
```python
# התראות דרך webhooks - בקרוב  
# module.alert_manager.add_webhook("https://api.company.com/alerts")
```

## 🧪 בדיקות ואימות

### הרצת בדיקות

```bash
# בדיקות יחידה
pytest tests/

# בדיקות עם כיסוי
pytest tests/ --cov=failure_tracker

# בדיקת תקינות המודול
python -c "
from failure_tracker.module import create_failure_tracker_module
module = create_failure_tracker_module()
health = module.health_check()
print(f'סטטוס: {health[\"overall_status\"]}')
"
```

### דוגמת בדיקה

```python
def test_failure_tracking():
    module = create_failure_tracker_module()
    module.start()
    
    try:
        # יצירת כשל לבדיקה
        failure = FailureEvent(
            title="בדיקת מערכת",
            category=FailureCategory.CODE_EXECUTION,
            severity=FailureSeverity.LOW
        )
        
        failure_id = module.track_failure(failure)
        assert failure_id is not None
        
        # וידוא שהכשל נשמר
        tracked_failure = module.tracker.get_failure(failure_id)
        assert tracked_failure is not None
        assert tracked_failure.title == "בדיקת מערכת"
        
    finally:
        module.stop()
```

## 📈 ביצועים ואופטימיזציה

### מטריקות ביצועים
- **זמן תגובה** - < 100ms למעקב כשל בסיסי
- **throughput** - עד 1000 כשלים לשנייה
- **זיכרון** - < 50MB לכל 10,000 כשלים
- **מקום דיסק** - ~1KB לכל כשל

### אופטימיזציות
- **cache חכם** - זיכרון מהיר לכשלים אחרונים
- **batch processing** - עיבוד אצווה יעיל
- **אינדקסים DB** - חיפוש מהיר בבסיס הנתונים
- **compression** - דחיסת נתונים היסטוריים

## 🛡️ אבטחה ופרטיות

### אמצעי אבטחה
- **הצפנת נתונים** - הצפנה של נתונים רגישים
- **בקרת גישה** - הגבלת גישה למידע רגיש
- **audit log** - מעקב פעולות משתמשים
- **data masking** - הסתרת מידע רגיש בלוגים

### תאימות תקנים
- **GDPR** - תמיכה במחיקת נתונים אישיים
- **SOX** - שמירת audit trail מלא
- **ISO 27001** - עמידה בתקני אבטחת מידע

## 🔧 פתרון בעיות

### בעיות נפוצות

**שגיאת חיבור למסד נתונים**
```bash
# בדיקת קיום קובץ DB
ls -la failure_tracker.db

# אתחול מסד נתונים מחדש
rm failure_tracker.db
python -c "from failure_tracker.core.failure_tracker import DatabaseManager; DatabaseManager()"
```

**בעיות ביצועים**
```python
# הגדרת cache גדול יותר
module.config['cache_size'] = 5000
module.tracker.cache_size = 5000

# הפחתת תדירות מעקב
module.config['monitoring_interval'] = 60
```

**התראות לא מגיעות**
```python
# בדיקת תצורת אימייל
print(module.alert_manager.email_config)

# בדיקת כללי התראות
for rule_id, rule in module.alert_manager.rules.items():
    print(f"{rule_id}: {rule.enabled}")
```

### לוגים ודיבוג

```python
# הפעלת מצב debug
import logging
logging.getLogger('failure_tracker').setLevel(logging.DEBUG)

# בדיקת סטטוס מפורט
health = module.health_check()
print(json.dumps(health, indent=2, ensure_ascii=False))
```

## 📚 תיעוד נוסף

- [מדריך התקנה מפורט](docs/installation.md)
- [API Reference](docs/api_reference.md)  
- [מדריך תצורה](docs/configuration.md)
- [דוגמאות שימוש](docs/examples.md)
- [שאלות נפוצות](docs/faq.md)

## 🤝 תרומה לפרויקט

אנו מזמינים תרומות! אנא קראו את [מדריך התרומה](CONTRIBUTING.md) לפרטים.

### איך לתרום
1. Fork הפרויקט
2. יצירת branch חדש (`git checkout -b feature/amazing-feature`)
3. Commit השינויים (`git commit -m 'Add amazing feature'`)
4. Push לבranch (`git push origin feature/amazing-feature`)
5. פתיחת Pull Request

## 📜 רישיון

פרויקט זה מופץ תחת רישיון MIT. ראו קובץ [LICENSE](LICENSE) לפרטים.

## 🙏 תודות

- צוות הפיתוח של Effi AI
- קהילת המפתחים הישראלית
- תורמי קוד פתוח

## 📞 צור קשר

- **אימייל**: support@effi-ai.com
- **GitHub Issues**: [פתיחת ticket](https://github.com/effi-ai/failure-tracker/issues)
- **תיעוד**: [wiki הפרויקט](https://github.com/effi-ai/failure-tracker/wiki)

---

**עדכון אחרון**: דצמבר 2024  
**גרסה**: 1.0.0  
**מתחזקים**: צוות Effi AI

🔍 **FailTracker** - כי כל כשל הוא הזדמנות ללמוד ולהשתפר! 🚀