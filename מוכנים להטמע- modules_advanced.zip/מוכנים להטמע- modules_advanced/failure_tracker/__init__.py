"""
🔍 FailTracker - מודול מעקב כשלים מתקדם
Advanced Failure Tracking Module

מערכת מקיפה למעקב, ניתוח וטיפול בכשלים במערכת בזמן אמת
עם תמיכה מלאה בעברית והתאוששות אוטומטית.

מאפיינים עיקריים:
• מעקב כשלים בזמן אמת
• ניתוח דפוסי כשלים
• התאוששות אוטומטית
• התראות חכמות
• דשבורד אינטראקטיבי
• תמיכה מלאה בעברית

דוגמת שימוש:
    from failure_tracker import create_failure_tracker_module
    
    module = create_failure_tracker_module()
    module.start()
    
    try:
        # קוד שעלול להיכשל
        risky_operation()
    except Exception as e:
        module.track_exception(e)
"""

__version__ = "1.0.0"
__author__ = "Effi AI Team"
__email__ = "support@effi-ai.com"
__license__ = "MIT"

# ייבוא הקלאסים הראשיים
from .module import (
    FailureTrackerModule,
    create_failure_tracker_module,
    initialize_module
)

# ייבוא מודלי נתונים
from .models.failure_types import (
    FailureEvent,
    FailureCategory,
    FailureSeverity,
    FailurePattern,
    RecoveryAction,
    SystemState,
    FailureContext,
    create_failure_from_exception
)

# ייבוא רכיבי הליבה
from .core.failure_tracker import (
    FailureTracker,
    RealTimeMonitor,
    PatternAnalyzer,
    RecoveryManager
)

# ייבוא כלי עזר
from .utils.failure_utils import (
    FailureAnalyzer,
    PatternDetector,
    AlertManager,
    ReportGenerator,
    MetricsCollector,
    HebrewLocalizer,
    AlertRule,
    AnalysisResult
)

# רשימת ייצוא ציבורי
__all__ = [
    # מודול ראשי
    'FailureTrackerModule',
    'create_failure_tracker_module',
    'initialize_module',
    
    # מודלי נתונים
    'FailureEvent',
    'FailureCategory', 
    'FailureSeverity',
    'FailurePattern',
    'RecoveryAction',
    'SystemState',
    'FailureContext',
    'create_failure_from_exception',
    
    # רכיבי ליבה
    'FailureTracker',
    'RealTimeMonitor',
    'PatternAnalyzer', 
    'RecoveryManager',
    
    # כלי עזר
    'FailureAnalyzer',
    'PatternDetector',
    'AlertManager',
    'ReportGenerator',
    'MetricsCollector',
    'HebrewLocalizer',
    'AlertRule',
    'AnalysisResult',
    
    # מטא-דאטה
    '__version__',
    '__author__',
    '__email__',
    '__license__'
]

# פונקציות עזר מהירות
def quick_start(config_path: str = None) -> FailureTrackerModule:
    """
    התחלה מהירה של מודול מעקב כשלים
    
    Args:
        config_path: נתיב לקובץ תצורה (אופציונלי)
    
    Returns:
        מודול מעקב כשלים מותחל ופעיל
    """
    module = create_failure_tracker_module(config_path)
    module.start()
    return module


def track_exception_simple(exception: Exception, 
                          operation: str = None,
                          severity: FailureSeverity = FailureSeverity.MEDIUM) -> str:
    """
    מעקב מהיר אחר חריגה
    
    Args:
        exception: החריגה
        operation: שם הפעולה (אופציונלי)
        severity: רמת החומרה
    
    Returns:
        מזהה הכשל
    """
    # יצירת מודול זמני אם לא קיים
    global _global_tracker
    if '_global_tracker' not in globals():
        _global_tracker = quick_start()
    
    context = None
    if operation:
        context = FailureContext(
            operation_name=operation,
            module_name="quick_tracker",
            function_name="track_exception_simple",
            environment="unknown",
            version="1.0.0"
        )
    
    return _global_tracker.track_exception(
        exception, 
        context, 
        severity, 
        FailureCategory.UNKNOWN
    )


def get_module_info() -> dict:
    """
    קבלת מידע על המודול
    
    Returns:
        מילון עם מידע על המודול
    """
    return {
        'name': 'FailTracker',
        'version': __version__,
        'author': __author__,
        'license': __license__,
        'description': 'מערכת מעקב כשלים מתקדמת עם תמיכה בעברית',
        'capabilities': [
            'real_time_monitoring',
            'failure_tracking', 
            'pattern_analysis',
            'auto_recovery',
            'alerting',
            'reporting',
            'dashboard',
            'hebrew_support'
        ],
        'supported_categories': [cat.value for cat in FailureCategory],
        'supported_severities': [sev.value for sev in FailureSeverity]
    }


# הודעת ברוכים הבאים
def _print_welcome():
    """הדפסת הודעת ברוכים הבאים"""
    try:
        print(f"""
🔍 FailTracker v{__version__} - מעקב כשלים מתקדם
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

מערכת מקיפה למעקב וניתוח כשלים עם:
• מעקב זמן אמת ⏱️
• ניתוח דפוסים חכם 🧠  
• התאוששות אוטומטית 🤖
• דשבורד אינטראקטיבי 📊
• תמיכה מלאה בעברית 🇮🇱

להתחלה מהירה:
  from failure_tracker import quick_start
  module = quick_start()

לדוגמאות ותיעוד: README.md
        """)
    except:
        pass  # אם יש בעיה בהדפסה, לא נעצור


# הדפסת הודעת ברוכים הבאים בייבוא
if __name__ != '__main__':
    _print_welcome()


# דוגמה לשימוש המודול
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--demo':
        print("🚀 הפעלת דמו למודול מעקב כשלים...")
        
        # יצירת מודול
        module = quick_start()
        
        try:
            # דמו כשל
            try:
                result = 1 / 0
            except Exception as e:
                failure_id = track_exception_simple(
                    e, 
                    "demo_division", 
                    FailureSeverity.MEDIUM
                )
                print(f"✅ כשל נוסף למעקב: {failure_id}")
            
            # סטטיסטיקות
            stats = module.get_failure_statistics()
            print(f"📊 סטטיסטיקות: {stats['total_failures']} כשלים")
            
            # דוח יומי
            report = module.generate_daily_report()
            print("\n📋 דוח יומי:")
            print(report[:200] + "..." if len(report) > 200 else report)
            
        finally:
            module.stop()
            print("\n✅ דמו הושלם בהצלחה!")
    
    else:
        print("שימוש: python -m failure_tracker --demo")
        print("או: from failure_tracker import quick_start")