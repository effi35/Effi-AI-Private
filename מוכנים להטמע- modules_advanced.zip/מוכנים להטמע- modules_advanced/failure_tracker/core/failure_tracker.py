"""
מעקב כשלים ראשי - Main Failure Tracker Engine
מנוע מקיף למעקב, ניתוח וטיפול בכשלים במערכת בזמן אמת
"""

import json
import sqlite3
import threading
import time
import logging
import psutil
import asyncio
from collections import defaultdict, deque
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any, Tuple, Set
from dataclasses import asdict
from concurrent.futures import ThreadPoolExecutor
import queue

from ..models.failure_types import (
    FailureEvent, FailureCategory, FailureSeverity, FailurePattern,
    RecoveryAction, SystemState, FailureContext, create_failure_from_exception,
    DEFAULT_RECOVERY_ACTIONS
)


class DatabaseManager:
    """מנהל בסיס נתונים לכשלים"""
    
    def __init__(self, db_path: str = "failure_tracker.db"):
        self.db_path = db_path
        self.connection = None
        self.lock = threading.Lock()
        self._initialize_database()
    
    def _initialize_database(self):
        """אתחול בסיס הנתונים"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS failures (
                        id TEXT PRIMARY KEY,
                        timestamp TEXT NOT NULL,
                        category TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT,
                        error_message TEXT,
                        stack_trace TEXT,
                        context TEXT,
                        system_state TEXT,
                        resolved INTEGER DEFAULT 0,
                        resolution_time TEXT,
                        resolution_duration TEXT,
                        pattern_id TEXT,
                        impact_score REAL,
                        data TEXT
                    )
                """)
                
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS recovery_actions (
                        id TEXT PRIMARY KEY,
                        failure_id TEXT,
                        name TEXT NOT NULL,
                        description TEXT,
                        action_type TEXT,
                        execution_time TEXT,
                        success INTEGER,
                        effectiveness_score REAL,
                        data TEXT,
                        FOREIGN KEY (failure_id) REFERENCES failures (id)
                    )
                """)
                
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS failure_patterns (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        category TEXT NOT NULL,
                        frequency INTEGER DEFAULT 0,
                        first_occurrence TEXT,
                        last_occurrence TEXT,
                        success_rate REAL DEFAULT 0.0,
                        data TEXT
                    )
                """)
                
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS system_metrics (
                        timestamp TEXT PRIMARY KEY,
                        cpu_usage REAL,
                        memory_usage REAL,
                        disk_usage REAL,
                        active_processes INTEGER,
                        error_rate REAL,
                        response_time REAL
                    )
                """)
                
                # אינדקסים לביצועים
                conn.execute("CREATE INDEX IF NOT EXISTS idx_failures_timestamp ON failures(timestamp)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_failures_category ON failures(category)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_failures_severity ON failures(severity)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_failures_resolved ON failures(resolved)")
                
                conn.commit()
                
        except Exception as e:
            logging.error(f"שגיאה באתחול בסיס הנתונים: {e}")
            raise
    
    def save_failure(self, failure: FailureEvent) -> bool:
        """שמירת כשל"""
        try:
            with self.lock:
                with sqlite3.connect(self.db_path) as conn:
                    conn.execute("""
                        INSERT OR REPLACE INTO failures 
                        (id, timestamp, category, severity, title, description, error_message,
                         stack_trace, context, system_state, resolved, resolution_time,
                         resolution_duration, pattern_id, impact_score, data)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        failure.id,
                        failure.timestamp.isoformat(),
                        failure.category.value,
                        failure.severity.value,
                        failure.title,
                        failure.description,
                        failure.error_message,
                        failure.stack_trace,
                        json.dumps(failure.context.to_dict() if failure.context else {}),
                        json.dumps(failure.system_state.to_dict() if failure.system_state else {}),
                        int(failure.resolved),
                        failure.resolution_time.isoformat() if failure.resolution_time else None,
                        str(failure.resolution_duration) if failure.resolution_duration else None,
                        failure.pattern_id,
                        failure.calculate_impact_score(),
                        failure.to_json()
                    ))
                    
                    # שמירת פעולות התאוששות
                    for action in failure.attempted_actions:
                        self._save_recovery_action(conn, action, failure.id)
                    
                    conn.commit()
                    return True
                    
        except Exception as e:
            logging.error(f"שגיאה בשמירת כשל: {e}")
            return False
    
    def _save_recovery_action(self, conn, action: RecoveryAction, failure_id: str):
        """שמירת פעולת התאוששות"""
        conn.execute("""
            INSERT OR REPLACE INTO recovery_actions
            (id, failure_id, name, description, action_type, execution_time,
             success, effectiveness_score, data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            action.id,
            failure_id,
            action.name,
            action.description,
            action.action_type,
            action.execution_time.isoformat() if action.execution_time else None,
            int(action.success) if action.success is not None else None,
            action.effectiveness_score,
            action.to_json()
        ))
    
    def get_failures(self, limit: int = 100, category: Optional[FailureCategory] = None,
                    resolved: Optional[bool] = None, 
                    start_time: Optional[datetime] = None,
                    end_time: Optional[datetime] = None) -> List[FailureEvent]:
        """קבלת כשלים מבסיס הנתונים"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = "SELECT data FROM failures WHERE 1=1"
                params = []
                
                if category:
                    query += " AND category = ?"
                    params.append(category.value)
                
                if resolved is not None:
                    query += " AND resolved = ?"
                    params.append(int(resolved))
                
                if start_time:
                    query += " AND timestamp >= ?"
                    params.append(start_time.isoformat())
                
                if end_time:
                    query += " AND timestamp <= ?"
                    params.append(end_time.isoformat())
                
                query += " ORDER BY timestamp DESC LIMIT ?"
                params.append(limit)
                
                cursor = conn.execute(query, params)
                failures = []
                
                for row in cursor:
                    try:
                        failure_data = json.loads(row[0])
                        failure = FailureEvent.from_dict(failure_data)
                        failures.append(failure)
                    except Exception as e:
                        logging.warning(f"שגיאה בטעינת כשל: {e}")
                
                return failures
                
        except Exception as e:
            logging.error(f"שגיאה בקבלת כשלים: {e}")
            return []
    
    def get_failure_by_id(self, failure_id: str) -> Optional[FailureEvent]:
        """קבלת כשל לפי ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("SELECT data FROM failures WHERE id = ?", (failure_id,))
                row = cursor.fetchone()
                
                if row:
                    failure_data = json.loads(row[0])
                    return FailureEvent.from_dict(failure_data)
                
                return None
                
        except Exception as e:
            logging.error(f"שגיאה בקבלת כשל {failure_id}: {e}")
            return None


class RealTimeMonitor:
    """מונטור זמן אמת למעקב אחר כשלים"""
    
    def __init__(self, tracker: 'FailureTracker'):
        self.tracker = tracker
        self.monitoring = False
        self.monitor_thread = None
        self.alert_callbacks: List[Callable] = []
        self.metrics_history = deque(maxlen=1000)
        self.thresholds = {
            'cpu_usage': 90.0,
            'memory_usage': 85.0,
            'disk_usage': 90.0,
            'error_rate': 5.0,
            'response_time': 5000.0  # ms
        }
        
    def start_monitoring(self, interval: int = 10):
        """התחלת מעקב זמן אמת"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, args=(interval,))
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        logging.info("מעקב זמן אמת התחיל")
    
    def stop_monitoring(self):
        """עצירת מעקב זמן אמת"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        
        logging.info("מעקב זמן אמת הופסק")
    
    def _monitor_loop(self, interval: int):
        """לולאת מעקב ראשית"""
        while self.monitoring:
            try:
                # איסוף מטריקות מערכת
                system_state = self._collect_system_metrics()
                self.metrics_history.append(system_state)
                
                # בדיקת סטיות
                self._check_thresholds(system_state)
                
                # שמירת מטריקות
                self.tracker.db_manager.save_system_metrics(system_state)
                
                time.sleep(interval)
                
            except Exception as e:
                logging.error(f"שגיאה במעקב זמן אמת: {e}")
                time.sleep(interval)
    
    def _collect_system_metrics(self) -> SystemState:
        """איסוף מטריקות מערכת"""
        cpu_usage = psutil.cpu_percent()
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return SystemState(
            timestamp=datetime.now(),
            cpu_usage=cpu_usage,
            memory_usage=memory.percent,
            disk_usage=disk.percent,
            active_processes=len(psutil.pids()),
            system_load=psutil.getloadavg()[0] if hasattr(psutil, 'getloadavg') else 0.0,
            network_status=True,  # יש לממש בדיקה אמיתית
            database_status=True,  # יש לממש בדיקה אמיתית
            api_response_time=100.0,  # יש לממש מדידה אמיתית
            error_rate=self._calculate_error_rate(),
            active_users=1,  # יש לממש ספירה אמיתית
            system_uptime=timedelta(seconds=psutil.boot_time())
        )
    
    def _calculate_error_rate(self) -> float:
        """חישוב שיעור שגיאות"""
        # חישוב בהתבסס על כשלים אחרונים
        recent_failures = self.tracker.get_recent_failures(minutes=10)
        return len(recent_failures) / 10.0  # שגיאות לדקה
    
    def _check_thresholds(self, system_state: SystemState):
        """בדיקת חריגה מספים"""
        alerts = []
        
        if system_state.cpu_usage > self.thresholds['cpu_usage']:
            alerts.append(f"שימוש גבוה ב-CPU: {system_state.cpu_usage:.1f}%")
        
        if system_state.memory_usage > self.thresholds['memory_usage']:
            alerts.append(f"שימוש גבוה בזיכרון: {system_state.memory_usage:.1f}%")
        
        if system_state.disk_usage > self.thresholds['disk_usage']:
            alerts.append(f"שימוש גבוה בדיסק: {system_state.disk_usage:.1f}%")
        
        if system_state.error_rate > self.thresholds['error_rate']:
            alerts.append(f"שיעור שגיאות גבוה: {system_state.error_rate:.1f}/דקה")
        
        # שליחת התראות
        for alert in alerts:
            self._send_alert(alert, system_state)
    
    def _send_alert(self, message: str, system_state: SystemState):
        """שליחת התראה"""
        for callback in self.alert_callbacks:
            try:
                callback(message, system_state)
            except Exception as e:
                logging.error(f"שגיאה בשליחת התראה: {e}")
    
    def add_alert_callback(self, callback: Callable):
        """הוספת callback להתראות"""
        self.alert_callbacks.append(callback)
    
    def get_current_metrics(self) -> Optional[SystemState]:
        """קבלת מטריקות נוכחיות"""
        return self.metrics_history[-1] if self.metrics_history else None


class PatternAnalyzer:
    """מנתח דפוסי כשלים"""
    
    def __init__(self, tracker: 'FailureTracker'):
        self.tracker = tracker
        self.patterns: Dict[str, FailurePattern] = {}
        self.similarity_threshold = 0.7
        
    def analyze_failure(self, failure: FailureEvent) -> Optional[FailurePattern]:
        """ניתוח כשל וזיהוי דפוס"""
        # חיפוש דפוס קיים
        matching_pattern = self._find_matching_pattern(failure)
        
        if matching_pattern:
            # עדכון דפוס קיים
            matching_pattern.update_statistics(failure)
            failure.pattern_id = matching_pattern.id
            return matching_pattern
        else:
            # יצירת דפוס חדש אם מתאים
            if self._should_create_pattern(failure):
                new_pattern = self._create_pattern_from_failure(failure)
                self.patterns[new_pattern.id] = new_pattern
                failure.pattern_id = new_pattern.id
                return new_pattern
        
        return None
    
    def _find_matching_pattern(self, failure: FailureEvent) -> Optional[FailurePattern]:
        """חיפוש דפוס תואם"""
        for pattern in self.patterns.values():
            if self._calculate_similarity(failure, pattern) > self.similarity_threshold:
                return pattern
        return None
    
    def _calculate_similarity(self, failure: FailureEvent, pattern: FailurePattern) -> float:
        """חישוב דמיון בין כשל לדפוס"""
        score = 0.0
        
        # דמיון בקטגוריה
        if failure.category == pattern.category:
            score += 0.3
        
        # דמיון בהודעת שגיאה
        if failure.error_message and any(failure.error_message in condition 
                                       for condition in pattern.conditions):
            score += 0.3
        
        # דמיון בהקשר
        if failure.context and failure.context.operation_name in pattern.affected_operations:
            score += 0.2
        
        # דמיון בזמן (כשלים קרובים בזמן)
        if pattern.last_occurrence:
            time_diff = abs((failure.timestamp - pattern.last_occurrence).total_seconds())
            if time_diff < 3600:  # פחות משעה
                score += 0.2
        
        return min(1.0, score)
    
    def _should_create_pattern(self, failure: FailureEvent) -> bool:
        """האם ליצור דפוס חדש"""
        # יצירת דפוס רק עבור כשלים חמורים או חוזרים
        return (failure.severity in [FailureSeverity.CRITICAL, FailureSeverity.HIGH] or
                len(self._find_similar_failures(failure)) >= 2)
    
    def _find_similar_failures(self, failure: FailureEvent) -> List[FailureEvent]:
        """חיפוש כשלים דומים"""
        similar = []
        recent_failures = self.tracker.get_recent_failures(hours=24)
        
        for other_failure in recent_failures:
            if (other_failure.id != failure.id and
                other_failure.category == failure.category and
                other_failure.error_message == failure.error_message):
                similar.append(other_failure)
        
        return similar
    
    def _create_pattern_from_failure(self, failure: FailureEvent) -> FailurePattern:
        """יצירת דפוס מכשל"""
        pattern = FailurePattern(
            name=f"דפוס_{failure.category.value}_{len(self.patterns) + 1}",
            description=f"דפוס כשל עבור {failure.category.value}: {failure.error_message[:100]}",
            category=failure.category,
            conditions=[failure.error_message] if failure.error_message else [],
            frequency=1,
            first_occurrence=failure.timestamp,
            last_occurrence=failure.timestamp
        )
        
        if failure.context:
            pattern.affected_operations.append(failure.context.operation_name)
        
        return pattern
    
    def get_pattern_recommendations(self, pattern: FailurePattern) -> List[str]:
        """קבלת המלצות לדפוס"""
        recommendations = []
        
        # המלצות לפי קטגוריה
        if pattern.category == FailureCategory.API_CALL:
            recommendations.extend([
                "הוספת retry mechanism",
                "הגדרת timeout מתאים",
                "שימוש ב-circuit breaker",
                "הוספת fallback API"
            ])
        elif pattern.category == FailureCategory.DATABASE:
            recommendations.extend([
                "אופטימיזציה של שאילתות",
                "הוספת connection pooling",
                "שדרוג חומרה",
                "הוספת אינדקסים"
            ])
        elif pattern.category == FailureCategory.MEMORY:
            recommendations.extend([
                "אופטימיזציה של שימוש בזיכרון",
                "הוספת garbage collection",
                "הגדלת הקצאת זיכרון",
                "זיהוי memory leaks"
            ])
        
        return recommendations


class RecoveryManager:
    """מנהל התאוששות אוטומטית"""
    
    def __init__(self, tracker: 'FailureTracker'):
        self.tracker = tracker
        self.recovery_strategies: Dict[FailureCategory, List[RecoveryAction]] = DEFAULT_RECOVERY_ACTIONS.copy()
        self.auto_recovery_enabled = True
        self.max_recovery_attempts = 3
        
    def attempt_recovery(self, failure: FailureEvent) -> bool:
        """ניסיון התאוששות מכשל"""
        if not self.auto_recovery_enabled:
            return False
        
        # קבלת אסטרטגיות התאוששות
        strategies = self._get_recovery_strategies(failure)
        
        for strategy in strategies:
            if len(failure.attempted_actions) >= self.max_recovery_attempts:
                break
            
            try:
                logging.info(f"מנסה התאוששות: {strategy.name}")
                
                # ביצוע פעולת התאוששות
                success = strategy.execute(self._build_recovery_context(failure))
                
                # הוספת הפעולה לכשל
                failure.add_recovery_action(strategy)
                
                if success:
                    logging.info(f"התאוששות הצליחה: {strategy.name}")
                    return True
                else:
                    logging.warning(f"התאוששות נכשלה: {strategy.name}")
                    
            except Exception as e:
                logging.error(f"שגיאה בהתאוששות {strategy.name}: {e}")
                strategy.success = False
                strategy.error_message = str(e)
                failure.add_recovery_action(strategy)
        
        return False
    
    def _get_recovery_strategies(self, failure: FailureEvent) -> List[RecoveryAction]:
        """קבלת אסטרטגיות התאוששות"""
        strategies = []
        
        # אסטרטגיות לפי קטגוריה
        if failure.category in self.recovery_strategies:
            strategies.extend(self.recovery_strategies[failure.category])
        
        # אסטרטגיות בהתבסס על דפוס
        if failure.pattern_id:
            pattern = self.tracker.pattern_analyzer.patterns.get(failure.pattern_id)
            if pattern and pattern.recommended_actions:
                for action_name in pattern.recommended_actions:
                    strategies.append(RecoveryAction(
                        name=action_name,
                        description=f"פעולה מומלצת לדפוס {pattern.name}",
                        action_type="pattern_based"
                    ))
        
        # מיון לפי יעילות היסטורית
        strategies.sort(key=lambda x: x.effectiveness_score or 0.5, reverse=True)
        
        return strategies
    
    def _build_recovery_context(self, failure: FailureEvent) -> Dict[str, Any]:
        """בניית הקשר להתאוששות"""
        context = {
            'failure': failure,
            'system_state': failure.system_state,
            'timestamp': datetime.now()
        }
        
        if failure.context:
            context.update({
                'operation': failure.context.operation_name,
                'module': failure.context.module_name,
                'parameters': failure.context.parameters
            })
        
        return context
    
    def add_recovery_strategy(self, category: FailureCategory, action: RecoveryAction):
        """הוספת אסטרטגיית התאוששות"""
        if category not in self.recovery_strategies:
            self.recovery_strategies[category] = []
        self.recovery_strategies[category].append(action)
    
    def learn_from_recovery(self, failure: FailureEvent):
        """למידה מהתאוששות"""
        for action in failure.attempted_actions:
            if action.success and action.effectiveness_score:
                # עדכון יעילות האסטרטגיה
                self._update_strategy_effectiveness(failure.category, action)
    
    def _update_strategy_effectiveness(self, category: FailureCategory, action: RecoveryAction):
        """עדכון יעילות אסטרטגיה"""
        if category in self.recovery_strategies:
            for strategy in self.recovery_strategies[category]:
                if strategy.name == action.name:
                    # עדכון ציון יעילות ממוצע
                    if strategy.effectiveness_score is None:
                        strategy.effectiveness_score = action.effectiveness_score
                    else:
                        strategy.effectiveness_score = (
                            (strategy.effectiveness_score + action.effectiveness_score) / 2
                        )


class FailureTracker:
    """מעקב כשלים ראשי"""
    
    def __init__(self, db_path: str = "failure_tracker.db"):
        self.db_manager = DatabaseManager(db_path)
        self.monitor = RealTimeMonitor(self)
        self.pattern_analyzer = PatternAnalyzer(self)
        self.recovery_manager = RecoveryManager(self)
        
        self.failure_cache: Dict[str, FailureEvent] = {}
        self.active_failures: Set[str] = set()
        self.event_subscribers: List[Callable] = []
        
        # הגדרות
        self.auto_analysis = True
        self.auto_recovery = True
        self.cache_size = 1000
        
        # סטטיסטיקות
        self.stats = {
            'total_failures': 0,
            'resolved_failures': 0,
            'auto_resolved': 0,
            'patterns_detected': 0
        }
        
        self._setup_logging()
    
    def _setup_logging(self):
        """הגדרת logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('failure_tracker.log', encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
    
    def track_failure(self, failure: FailureEvent) -> str:
        """מעקב אחר כשל חדש"""
        try:
            # הוספה לזיכרון
            self.failure_cache[failure.id] = failure
            self.active_failures.add(failure.id)
            
            # ניתוח דפוסים
            if self.auto_analysis:
                pattern = self.pattern_analyzer.analyze_failure(failure)
                if pattern:
                    self.stats['patterns_detected'] += 1
            
            # ניסיון התאוששות אוטומטית
            if self.auto_recovery and failure.severity in [FailureSeverity.CRITICAL, FailureSeverity.HIGH]:
                recovery_success = self.recovery_manager.attempt_recovery(failure)
                if recovery_success:
                    self.stats['auto_resolved'] += 1
            
            # שמירה בבסיס נתונים
            self.db_manager.save_failure(failure)
            
            # עדכון סטטיסטיקות
            self.stats['total_failures'] += 1
            
            # הודעה למנויים
            self._notify_subscribers('failure_tracked', failure)
            
            # ניקוי cache אם נדרש
            self._cleanup_cache()
            
            logging.info(f"כשל נוסף למעקב: {failure.id} - {failure.title}")
            return failure.id
            
        except Exception as e:
            logging.error(f"שגיאה במעקב כשל: {e}")
            raise
    
    def track_exception(self, exception: Exception, 
                       context: Optional[FailureContext] = None,
                       severity: FailureSeverity = FailureSeverity.MEDIUM,
                       category: FailureCategory = FailureCategory.UNKNOWN) -> str:
        """מעקב אחר חריגה"""
        failure = create_failure_from_exception(exception, context, severity, category)
        
        # הוספת מצב מערכת נוכחי
        current_metrics = self.monitor.get_current_metrics()
        if current_metrics:
            failure.system_state = current_metrics
        
        return self.track_failure(failure)
    
    def resolve_failure(self, failure_id: str, 
                       resolution_time: Optional[datetime] = None,
                       recovery_action: Optional[RecoveryAction] = None) -> bool:
        """סימון כשל כנפתר"""
        try:
            failure = self.get_failure(failure_id)
            if not failure:
                return False
            
            failure.mark_resolved(resolution_time)
            
            if recovery_action:
                failure.add_recovery_action(recovery_action)
                self.recovery_manager.learn_from_recovery(failure)
            
            # הסרה מכשלים פעילים
            self.active_failures.discard(failure_id)
            
            # שמירה
            self.db_manager.save_failure(failure)
            
            # עדכון סטטיסטיקות
            self.stats['resolved_failures'] += 1
            
            # הודעה למנויים
            self._notify_subscribers('failure_resolved', failure)
            
            logging.info(f"כשל נפתר: {failure_id}")
            return True
            
        except Exception as e:
            logging.error(f"שגיאה בפתרון כשל {failure_id}: {e}")
            return False
    
    def get_failure(self, failure_id: str) -> Optional[FailureEvent]:
        """קבלת כשל לפי ID"""
        # חיפוש בזיכרון תחילה
        if failure_id in self.failure_cache:
            return self.failure_cache[failure_id]
        
        # חיפוש בבסיס נתונים
        failure = self.db_manager.get_failure_by_id(failure_id)
        if failure:
            self.failure_cache[failure_id] = failure
        
        return failure
    
    def get_failures(self, **kwargs) -> List[FailureEvent]:
        """קבלת כשלים לפי קריטריונים"""
        return self.db_manager.get_failures(**kwargs)
    
    def get_active_failures(self) -> List[FailureEvent]:
        """קבלת כשלים פעילים"""
        return [self.failure_cache[fid] for fid in self.active_failures 
                if fid in self.failure_cache]
    
    def get_recent_failures(self, hours: int = 24, minutes: int = 0) -> List[FailureEvent]:
        """קבלת כשלים אחרונים"""
        start_time = datetime.now() - timedelta(hours=hours, minutes=minutes)
        return self.get_failures(start_time=start_time)
    
    def get_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות"""
        stats = self.stats.copy()
        stats.update({
            'active_failures': len(self.active_failures),
            'cache_size': len(self.failure_cache),
            'patterns_count': len(self.pattern_analyzer.patterns),
            'resolution_rate': (
                self.stats['resolved_failures'] / max(1, self.stats['total_failures'])
            ),
            'auto_resolution_rate': (
                self.stats['auto_resolved'] / max(1, self.stats['total_failures'])
            )
        })
        return stats
    
    def subscribe_to_events(self, callback: Callable):
        """מנוי לאירועים"""
        self.event_subscribers.append(callback)
    
    def _notify_subscribers(self, event_type: str, data: Any):
        """הודעה למנויים"""
        for callback in self.event_subscribers:
            try:
                callback(event_type, data)
            except Exception as e:
                logging.error(f"שגיאה בהודעה למנוי: {e}")
    
    def _cleanup_cache(self):
        """ניקוי cache"""
        if len(self.failure_cache) > self.cache_size:
            # מחיקת הכשלים הישנים ביותר
            sorted_failures = sorted(
                self.failure_cache.items(),
                key=lambda x: x[1].timestamp
            )
            
            to_remove = len(self.failure_cache) - self.cache_size + 100
            for failure_id, _ in sorted_failures[:to_remove]:
                self.failure_cache.pop(failure_id, None)
                self.active_failures.discard(failure_id)
    
    def start_monitoring(self, interval: int = 10):
        """התחלת מעקב זמן אמת"""
        self.monitor.start_monitoring(interval)
    
    def stop_monitoring(self):
        """עצירת מעקב זמן אמת"""
        self.monitor.stop_monitoring()
    
    def add_alert_callback(self, callback: Callable):
        """הוספת callback להתראות"""
        self.monitor.add_alert_callback(callback)
    
    def export_failures(self, filepath: str, format: str = 'json') -> bool:
        """ייצוא כשלים לקובץ"""
        try:
            failures = self.get_failures(limit=10000)
            
            if format.lower() == 'json':
                data = [failure.to_dict() for failure in failures]
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            
            elif format.lower() == 'csv':
                import csv
                with open(filepath, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        'ID', 'Timestamp', 'Category', 'Severity', 'Title',
                        'Description', 'Error', 'Resolved', 'Resolution Time'
                    ])
                    
                    for failure in failures:
                        writer.writerow([
                            failure.id,
                            failure.timestamp.isoformat(),
                            failure.category.value,
                            failure.severity.value,
                            failure.title,
                            failure.description,
                            failure.error_message,
                            failure.resolved,
                            failure.resolution_time.isoformat() if failure.resolution_time else ''
                        ])
            
            logging.info(f"ייצוא {len(failures)} כשלים ל-{filepath}")
            return True
            
        except Exception as e:
            logging.error(f"שגיאה בייצוא כשלים: {e}")
            return False


# הרחבות למסד הנתונים
def add_system_metrics_to_db_manager():
    """הוספת שמירת מטריקות מערכת למנהל בסיס הנתונים"""
    
    def save_system_metrics(self, system_state: SystemState) -> bool:
        """שמירת מטריקות מערכת"""
        try:
            with self.lock:
                with sqlite3.connect(self.db_path) as conn:
                    conn.execute("""
                        INSERT OR REPLACE INTO system_metrics
                        (timestamp, cpu_usage, memory_usage, disk_usage,
                         active_processes, error_rate, response_time)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        system_state.timestamp.isoformat(),
                        system_state.cpu_usage,
                        system_state.memory_usage,
                        system_state.disk_usage,
                        system_state.active_processes,
                        system_state.error_rate,
                        system_state.api_response_time
                    ))
                    conn.commit()
                    return True
        except Exception as e:
            logging.error(f"שגיאה בשמירת מטריקות: {e}")
            return False
    
    DatabaseManager.save_system_metrics = save_system_metrics