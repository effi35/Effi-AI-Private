"""
כלי עזר למודל AI מקומי - Local AI Utilities
פונקציות עזר לניהול ואופטימיזציה של מודל Hudson/Llama3.1 המקומי
"""

import json
import os
import re
import hashlib
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class LocalAIConfig:
    """קונפיגורציה למודל AI מקומי"""
    
    # הגדרות ברירת מחדל למודל Hudson/Llama3.1
    DEFAULT_MODEL = "hudson/llama3.1-uncensored"
    DEFAULT_HOST = "http://localhost:11434"
    DEFAULT_TIMEOUT = 300  # 5 דקות
    DEFAULT_MAX_TOKENS = 4096
    DEFAULT_TEMPERATURE = 0.7
    
    # הגדרות ביצועים
    PERFORMANCE_SETTINGS = {
        "num_ctx": 4096,      # חלון הקשר
        "num_threads": -1,     # כל הליבות הזמינות
        "num_gpu": -1,        # כל כרטיסי הגרפיקה
        "num_batch": 512,     # גודל באצ'
        "numa": True,         # אופטימיזציית NUMA
        "use_mlock": True,    # נעילת זיכרון
        "use_mmap": True      # מיפוי זיכרון
    }
    
    # הגדרות אבטחה
    SECURITY_SETTINGS = {
        "enable_cors": False,
        "allowed_origins": ["http://localhost"],
        "max_request_size": "100MB",
        "rate_limit": {
            "requests_per_minute": 60,
            "tokens_per_minute": 50000
        }
    }

class PromptTemplates:
    """תבניות פרומפטים בעברית למודל המקומי"""
    
    SYSTEM_PROMPT = """אתה עוזר AI מקומי חכם ופרטי הפועל על מודל Hudson/Llama3.1.
אתה עונה בעברית ומספק מידע מדויק ושימושי.
שמור על פרטיות מלאה - כל המידע נשאר מקומי ובטוח."""
    
    CODE_ASSISTANT = """אתה מומחה תכנות המסייע בכתיבה ובניתוח קוד.
אתה עונה בעברית עם קוד באנגלית.
התמחויות שלך: Python, JavaScript, Java, C++, Go, Rust ועוד.
ספק הסבר מפורט לכל קוד שאתה כותב."""
    
    CREATIVE_ASSISTANT = """אתה עוזר יצירתי המסייע בכתיבה, רעיונות וחשיבה יצירתית.
אתה כותב בעברית שוטפת וספרותית.
עזור למשתמש ליצור תוכן מקורי ומעניין."""
    
    ANALYSIS_ASSISTANT = """אתה אנליסט מקצועי המסייע בניתוח נתונים ומידע.
אתה מספק ניתוחים מעמיקים ומסקנות מבוססות נתונים.
השתמש בעברית מדעית ומקצועית."""

class MessageProcessor:
    """מעבד הודעות למודל המקומי"""
    
    @staticmethod
    def prepare_hebrew_message(message: str) -> str:
        """הכנת הודעה בעברית למודל"""
        # ניקוי וטיוב הטקסט העברי
        cleaned = message.strip()
        
        # הוספת הנחיות לתגובה בעברית
        if not any(word in cleaned.lower() for word in ["respond", "answer", "עבר", "תגיב"]):
            cleaned += "\n\nאנא התגב בעברית."
        
        return cleaned
    
    @staticmethod
    def format_code_request(language: str, task: str, context: str = "") -> str:
        """עיצוב בקשת קוד"""
        prompt = f"""כתוב קוד ב-{language} עבור המשימה הבאה:
{task}

{f"הקשר נוסף: {context}" if context else ""}

הסבר את הקוד בעברית ותן דוגמאות לשימוש."""
        
        return prompt
    
    @staticmethod
    def create_conversation_context(messages: List[Dict[str, str]], max_context: int = 10) -> str:
        """יצירת הקשר שיחה"""
        if not messages:
            return ""
        
        # קחת את ההודעות האחרונות
        recent_messages = messages[-max_context:]
        
        context_parts = []
        for msg in recent_messages:
            role = "משתמש" if msg.get("role") == "user" else "עוזר"
            content = msg.get("content", "")
            context_parts.append(f"{role}: {content}")
        
        return "\n\n".join(context_parts)

class ResponseProcessor:
    """מעבד תגובות מהמודל המקומי"""
    
    @staticmethod
    def clean_hebrew_response(response: str) -> str:
        """ניקוי תגובה עברית"""
        if not response:
            return ""
        
        # ניקוי תווים מיותרים
        cleaned = response.strip()
        
        # ביטול כפל שורות
        cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
        
        # תיקון רווחים
        cleaned = re.sub(r' +', ' ', cleaned)
        
        return cleaned
    
    @staticmethod
    def extract_code_blocks(response: str) -> List[Dict[str, str]]:
        """חילוץ בלוקי קוד מהתגובה"""
        code_pattern = r'```(\w+)?\n(.*?)\n```'
        matches = re.findall(code_pattern, response, re.DOTALL)
        
        code_blocks = []
        for i, (language, code) in enumerate(matches):
            code_blocks.append({
                "id": f"code_block_{i}",
                "language": language or "text",
                "code": code.strip(),
                "line_count": len(code.strip().split('\n'))
            })
        
        return code_blocks
    
    @staticmethod
    def format_response_with_metadata(response: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """עיצוב תגובה עם מטאדאטה"""
        return {
            "content": ResponseProcessor.clean_hebrew_response(response),
            "code_blocks": ResponseProcessor.extract_code_blocks(response),
            "metadata": {
                **metadata,
                "response_length": len(response),
                "has_code": "```" in response,
                "is_hebrew": any('\u0590' <= char <= '\u05FF' for char in response),
                "processed_at": datetime.now().isoformat()
            }
        }

class PerformanceOptimizer:
    """אופטימיזציה לביצועי המודל המקומי"""
    
    @staticmethod
    def calculate_optimal_batch_size(available_memory_gb: float, model_size_gb: float = 8) -> int:
        """חישוב גודל באצ' אופטימלי"""
        # שמירת 2GB לסיסטם
        usable_memory = max(available_memory_gb - 2 - model_size_gb, 1)
        
        # חישוב גודל באצ' בהתבסס על זיכרון זמין
        if usable_memory >= 8:
            return 1024
        elif usable_memory >= 4:
            return 512
        elif usable_memory >= 2:
            return 256
        else:
            return 128
    
    @staticmethod
    def get_cpu_optimization_settings() -> Dict[str, Any]:
        """הגדרות אופטימיזציה למעבד"""
        import os
        
        cpu_count = os.cpu_count() or 4
        
        return {
            "num_threads": max(cpu_count - 1, 1),  # השאר ליבה אחת לסיסטם
            "numa": True,
            "use_mlock": True,
            "use_mmap": True
        }

class CacheManager:
    """מנהל מטמון למודל המקומי"""
    
    def __init__(self, cache_dir: str = "/tmp/ollama_cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.max_cache_size_mb = 1024  # 1GB
    
    def _get_cache_key(self, prompt: str, model: str, params: Dict[str, Any]) -> str:
        """יצירת מפתח מטמון"""
        cache_input = f"{prompt}|{model}|{json.dumps(params, sort_keys=True)}"
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def get_cached_response(self, prompt: str, model: str, params: Dict[str, Any]) -> Optional[str]:
        """קבלת תגובה מהמטמון"""
        try:
            cache_key = self._get_cache_key(prompt, model, params)
            cache_file = self.cache_dir / f"{cache_key}.json"
            
            if cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # בדיקת תוקף המטמון (24 שעות)
                cached_time = datetime.fromisoformat(data['timestamp'])
                if datetime.now() - cached_time < timedelta(hours=24):
                    logger.info(f"תגובה נמצאה במטמון: {cache_key[:8]}")
                    return data['response']
            
            return None
            
        except Exception as e:
            logger.error(f"שגיאה בקריאת מטמון: {e}")
            return None
    
    def cache_response(self, prompt: str, model: str, params: Dict[str, Any], response: str):
        """שמירת תגובה במטמון"""
        try:
            cache_key = self._get_cache_key(prompt, model, params)
            cache_file = self.cache_dir / f"{cache_key}.json"
            
            data = {
                "prompt": prompt[:200],  # שמירת תחילת הפרומפט בלבד
                "model": model,
                "params": params,
                "response": response,
                "timestamp": datetime.now().isoformat()
            }
            
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"תגובה נשמרה במטמון: {cache_key[:8]}")
            
            # ניקוי מטמון ישן
            self._cleanup_old_cache()
            
        except Exception as e:
            logger.error(f"שגיאה בשמירת מטמון: {e}")
    
    def _cleanup_old_cache(self):
        """ניקוי מטמון ישן"""
        try:
            cache_files = list(self.cache_dir.glob("*.json"))
            total_size = sum(f.stat().st_size for f in cache_files) / (1024 * 1024)  # MB
            
            if total_size > self.max_cache_size_mb:
                # מיון לפי זמן גישה ומחיקת הישנים
                cache_files.sort(key=lambda f: f.stat().st_atime)
                files_to_delete = cache_files[:len(cache_files) // 2]  # מחק חצי
                
                for file_path in files_to_delete:
                    file_path.unlink()
                
                logger.info(f"נמחקו {len(files_to_delete)} קבצי מטמון ישנים")
                
        except Exception as e:
            logger.error(f"שגיאה בניקוי מטמון: {e}")

class ErrorHandler:
    """מטפל שגיאות למודל המקומי"""
    
    ERROR_MESSAGES = {
        "connection_error": "שגיאת חיבור למודל המקומי. בדוק שהשרת Ollama פועל.",
        "model_not_found": "מודל Hudson/Llama3.1 לא נמצא. בדוק את התקנת המודל.",
        "timeout_error": "המודל לא הגיב בזמן הקצוב. נסה הודעה קצרה יותר.",
        "memory_error": "אין מספיק זיכרון להרצת המודל. סגור יישומים אחרים.",
        "gpu_error": "שגיאה בכרטיס הגרפיקה. המודל יעבור למעבד.",
        "rate_limit": "יותר מדי בקשות. המתן מעט לפני שליחת הודעה נוספת."
    }
    
    @staticmethod
    def get_user_friendly_error(error: Exception) -> str:
        """המרת שגיאה להודעה ידידותית למשתמש"""
        error_str = str(error).lower()
        
        if "connection" in error_str or "refused" in error_str:
            return ErrorHandler.ERROR_MESSAGES["connection_error"]
        elif "not found" in error_str or "404" in error_str:
            return ErrorHandler.ERROR_MESSAGES["model_not_found"]
        elif "timeout" in error_str:
            return ErrorHandler.ERROR_MESSAGES["timeout_error"]
        elif "memory" in error_str or "oom" in error_str:
            return ErrorHandler.ERROR_MESSAGES["memory_error"]
        elif "cuda" in error_str or "gpu" in error_str:
            return ErrorHandler.ERROR_MESSAGES["gpu_error"]
        elif "rate" in error_str or "limit" in error_str:
            return ErrorHandler.ERROR_MESSAGES["rate_limit"]
        else:
            return f"שגיאה בלתי צפויה: {str(error)[:100]}"

class SystemMonitor:
    """מוניטור מערכת למודל המקומי"""
    
    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """קבלת מידע על המערכת"""
        import psutil
        import platform
        
        return {
            "platform": platform.system(),
            "cpu_count": os.cpu_count(),
            "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
            "memory_available_gb": round(psutil.virtual_memory().available / (1024**3), 2),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_usage_percent": psutil.disk_usage('/').percent,
            "load_average": os.getloadavg() if hasattr(os, 'getloadavg') else None
        }
    
    @staticmethod
    def check_ollama_health() -> Dict[str, Any]:
        """בדיקת בריאות שרת Ollama"""
        import aiohttp
        
        async def _check():
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get("http://localhost:11434/api/tags", timeout=5) as response:
                        if response.status == 200:
                            models = await response.json()
                            return {
                                "status": "healthy",
                                "models_count": len(models.get("models", [])),
                                "hudson_available": any("hudson" in m.get("name", "").lower() for m in models.get("models", []))
                            }
                        else:
                            return {"status": "unhealthy", "error": f"HTTP {response.status}"}
            except Exception as e:
                return {"status": "error", "error": str(e)}
        
        return asyncio.run(_check())

# פונקציות עזר גלובליות
def create_local_ai_session(model_name: str = LocalAIConfig.DEFAULT_MODEL) -> Dict[str, Any]:
    """יצירת סשן AI מקומי"""
    return {
        "session_id": f"local_ai_{datetime.now().timestamp()}",
        "model_name": model_name,
        "created_at": datetime.now().isoformat(),
        "settings": LocalAIConfig.PERFORMANCE_SETTINGS.copy()
    }

def validate_hebrew_input(text: str) -> bool:
    """בדיקת קלט עברי תקין"""
    if not text or not text.strip():
        return False
    
    # בדיקת נוכחות תווים עברים
    hebrew_chars = sum(1 for char in text if '\u0590' <= char <= '\u05FF')
    return hebrew_chars > 0

def optimize_prompt_for_local_model(prompt: str, context: str = "") -> str:
    """אופטימיזציה של פרומפט למודל מקומי"""
    optimized = PromptTemplates.SYSTEM_PROMPT + "\n\n"
    
    if context:
        optimized += f"הקשר: {context}\n\n"
    
    optimized += MessageProcessor.prepare_hebrew_message(prompt)
    
    return optimized