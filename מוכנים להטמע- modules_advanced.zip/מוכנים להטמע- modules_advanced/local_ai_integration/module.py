"""
מודול אינטגרציית AI מקומי - Local AI Integration Module
מודול מתקדם לניהול וחיבור למודל Hudson/Llama3.1 המקומי עם פרטיות מלאה
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from dataclasses import asdict

from .models.ollama_integration import (
    OllamaModel, ChatSession, ChatMessage, InferenceRequest, 
    create_llama_uncensored_model
)
from .core.ollama_client import OllamaClient
from .ui.ollama_dashboard import OllamaDashboard, get_dashboard, initialize_dashboard
from .utils.local_ai_utils import (
    LocalAIConfig, MessageProcessor, ResponseProcessor, 
    PerformanceOptimizer, CacheManager, ErrorHandler, SystemMonitor,
    create_local_ai_session, validate_hebrew_input, optimize_prompt_for_local_model
)

logger = logging.getLogger(__name__)

class LocalAIIntegrationModule:
    """מודול אינטגרציית AI מקומי מתקדם"""
    
    def __init__(self):
        self.name = "local_ai_integration"
        self.display_name = "אינטגרציית AI מקומי"
        self.description = "מודול מתקדם לניהול וחיבור למודל Hudson/Llama3.1 המקומי"
        self.version = "1.0.0"
        self.author = "Effi AI Private System"
        
        # רכיבי המודול
        self.ollama_client = OllamaClient()
        self.dashboard = get_dashboard()
        self.cache_manager = CacheManager()
        self.current_model = create_llama_uncensored_model()
        
        # מטמון שיחות פעילות
        self.active_sessions: Dict[str, ChatSession] = {}
        self.is_initialized = False
        
    async def initialize(self) -> bool:
        """אתחול המודול"""
        try:
            logger.info("מאתחל מודול אינטגרציית AI מקומי...")
            
            # אתחול לוח הבקרה
            dashboard_ready = await initialize_dashboard()
            if not dashboard_ready:
                logger.warning("לוח הבקרה לא אותחל, המשך בלי ממשק משתמש")
            
            # בדיקת זמינות מודל Hudson/Llama3.1
            models = await self.ollama_client.list_models()
            hudson_available = any(
                "hudson" in model.name.lower() or "llama3.1" in model.name.lower() 
                for model in models
            )
            
            if not hudson_available:
                logger.error("מודל Hudson/Llama3.1 לא זמין!")
                return False
            
            # קביעת הגדרות אופטימליות
            system_info = SystemMonitor.get_system_info()
            optimal_settings = PerformanceOptimizer.get_cpu_optimization_settings()
            
            logger.info(f"מערכת זוהתה: {system_info['platform']}, "
                       f"זיכרון זמין: {system_info['memory_available_gb']}GB")
            
            self.is_initialized = True
            logger.info("מודול אינטגרציית AI מקומי אותחל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול מודול: {e}")
            return False
    
    async def start_conversation(self, 
                                context: str = "", 
                                system_prompt: str = "",
                                hebrew_optimized: bool = True) -> str:
        """התחלת שיחה חדשה עם המודל המקומי"""
        try:
            if not self.is_initialized:
                await self.initialize()
            
            # יצירת סשן חדש
            session_id = f"local_ai_{datetime.now().timestamp()}"
            
            # הכנת הקשר והנחיות מערכת
            if hebrew_optimized:
                final_context = context or "שיחה בעברית עם מודל AI מקומי"
                if system_prompt:
                    final_context = f"{system_prompt}\n\n{final_context}"
            else:
                final_context = context or system_prompt or "Conversation with local AI model"
            
            # יצירת סשן
            session = ChatSession(
                session_id=session_id,
                model_name=self.current_model.name,
                created_at=datetime.now(),
                context=final_context
            )
            
            self.active_sessions[session_id] = session
            
            # רישום בלוח הבקרה
            if self.dashboard:
                await self.dashboard.start_conversation(final_context)
            
            logger.info(f"התחילה שיחה חדשה: {session_id}")
            return session_id
            
        except Exception as e:
            logger.error(f"שגיאה בהתחלת שיחה: {e}")
            raise
    
    async def send_message(self, 
                          session_id: str, 
                          message: str,
                          use_cache: bool = True,
                          stream: bool = False,
                          temperature: float = 0.7) -> Union[str, Dict[str, Any]]:
        """שליחת הודעה למודל המקומי"""
        try:
            if session_id not in self.active_sessions:
                raise ValueError(f"מזהה שיחה לא קיים: {session_id}")
            
            session = self.active_sessions[session_id]
            
            # אופטימיזציה והכנת ההודעה
            if validate_hebrew_input(message):
                optimized_message = MessageProcessor.prepare_hebrew_message(message)
            else:
                optimized_message = message
            
            # בדיקת מטמון
            if use_cache:
                cached_response = self.cache_manager.get_cached_response(
                    optimized_message, 
                    self.current_model.name,
                    {"temperature": temperature}
                )
                if cached_response:
                    logger.info("תגובה נמצאה במטמון")
                    return cached_response
            
            # שליחה למודל
            start_time = datetime.now()
            
            if stream:
                # תגובה בזרימה
                response_parts = []
                async for chunk in self.ollama_client.stream_chat(
                    session_id, optimized_message, self.current_model.name
                ):
                    response_parts.append(chunk)
                    
                response = "".join(response_parts)
            else:
                # תגובה רגילה
                response = await self.ollama_client.chat(
                    session_id, optimized_message, self.current_model.name
                )
            
            end_time = datetime.now()
            response_time = (end_time - start_time).total_seconds()
            
            # עיבוד התגובה
            processed_response = ResponseProcessor.format_response_with_metadata(
                response, 
                {
                    "session_id": session_id,
                    "response_time": response_time,
                    "model_name": self.current_model.name,
                    "cached": False,
                    "stream": stream
                }
            )
            
            # שמירת ההודעות בסשן
            user_msg = ChatMessage(
                role="user",
                content=message,
                timestamp=start_time
            )
            ai_msg = ChatMessage(
                role="assistant",
                content=response,
                timestamp=end_time,
                metadata={"response_time": response_time}
            )
            
            session.messages.extend([user_msg, ai_msg])
            session.last_activity = end_time
            
            # שמירה במטמון
            if use_cache:
                self.cache_manager.cache_response(
                    optimized_message,
                    self.current_model.name,
                    {"temperature": temperature},
                    response
                )
            
            # עדכון לוח הבקרה
            if self.dashboard:
                await self.dashboard.send_message(session_id, message)
            
            return processed_response["content"] if not stream else processed_response
            
        except Exception as e:
            error_msg = ErrorHandler.get_user_friendly_error(e)
            logger.error(f"שגיאה בשליחת הודעה: {error_msg}")
            raise Exception(error_msg)
    
    async def generate_code(self, 
                           language: str, 
                           task: str, 
                           context: str = "",
                           session_id: Optional[str] = None) -> Dict[str, Any]:
        """יצירת קוד באמצעות המודל המקומי"""
        try:
            # יצירת סשן חדש אם לא סופק
            if not session_id:
                session_id = await self.start_conversation(
                    context="יצירת קוד עם מודל AI מקומי",
                    system_prompt="אתה מומחה תכנות המייצר קוד איכותי ומוסבר"
                )
            
            # הכנת פרומפט לקוד
            code_prompt = MessageProcessor.format_code_request(language, task, context)
            
            # שליחה למודל
            response = await self.send_message(session_id, code_prompt, use_cache=True)
            
            # חילוץ בלוקי קוד
            if isinstance(response, dict):
                code_blocks = response.get("code_blocks", [])
                content = response.get("content", "")
            else:
                code_blocks = ResponseProcessor.extract_code_blocks(response)
                content = response
            
            return {
                "session_id": session_id,
                "language": language,
                "task": task,
                "response": content,
                "code_blocks": code_blocks,
                "generated_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת קוד: {e}")
            raise
    
    async def analyze_text(self, 
                          text: str, 
                          analysis_type: str = "general",
                          session_id: Optional[str] = None) -> Dict[str, Any]:
        """ניתוח טקסט באמצעות המודל המקומי"""
        try:
            if not session_id:
                session_id = await self.start_conversation(
                    context="ניתוח טקסט עם מודל AI מקומי",
                    system_prompt="אתה אנליסט טקסט מקצועי המספק ניתוחים מעמיקים"
                )
            
            # הכנת פרומפט לניתוח
            analysis_prompts = {
                "general": f"נתח את הטקסט הבא:\n\n{text}",
                "sentiment": f"נתח את הרגש והטון בטקסט הבא:\n\n{text}",
                "summary": f"סכם את הטקסט הבא בצורה קצרה ומרוכזת:\n\n{text}",
                "keywords": f"חלץ מילות מפתח ונושאים עיקריים מהטקסט הבא:\n\n{text}"
            }
            
            prompt = analysis_prompts.get(analysis_type, analysis_prompts["general"])
            
            # שליחה למודל
            response = await self.send_message(session_id, prompt, use_cache=True)
            
            return {
                "session_id": session_id,
                "analysis_type": analysis_type,
                "original_text": text[:200] + "..." if len(text) > 200 else text,
                "analysis": response,
                "analyzed_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח טקסט: {e}")
            raise
    
    async def get_conversation_history(self, session_id: str) -> List[Dict[str, Any]]:
        """קבלת היסטוריית שיחה"""
        try:
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                return [asdict(msg) for msg in session.messages]
            else:
                # חיפוש בלוח הבקרה
                if self.dashboard:
                    return await self.dashboard.get_conversation_history(session_id)
                return []
        except Exception as e:
            logger.error(f"שגיאה בקבלת היסטוריה: {e}")
            return []
    
    async def end_conversation(self, session_id: str) -> bool:
        """סיום שיחה"""
        try:
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                session.ended_at = datetime.now()
                del self.active_sessions[session_id]
                
                # עדכון לוח הבקרה
                if self.dashboard:
                    await self.dashboard.end_conversation(session_id)
                
                logger.info(f"שיחה הסתיימה: {session_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"שגיאה בסיום שיחה: {e}")
            return False
    
    async def get_model_status(self) -> Dict[str, Any]:
        """קבלת סטטוס המודל המקומי"""
        try:
            # בדיקת בריאות Ollama
            ollama_health = SystemMonitor.check_ollama_health()
            
            # מידע על המערכת
            system_info = SystemMonitor.get_system_info()
            
            # סטטוס המודל
            models = await self.ollama_client.list_models()
            hudson_model = next(
                (m for m in models if "hudson" in m.name.lower() or "llama3.1" in m.name.lower()),
                None
            )
            
            # נתוני לוח הבקרה
            dashboard_data = {}
            if self.dashboard:
                dashboard_data = self.dashboard.get_dashboard_data()
            
            return {
                "model_available": hudson_model is not None,
                "model_info": asdict(hudson_model) if hudson_model else None,
                "ollama_health": ollama_health,
                "system_info": system_info,
                "active_sessions": len(self.active_sessions),
                "dashboard_data": dashboard_data,
                "module_initialized": self.is_initialized,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת סטטוס: {e}")
            return {"error": str(e), "timestamp": datetime.now().isoformat()}
    
    async def test_model_connection(self, test_message: str = "שלום, בדוק חיבור") -> Dict[str, Any]:
        """בדיקת חיבור למודל"""
        try:
            if self.dashboard:
                return await self.dashboard.test_model_response(test_message)
            else:
                # בדיקה ישירה
                session_id = await self.start_conversation("בדיקת חיבור")
                start_time = datetime.now()
                response = await self.send_message(session_id, test_message)
                end_time = datetime.now()
                await self.end_conversation(session_id)
                
                return {
                    "success": True,
                    "response": response,
                    "response_time": (end_time - start_time).total_seconds(),
                    "timestamp": end_time.isoformat()
                }
        except Exception as e:
            return {
                "success": False,
                "error": ErrorHandler.get_user_friendly_error(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def export_conversation(self, session_id: str, format_type: str = "json") -> str:
        """ייצוא שיחה"""
        try:
            if self.dashboard:
                return await self.dashboard.export_conversation(session_id, format_type)
            else:
                history = await self.get_conversation_history(session_id)
                if format_type == "json":
                    import json
                    return json.dumps(history, ensure_ascii=False, indent=2)
                else:
                    return str(history)
        except Exception as e:
            logger.error(f"שגיאה בייצוא שיחה: {e}")
            return ""
    
    async def cleanup_resources(self):
        """ניקוי משאבים"""
        try:
            # סיום כל השיחות הפעילות
            for session_id in list(self.active_sessions.keys()):
                await self.end_conversation(session_id)
            
            # ניקוי מטמון
            if hasattr(self.cache_manager, 'cleanup_old_cache'):
                self.cache_manager._cleanup_old_cache()
            
            # ניקוי לוח הבקרה
            if self.dashboard:
                await self.dashboard.cleanup_old_sessions()
            
            logger.info("ניקוי משאבים הושלם")
            
        except Exception as e:
            logger.error(f"שגיאה בניקוי משאבים: {e}")

# פונקציות API למודול
async def initialize_local_ai() -> LocalAIIntegrationModule:
    """אתחול מודול אינטגרציית AI מקומי"""
    module = LocalAIIntegrationModule()
    await module.initialize()
    return module

async def chat_with_local_ai(message: str, 
                           session_id: Optional[str] = None,
                           context: str = "",
                           hebrew_optimized: bool = True) -> Dict[str, Any]:
    """צ'אט עם המודל המקומי"""
    module = await initialize_local_ai()
    
    if not session_id:
        session_id = await module.start_conversation(context=context, hebrew_optimized=hebrew_optimized)
    
    response = await module.send_message(session_id, message)
    
    return {
        "session_id": session_id,
        "response": response,
        "timestamp": datetime.now().isoformat()
    }

async def generate_code_local(language: str, task: str, context: str = "") -> Dict[str, Any]:
    """יצירת קוד עם המודל המקומי"""
    module = await initialize_local_ai()
    return await module.generate_code(language, task, context)

async def analyze_text_local(text: str, analysis_type: str = "general") -> Dict[str, Any]:
    """ניתוח טקסט עם המודל המקומי"""
    module = await initialize_local_ai()
    return await module.analyze_text(text, analysis_type)

# יצוא למודול
__all__ = [
    'LocalAIIntegrationModule',
    'initialize_local_ai',
    'chat_with_local_ai', 
    'generate_code_local',
    'analyze_text_local'
]