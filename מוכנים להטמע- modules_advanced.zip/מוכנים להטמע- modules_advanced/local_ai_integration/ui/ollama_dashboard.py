"""
לוח בקרה של מודל AI מקומי - Ollama Dashboard
ממשק משתמש מתקדם לניהול מודל ה-AI המקומי Hudson/Llama3.1
"""

import json
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import logging

from ..core.ollama_client import OllamaClient
from ..models.ollama_integration import ChatSession, ChatMessage

logger = logging.getLogger(__name__)

@dataclass
class DashboardMetrics:
    """מטריקות לוח הבקרה"""
    total_conversations: int = 0
    total_messages: int = 0
    average_response_time: float = 0.0
    model_uptime: str = ""
    memory_usage: str = ""
    active_sessions: int = 0
    last_activity: str = ""

@dataclass
class ModelStatus:
    """סטטוס המודל"""
    is_online: bool = False
    model_name: str = "hudson/llama3.1-uncensored"
    version: str = "8b"
    loaded_at: Optional[str] = None
    last_response: Optional[str] = None
    error_message: Optional[str] = None

class OllamaDashboard:
    """לוח בקרה מתקדם למודל AI מקומי"""
    
    def __init__(self):
        self.ollama_client = OllamaClient()
        self.metrics = DashboardMetrics()
        self.model_status = ModelStatus()
        self.conversation_history: List[ChatSession] = []
        self.active_sessions: Dict[str, ChatSession] = {}
        
    async def initialize(self) -> bool:
        """אתחול לוח הבקרה"""
        try:
            # בדיקת זמינות המודל
            status = await self.check_model_status()
            if status:
                self.model_status.is_online = True
                self.model_status.loaded_at = datetime.now().isoformat()
                logger.info("לוח בקרה Ollama אותחל בהצלחה")
                return True
            return False
        except Exception as e:
            logger.error(f"שגיאה באתחול לוח הבקרה: {e}")
            self.model_status.error_message = str(e)
            return False
    
    async def check_model_status(self) -> bool:
        """בדיקת סטטוס המודל"""
        try:
            models = await self.ollama_client.list_models()
            hudson_model = next(
                (m for m in models if "hudson" in m.name.lower() or "llama3.1" in m.name.lower()),
                None
            )
            
            if hudson_model:
                self.model_status.is_online = True
                self.model_status.model_name = hudson_model.name
                self.model_status.last_response = datetime.now().isoformat()
                return True
            else:
                self.model_status.is_online = False
                self.model_status.error_message = "מודל Hudson/Llama3.1 לא נמצא"
                return False
                
        except Exception as e:
            self.model_status.is_online = False
            self.model_status.error_message = f"שגיאה בבדיקת סטטוס: {e}"
            return False
    
    async def start_conversation(self, context: str = "") -> str:
        """התחלת שיחה חדשה"""
        try:
            session_id = f"session_{datetime.now().timestamp()}"
            session = ChatSession(
                session_id=session_id,
                model_name="hudson/llama3.1-uncensored",
                created_at=datetime.now(),
                context=context or "שיחה עם מודל AI מקומי Hudson/Llama3.1"
            )
            
            self.active_sessions[session_id] = session
            self.conversation_history.append(session)
            self.metrics.total_conversations += 1
            self.metrics.active_sessions = len(self.active_sessions)
            
            logger.info(f"התחילה שיחה חדשה: {session_id}")
            return session_id
            
        except Exception as e:
            logger.error(f"שגיאה בהתחלת שיחה: {e}")
            raise
    
    async def send_message(self, session_id: str, message: str) -> str:
        """שליחת הודעה ב-AI מקומי"""
        try:
            if session_id not in self.active_sessions:
                raise ValueError(f"מזהה שיחה לא קיים: {session_id}")
            
            session = self.active_sessions[session_id]
            
            # שליחת הודעה למודל המקומי
            start_time = datetime.now()
            response = await self.ollama_client.chat(
                session_id=session_id,
                message=message,
                model_name="hudson/llama3.1-uncensored"
            )
            end_time = datetime.now()
            
            # חישוב זמן תגובה
            response_time = (end_time - start_time).total_seconds()
            
            # הוספת הודעות לשיחה
            user_msg = ChatMessage(
                role="user",
                content=message,
                timestamp=start_time
            )
            ai_msg = ChatMessage(
                role="assistant", 
                content=response,
                timestamp=end_time,
                metadata={"response_time": response_time}
            )
            
            session.messages.extend([user_msg, ai_msg])
            session.last_activity = end_time
            
            # עדכון מטריקות
            self.metrics.total_messages += 2
            self.metrics.last_activity = end_time.isoformat()
            self._update_average_response_time(response_time)
            
            return response
            
        except Exception as e:
            logger.error(f"שגיאה בשליחת הודעה: {e}")
            raise
    
    def _update_average_response_time(self, new_time: float):
        """עדכון זמן תגובה ממוצע"""
        if self.metrics.average_response_time == 0:
            self.metrics.average_response_time = new_time
        else:
            # חישוב ממוצע נע
            self.metrics.average_response_time = (
                (self.metrics.average_response_time * 0.8) + (new_time * 0.2)
            )
    
    async def get_conversation_history(self, session_id: str) -> List[Dict[str, Any]]:
        """קבלת היסטוריית שיחה"""
        try:
            if session_id not in self.active_sessions:
                # חיפוש בהיסטוריה
                session = next(
                    (s for s in self.conversation_history if s.session_id == session_id),
                    None
                )
            else:
                session = self.active_sessions[session_id]
            
            if not session:
                return []
            
            return [asdict(msg) for msg in session.messages]
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת היסטוריה: {e}")
            return []
    
    async def end_conversation(self, session_id: str):
        """סיום שיחה"""
        try:
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                session.ended_at = datetime.now()
                del self.active_sessions[session_id]
                self.metrics.active_sessions = len(self.active_sessions)
                
                logger.info(f"שיחה הסתיימה: {session_id}")
                
        except Exception as e:
            logger.error(f"שגיאה בסיום שיחה: {e}")
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """קבלת נתוני לוח הבקרה"""
        return {
            "model_status": asdict(self.model_status),
            "metrics": asdict(self.metrics),
            "active_sessions": len(self.active_sessions),
            "conversation_history": [asdict(s) for s in self.conversation_history[-10:]],  # 10 אחרונות
            "timestamp": datetime.now().isoformat()
        }
    
    async def test_model_response(self, test_message: str = "שלום, בדוק את הפעילות שלך") -> Dict[str, Any]:
        """בדיקת תגובת המודל"""
        try:
            start_time = datetime.now()
            
            # יצירת שיחת בדיקה
            test_session_id = await self.start_conversation("בדיקת מודל")
            response = await self.send_message(test_session_id, test_message)
            
            end_time = datetime.now()
            response_time = (end_time - start_time).total_seconds()
            
            # סיום שיחת הבדיקה
            await self.end_conversation(test_session_id)
            
            return {
                "success": True,
                "response": response,
                "response_time": response_time,
                "timestamp": end_time.isoformat()
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def export_conversation(self, session_id: str, format_type: str = "json") -> str:
        """ייצוא שיחה"""
        try:
            history = await self.get_conversation_history(session_id)
            
            if format_type == "json":
                return json.dumps(history, ensure_ascii=False, indent=2)
            elif format_type == "text":
                text_output = []
                for msg in history:
                    timestamp = msg.get("timestamp", "")
                    role = "משתמש" if msg["role"] == "user" else "AI"
                    content = msg["content"]
                    text_output.append(f"[{timestamp}] {role}: {content}\n")
                return "\n".join(text_output)
            
            return json.dumps(history, ensure_ascii=False, indent=2)
            
        except Exception as e:
            logger.error(f"שגיאה בייצוא שיחה: {e}")
            return ""
    
    async def cleanup_old_sessions(self, max_age_hours: int = 24):
        """ניקוי שיחות ישנות"""
        try:
            current_time = datetime.now()
            cleaned_count = 0
            
            # ניקוי שיחות פעילות ישנות
            expired_sessions = []
            for session_id, session in self.active_sessions.items():
                if session.last_activity:
                    age = (current_time - session.last_activity).total_seconds() / 3600
                    if age > max_age_hours:
                        expired_sessions.append(session_id)
            
            for session_id in expired_sessions:
                await self.end_conversation(session_id)
                cleaned_count += 1
            
            # ניקוי היסטוריה ישנה (השארת 100 אחרונות)
            if len(self.conversation_history) > 100:
                self.conversation_history = self.conversation_history[-100:]
                cleaned_count += len(self.conversation_history) - 100
            
            logger.info(f"נוקו {cleaned_count} שיחות ישנות")
            return cleaned_count
            
        except Exception as e:
            logger.error(f"שגיאה בניקוי שיחות: {e}")
            return 0

# פונקציית עזר ליצירת מופע יחיד
_dashboard_instance: Optional[OllamaDashboard] = None

def get_dashboard() -> OllamaDashboard:
    """קבלת מופע יחיד של לוח הבקרה"""
    global _dashboard_instance
    if _dashboard_instance is None:
        _dashboard_instance = OllamaDashboard()
    return _dashboard_instance

async def initialize_dashboard() -> bool:
    """אתחול לוח הבקרה הגלובלי"""
    dashboard = get_dashboard()
    return await dashboard.initialize()