"""
Ollama Client for Local AI Integration
לקוח Ollama לאינטגרציית בינה מלאכותית מקומית

Complete client for managing Hudson/llama3.1-uncensored:8b and other local models.
לקוח מלא לניהול Hudson/llama3.1-uncensored:8b ומודלים מקומיים אחרים.
"""

import asyncio
import aiohttp
import json
import logging
import time
from typing import Dict, List, Any, Optional, AsyncGenerator, Callable
from datetime import datetime, timedelta
import uuid

from ..models.ollama_integration import (
    OllamaModel, OllamaConfig, InferenceRequest, InferenceResult,
    ChatSession, ChatMessage, ChatHistory, InferenceMode,
    create_llama_uncensored_model, create_default_ollama_config
)

logger = logging.getLogger(__name__)

class OllamaClient:
    """
    Advanced Ollama client for complete local AI management
    לקוח Ollama מתקדם לניהול בינה מלאכותית מקומית מלא
    """
    
    def __init__(self, config: Optional[OllamaConfig] = None):
        self.config = config or create_default_ollama_config()
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Model management
        self.available_models: Dict[str, OllamaModel] = {}
        self.loaded_models: Dict[str, OllamaModel] = {}
        
        # Chat sessions
        self.active_sessions: Dict[str, ChatSession] = {}
        
        # Performance tracking
        self.inference_history: List[InferenceResult] = []
        self.performance_metrics: Dict[str, Any] = {}
        
        # Caching
        self.response_cache: Dict[str, Dict] = {}
        self.cache_hits: int = 0
        self.cache_misses: int = 0
        
        # Initialize with default model
        self._initialize_default_models()
        
        logger.info(f"Ollama client initialized for {self.config.get_base_url()}")
    
    def _initialize_default_models(self):
        """Initialize with Hudson Llama model"""
        hudson_model = create_llama_uncensored_model()
        self.available_models[hudson_model.name] = hudson_model
        
        logger.info(f"Initialized with Hudson Llama model: {hudson_model.name}")
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.disconnect()
    
    async def connect(self):
        """Connect to Ollama server"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.config.timeout)
            self.session = aiohttp.ClientSession(timeout=timeout)
        
        # Test connection
        try:
            await self.health_check()
            logger.info("Connected to Ollama server successfully")
        except Exception as e:
            logger.error(f"Failed to connect to Ollama server: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from Ollama server"""
        if self.session:
            await self.session.close()
            self.session = None
        logger.info("Disconnected from Ollama server")
    
    async def health_check(self) -> bool:
        """Check if Ollama server is healthy"""
        try:
            if not self.session:
                await self.connect()
            
            async with self.session.get(f"{self.config.get_base_url()}/api/tags") as response:
                return response.status == 200
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def list_available_models(self) -> List[OllamaModel]:
        """List all available models on the server"""
        try:
            if not self.session:
                await self.connect()
            
            async with self.session.get(f"{self.config.get_base_url()}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    models = data.get('models', [])
                    
                    for model_data in models:
                        model_name = model_data.get('name', '')
                        if model_name not in self.available_models:
                            # Create model instance from server data
                            model = self._create_model_from_server_data(model_data)
                            self.available_models[model_name] = model
                    
                    return list(self.available_models.values())
                else:
                    logger.error(f"Failed to list models: {response.status}")
                    return []
        
        except Exception as e:
            logger.error(f"Error listing models: {e}")
            return []
    
    def _create_model_from_server_data(self, model_data: Dict[str, Any]) -> OllamaModel:
        """Create OllamaModel from server response data"""
        name = model_data.get('name', '')
        size = model_data.get('size', 0)
        
        # Determine model family from name
        from ..models.ollama_integration import ModelFamily, ModelSize
        
        if 'llama' in name.lower():
            family = ModelFamily.LLAMA
        elif 'mistral' in name.lower():
            family = ModelFamily.MISTRAL
        elif 'codellama' in name.lower():
            family = ModelFamily.CODELLAMA
        else:
            family = ModelFamily.CUSTOM
        
        # Determine size category
        if size < 2 * 1024**3:  # < 2GB
            size_cat = ModelSize.SMALL
        elif size < 8 * 1024**3:  # < 8GB
            size_cat = ModelSize.MEDIUM
        else:
            size_cat = ModelSize.LARGE
        
        return OllamaModel(
            name=name,
            model_family=family,
            size=size_cat,
            download_size_gb=size / (1024**3),
            local_path=model_data.get('digest', ''),
            version=model_data.get('modified_at', ''),
            supports_chat=True,
            supports_completion=True,
            supports_hebrew=True
        )
    
    async def pull_model(self, model_name: str, progress_callback: Optional[Callable] = None) -> bool:
        """Pull/download a model from Ollama registry"""
        try:
            if not self.session:
                await self.connect()
            
            payload = {"name": model_name}
            
            async with self.session.post(
                f"{self.config.get_base_url()}/api/pull",
                json=payload
            ) as response:
                
                if response.status == 200:
                    # Stream the download progress
                    async for line in response.content:
                        if line:
                            try:
                                progress_data = json.loads(line.decode())
                                if progress_callback:
                                    progress_callback(progress_data)
                                
                                # Check if completed
                                if progress_data.get('status') == 'success':
                                    logger.info(f"Model {model_name} pulled successfully")
                                    await self.list_available_models()  # Refresh model list
                                    return True
                                    
                            except json.JSONDecodeError:
                                continue
                    
                    return True
                else:
                    logger.error(f"Failed to pull model {model_name}: {response.status}")
                    return False
        
        except Exception as e:
            logger.error(f"Error pulling model {model_name}: {e}")
            return False
    
    async def load_model(self, model_name: str) -> bool:
        """Load a model into memory"""
        try:
            # Check if model is available
            if model_name not in self.available_models:
                logger.error(f"Model {model_name} not available")
                return False
            
            # Simple load by making a small request
            load_request = InferenceRequest(
                model_name=model_name,
                prompt="Test",
                max_tokens=1
            )
            
            result = await self.generate(load_request)
            
            if result.success:
                self.loaded_models[model_name] = self.available_models[model_name]
                self.loaded_models[model_name].last_used = datetime.now()
                logger.info(f"Model {model_name} loaded successfully")
                return True
            else:
                logger.error(f"Failed to load model {model_name}")
                return False
        
        except Exception as e:
            logger.error(f"Error loading model {model_name}: {e}")
            return False
    
    async def generate(self, request: InferenceRequest) -> InferenceResult:
        """
        Generate response using specified model
        יצירת תשובה באמצעות המודל המוגדר
        """
        start_time = time.time()
        
        try:
            if not self.session:
                await self.connect()
            
            # Check cache first
            cache_key = self._get_cache_key(request)
            if self.config.enable_caching and cache_key in self.response_cache:
                cached_result = self.response_cache[cache_key]
                if time.time() - cached_result['timestamp'] < self.config.cache_ttl_seconds:
                    self.cache_hits += 1
                    logger.info(f"Cache hit for request {request.request_id}")
                    return InferenceResult(**cached_result['result'])
            
            self.cache_misses += 1
            
            # Prepare request for Ollama API
            api_request = request.to_ollama_format()
            
            # Choose appropriate endpoint
            if request.mode == InferenceMode.CHAT:
                endpoint = "/api/chat"
            else:
                endpoint = "/api/generate"
            
            # Make API request
            async with self.session.post(
                f"{self.config.get_base_url()}{endpoint}",
                json=api_request
            ) as response:
                
                if response.status == 200:
                    result = await self._process_successful_response(
                        response, request, start_time
                    )
                else:
                    result = await self._process_error_response(
                        response, request, start_time
                    )
            
            # Cache successful results
            if result.success and self.config.enable_caching:
                self.response_cache[cache_key] = {
                    'result': result.to_dict(),
                    'timestamp': time.time()
                }
                
                # Cleanup old cache entries
                self._cleanup_cache()
            
            # Store metrics
            self.inference_history.append(result)
            self._update_performance_metrics(result)
            
            return result
        
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return InferenceResult(
                request_id=request.request_id,
                model_name=request.model_name,
                response="",
                success=False,
                error_message=str(e),
                total_duration=(time.time() - start_time) * 1000
            )
    
    async def _process_successful_response(self, response: aiohttp.ClientResponse, 
                                          request: InferenceRequest, start_time: float) -> InferenceResult:
        """Process successful API response"""
        response_text = ""
        total_duration = 0
        load_duration = 0
        prompt_eval_count = 0
        prompt_eval_duration = 0
        eval_count = 0
        eval_duration = 0
        
        # Handle streaming response
        async for line in response.content:
            if line:
                try:
                    data = json.loads(line.decode())
                    
                    # Accumulate response text
                    if 'response' in data:
                        response_text += data['response']
                    elif 'message' in data and 'content' in data['message']:
                        response_text += data['message']['content']
                    
                    # Extract performance metrics
                    if 'total_duration' in data:
                        total_duration = data['total_duration'] / 1_000_000  # Convert to ms
                    if 'load_duration' in data:
                        load_duration = data['load_duration'] / 1_000_000
                    if 'prompt_eval_count' in data:
                        prompt_eval_count = data['prompt_eval_count']
                    if 'prompt_eval_duration' in data:
                        prompt_eval_duration = data['prompt_eval_duration'] / 1_000_000
                    if 'eval_count' in data:
                        eval_count = data['eval_count']
                    if 'eval_duration' in data:
                        eval_duration = data['eval_duration'] / 1_000_000
                    
                    # Check if this is the final response
                    if data.get('done', False):
                        break
                        
                except json.JSONDecodeError:
                    continue
        
        return InferenceResult(
            request_id=request.request_id,
            model_name=request.model_name,
            response=response_text,
            success=True,
            total_duration=total_duration or (time.time() - start_time) * 1000,
            load_duration=load_duration,
            prompt_eval_count=prompt_eval_count,
            prompt_eval_duration=prompt_eval_duration,
            eval_count=eval_count,
            eval_duration=eval_duration,
            input_tokens=len(request.prompt.split()),  # Rough estimation
            output_tokens=len(response_text.split()),   # Rough estimation
            finish_reason="stop"
        )
    
    async def _process_error_response(self, response: aiohttp.ClientResponse,
                                     request: InferenceRequest, start_time: float) -> InferenceResult:
        """Process error API response"""
        try:
            error_data = await response.json()
            error_message = error_data.get('error', f'HTTP {response.status}')
        except:
            error_message = f'HTTP {response.status}'
        
        return InferenceResult(
            request_id=request.request_id,
            model_name=request.model_name,
            response="",
            success=False,
            error_message=error_message,
            error_code=str(response.status),
            total_duration=(time.time() - start_time) * 1000
        )
    
    def _get_cache_key(self, request: InferenceRequest) -> str:
        """Generate cache key for request"""
        # Create a hash of the request parameters
        import hashlib
        
        key_data = f"{request.model_name}:{request.prompt}:{request.temperature}:{request.max_tokens}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def _cleanup_cache(self):
        """Clean up old cache entries"""
        if len(self.response_cache) > self.config.cache_size_mb * 10:  # Rough estimation
            # Remove oldest entries
            current_time = time.time()
            expired_keys = [
                key for key, value in self.response_cache.items()
                if current_time - value['timestamp'] > self.config.cache_ttl_seconds
            ]
            
            for key in expired_keys:
                del self.response_cache[key]
    
    def _update_performance_metrics(self, result: InferenceResult):
        """Update performance metrics"""
        model_name = result.model_name
        
        if model_name not in self.performance_metrics:
            self.performance_metrics[model_name] = {
                'total_requests': 0,
                'successful_requests': 0,
                'total_tokens': 0,
                'total_duration': 0.0,
                'average_tokens_per_second': 0.0,
                'average_response_time': 0.0
            }
        
        metrics = self.performance_metrics[model_name]
        metrics['total_requests'] += 1
        
        if result.success:
            metrics['successful_requests'] += 1
            metrics['total_tokens'] += result.output_tokens
            metrics['total_duration'] += result.total_duration
            
            # Update averages
            if metrics['successful_requests'] > 0:
                metrics['average_response_time'] = metrics['total_duration'] / metrics['successful_requests']
                
            if result.eval_duration > 0 and result.eval_count > 0:
                tokens_per_second = (result.eval_count / result.eval_duration) * 1000
                if metrics['average_tokens_per_second'] == 0:
                    metrics['average_tokens_per_second'] = tokens_per_second
                else:
                    # Running average
                    metrics['average_tokens_per_second'] = (
                        (metrics['average_tokens_per_second'] * (metrics['successful_requests'] - 1) + tokens_per_second)
                        / metrics['successful_requests']
                    )
    
    async def chat(self, session_id: str, message: str, model_name: str = "hudson/llama3.1-uncensored") -> str:
        """
        Simple chat interface
        ממשק צ'אט פשוט
        """
        try:
            # Get or create session
            if session_id not in self.active_sessions:
                self.active_sessions[session_id] = ChatSession(
                    session_id=session_id,
                    model_name=model_name,
                    history=ChatHistory(session_id=session_id)
                )
            
            session = self.active_sessions[session_id]
            
            # Add user message
            session.add_user_message(message)
            
            # Create inference request
            request = InferenceRequest(
                model_name=model_name,
                prompt=message,
                mode=InferenceMode.CHAT,
                chat_history=session.history.messages,
                temperature=session.temperature,
                max_tokens=session.max_tokens,
                request_id=str(uuid.uuid4()),
                session_id=session_id
            )
            
            # Generate response
            result = await self.generate(request)
            
            if result.success:
                # Add assistant response
                session.add_assistant_message(
                    result.response,
                    metadata={
                        'tokens_used': result.output_tokens,
                        'response_time': result.total_duration,
                        'model_version': result.model_version
                    }
                )
                
                # Update session metrics
                session.update_performance_metrics(
                    result.get_response_time_seconds(),
                    result.total_tokens
                )
                
                return result.response
            else:
                error_msg = f"שגיאה ביצירת תגובה: {result.error_message}"
                session.add_assistant_message(error_msg)
                return error_msg
        
        except Exception as e:
            logger.error(f"Chat error: {e}")
            return f"שגיאה בצ'אט: {str(e)}"
    
    async def chat_stream(self, session_id: str, message: str, 
                         model_name: str = "hudson/llama3.1-uncensored") -> AsyncGenerator[str, None]:
        """
        Streaming chat interface
        ממשק צ'אט זורם
        """
        try:
            # Get or create session
            if session_id not in self.active_sessions:
                self.active_sessions[session_id] = ChatSession(
                    session_id=session_id,
                    model_name=model_name,
                    history=ChatHistory(session_id=session_id)
                )
            
            session = self.active_sessions[session_id]
            session.add_user_message(message)
            
            # Prepare streaming request
            api_request = {
                "model": model_name,
                "messages": session.get_context_for_inference(),
                "stream": True,
                "options": {
                    "temperature": session.temperature,
                    "num_predict": session.max_tokens
                }
            }
            
            if not self.session:
                await self.connect()
            
            full_response = ""
            
            async with self.session.post(
                f"{self.config.get_base_url()}/api/chat",
                json=api_request
            ) as response:
                
                if response.status == 200:
                    async for line in response.content:
                        if line:
                            try:
                                data = json.loads(line.decode())
                                
                                if 'message' in data and 'content' in data['message']:
                                    chunk = data['message']['content']
                                    full_response += chunk
                                    yield chunk
                                
                                if data.get('done', False):
                                    break
                                    
                            except json.JSONDecodeError:
                                continue
                    
                    # Add complete response to session
                    if full_response:
                        session.add_assistant_message(full_response)
                
                else:
                    error_msg = f"שגיאה בזרימה: HTTP {response.status}"
                    session.add_assistant_message(error_msg)
                    yield error_msg
        
        except Exception as e:
            error_msg = f"שגיאה בצ'אט זורם: {str(e)}"
            logger.error(error_msg)
            yield error_msg
    
    def get_chat_session(self, session_id: str) -> Optional[ChatSession]:
        """Get chat session by ID"""
        return self.active_sessions.get(session_id)
    
    def list_chat_sessions(self) -> List[ChatSession]:
        """List all active chat sessions"""
        return list(self.active_sessions.values())
    
    def delete_chat_session(self, session_id: str) -> bool:
        """Delete chat session"""
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
            return True
        return False
    
    def get_model_info(self, model_name: str) -> Optional[Dict[str, Any]]:
        """Get detailed model information"""
        model = self.available_models.get(model_name)
        return model.to_dict() if model else None
    
    def get_performance_statistics(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics"""
        total_requests = len(self.inference_history)
        successful_requests = sum(1 for r in self.inference_history if r.success)
        
        return {
            'total_requests': total_requests,
            'successful_requests': successful_requests,
            'success_rate': (successful_requests / total_requests * 100) if total_requests > 0 else 0,
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'cache_hit_rate': (self.cache_hits / (self.cache_hits + self.cache_misses) * 100) if (self.cache_hits + self.cache_misses) > 0 else 0,
            'active_sessions': len(self.active_sessions),
            'loaded_models': len(self.loaded_models),
            'available_models': len(self.available_models),
            'model_performance': self.performance_metrics
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get client status"""
        return {
            'connected': self.session is not None,
            'server_url': self.config.get_base_url(),
            'available_models': len(self.available_models),
            'loaded_models': len(self.loaded_models),
            'active_sessions': len(self.active_sessions),
            'inference_history_size': len(self.inference_history),
            'cache_size': len(self.response_cache),
            'primary_model': "hudson/llama3.1-uncensored"
        }