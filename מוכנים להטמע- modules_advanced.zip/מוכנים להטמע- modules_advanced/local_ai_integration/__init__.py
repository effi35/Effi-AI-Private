"""
מודול אינטגרציית AI מקומי - Local AI Integration Module
ממשק לניהול מודל Hudson/Llama3.1 המקומי עם פרטיות מלאה

המודול מספק:
- חיבור ישיר למודל Ollama המקומי
- ממשק בעברית מותאם תרבותית
- מטמון ואופטימיזציה לביצועים
- לוח בקרה מתקדם לניהול שיחות
- אבטחה ופרטיות מלאה
"""

from .module import (
    LocalAIIntegrationModule,
    initialize_local_ai,
    chat_with_local_ai,
    generate_code_local,
    analyze_text_local
)

from .models.ollama_integration import (
    OllamaModel,
    ChatSession,
    ChatMessage,
    InferenceRequest,
    create_llama_uncensored_model
)

from .core.ollama_client import OllamaClient

from .ui.ollama_dashboard import (
    OllamaDashboard,
    get_dashboard,
    initialize_dashboard
)

from .utils.local_ai_utils import (
    LocalAIConfig,
    MessageProcessor,
    ResponseProcessor,
    PerformanceOptimizer,
    CacheManager,
    ErrorHandler,
    SystemMonitor,
    create_local_ai_session,
    validate_hebrew_input,
    optimize_prompt_for_local_model
)

__version__ = "1.0.0"
__author__ = "Effi AI Private System"
__description__ = "מודול אינטגרציית AI מקומי עם מודל Hudson/Llama3.1"

# רכיבי המודול הזמינים לייבוא
__all__ = [
    # מודול ראשי
    'LocalAIIntegrationModule',
    'initialize_local_ai',
    'chat_with_local_ai',
    'generate_code_local', 
    'analyze_text_local',
    
    # מודלים
    'OllamaModel',
    'ChatSession',
    'ChatMessage',
    'InferenceRequest',
    'create_llama_uncensored_model',
    
    # לקוח Ollama
    'OllamaClient',
    
    # לוח בקרה
    'OllamaDashboard',
    'get_dashboard',
    'initialize_dashboard',
    
    # כלי עזר
    'LocalAIConfig',
    'MessageProcessor',
    'ResponseProcessor',
    'PerformanceOptimizer',
    'CacheManager',
    'ErrorHandler',
    'SystemMonitor',
    'create_local_ai_session',
    'validate_hebrew_input',
    'optimize_prompt_for_local_model'
]