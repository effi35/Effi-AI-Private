"""
Ollama Integration Models
מודלי אינטגרציית Ollama

Complete integration with Ollama for local AI model management.
אינטגרציה מלאה עם Ollama לניהול מודלי בינה מלאכותית מקומיים.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, AsyncGenerator
from datetime import datetime
from enum import Enum
import json
import asyncio

class ModelSize(Enum):
    """Model size categories"""
    TINY = "tiny"           # קטן מאוד
    SMALL = "small"         # קטן  
    MEDIUM = "medium"       # בינוני
    LARGE = "large"         # גדול
    XLARGE = "xlarge"      # גדול מאוד

class ModelFamily(Enum):
    """Model families"""
    LLAMA = "llama"         # Llama models
    CODELLAMA = "codellama" # Code Llama models
    MISTRAL = "mistral"     # Mistral models
    GEMMA = "gemma"         # Gemma models
    PHI = "phi"             # Phi models
    QWEN = "qwen"           # Qwen models
    CUSTOM = "custom"       # Custom models

class InferenceMode(Enum):
    """Inference modes"""
    CHAT = "chat"           # צ'אט
    COMPLETION = "completion" # השלמת טקסט
    EMBEDDING = "embedding" # הטמעות
    GENERATION = "generation" # יצירה

@dataclass
class ChatMessage:
    """
    Chat message for conversation
    הודעת צ'אט לשיחה
    """
    role: str  # user, assistant, system
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'role': self.role,
            'content': self.content,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChatMessage':
        return cls(
            role=data['role'],
            content=data['content'],
            timestamp=datetime.fromisoformat(data.get('timestamp', datetime.now().isoformat())),
            metadata=data.get('metadata', {})
        )

@dataclass
class ChatHistory:
    """
    Chat conversation history
    היסטוריית שיחת צ'אט
    """
    session_id: str
    messages: List[ChatMessage] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    # Context settings
    system_prompt: str = ""
    temperature: float = 0.7
    max_tokens: int = 2048
    context_window: int = 4096
    
    # Session metadata
    model_name: str = ""
    total_tokens_used: int = 0
    conversation_summary: str = ""
    
    def add_message(self, message: ChatMessage):
        """Add message to history"""
        self.messages.append(message)
        self.updated_at = datetime.now()
        
        # Keep context window size
        if len(self.messages) > self.context_window // 100:  # Rough estimation
            # Remove older messages but keep system prompt
            system_messages = [msg for msg in self.messages if msg.role == 'system']
            other_messages = [msg for msg in self.messages if msg.role != 'system']
            
            # Keep last N messages
            keep_count = (self.context_window // 100) - len(system_messages)
            self.messages = system_messages + other_messages[-keep_count:]
    
    def get_conversation_context(self) -> List[Dict[str, Any]]:
        """Get conversation context for model"""
        return [msg.to_dict() for msg in self.messages]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'session_id': self.session_id,
            'messages': [msg.to_dict() for msg in self.messages],
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'system_prompt': self.system_prompt,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'context_window': self.context_window,
            'model_name': self.model_name,
            'total_tokens_used': self.total_tokens_used,
            'conversation_summary': self.conversation_summary
        }

@dataclass
class OllamaModel:
    """
    Ollama model configuration
    תצורת מודל Ollama
    """
    name: str
    model_family: ModelFamily
    size: ModelSize
    quantization: str = "Q4_K_M"  # Quantization level
    
    # Model capabilities
    supports_chat: bool = True
    supports_completion: bool = True
    supports_embedding: bool = False
    supports_code: bool = False
    supports_hebrew: bool = True
    
    # Technical specs
    parameter_count: str = ""  # "8B", "13B", "70B"
    context_length: int = 4096
    vocab_size: int = 32000
    architecture: str = ""
    
    # Performance
    memory_required_gb: float = 8.0
    inference_speed: str = "medium"  # slow, medium, fast
    gpu_required: bool = False
    
    # Model metadata
    version: str = "latest"
    description: str = ""
    description_hebrew: str = ""
    license: str = ""
    source_url: str = ""
    local_path: str = ""
    
    # Usage statistics
    download_size_gb: float = 0.0
    last_used: Optional[datetime] = None
    usage_count: int = 0
    
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def get_full_name(self) -> str:
        """Get full model name for Ollama"""
        return f"{self.name}:{self.quantization.lower()}" if self.quantization else self.name
    
    def is_downloaded(self) -> bool:
        """Check if model is downloaded locally"""
        return bool(self.local_path)
    
    def estimate_memory_usage(self) -> float:
        """Estimate memory usage in GB"""
        # Base estimation based on parameter count and quantization
        if "8B" in self.parameter_count or "8b" in self.name.lower():
            base_memory = 8.0
        elif "13B" in self.parameter_count or "13b" in self.name.lower():
            base_memory = 13.0
        elif "70B" in self.parameter_count or "70b" in self.name.lower():
            base_memory = 70.0
        else:
            base_memory = self.memory_required_gb
        
        # Adjust for quantization
        if "Q4" in self.quantization:
            return base_memory * 0.5
        elif "Q8" in self.quantization:
            return base_memory * 0.75
        else:
            return base_memory
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'model_family': self.model_family.value,
            'size': self.size.value,
            'quantization': self.quantization,
            'supports_chat': self.supports_chat,
            'supports_completion': self.supports_completion,
            'supports_embedding': self.supports_embedding,
            'supports_code': self.supports_code,
            'supports_hebrew': self.supports_hebrew,
            'parameter_count': self.parameter_count,
            'context_length': self.context_length,
            'vocab_size': self.vocab_size,
            'architecture': self.architecture,
            'memory_required_gb': self.memory_required_gb,
            'inference_speed': self.inference_speed,
            'gpu_required': self.gpu_required,
            'version': self.version,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'license': self.license,
            'source_url': self.source_url,
            'local_path': self.local_path,
            'download_size_gb': self.download_size_gb,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'usage_count': self.usage_count,
            'full_name': self.get_full_name(),
            'is_downloaded': self.is_downloaded(),
            'estimated_memory': self.estimate_memory_usage(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

@dataclass
class OllamaConfig:
    """
    Ollama client configuration
    תצורת לקוח Ollama
    """
    host: str = "localhost"
    port: int = 11434
    timeout: int = 300  # seconds
    
    # Default generation parameters
    default_temperature: float = 0.7
    default_top_p: float = 0.9
    default_top_k: int = 40
    default_max_tokens: int = 2048
    default_context_window: int = 4096
    
    # Performance settings
    num_thread: int = 8
    num_gpu_layers: int = 0  # 0 = CPU only
    batch_size: int = 512
    
    # Security settings
    enable_cors: bool = False
    allowed_origins: List[str] = field(default_factory=list)
    api_key: Optional[str] = None
    
    # Caching
    enable_caching: bool = True
    cache_size_mb: int = 1024
    cache_ttl_seconds: int = 3600
    
    def get_base_url(self) -> str:
        """Get base URL for Ollama API"""
        return f"http://{self.host}:{self.port}"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'host': self.host,
            'port': self.port,
            'timeout': self.timeout,
            'default_temperature': self.default_temperature,
            'default_top_p': self.default_top_p,
            'default_top_k': self.default_top_k,
            'default_max_tokens': self.default_max_tokens,
            'default_context_window': self.default_context_window,
            'num_thread': self.num_thread,
            'num_gpu_layers': self.num_gpu_layers,
            'batch_size': self.batch_size,
            'enable_cors': self.enable_cors,
            'allowed_origins': self.allowed_origins,
            'api_key': self.api_key,
            'enable_caching': self.enable_caching,
            'cache_size_mb': self.cache_size_mb,
            'cache_ttl_seconds': self.cache_ttl_seconds,
            'base_url': self.get_base_url()
        }

@dataclass
class InferenceRequest:
    """
    Request for model inference
    בקשה להסקת מודל
    """
    model_name: str
    prompt: str
    mode: InferenceMode = InferenceMode.COMPLETION
    
    # Generation parameters
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    max_tokens: int = 2048
    stop_tokens: List[str] = field(default_factory=list)
    
    # Context
    system_prompt: str = ""
    chat_history: Optional[List[ChatMessage]] = None
    context: str = ""
    
    # Advanced options
    seed: Optional[int] = None
    repeat_penalty: float = 1.1
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0
    
    # Metadata
    request_id: str = ""
    user_id: str = ""
    session_id: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_ollama_format(self) -> Dict[str, Any]:
        """Convert to Ollama API format"""
        request_data = {
            'model': self.model_name,
            'prompt': self.prompt,
            'options': {
                'temperature': self.temperature,
                'top_p': self.top_p,
                'top_k': self.top_k,
                'num_predict': self.max_tokens,
                'repeat_penalty': self.repeat_penalty
            }
        }
        
        if self.system_prompt:
            request_data['system'] = self.system_prompt
        
        if self.stop_tokens:
            request_data['options']['stop'] = self.stop_tokens
        
        if self.seed is not None:
            request_data['options']['seed'] = self.seed
        
        if self.mode == InferenceMode.CHAT and self.chat_history:
            request_data['messages'] = [msg.to_dict() for msg in self.chat_history]
        
        return request_data
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'model_name': self.model_name,
            'prompt': self.prompt,
            'mode': self.mode.value,
            'temperature': self.temperature,
            'top_p': self.top_p,
            'top_k': self.top_k,
            'max_tokens': self.max_tokens,
            'stop_tokens': self.stop_tokens,
            'system_prompt': self.system_prompt,
            'chat_history': [msg.to_dict() for msg in self.chat_history] if self.chat_history else None,
            'context': self.context,
            'seed': self.seed,
            'repeat_penalty': self.repeat_penalty,
            'presence_penalty': self.presence_penalty,
            'frequency_penalty': self.frequency_penalty,
            'request_id': self.request_id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'timestamp': self.timestamp.isoformat()
        }

@dataclass
class InferenceResult:
    """
    Result from model inference
    תוצאה מהסקת מודל
    """
    request_id: str
    model_name: str
    response: str
    success: bool = True
    
    # Performance metrics
    total_duration: float = 0.0  # milliseconds
    load_duration: float = 0.0
    prompt_eval_count: int = 0
    prompt_eval_duration: float = 0.0
    eval_count: int = 0
    eval_duration: float = 0.0
    
    # Token information
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    
    # Quality metrics
    perplexity: Optional[float] = None
    confidence_score: float = 0.0
    coherence_score: float = 0.0
    
    # Error handling
    error_message: str = ""
    error_code: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    
    # Metadata
    finish_reason: str = ""  # stop, length, error
    model_version: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    
    def get_tokens_per_second(self) -> float:
        """Calculate tokens per second"""
        if self.eval_duration > 0 and self.eval_count > 0:
            return (self.eval_count / self.eval_duration) * 1000  # Convert ms to seconds
        return 0.0
    
    def get_response_time_seconds(self) -> float:
        """Get total response time in seconds"""
        return self.total_duration / 1000.0  # Convert ms to seconds
    
    def get_efficiency_score(self) -> float:
        """Calculate efficiency score based on speed and quality"""
        speed_score = min(1.0, self.get_tokens_per_second() / 50.0)  # Normalize to 50 tokens/sec
        quality_score = (self.confidence_score + self.coherence_score) / 2.0
        return (speed_score + quality_score) / 2.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'request_id': self.request_id,
            'model_name': self.model_name,
            'response': self.response,
            'success': self.success,
            'total_duration': self.total_duration,
            'load_duration': self.load_duration,
            'prompt_eval_count': self.prompt_eval_count,
            'prompt_eval_duration': self.prompt_eval_duration,
            'eval_count': self.eval_count,
            'eval_duration': self.eval_duration,
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'total_tokens': self.total_tokens,
            'perplexity': self.perplexity,
            'confidence_score': self.confidence_score,
            'coherence_score': self.coherence_score,
            'error_message': self.error_message,
            'error_code': self.error_code,
            'warnings': self.warnings,
            'finish_reason': self.finish_reason,
            'model_version': self.model_version,
            'timestamp': self.timestamp.isoformat(),
            'tokens_per_second': self.get_tokens_per_second(),
            'response_time_seconds': self.get_response_time_seconds(),
            'efficiency_score': self.get_efficiency_score()
        }

@dataclass
class ChatSession:
    """
    Chat session with continuous conversation
    סשן צ'אט עם שיחה רציפה
    """
    session_id: str
    model_name: str
    history: ChatHistory
    
    # Session configuration
    system_prompt: str = ""
    temperature: float = 0.7
    max_tokens: int = 2048
    context_length: int = 4096
    
    # Session state
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_activity: datetime = field(default_factory=datetime.now)
    
    # Performance tracking
    total_requests: int = 0
    total_tokens_used: int = 0
    average_response_time: float = 0.0
    
    # Memory management
    conversation_summary: str = ""
    important_facts: List[str] = field(default_factory=list)
    user_preferences: Dict[str, Any] = field(default_factory=dict)
    
    def add_user_message(self, content: str) -> ChatMessage:
        """Add user message to session"""
        message = ChatMessage(role="user", content=content)
        self.history.add_message(message)
        self.last_activity = datetime.now()
        return message
    
    def add_assistant_message(self, content: str, metadata: Dict[str, Any] = None) -> ChatMessage:
        """Add assistant message to session"""
        message = ChatMessage(
            role="assistant", 
            content=content,
            metadata=metadata or {}
        )
        self.history.add_message(message)
        self.last_activity = datetime.now()
        return message
    
    def add_system_message(self, content: str) -> ChatMessage:
        """Add system message to session"""
        message = ChatMessage(role="system", content=content)
        self.history.add_message(message)
        return message
    
    def get_context_for_inference(self) -> List[Dict[str, Any]]:
        """Get conversation context for model inference"""
        context = []
        
        # Add system prompt if available
        if self.system_prompt:
            context.append({
                'role': 'system',
                'content': self.system_prompt
            })
        
        # Add conversation history
        context.extend(self.history.get_conversation_context())
        
        return context
    
    def update_performance_metrics(self, response_time: float, tokens_used: int):
        """Update session performance metrics"""
        self.total_requests += 1
        self.total_tokens_used += tokens_used
        
        # Update average response time
        if self.total_requests == 1:
            self.average_response_time = response_time
        else:
            self.average_response_time = (
                (self.average_response_time * (self.total_requests - 1) + response_time) 
                / self.total_requests
            )
    
    def should_summarize(self) -> bool:
        """Check if conversation should be summarized"""
        return len(self.history.messages) > (self.context_length // 100)
    
    def get_session_summary(self) -> str:
        """Get summary of the session"""
        if not self.history.messages:
            return "Empty conversation"
        
        duration = (self.last_activity - self.created_at).total_seconds()
        hours = duration // 3600
        minutes = (duration % 3600) // 60
        
        return f"""
Session Summary:
- Duration: {int(hours)}h {int(minutes)}m
- Messages: {len(self.history.messages)}
- Requests: {self.total_requests}
- Tokens Used: {self.total_tokens_used}
- Avg Response Time: {self.average_response_time:.2f}s
- Model: {self.model_name}
"""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'session_id': self.session_id,
            'model_name': self.model_name,
            'history': self.history.to_dict(),
            'system_prompt': self.system_prompt,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'context_length': self.context_length,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'last_activity': self.last_activity.isoformat(),
            'total_requests': self.total_requests,
            'total_tokens_used': self.total_tokens_used,
            'average_response_time': self.average_response_time,
            'conversation_summary': self.conversation_summary,
            'important_facts': self.important_facts,
            'user_preferences': self.user_preferences,
            'session_summary': self.get_session_summary()
        }

# Factory functions for creating specific models
def create_llama_uncensored_model() -> OllamaModel:
    """Create Hudson/llama3.1-uncensored:8b model configuration"""
    return OllamaModel(
        name="hudson/llama3.1-uncensored",
        model_family=ModelFamily.LLAMA,
        size=ModelSize.MEDIUM,
        quantization="8b",
        parameter_count="8B",
        context_length=8192,  # Llama 3.1 has extended context
        supports_chat=True,
        supports_completion=True,
        supports_code=True,
        supports_hebrew=True,
        memory_required_gb=8.0,
        inference_speed="fast",
        description="Llama 3.1 8B Uncensored model by Hudson",
        description_hebrew="מודל Llama 3.1 8B ללא צנזורה של Hudson",
        license="Custom",
        architecture="Transformer"
    )

def create_default_ollama_config() -> OllamaConfig:
    """Create default Ollama configuration"""
    return OllamaConfig(
        host="localhost",
        port=11434,
        timeout=300,
        default_temperature=0.7,
        default_max_tokens=2048,
        num_thread=8,
        enable_caching=True
    )

def create_chat_session(model_name: str, system_prompt: str = "") -> ChatSession:
    """Create new chat session"""
    session_id = f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    history = ChatHistory(session_id=session_id, system_prompt=system_prompt)
    
    return ChatSession(
        session_id=session_id,
        model_name=model_name,
        history=history,
        system_prompt=system_prompt
    )