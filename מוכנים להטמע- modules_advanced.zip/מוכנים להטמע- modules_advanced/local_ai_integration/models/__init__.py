"""
Local AI Integration Models Package
חבילת מודלי אינטגרציית בינה מלאכותית מקומית

Complete integration with local AI models for 100% privacy.
אינטגרציה מלאה עם מודלי בינה מלאכותית מקומיים לפרטיות 100%.
"""

from .local_models import (
    LocalAIModel, ModelType, ModelCapability,
    LlamaModel, LocalModelManager, ModelConfig,
    InferenceRequest, InferenceResult, ModelMetrics
)

from .ollama_integration import (
    OllamaClient, OllamaModel, OllamaConfig,
    ModelPull, ModelRun, ModelResponse,
    ChatSession, ChatMessage, ChatHistory
)

from .private_ai_types import (
    PrivateAIEngine, PrivateInference, LocalGeneration,
    PrivacyLevel, SecurityMode, OfflineCapability,
    LocalKnowledgeBase, PrivateMemory, SecureContext
)

__all__ = [
    # Local models
    'LocalAIModel', 'ModelType', 'ModelCapability',
    'LlamaModel', 'LocalModelManager', 'ModelConfig',
    'InferenceRequest', 'InferenceResult', 'ModelMetrics',
    
    # Ollama integration
    'OllamaClient', 'OllamaModel', 'OllamaConfig',
    'ModelPull', 'ModelRun', 'ModelResponse',
    'ChatSession', 'ChatMessage', 'ChatHistory',
    
    # Private AI types
    'PrivateAIEngine', 'PrivateInference', 'LocalGeneration',
    'PrivacyLevel', 'SecurityMode', 'OfflineCapability',
    'LocalKnowledgeBase', 'PrivateMemory', 'SecureContext'
]