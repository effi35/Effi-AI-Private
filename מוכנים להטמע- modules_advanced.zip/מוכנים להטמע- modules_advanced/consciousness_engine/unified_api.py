#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Unified Consciousness API with Local AI Integration
====================================================

API מאוחד למנוע התודעה עם אינטגרציית Hudson/Llama3.1 מקומי.
מספק ממשק פשוט וחכם לכל יכולות התודעה עם AI מתקדם.

תכונות מרכזיות:
- ממשק API מאוחד לכל מנועי התודעה
- אינטגרציה מלאה עם Hudson/Llama3.1 מקומי
- עיבוד עברית מתקדם עם AI
- ניתוח רגשי חכם
- יצירת תובנות מתקדמות
- תמיכה בתרבות ישראלית
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Union, Callable
import json

from .module import ConsciousnessEngineModule
from .models.config import ConsciousnessConfiguration, create_config_from_preset

logger = logging.getLogger(__name__)


class UnifiedConsciousnessAPI:
    """API מאוחד למנוע התודעה עם AI מקומי"""
    
    def __init__(self, config_preset: str = "standard"):
        """אתחול API המאוחד"""
        self.api_version = "2.0.0"
        self.consciousness_engine: Optional[ConsciousnessEngineModule] = None
        self.config_preset = config_preset
        self.is_initialized = False
        
        # מטמון תגובות
        self.response_cache = {}
        self.cache_max_size = 100
        
        # סטטיסטיקות API
        self.api_stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'ai_enhanced_requests': 0,
            'hebrew_requests': 0,
            'start_time': datetime.now()
        }
        
        logger.info("API מאוחד למנוע התודעה אותחל")
    
    async def initialize(self) -> bool:
        """אתחול API והמנוע"""
        try:
            if self.is_initialized:
                return True
            
            logger.info("מאתחל API מאוחד למנוע התודעה...")
            
            # יצירת מנוע התודעה
            self.consciousness_engine = ConsciousnessEngineModule(
                config_preset=self.config_preset
            )
            
            # אתחול המנוע
            if not await self.consciousness_engine.initialize():
                logger.error("נכשל אתחול מנוע התודעה")
                return False
            
            self.is_initialized = True
            logger.info("API מאוחד למנוע התודעה אותחל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול API: {e}")
            return False
    
    async def process_input(self, 
                           input_text: str, 
                           context: Dict[str, Any] = None,
                           use_ai_enhancement: bool = True,
                           response_type: str = "full") -> Dict[str, Any]:
        """
        עיבוד קלט עם תודעה ו-AI מקומי
        
        Args:
            input_text: הטקסט לעיבוד
            context: הקשר נוסף
            use_ai_enhancement: האם להשתמש בשיפור AI
            response_type: סוג התגובה - "full", "summary", "insights"
        """
        try:
            if not self.is_initialized:
                await self.initialize()
            
            if not self.consciousness_engine:
                return self._create_error_response("מנוע התודעה לא זמין")
            
            # עדכון סטטיסטיקות
            self.api_stats['total_requests'] += 1
            
            # זיהוי שפה
            is_hebrew = self._detect_hebrew(input_text)
            if is_hebrew:
                self.api_stats['hebrew_requests'] += 1
            
            # בחירת סוג עיבוד
            if use_ai_enhancement:
                results = await self.consciousness_engine.process_text_with_consciousness(
                    text=input_text,
                    context=context
                )
                self.api_stats['ai_enhanced_requests'] += 1
            else:
                # עיבוד בסיסי ללא AI
                results = {'basic_processing': True, 'text': input_text}
            
            # עיצוב התגובה לפי הסוג המבוקש
            formatted_response = self._format_response(results, response_type, is_hebrew)
            
            # עדכון מטמון
            self._update_cache(input_text, formatted_response)
            
            self.api_stats['successful_requests'] += 1
            return formatted_response
            
        except Exception as e:
            logger.error(f"שגיאה בעיבוד קלט: {e}")
            self.api_stats['failed_requests'] += 1
            return self._create_error_response(str(e))
    
    async def get_consciousness_insights(self, 
                                       include_ai_analysis: bool = True,
                                       depth: str = "standard") -> Dict[str, Any]:
        """
        קבלת תובנות תודעה מתקדמות
        
        Args:
            include_ai_analysis: כולל ניתוח AI
            depth: עומק הניתוח - "basic", "standard", "deep"
        """
        try:
            if not self.consciousness_engine:
                await self.initialize()
            
            # קבלת תובנות בסיסיות
            insights = await self.consciousness_engine.get_consciousness_insights()
            
            # הוספת ניתוח AI אם נדרש
            if include_ai_analysis and insights.get('ai_integration_status', {}).get('ai_module_initialized'):
                ai_insights = await self._generate_ai_insights(insights, depth)
                insights['ai_enhanced_insights'] = ai_insights
            
            # הוספת מטא-דאטה
            insights['api_metadata'] = {
                'api_version': self.api_version,
                'insight_depth': depth,
                'ai_analysis_included': include_ai_analysis,
                'generation_timestamp': datetime.now().isoformat(),
                'language_context': 'hebrew_israeli'
            }
            
            return insights
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת תובנות: {e}")
            return self._create_error_response(str(e))
    
    async def analyze_emotional_state(self, 
                                    input_text: str = None,
                                    analysis_depth: str = "standard") -> Dict[str, Any]:
        """
        ניתוח מצב רגשי מתקדם עם AI
        
        Args:
            input_text: טקסט לניתוח (אופציונלי)
            analysis_depth: עומק הניתוח - "basic", "standard", "deep"
        """
        try:
            if not self.consciousness_engine:
                await self.initialize()
            
            # ניתוח רגשי בסיסי
            emotional_analysis = await self.consciousness_engine.analyze_emotional_state(input_text)
            
            # שיפור עם AI אם זמין
            if self.consciousness_engine._is_ai_integration_active() and analysis_depth in ["standard", "deep"]:
                ai_emotional_insights = await self._get_ai_emotional_analysis(
                    emotional_analysis, 
                    input_text, 
                    analysis_depth
                )
                emotional_analysis['ai_emotional_insights'] = ai_emotional_insights
            
            # הוספת המלצות לפי עומק הניתוח
            if analysis_depth == "deep":
                recommendations = await self._generate_emotional_recommendations(emotional_analysis)
                emotional_analysis['emotional_recommendations'] = recommendations
            
            # מטא-דאטה
            emotional_analysis['analysis_metadata'] = {
                'analysis_depth': analysis_depth,
                'ai_enhanced': self.consciousness_engine._is_ai_integration_active(),
                'cultural_context': 'israeli',
                'timestamp': datetime.now().isoformat()
            }
            
            return emotional_analysis
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח רגשי: {e}")
            return self._create_error_response(str(e))
    
    async def generate_response(self, 
                              context: Dict[str, Any] = None,
                              response_style: str = "balanced",
                              include_reasoning: bool = True) -> Dict[str, Any]:
        """
        יצירת תגובה מהתודעה
        
        Args:
            context: הקשר לתגובה
            response_style: סגנון התגובה - "analytical", "creative", "balanced", "emotional"
            include_reasoning: כולל הסבר הנמקה
        """
        try:
            if not self.consciousness_engine:
                await self.initialize()
            
            # התאמת הקשר לסגנון התגובה
            enhanced_context = self._enhance_context_for_style(context, response_style)
            
            # יצירת תגובה
            response = await self.consciousness_engine.generate_consciousness_response(enhanced_context)
            
            # הוספת נמקה אם נדרש
            if include_reasoning and self.consciousness_engine._is_ai_integration_active():
                reasoning = await self._generate_response_reasoning(response, response_style)
                response['reasoning'] = reasoning
            
            # התאמה תרבותית
            response['cultural_adaptation'] = self._apply_cultural_adaptation(response)
            
            # מטא-דאטה
            response['response_metadata'] = {
                'style': response_style,
                'includes_reasoning': include_reasoning,
                'ai_enhanced': self.consciousness_engine._is_ai_integration_active(),
                'cultural_context': 'israeli_hebrew',
                'generation_timestamp': datetime.now().isoformat()
            }
            
            return response
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת תגובה: {e}")
            return self._create_error_response(str(e))
    
    async def test_system(self) -> Dict[str, Any]:
        """בדיקת תקינות המערכת"""
        try:
            test_results = {
                'api_status': 'active' if self.is_initialized else 'inactive',
                'consciousness_engine_status': 'unknown',
                'ai_integration_status': 'unknown',
                'test_timestamp': datetime.now().isoformat()
            }
            
            if self.consciousness_engine:
                # בדיקת מנוע התודעה
                engine_info = self.consciousness_engine.get_module_info()
                test_results['consciousness_engine_status'] = 'active' if engine_info['status']['running'] else 'inactive'
                
                # בדיקת אינטגרציית AI
                ai_test = await self.consciousness_engine.test_ai_integration()
                test_results['ai_integration_status'] = 'active' if ai_test['success'] else 'inactive'
                test_results['ai_test_details'] = ai_test
                
                # בדיקת עיבוד עברית
                hebrew_test = await self.process_input(
                    "שלום, זו בדיקה של המערכת",
                    response_type="summary"
                )
                test_results['hebrew_processing_test'] = {
                    'success': 'error' not in hebrew_test,
                    'details': hebrew_test
                }
            
            test_results['overall_status'] = (
                'healthy' if all([
                    test_results['api_status'] == 'active',
                    test_results['consciousness_engine_status'] == 'active',
                    test_results['ai_integration_status'] == 'active'
                ]) else 'degraded'
            )
            
            return test_results
            
        except Exception as e:
            logger.error(f"שגיאה בבדיקת מערכת: {e}")
            return self._create_error_response(str(e))
    
    def get_api_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות API"""
        try:
            uptime = (datetime.now() - self.api_stats['start_time']).total_seconds()
            
            stats = self.api_stats.copy()
            stats['uptime_seconds'] = uptime
            stats['success_rate'] = (
                (stats['successful_requests'] / max(1, stats['total_requests'])) * 100
            )
            stats['ai_enhancement_rate'] = (
                (stats['ai_enhanced_requests'] / max(1, stats['total_requests'])) * 100
            )
            stats['hebrew_usage_rate'] = (
                (stats['hebrew_requests'] / max(1, stats['total_requests'])) * 100
            )
            
            # הוספת סטטיסטיקות מנוע התודעה
            if self.consciousness_engine:
                engine_stats = self.consciousness_engine.get_performance_stats()
                stats['consciousness_engine_stats'] = engine_stats
            
            return stats
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    # פונקציות עזר פרטיות
    
    def _detect_hebrew(self, text: str) -> bool:
        """זיהוי טקסט עברי"""
        try:
            import re
            hebrew_chars = len(re.findall(r'[א-ת]', text))
            total_chars = len(re.findall(r'[א-תa-zA-Z]', text))
            return (hebrew_chars / max(1, total_chars)) > 0.3
        except:
            return False
    
    def _format_response(self, results: Dict[str, Any], response_type: str, is_hebrew: bool) -> Dict[str, Any]:
        """עיצוב התגובה לפי הסוג המבוקש"""
        try:
            if response_type == "summary":
                return {
                    'summary': self._create_summary(results),
                    'confidence': results.get('integrated_response', {}).get('confidence', 0.5),
                    'language': 'hebrew' if is_hebrew else 'english',
                    'ai_enhanced': 'ai_insights' in results
                }
            
            elif response_type == "insights":
                return {
                    'insights': results.get('insights', {}),
                    'ai_insights': results.get('ai_insights', {}),
                    'consciousness_state': results.get('individual_results', {}).get('state', {}),
                    'language': 'hebrew' if is_hebrew else 'english'
                }
            
            else:  # "full"
                return results
            
        except Exception as e:
            logger.error(f"שגיאה בעיצוב תגובה: {e}")
            return results
    
    def _create_summary(self, results: Dict[str, Any]) -> str:
        """יצירת סיכום מתוצאות העיבוד"""
        try:
            summary_parts = []
            
            # סיכום מחשבות
            thoughts = results.get('individual_results', {}).get('thoughts', {})
            if thoughts.get('thought_ids'):
                summary_parts.append(f"עובדו {len(thoughts['thought_ids'])} מחשבות")
            
            # סיכום רגשות
            emotions = results.get('individual_results', {}).get('emotions', {})
            if emotions.get('emotions_detected'):
                summary_parts.append(f"זוהו {len(emotions['emotions_detected'])} רגשות")
            
            # סיכום AI
            if 'ai_insights' in results:
                summary_parts.append("בוצע ניתוח AI מתקדם")
            
            return "עיבוד הושלם: " + ", ".join(summary_parts) if summary_parts else "עיבוד בסיסי הושלם"
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת סיכום: {e}")
            return "עיבוד הושלם"
    
    async def _generate_ai_insights(self, insights: Dict[str, Any], depth: str) -> Dict[str, Any]:
        """יצירת תובנות AI מתקדמות"""
        try:
            if not self.consciousness_engine or not self.consciousness_engine.consciousness_core:
                return {}
            
            consciousness_core = self.consciousness_engine.consciousness_core
            
            if not consciousness_core.local_ai or not consciousness_core.ai_session_id:
                return {}
            
            # יצירת פרומפט לפי עומק הניתוח
            if depth == "deep":
                prompt = f"""
                נתח בעומק את המצב הנוכחי של התודעה ויצור תובנות מתקדמות:
                
                מצב תודעה: {insights.get('consciousness_state', {})}
                מצב רגשי: {insights.get('emotional_insights', {})}
                ביצועים: {insights.get('performance_metrics', {})}
                
                ספק:
                1. ניתוח מעמיק של הדפוסים
                2. זיהוי מגמות והתפתחויות
                3. תחזיות לתקופה הקרובה
                4. המלצות לשיפור וטיוב
                """
            else:
                prompt = f"""
                נתח את מצב התודעה הנוכחי:
                {json.dumps(insights, ensure_ascii=False, indent=2)[:500]}...
                
                ספק תובנות קצרות ומעשיות על המצב.
                """
            
            ai_response = await consciousness_core.local_ai.send_message(
                consciousness_core.ai_session_id,
                prompt,
                temperature=0.7
            )
            
            return {
                'ai_analysis': ai_response,
                'analysis_depth': depth,
                'generation_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת תובנות AI: {e}")
            return {}
    
    async def _get_ai_emotional_analysis(self, emotional_data: Dict[str, Any], 
                                       input_text: str, depth: str) -> Dict[str, Any]:
        """ניתוח רגשי AI מתקדם"""
        try:
            if not self.consciousness_engine or not self.consciousness_engine.consciousness_core:
                return {}
            
            consciousness_core = self.consciousness_engine.consciousness_core
            
            if not consciousness_core.local_ai:
                return {}
            
            # יצירת ניתוח רגשי מתקדם
            analysis_prompt = f"""
            בצע ניתוח רגשי מתקדם:
            
            טקסט קלט: {input_text or 'ללא טקסט ספציפי'}
            מצב רגשי נוכחי: {emotional_data.get('current_emotional_state', {})}
            
            ספק ניתוח שכולל:
            1. זיהוי רגשות סמויים
            2. דפוסים רגשיים
            3. השפעות אפשריות
            4. המלצות להתמודדות
            """
            
            ai_emotional_analysis = await consciousness_core.local_ai.analyze_text(
                analysis_prompt,
                analysis_type="sentiment"
            )
            
            return ai_emotional_analysis
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח רגשי AI: {e}")
            return {}
    
    async def _generate_emotional_recommendations(self, emotional_analysis: Dict[str, Any]) -> List[str]:
        """יצירת המלצות רגשיות"""
        try:
            recommendations = []
            
            current_state = emotional_analysis.get('current_emotional_state', {})
            dominant_emotion = current_state.get('dominant_emotion')
            
            # המלצות בסיסיות לפי רגש דומיננטי
            emotion_recommendations = {
                'joy': ['המשך לטפח רגשות חיוביים', 'שתף את השמחה עם אחרים'],
                'sadness': ['אפשר לעצמך לחוות את הרגש', 'חפש תמיכה אם נדרש'],
                'anger': ['קח נשימה עמוקה', 'בחן את מקור הכעס'],
                'fear': ['זהה את מקור הפחד', 'התמודד בהדרגה'],
                'surprise': ['קח זמן לעכל את המידע החדש'],
                'disgust': ['הבן מה מעורר את התחושה', 'שמור על גבולות בריאים']
            }
            
            if dominant_emotion and dominant_emotion in emotion_recommendations:
                recommendations.extend(emotion_recommendations[dominant_emotion])
            
            # המלצות לפי יציבות רגשית
            stability = current_state.get('emotional_stability', 0.5)
            if stability < 0.4:
                recommendations.append('התמקד בפעילויות מרגיעות ומייצבות')
            elif stability > 0.8:
                recommendations.append('נסה לנצל את היציבות הרגשית לפעילויות חדשות')
            
            return recommendations[:5]  # מקסימום 5 המלצות
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת המלצות רגשיות: {e}")
            return []
    
    def _enhance_context_for_style(self, context: Dict[str, Any], style: str) -> Dict[str, Any]:
        """שיפור הקשר לפי סגנון התגובה"""
        enhanced_context = context.copy() if context else {}
        
        style_enhancements = {
            'analytical': {'focus': 'logic', 'depth': 'detailed'},
            'creative': {'focus': 'innovation', 'depth': 'imaginative'},
            'balanced': {'focus': 'comprehensive', 'depth': 'moderate'},
            'emotional': {'focus': 'feelings', 'depth': 'empathetic'}
        }
        
        if style in style_enhancements:
            enhanced_context.update(style_enhancements[style])
        
        enhanced_context['response_style'] = style
        enhanced_context['cultural_context'] = 'israeli'
        
        return enhanced_context
    
    async def _generate_response_reasoning(self, response: Dict[str, Any], style: str) -> Dict[str, Any]:
        """יצירת הסבר נמקה לתגובה"""
        try:
            if not self.consciousness_engine or not self.consciousness_engine.consciousness_core:
                return {}
            
            consciousness_core = self.consciousness_engine.consciousness_core
            
            if not consciousness_core.local_ai or not consciousness_core.ai_session_id:
                return {}
            
            reasoning_prompt = f"""
            הסבר את הנמקה מאחורי התגובה שנוצרה:
            
            סגנון התגובה: {style}
            תוכן התגובה: {str(response)[:300]}...
            
            ספק הסבר קצר ומובן על:
            1. מדוע נבחר תוכן זה
            2. איך הסגנון השפיע על התגובה
            3. אילו שיקולים הוביל להחלטות
            """
            
            reasoning_response = await consciousness_core.local_ai.send_message(
                consciousness_core.ai_session_id,
                reasoning_prompt,
                temperature=0.5
            )
            
            return {
                'explanation': reasoning_response,
                'style_influence': style,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת נמקה: {e}")
            return {}
    
    def _apply_cultural_adaptation(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """התאמה תרבותית לתגובה"""
        adaptation = {
            'cultural_context': 'israeli',
            'language_style': 'hebrew_mixed',
            'communication_style': 'direct_warm',
            'cultural_elements': []
        }
        
        # זיהוי אלמנטים תרבותיים ברגש
        emotional_state = response.get('emotional_state', {})
        if emotional_state.get('dominant_emotion') == 'joy':
            adaptation['cultural_elements'].append('israeli_celebration')
        
        # התאמת סגנון תקשורת
        consciousness_state = response.get('consciousness_state', {})
        if consciousness_state.get('cognitive_mode') == 'analytical':
            adaptation['communication_style'] = 'sabra_direct'
        
        return adaptation
    
    def _create_error_response(self, error_message: str) -> Dict[str, Any]:
        """יצירת תגובת שגיאה סטנדרטית"""
        return {
            'error': error_message,
            'timestamp': datetime.now().isoformat(),
            'api_version': self.api_version,
            'success': False
        }
    
    def _update_cache(self, input_text: str, response: Dict[str, Any]):
        """עדכון מטמון תגובות"""
        try:
            if len(self.response_cache) >= self.cache_max_size:
                # הסרת הרשומה הישנה ביותר
                oldest_key = next(iter(self.response_cache))
                del self.response_cache[oldest_key]
            
            cache_key = hash(input_text[:100])  # מקסימום 100 תווים למפתח
            self.response_cache[cache_key] = {
                'response': response,
                'timestamp': datetime.now(),
                'input_preview': input_text[:50]
            }
            
        except Exception as e:
            logger.error(f"שגיאה בעדכון מטמון: {e}")


# פונקציות API חיצוניות מפושטות

# יצירת instance גלובלי
_global_api: Optional[UnifiedConsciousnessAPI] = None

async def initialize_consciousness_api(config_preset: str = "standard") -> bool:
    """אתחול API גלובלי"""
    global _global_api
    try:
        _global_api = UnifiedConsciousnessAPI(config_preset=config_preset)
        return await _global_api.initialize()
    except Exception as e:
        logger.error(f"שגיאה באתחול API גלובלי: {e}")
        return False

async def process_consciousness_text(text: str, 
                                   context: Dict[str, Any] = None,
                                   response_type: str = "full") -> Dict[str, Any]:
    """עיבוד טקסט עם תודעה (API פשוט)"""
    global _global_api
    if not _global_api:
        await initialize_consciousness_api()
    
    if _global_api:
        return await _global_api.process_input(text, context, response_type=response_type)
    else:
        return {'error': 'API לא זמין'}

async def get_consciousness_insights_simple(depth: str = "standard") -> Dict[str, Any]:
    """קבלת תובנות תודעה (API פשוט)"""
    global _global_api
    if not _global_api:
        await initialize_consciousness_api()
    
    if _global_api:
        return await _global_api.get_consciousness_insights(depth=depth)
    else:
        return {'error': 'API לא זמין'}

async def analyze_emotions_simple(text: str = None) -> Dict[str, Any]:
    """ניתוח רגשי פשוט"""
    global _global_api
    if not _global_api:
        await initialize_consciousness_api()
    
    if _global_api:
        return await _global_api.analyze_emotional_state(text)
    else:
        return {'error': 'API לא זמין'}

# יצוא פונקציות
__all__ = [
    'UnifiedConsciousnessAPI',
    'initialize_consciousness_api',
    'process_consciousness_text',
    'get_consciousness_insights_simple',
    'analyze_emotions_simple'
]