"""
Visualization and Chart Generation Utilities
"""

import json
import math
from typing import Dict, List, Any, Tuple, Optional, Union
from enum import Enum
from dataclasses import dataclass
from datetime import datetime, timedelta

class ChartType(Enum):
    """Chart types supported"""
    LINE = "line"
    BAR = "bar"
    PIE = "pie"
    RADAR = "radar"
    SCATTER = "scatter"
    HEATMAP = "heatmap"
    TIMELINE = "timeline"
    NETWORK = "network"

class ColorScheme(Enum):
    """Color schemes for charts"""
    CONSCIOUSNESS = "consciousness"
    EMOTION = "emotion"
    MEMORY = "memory"
    THOUGHT = "thought"
    DARK = "dark"
    LIGHT = "light"
    HEBREW = "hebrew"

@dataclass
class ChartData:
    """Chart data structure"""
    labels: List[str]
    datasets: List[Dict[str, Any]]
    title: str = ""
    subtitle: str = ""
    xAxisLabel: str = ""
    yAxisLabel: str = ""

@dataclass
class ChartOptions:
    """Chart configuration options"""
    width: int = 400
    height: int = 300
    color_scheme: ColorScheme = ColorScheme.CONSCIOUSNESS
    animation_duration: int = 300
    responsive: bool = True
    rtl_support: bool = True
    hebrew_labels: bool = True
    show_legend: bool = True
    show_grid: bool = True
    interactive: bool = True

class ColorPalette:
    """Color palette management for consciousness visualizations"""
    
    def __init__(self):
        self.palettes = {
            ColorScheme.CONSCIOUSNESS: {
                'primary': '#667eea',
                'secondary': '#764ba2',
                'accent': '#f093fb',
                'background': '#ffffff',
                'text': '#333333',
                'grid': '#e0e0e0',
                'gradient': ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#00f2fe']
            },
            ColorScheme.EMOTION: {
                'primary': '#FF6B6B',
                'secondary': '#4ECDC4',
                'accent': '#45B7D1',
                'background': '#ffffff',
                'text': '#2c3e50',
                'grid': '#ecf0f1',
                'gradient': ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']
            },
            ColorScheme.MEMORY: {
                'primary': '#9B59B6',
                'secondary': '#3498DB',
                'accent': '#E74C3C',
                'background': '#ffffff',
                'text': '#34495e',
                'grid': '#bdc3c7',
                'gradient': ['#9B59B6', '#8E44AD', '#3498DB', '#2980B9', '#E74C3C']
            },
            ColorScheme.THOUGHT: {
                'primary': '#F39C12',
                'secondary': '#E67E22',
                'accent': '#D35400',
                'background': '#ffffff',
                'text': '#2c3e50',
                'grid': '#ecf0f1',
                'gradient': ['#F39C12', '#E67E22', '#D35400', '#F1C40F', '#FF9800']
            },
            ColorScheme.DARK: {
                'primary': '#00d4ff',
                'secondary': '#1e3c72',
                'accent': '#2a5298',
                'background': '#1a1a1a',
                'text': '#ffffff',
                'grid': '#333333',
                'gradient': ['#00d4ff', '#1e3c72', '#2a5298', '#0f2027', '#203a43']
            },
            ColorScheme.LIGHT: {
                'primary': '#667eea',
                'secondary': '#764ba2',
                'accent': '#f093fb',
                'background': '#f8f9fa',
                'text': '#212529',
                'grid': '#dee2e6',
                'gradient': ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#00f2fe']
            },
            ColorScheme.HEBREW: {
                'primary': '#1976D2',
                'secondary': '#2196F3',
                'accent': '#03DAC6',
                'background': '#FAFAFA',
                'text': '#212121',
                'grid': '#E0E0E0',
                'gradient': ['#1976D2', '#2196F3', '#03DAC6', '#4CAF50', '#FF9800']
            }
        }
        
        # Emotion-specific colors
        self.emotion_colors = {
            'שמחה': '#FFD700',      # Gold
            'עצב': '#4169E1',       # Royal Blue
            'כעס': '#DC143C',       # Crimson
            'פחד': '#800080',       # Purple
            'גאווה': '#FF4500',     # Orange Red
            'בושה': '#8B4513',      # Saddle Brown
            'אהבה': '#FF1493',      # Deep Pink
            'שנאה': '#8B0000',      # Dark Red
            'התלהבות': '#FF6347',   # Tomato
            'רוגע': '#20B2AA',      # Light Sea Green
            'סקרנות': '#9370DB',    # Medium Purple
            'אכזבה': '#708090',     # Slate Gray
            'תקווה': '#32CD32',     # Lime Green
            'ייאוש': '#2F4F4F',     # Dark Slate Gray
            'הכרת תודה': '#DAA520'  # Goldenrod
        }
        
        # Memory layer colors
        self.memory_layer_colors = {
            1: '#E3F2FD',  # Working Memory - Light Blue
            2: '#BBDEFB',  # Short-term - Blue
            3: '#90CAF9',  # Episodic - Medium Blue
            4: '#64B5F6',  # Semantic - Darker Blue
            5: '#42A5F5'   # Procedural - Deep Blue
        }
        
        # Consciousness level colors
        self.consciousness_level_colors = {
            0: '#BDBDBD',  # Unconscious - Gray
            1: '#9E9E9E',  # Subconscious - Dark Gray
            2: '#757575',  # Preconscious - Darker Gray
            3: '#4CAF50',  # Conscious - Green
            4: '#2196F3',  # Hyperconscious - Blue
            5: '#9C27B0',  # Transcendent - Purple
            6: '#E91E63'   # Ultimate - Pink
        }
    
    def get_palette(self, scheme: ColorScheme) -> Dict[str, str]:
        """Get color palette for scheme"""
        return self.palettes.get(scheme, self.palettes[ColorScheme.CONSCIOUSNESS])
    
    def get_emotion_color(self, emotion: str) -> str:
        """Get color for specific emotion"""
        return self.emotion_colors.get(emotion, '#667eea')
    
    def get_memory_layer_color(self, layer: int) -> str:
        """Get color for memory layer"""
        return self.memory_layer_colors.get(layer, '#667eea')
    
    def get_consciousness_level_color(self, level: int) -> str:
        """Get color for consciousness level"""
        return self.consciousness_level_colors.get(level, '#667eea')
    
    def get_gradient_colors(self, scheme: ColorScheme, count: int) -> List[str]:
        """Get gradient colors for scheme"""
        palette = self.get_palette(scheme)
        gradient = palette['gradient']
        
        if count <= len(gradient):
            return gradient[:count]
        
        # Interpolate colors if more needed
        return self._interpolate_colors(gradient, count)
    
    def _interpolate_colors(self, colors: List[str], count: int) -> List[str]:
        """Interpolate between colors to get desired count"""
        if count <= len(colors):
            return colors[:count]
        
        result = []
        step = (len(colors) - 1) / (count - 1)
        
        for i in range(count):
            position = i * step
            lower_idx = int(position)
            upper_idx = min(lower_idx + 1, len(colors) - 1)
            
            if lower_idx == upper_idx:
                result.append(colors[lower_idx])
            else:
                # Simple interpolation (could be improved with HSL)
                result.append(colors[lower_idx])
        
        return result

class ChartGenerator:
    """Chart generation utilities for consciousness data"""
    
    def __init__(self, color_palette: Optional[ColorPalette] = None):
        self.color_palette = color_palette or ColorPalette()
        
        # Hebrew labels
        self.hebrew_labels = {
            'emotions': 'רגשות',
            'memory': 'זיכרון',
            'thoughts': 'מחשבות',
            'consciousness': 'תודעה',
            'time': 'זמן',
            'intensity': 'עוצמה',
            'frequency': 'תדירות',
            'level': 'רמה',
            'layer': 'שכבה',
            'type': 'סוג',
            'count': 'כמות',
            'efficiency': 'יעילות',
            'stability': 'יציבות',
            'complexity': 'מורכבות'
        }
    
    def create_emotion_pie_chart(self, emotion_data: List[Dict[str, Any]], 
                                options: Optional[ChartOptions] = None) -> str:
        """Create pie chart for emotion distribution"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.EMOTION)
        
        # Process emotion data
        emotion_counts = {}
        for emotion in emotion_data:
            emotion_type = emotion.get('type', 'לא ידוע')
            emotion_counts[emotion_type] = emotion_counts.get(emotion_type, 0) + 1
        
        # Prepare chart data
        labels = list(emotion_counts.keys())
        values = list(emotion_counts.values())
        colors = [self.color_palette.get_emotion_color(label) for label in labels]
        
        chart_data = ChartData(
            labels=labels,
            datasets=[{
                'data': values,
                'backgroundColor': colors,
                'borderColor': '#ffffff',
                'borderWidth': 2
            }],
            title=self.hebrew_labels['emotions'] if options.hebrew_labels else 'Emotions'
        )
        
        return self._generate_chart_config(ChartType.PIE, chart_data, options)
    
    def create_memory_layer_chart(self, memory_data: List[Dict[str, Any]], 
                                 options: Optional[ChartOptions] = None) -> str:
        """Create bar chart for memory layer distribution"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.MEMORY)
        
        # Count memories per layer
        layer_counts = {}
        for memory in memory_data:
            layer = memory.get('layer', 1)
            layer_counts[layer] = layer_counts.get(layer, 0) + 1
        
        # Prepare chart data
        layers = sorted(layer_counts.keys())
        labels = [f"שכבה {layer}" if options.hebrew_labels else f"Layer {layer}" 
                 for layer in layers]
        values = [layer_counts[layer] for layer in layers]
        colors = [self.color_palette.get_memory_layer_color(layer) for layer in layers]
        
        chart_data = ChartData(
            labels=labels,
            datasets=[{
                'label': self.hebrew_labels['memory'] if options.hebrew_labels else 'Memory',
                'data': values,
                'backgroundColor': colors,
                'borderColor': colors,
                'borderWidth': 1
            }],
            title=f"{self.hebrew_labels['memory']} - {self.hebrew_labels['layer']}" 
                  if options.hebrew_labels else "Memory Layers",
            yAxisLabel=self.hebrew_labels['count'] if options.hebrew_labels else 'Count'
        )
        
        return self._generate_chart_config(ChartType.BAR, chart_data, options)
    
    def create_consciousness_timeline(self, state_data: List[Dict[str, Any]], 
                                    options: Optional[ChartOptions] = None) -> str:
        """Create timeline chart for consciousness levels"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.CONSCIOUSNESS)
        
        # Sort by timestamp
        sorted_states = sorted(state_data, 
                             key=lambda x: x.get('timestamp', ''))
        
        # Prepare timeline data
        timestamps = []
        levels = []
        
        for state in sorted_states:
            timestamp = state.get('timestamp', '')
            level = state.get('level', 0)
            
            if timestamp:
                try:
                    dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    timestamps.append(dt.strftime('%H:%M'))
                    levels.append(level)
                except:
                    continue
        
        # Colors based on levels
        colors = [self.color_palette.get_consciousness_level_color(level) 
                 for level in levels]
        
        chart_data = ChartData(
            labels=timestamps,
            datasets=[{
                'label': self.hebrew_labels['consciousness'] if options.hebrew_labels else 'Consciousness',
                'data': levels,
                'borderColor': self.color_palette.get_palette(options.color_scheme)['primary'],
                'backgroundColor': colors,
                'fill': False,
                'tension': 0.4
            }],
            title=f"{self.hebrew_labels['consciousness']} - {self.hebrew_labels['time']}" 
                  if options.hebrew_labels else "Consciousness Timeline",
            xAxisLabel=self.hebrew_labels['time'] if options.hebrew_labels else 'Time',
            yAxisLabel=self.hebrew_labels['level'] if options.hebrew_labels else 'Level'
        )
        
        return self._generate_chart_config(ChartType.LINE, chart_data, options)
    
    def create_thought_flow_chart(self, thought_data: List[Dict[str, Any]], 
                                 options: Optional[ChartOptions] = None) -> str:
        """Create flow chart for thought patterns"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.THOUGHT)
        
        # Group thoughts by type and calculate average cognitive load
        thought_types = {}
        for thought in thought_data:
            thought_type = thought.get('type', 'לא ידוע')
            cognitive_load = thought.get('cognitive_load', 0)
            
            if thought_type not in thought_types:
                thought_types[thought_type] = {'loads': [], 'count': 0}
            
            thought_types[thought_type]['loads'].append(cognitive_load)
            thought_types[thought_type]['count'] += 1
        
        # Calculate averages
        labels = []
        avg_loads = []
        counts = []
        
        for thought_type, data in thought_types.items():
            labels.append(thought_type)
            avg_loads.append(sum(data['loads']) / len(data['loads']))
            counts.append(data['count'])
        
        # Create bubble chart data (x=count, y=avg_load, size=count)
        bubble_data = []
        colors = self.color_palette.get_gradient_colors(options.color_scheme, len(labels))
        
        for i, label in enumerate(labels):
            bubble_data.append({
                'x': counts[i],
                'y': avg_loads[i],
                'r': math.sqrt(counts[i]) * 3,  # Bubble size
                'label': label,
                'backgroundColor': colors[i],
                'borderColor': colors[i]
            })
        
        chart_data = ChartData(
            labels=labels,
            datasets=[{
                'label': self.hebrew_labels['thoughts'] if options.hebrew_labels else 'Thoughts',
                'data': bubble_data
            }],
            title=f"{self.hebrew_labels['thoughts']} - זרימה" if options.hebrew_labels else "Thought Flow",
            xAxisLabel=self.hebrew_labels['frequency'] if options.hebrew_labels else 'Frequency',
            yAxisLabel='עומס קוגניטיבי ממוצע' if options.hebrew_labels else 'Avg Cognitive Load'
        )
        
        return self._generate_chart_config(ChartType.SCATTER, chart_data, options)
    
    def create_integration_radar_chart(self, metrics: Dict[str, float], 
                                     options: Optional[ChartOptions] = None) -> str:
        """Create radar chart for system integration metrics"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.CONSCIOUSNESS)
        
        # Hebrew metric labels
        metric_labels = {
            'emotion_stability': 'יציבות רגשית',
            'memory_efficiency': 'יעילות זיכרון',
            'thought_coherence': 'קוהרנטיות מחשבתית',
            'consciousness_level': 'רמת תודעה',
            'integration_score': 'ציון אינטגרציה',
            'overall_complexity': 'מורכבות כללית'
        }
        
        labels = []
        values = []
        
        for metric, value in metrics.items():
            label = metric_labels.get(metric, metric) if options.hebrew_labels else metric
            labels.append(label)
            values.append(value)
        
        palette = self.color_palette.get_palette(options.color_scheme)
        
        chart_data = ChartData(
            labels=labels,
            datasets=[{
                'label': 'מדדי מערכת' if options.hebrew_labels else 'System Metrics',
                'data': values,
                'backgroundColor': f"{palette['primary']}30",  # 30% opacity
                'borderColor': palette['primary'],
                'borderWidth': 2,
                'pointBackgroundColor': palette['accent']
            }],
            title='מדדי אינטגרציה' if options.hebrew_labels else 'Integration Metrics'
        )
        
        return self._generate_chart_config(ChartType.RADAR, chart_data, options)
    
    def create_pattern_heatmap(self, pattern_data: Dict[str, Dict[str, int]], 
                              options: Optional[ChartOptions] = None) -> str:
        """Create heatmap for pattern correlations"""
        if not options:
            options = ChartOptions(color_scheme=ColorScheme.CONSCIOUSNESS)
        
        # Convert pattern data to heatmap format
        categories = list(pattern_data.keys())
        
        heatmap_data = []
        for i, cat1 in enumerate(categories):
            row = []
            for j, cat2 in enumerate(categories):
                # Get correlation value or 0
                value = pattern_data.get(cat1, {}).get(cat2, 0)
                row.append(value)
            heatmap_data.append(row)
        
        chart_data = ChartData(
            labels=categories,
            datasets=[{
                'label': 'קורלציות דפוסים' if options.hebrew_labels else 'Pattern Correlations',
                'data': heatmap_data
            }],
            title='מפת דפוסים' if options.hebrew_labels else 'Pattern Heatmap'
        )
        
        return self._generate_chart_config(ChartType.HEATMAP, chart_data, options)
    
    def _generate_chart_config(self, chart_type: ChartType, 
                              chart_data: ChartData, 
                              options: ChartOptions) -> str:
        """Generate Chart.js configuration"""
        
        palette = self.color_palette.get_palette(options.color_scheme)
        
        # Base configuration
        config = {
            'type': chart_type.value,
            'data': {
                'labels': chart_data.labels,
                'datasets': chart_data.datasets
            },
            'options': {
                'responsive': options.responsive,
                'maintainAspectRatio': False,
                'animation': {
                    'duration': options.animation_duration
                },
                'plugins': {
                    'title': {
                        'display': bool(chart_data.title),
                        'text': chart_data.title,
                        'color': palette['text'],
                        'font': {
                            'size': 16,
                            'weight': 'bold'
                        }
                    },
                    'legend': {
                        'display': options.show_legend,
                        'labels': {
                            'color': palette['text'],
                            'usePointStyle': True
                        }
                    }
                }
            }
        }
        
        # RTL support
        if options.rtl_support:
            config['options']['locale'] = 'he-IL'
            config['options']['plugins']['legend']['rtl'] = True
        
        # Chart-specific configurations
        if chart_type in [ChartType.LINE, ChartType.BAR]:
            config['options']['scales'] = {
                'x': {
                    'display': True,
                    'title': {
                        'display': bool(chart_data.xAxisLabel),
                        'text': chart_data.xAxisLabel,
                        'color': palette['text']
                    },
                    'grid': {
                        'display': options.show_grid,
                        'color': palette['grid']
                    },
                    'ticks': {
                        'color': palette['text']
                    }
                },
                'y': {
                    'display': True,
                    'title': {
                        'display': bool(chart_data.yAxisLabel),
                        'text': chart_data.yAxisLabel,
                        'color': palette['text']
                    },
                    'grid': {
                        'display': options.show_grid,
                        'color': palette['grid']
                    },
                    'ticks': {
                        'color': palette['text']
                    }
                }
            }
        
        elif chart_type == ChartType.RADAR:
            config['options']['scales'] = {
                'r': {
                    'beginAtZero': True,
                    'max': 1,
                    'grid': {
                        'color': palette['grid']
                    },
                    'pointLabels': {
                        'color': palette['text']
                    },
                    'ticks': {
                        'color': palette['text']
                    }
                }
            }
        
        # Interactive features
        if options.interactive:
            config['options']['interaction'] = {
                'intersect': False,
                'mode': 'index'
            }
            config['options']['hover'] = {
                'animationDuration': 200
            }
        
        return json.dumps(config, ensure_ascii=False, indent=2)
    
    def create_custom_visualization(self, data: Any, 
                                  visualization_type: str,
                                  options: Optional[ChartOptions] = None) -> str:
        """Create custom visualization based on type"""
        
        if visualization_type == "emotion_wheel":
            return self._create_emotion_wheel(data, options)
        elif visualization_type == "memory_tree":
            return self._create_memory_tree(data, options)
        elif visualization_type == "consciousness_flow":
            return self._create_consciousness_flow(data, options)
        else:
            return "{}"
    
    def _create_emotion_wheel(self, emotion_data: List[Dict[str, Any]], 
                             options: Optional[ChartOptions] = None) -> str:
        """Create emotion wheel visualization"""
        # Custom SVG-based emotion wheel
        if not options:
            options = ChartOptions()
        
        emotions = {}
        for emotion in emotion_data:
            emotion_type = emotion.get('type', 'unknown')
            intensity = emotion.get('intensity', 0)
            emotions[emotion_type] = max(emotions.get(emotion_type, 0), intensity)
        
        # Generate SVG configuration
        svg_config = {
            'type': 'emotion_wheel',
            'data': emotions,
            'colors': {emotion: self.color_palette.get_emotion_color(emotion) 
                      for emotion in emotions.keys()},
            'options': {
                'radius': 100,
                'centerX': options.width // 2,
                'centerY': options.height // 2,
                'rtl': options.rtl_support
            }
        }
        
        return json.dumps(svg_config, ensure_ascii=False, indent=2)
    
    def _create_memory_tree(self, memory_data: List[Dict[str, Any]], 
                           options: Optional[ChartOptions] = None) -> str:
        """Create memory tree visualization"""
        # Tree structure for memory layers
        tree_data = {
            'name': 'זיכרון' if options and options.hebrew_labels else 'Memory',
            'children': []
        }
        
        # Group by layers
        layers = {}
        for memory in memory_data:
            layer = memory.get('layer', 1)
            if layer not in layers:
                layers[layer] = []
            layers[layer].append(memory)
        
        # Build tree structure
        for layer in sorted(layers.keys()):
            layer_node = {
                'name': f'שכבה {layer}' if options and options.hebrew_labels else f'Layer {layer}',
                'value': len(layers[layer]),
                'color': self.color_palette.get_memory_layer_color(layer),
                'children': []
            }
            
            # Group by type within layer
            types = {}
            for memory in layers[layer]:
                mem_type = memory.get('type', 'unknown')
                if mem_type not in types:
                    types[mem_type] = 0
                types[mem_type] += 1
            
            for mem_type, count in types.items():
                layer_node['children'].append({
                    'name': mem_type,
                    'value': count
                })
            
            tree_data['children'].append(layer_node)
        
        return json.dumps(tree_data, ensure_ascii=False, indent=2)
    
    def _create_consciousness_flow(self, flow_data: List[Dict[str, Any]], 
                                  options: Optional[ChartOptions] = None) -> str:
        """Create consciousness flow visualization"""
        # Flow diagram for consciousness states
        nodes = []
        links = []
        
        # Create nodes for each consciousness level
        levels = [0, 1, 2, 3, 4, 5, 6]
        level_names = [
            'לא מודע', 'תת מודע', 'טרום מודע', 'מודע', 
            'על מודע', 'היפר מודע', 'טרנסצנדנטי'
        ] if options and options.hebrew_labels else [
            'Unconscious', 'Subconscious', 'Preconscious', 'Conscious',
            'Hyperconscious', 'Transcendent', 'Ultimate'
        ]
        
        for i, level in enumerate(levels):
            nodes.append({
                'id': str(level),
                'name': level_names[i] if i < len(level_names) else f'Level {level}',
                'value': len([d for d in flow_data if d.get('level') == level]),
                'color': self.color_palette.get_consciousness_level_color(level)
            })
        
        # Create links based on transitions
        transitions = {}
        for i in range(len(flow_data) - 1):
            current_level = flow_data[i].get('level', 0)
            next_level = flow_data[i + 1].get('level', 0)
            
            if current_level != next_level:
                transition = (current_level, next_level)
                transitions[transition] = transitions.get(transition, 0) + 1
        
        for (source, target), count in transitions.items():
            links.append({
                'source': str(source),
                'target': str(target),
                'value': count
            })
        
        flow_config = {
            'type': 'consciousness_flow',
            'nodes': nodes,
            'links': links,
            'options': {
                'width': options.width if options else 400,
                'height': options.height if options else 300
            }
        }
        
        return json.dumps(flow_config, ensure_ascii=False, indent=2)