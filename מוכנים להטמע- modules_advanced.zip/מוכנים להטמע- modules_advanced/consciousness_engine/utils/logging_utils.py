"""
Consciousness Engine Logging and Event Tracking Utilities
"""

import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
from enum import Enum
from dataclasses import dataclass, asdict
import threading
from collections import deque
import traceback

class LogLevel(Enum):
    """Consciousness-specific log levels"""
    TRACE = "trace"
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
    CONSCIOUSNESS = "consciousness"
    EMOTION = "emotion"
    MEMORY = "memory"
    THOUGHT = "thought"

class EventType(Enum):
    """Consciousness event types"""
    EMOTION_CHANGE = "emotion_change"
    MEMORY_FORMATION = "memory_formation"
    MEMORY_RETRIEVAL = "memory_retrieval"
    THOUGHT_GENERATED = "thought_generated"
    STATE_TRANSITION = "state_transition"
    LEARNING_EVENT = "learning_event"
    PATTERN_DETECTED = "pattern_detected"
    ANOMALY_DETECTED = "anomaly_detected"
    SYSTEM_EVENT = "system_event"
    USER_INTERACTION = "user_interaction"

@dataclass
class ConsciousnessEvent:
    """Consciousness system event"""
    timestamp: datetime
    event_type: EventType
    component: str
    data: Dict[str, Any]
    context: Optional[Dict[str, Any]] = None
    severity: str = "info"
    correlation_id: Optional[str] = None
    user_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'event_type': self.event_type.value,
            'component': self.component,
            'data': self.data,
            'context': self.context,
            'severity': self.severity,
            'correlation_id': self.correlation_id,
            'user_id': self.user_id
        }

class ConsciousnessLogger:
    """Advanced logging system for consciousness engine"""
    
    def __init__(self, 
                 log_dir: str = "logs/consciousness",
                 max_file_size: int = 10 * 1024 * 1024,  # 10MB
                 backup_count: int = 5,
                 enable_hebrew: bool = True):
        self.log_dir = log_dir
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        self.enable_hebrew = enable_hebrew
        
        # Create log directory
        os.makedirs(log_dir, exist_ok=True)
        
        # Setup loggers
        self._setup_loggers()
        
        # Event buffer for real-time monitoring
        self.event_buffer = deque(maxlen=1000)
        self.event_listeners: List[Callable] = []
        
        # Thread safety
        self._lock = threading.Lock()
        
    def _setup_loggers(self):
        """Setup different loggers for different components"""
        self.loggers = {}
        
        # Main consciousness logger
        self.loggers['main'] = self._create_logger(
            'consciousness_main',
            f"{self.log_dir}/consciousness_main.log"
        )
        
        # Component-specific loggers
        components = ['emotion', 'memory', 'thought', 'state', 'core']
        for component in components:
            self.loggers[component] = self._create_logger(
                f'consciousness_{component}',
                f"{self.log_dir}/consciousness_{component}.log"
            )
        
        # Error logger
        self.loggers['error'] = self._create_logger(
            'consciousness_error',
            f"{self.log_dir}/consciousness_error.log",
            level=logging.ERROR
        )
        
        # Performance logger
        self.loggers['performance'] = self._create_logger(
            'consciousness_performance',
            f"{self.log_dir}/consciousness_performance.log"
        )
    
    def _create_logger(self, name: str, filename: str, 
                      level: int = logging.INFO) -> logging.Logger:
        """Create a configured logger"""
        logger = logging.getLogger(name)
        logger.setLevel(level)
        
        # Remove existing handlers
        for handler in logger.handlers[:]:
            logger.removeHandler(handler)
        
        # File handler with rotation
        handler = logging.handlers.RotatingFileHandler(
            filename,
            maxBytes=self.max_file_size,
            backupCount=self.backup_count,
            encoding='utf-8'
        )
        
        # Custom formatter for Hebrew support
        if self.enable_hebrew:
            formatter = self._create_hebrew_formatter()
        else:
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # Console handler for errors
        if level >= logging.ERROR:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        
        return logger
    
    def _create_hebrew_formatter(self) -> logging.Formatter:
        """Create formatter that supports Hebrew text"""
        class HebrewFormatter(logging.Formatter):
            def format(self, record):
                # Ensure Hebrew text is properly handled
                if hasattr(record, 'hebrew_msg') and record.hebrew_msg:
                    record.msg = f"[עברית] {record.msg}"
                
                formatted = super().format(record)
                
                # Ensure proper RTL formatting
                if any('\u0590' <= c <= '\u05FF' for c in formatted):
                    formatted = f"\u200F{formatted}\u200F"  # RTL marks
                
                return formatted
        
        return HebrewFormatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    def log_consciousness_event(self, 
                              event_type: EventType,
                              component: str,
                              data: Dict[str, Any],
                              severity: str = "info",
                              context: Optional[Dict[str, Any]] = None,
                              correlation_id: Optional[str] = None,
                              user_id: Optional[str] = None):
        """Log consciousness-specific event"""
        
        event = ConsciousnessEvent(
            timestamp=datetime.now(),
            event_type=event_type,
            component=component,
            data=data,
            context=context,
            severity=severity,
            correlation_id=correlation_id,
            user_id=user_id
        )
        
        with self._lock:
            self.event_buffer.append(event)
        
        # Log to appropriate logger
        logger = self.loggers.get(component, self.loggers['main'])
        
        # Format message
        message = self._format_consciousness_message(event)
        
        # Log based on severity
        if severity == "critical":
            logger.critical(message)
        elif severity == "error":
            logger.error(message)
        elif severity == "warning":
            logger.warning(message)
        else:
            logger.info(message)
        
        # Notify listeners
        self._notify_listeners(event)
    
    def _format_consciousness_message(self, event: ConsciousnessEvent) -> str:
        """Format consciousness event message"""
        base_msg = f"[{event.component.upper()}] {event.event_type.value}"
        
        # Add key data points
        if event.data:
            key_points = []
            for key, value in event.data.items():
                if key in ['type', 'intensity', 'layer', 'level', 'content']:
                    if isinstance(value, str) and len(value) > 50:
                        value = value[:47] + "..."
                    key_points.append(f"{key}={value}")
            
            if key_points:
                base_msg += f" | {', '.join(key_points)}"
        
        # Add context if available
        if event.context:
            context_str = json.dumps(event.context, ensure_ascii=False)[:100]
            base_msg += f" | Context: {context_str}"
        
        return base_msg
    
    def log_emotion_event(self, emotion_type: str, intensity: float, 
                         context: Optional[Dict[str, Any]] = None):
        """Log emotion-specific event"""
        self.log_consciousness_event(
            event_type=EventType.EMOTION_CHANGE,
            component="emotion",
            data={
                "type": emotion_type,
                "intensity": intensity,
                "timestamp": datetime.now().isoformat()
            },
            context=context
        )
    
    def log_memory_event(self, action: str, memory_data: Dict[str, Any],
                        context: Optional[Dict[str, Any]] = None):
        """Log memory-specific event"""
        event_type = (EventType.MEMORY_FORMATION if action == "formation" 
                     else EventType.MEMORY_RETRIEVAL)
        
        self.log_consciousness_event(
            event_type=event_type,
            component="memory",
            data={
                "action": action,
                "layer": memory_data.get("layer"),
                "type": memory_data.get("type"),
                "content_length": len(memory_data.get("content", "")),
                "timestamp": datetime.now().isoformat()
            },
            context=context
        )
    
    def log_thought_event(self, thought_data: Dict[str, Any],
                         context: Optional[Dict[str, Any]] = None):
        """Log thought-specific event"""
        self.log_consciousness_event(
            event_type=EventType.THOUGHT_GENERATED,
            component="thought",
            data={
                "type": thought_data.get("type"),
                "cognitive_load": thought_data.get("cognitive_load"),
                "content_length": len(thought_data.get("content", "")),
                "timestamp": datetime.now().isoformat()
            },
            context=context
        )
    
    def log_state_transition(self, from_state: str, to_state: str,
                           context: Optional[Dict[str, Any]] = None):
        """Log consciousness state transition"""
        self.log_consciousness_event(
            event_type=EventType.STATE_TRANSITION,
            component="state",
            data={
                "from_state": from_state,
                "to_state": to_state,
                "transition_time": datetime.now().isoformat()
            },
            context=context
        )
    
    def log_performance_metric(self, metric_name: str, value: float,
                              component: str = "performance",
                              context: Optional[Dict[str, Any]] = None):
        """Log performance metric"""
        logger = self.loggers['performance']
        
        message = f"METRIC: {metric_name}={value}"
        if context:
            message += f" | Context: {json.dumps(context, ensure_ascii=False)}"
        
        logger.info(message)
    
    def log_error(self, error: Exception, component: str,
                 context: Optional[Dict[str, Any]] = None):
        """Log error with full context"""
        error_data = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "traceback": traceback.format_exc(),
            "timestamp": datetime.now().isoformat()
        }
        
        self.log_consciousness_event(
            event_type=EventType.SYSTEM_EVENT,
            component=component,
            data=error_data,
            severity="error",
            context=context
        )
    
    def log_hebrew_message(self, message: str, component: str = "main",
                          level: str = "info"):
        """Log Hebrew message with proper formatting"""
        logger = self.loggers.get(component, self.loggers['main'])
        
        # Create log record with Hebrew flag
        record = logging.LogRecord(
            name=logger.name,
            level=getattr(logging, level.upper()),
            pathname="",
            lineno=0,
            msg=message,
            args=(),
            exc_info=None
        )
        record.hebrew_msg = True
        
        logger.handle(record)
    
    def add_event_listener(self, callback: Callable[[ConsciousnessEvent], None]):
        """Add event listener for real-time monitoring"""
        with self._lock:
            self.event_listeners.append(callback)
    
    def remove_event_listener(self, callback: Callable[[ConsciousnessEvent], None]):
        """Remove event listener"""
        with self._lock:
            if callback in self.event_listeners:
                self.event_listeners.remove(callback)
    
    def _notify_listeners(self, event: ConsciousnessEvent):
        """Notify all event listeners"""
        for listener in self.event_listeners:
            try:
                listener(event)
            except Exception as e:
                # Log listener error but don't propagate
                self.loggers['error'].error(f"Event listener error: {e}")
    
    def get_recent_events(self, count: int = 100, 
                         event_type: Optional[EventType] = None,
                         component: Optional[str] = None) -> List[ConsciousnessEvent]:
        """Get recent events with optional filtering"""
        with self._lock:
            events = list(self.event_buffer)
        
        # Apply filters
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        if component:
            events = [e for e in events if e.component == component]
        
        # Sort by timestamp (most recent first) and limit
        events.sort(key=lambda e: e.timestamp, reverse=True)
        return events[:count]
    
    def export_logs(self, start_time: datetime, end_time: datetime,
                   output_file: str, format_type: str = "json") -> bool:
        """Export logs for a time period"""
        try:
            events = []
            
            # Filter events by time range
            with self._lock:
                for event in self.event_buffer:
                    if start_time <= event.timestamp <= end_time:
                        events.append(event)
            
            # Export based on format
            if format_type == "json":
                self._export_json(events, output_file)
            elif format_type == "csv":
                self._export_csv(events, output_file)
            else:
                return False
            
            return True
            
        except Exception as e:
            self.log_error(e, "logging")
            return False
    
    def _export_json(self, events: List[ConsciousnessEvent], filename: str):
        """Export events to JSON"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(
                [event.to_dict() for event in events],
                f,
                ensure_ascii=False,
                indent=2
            )
    
    def _export_csv(self, events: List[ConsciousnessEvent], filename: str):
        """Export events to CSV"""
        import csv
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow([
                'timestamp', 'event_type', 'component', 'severity',
                'data', 'context', 'correlation_id', 'user_id'
            ])
            
            # Data
            for event in events:
                writer.writerow([
                    event.timestamp.isoformat(),
                    event.event_type.value,
                    event.component,
                    event.severity,
                    json.dumps(event.data, ensure_ascii=False),
                    json.dumps(event.context, ensure_ascii=False) if event.context else '',
                    event.correlation_id or '',
                    event.user_id or ''
                ])

class EventTracker:
    """Event tracking and analytics system"""
    
    def __init__(self, logger: ConsciousnessLogger):
        self.logger = logger
        self.metrics = {}
        self.patterns = {}
        self._last_reset = datetime.now()
        
        # Register as event listener
        self.logger.add_event_listener(self._process_event)
    
    def _process_event(self, event: ConsciousnessEvent):
        """Process incoming event for tracking"""
        # Update metrics
        self._update_metrics(event)
        
        # Detect patterns
        self._detect_patterns(event)
        
        # Check for anomalies
        self._check_anomalies(event)
    
    def _update_metrics(self, event: ConsciousnessEvent):
        """Update event metrics"""
        # Component metrics
        component = event.component
        if component not in self.metrics:
            self.metrics[component] = {
                'event_count': 0,
                'last_event': None,
                'event_types': {},
                'severity_counts': {},
                'hourly_counts': {}
            }
        
        self.metrics[component]['event_count'] += 1
        self.metrics[component]['last_event'] = event.timestamp
        
        # Event type counts
        event_type = event.event_type.value
        if event_type not in self.metrics[component]['event_types']:
            self.metrics[component]['event_types'][event_type] = 0
        self.metrics[component]['event_types'][event_type] += 1
        
        # Severity counts
        severity = event.severity
        if severity not in self.metrics[component]['severity_counts']:
            self.metrics[component]['severity_counts'][severity] = 0
        self.metrics[component]['severity_counts'][severity] += 1
        
        # Hourly distribution
        hour = event.timestamp.hour
        if hour not in self.metrics[component]['hourly_counts']:
            self.metrics[component]['hourly_counts'][hour] = 0
        self.metrics[component]['hourly_counts'][hour] += 1
    
    def _detect_patterns(self, event: ConsciousnessEvent):
        """Detect patterns in events"""
        # Pattern detection logic would go here
        # For now, just track recent event sequences
        
        component = event.component
        if component not in self.patterns:
            self.patterns[component] = {
                'recent_sequence': deque(maxlen=10),
                'common_sequences': {},
                'transition_patterns': {}
            }
        
        # Add to recent sequence
        self.patterns[component]['recent_sequence'].append(event.event_type.value)
        
        # Check for repeated sequences
        sequence = list(self.patterns[component]['recent_sequence'])
        if len(sequence) >= 3:
            seq_key = tuple(sequence[-3:])  # Last 3 events
            if seq_key not in self.patterns[component]['common_sequences']:
                self.patterns[component]['common_sequences'][seq_key] = 0
            self.patterns[component]['common_sequences'][seq_key] += 1
    
    def _check_anomalies(self, event: ConsciousnessEvent):
        """Check for anomalous events"""
        component = event.component
        
        # Check for unusual frequency
        if component in self.metrics:
            recent_events = self.logger.get_recent_events(
                count=100, 
                component=component
            )
            
            # Time-based anomaly detection
            if len(recent_events) >= 10:
                recent_time = datetime.now() - timedelta(minutes=5)
                recent_count = len([e for e in recent_events if e.timestamp >= recent_time])
                
                # If more than 20 events in 5 minutes, it might be anomalous
                if recent_count > 20:
                    self.logger.log_consciousness_event(
                        event_type=EventType.ANOMALY_DETECTED,
                        component="tracker",
                        data={
                            "anomaly_type": "high_frequency",
                            "component": component,
                            "event_count": recent_count,
                            "time_window": "5_minutes"
                        },
                        severity="warning"
                    )
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of tracked metrics"""
        summary = {
            'total_events': sum(m['event_count'] for m in self.metrics.values()),
            'components': list(self.metrics.keys()),
            'tracking_duration': (datetime.now() - self._last_reset).total_seconds(),
            'component_metrics': self.metrics.copy()
        }
        
        return summary
    
    def get_pattern_analysis(self) -> Dict[str, Any]:
        """Get pattern analysis results"""
        analysis = {}
        
        for component, patterns in self.patterns.items():
            # Find most common sequences
            common_seqs = sorted(
                patterns['common_sequences'].items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
            
            analysis[component] = {
                'most_common_sequences': common_seqs,
                'sequence_diversity': len(patterns['common_sequences']),
                'current_sequence': list(patterns['recent_sequence'])
            }
        
        return analysis
    
    def reset_metrics(self):
        """Reset tracking metrics"""
        self.metrics.clear()
        self.patterns.clear()
        self._last_reset = datetime.now()
        
        self.logger.log_consciousness_event(
            event_type=EventType.SYSTEM_EVENT,
            component="tracker",
            data={"action": "metrics_reset"},
            severity="info"
        )
    
    def generate_report(self, output_file: str) -> bool:
        """Generate comprehensive tracking report"""
        try:
            report = {
                'report_timestamp': datetime.now().isoformat(),
                'metrics_summary': self.get_metrics_summary(),
                'pattern_analysis': self.get_pattern_analysis(),
                'recent_events': [
                    e.to_dict() for e in self.logger.get_recent_events(50)
                ]
            }
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            return True
            
        except Exception as e:
            self.logger.log_error(e, "tracker")
            return False