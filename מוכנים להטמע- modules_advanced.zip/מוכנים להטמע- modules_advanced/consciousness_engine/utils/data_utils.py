"""
Data Processing and Analysis Utilities
"""

import json
import statistics
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import re

class ValidationLevel(Enum):
    """Data validation levels"""
    STRICT = "strict"
    MODERATE = "moderate"
    LENIENT = "lenient"

@dataclass
class ValidationResult:
    """Data validation result"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    score: float

class DataValidator:
    """Comprehensive data validation utilities"""
    
    def __init__(self, level: ValidationLevel = ValidationLevel.MODERATE):
        self.validation_level = level
        self.error_patterns = {
            'hebrew_encoding': r'[�]+',
            'invalid_emotion': r'[^א-תa-zA-Z0-9\s\-_]',
            'malformed_json': r'[{}].*[,]{2,}',
            'sql_injection': r'(drop|delete|insert|update|select).*[;]',
        }
    
    def validate_emotion_data(self, emotion_data: Dict[str, Any]) -> ValidationResult:
        """Validate emotion data structure"""
        errors = []
        warnings = []
        
        required_fields = ['type', 'intensity', 'timestamp']
        optional_fields = ['duration', 'triggers', 'associations']
        
        # Check required fields
        for field in required_fields:
            if field not in emotion_data:
                errors.append(f"שדה חסר: {field}")
        
        # Validate emotion type
        if 'type' in emotion_data:
            if not isinstance(emotion_data['type'], str):
                errors.append("סוג רגש חייב להיות מחרוזת")
            elif not re.match(r'^[א-תa-zA-Z\s]+$', emotion_data['type']):
                errors.append("סוג רגש מכיל תווים לא חוקיים")
        
        # Validate intensity
        if 'intensity' in emotion_data:
            intensity = emotion_data['intensity']
            if not isinstance(intensity, (int, float)):
                errors.append("עוצמת רגש חייבת להיות מספר")
            elif not 0 <= intensity <= 1:
                errors.append("עוצמת רגש חייבת להיות בין 0 ל-1")
        
        # Validate timestamp
        if 'timestamp' in emotion_data:
            try:
                datetime.fromisoformat(emotion_data['timestamp'].replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                errors.append("פורמט זמן לא תקין")
        
        score = max(0, 1 - (len(errors) * 0.3 + len(warnings) * 0.1))
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            score=score
        )
    
    def validate_memory_data(self, memory_data: Dict[str, Any]) -> ValidationResult:
        """Validate memory data structure"""
        errors = []
        warnings = []
        
        required_fields = ['content', 'type', 'layer', 'timestamp']
        
        # Check required fields
        for field in required_fields:
            if field not in memory_data:
                errors.append(f"שדה חסר: {field}")
        
        # Validate memory content
        if 'content' in memory_data:
            content = memory_data['content']
            if not isinstance(content, str):
                errors.append("תוכן הזיכרון חייב להיות מחרוזת")
            elif len(content.strip()) == 0:
                errors.append("תוכן הזיכרון ריק")
            elif len(content) > 10000:
                warnings.append("תוכן הזיכרון ארוך מאוד")
        
        # Validate memory type
        valid_types = ['episodic', 'semantic', 'procedural', 'working', 'short_term']
        if 'type' in memory_data:
            if memory_data['type'] not in valid_types:
                errors.append(f"סוג זיכרון לא תקין: {memory_data['type']}")
        
        # Validate layer
        if 'layer' in memory_data:
            layer = memory_data['layer']
            if not isinstance(layer, int) or not 1 <= layer <= 5:
                errors.append("שכבת זיכרון חייבת להיות בין 1 ל-5")
        
        score = max(0, 1 - (len(errors) * 0.3 + len(warnings) * 0.1))
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            score=score
        )
    
    def validate_thought_data(self, thought_data: Dict[str, Any]) -> ValidationResult:
        """Validate thought data structure"""
        errors = []
        warnings = []
        
        required_fields = ['content', 'type', 'cognitive_load']
        
        for field in required_fields:
            if field not in thought_data:
                errors.append(f"שדה חסר: {field}")
        
        # Validate cognitive load
        if 'cognitive_load' in thought_data:
            load = thought_data['cognitive_load']
            if not isinstance(load, (int, float)):
                errors.append("עומס קוגניטיבי חייב להיות מספר")
            elif not 0 <= load <= 1:
                errors.append("עומס קוגניטיבי חייב להיות בין 0 ל-1")
        
        score = max(0, 1 - (len(errors) * 0.3 + len(warnings) * 0.1))
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            score=score
        )
    
    def validate_config_data(self, config_data: Dict[str, Any]) -> ValidationResult:
        """Validate configuration data"""
        errors = []
        warnings = []
        
        # Check for dangerous patterns
        json_str = json.dumps(config_data)
        for pattern_name, pattern in self.error_patterns.items():
            if re.search(pattern, json_str, re.IGNORECASE):
                errors.append(f"דפוס מסוכן זוהה: {pattern_name}")
        
        # Validate structure
        if not isinstance(config_data, dict):
            errors.append("קונפיגורציה חייבת להיות אובייקט")
        
        score = max(0, 1 - (len(errors) * 0.5 + len(warnings) * 0.2))
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            score=score
        )

class MetricsCalculator:
    """Advanced metrics calculation utilities"""
    
    def __init__(self):
        self.calculation_history = []
    
    def calculate_emotion_metrics(self, emotions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate comprehensive emotion metrics"""
        if not emotions:
            return self._empty_emotion_metrics()
        
        intensities = [e.get('intensity', 0) for e in emotions]
        durations = [e.get('duration', 0) for e in emotions if 'duration' in e]
        
        metrics = {
            'avg_intensity': statistics.mean(intensities),
            'max_intensity': max(intensities),
            'min_intensity': min(intensities),
            'intensity_variance': statistics.variance(intensities) if len(intensities) > 1 else 0,
            'emotion_count': len(emotions),
            'unique_emotions': len(set(e.get('type', '') for e in emotions)),
            'stability_score': self._calculate_emotion_stability(emotions),
            'complexity_score': self._calculate_emotion_complexity(emotions)
        }
        
        if durations:
            metrics.update({
                'avg_duration': statistics.mean(durations),
                'total_duration': sum(durations)
            })
        
        return metrics
    
    def calculate_memory_metrics(self, memories: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate memory system metrics"""
        if not memories:
            return self._empty_memory_metrics()
        
        layer_distribution = {}
        type_distribution = {}
        content_lengths = []
        
        for memory in memories:
            layer = memory.get('layer', 0)
            mem_type = memory.get('type', 'unknown')
            content = memory.get('content', '')
            
            layer_distribution[layer] = layer_distribution.get(layer, 0) + 1
            type_distribution[mem_type] = type_distribution.get(mem_type, 0) + 1
            content_lengths.append(len(content))
        
        metrics = {
            'total_memories': len(memories),
            'avg_content_length': statistics.mean(content_lengths),
            'layer_diversity': len(layer_distribution),
            'type_diversity': len(type_distribution),
            'memory_density': self._calculate_memory_density(memories),
            'consolidation_score': self._calculate_consolidation_score(memories),
            'retrieval_efficiency': self._calculate_retrieval_efficiency(memories)
        }
        
        # Layer-specific metrics
        for layer in range(1, 6):
            layer_count = layer_distribution.get(layer, 0)
            metrics[f'layer_{layer}_usage'] = layer_count / len(memories)
        
        return metrics
    
    def calculate_thought_metrics(self, thoughts: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate thought process metrics"""
        if not thoughts:
            return self._empty_thought_metrics()
        
        cognitive_loads = [t.get('cognitive_load', 0) for t in thoughts]
        thought_types = [t.get('type', '') for t in thoughts]
        
        metrics = {
            'total_thoughts': len(thoughts),
            'avg_cognitive_load': statistics.mean(cognitive_loads),
            'max_cognitive_load': max(cognitive_loads),
            'cognitive_efficiency': self._calculate_cognitive_efficiency(thoughts),
            'thought_diversity': len(set(thought_types)),
            'processing_speed': self._calculate_processing_speed(thoughts),
            'coherence_score': self._calculate_thought_coherence(thoughts)
        }
        
        return metrics
    
    def calculate_consciousness_metrics(self, 
                                     emotions: List[Dict[str, Any]],
                                     memories: List[Dict[str, Any]], 
                                     thoughts: List[Dict[str, Any]],
                                     states: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate overall consciousness metrics"""
        emotion_metrics = self.calculate_emotion_metrics(emotions)
        memory_metrics = self.calculate_memory_metrics(memories)
        thought_metrics = self.calculate_thought_metrics(thoughts)
        
        # Integration metrics
        consciousness_metrics = {
            'overall_complexity': self._calculate_overall_complexity(
                emotion_metrics, memory_metrics, thought_metrics
            ),
            'system_coherence': self._calculate_system_coherence(
                emotion_metrics, memory_metrics, thought_metrics
            ),
            'adaptive_capacity': self._calculate_adaptive_capacity(states),
            'consciousness_level': self._calculate_consciousness_level(states),
            'integration_score': self._calculate_integration_score(
                emotions, memories, thoughts
            ),
            'stability_index': self._calculate_stability_index(
                emotion_metrics, memory_metrics, thought_metrics
            )
        }
        
        return consciousness_metrics
    
    def _empty_emotion_metrics(self) -> Dict[str, float]:
        """Return empty emotion metrics"""
        return {
            'avg_intensity': 0.0,
            'max_intensity': 0.0,
            'min_intensity': 0.0,
            'intensity_variance': 0.0,
            'emotion_count': 0,
            'unique_emotions': 0,
            'stability_score': 0.0,
            'complexity_score': 0.0
        }
    
    def _empty_memory_metrics(self) -> Dict[str, float]:
        """Return empty memory metrics"""
        return {
            'total_memories': 0,
            'avg_content_length': 0.0,
            'layer_diversity': 0,
            'type_diversity': 0,
            'memory_density': 0.0,
            'consolidation_score': 0.0,
            'retrieval_efficiency': 0.0
        }
    
    def _empty_thought_metrics(self) -> Dict[str, float]:
        """Return empty thought metrics"""
        return {
            'total_thoughts': 0,
            'avg_cognitive_load': 0.0,
            'max_cognitive_load': 0.0,
            'cognitive_efficiency': 0.0,
            'thought_diversity': 0,
            'processing_speed': 0.0,
            'coherence_score': 0.0
        }
    
    def _calculate_emotion_stability(self, emotions: List[Dict[str, Any]]) -> float:
        """Calculate emotion stability score"""
        if len(emotions) < 2:
            return 1.0
        
        intensities = [e.get('intensity', 0) for e in emotions]
        variance = statistics.variance(intensities)
        return max(0, 1 - variance)
    
    def _calculate_emotion_complexity(self, emotions: List[Dict[str, Any]]) -> float:
        """Calculate emotion complexity score"""
        unique_types = len(set(e.get('type', '') for e in emotions))
        total_emotions = len(emotions)
        
        if total_emotions == 0:
            return 0.0
        
        return min(1.0, unique_types / max(5, total_emotions * 0.5))
    
    def _calculate_memory_density(self, memories: List[Dict[str, Any]]) -> float:
        """Calculate memory density score"""
        if not memories:
            return 0.0
        
        total_content = sum(len(m.get('content', '')) for m in memories)
        avg_content = total_content / len(memories)
        
        # Normalize to 0-1 scale (assuming 500 chars is optimal)
        return min(1.0, avg_content / 500)
    
    def _calculate_consolidation_score(self, memories: List[Dict[str, Any]]) -> float:
        """Calculate memory consolidation score"""
        if not memories:
            return 0.0
        
        # Check distribution across layers
        layer_counts = {}
        for memory in memories:
            layer = memory.get('layer', 1)
            layer_counts[layer] = layer_counts.get(layer, 0) + 1
        
        # Ideal distribution: more in higher layers
        total = len(memories)
        ideal_distribution = [0.4, 0.3, 0.15, 0.1, 0.05]  # layers 1-5
        
        score = 0.0
        for layer in range(1, 6):
            actual_ratio = layer_counts.get(layer, 0) / total
            ideal_ratio = ideal_distribution[layer - 1]
            score += 1 - abs(actual_ratio - ideal_ratio)
        
        return score / 5
    
    def _calculate_retrieval_efficiency(self, memories: List[Dict[str, Any]]) -> float:
        """Calculate memory retrieval efficiency"""
        # Simplified calculation based on memory associations
        if not memories:
            return 0.0
        
        associated_memories = sum(1 for m in memories if m.get('associations', []))
        return associated_memories / len(memories)
    
    def _calculate_cognitive_efficiency(self, thoughts: List[Dict[str, Any]]) -> float:
        """Calculate cognitive processing efficiency"""
        if not thoughts:
            return 0.0
        
        loads = [t.get('cognitive_load', 0) for t in thoughts]
        avg_load = statistics.mean(loads)
        
        # Lower average load with maintained diversity = higher efficiency
        diversity = len(set(t.get('type', '') for t in thoughts))
        efficiency = (diversity / len(thoughts)) * (1 - avg_load)
        
        return max(0, min(1, efficiency))
    
    def _calculate_processing_speed(self, thoughts: List[Dict[str, Any]]) -> float:
        """Calculate thought processing speed"""
        # Simplified calculation based on thought frequency
        if len(thoughts) < 2:
            return 0.0
        
        timestamps = []
        for thought in thoughts:
            if 'timestamp' in thought:
                try:
                    ts = datetime.fromisoformat(thought['timestamp'].replace('Z', '+00:00'))
                    timestamps.append(ts)
                except:
                    continue
        
        if len(timestamps) < 2:
            return 0.5  # Default moderate speed
        
        time_diffs = []
        for i in range(1, len(timestamps)):
            diff = (timestamps[i] - timestamps[i-1]).total_seconds()
            time_diffs.append(diff)
        
        avg_interval = statistics.mean(time_diffs)
        # Normalize (1 second = 1.0, faster = higher score)
        return min(1.0, 1.0 / max(0.1, avg_interval))
    
    def _calculate_thought_coherence(self, thoughts: List[Dict[str, Any]]) -> float:
        """Calculate thought stream coherence"""
        if len(thoughts) < 2:
            return 1.0
        
        # Check for related thoughts (simplified)
        coherent_pairs = 0
        total_pairs = 0
        
        for i in range(len(thoughts) - 1):
            thought1 = thoughts[i]
            thought2 = thoughts[i + 1]
            
            # Check if thoughts are related (same type or similar content)
            if (thought1.get('type') == thought2.get('type') or 
                self._thoughts_related(thought1.get('content', ''), 
                                     thought2.get('content', ''))):
                coherent_pairs += 1
            total_pairs += 1
        
        return coherent_pairs / total_pairs if total_pairs > 0 else 1.0
    
    def _thoughts_related(self, content1: str, content2: str) -> bool:
        """Check if two thoughts are related"""
        if not content1 or not content2:
            return False
        
        # Simple keyword overlap check
        words1 = set(content1.lower().split())
        words2 = set(content2.lower().split())
        
        overlap = len(words1.intersection(words2))
        return overlap >= 2
    
    def _calculate_overall_complexity(self, 
                                    emotion_metrics: Dict[str, float],
                                    memory_metrics: Dict[str, float], 
                                    thought_metrics: Dict[str, float]) -> float:
        """Calculate overall system complexity"""
        components = [
            emotion_metrics.get('complexity_score', 0),
            memory_metrics.get('type_diversity', 0) / 5,  # Normalize
            thought_metrics.get('thought_diversity', 0) / 10  # Normalize
        ]
        
        return statistics.mean(components)
    
    def _calculate_system_coherence(self,
                                  emotion_metrics: Dict[str, float],
                                  memory_metrics: Dict[str, float],
                                  thought_metrics: Dict[str, float]) -> float:
        """Calculate system-wide coherence"""
        components = [
            emotion_metrics.get('stability_score', 0),
            memory_metrics.get('consolidation_score', 0),
            thought_metrics.get('coherence_score', 0)
        ]
        
        return statistics.mean(components)
    
    def _calculate_adaptive_capacity(self, states: List[Dict[str, Any]]) -> float:
        """Calculate adaptive capacity from consciousness states"""
        if not states:
            return 0.0
        
        # Check for state transitions (indicates adaptability)
        unique_states = len(set(s.get('level', 0) for s in states))
        total_states = len(states)
        
        return min(1.0, unique_states / max(3, total_states * 0.3))
    
    def _calculate_consciousness_level(self, states: List[Dict[str, Any]]) -> float:
        """Calculate current consciousness level"""
        if not states:
            return 0.0
        
        # Use the most recent state
        recent_state = states[-1] if states else {}
        level = recent_state.get('level', 0)
        
        # Normalize to 0-1 scale (6 levels)
        return level / 6.0
    
    def _calculate_integration_score(self,
                                   emotions: List[Dict[str, Any]],
                                   memories: List[Dict[str, Any]],
                                   thoughts: List[Dict[str, Any]]) -> float:
        """Calculate integration between different consciousness components"""
        # Simplified integration score based on temporal correlation
        if not all([emotions, memories, thoughts]):
            return 0.0
        
        # Check for temporal clustering of activities
        all_events = []
        
        for emotion in emotions:
            if 'timestamp' in emotion:
                all_events.append(('emotion', emotion['timestamp']))
        
        for memory in memories:
            if 'timestamp' in memory:
                all_events.append(('memory', memory['timestamp']))
        
        for thought in thoughts:
            if 'timestamp' in thought:
                all_events.append(('thought', thought['timestamp']))
        
        if len(all_events) < 6:  # Need sufficient events
            return 0.5
        
        # Sort by timestamp and check for mixed event types in clusters
        all_events.sort(key=lambda x: x[1])
        
        clusters = []
        current_cluster = []
        
        for i, (event_type, timestamp) in enumerate(all_events):
            if i == 0:
                current_cluster.append(event_type)
            else:
                prev_time = all_events[i-1][1]
                try:
                    time_diff = abs((datetime.fromisoformat(timestamp.replace('Z', '+00:00')) - 
                                   datetime.fromisoformat(prev_time.replace('Z', '+00:00'))).total_seconds())
                    
                    if time_diff < 60:  # Within 1 minute = same cluster
                        current_cluster.append(event_type)
                    else:
                        if len(current_cluster) > 1:
                            clusters.append(current_cluster)
                        current_cluster = [event_type]
                except:
                    continue
        
        if len(current_cluster) > 1:
            clusters.append(current_cluster)
        
        # Calculate integration score based on cluster diversity
        if not clusters:
            return 0.0
        
        integration_scores = []
        for cluster in clusters:
            unique_types = len(set(cluster))
            integration_scores.append(unique_types / 3)  # Max 3 types
        
        return statistics.mean(integration_scores)
    
    def _calculate_stability_index(self,
                                 emotion_metrics: Dict[str, float],
                                 memory_metrics: Dict[str, float],
                                 thought_metrics: Dict[str, float]) -> float:
        """Calculate overall system stability"""
        stability_components = [
            emotion_metrics.get('stability_score', 0),
            memory_metrics.get('consolidation_score', 0),
            thought_metrics.get('cognitive_efficiency', 0)
        ]
        
        return statistics.mean(stability_components)

class PatternAnalyzer:
    """Advanced pattern analysis utilities"""
    
    def __init__(self):
        self.pattern_cache = {}
        self.analysis_history = []
    
    def analyze_emotion_patterns(self, emotions: List[Dict[str, Any]], 
                               time_window: int = 3600) -> Dict[str, Any]:
        """Analyze emotional patterns over time"""
        if not emotions:
            return {'patterns': [], 'trends': {}, 'cycles': []}
        
        # Group emotions by time windows
        time_groups = self._group_by_time_windows(emotions, time_window)
        
        patterns = {
            'dominant_emotions': self._find_dominant_emotions(emotions),
            'emotion_transitions': self._analyze_emotion_transitions(emotions),
            'intensity_patterns': self._analyze_intensity_patterns(emotions),
            'temporal_trends': self._analyze_temporal_trends(time_groups),
            'correlation_patterns': self._analyze_emotion_correlations(emotions)
        }
        
        return patterns
    
    def analyze_memory_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze memory formation and access patterns"""
        if not memories:
            return {'patterns': [], 'consolidation': {}, 'access_patterns': []}
        
        patterns = {
            'layer_patterns': self._analyze_layer_patterns(memories),
            'content_patterns': self._analyze_content_patterns(memories),
            'temporal_patterns': self._analyze_memory_temporal_patterns(memories),
            'association_patterns': self._analyze_association_patterns(memories),
            'consolidation_patterns': self._analyze_consolidation_patterns(memories)
        }
        
        return patterns
    
    def analyze_thought_patterns(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze thought patterns and cognitive processes"""
        if not thoughts:
            return {'patterns': [], 'cognitive_flows': [], 'efficiency': 0}
        
        patterns = {
            'cognitive_patterns': self._analyze_cognitive_patterns(thoughts),
            'thought_flows': self._analyze_thought_flows(thoughts),
            'load_patterns': self._analyze_cognitive_load_patterns(thoughts),
            'type_patterns': self._analyze_thought_type_patterns(thoughts),
            'coherence_patterns': self._analyze_coherence_patterns(thoughts)
        }
        
        return patterns
    
    def detect_anomalies(self, data: List[Dict[str, Any]], 
                        data_type: str) -> List[Dict[str, Any]]:
        """Detect anomalies in consciousness data"""
        anomalies = []
        
        if data_type == 'emotion':
            anomalies.extend(self._detect_emotion_anomalies(data))
        elif data_type == 'memory':
            anomalies.extend(self._detect_memory_anomalies(data))
        elif data_type == 'thought':
            anomalies.extend(self._detect_thought_anomalies(data))
        
        return anomalies
    
    def _group_by_time_windows(self, data: List[Dict[str, Any]], 
                              window_size: int) -> Dict[str, List[Dict[str, Any]]]:
        """Group data by time windows"""
        groups = {}
        
        for item in data:
            if 'timestamp' not in item:
                continue
            
            try:
                timestamp = datetime.fromisoformat(item['timestamp'].replace('Z', '+00:00'))
                window_key = f"{timestamp.date()}_{timestamp.hour // (window_size // 3600)}"
                
                if window_key not in groups:
                    groups[window_key] = []
                groups[window_key].append(item)
            except:
                continue
        
        return groups
    
    def _find_dominant_emotions(self, emotions: List[Dict[str, Any]]) -> List[Tuple[str, float]]:
        """Find dominant emotions by frequency and intensity"""
        emotion_stats = {}
        
        for emotion in emotions:
            emotion_type = emotion.get('type', 'unknown')
            intensity = emotion.get('intensity', 0)
            
            if emotion_type not in emotion_stats:
                emotion_stats[emotion_type] = {'count': 0, 'total_intensity': 0}
            
            emotion_stats[emotion_type]['count'] += 1
            emotion_stats[emotion_type]['total_intensity'] += intensity
        
        # Calculate dominance score (frequency * average intensity)
        dominance_scores = []
        for emotion_type, stats in emotion_stats.items():
            avg_intensity = stats['total_intensity'] / stats['count']
            dominance = stats['count'] * avg_intensity
            dominance_scores.append((emotion_type, dominance))
        
        return sorted(dominance_scores, key=lambda x: x[1], reverse=True)[:5]
    
    def _analyze_emotion_transitions(self, emotions: List[Dict[str, Any]]) -> List[Tuple[str, str, int]]:
        """Analyze transitions between emotions"""
        transitions = {}
        
        for i in range(len(emotions) - 1):
            current_emotion = emotions[i].get('type', 'unknown')
            next_emotion = emotions[i + 1].get('type', 'unknown')
            
            transition = (current_emotion, next_emotion)
            transitions[transition] = transitions.get(transition, 0) + 1
        
        return sorted(transitions.items(), key=lambda x: x[1], reverse=True)
    
    def _analyze_intensity_patterns(self, emotions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Analyze emotion intensity patterns"""
        intensities = [e.get('intensity', 0) for e in emotions]
        
        if not intensities:
            return {}
        
        return {
            'mean_intensity': statistics.mean(intensities),
            'median_intensity': statistics.median(intensities),
            'intensity_variance': statistics.variance(intensities) if len(intensities) > 1 else 0,
            'max_intensity': max(intensities),
            'min_intensity': min(intensities),
            'intensity_trend': self._calculate_trend(intensities)
        }
    
    def _analyze_temporal_trends(self, time_groups: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        """Analyze temporal trends in grouped data"""
        trends = {
            'activity_by_time': {},
            'peak_activity_periods': [],
            'trend_direction': 'stable'
        }
        
        for time_key, group in time_groups.items():
            trends['activity_by_time'][time_key] = len(group)
        
        # Find peak periods
        if trends['activity_by_time']:
            max_activity = max(trends['activity_by_time'].values())
            peaks = [k for k, v in trends['activity_by_time'].items() if v >= max_activity * 0.8]
            trends['peak_activity_periods'] = peaks
        
        return trends
    
    def _analyze_emotion_correlations(self, emotions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Analyze correlations between different emotions"""
        # Simplified correlation analysis
        emotion_pairs = {}
        
        # Group emotions by time proximity (within 5 minutes)
        time_groups = []
        current_group = []
        
        for emotion in emotions:
            if not emotion.get('timestamp'):
                continue
            
            if not current_group:
                current_group.append(emotion)
            else:
                try:
                    current_time = datetime.fromisoformat(emotion['timestamp'].replace('Z', '+00:00'))
                    last_time = datetime.fromisoformat(current_group[-1]['timestamp'].replace('Z', '+00:00'))
                    
                    if (current_time - last_time).total_seconds() <= 300:  # 5 minutes
                        current_group.append(emotion)
                    else:
                        if len(current_group) > 1:
                            time_groups.append(current_group)
                        current_group = [emotion]
                except:
                    continue
        
        if len(current_group) > 1:
            time_groups.append(current_group)
        
        # Calculate co-occurrence
        for group in time_groups:
            emotion_types = [e.get('type', '') for e in group]
            unique_types = list(set(emotion_types))
            
            for i in range(len(unique_types)):
                for j in range(i + 1, len(unique_types)):
                    pair = tuple(sorted([unique_types[i], unique_types[j]]))
                    emotion_pairs[pair] = emotion_pairs.get(pair, 0) + 1
        
        return emotion_pairs
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction for a series of values"""
        if len(values) < 3:
            return 'insufficient_data'
        
        # Simple linear trend calculation
        x = list(range(len(values)))
        n = len(values)
        
        sum_x = sum(x)
        sum_y = sum(values)
        sum_xy = sum(x[i] * values[i] for i in range(n))
        sum_x2 = sum(x[i] ** 2 for i in range(n))
        
        # Calculate slope
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
        
        if slope > 0.1:
            return 'increasing'
        elif slope < -0.1:
            return 'decreasing'
        else:
            return 'stable'
    
    def _analyze_layer_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze memory layer usage patterns"""
        layer_stats = {}
        
        for memory in memories:
            layer = memory.get('layer', 1)
            if layer not in layer_stats:
                layer_stats[layer] = {'count': 0, 'avg_content_length': 0, 'types': set()}
            
            layer_stats[layer]['count'] += 1
            layer_stats[layer]['avg_content_length'] += len(memory.get('content', ''))
            layer_stats[layer]['types'].add(memory.get('type', 'unknown'))
        
        # Calculate averages
        for layer in layer_stats:
            if layer_stats[layer]['count'] > 0:
                layer_stats[layer]['avg_content_length'] /= layer_stats[layer]['count']
            layer_stats[layer]['type_diversity'] = len(layer_stats[layer]['types'])
            layer_stats[layer]['types'] = list(layer_stats[layer]['types'])
        
        return layer_stats
    
    def _analyze_content_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze memory content patterns"""
        # Simplified content analysis
        word_frequency = {}
        content_lengths = []
        
        for memory in memories:
            content = memory.get('content', '')
            content_lengths.append(len(content))
            
            # Simple word extraction
            words = re.findall(r'\b\w+\b', content.lower())
            for word in words:
                if len(word) > 3:  # Skip short words
                    word_frequency[word] = word_frequency.get(word, 0) + 1
        
        # Get top words
        top_words = sorted(word_frequency.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            'top_keywords': top_words,
            'avg_content_length': statistics.mean(content_lengths) if content_lengths else 0,
            'content_length_variance': statistics.variance(content_lengths) if len(content_lengths) > 1 else 0
        }
    
    def _analyze_memory_temporal_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze temporal patterns in memory formation"""
        timestamps = []
        
        for memory in memories:
            if 'timestamp' in memory:
                try:
                    ts = datetime.fromisoformat(memory['timestamp'].replace('Z', '+00:00'))
                    timestamps.append(ts)
                except:
                    continue
        
        if len(timestamps) < 2:
            return {'pattern': 'insufficient_data'}
        
        timestamps.sort()
        intervals = []
        
        for i in range(1, len(timestamps)):
            interval = (timestamps[i] - timestamps[i-1]).total_seconds()
            intervals.append(interval)
        
        return {
            'avg_formation_interval': statistics.mean(intervals),
            'formation_pattern': self._classify_formation_pattern(intervals),
            'peak_formation_hours': self._find_peak_hours(timestamps)
        }
    
    def _classify_formation_pattern(self, intervals: List[float]) -> str:
        """Classify memory formation pattern"""
        if not intervals:
            return 'unknown'
        
        avg_interval = statistics.mean(intervals)
        variance = statistics.variance(intervals) if len(intervals) > 1 else 0
        
        if variance < avg_interval * 0.1:
            return 'regular'
        elif variance > avg_interval * 2:
            return 'burst'
        else:
            return 'irregular'
    
    def _find_peak_hours(self, timestamps: List[datetime]) -> List[int]:
        """Find peak hours for memory formation"""
        hour_counts = {}
        
        for ts in timestamps:
            hour = ts.hour
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
        
        if not hour_counts:
            return []
        
        max_count = max(hour_counts.values())
        peak_hours = [hour for hour, count in hour_counts.items() if count >= max_count * 0.8]
        
        return sorted(peak_hours)
    
    def _analyze_association_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze memory association patterns"""
        association_stats = {
            'total_associations': 0,
            'memories_with_associations': 0,
            'avg_associations_per_memory': 0,
            'association_network_density': 0
        }
        
        total_associations = 0
        memories_with_assoc = 0
        
        for memory in memories:
            associations = memory.get('associations', [])
            if associations:
                memories_with_assoc += 1
                total_associations += len(associations)
        
        if memories:
            association_stats['total_associations'] = total_associations
            association_stats['memories_with_associations'] = memories_with_assoc
            association_stats['avg_associations_per_memory'] = total_associations / len(memories)
            association_stats['association_network_density'] = memories_with_assoc / len(memories)
        
        return association_stats
    
    def _analyze_consolidation_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze memory consolidation patterns"""
        # Track movement between layers over time
        layer_transitions = {}
        
        # Group memories by content similarity and track layer changes
        # This is a simplified version - in practice, you'd track actual transitions
        
        layer_distribution = {}
        for memory in memories:
            layer = memory.get('layer', 1)
            layer_distribution[layer] = layer_distribution.get(layer, 0) + 1
        
        consolidation_score = 0
        total_memories = len(memories)
        
        # Higher layers should have fewer memories (consolidation effect)
        for layer in range(1, 6):
            count = layer_distribution.get(layer, 0)
            expected_ratio = 1.0 / (layer ** 1.5)  # Exponential decay expectation
            actual_ratio = count / total_memories if total_memories > 0 else 0
            
            # Score based on how close to expected distribution
            score_component = 1 - abs(actual_ratio - expected_ratio)
            consolidation_score += max(0, score_component)
        
        return {
            'consolidation_score': consolidation_score / 5,
            'layer_distribution': layer_distribution,
            'consolidation_efficiency': self._calculate_consolidation_efficiency(layer_distribution)
        }
    
    def _calculate_consolidation_efficiency(self, layer_distribution: Dict[int, int]) -> float:
        """Calculate consolidation efficiency"""
        total = sum(layer_distribution.values())
        if total == 0:
            return 0.0
        
        # Weighted score: higher layers = better consolidation
        weighted_sum = sum(layer * count for layer, count in layer_distribution.items())
        max_possible = total * 5  # All memories in layer 5
        
        return weighted_sum / max_possible
    
    def _analyze_cognitive_patterns(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze cognitive processing patterns"""
        cognitive_types = {}
        load_by_type = {}
        
        for thought in thoughts:
            thought_type = thought.get('type', 'unknown')
            cognitive_load = thought.get('cognitive_load', 0)
            
            cognitive_types[thought_type] = cognitive_types.get(thought_type, 0) + 1
            
            if thought_type not in load_by_type:
                load_by_type[thought_type] = []
            load_by_type[thought_type].append(cognitive_load)
        
        # Calculate average load per type
        avg_load_by_type = {}
        for thought_type, loads in load_by_type.items():
            avg_load_by_type[thought_type] = statistics.mean(loads)
        
        return {
            'type_frequency': cognitive_types,
            'avg_load_by_type': avg_load_by_type,
            'most_common_type': max(cognitive_types.items(), key=lambda x: x[1])[0] if cognitive_types else 'unknown',
            'most_intensive_type': max(avg_load_by_type.items(), key=lambda x: x[1])[0] if avg_load_by_type else 'unknown'
        }
    
    def _analyze_thought_flows(self, thoughts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Analyze thought flow patterns"""
        flows = []
        
        # Identify sequences of related thoughts
        current_flow = []
        
        for i, thought in enumerate(thoughts):
            if not current_flow:
                current_flow.append(thought)
            else:
                # Check if thought continues the flow (same type or related content)
                prev_thought = current_flow[-1]
                
                if (thought.get('type') == prev_thought.get('type') or
                    self._thoughts_related(thought.get('content', ''), 
                                         prev_thought.get('content', ''))):
                    current_flow.append(thought)
                else:
                    if len(current_flow) > 1:
                        flows.append({
                            'length': len(current_flow),
                            'type': current_flow[0].get('type', 'unknown'),
                            'avg_load': statistics.mean([t.get('cognitive_load', 0) for t in current_flow]),
                            'duration': self._calculate_flow_duration(current_flow)
                        })
                    current_flow = [thought]
        
        if len(current_flow) > 1:
            flows.append({
                'length': len(current_flow),
                'type': current_flow[0].get('type', 'unknown'),
                'avg_load': statistics.mean([t.get('cognitive_load', 0) for t in current_flow]),
                'duration': self._calculate_flow_duration(current_flow)
            })
        
        return flows
    
    def _calculate_flow_duration(self, flow: List[Dict[str, Any]]) -> float:
        """Calculate duration of a thought flow"""
        timestamps = []
        
        for thought in flow:
            if 'timestamp' in thought:
                try:
                    ts = datetime.fromisoformat(thought['timestamp'].replace('Z', '+00:00'))
                    timestamps.append(ts)
                except:
                    continue
        
        if len(timestamps) < 2:
            return 0.0
        
        return (max(timestamps) - min(timestamps)).total_seconds()
    
    def _analyze_cognitive_load_patterns(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze cognitive load patterns"""
        loads = [t.get('cognitive_load', 0) for t in thoughts]
        
        if not loads:
            return {}
        
        return {
            'avg_load': statistics.mean(loads),
            'max_load': max(loads),
            'min_load': min(loads),
            'load_variance': statistics.variance(loads) if len(loads) > 1 else 0,
            'load_trend': self._calculate_trend(loads),
            'overload_episodes': len([l for l in loads if l > 0.8]),
            'underutilization_episodes': len([l for l in loads if l < 0.2])
        }
    
    def _analyze_thought_type_patterns(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze thought type patterns"""
        type_sequences = []
        current_sequence = []
        
        for thought in thoughts:
            thought_type = thought.get('type', 'unknown')
            
            if not current_sequence or current_sequence[-1] != thought_type:
                if current_sequence:
                    type_sequences.append(current_sequence)
                current_sequence = [thought_type]
            else:
                current_sequence.append(thought_type)
        
        if current_sequence:
            type_sequences.append(current_sequence)
        
        # Analyze patterns
        pattern_analysis = {
            'sequence_count': len(type_sequences),
            'avg_sequence_length': statistics.mean([len(seq) for seq in type_sequences]) if type_sequences else 0,
            'type_persistence': {},
            'most_common_transitions': self._find_common_transitions(type_sequences)
        }
        
        # Calculate type persistence
        for sequence in type_sequences:
            if sequence:
                thought_type = sequence[0]
                persistence = len(sequence)
                if thought_type not in pattern_analysis['type_persistence']:
                    pattern_analysis['type_persistence'][thought_type] = []
                pattern_analysis['type_persistence'][thought_type].append(persistence)
        
        # Average persistence per type
        for thought_type in pattern_analysis['type_persistence']:
            persistences = pattern_analysis['type_persistence'][thought_type]
            pattern_analysis['type_persistence'][thought_type] = statistics.mean(persistences)
        
        return pattern_analysis
    
    def _find_common_transitions(self, sequences: List[List[str]]) -> List[Tuple[str, str, int]]:
        """Find common type transitions"""
        transitions = {}
        
        for i in range(len(sequences) - 1):
            if sequences[i] and sequences[i + 1]:
                from_type = sequences[i][-1]  # Last type of current sequence
                to_type = sequences[i + 1][0]  # First type of next sequence
                
                transition = (from_type, to_type)
                transitions[transition] = transitions.get(transition, 0) + 1
        
        return sorted(transitions.items(), key=lambda x: x[1], reverse=True)[:5]
    
    def _analyze_coherence_patterns(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze thought coherence patterns"""
        coherence_scores = []
        
        # Calculate local coherence (between adjacent thoughts)
        for i in range(len(thoughts) - 1):
            thought1 = thoughts[i]
            thought2 = thoughts[i + 1]
            
            coherence = self._calculate_local_coherence(thought1, thought2)
            coherence_scores.append(coherence)
        
        if not coherence_scores:
            return {'avg_coherence': 0, 'coherence_trend': 'unknown'}
        
        return {
            'avg_coherence': statistics.mean(coherence_scores),
            'coherence_variance': statistics.variance(coherence_scores) if len(coherence_scores) > 1 else 0,
            'coherence_trend': self._calculate_trend(coherence_scores),
            'coherent_periods': self._find_coherent_periods(coherence_scores),
            'fragmentation_episodes': len([s for s in coherence_scores if s < 0.3])
        }
    
    def _calculate_local_coherence(self, thought1: Dict[str, Any], thought2: Dict[str, Any]) -> float:
        """Calculate coherence between two thoughts"""
        # Type coherence
        type_match = 1.0 if thought1.get('type') == thought2.get('type') else 0.0
        
        # Content coherence (simplified)
        content_match = 1.0 if self._thoughts_related(
            thought1.get('content', ''), 
            thought2.get('content', '')
        ) else 0.0
        
        # Load coherence (similar cognitive loads)
        load1 = thought1.get('cognitive_load', 0)
        load2 = thought2.get('cognitive_load', 0)
        load_similarity = 1 - abs(load1 - load2)
        
        # Weighted combination
        coherence = (type_match * 0.4 + content_match * 0.4 + load_similarity * 0.2)
        
        return coherence
    
    def _find_coherent_periods(self, coherence_scores: List[float]) -> List[Dict[str, Any]]:
        """Find periods of high coherence"""
        periods = []
        current_period = None
        
        for i, score in enumerate(coherence_scores):
            if score >= 0.7:  # High coherence threshold
                if current_period is None:
                    current_period = {'start': i, 'end': i, 'scores': [score]}
                else:
                    current_period['end'] = i
                    current_period['scores'].append(score)
            else:
                if current_period is not None:
                    if len(current_period['scores']) >= 3:  # Minimum period length
                        current_period['avg_coherence'] = statistics.mean(current_period['scores'])
                        current_period['length'] = len(current_period['scores'])
                        periods.append(current_period)
                    current_period = None
        
        # Handle period that extends to the end
        if current_period is not None and len(current_period['scores']) >= 3:
            current_period['avg_coherence'] = statistics.mean(current_period['scores'])
            current_period['length'] = len(current_period['scores'])
            periods.append(current_period)
        
        return periods
    
    def _detect_emotion_anomalies(self, emotions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Detect anomalies in emotion data"""
        anomalies = []
        
        if len(emotions) < 10:  # Need sufficient data
            return anomalies
        
        intensities = [e.get('intensity', 0) for e in emotions]
        mean_intensity = statistics.mean(intensities)
        std_intensity = statistics.stdev(intensities) if len(intensities) > 1 else 0
        
        for i, emotion in enumerate(emotions):
            intensity = emotion.get('intensity', 0)
            
            # Intensity anomaly (3 sigma rule)
            if abs(intensity - mean_intensity) > 3 * std_intensity:
                anomalies.append({
                    'type': 'intensity_anomaly',
                    'index': i,
                    'value': intensity,
                    'expected_range': (mean_intensity - 2*std_intensity, mean_intensity + 2*std_intensity),
                    'severity': 'high' if abs(intensity - mean_intensity) > 4 * std_intensity else 'moderate'
                })
        
        # Rapid emotion changes
        for i in range(len(emotions) - 1):
            intensity1 = emotions[i].get('intensity', 0)
            intensity2 = emotions[i + 1].get('intensity', 0)
            
            if abs(intensity2 - intensity1) > 0.7:  # Large change
                anomalies.append({
                    'type': 'rapid_change',
                    'index': i,
                    'change': intensity2 - intensity1,
                    'severity': 'high' if abs(intensity2 - intensity1) > 0.9 else 'moderate'
                })
        
        return anomalies
    
    def _detect_memory_anomalies(self, memories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Detect anomalies in memory data"""
        anomalies = []
        
        content_lengths = [len(m.get('content', '')) for m in memories]
        
        if len(content_lengths) < 5:
            return anomalies
        
        mean_length = statistics.mean(content_lengths)
        std_length = statistics.stdev(content_lengths)
        
        for i, memory in enumerate(memories):
            content_length = len(memory.get('content', ''))
            
            # Content length anomaly
            if abs(content_length - mean_length) > 3 * std_length:
                anomalies.append({
                    'type': 'content_length_anomaly',
                    'index': i,
                    'length': content_length,
                    'expected_range': (mean_length - 2*std_length, mean_length + 2*std_length),
                    'severity': 'high' if content_length > mean_length + 4*std_length else 'moderate'
                })
            
            # Layer anomaly (memory in wrong layer)
            layer = memory.get('layer', 1)
            content_length = len(memory.get('content', ''))
            
            # Simple heuristic: longer content should be in higher layers
            expected_layer = min(5, max(1, int(content_length / 200) + 1))
            
            if abs(layer - expected_layer) > 2:
                anomalies.append({
                    'type': 'layer_mismatch',
                    'index': i,
                    'actual_layer': layer,
                    'expected_layer': expected_layer,
                    'severity': 'moderate'
                })
        
        return anomalies
    
    def _detect_thought_anomalies(self, thoughts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Detect anomalies in thought data"""
        anomalies = []
        
        loads = [t.get('cognitive_load', 0) for t in thoughts]
        
        if len(loads) < 5:
            return anomalies
        
        mean_load = statistics.mean(loads)
        std_load = statistics.stdev(loads)
        
        for i, thought in enumerate(thoughts):
            load = thought.get('cognitive_load', 0)
            
            # Cognitive load anomaly
            if abs(load - mean_load) > 3 * std_load:
                anomalies.append({
                    'type': 'cognitive_load_anomaly',
                    'index': i,
                    'load': load,
                    'expected_range': (mean_load - 2*std_load, mean_load + 2*std_load),
                    'severity': 'high' if abs(load - mean_load) > 4 * std_load else 'moderate'
                })
            
            # Sustained high load
            if i >= 4:  # Check last 5 thoughts
                recent_loads = loads[i-4:i+1]
                if all(l > 0.8 for l in recent_loads):
                    anomalies.append({
                        'type': 'sustained_high_load',
                        'index': i,
                        'load_sequence': recent_loads,
                        'severity': 'high'
                    })
        
        return anomalies