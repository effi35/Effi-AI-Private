"""
Hebrew Text Processing and RTL Support Utilities
"""

import re
import unicodedata
from typing import List, Dict, Tuple, Optional
from enum import Enum

class TextDirection(Enum):
    """Text direction enumeration"""
    LTR = "ltr"
    RTL = "rtl"
    AUTO = "auto"

class HebrewTextProcessor:
    """Hebrew text processing utilities"""
    
    def __init__(self):
        self.hebrew_range = (0x0590, 0x05FF)
        self.arabic_range = (0x0600, 0x06FF)
        self.punctuation_marks = '.,;:!?()[]{}"\'-'
        
    def is_hebrew_char(self, char: str) -> bool:
        """Check if character is Hebrew"""
        return self.hebrew_range[0] <= ord(char) <= self.hebrew_range[1]
    
    def is_arabic_char(self, char: str) -> bool:
        """Check if character is Arabic"""
        return self.arabic_range[0] <= ord(char) <= self.arabic_range[1]
    
    def is_rtl_char(self, char: str) -> bool:
        """Check if character is RTL (Hebrew or Arabic)"""
        return self.is_hebrew_char(char) or self.is_arabic_char(char)
    
    def detect_text_direction(self, text: str) -> TextDirection:
        """Detect text direction based on character analysis"""
        if not text:
            return TextDirection.LTR
        
        rtl_count = sum(1 for char in text if self.is_rtl_char(char))
        ltr_count = sum(1 for char in text if char.isalnum() and not self.is_rtl_char(char))
        
        if rtl_count > ltr_count:
            return TextDirection.RTL
        elif ltr_count > rtl_count:
            return TextDirection.LTR
        else:
            return TextDirection.AUTO
    
    def normalize_hebrew_text(self, text: str) -> str:
        """Normalize Hebrew text (remove diacritics, standardize)"""
        # Remove Hebrew diacritics (nikud)
        normalized = ''.join(char for char in text 
                           if not (0x0591 <= ord(char) <= 0x05C7))
        
        # Normalize Unicode
        normalized = unicodedata.normalize('NFKC', normalized)
        
        return normalized.strip()
    
    def clean_mixed_text(self, text: str) -> str:
        """Clean mixed Hebrew-English text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Fix common RTL/LTR mixing issues
        text = self._fix_number_spacing(text)
        text = self._fix_punctuation_spacing(text)
        
        return text.strip()
    
    def _fix_number_spacing(self, text: str) -> str:
        """Fix spacing around numbers in RTL text"""
        # Add space before numbers preceded by Hebrew
        text = re.sub(r'([א-ת])(\d)', r'\1 \2', text)
        # Add space after numbers followed by Hebrew
        text = re.sub(r'(\d)([א-ת])', r'\1 \2', text)
        return text
    
    def _fix_punctuation_spacing(self, text: str) -> str:
        """Fix punctuation spacing in Hebrew text"""
        # Remove space before punctuation
        text = re.sub(r'\s+([.,;:!?])', r'\1', text)
        # Add space after punctuation if followed by letter
        text = re.sub(r'([.,;:!?])([א-תa-zA-Z])', r'\1 \2', text)
        return text
    
    def extract_hebrew_words(self, text: str) -> List[str]:
        """Extract Hebrew words from text"""
        hebrew_pattern = r'[א-ת]+'
        return re.findall(hebrew_pattern, text)
    
    def transliterate_to_latin(self, hebrew_text: str) -> str:
        """Basic Hebrew to Latin transliteration"""
        transliteration_map = {
            'א': 'a', 'ב': 'b', 'ג': 'g', 'ד': 'd', 'ה': 'h',
            'ו': 'v', 'ז': 'z', 'ח': 'ch', 'ט': 't', 'י': 'y',
            'כ': 'k', 'ל': 'l', 'מ': 'm', 'נ': 'n', 'ס': 's',
            'ע': 'a', 'פ': 'p', 'צ': 'ts', 'ק': 'k', 'ר': 'r',
            'ש': 'sh', 'ת': 't', 'ך': 'k', 'ם': 'm', 'ן': 'n',
            'ף': 'p', 'ץ': 'ts'
        }
        
        result = []
        for char in hebrew_text:
            if char in transliteration_map:
                result.append(transliteration_map[char])
            else:
                result.append(char)
        
        return ''.join(result)

class RTLFormatter:
    """RTL text formatting utilities"""
    
    def __init__(self):
        self.text_processor = HebrewTextProcessor()
    
    def format_for_display(self, text: str, max_width: int = 80) -> List[str]:
        """Format RTL text for display with proper line breaks"""
        words = text.split()
        lines = []
        current_line = []
        current_length = 0
        
        for word in words:
            word_length = len(word)
            
            if current_length + word_length + len(current_line) <= max_width:
                current_line.append(word)
                current_length += word_length
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
                current_length = word_length
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
    
    def align_rtl_text(self, text: str, width: int, 
                      alignment: str = 'right') -> str:
        """Align RTL text within specified width"""
        text = text.strip()
        text_length = len(text)
        
        if text_length >= width:
            return text
        
        padding = width - text_length
        
        if alignment == 'right':
            return ' ' * padding + text
        elif alignment == 'left':
            return text + ' ' * padding
        elif alignment == 'center':
            left_padding = padding // 2
            right_padding = padding - left_padding
            return ' ' * left_padding + text + ' ' * right_padding
        else:
            return text
    
    def create_rtl_table(self, data: List[List[str]], 
                        headers: List[str], 
                        column_widths: Optional[List[int]] = None) -> str:
        """Create RTL-formatted table"""
        if not data or not headers:
            return ""
        
        # Calculate column widths if not provided
        if not column_widths:
            column_widths = []
            for i in range(len(headers)):
                max_width = len(headers[i])
                for row in data:
                    if i < len(row):
                        max_width = max(max_width, len(str(row[i])))
                column_widths.append(max_width + 2)
        
        # Create separator line
        separator = '+'
        for width in column_widths:
            separator += '-' * width + '+'
        
        # Create header row
        header_row = '|'
        for i, header in enumerate(headers):
            aligned_header = self.align_rtl_text(header, column_widths[i])
            header_row += aligned_header + '|'
        
        # Create data rows
        table_lines = [separator, header_row, separator]
        
        for row in data:
            data_row = '|'
            for i in range(len(headers)):
                cell_value = str(row[i]) if i < len(row) else ''
                aligned_cell = self.align_rtl_text(cell_value, column_widths[i])
                data_row += aligned_cell + '|'
            table_lines.append(data_row)
        
        table_lines.append(separator)
        return '\n'.join(table_lines)
    
    def wrap_with_rtl_marks(self, text: str) -> str:
        """Wrap text with RTL directional marks"""
        rtl_mark = '\u200F'  # Right-to-Left Mark
        return f"{rtl_mark}{text}{rtl_mark}"
    
    def format_mixed_content(self, content: str) -> str:
        """Format mixed RTL/LTR content properly"""
        # Split by lines and process each
        lines = content.split('\n')
        formatted_lines = []
        
        for line in lines:
            direction = self.text_processor.detect_text_direction(line)
            
            if direction == TextDirection.RTL:
                line = self.wrap_with_rtl_marks(line)
            
            formatted_lines.append(line)
        
        return '\n'.join(formatted_lines)
    
    def create_rtl_menu(self, items: List[Tuple[str, str]], 
                       title: str = "תפריט") -> str:
        """Create RTL-formatted menu"""
        menu_lines = []
        
        # Add title
        menu_lines.append(f"=== {title} ===")
        menu_lines.append("")
        
        # Add menu items
        for i, (key, description) in enumerate(items, 1):
            menu_line = f"{i}. {description} ({key})"
            menu_lines.append(menu_line)
        
        menu_lines.append("")
        menu_lines.append("בחר אפשרות:")
        
        return '\n'.join(menu_lines)
    
    def format_error_message(self, error: str, context: str = "") -> str:
        """Format error message in Hebrew"""
        error_template = """
┌─ שגיאה ─┐
│ {error}
│ 
│ הקשר: {context}
└─────────┘
        """.strip()
        
        return error_template.format(
            error=error,
            context=context or "לא זמין"
        )
    
    def format_success_message(self, message: str, details: str = "") -> str:
        """Format success message in Hebrew"""
        success_template = """
┌─ הצלחה ─┐
│ ✓ {message}
│ 
│ פרטים: {details}
└─────────┘
        """.strip()
        
        return success_template.format(
            message=message,
            details=details or "אין פרטים נוספים"
        )

class HebrewStringUtils:
    """Additional Hebrew string utilities"""
    
    @staticmethod
    def reverse_hebrew_words(text: str) -> str:
        """Reverse word order in Hebrew sentence (for special cases)"""
        words = text.split()
        return ' '.join(reversed(words))
    
    @staticmethod
    def count_hebrew_characters(text: str) -> int:
        """Count Hebrew characters in text"""
        processor = HebrewTextProcessor()
        return sum(1 for char in text if processor.is_hebrew_char(char))
    
    @staticmethod
    def extract_hebrew_sentences(text: str) -> List[str]:
        """Extract Hebrew sentences from mixed text"""
        # Split by sentence endings
        sentences = re.split(r'[.!?]+', text)
        
        processor = HebrewTextProcessor()
        hebrew_sentences = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence and processor.detect_text_direction(sentence) == TextDirection.RTL:
                hebrew_sentences.append(sentence)
        
        return hebrew_sentences
    
    @staticmethod
    def format_hebrew_number(number: int) -> str:
        """Format number with Hebrew thousands separator"""
        return f"{number:,}".replace(',', ',')  # Hebrew uses comma
    
    @staticmethod
    def validate_hebrew_input(text: str) -> Tuple[bool, str]:
        """Validate Hebrew text input"""
        if not text:
            return False, "טקסט ריק"
        
        if len(text.strip()) == 0:
            return False, "טקסט מכיל רק רווחים"
        
        processor = HebrewTextProcessor()
        hebrew_chars = sum(1 for char in text if processor.is_hebrew_char(char))
        
        if hebrew_chars == 0:
            return False, "הטקסט לא מכיל תווים עבריים"
        
        # Check for common encoding issues
        if '?' in text and hebrew_chars > 0:
            return False, "בעיית קידוד בטקסט"
        
        return True, "טקסט תקין"