"""
Configuration Management and Validation Utilities
"""

import json
import os
import yaml
from typing import Dict, Any, Optional, List, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
import jsonschema
from pathlib import Path
import threading
from datetime import datetime

class ConfigFormat(Enum):
    """Configuration file formats"""
    JSON = "json"
    YAML = "yaml"
    TOML = "toml"

class ValidationMode(Enum):
    """Configuration validation modes"""
    STRICT = "strict"
    LENIENT = "lenient"
    NONE = "none"

@dataclass
class ConfigValidationResult:
    """Configuration validation result"""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)

class ConfigValidator:
    """Configuration validation utilities"""
    
    def __init__(self, validation_mode: ValidationMode = ValidationMode.STRICT):
        self.validation_mode = validation_mode
        self.schemas = self._load_schemas()
    
    def _load_schemas(self) -> Dict[str, Dict[str, Any]]:
        """Load validation schemas"""
        return {
            'consciousness_engine': {
                'type': 'object',
                'required': ['emotion_engine', 'memory_engine', 'thought_engine', 'state_engine'],
                'properties': {
                    'emotion_engine': {
                        'type': 'object',
                        'required': ['enabled', 'max_emotions', 'decay_rate'],
                        'properties': {
                            'enabled': {'type': 'boolean'},
                            'max_emotions': {'type': 'integer', 'minimum': 1, 'maximum': 100},
                            'decay_rate': {'type': 'number', 'minimum': 0.0, 'maximum': 1.0},
                            'cultural_mapping': {'type': 'boolean'},
                            'hebrew_support': {'type': 'boolean'},
                            'interaction_matrix': {'type': 'object'}
                        }
                    },
                    'memory_engine': {
                        'type': 'object',
                        'required': ['enabled', 'max_memories_per_layer', 'consolidation_threshold'],
                        'properties': {
                            'enabled': {'type': 'boolean'},
                            'max_memories_per_layer': {
                                'type': 'array',
                                'items': {'type': 'integer', 'minimum': 1},
                                'minItems': 5,
                                'maxItems': 5
                            },
                            'consolidation_threshold': {'type': 'number', 'minimum': 0.0, 'maximum': 1.0},
                            'decay_rates': {
                                'type': 'array',
                                'items': {'type': 'number', 'minimum': 0.0, 'maximum': 1.0},
                                'minItems': 5,
                                'maxItems': 5
                            },
                            'auto_consolidation': {'type': 'boolean'},
                            'persistence_enabled': {'type': 'boolean'}
                        }
                    },
                    'thought_engine': {
                        'type': 'object',
                        'required': ['enabled', 'max_concurrent_thoughts', 'cognitive_load_limit'],
                        'properties': {
                            'enabled': {'type': 'boolean'},
                            'max_concurrent_thoughts': {'type': 'integer', 'minimum': 1, 'maximum': 50},
                            'cognitive_load_limit': {'type': 'number', 'minimum': 0.0, 'maximum': 1.0},
                            'thought_decay_rate': {'type': 'number', 'minimum': 0.0, 'maximum': 1.0},
                            'pattern_recognition': {'type': 'boolean'},
                            'stream_persistence': {'type': 'boolean'}
                        }
                    },
                    'state_engine': {
                        'type': 'object',
                        'required': ['enabled', 'default_level', 'transition_speed'],
                        'properties': {
                            'enabled': {'type': 'boolean'},
                            'default_level': {'type': 'integer', 'minimum': 0, 'maximum': 6},
                            'transition_speed': {'type': 'number', 'minimum': 0.1, 'maximum': 10.0},
                            'auto_transitions': {'type': 'boolean'},
                            'energy_tracking': {'type': 'boolean'},
                            'attention_management': {'type': 'boolean'}
                        }
                    },
                    'integration': {
                        'type': 'object',
                        'properties': {
                            'cross_component_learning': {'type': 'boolean'},
                            'pattern_correlation': {'type': 'boolean'},
                            'adaptive_responses': {'type': 'boolean'},
                            'cultural_adaptation': {'type': 'boolean'}
                        }
                    },
                    'logging': {
                        'type': 'object',
                        'properties': {
                            'enabled': {'type': 'boolean'},
                            'level': {'type': 'string', 'enum': ['debug', 'info', 'warning', 'error']},
                            'hebrew_support': {'type': 'boolean'},
                            'max_file_size': {'type': 'integer', 'minimum': 1024},
                            'backup_count': {'type': 'integer', 'minimum': 1, 'maximum': 10}
                        }
                    }
                }
            },
            'ui_config': {
                'type': 'object',
                'properties': {
                    'theme': {'type': 'string', 'enum': ['light', 'dark', 'auto']},
                    'language': {'type': 'string', 'enum': ['he', 'en', 'auto']},
                    'rtl_support': {'type': 'boolean'},
                    'animations_enabled': {'type': 'boolean'},
                    'update_frequency': {'type': 'integer', 'minimum': 100, 'maximum': 10000},
                    'chart_config': {
                        'type': 'object',
                        'properties': {
                            'color_scheme': {'type': 'string'},
                            'animation_duration': {'type': 'integer', 'minimum': 0, 'maximum': 5000}
                        }
                    }
                }
            }
        }
    
    def validate_config(self, config: Dict[str, Any], 
                       config_type: str = 'consciousness_engine') -> ConfigValidationResult:
        """Validate configuration against schema"""
        result = ConfigValidationResult(is_valid=True)
        
        if self.validation_mode == ValidationMode.NONE:
            return result
        
        # Get schema
        schema = self.schemas.get(config_type)
        if not schema:
            result.warnings.append(f"לא נמצא סכמת אימות עבור {config_type}")
            return result
        
        try:
            # Validate against JSON schema
            jsonschema.validate(config, schema)
            
            # Additional custom validations
            self._perform_custom_validations(config, config_type, result)
            
        except jsonschema.ValidationError as e:
            result.is_valid = False
            result.errors.append(f"שגיאת אימות: {e.message}")
            
            # Add suggestions based on error
            self._add_validation_suggestions(e, result)
        
        except Exception as e:
            result.is_valid = False
            result.errors.append(f"שגיאה כללית באימות: {str(e)}")
        
        return result
    
    def _perform_custom_validations(self, config: Dict[str, Any], 
                                   config_type: str, 
                                   result: ConfigValidationResult):
        """Perform custom validation logic"""
        if config_type == 'consciousness_engine':
            self._validate_consciousness_config(config, result)
        elif config_type == 'ui_config':
            self._validate_ui_config(config, result)
    
    def _validate_consciousness_config(self, config: Dict[str, Any], 
                                     result: ConfigValidationResult):
        """Validate consciousness engine specific configuration"""
        
        # Check memory layer configuration consistency
        memory_config = config.get('memory_engine', {})
        if 'max_memories_per_layer' in memory_config and 'decay_rates' in memory_config:
            max_memories = memory_config['max_memories_per_layer']
            decay_rates = memory_config['decay_rates']
            
            if len(max_memories) != len(decay_rates):
                result.errors.append("מספר שכבות הזיכרון לא תואם בין max_memories_per_layer ו-decay_rates")
            
            # Check that higher layers have lower limits (consolidation principle)
            for i in range(1, len(max_memories)):
                if max_memories[i] >= max_memories[i-1]:
                    result.warnings.append(f"שכבת זיכרון {i+1} צריכה להיות קטנה יותר משכבה {i}")
        
        # Check thought engine cognitive load
        thought_config = config.get('thought_engine', {})
        if 'cognitive_load_limit' in thought_config and 'max_concurrent_thoughts' in thought_config:
            load_limit = thought_config['cognitive_load_limit']
            max_thoughts = thought_config['max_concurrent_thoughts']
            
            # Warn if cognitive load might be too high
            theoretical_max_load = max_thoughts * 1.0  # Assuming max 1.0 per thought
            if load_limit < theoretical_max_load * 0.8:
                result.warnings.append("מגבלת העומס הקוגניטיבי נמוכה יחסית למספר המחשבות המקסימלי")
        
        # Check integration settings consistency
        integration_config = config.get('integration', {})
        if integration_config.get('cultural_adaptation') and not config.get('emotion_engine', {}).get('cultural_mapping'):
            result.warnings.append("התאמה תרבותית מופעלת אך מיפוי תרבותי ברגשות כבוי")
    
    def _validate_ui_config(self, config: Dict[str, Any], 
                           result: ConfigValidationResult):
        """Validate UI configuration"""
        
        # Check RTL/Hebrew consistency
        if config.get('language') == 'he' and not config.get('rtl_support'):
            result.warnings.append("שפה עברית נבחרה אך תמיכה ב-RTL כבויה")
        
        # Check update frequency sanity
        update_freq = config.get('update_frequency', 1000)
        if update_freq < 500:
            result.warnings.append("תדירות עדכון גבוהה מאוד - עלולה להשפיע על ביצועים")
        elif update_freq > 5000:
            result.warnings.append("תדירות עדכון נמוכה - הממשק עלול להיראות לא רספונסיבי")
    
    def _add_validation_suggestions(self, error: jsonschema.ValidationError, 
                                   result: ConfigValidationResult):
        """Add suggestions based on validation error"""
        if error.validator == 'required':
            missing_field = error.message.split("'")[1] if "'" in error.message else "unknown"
            result.suggestions.append(f"הוסף את השדה החסר: {missing_field}")
        
        elif error.validator == 'type':
            expected_type = error.validator_value
            result.suggestions.append(f"השדה צריך להיות מסוג {expected_type}")
        
        elif error.validator in ['minimum', 'maximum']:
            limit = error.validator_value
            result.suggestions.append(f"הערך צריך להיות {error.validator} {limit}")
        
        elif error.validator == 'enum':
            valid_values = ', '.join(error.validator_value)
            result.suggestions.append(f"ערכים תקינים: {valid_values}")

class SettingsManager:
    """Advanced settings management system"""
    
    def __init__(self, 
                 config_dir: str = "config",
                 auto_save: bool = True,
                 backup_enabled: bool = True):
        self.config_dir = Path(config_dir)
        self.auto_save = auto_save
        self.backup_enabled = backup_enabled
        
        # Create config directory
        self.config_dir.mkdir(exist_ok=True, parents=True)
        
        # Configuration cache
        self._config_cache = {}
        self._file_timestamps = {}
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Validator
        self.validator = ConfigValidator()
        
        # Change listeners
        self._change_listeners = []
    
    def load_config(self, config_name: str, 
                   format_type: ConfigFormat = ConfigFormat.JSON,
                   validate: bool = True) -> Tuple[Dict[str, Any], ConfigValidationResult]:
        """Load configuration from file"""
        
        config_file = self._get_config_path(config_name, format_type)
        
        with self._lock:
            # Check if file exists
            if not config_file.exists():
                return {}, ConfigValidationResult(
                    is_valid=False, 
                    errors=[f"קובץ קונפיגורציה לא נמצא: {config_file}"]
                )
            
            # Check if cached version is up to date
            file_mtime = config_file.stat().st_mtime
            cache_key = f"{config_name}_{format_type.value}"
            
            if (cache_key in self._config_cache and 
                cache_key in self._file_timestamps and
                self._file_timestamps[cache_key] >= file_mtime):
                
                cached_config = self._config_cache[cache_key]
                if validate:
                    validation_result = self.validator.validate_config(cached_config, config_name)
                    return cached_config, validation_result
                else:
                    return cached_config, ConfigValidationResult(is_valid=True)
            
            # Load from file
            try:
                config = self._load_file(config_file, format_type)
                
                # Update cache
                self._config_cache[cache_key] = config
                self._file_timestamps[cache_key] = file_mtime
                
                # Validate if requested
                validation_result = ConfigValidationResult(is_valid=True)
                if validate:
                    validation_result = self.validator.validate_config(config, config_name)
                
                return config, validation_result
                
            except Exception as e:
                return {}, ConfigValidationResult(
                    is_valid=False,
                    errors=[f"שגיאה בטעינת קונפיגורציה: {str(e)}"]
                )
    
    def save_config(self, config_name: str, config: Dict[str, Any],
                   format_type: ConfigFormat = ConfigFormat.JSON,
                   validate: bool = True,
                   create_backup: bool = None) -> ConfigValidationResult:
        """Save configuration to file"""
        
        if create_backup is None:
            create_backup = self.backup_enabled
        
        # Validate before saving
        validation_result = ConfigValidationResult(is_valid=True)
        if validate:
            validation_result = self.validator.validate_config(config, config_name)
            if not validation_result.is_valid:
                return validation_result
        
        config_file = self._get_config_path(config_name, format_type)
        
        with self._lock:
            try:
                # Create backup if enabled and file exists
                if create_backup and config_file.exists():
                    self._create_backup(config_file)
                
                # Save configuration
                self._save_file(config_file, config, format_type)
                
                # Update cache
                cache_key = f"{config_name}_{format_type.value}"
                self._config_cache[cache_key] = config.copy()
                self._file_timestamps[cache_key] = config_file.stat().st_mtime
                
                # Notify listeners
                self._notify_change_listeners(config_name, config)
                
                return validation_result
                
            except Exception as e:
                return ConfigValidationResult(
                    is_valid=False,
                    errors=[f"שגיאה בשמירת קונפיגורציה: {str(e)}"]
                )
    
    def get_setting(self, config_name: str, setting_path: str, 
                   default: Any = None) -> Any:
        """Get specific setting using dot notation (e.g., 'emotion_engine.max_emotions')"""
        
        config, _ = self.load_config(config_name, validate=False)
        
        # Navigate through nested structure
        current = config
        for key in setting_path.split('.'):
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
        
        return current
    
    def set_setting(self, config_name: str, setting_path: str, value: Any,
                   auto_save: bool = None) -> ConfigValidationResult:
        """Set specific setting using dot notation"""
        
        if auto_save is None:
            auto_save = self.auto_save
        
        config, validation_result = self.load_config(config_name, validate=False)
        
        if not validation_result.is_valid:
            return validation_result
        
        # Navigate and set value
        keys = setting_path.split('.')
        current = config
        
        # Navigate to parent
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        # Set final value
        current[keys[-1]] = value
        
        # Save if auto-save enabled
        if auto_save:
            return self.save_config(config_name, config)
        else:
            # Update cache only
            cache_key = f"{config_name}_json"
            with self._lock:
                self._config_cache[cache_key] = config
            return ConfigValidationResult(is_valid=True)
    
    def merge_configs(self, base_config: Dict[str, Any], 
                     override_config: Dict[str, Any]) -> Dict[str, Any]:
        """Merge two configurations with override taking precedence"""
        
        def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
            result = base.copy()
            
            for key, value in override.items():
                if (key in result and 
                    isinstance(result[key], dict) and 
                    isinstance(value, dict)):
                    result[key] = deep_merge(result[key], value)
                else:
                    result[key] = value
            
            return result
        
        return deep_merge(base_config, override_config)
    
    def create_config_template(self, config_name: str) -> Dict[str, Any]:
        """Create configuration template with default values"""
        
        templates = {
            'consciousness_engine': {
                'emotion_engine': {
                    'enabled': True,
                    'max_emotions': 15,
                    'decay_rate': 0.1,
                    'cultural_mapping': True,
                    'hebrew_support': True,
                    'interaction_matrix': {}
                },
                'memory_engine': {
                    'enabled': True,
                    'max_memories_per_layer': [100, 80, 60, 40, 20],
                    'consolidation_threshold': 0.7,
                    'decay_rates': [0.9, 0.7, 0.5, 0.3, 0.1],
                    'auto_consolidation': True,
                    'persistence_enabled': True
                },
                'thought_engine': {
                    'enabled': True,
                    'max_concurrent_thoughts': 10,
                    'cognitive_load_limit': 0.8,
                    'thought_decay_rate': 0.2,
                    'pattern_recognition': True,
                    'stream_persistence': True
                },
                'state_engine': {
                    'enabled': True,
                    'default_level': 3,
                    'transition_speed': 1.0,
                    'auto_transitions': True,
                    'energy_tracking': True,
                    'attention_management': True
                },
                'integration': {
                    'cross_component_learning': True,
                    'pattern_correlation': True,
                    'adaptive_responses': True,
                    'cultural_adaptation': True
                },
                'logging': {
                    'enabled': True,
                    'level': 'info',
                    'hebrew_support': True,
                    'max_file_size': 10485760,  # 10MB
                    'backup_count': 5
                }
            },
            'ui_config': {
                'theme': 'auto',
                'language': 'he',
                'rtl_support': True,
                'animations_enabled': True,
                'update_frequency': 1000,
                'chart_config': {
                    'color_scheme': 'consciousness',
                    'animation_duration': 300
                }
            }
        }
        
        return templates.get(config_name, {})
    
    def _get_config_path(self, config_name: str, format_type: ConfigFormat) -> Path:
        """Get full path to configuration file"""
        extension = format_type.value
        return self.config_dir / f"{config_name}.{extension}"
    
    def _load_file(self, file_path: Path, format_type: ConfigFormat) -> Dict[str, Any]:
        """Load configuration from file based on format"""
        
        with open(file_path, 'r', encoding='utf-8') as f:
            if format_type == ConfigFormat.JSON:
                return json.load(f)
            elif format_type == ConfigFormat.YAML:
                return yaml.safe_load(f)
            elif format_type == ConfigFormat.TOML:
                import toml
                return toml.load(f)
            else:
                raise ValueError(f"פורמט לא נתמך: {format_type}")
    
    def _save_file(self, file_path: Path, config: Dict[str, Any], 
                  format_type: ConfigFormat):
        """Save configuration to file based on format"""
        
        with open(file_path, 'w', encoding='utf-8') as f:
            if format_type == ConfigFormat.JSON:
                json.dump(config, f, ensure_ascii=False, indent=2)
            elif format_type == ConfigFormat.YAML:
                yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
            elif format_type == ConfigFormat.TOML:
                import toml
                toml.dump(config, f)
            else:
                raise ValueError(f"פורמט לא נתמך: {format_type}")
    
    def _create_backup(self, file_path: Path):
        """Create backup of configuration file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = file_path.parent / f"{file_path.stem}_backup_{timestamp}{file_path.suffix}"
        
        import shutil
        shutil.copy2(file_path, backup_path)
        
        # Clean old backups (keep only last 10)
        backup_pattern = f"{file_path.stem}_backup_*{file_path.suffix}"
        backups = list(file_path.parent.glob(backup_pattern))
        backups.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        
        for old_backup in backups[10:]:
            old_backup.unlink()
    
    def add_change_listener(self, callback: callable):
        """Add listener for configuration changes"""
        with self._lock:
            self._change_listeners.append(callback)
    
    def remove_change_listener(self, callback: callable):
        """Remove configuration change listener"""
        with self._lock:
            if callback in self._change_listeners:
                self._change_listeners.remove(callback)
    
    def _notify_change_listeners(self, config_name: str, config: Dict[str, Any]):
        """Notify all change listeners"""
        for listener in self._change_listeners:
            try:
                listener(config_name, config)
            except Exception:
                # Ignore listener errors
                pass
    
    def clear_cache(self):
        """Clear configuration cache"""
        with self._lock:
            self._config_cache.clear()
            self._file_timestamps.clear()
    
    def get_cache_info(self) -> Dict[str, Any]:
        """Get information about cached configurations"""
        with self._lock:
            return {
                'cached_configs': list(self._config_cache.keys()),
                'cache_size': len(self._config_cache),
                'last_access_times': self._file_timestamps.copy()
            }