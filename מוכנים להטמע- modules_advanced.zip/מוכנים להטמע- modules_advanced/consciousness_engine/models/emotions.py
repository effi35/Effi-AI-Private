#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
😊 Emotion Models - מודלי רגשות מתקדמים
=====================================

מערכת רגשות מתקדמת עם 15 רגשות בסיסיים, עוצמות דינמיות,
והשפעות הדדיות בין רגשות שונים.

תכונות:
- 15 רגשות בסיסיים מפורטים
- מטריצת השפעות בין רגשות  
- התפתחות רגשית לאורך זמן
- רגשות מורכבים (שילובים)
- זיכרון רגשי ולמידה
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime, timedelta
import json
import math

class EmotionType(Enum):
    """15 רגשות בסיסיים במנוע התודעה"""
    
    # רגשות בסיסיים (Plutchik's Wheel)
    JOY = "joy"                    # שמחה - תחושת אושר ושביעות רצון
    SADNESS = "sadness"            # עצב - תחושת אובדן או אכזבה
    ANGER = "anger"                # כעס - תגובה לעווינות או הפרה
    FEAR = "fear"                  # פחד - תגובה לאיום או סכנה
    SURPRISE = "surprise"          # הפתעה - תגובה לבלתי צפוי
    DISGUST = "disgust"            # גועל - תגובה דחייה
    TRUST = "trust"                # אמון - תחושת ביטחון וסמכה
    ANTICIPATION = "anticipation"   # ציפייה - תחושת ציפיה חיובית
    
    # רגשות מורכבים נוספים
    CURIOSITY = "curiosity"        # סקרנות - רצון ללמוד ולחקור
    CONFUSION = "confusion"        # בלבול - אי הבנה או אי ודאות
    EXCITEMENT = "excitement"      # התרגשות - אנרגיה חיובית גבוהה
    CALM = "calm"                 # רוגע - מצב של שלווה ושקט
    EMPATHY = "empathy"           # אמפתיה - הבנה ושיתוף ברגשות אחרים
    CREATIVITY = "creativity"      # יצירתיות - רצון ליצור ולחדש
    CONTEMPLATION = "contemplation" # הרהור - מחשבה עמוקה ופילוסופית

@dataclass
class EmotionIntensity:
    """עוצמת רגש עם פרמטרים מתקדמים"""
    
    level: float = 0.0              # רמת עוצמה (0.0 - 1.0)
    stability: float = 0.5          # יציבות הרגש (0.0 - 1.0)
    duration: float = 60.0          # משך זמן ברירת מחדל (שניות)
    decay_rate: float = 0.95        # קצב דעיכה (0.0 - 1.0)
    
    def decay(self, time_passed: float) -> float:
        """חישוב דעיכת רגש לאורך זמן"""
        decay_factor = math.pow(self.decay_rate, time_passed / 60.0)
        return max(0.0, self.level * decay_factor)
    
    def amplify(self, factor: float) -> 'EmotionIntensity':
        """הגברת עוצמת הרגש"""
        new_level = min(1.0, self.level * factor)
        return EmotionIntensity(
            level=new_level,
            stability=self.stability,
            duration=self.duration * factor,
            decay_rate=self.decay_rate
        )

@dataclass
class EmotionState:
    """מצב רגשי מלא עם מטא-דאטה"""
    
    emotion_type: EmotionType
    intensity: EmotionIntensity
    timestamp: datetime = field(default_factory=datetime.now)
    trigger: Optional[str] = None    # מה גרם לרגש
    context: Dict[str, Any] = field(default_factory=dict)
    related_memories: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון לשמירה"""
        return {
            'emotion_type': self.emotion_type.value,
            'intensity': {
                'level': self.intensity.level,
                'stability': self.intensity.stability,
                'duration': self.intensity.duration,
                'decay_rate': self.intensity.decay_rate
            },
            'timestamp': self.timestamp.isoformat(),
            'trigger': self.trigger,
            'context': self.context,
            'related_memories': self.related_memories
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EmotionState':
        """יצירה ממילון"""
        intensity_data = data['intensity']
        intensity = EmotionIntensity(
            level=intensity_data['level'],
            stability=intensity_data['stability'],
            duration=intensity_data['duration'],
            decay_rate=intensity_data['decay_rate']
        )
        
        return cls(
            emotion_type=EmotionType(data['emotion_type']),
            intensity=intensity,
            timestamp=datetime.fromisoformat(data['timestamp']),
            trigger=data.get('trigger'),
            context=data.get('context', {}),
            related_memories=data.get('related_memories', [])
        )

class EmotionInteractionMatrix:
    """מטריצת השפעות הדדיות בין רגשות"""
    
    def __init__(self):
        # מטריצת השפעות: כיצד רגש A משפיע על רגש B
        self.interactions = {
            # שמחה מחזקת אמון וסקרנות, מחלישה עצב ופחד
            EmotionType.JOY: {
                EmotionType.TRUST: 0.3,
                EmotionType.CURIOSITY: 0.2,
                EmotionType.EXCITEMENT: 0.4,
                EmotionType.SADNESS: -0.5,
                EmotionType.FEAR: -0.3,
                EmotionType.ANGER: -0.2
            },
            
            # עצב מחליש רגשות חיוביים
            EmotionType.SADNESS: {
                EmotionType.JOY: -0.6,
                EmotionType.EXCITEMENT: -0.4,
                EmotionType.CURIOSITY: -0.2,
                EmotionType.EMPATHY: 0.3,
                EmotionType.CONTEMPLATION: 0.2
            },
            
            # כעס מחזק עוצמה, מחליש אמון
            EmotionType.ANGER: {
                EmotionType.TRUST: -0.5,
                EmotionType.FEAR: 0.2,
                EmotionType.DISGUST: 0.3,
                EmotionType.CALM: -0.7,
                EmotionType.EMPATHY: -0.3
            },
            
            # פחד מחליש ביטחון עצמי
            EmotionType.FEAR: {
                EmotionType.TRUST: -0.4,
                EmotionType.CURIOSITY: -0.3,
                EmotionType.CALM: -0.5,
                EmotionType.ANTICIPATION: -0.2
            },
            
            # סקרנות מחזקת למידה ויצירתיות
            EmotionType.CURIOSITY: {
                EmotionType.EXCITEMENT: 0.3,
                EmotionType.CREATIVITY: 0.4,
                EmotionType.ANTICIPATION: 0.2,
                EmotionType.CONFUSION: -0.1
            },
            
            # רוגע מחזק חשיבה ואמפתיה
            EmotionType.CALM: {
                EmotionType.CONTEMPLATION: 0.4,
                EmotionType.EMPATHY: 0.3,
                EmotionType.CREATIVITY: 0.2,
                EmotionType.ANGER: -0.6,
                EmotionType.FEAR: -0.4
            }
        }
    
    def get_interaction_effect(self, source: EmotionType, target: EmotionType) -> float:
        """קבלת השפעה של רגש מקור על רגש יעד"""
        if source in self.interactions:
            return self.interactions[source].get(target, 0.0)
        return 0.0
    
    def apply_interactions(self, emotions: Dict[EmotionType, EmotionIntensity]) -> Dict[EmotionType, EmotionIntensity]:
        """החלת השפעות הדדיות על מערכת רגשות"""
        new_emotions = {}
        
        for emotion_type, intensity in emotions.items():
            total_effect = 0.0
            
            # חישוב השפעה מכל הרגשות האחרים
            for other_emotion, other_intensity in emotions.items():
                if other_emotion != emotion_type:
                    interaction_strength = self.get_interaction_effect(other_emotion, emotion_type)
                    effect = interaction_strength * other_intensity.level
                    total_effect += effect
            
            # החלת ההשפעה על עוצמת הרגש
            new_level = max(0.0, min(1.0, intensity.level + total_effect * 0.1))
            
            new_emotions[emotion_type] = EmotionIntensity(
                level=new_level,
                stability=intensity.stability,
                duration=intensity.duration,
                decay_rate=intensity.decay_rate
            )
        
        return new_emotions

@dataclass
class EmotionConfig:
    """תצורת מערכת הרגשות"""
    
    # הגדרות בסיסיות
    enable_emotion_interactions: bool = True
    enable_emotion_memory: bool = True
    enable_complex_emotions: bool = True
    
    # פרמטרי זמן
    emotion_update_interval: float = 1.0      # שניות
    emotion_decay_enabled: bool = True
    memory_retention_days: int = 30
    
    # עוצמויות ברירת מחדל
    default_intensity: float = 0.3
    max_emotion_intensity: float = 1.0
    min_emotion_threshold: float = 0.01
    
    # הגדרות למידה
    emotion_learning_rate: float = 0.1
    pattern_recognition_enabled: bool = True
    adaptive_responses: bool = True
    
    # רגשות ברירת מחדל
    baseline_emotions: Dict[str, float] = field(default_factory=lambda: {
        EmotionType.CALM.value: 0.5,
        EmotionType.CURIOSITY.value: 0.3,
        EmotionType.TRUST.value: 0.4
    })
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        return {
            'enable_emotion_interactions': self.enable_emotion_interactions,
            'enable_emotion_memory': self.enable_emotion_memory,
            'enable_complex_emotions': self.enable_complex_emotions,
            'emotion_update_interval': self.emotion_update_interval,
            'emotion_decay_enabled': self.emotion_decay_enabled,
            'memory_retention_days': self.memory_retention_days,
            'default_intensity': self.default_intensity,
            'max_emotion_intensity': self.max_emotion_intensity,
            'min_emotion_threshold': self.min_emotion_threshold,
            'emotion_learning_rate': self.emotion_learning_rate,
            'pattern_recognition_enabled': self.pattern_recognition_enabled,
            'adaptive_responses': self.adaptive_responses,
            'baseline_emotions': self.baseline_emotions
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EmotionConfig':
        """יצירה ממילון"""
        return cls(**data)

class EmotionPattern:
    """דפוס רגשי - זיהוי תבניות בהתנהגות רגשית"""
    
    def __init__(self, name: str):
        self.name = name
        self.sequence: List[EmotionType] = []
        self.triggers: List[str] = []
        self.frequency: int = 0
        self.confidence: float = 0.0
        self.last_occurrence: Optional[datetime] = None
    
    def add_occurrence(self, emotions: List[EmotionType], trigger: str):
        """הוספת התרחשות של הדפוס"""
        self.sequence = emotions
        if trigger not in self.triggers:
            self.triggers.append(trigger)
        self.frequency += 1
        self.last_occurrence = datetime.now()
        
        # עדכון רמת ביטחון
        self.confidence = min(1.0, self.frequency * 0.1)
    
    def matches(self, recent_emotions: List[EmotionType], threshold: float = 0.7) -> bool:
        """בדיקה האם רצף רגשות תואם לדפוס"""
        if len(recent_emotions) < len(self.sequence):
            return False
        
        matches = 0
        for i, emotion in enumerate(self.sequence):
            if i < len(recent_emotions) and recent_emotions[i] == emotion:
                matches += 1
        
        similarity = matches / len(self.sequence)
        return similarity >= threshold

# פונקציות עזר לעבודה עם רגשות
def create_emotion_from_text(text: str, intensity: float = 0.5) -> Optional[EmotionState]:
    """יצירת רגש מטקסט (ניתוח סנטימנט בסיסי)"""
    
    # מילות מפתח לזיהוי רגשות בעברית ואנגלית
    emotion_keywords = {
        EmotionType.JOY: ['שמח', 'שמחה', 'אושר', 'נהדר', 'מעולה', 'happy', 'joy', 'great', 'excellent'],
        EmotionType.SADNESS: ['עצוב', 'עצב', 'מצטער', 'רע', 'כואב', 'sad', 'sorry', 'bad', 'hurt'],
        EmotionType.ANGER: ['כועס', 'כעס', 'זעם', 'מתרגז', 'angry', 'mad', 'furious', 'rage'],
        EmotionType.FEAR: ['פחד', 'מפחד', 'חושש', 'דאגה', 'fear', 'afraid', 'worried', 'scared'],
        EmotionType.SURPRISE: ['הפתעה', 'מופתע', 'לא יאמן', 'surprise', 'surprised', 'amazing'],
        EmotionType.CURIOSITY: ['סקרן', 'סקרנות', 'מעניין', 'למה', 'איך', 'curious', 'interesting', 'why', 'how'],
        EmotionType.CALM: ['רגוע', 'שקט', 'נינוח', 'calm', 'peaceful', 'relaxed'],
        EmotionType.EXCITEMENT: ['מתרגש', 'התרגשות', 'נרגש', 'excited', 'thrilled', 'enthusiasm']
    }
    
    text_lower = text.lower()
    
    for emotion_type, keywords in emotion_keywords.items():
        for keyword in keywords:
            if keyword in text_lower:
                emotion_intensity = EmotionIntensity(level=intensity)
                return EmotionState(
                    emotion_type=emotion_type,
                    intensity=emotion_intensity,
                    trigger=f"text_analysis: {keyword}",
                    context={'original_text': text}
                )
    
    # אם לא נמצא רגש ספציפי, החזר רוגע
    return EmotionState(
        emotion_type=EmotionType.CALM,
        intensity=EmotionIntensity(level=0.3),
        trigger="default_response",
        context={'original_text': text}
    )

def blend_emotions(emotion1: EmotionState, emotion2: EmotionState, 
                  ratio: float = 0.5) -> EmotionState:
    """ערבוב שני רגשות ליצירת רגש מורכב"""
    
    # חישוב עוצמה ממוצעת
    blended_intensity = EmotionIntensity(
        level=(emotion1.intensity.level * ratio + emotion2.intensity.level * (1 - ratio)),
        stability=min(emotion1.intensity.stability, emotion2.intensity.stability),
        duration=max(emotion1.intensity.duration, emotion2.intensity.duration),
        decay_rate=(emotion1.intensity.decay_rate + emotion2.intensity.decay_rate) / 2
    )
    
    # בחירת רגש דומיננטי
    dominant_emotion = emotion1 if emotion1.intensity.level > emotion2.intensity.level else emotion2
    
    return EmotionState(
        emotion_type=dominant_emotion.emotion_type,
        intensity=blended_intensity,
        trigger=f"blend: {emotion1.emotion_type.value} + {emotion2.emotion_type.value}",
        context={
            'blend_ratio': ratio,
            'source_emotions': [emotion1.emotion_type.value, emotion2.emotion_type.value]
        }
    )

__all__ = [
    'EmotionType', 'EmotionIntensity', 'EmotionState', 'EmotionConfig',
    'EmotionInteractionMatrix', 'EmotionPattern',
    'create_emotion_from_text', 'blend_emotions'
]