"""
Thought Models for Consciousness Engine
Implements thought patterns, cognitive processes, and mental states
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Set, Callable
from datetime import datetime, timedelta
import uuid
import json


class ThoughtType(Enum):
    """Types of thoughts in consciousness"""
    ANALYTICAL = "analytical"        # Logical reasoning and analysis
    CREATIVE = "creative"           # Creative and imaginative thoughts
    EMOTIONAL = "emotional"         # Emotion-driven thoughts
    INTUITIVE = "intuitive"         # Gut feelings and insights
    REFLECTIVE = "reflective"       # Self-reflection and introspection
    GOAL_ORIENTED = "goal_oriented" # Task and goal-focused thoughts
    ASSOCIATIVE = "associative"     # Connected and linked thoughts
    ABSTRACT = "abstract"           # Abstract concepts and ideas
    CONCRETE = "concrete"           # Specific and tangible thoughts
    METACOGNITIVE = "metacognitive" # Thinking about thinking


class ThoughtIntensity(Enum):
    """Intensity levels for thoughts"""
    MINIMAL = 1
    LOW = 2
    MODERATE = 3
    HIGH = 4
    INTENSE = 5


class ThoughtState(Enum):
    """States of thought processing"""
    EMERGING = "emerging"           # Thought is forming
    ACTIVE = "active"              # Currently being processed
    SUSTAINED = "sustained"        # Maintained focus
    FADING = "fading"             # Losing attention
    COMPLETED = "completed"        # Processing finished
    INTERRUPTED = "interrupted"    # Stopped before completion
    DORMANT = "dormant"           # Stored but inactive


class CognitiveProcess(Enum):
    """Types of cognitive processes"""
    PERCEPTION = "perception"       # Processing sensory input
    ATTENTION = "attention"         # Focusing on specific content
    MEMORY_RETRIEVAL = "memory_retrieval"  # Accessing stored information
    REASONING = "reasoning"         # Logical thinking processes
    PLANNING = "planning"          # Future-oriented thinking
    DECISION_MAKING = "decision_making"  # Choosing between options
    PROBLEM_SOLVING = "problem_solving"  # Addressing challenges
    LEARNING = "learning"          # Acquiring new knowledge
    IMAGINATION = "imagination"     # Creating mental imagery
    EVALUATION = "evaluation"      # Assessing and judging


@dataclass
class ThoughtContent:
    """Content and data of a thought"""
    primary_content: Any
    secondary_content: List[Any] = field(default_factory=list)
    content_type: str = "text"  # text, image, concept, memory_reference, etc.
    language: str = "mixed"  # Hebrew, English, mixed
    
    # Semantic information
    keywords: Set[str] = field(default_factory=set)
    concepts: Set[str] = field(default_factory=set)
    entities: Set[str] = field(default_factory=set)
    
    def add_keyword(self, keyword: str):
        """Add keyword to thought content"""
        self.keywords.add(keyword.lower())
        
    def add_concept(self, concept: str):
        """Add concept to thought content"""
        self.concepts.add(concept.lower())
        
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "primary_content": str(self.primary_content),
            "secondary_content": [str(item) for item in self.secondary_content],
            "content_type": self.content_type,
            "language": self.language,
            "keywords": list(self.keywords),
            "concepts": list(self.concepts),
            "entities": list(self.entities)
        }


@dataclass
class ThoughtConnection:
    """Connection between thoughts"""
    target_thought_id: str
    connection_type: str  # causal, associative, oppositional, supportive, etc.
    strength: float  # 0.0 to 1.0
    bidirectional: bool = False
    created_at: datetime = field(default_factory=datetime.now)
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "target_thought_id": self.target_thought_id,
            "connection_type": self.connection_type,
            "strength": self.strength,
            "bidirectional": self.bidirectional,
            "created_at": self.created_at.isoformat()
        }


@dataclass
class Thought:
    """Individual thought in the consciousness system"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: ThoughtContent = field(default_factory=lambda: ThoughtContent(""))
    thought_type: ThoughtType = ThoughtType.ANALYTICAL
    intensity: ThoughtIntensity = ThoughtIntensity.MODERATE
    state: ThoughtState = ThoughtState.EMERGING
    
    # Temporal information
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    duration: timedelta = field(default_factory=lambda: timedelta(seconds=0))
    
    # Cognitive processing
    cognitive_processes: Set[CognitiveProcess] = field(default_factory=set)
    attention_level: float = 1.0  # 0.0 to 1.0
    confidence: float = 0.5  # 0.0 to 1.0
    
    # Emotional aspects
    emotional_charge: float = 0.0  # -1.0 (negative) to 1.0 (positive)
    emotional_intensity: float = 0.0  # 0.0 to 1.0
    associated_emotions: Set[str] = field(default_factory=set)
    
    # Connections and relationships
    connections: List[ThoughtConnection] = field(default_factory=list)
    parent_thought_id: Optional[str] = None
    child_thought_ids: List[str] = field(default_factory=list)
    
    # Context and metadata
    context: Dict[str, Any] = field(default_factory=dict)
    tags: Set[str] = field(default_factory=set)
    priority: int = 3  # 1-5, 5 being highest priority
    
    # Memory associations
    related_memory_ids: List[str] = field(default_factory=list)
    
    def activate(self):
        """Activate thought for processing"""
        self.state = ThoughtState.ACTIVE
        self.last_active = datetime.now()
        
    def sustain(self):
        """Sustain thought processing"""
        if self.state == ThoughtState.ACTIVE:
            self.state = ThoughtState.SUSTAINED
            self.duration += datetime.now() - self.last_active
            self.last_active = datetime.now()
            
    def fade(self):
        """Begin fading thought"""
        self.state = ThoughtState.FADING
        self.attention_level *= 0.8  # Reduce attention
        
    def complete(self):
        """Mark thought as completed"""
        self.state = ThoughtState.COMPLETED
        self.duration += datetime.now() - self.last_active
        
    def interrupt(self):
        """Interrupt thought processing"""
        self.state = ThoughtState.INTERRUPTED
        self.duration += datetime.now() - self.last_active
        
    def add_connection(self, target_id: str, connection_type: str, 
                      strength: float, bidirectional: bool = False):
        """Add connection to another thought"""
        connection = ThoughtConnection(
            target_thought_id=target_id,
            connection_type=connection_type,
            strength=strength,
            bidirectional=bidirectional
        )
        self.connections.append(connection)
        
    def add_cognitive_process(self, process: CognitiveProcess):
        """Add cognitive process to thought"""
        self.cognitive_processes.add(process)
        
    def update_confidence(self, new_evidence: float):
        """Update confidence based on new evidence"""
        # Bayesian-like update
        self.confidence = (self.confidence + new_evidence) / 2
        self.confidence = max(0.0, min(1.0, self.confidence))
        
    def get_age(self) -> timedelta:
        """Get age of thought"""
        return datetime.now() - self.created_at
        
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "id": self.id,
            "content": self.content.serialize(),
            "thought_type": self.thought_type.value,
            "intensity": self.intensity.value,
            "state": self.state.value,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "duration": self.duration.total_seconds(),
            "cognitive_processes": [proc.value for proc in self.cognitive_processes],
            "attention_level": self.attention_level,
            "confidence": self.confidence,
            "emotional_charge": self.emotional_charge,
            "emotional_intensity": self.emotional_intensity,
            "associated_emotions": list(self.associated_emotions),
            "connections": [conn.serialize() for conn in self.connections],
            "parent_thought_id": self.parent_thought_id,
            "child_thought_ids": self.child_thought_ids,
            "context": self.context,
            "tags": list(self.tags),
            "priority": self.priority,
            "related_memory_ids": self.related_memory_ids
        }


@dataclass
class ThoughtStream:
    """Stream of thoughts in consciousness"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "Main Stream"
    thoughts: Dict[str, Thought] = field(default_factory=dict)
    active_thoughts: List[str] = field(default_factory=list)  # IDs of active thoughts
    
    # Stream properties
    focus_level: float = 1.0  # Overall focus of the stream
    coherence: float = 0.5   # How well thoughts connect
    creativity: float = 0.5  # Creative vs analytical bias
    
    # Processing limits
    max_active_thoughts: int = 7  # Working memory limit
    max_total_thoughts: int = 100  # Total thoughts to keep
    
    def add_thought(self, thought: Thought) -> bool:
        """Add thought to stream"""
        # Check if we need to remove old thoughts
        if len(self.thoughts) >= self.max_total_thoughts:
            self._evict_old_thoughts()
            
        self.thoughts[thought.id] = thought
        
        # Activate if there's space
        if len(self.active_thoughts) < self.max_active_thoughts:
            self.activate_thought(thought.id)
            
        return True
        
    def activate_thought(self, thought_id: str) -> bool:
        """Activate a thought for processing"""
        if thought_id not in self.thoughts:
            return False
            
        if len(self.active_thoughts) >= self.max_active_thoughts:
            # Deactivate least important active thought
            self._deactivate_least_important()
            
        if thought_id not in self.active_thoughts:
            self.active_thoughts.append(thought_id)
            self.thoughts[thought_id].activate()
            
        return True
        
    def _deactivate_least_important(self):
        """Deactivate the least important active thought"""
        if not self.active_thoughts:
            return
            
        # Find thought with lowest priority and attention
        least_important = min(
            self.active_thoughts,
            key=lambda tid: (
                self.thoughts[tid].priority + 
                self.thoughts[tid].attention_level
            )
        )
        
        self.deactivate_thought(least_important)
        
    def deactivate_thought(self, thought_id: str):
        """Deactivate a thought"""
        if thought_id in self.active_thoughts:
            self.active_thoughts.remove(thought_id)
            if thought_id in self.thoughts:
                self.thoughts[thought_id].fade()
                
    def _evict_old_thoughts(self):
        """Remove old, unimportant thoughts"""
        # Sort by importance (combination of priority, confidence, and age)
        sorted_thoughts = sorted(
            self.thoughts.values(),
            key=lambda t: (
                t.priority * t.confidence * 
                (1.0 / (t.get_age().days + 1))
            )
        )
        
        # Remove the least important 20%
        remove_count = max(1, len(sorted_thoughts) // 5)
        for thought in sorted_thoughts[:remove_count]:
            if thought.id in self.active_thoughts:
                self.deactivate_thought(thought.id)
            del self.thoughts[thought.id]
            
    def get_active_thoughts(self) -> List[Thought]:
        """Get currently active thoughts"""
        return [self.thoughts[tid] for tid in self.active_thoughts 
                if tid in self.thoughts]
                
    def find_related_thoughts(self, thought_id: str, 
                            max_results: int = 10) -> List[Thought]:
        """Find thoughts related to given thought"""
        if thought_id not in self.thoughts:
            return []
            
        base_thought = self.thoughts[thought_id]
        related = []
        
        # Check direct connections
        for connection in base_thought.connections:
            if connection.target_thought_id in self.thoughts:
                related.append((
                    self.thoughts[connection.target_thought_id],
                    connection.strength
                ))
                
        # Check content similarity (simplified)
        for thought in self.thoughts.values():
            if thought.id == thought_id:
                continue
                
            # Simple keyword overlap
            base_keywords = base_thought.content.keywords
            other_keywords = thought.content.keywords
            overlap = len(base_keywords & other_keywords)
            
            if overlap > 0:
                similarity = overlap / len(base_keywords | other_keywords)
                related.append((thought, similarity))
                
        # Sort by strength/similarity and return top results
        related.sort(key=lambda x: x[1], reverse=True)
        return [thought for thought, _ in related[:max_results]]
        
    def update_coherence(self):
        """Update stream coherence based on thought connections"""
        if len(self.thoughts) < 2:
            self.coherence = 1.0
            return
            
        total_connections = 0
        possible_connections = len(self.thoughts) * (len(self.thoughts) - 1)
        
        for thought in self.thoughts.values():
            total_connections += len(thought.connections)
            
        self.coherence = min(1.0, total_connections / possible_connections)
        
    def process_stream(self):
        """Process the thought stream"""
        # Update active thoughts
        for thought_id in self.active_thoughts[:]:
            thought = self.thoughts.get(thought_id)
            if thought:
                # Age-based fading
                if thought.get_age() > timedelta(minutes=10):
                    thought.fade()
                    
                # Attention decay
                thought.attention_level *= 0.95
                
                # Remove if attention too low
                if thought.attention_level < 0.1:
                    self.deactivate_thought(thought_id)
                    
        # Update stream properties
        self.update_coherence()
        
    def get_stream_summary(self) -> Dict[str, Any]:
        """Get summary of stream state"""
        active_thoughts = self.get_active_thoughts()
        
        return {
            "total_thoughts": len(self.thoughts),
            "active_thoughts": len(active_thoughts),
            "focus_level": self.focus_level,
            "coherence": self.coherence,
            "creativity": self.creativity,
            "primary_themes": self._extract_themes(),
            "dominant_emotions": self._extract_emotions(),
            "cognitive_processes": self._extract_processes()
        }
        
    def _extract_themes(self) -> List[str]:
        """Extract dominant themes from active thoughts"""
        all_keywords = set()
        for thought in self.get_active_thoughts():
            all_keywords.update(thought.content.keywords)
            
        # Return most common keywords (simplified)
        return list(all_keywords)[:10]
        
    def _extract_emotions(self) -> List[str]:
        """Extract dominant emotions from active thoughts"""
        all_emotions = set()
        for thought in self.get_active_thoughts():
            all_emotions.update(thought.associated_emotions)
            
        return list(all_emotions)[:5]
        
    def _extract_processes(self) -> List[str]:
        """Extract active cognitive processes"""
        all_processes = set()
        for thought in self.get_active_thoughts():
            all_processes.update(thought.cognitive_processes)
            
        return [proc.value for proc in all_processes]


@dataclass
class ThoughtPattern:
    """Recurring patterns in thought processes"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    pattern_type: str = "sequential"  # sequential, parallel, cyclical, branching
    
    # Pattern definition
    thought_sequence: List[ThoughtType] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)  # What triggers this pattern
    outcomes: List[str] = field(default_factory=list)  # Expected outcomes
    
    # Pattern metrics
    frequency: int = 0  # How often this pattern occurs
    success_rate: float = 0.0  # How often it leads to expected outcomes
    average_duration: timedelta = field(default_factory=lambda: timedelta(minutes=5))
    
    # Learning and adaptation
    adaptations: List[Dict[str, Any]] = field(default_factory=list)
    
    def matches_sequence(self, recent_thoughts: List[Thought]) -> float:
        """Check if recent thoughts match this pattern"""
        if len(recent_thoughts) < len(self.thought_sequence):
            return 0.0
            
        matches = 0
        for i, expected_type in enumerate(self.thought_sequence):
            if i < len(recent_thoughts):
                if recent_thoughts[i].thought_type == expected_type:
                    matches += 1
                    
        return matches / len(self.thought_sequence)
        
    def activate_pattern(self, context: Dict[str, Any] = None):
        """Activate this thought pattern"""
        self.frequency += 1
        # Could trigger specific thought generation based on pattern
        
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "id": self.id,
            "name": self.name,
            "pattern_type": self.pattern_type,
            "thought_sequence": [tt.value for tt in self.thought_sequence],
            "triggers": self.triggers,
            "outcomes": self.outcomes,
            "frequency": self.frequency,
            "success_rate": self.success_rate,
            "average_duration": self.average_duration.total_seconds(),
            "adaptations": self.adaptations
        }