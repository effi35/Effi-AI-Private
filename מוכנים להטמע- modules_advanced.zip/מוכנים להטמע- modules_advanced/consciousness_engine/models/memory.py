"""
Memory Models for Consciousness Engine
Implements 5-layer memory system with different types and capabilities
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timedelta
import json
import uuid


class MemoryType(Enum):
    """Types of memory in the consciousness system"""
    WORKING = "working"           # Current active thoughts and processing
    SHORT_TERM = "short_term"     # Recent experiences and interactions
    EPISODIC = "episodic"         # Specific events and experiences
    SEMANTIC = "semantic"         # General knowledge and facts
    PROCEDURAL = "procedural"     # Skills and procedures


class MemoryImportance(Enum):
    """Importance levels for memory consolidation"""
    CRITICAL = 5
    HIGH = 4
    MEDIUM = 3
    LOW = 2
    MINIMAL = 1


class MemoryState(Enum):
    """States of memory items"""
    ACTIVE = "active"
    CONSOLIDATING = "consolidating"
    CONSOLIDATED = "consolidated"
    DECAYING = "decaying"
    ARCHIVED = "archived"


@dataclass
class MemoryContent:
    """Core content of a memory item"""
    data: Any
    content_type: str  # text, image, audio, structured_data, etc.
    encoding: str = "utf-8"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "data": self.data if isinstance(self.data, (str, int, float, bool, list, dict)) else str(self.data),
            "content_type": self.content_type,
            "encoding": self.encoding,
            "metadata": self.metadata
        }


@dataclass
class MemoryAssociation:
    """Association between memory items"""
    target_id: str
    association_type: str  # semantic, temporal, causal, emotional, etc.
    strength: float  # 0.0 to 1.0
    created_at: datetime = field(default_factory=datetime.now)
    last_accessed: datetime = field(default_factory=datetime.now)
    
    def decay_strength(self, decay_rate: float = 0.01):
        """Apply time-based decay to association strength"""
        time_since_access = datetime.now() - self.last_accessed
        days_passed = time_since_access.days
        self.strength = max(0.0, self.strength - (decay_rate * days_passed))


@dataclass
class MemoryItem:
    """Individual memory item in the consciousness system"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: MemoryContent = field(default_factory=lambda: MemoryContent("", "text"))
    memory_type: MemoryType = MemoryType.WORKING
    importance: MemoryImportance = MemoryImportance.MEDIUM
    state: MemoryState = MemoryState.ACTIVE
    
    # Temporal information
    created_at: datetime = field(default_factory=datetime.now)
    last_accessed: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    
    # Associations and relationships
    associations: List[MemoryAssociation] = field(default_factory=list)
    tags: Set[str] = field(default_factory=set)
    
    # Emotional and contextual information
    emotional_valence: float = 0.0  # -1.0 (negative) to 1.0 (positive)
    emotional_intensity: float = 0.0  # 0.0 to 1.0
    context: Dict[str, Any] = field(default_factory=dict)
    
    # Memory strength and consolidation
    strength: float = 1.0  # 0.0 to 1.0
    consolidation_score: float = 0.0  # How well consolidated this memory is
    
    def access(self):
        """Record memory access"""
        self.last_accessed = datetime.now()
        self.access_count += 1
        
    def add_association(self, target_id: str, association_type: str, strength: float):
        """Add association to another memory item"""
        association = MemoryAssociation(
            target_id=target_id,
            association_type=association_type,
            strength=strength
        )
        self.associations.append(association)
        
    def decay(self, decay_rate: float = 0.01):
        """Apply time-based decay to memory strength"""
        if self.state == MemoryState.ACTIVE:
            time_since_access = datetime.now() - self.last_accessed
            days_passed = time_since_access.days
            self.strength = max(0.0, self.strength - (decay_rate * days_passed))
            
            # Decay associations
            for association in self.associations:
                association.decay_strength()
                
    def consolidate(self, consolidation_factor: float = 0.1):
        """Consolidate memory based on importance and access patterns"""
        # Calculate consolidation based on various factors
        access_factor = min(1.0, self.access_count / 10.0)
        importance_factor = self.importance.value / 5.0
        time_factor = min(1.0, (datetime.now() - self.created_at).days / 7.0)
        
        consolidation_increase = consolidation_factor * (
            0.4 * access_factor +
            0.4 * importance_factor +
            0.2 * time_factor
        )
        
        self.consolidation_score = min(1.0, self.consolidation_score + consolidation_increase)
        
        # Update state based on consolidation
        if self.consolidation_score > 0.8:
            self.state = MemoryState.CONSOLIDATED
        elif self.consolidation_score > 0.5:
            self.state = MemoryState.CONSOLIDATING
            
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "id": self.id,
            "content": self.content.serialize(),
            "memory_type": self.memory_type.value,
            "importance": self.importance.value,
            "state": self.state.value,
            "created_at": self.created_at.isoformat(),
            "last_accessed": self.last_accessed.isoformat(),
            "access_count": self.access_count,
            "associations": [
                {
                    "target_id": assoc.target_id,
                    "association_type": assoc.association_type,
                    "strength": assoc.strength,
                    "created_at": assoc.created_at.isoformat(),
                    "last_accessed": assoc.last_accessed.isoformat()
                }
                for assoc in self.associations
            ],
            "tags": list(self.tags),
            "emotional_valence": self.emotional_valence,
            "emotional_intensity": self.emotional_intensity,
            "context": self.context,
            "strength": self.strength,
            "consolidation_score": self.consolidation_score
        }


@dataclass
class MemoryLayer:
    """Represents one of the 5 memory layers"""
    layer_type: MemoryType
    capacity: int  # Maximum number of items
    retention_time: timedelta  # How long items stay in this layer
    consolidation_threshold: float  # Threshold for moving to next layer
    
    items: Dict[str, MemoryItem] = field(default_factory=dict)
    
    def add_item(self, item: MemoryItem) -> bool:
        """Add item to memory layer"""
        if len(self.items) >= self.capacity:
            self._evict_oldest()
            
        self.items[item.id] = item
        item.memory_type = self.layer_type
        return True
        
    def _evict_oldest(self):
        """Remove oldest or least important item"""
        if not self.items:
            return
            
        # Find item to evict (lowest combination of strength and importance)
        evict_item = min(
            self.items.values(),
            key=lambda x: x.strength * (x.importance.value / 5.0)
        )
        
        del self.items[evict_item.id]
        
    def get_item(self, item_id: str) -> Optional[MemoryItem]:
        """Retrieve item by ID"""
        if item_id in self.items:
            self.items[item_id].access()
            return self.items[item_id]
        return None
        
    def search_items(self, query: str, limit: int = 10) -> List[MemoryItem]:
        """Search items by content"""
        results = []
        query_lower = query.lower()
        
        for item in self.items.values():
            if isinstance(item.content.data, str):
                if query_lower in item.content.data.lower():
                    item.access()
                    results.append(item)
                    
        # Sort by relevance (access count and strength)
        results.sort(key=lambda x: x.access_count * x.strength, reverse=True)
        return results[:limit]
        
    def consolidate_layer(self):
        """Consolidate memories in this layer"""
        for item in self.items.values():
            item.consolidate()
            item.decay()


@dataclass
class MemorySystem:
    """5-layer memory system for consciousness"""
    
    # Memory layers with different capacities and retention times
    working_memory: MemoryLayer = field(default_factory=lambda: MemoryLayer(
        MemoryType.WORKING, 
        capacity=20, 
        retention_time=timedelta(minutes=30),
        consolidation_threshold=0.7
    ))
    
    short_term_memory: MemoryLayer = field(default_factory=lambda: MemoryLayer(
        MemoryType.SHORT_TERM,
        capacity=100,
        retention_time=timedelta(hours=24),
        consolidation_threshold=0.6
    ))
    
    episodic_memory: MemoryLayer = field(default_factory=lambda: MemoryLayer(
        MemoryType.EPISODIC,
        capacity=1000,
        retention_time=timedelta(days=30),
        consolidation_threshold=0.5
    ))
    
    semantic_memory: MemoryLayer = field(default_factory=lambda: MemoryLayer(
        MemoryType.SEMANTIC,
        capacity=10000,
        retention_time=timedelta(days=365),
        consolidation_threshold=0.4
    ))
    
    procedural_memory: MemoryLayer = field(default_factory=lambda: MemoryLayer(
        MemoryType.PROCEDURAL,
        capacity=5000,
        retention_time=timedelta(days=1000),
        consolidation_threshold=0.3
    ))
    
    def get_layer(self, memory_type: MemoryType) -> MemoryLayer:
        """Get memory layer by type"""
        layer_map = {
            MemoryType.WORKING: self.working_memory,
            MemoryType.SHORT_TERM: self.short_term_memory,
            MemoryType.EPISODIC: self.episodic_memory,
            MemoryType.SEMANTIC: self.semantic_memory,
            MemoryType.PROCEDURAL: self.procedural_memory
        }
        return layer_map[memory_type]
        
    def store_memory(self, content: Any, memory_type: MemoryType, 
                    importance: MemoryImportance = MemoryImportance.MEDIUM,
                    emotional_valence: float = 0.0,
                    emotional_intensity: float = 0.0,
                    context: Dict[str, Any] = None) -> str:
        """Store new memory in appropriate layer"""
        
        memory_content = MemoryContent(
            data=content,
            content_type=type(content).__name__
        )
        
        memory_item = MemoryItem(
            content=memory_content,
            memory_type=memory_type,
            importance=importance,
            emotional_valence=emotional_valence,
            emotional_intensity=emotional_intensity,
            context=context or {}
        )
        
        layer = self.get_layer(memory_type)
        layer.add_item(memory_item)
        
        return memory_item.id
        
    def retrieve_memory(self, memory_id: str) -> Optional[MemoryItem]:
        """Retrieve memory by ID from any layer"""
        for memory_type in MemoryType:
            layer = self.get_layer(memory_type)
            item = layer.get_item(memory_id)
            if item:
                return item
        return None
        
    def search_memories(self, query: str, memory_types: List[MemoryType] = None,
                       limit: int = 20) -> List[MemoryItem]:
        """Search across memory layers"""
        if memory_types is None:
            memory_types = list(MemoryType)
            
        all_results = []
        for memory_type in memory_types:
            layer = self.get_layer(memory_type)
            results = layer.search_items(query, limit)
            all_results.extend(results)
            
        # Sort by relevance and memory type priority
        type_priority = {
            MemoryType.WORKING: 5,
            MemoryType.SHORT_TERM: 4,
            MemoryType.EPISODIC: 3,
            MemoryType.SEMANTIC: 2,
            MemoryType.PROCEDURAL: 1
        }
        
        all_results.sort(
            key=lambda x: (
                type_priority[x.memory_type] * x.access_count * x.strength
            ),
            reverse=True
        )
        
        return all_results[:limit]
        
    def consolidate_memories(self):
        """Consolidate memories across all layers"""
        for memory_type in MemoryType:
            layer = self.get_layer(memory_type)
            layer.consolidate_layer()
            
        self._promote_memories()
        
    def _promote_memories(self):
        """Promote memories between layers based on consolidation"""
        # Promote from working to short-term
        self._promote_between_layers(
            self.working_memory, 
            self.short_term_memory,
            lambda item: item.consolidation_score > 0.7
        )
        
        # Promote from short-term to episodic/semantic
        self._promote_between_layers(
            self.short_term_memory,
            self.episodic_memory,
            lambda item: item.consolidation_score > 0.6 and item.emotional_intensity > 0.3
        )
        
        self._promote_between_layers(
            self.short_term_memory,
            self.semantic_memory,
            lambda item: item.consolidation_score > 0.6 and item.importance.value >= 3
        )
        
    def _promote_between_layers(self, source_layer: MemoryLayer, 
                               target_layer: MemoryLayer,
                               condition_func):
        """Promote memories between layers based on condition"""
        items_to_promote = []
        
        for item in source_layer.items.values():
            if condition_func(item):
                items_to_promote.append(item)
                
        for item in items_to_promote:
            del source_layer.items[item.id]
            target_layer.add_item(item)
            
    def get_memory_statistics(self) -> Dict[str, Any]:
        """Get statistics about memory system"""
        stats = {}
        
        for memory_type in MemoryType:
            layer = self.get_layer(memory_type)
            stats[memory_type.value] = {
                "count": len(layer.items),
                "capacity": layer.capacity,
                "utilization": len(layer.items) / layer.capacity * 100,
                "avg_strength": sum(item.strength for item in layer.items.values()) / len(layer.items) if layer.items else 0,
                "avg_consolidation": sum(item.consolidation_score for item in layer.items.values()) / len(layer.items) if layer.items else 0
            }
            
        return stats