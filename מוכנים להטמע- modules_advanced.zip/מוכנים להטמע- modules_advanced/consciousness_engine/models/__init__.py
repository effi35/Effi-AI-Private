#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Consciousness Engine - Models Package
=======================================

מבני נתונים ותצורות עבור מנוע התודעה המתקדם

מודלים זמינים:
- EmotionModel: מודל רגשות עם 15 רגשות בסיסיים
- MemoryModel: מודל זיכרון עם 5 שכבות
- ConsciousnessConfig: תצורת מנוע התודעה
- ThoughtModel: מודל מחשבות ורפלקסיות
- StateModel: מודל מצבי התודעה
"""

from .emotions import (
    EmotionType,
    EmotionIntensity,
    EmotionState,
    EmotionInteractionMatrix,
    EmotionBlend,
    EmotionSystem
)

from .memory import (
    MemoryType,
    MemoryImportance,
    MemoryState,
    MemoryContent,
    MemoryAssociation,
    MemoryItem,
    MemoryLayer,
    MemorySystem
)

from .thoughts import (
    ThoughtType,
    ThoughtIntensity,
    ThoughtState,
    CognitiveProcess,
    ThoughtContent,
    ThoughtConnection,
    Thought,
    ThoughtStream,
    ThoughtPattern
)

from .states import (
    ConsciousnessLevel,
    AttentionState,
    EmotionalState,
    CognitiveMode,
    EnergyLevel,
    AttentionFocus,
    ConsciousnessMetrics,
    StateTransition,
    ConsciousnessState,
    StatePattern,
    StateManager
)

from .config import (
    ProcessingMode,
    LanguageMode,
    LearningMode,
    MemoryConfiguration,
    EmotionConfiguration,
    ThoughtConfiguration,
    StateConfiguration,
    PerformanceConfiguration,
    IntegrationConfiguration,
    ConsciousnessConfiguration,
    DEFAULT_CONFIGS,
    create_config_from_preset
)

__all__ = [
    # Emotions
    'EmotionType',
    'EmotionIntensity', 
    'EmotionState',
    'EmotionInteractionMatrix',
    'EmotionBlend',
    'EmotionSystem',
    
    # Memory
    'MemoryType',
    'MemoryImportance',
    'MemoryState',
    'MemoryContent',
    'MemoryAssociation',
    'MemoryItem',
    'MemoryLayer',
    'MemorySystem',
    
    # Thoughts
    'ThoughtType',
    'ThoughtIntensity',
    'ThoughtState',
    'CognitiveProcess',
    'ThoughtContent',
    'ThoughtConnection',
    'Thought',
    'ThoughtStream',
    'ThoughtPattern',
    
    # States
    'ConsciousnessLevel',
    'AttentionState',
    'EmotionalState',
    'CognitiveMode',
    'EnergyLevel',
    'AttentionFocus',
    'ConsciousnessMetrics',
    'StateTransition',
    'ConsciousnessState',
    'StatePattern',
    'StateManager',
    
    # Configuration
    'ProcessingMode',
    'LanguageMode',
    'LearningMode',
    'MemoryConfiguration',
    'EmotionConfiguration',
    'ThoughtConfiguration',
    'StateConfiguration',
    'PerformanceConfiguration',
    'IntegrationConfiguration',
    'ConsciousnessConfiguration',
    'DEFAULT_CONFIGS',
    'create_config_from_preset'
]

__version__ = "2.0.0-MONSTER"
__author__ = "Effi-AI Consciousness Team"