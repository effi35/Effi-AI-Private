"""
Configuration Models for Consciousness Engine
Defines all configuration structures and settings
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Tuple
import json
from pathlib import Path


class ProcessingMode(Enum):
    """Processing modes for consciousness engine"""
    REAL_TIME = "real_time"          # Immediate processing
    BATCH = "batch"                  # Process in batches
    ADAPTIVE = "adaptive"            # Adapt based on load
    ENERGY_EFFICIENT = "energy_efficient"  # Optimize for energy
    HIGH_PERFORMANCE = "high_performance"   # Maximum performance


class LanguageMode(Enum):
    """Language processing modes"""
    HEBREW_ONLY = "hebrew_only"
    ENGLISH_ONLY = "english_only"
    MIXED = "mixed"
    ADAPTIVE = "adaptive"  # Switch based on context


class LearningMode(Enum):
    """Learning and adaptation modes"""
    PASSIVE = "passive"      # No learning, use existing patterns
    ACTIVE = "active"        # Continuous learning
    SUPERVISED = "supervised"  # Learn from feedback
    REINFORCEMENT = "reinforcement"  # Learn from rewards/penalties


@dataclass
class MemoryConfiguration:
    """Configuration for memory system"""
    # Layer capacities
    working_memory_capacity: int = 20
    short_term_capacity: int = 100
    episodic_capacity: int = 1000
    semantic_capacity: int = 10000
    procedural_capacity: int = 5000
    
    # Retention times (in seconds)
    working_retention: int = 1800      # 30 minutes
    short_term_retention: int = 86400   # 24 hours
    episodic_retention: int = 2592000   # 30 days
    semantic_retention: int = 31536000  # 1 year
    procedural_retention: int = 86400000  # ~1000 days
    
    # Consolidation settings
    consolidation_frequency: int = 3600  # Every hour
    decay_rate: float = 0.01
    importance_threshold: float = 0.6
    
    # Memory association settings
    max_associations_per_item: int = 20
    association_strength_threshold: float = 0.3
    auto_associate: bool = True
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "working_memory_capacity": self.working_memory_capacity,
            "short_term_capacity": self.short_term_capacity,
            "episodic_capacity": self.episodic_capacity,
            "semantic_capacity": self.semantic_capacity,
            "procedural_capacity": self.procedural_capacity,
            "working_retention": self.working_retention,
            "short_term_retention": self.short_term_retention,
            "episodic_retention": self.episodic_retention,
            "semantic_retention": self.semantic_retention,
            "procedural_retention": self.procedural_retention,
            "consolidation_frequency": self.consolidation_frequency,
            "decay_rate": self.decay_rate,
            "importance_threshold": self.importance_threshold,
            "max_associations_per_item": self.max_associations_per_item,
            "association_strength_threshold": self.association_strength_threshold,
            "auto_associate": self.auto_associate
        }


@dataclass
class EmotionConfiguration:
    """Configuration for emotion system"""
    # Emotion processing
    emotion_intensity_range: Tuple[float, float] = (0.0, 1.0)
    emotion_decay_rate: float = 0.05
    emotion_blend_threshold: float = 0.4
    max_concurrent_emotions: int = 5
    
    # Interaction matrix settings
    enable_emotion_interactions: bool = True
    interaction_strength_multiplier: float = 1.0
    emotional_memory_influence: float = 0.3
    
    # Cultural and language settings
    hebrew_emotion_mapping: bool = True
    cultural_emotion_modifiers: Dict[str, float] = field(default_factory=lambda: {
        "collectivism_factor": 0.8,
        "expression_intensity": 0.9,
        "family_emotion_weight": 1.2
    })
    
    # Emotion regulation
    auto_regulation: bool = True
    regulation_threshold: float = 0.8  # When to start regulating
    regulation_speed: float = 0.1     # How fast to regulate
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "emotion_intensity_range": self.emotion_intensity_range,
            "emotion_decay_rate": self.emotion_decay_rate,
            "emotion_blend_threshold": self.emotion_blend_threshold,
            "max_concurrent_emotions": self.max_concurrent_emotions,
            "enable_emotion_interactions": self.enable_emotion_interactions,
            "interaction_strength_multiplier": self.interaction_strength_multiplier,
            "emotional_memory_influence": self.emotional_memory_influence,
            "hebrew_emotion_mapping": self.hebrew_emotion_mapping,
            "cultural_emotion_modifiers": self.cultural_emotion_modifiers,
            "auto_regulation": self.auto_regulation,
            "regulation_threshold": self.regulation_threshold,
            "regulation_speed": self.regulation_speed
        }


@dataclass
class ThoughtConfiguration:
    """Configuration for thought processing"""
    # Thought stream settings
    max_active_thoughts: int = 7
    max_total_thoughts: int = 100
    thought_lifetime: int = 3600  # 1 hour in seconds
    
    # Processing settings
    attention_decay_rate: float = 0.05
    coherence_threshold: float = 0.6
    creativity_bias: float = 0.5  # 0.0 = analytical, 1.0 = creative
    
    # Thought generation
    auto_generate_thoughts: bool = True
    generation_interval: int = 30  # seconds
    association_strength_threshold: float = 0.4
    
    # Language processing
    multilingual_thoughts: bool = True
    hebrew_thought_patterns: bool = True
    thought_translation: bool = False
    
    # Pattern recognition
    enable_pattern_detection: bool = True
    pattern_memory_size: int = 50
    pattern_threshold: float = 0.7
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "max_active_thoughts": self.max_active_thoughts,
            "max_total_thoughts": self.max_total_thoughts,
            "thought_lifetime": self.thought_lifetime,
            "attention_decay_rate": self.attention_decay_rate,
            "coherence_threshold": self.coherence_threshold,
            "creativity_bias": self.creativity_bias,
            "auto_generate_thoughts": self.auto_generate_thoughts,
            "generation_interval": self.generation_interval,
            "association_strength_threshold": self.association_strength_threshold,
            "multilingual_thoughts": self.multilingual_thoughts,
            "hebrew_thought_patterns": self.hebrew_thought_patterns,
            "thought_translation": self.thought_translation,
            "enable_pattern_detection": self.enable_pattern_detection,
            "pattern_memory_size": self.pattern_memory_size,
            "pattern_threshold": self.pattern_threshold
        }


@dataclass
class StateConfiguration:
    """Configuration for consciousness states"""
    # State transitions
    auto_state_transitions: bool = True
    transition_smoothing: float = 0.3  # How smooth transitions are
    state_persistence: float = 0.7     # How long states persist
    
    # Attention management
    max_attention_focuses: int = 5
    focus_decay_rate: float = 0.02
    attention_reallocation: bool = True
    
    # Energy management
    energy_decay_rate: float = 0.01
    energy_recovery_rate: float = 0.005
    fatigue_threshold: float = 0.3
    
    # Consciousness levels
    level_transition_threshold: float = 0.1
    metacognition_threshold: float = 0.8
    transcendence_threshold: float = 0.95
    
    # State history
    max_state_history: int = 1000
    pattern_detection_window: int = 10
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "auto_state_transitions": self.auto_state_transitions,
            "transition_smoothing": self.transition_smoothing,
            "state_persistence": self.state_persistence,
            "max_attention_focuses": self.max_attention_focuses,
            "focus_decay_rate": self.focus_decay_rate,
            "attention_reallocation": self.attention_reallocation,
            "energy_decay_rate": self.energy_decay_rate,
            "energy_recovery_rate": self.energy_recovery_rate,
            "fatigue_threshold": self.fatigue_threshold,
            "level_transition_threshold": self.level_transition_threshold,
            "metacognition_threshold": self.metacognition_threshold,
            "transcendence_threshold": self.transcendence_threshold,
            "max_state_history": self.max_state_history,
            "pattern_detection_window": self.pattern_detection_window
        }


@dataclass
class PerformanceConfiguration:
    """Configuration for performance optimization"""
    # Processing optimization
    processing_mode: ProcessingMode = ProcessingMode.ADAPTIVE
    max_concurrent_processes: int = 10
    batch_size: int = 50
    processing_timeout: int = 30  # seconds
    
    # Resource management
    max_memory_usage: int = 1024  # MB
    max_cpu_usage: float = 80.0   # percentage
    cleanup_frequency: int = 3600  # seconds
    
    # Caching
    enable_caching: bool = True
    cache_size: int = 1000
    cache_ttl: int = 3600  # seconds
    
    # Monitoring
    enable_metrics: bool = True
    metrics_interval: int = 60  # seconds
    log_level: str = "INFO"
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "processing_mode": self.processing_mode.value,
            "max_concurrent_processes": self.max_concurrent_processes,
            "batch_size": self.batch_size,
            "processing_timeout": self.processing_timeout,
            "max_memory_usage": self.max_memory_usage,
            "max_cpu_usage": self.max_cpu_usage,
            "cleanup_frequency": self.cleanup_frequency,
            "enable_caching": self.enable_caching,
            "cache_size": self.cache_size,
            "cache_ttl": self.cache_ttl,
            "enable_metrics": self.enable_metrics,
            "metrics_interval": self.metrics_interval,
            "log_level": self.log_level
        }


@dataclass
class IntegrationConfiguration:
    """Configuration for integration with other systems"""
    # Module interfaces
    memory_module_enabled: bool = True
    avatar_module_enabled: bool = True
    voice_module_enabled: bool = True
    knowledge_base_enabled: bool = True
    
    # API settings
    api_enabled: bool = True
    api_port: int = 8080
    api_authentication: bool = False
    api_rate_limit: int = 100  # requests per minute
    
    # Database settings
    database_type: str = "sqlite"  # sqlite, postgresql, mongodb
    database_path: str = "consciousness.db"
    auto_backup: bool = True
    backup_frequency: int = 86400  # daily
    
    # External services
    llm_integration: bool = True
    llm_provider: str = "local"  # local, openai, anthropic
    vector_db_enabled: bool = False
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "memory_module_enabled": self.memory_module_enabled,
            "avatar_module_enabled": self.avatar_module_enabled,
            "voice_module_enabled": self.voice_module_enabled,
            "knowledge_base_enabled": self.knowledge_base_enabled,
            "api_enabled": self.api_enabled,
            "api_port": self.api_port,
            "api_authentication": self.api_authentication,
            "api_rate_limit": self.api_rate_limit,
            "database_type": self.database_type,
            "database_path": self.database_path,
            "auto_backup": self.auto_backup,
            "backup_frequency": self.backup_frequency,
            "llm_integration": self.llm_integration,
            "llm_provider": self.llm_provider,
            "vector_db_enabled": self.vector_db_enabled
        }


@dataclass
class ConsciousnessConfiguration:
    """Main configuration for consciousness engine"""
    # Basic settings
    name: str = "Effi Consciousness Engine"
    version: str = "1.0.0"
    language_mode: LanguageMode = LanguageMode.MIXED
    learning_mode: LearningMode = LearningMode.ACTIVE
    
    # Component configurations
    memory_config: MemoryConfiguration = field(default_factory=MemoryConfiguration)
    emotion_config: EmotionConfiguration = field(default_factory=EmotionConfiguration)
    thought_config: ThoughtConfiguration = field(default_factory=ThoughtConfiguration)
    state_config: StateConfiguration = field(default_factory=StateConfiguration)
    performance_config: PerformanceConfiguration = field(default_factory=PerformanceConfiguration)
    integration_config: IntegrationConfiguration = field(default_factory=IntegrationConfiguration)
    
    # Advanced settings
    consciousness_features: Dict[str, bool] = field(default_factory=lambda: {
        "self_awareness": True,
        "meta_cognition": True,
        "emotional_intelligence": True,
        "creative_thinking": True,
        "moral_reasoning": False,  # Advanced feature
        "temporal_awareness": True,
        "social_awareness": True,
        "cultural_awareness": True
    })
    
    # Cultural and personal settings
    cultural_context: str = "israeli"
    personality_traits: Dict[str, float] = field(default_factory=lambda: {
        "openness": 0.7,
        "conscientiousness": 0.8,
        "extraversion": 0.6,
        "agreeableness": 0.7,
        "neuroticism": 0.3
    })
    
    # Security and privacy
    privacy_settings: Dict[str, bool] = field(default_factory=lambda: {
        "encrypt_memories": False,
        "anonymize_data": False,
        "local_processing_only": True,
        "disable_learning_from_sensitive": True
    })
    
    @classmethod
    def from_file(cls, config_path: str) -> 'ConsciousnessConfiguration':
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Create config object and update with loaded data
            config = cls()
            config._update_from_dict(data)
            return config
        except Exception as e:
            print(f"Error loading config from {config_path}: {e}")
            return cls()  # Return default config
    
    def _update_from_dict(self, data: Dict[str, Any]):
        """Update configuration from dictionary"""
        for key, value in data.items():
            if hasattr(self, key):
                if key.endswith('_config') and hasattr(self, key):
                    # Update nested configuration objects
                    config_obj = getattr(self, key)
                    if isinstance(value, dict):
                        for sub_key, sub_value in value.items():
                            if hasattr(config_obj, sub_key):
                                setattr(config_obj, sub_key, sub_value)
                else:
                    setattr(self, key, value)
    
    def save_to_file(self, config_path: str):
        """Save configuration to JSON file"""
        try:
            # Ensure directory exists
            Path(config_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.serialize(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving config to {config_path}: {e}")
    
    def validate(self) -> List[str]:
        """Validate configuration and return any errors"""
        errors = []
        
        # Validate memory configuration
        if self.memory_config.working_memory_capacity < 1:
            errors.append("Working memory capacity must be at least 1")
        
        if self.memory_config.decay_rate < 0 or self.memory_config.decay_rate > 1:
            errors.append("Memory decay rate must be between 0 and 1")
        
        # Validate emotion configuration
        if self.emotion_config.max_concurrent_emotions < 1:
            errors.append("Max concurrent emotions must be at least 1")
        
        # Validate thought configuration
        if self.thought_config.max_active_thoughts < 1:
            errors.append("Max active thoughts must be at least 1")
        
        # Validate performance configuration
        if self.performance_config.max_cpu_usage < 0 or self.performance_config.max_cpu_usage > 100:
            errors.append("Max CPU usage must be between 0 and 100")
        
        return errors
    
    def get_summary(self) -> Dict[str, Any]:
        """Get configuration summary"""
        return {
            "name": self.name,
            "version": self.version,
            "language_mode": self.language_mode.value,
            "learning_mode": self.learning_mode.value,
            "enabled_features": [k for k, v in self.consciousness_features.items() if v],
            "cultural_context": self.cultural_context,
            "memory_total_capacity": (
                self.memory_config.working_memory_capacity +
                self.memory_config.short_term_capacity +
                self.memory_config.episodic_capacity +
                self.memory_config.semantic_capacity +
                self.memory_config.procedural_capacity
            ),
            "performance_mode": self.performance_config.processing_mode.value,
            "integration_modules": [
                k.replace('_enabled', '') for k, v in self.integration_config.__dict__.items()
                if k.endswith('_enabled') and v
            ]
        }
    
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "name": self.name,
            "version": self.version,
            "language_mode": self.language_mode.value,
            "learning_mode": self.learning_mode.value,
            "memory_config": self.memory_config.serialize(),
            "emotion_config": self.emotion_config.serialize(),
            "thought_config": self.thought_config.serialize(),
            "state_config": self.state_config.serialize(),
            "performance_config": self.performance_config.serialize(),
            "integration_config": self.integration_config.serialize(),
            "consciousness_features": self.consciousness_features,
            "cultural_context": self.cultural_context,
            "personality_traits": self.personality_traits,
            "privacy_settings": self.privacy_settings
        }


# Default configuration presets
DEFAULT_CONFIGS = {
    "minimal": {
        "name": "Minimal Consciousness",
        "memory_config": {
            "working_memory_capacity": 10,
            "short_term_capacity": 50,
            "episodic_capacity": 200,
            "semantic_capacity": 1000,
            "procedural_capacity": 500
        },
        "consciousness_features": {
            "self_awareness": True,
            "meta_cognition": False,
            "emotional_intelligence": True,
            "creative_thinking": False,
            "moral_reasoning": False,
            "temporal_awareness": True,
            "social_awareness": False,
            "cultural_awareness": False
        }
    },
    
    "standard": {
        "name": "Standard Consciousness",
        # Uses default values
    },
    
    "advanced": {
        "name": "Advanced Consciousness",
        "memory_config": {
            "working_memory_capacity": 30,
            "short_term_capacity": 200,
            "episodic_capacity": 2000,
            "semantic_capacity": 20000,
            "procedural_capacity": 10000
        },
        "consciousness_features": {
            "self_awareness": True,
            "meta_cognition": True,
            "emotional_intelligence": True,
            "creative_thinking": True,
            "moral_reasoning": True,
            "temporal_awareness": True,
            "social_awareness": True,
            "cultural_awareness": True
        },
        "performance_config": {
            "processing_mode": "high_performance",
            "max_concurrent_processes": 20,
            "enable_caching": True
        }
    }
}


def create_config_from_preset(preset_name: str) -> ConsciousnessConfiguration:
    """Create configuration from preset"""
    if preset_name not in DEFAULT_CONFIGS:
        raise ValueError(f"Unknown preset: {preset_name}")
    
    config = ConsciousnessConfiguration()
    config._update_from_dict(DEFAULT_CONFIGS[preset_name])
    return config