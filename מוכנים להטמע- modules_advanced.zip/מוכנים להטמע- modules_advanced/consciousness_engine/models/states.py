"""
Consciousness States Models
Implements various states of consciousness and awareness levels
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timedelta
import json


class ConsciousnessLevel(Enum):
    """Levels of consciousness awareness"""
    UNCONSCIOUS = 0      # No awareness, automatic processing only
    SUBCONSCIOUS = 1     # Background processing, limited awareness
    PRECONSCIOUS = 2     # Information available but not in focus
    CONSCIOUS = 3        # Active awareness and processing
    HYPERCONSCIOUS = 4   # Heightened awareness and meta-cognition
    TRANSCENDENT = 5     # Peak consciousness, unified awareness


class AttentionState(Enum):
    """States of attention and focus"""
    SCATTERED = "scattered"       # Unfocused, jumping between topics
    FOCUSED = "focused"          # Single-point concentration
    DIVIDED = "divided"          # Multi-tasking attention
    SUSTAINED = "sustained"      # Long-term focused attention
    SELECTIVE = "selective"      # Filtering specific information
    ALTERNATING = "alternating"  # Switching between focuses
    ABSORBED = "absorbed"        # Deep immersion (flow state)


class EmotionalState(Enum):
    """Overall emotional states"""
    NEUTRAL = "neutral"
    POSITIVE = "positive"
    NEGATIVE = "negative"
    MIXED = "mixed"
    EXCITED = "excited"
    CALM = "calm"
    STRESSED = "stressed"
    EUPHORIC = "euphoric"
    MELANCHOLIC = "melancholic"
    ANXIOUS = "anxious"
    CONFIDENT = "confident"
    CURIOUS = "curious"
    BORED = "bored"
    PASSIONATE = "passionate"
    CONTEMPLATIVE = "contemplative"


class CognitiveMode(Enum):
    """Modes of cognitive processing"""
    ANALYTICAL = "analytical"        # Logical, systematic thinking
    CREATIVE = "creative"           # Imaginative, divergent thinking
    INTUITIVE = "intuitive"         # Gut-feeling based processing
    REFLECTIVE = "reflective"       # Self-examining, introspective
    REACTIVE = "reactive"           # Quick, automatic responses
    DELIBERATE = "deliberate"       # Slow, careful consideration
    ASSOCIATIVE = "associative"     # Connection-based thinking
    CRITICAL = "critical"           # Evaluative, skeptical thinking
    EXPLORATORY = "exploratory"     # Discovery-oriented thinking
    PROBLEM_SOLVING = "problem_solving"  # Solution-focused thinking


class EnergyLevel(Enum):
    """Energy and alertness levels"""
    EXHAUSTED = 1
    LOW = 2
    MODERATE = 3
    HIGH = 4
    PEAK = 5


@dataclass
class AttentionFocus:
    """Represents what consciousness is focused on"""
    target: str                    # What is being focused on
    intensity: float = 0.5         # Strength of focus (0.0 to 1.0)
    duration: timedelta = field(default_factory=lambda: timedelta(seconds=0))
    start_time: datetime = field(default_factory=datetime.now)
    context: Dict[str, Any] = field(default_factory=dict)
    
    def update_duration(self):
        """Update the duration of this focus"""
        self.duration = datetime.now() - self.start_time
        
    def serialize(self) -> Dict[str, Any]:
        return {
            "target": self.target,
            "intensity": self.intensity,
            "duration": self.duration.total_seconds(),
            "start_time": self.start_time.isoformat(),
            "context": self.context
        }


@dataclass
class ConsciousnessMetrics:
    """Metrics for measuring consciousness state"""
    awareness_score: float = 0.5      # Overall awareness level (0.0 to 1.0)
    coherence_score: float = 0.5      # How well integrated thoughts are
    complexity_score: float = 0.5     # Complexity of current processing
    meta_awareness: float = 0.5       # Awareness of own mental processes
    integration_level: float = 0.5    # How well different processes integrate
    
    # Processing metrics
    processing_speed: float = 0.5     # How fast thoughts are processed
    memory_accessibility: float = 0.5 # How easily memories are accessed
    creativity_index: float = 0.5     # Current creative capacity
    
    # Stability metrics
    emotional_stability: float = 0.5  # Emotional regulation
    attention_stability: float = 0.5  # Ability to maintain focus
    
    def calculate_overall_score(self) -> float:
        """Calculate overall consciousness score"""
        scores = [
            self.awareness_score,
            self.coherence_score,
            self.complexity_score,
            self.meta_awareness,
            self.integration_level
        ]
        return sum(scores) / len(scores)
        
    def serialize(self) -> Dict[str, Any]:
        return {
            "awareness_score": self.awareness_score,
            "coherence_score": self.coherence_score,
            "complexity_score": self.complexity_score,
            "meta_awareness": self.meta_awareness,
            "integration_level": self.integration_level,
            "processing_speed": self.processing_speed,
            "memory_accessibility": self.memory_accessibility,
            "creativity_index": self.creativity_index,
            "emotional_stability": self.emotional_stability,
            "attention_stability": self.attention_stability,
            "overall_score": self.calculate_overall_score()
        }


@dataclass
class StateTransition:
    """Represents a transition between consciousness states"""
    from_state: str
    to_state: str
    trigger: str                   # What caused the transition
    timestamp: datetime = field(default_factory=datetime.now)
    duration: Optional[timedelta] = None  # How long the transition took
    successful: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def serialize(self) -> Dict[str, Any]:
        return {
            "from_state": self.from_state,
            "to_state": self.to_state,
            "trigger": self.trigger,
            "timestamp": self.timestamp.isoformat(),
            "duration": self.duration.total_seconds() if self.duration else None,
            "successful": self.successful,
            "metadata": self.metadata
        }


@dataclass
class ConsciousnessState:
    """Complete state of consciousness at a point in time"""
    id: str = field(default_factory=lambda: str(__import__('uuid').uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    
    # Core state dimensions
    consciousness_level: ConsciousnessLevel = ConsciousnessLevel.CONSCIOUS
    attention_state: AttentionState = AttentionState.FOCUSED
    emotional_state: EmotionalState = EmotionalState.NEUTRAL
    cognitive_mode: CognitiveMode = CognitiveMode.ANALYTICAL
    energy_level: EnergyLevel = EnergyLevel.MODERATE
    
    # Attention and focus
    primary_focus: Optional[AttentionFocus] = None
    secondary_focuses: List[AttentionFocus] = field(default_factory=list)
    
    # Metrics and measurements
    metrics: ConsciousnessMetrics = field(default_factory=ConsciousnessMetrics)
    
    # Context and environment
    context: Dict[str, Any] = field(default_factory=dict)
    environmental_factors: Dict[str, Any] = field(default_factory=dict)
    
    # Active processes
    active_thought_ids: List[str] = field(default_factory=list)
    active_emotion_ids: List[str] = field(default_factory=list)
    active_memory_ids: List[str] = field(default_factory=list)
    
    # State history and patterns
    previous_state_id: Optional[str] = None
    transition_history: List[StateTransition] = field(default_factory=list)
    
    # Stability and persistence
    stability_score: float = 0.5    # How stable this state is
    duration: timedelta = field(default_factory=lambda: timedelta(seconds=0))
    
    def update_duration(self):
        """Update how long we've been in this state"""
        # This would typically be called by the consciousness engine
        pass
        
    def set_primary_focus(self, target: str, intensity: float = 0.8, 
                         context: Dict[str, Any] = None):
        """Set primary attention focus"""
        self.primary_focus = AttentionFocus(
            target=target,
            intensity=intensity,
            context=context or {}
        )
        
    def add_secondary_focus(self, target: str, intensity: float = 0.4,
                           context: Dict[str, Any] = None):
        """Add secondary attention focus"""
        focus = AttentionFocus(
            target=target,
            intensity=intensity,
            context=context or {}
        )
        self.secondary_focuses.append(focus)
        
    def calculate_total_attention(self) -> float:
        """Calculate total attention being used"""
        total = 0.0
        if self.primary_focus:
            total += self.primary_focus.intensity
        for focus in self.secondary_focuses:
            total += focus.intensity
        return min(1.0, total)  # Cap at 1.0
        
    def is_overloaded(self) -> bool:
        """Check if consciousness is overloaded"""
        return self.calculate_total_attention() > 1.0
        
    def transition_to(self, new_state: 'ConsciousnessState', 
                     trigger: str, duration: timedelta = None):
        """Record transition to new state"""
        transition = StateTransition(
            from_state=f"{self.consciousness_level.name}_{self.cognitive_mode.value}",
            to_state=f"{new_state.consciousness_level.name}_{new_state.cognitive_mode.value}",
            trigger=trigger,
            duration=duration
        )
        
        self.transition_history.append(transition)
        new_state.previous_state_id = self.id
        
    def get_state_signature(self) -> str:
        """Get unique signature for this state combination"""
        return f"{self.consciousness_level.name}_{self.attention_state.value}_{self.cognitive_mode.value}_{self.emotional_state.value}"
        
    def update_metrics(self, **kwargs):
        """Update consciousness metrics"""
        for key, value in kwargs.items():
            if hasattr(self.metrics, key):
                setattr(self.metrics, key, value)
                
    def serialize(self) -> Dict[str, Any]:
        """Convert to JSON-serializable format"""
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "consciousness_level": self.consciousness_level.value,
            "attention_state": self.attention_state.value,
            "emotional_state": self.emotional_state.value,
            "cognitive_mode": self.cognitive_mode.value,
            "energy_level": self.energy_level.value,
            "primary_focus": self.primary_focus.serialize() if self.primary_focus else None,
            "secondary_focuses": [focus.serialize() for focus in self.secondary_focuses],
            "metrics": self.metrics.serialize(),
            "context": self.context,
            "environmental_factors": self.environmental_factors,
            "active_thought_ids": self.active_thought_ids,
            "active_emotion_ids": self.active_emotion_ids,
            "active_memory_ids": self.active_memory_ids,
            "previous_state_id": self.previous_state_id,
            "transition_history": [t.serialize() for t in self.transition_history],
            "stability_score": self.stability_score,
            "duration": self.duration.total_seconds(),
            "state_signature": self.get_state_signature(),
            "total_attention": self.calculate_total_attention(),
            "is_overloaded": self.is_overloaded()
        }


@dataclass
class StatePattern:
    """Pattern of consciousness state changes"""
    id: str = field(default_factory=lambda: str(__import__('uuid').uuid4()))
    name: str = ""
    description: str = ""
    
    # Pattern definition
    state_sequence: List[str] = field(default_factory=list)  # Sequence of state signatures
    triggers: List[str] = field(default_factory=list)        # What triggers this pattern
    duration_range: tuple = (0, 3600)  # Min/max duration in seconds
    
    # Pattern metrics
    frequency: int = 0              # How often this pattern occurs
    reliability: float = 0.0        # How reliably it follows the sequence
    average_duration: float = 0.0   # Average time for complete pattern
    
    # Conditions and context
    required_conditions: Dict[str, Any] = field(default_factory=dict)
    typical_context: Dict[str, Any] = field(default_factory=dict)
    
    def matches_sequence(self, recent_states: List[ConsciousnessState], 
                        threshold: float = 0.8) -> float:
        """Check if recent states match this pattern"""
        if len(recent_states) < len(self.state_sequence):
            return 0.0
            
        matches = 0
        for i, expected_signature in enumerate(self.state_sequence):
            if i < len(recent_states):
                if recent_states[i].get_state_signature() == expected_signature:
                    matches += 1
                    
        match_ratio = matches / len(self.state_sequence)
        return match_ratio if match_ratio >= threshold else 0.0
        
    def predict_next_state(self, current_state: ConsciousnessState) -> Optional[str]:
        """Predict next state based on pattern"""
        current_signature = current_state.get_state_signature()
        
        try:
            current_index = self.state_sequence.index(current_signature)
            if current_index < len(self.state_sequence) - 1:
                return self.state_sequence[current_index + 1]
        except ValueError:
            # Current state not in pattern
            pass
            
        return None
        
    def serialize(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "state_sequence": self.state_sequence,
            "triggers": self.triggers,
            "duration_range": self.duration_range,
            "frequency": self.frequency,
            "reliability": self.reliability,
            "average_duration": self.average_duration,
            "required_conditions": self.required_conditions,
            "typical_context": self.typical_context
        }


@dataclass
class StateManager:
    """Manages consciousness states and transitions"""
    current_state: ConsciousnessState = field(default_factory=ConsciousnessState)
    state_history: List[ConsciousnessState] = field(default_factory=list)
    known_patterns: List[StatePattern] = field(default_factory=list)
    
    # Configuration
    max_history_size: int = 1000
    pattern_detection_window: int = 10  # States to consider for pattern detection
    
    def transition_to_state(self, new_state: ConsciousnessState, 
                           trigger: str = "unknown"):
        """Transition to a new consciousness state"""
        if self.current_state:
            # Calculate transition duration
            transition_duration = datetime.now() - self.current_state.timestamp
            
            # Record transition
            self.current_state.transition_to(new_state, trigger, transition_duration)
            
            # Add to history
            self.state_history.append(self.current_state)
            
            # Maintain history size
            if len(self.state_history) > self.max_history_size:
                self.state_history = self.state_history[-self.max_history_size:]
                
        self.current_state = new_state
        
    def detect_patterns(self) -> List[StatePattern]:
        """Detect patterns in recent state changes"""
        if len(self.state_history) < 3:
            return []
            
        recent_states = self.state_history[-self.pattern_detection_window:]
        detected_patterns = []
        
        for pattern in self.known_patterns:
            match_score = pattern.matches_sequence(recent_states)
            if match_score > 0.0:
                detected_patterns.append((pattern, match_score))
                
        # Sort by match score
        detected_patterns.sort(key=lambda x: x[1], reverse=True)
        return [pattern for pattern, _ in detected_patterns]
        
    def predict_next_state(self) -> Optional[str]:
        """Predict next likely state based on patterns"""
        patterns = self.detect_patterns()
        
        for pattern in patterns:
            predicted = pattern.predict_next_state(self.current_state)
            if predicted:
                return predicted
                
        return None
        
    def get_state_statistics(self) -> Dict[str, Any]:
        """Get statistics about state transitions"""
        if not self.state_history:
            return {}
            
        # Count state frequencies
        state_counts = {}
        transition_counts = {}
        
        for state in self.state_history:
            signature = state.get_state_signature()
            state_counts[signature] = state_counts.get(signature, 0) + 1
            
            for transition in state.transition_history:
                key = f"{transition.from_state} -> {transition.to_state}"
                transition_counts[key] = transition_counts.get(key, 0) + 1
                
        return {
            "total_states": len(self.state_history),
            "unique_states": len(state_counts),
            "most_common_states": sorted(state_counts.items(), 
                                       key=lambda x: x[1], reverse=True)[:5],
            "common_transitions": sorted(transition_counts.items(),
                                       key=lambda x: x[1], reverse=True)[:5],
            "current_state": self.current_state.get_state_signature(),
            "average_state_duration": sum(s.duration.total_seconds() 
                                        for s in self.state_history) / len(self.state_history)
        }
        
    def serialize(self) -> Dict[str, Any]:
        return {
            "current_state": self.current_state.serialize(),
            "state_history_count": len(self.state_history),
            "known_patterns_count": len(self.known_patterns),
            "statistics": self.get_state_statistics()
        }