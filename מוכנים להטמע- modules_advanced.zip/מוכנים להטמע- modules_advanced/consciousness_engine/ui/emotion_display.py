#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Emotion Display - תצוגת רגשות מתקדמת
=====================================

רכיב UI מתקדם לתצוגת מצב רגשי עם ויזואליזציה אינטראקטיבית.
מציג את 15 הרגשות, עירובים רגשיים ומעקב אחר שינויים בזמן אמת.

תכונות מרכזיות:
- ויזואליזציה של 15 רגשות בסיסיים
- תצוגת עירובים רגשיים דינמית
- גרפים בזמן אמת של שינויי רגש
- ממשק עברי מלא
- אינטראקטיביות עם מנוע הרגשות
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from collections import deque

from ..core.emotion_engine import EmotionEngine
from ..models.emotions import EmotionType, EmotionIntensity, EmotionState


class EmotionDisplay:
    """תצוגת רגשות מתקדמת עם ויזואליזציה ואינטראקטיביות"""
    
    def __init__(self, emotion_engine: EmotionEngine = None):
        """אתחול תצוגת הרגשות"""
        self.logger = logging.getLogger(__name__)
        
        # מנוע הרגשות
        self.emotion_engine = emotion_engine
        
        # היסטוריית רגשות לגרפים
        self.emotion_history: deque = deque(maxlen=100)
        self.intensity_history: deque = deque(maxlen=50)
        
        # הגדרות תצוגה
        self.display_settings = {
            'show_all_emotions': True,
            'show_intensity_graph': True,
            'show_blends': True,
            'animation_enabled': True,
            'update_interval': 1000,  # מילישניות
            'max_display_emotions': 15,
            'color_scheme': 'vibrant'
        }
        
        # מיפוי צבעים לרגשות
        self.emotion_colors = {
            EmotionType.JOY: '#FFD700',           # זהב
            EmotionType.SADNESS: '#4169E1',      # כחול רויאל
            EmotionType.ANGER: '#DC143C',        # אדום כהה
            EmotionType.FEAR: '#800080',         # סגול
            EmotionType.SURPRISE: '#FF8C00',     # כתום כהה
            EmotionType.DISGUST: '#8FBC8F',      # ירוק ים כהה
            EmotionType.SHAME: '#DDA0DD',        # בועת שקדים
            EmotionType.GUILT: '#A0522D',        # חום סיינה
            EmotionType.PRIDE: '#DAA520',        # זהב כהה
            EmotionType.ENVY: '#9ACD32',         # ירוק צהוב
            EmotionType.FRUSTRATION: '#B22222',  # אדום אש
            EmotionType.EXCITEMENT: '#FF1493',   # ורוד עמוק
            EmotionType.CALMNESS: '#20B2AA',     # טורקיז כהה
            EmotionType.MELANCHOLY: '#696969',   # אפור כהה
            EmotionType.CONTENTMENT: '#98FB98'   # ירוק בהיר
        }
        
        # תרגומים עבריים לרגשות
        self.emotion_translations = {
            EmotionType.JOY: 'שמחה',
            EmotionType.SADNESS: 'עצב',
            EmotionType.ANGER: 'כעס',
            EmotionType.FEAR: 'פחד',
            EmotionType.SURPRISE: 'הפתעה',
            EmotionType.DISGUST: 'גועל',
            EmotionType.SHAME: 'בושה',
            EmotionType.GUILT: 'אשמה',
            EmotionType.PRIDE: 'גאווה',
            EmotionType.ENVY: 'קנאה',
            EmotionType.FRUSTRATION: 'תסכול',
            EmotionType.EXCITEMENT: 'התרגשות',
            EmotionType.CALMNESS: 'רגיעה',
            EmotionType.MELANCHOLY: 'דכאון',
            EmotionType.CONTENTMENT: 'שלווה'
        }
        
        # סטטיסטיקות תצוגה
        self.display_stats = {
            'updates_count': 0,
            'last_update': None,
            'most_frequent_emotion': None,
            'avg_intensity': 0.0,
            'emotional_changes': 0
        }
        
        self.logger.info("תצוגת רגשות אותחלה")
    
    def update_display(self) -> Dict[str, Any]:
        """עדכון תצוגת הרגשות עם נתונים עדכניים"""
        try:
            if not self.emotion_engine:
                return {'error': 'מנוע רגשות אינו זמין'}
            
            # קבלת מצב רגשי נוכחי
            current_emotional_state = self.emotion_engine.get_current_emotional_state()
            active_emotions = self.emotion_engine.emotion_system.get_active_emotions()
            
            # עדכון היסטוריה
            self._update_emotion_history(active_emotions)
            
            # יצירת נתוני תצוגה
            display_data = {
                'timestamp': datetime.now().isoformat(),
                'current_state': current_emotional_state,
                'active_emotions': self._format_active_emotions(active_emotions),
                'emotion_history': self._get_formatted_history(),
                'intensity_graph_data': self._get_intensity_graph_data(),
                'emotion_blends': self._get_emotion_blends_data(),
                'statistics': self._calculate_display_statistics(),
                'visual_elements': self._generate_visual_elements()
            }
            
            # עדכון סטטיסטיקות
            self.display_stats['updates_count'] += 1
            self.display_stats['last_update'] = datetime.now()
            
            return display_data
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון תצוגת רגשות: {e}")
            return {'error': str(e)}
    
    def get_emotion_visualization_html(self) -> str:
        """יצירת HTML לויזואליזציה של רגשות"""
        try:
            # קבלת נתוני תצוגה
            display_data = self.update_display()
            
            if 'error' in display_data:
                return self._get_error_visualization(display_data['error'])
            
            # יצירת HTML
            html_content = f'''
            <div class="emotion-display-container" dir="rtl">
                <div class="emotion-header">
                    <h2>🎭 מצב רגשי נוכחי</h2>
                    <div class="emotion-stats">
                        <span>עדכון אחרון: {display_data['timestamp']}</span>
                    </div>
                </div>
                
                <div class="emotion-content">
                    <!-- רגש דומיננטי -->
                    <div class="dominant-emotion">
                        {self._create_dominant_emotion_html(display_data)}
                    </div>
                    
                    <!-- רגשות פעילים -->
                    <div class="active-emotions">
                        {self._create_active_emotions_html(display_data)}
                    </div>
                    
                    <!-- גרף עוצמה -->
                    <div class="intensity-graph">
                        {self._create_intensity_graph_html(display_data)}
                    </div>
                    
                    <!-- עירובים רגשיים -->
                    <div class="emotion-blends">
                        {self._create_blends_html(display_data)}
                    </div>
                    
                    <!-- סטטיסטיקות -->
                    <div class="emotion-statistics">
                        {self._create_statistics_html(display_data)}
                    </div>
                </div>
            </div>
            '''
            
            return html_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת HTML ויזואליזציה: {e}")
            return self._get_error_visualization(str(e))
    
    def get_emotion_css(self) -> str:
        """קבלת CSS עבור תצוגת הרגשות"""
        return '''
        .emotion-display-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        .emotion-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            padding-bottom: 15px;
        }
        
        .emotion-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        
        .emotion-stats {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .emotion-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .dominant-emotion {
            grid-column: 1 / -1;
            text-align: center;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
        }
        
        .dominant-emotion-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            transition: transform 0.3s ease;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .active-emotions {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
        }
        
        .emotion-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .emotion-item:last-child {
            border-bottom: none;
        }
        
        .emotion-name {
            font-weight: 500;
        }
        
        .emotion-intensity {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .intensity-bar {
            width: 60px;
            height: 8px;
            background: rgba(255,255,255,0.2);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .intensity-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .intensity-graph {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
        }
        
        .emotion-blends {
            grid-column: 1 / -1;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .blend-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .blend-colors {
            display: flex;
            gap: 5px;
        }
        
        .blend-color {
            width: 20px;
            height: 20px;
            border-radius: 50%;
        }
        
        .emotion-statistics {
            grid-column: 1 / -1;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 600;
            display: block;
        }
        
        .stat-label {
            font-size: 12px;
            opacity: 0.8;
        }
        '''
    
    def get_emotion_javascript(self) -> str:
        """קבלת JavaScript עבור תצוגת הרגשות"""
        return f'''
        // הגדרות תצוגת רגשות
        const emotionDisplayConfig = {json.dumps(self.display_settings, ensure_ascii=False)};
        
        class EmotionDisplay {{
            constructor() {{
                this.updateInterval = null;
                this.animationFrameId = null;
                this.initialize();
            }}
            
            initialize() {{
                this.startAutoUpdate();
                this.setupEventListeners();
            }}
            
            startAutoUpdate() {{
                if (emotionDisplayConfig.animation_enabled) {{
                    this.updateInterval = setInterval(() => {{
                        this.updateDisplay();
                    }}, emotionDisplayConfig.update_interval);
                }}
            }}
            
            stopAutoUpdate() {{
                if (this.updateInterval) {{
                    clearInterval(this.updateInterval);
                    this.updateInterval = null;
                }}
            }}
            
            updateDisplay() {{
                // עדכון נתוני תצוגה (יתחבר לשרת)
                console.log('מעדכן תצוגת רגשות...');
            }}
            
            setupEventListeners() {{
                // הוספת event listeners לאינטראקטיביות
                document.addEventListener('click', (e) => {{
                    if (e.target.classList.contains('emotion-item')) {{
                        this.showEmotionDetails(e.target);
                    }}
                }});
            }}
            
            showEmotionDetails(emotionElement) {{
                // הצגת פרטי רגש
                console.log('מציג פרטי רגש:', emotionElement);
            }}
            
            animateIntensityBars() {{
                const bars = document.querySelectorAll('.intensity-fill');
                bars.forEach(bar => {{
                    const width = bar.dataset.width || '0%';
                    bar.style.width = width;
                }});
            }}
        }}
        
        // אתחול כשהדף נטען
        document.addEventListener('DOMContentLoaded', function() {{
            window.emotionDisplay = new EmotionDisplay();
        }});
        '''
    
    def trigger_emotion_manually(self, emotion_type: EmotionType, intensity: float) -> bool:
        """הפעלת רגש ידנית לצורכי בדיקה"""
        try:
            if not self.emotion_engine:
                return False
            
            emotion_id = self.emotion_engine.process_emotion(
                emotion_type=emotion_type,
                intensity=intensity,
                context={'source': 'manual_trigger', 'ui_component': 'emotion_display'},
                source="emotion_display_ui"
            )
            
            self.logger.info(f"הופעל רגש ידני: {emotion_type.value} בעוצמה {intensity}")
            return bool(emotion_id)
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת רגש ידני: {e}")
            return False
    
    def _update_emotion_history(self, active_emotions: List):
        """עדכון היסטוריית הרגשות"""
        try:
            timestamp = datetime.now()
            
            # הוספה להיסטוריית רגשות
            emotion_snapshot = {
                'timestamp': timestamp.isoformat(),
                'emotions': [
                    {
                        'type': emotion.emotion_type.value,
                        'intensity': emotion.intensity.value,
                        'state': emotion.state.value
                    }
                    for emotion in active_emotions
                ]
            }
            self.emotion_history.append(emotion_snapshot)
            
            # הוספה להיסטוריית עוצמה
            if active_emotions:
                avg_intensity = sum(e.intensity.value for e in active_emotions) / len(active_emotions)
                self.intensity_history.append({
                    'timestamp': timestamp.isoformat(),
                    'intensity': avg_intensity
                })
                
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון היסטוריה: {e}")
    
    def _format_active_emotions(self, active_emotions: List) -> List[Dict[str, Any]]:
        """עיצוב רגשות פעילים לתצוגה"""
        try:
            formatted_emotions = []
            
            for emotion in active_emotions:
                formatted_emotion = {
                    'id': emotion.id,
                    'type': emotion.emotion_type.value,
                    'hebrew_name': self.emotion_translations.get(emotion.emotion_type, emotion.emotion_type.value),
                    'intensity': emotion.intensity.value,
                    'intensity_percentage': int(emotion.intensity.value * 20),  # המרה ל-0-100
                    'state': emotion.state.value,
                    'color': self.emotion_colors.get(emotion.emotion_type, '#CCCCCC'),
                    'created_at': emotion.timestamp.isoformat(),
                    'duration': (datetime.now() - emotion.timestamp).total_seconds()
                }
                formatted_emotions.append(formatted_emotion)
            
            # מיון לפי עוצמה
            formatted_emotions.sort(key=lambda x: x['intensity'], reverse=True)
            
            return formatted_emotions
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב רגשות פעילים: {e}")
            return []
    
    def _get_formatted_history(self) -> List[Dict[str, Any]]:
        """קבלת היסטוריה מעוצבת לתצוגה"""
        try:
            # החזרת 20 הרשומות האחרונות
            return list(self.emotion_history)[-20:]
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת היסטוריה: {e}")
            return []
    
    def _get_intensity_graph_data(self) -> Dict[str, Any]:
        """קבלת נתוני גרף עוצמה"""
        try:
            if not self.intensity_history:
                return {'data': [], 'max_value': 1.0}
            
            graph_data = {
                'data': list(self.intensity_history),
                'max_value': max(item['intensity'] for item in self.intensity_history),
                'min_value': min(item['intensity'] for item in self.intensity_history),
                'avg_value': sum(item['intensity'] for item in self.intensity_history) / len(self.intensity_history)
            }
            
            return graph_data
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת נתוני גרף: {e}")
            return {'data': [], 'max_value': 1.0}
    
    def _get_emotion_blends_data(self) -> List[Dict[str, Any]]:
        """קבלת נתוני עירובים רגשיים"""
        try:
            if not self.emotion_engine:
                return []
            
            all_blends = self.emotion_engine.emotion_system.get_all_blends()
            
            formatted_blends = []
            for blend in all_blends:
                blend_data = {
                    'id': blend.id,
                    'name': blend.name,
                    'emotions': [
                        {
                            'type': emotion.emotion_type.value,
                            'hebrew_name': self.emotion_translations.get(emotion.emotion_type, emotion.emotion_type.value),
                            'contribution': emotion.intensity.value,
                            'color': self.emotion_colors.get(emotion.emotion_type, '#CCCCCC')
                        }
                        for emotion_id in blend.emotion_ids
                        for emotion in [self.emotion_engine.emotion_system.get_emotion(emotion_id)]
                        if emotion
                    ],
                    'overall_intensity': blend.calculate_overall_intensity(),
                    'created_at': blend.created_at.isoformat()
                }
                formatted_blends.append(blend_data)
            
            return formatted_blends
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת נתוני עירובים: {e}")
            return []
    
    def _calculate_display_statistics(self) -> Dict[str, Any]:
        """חישוב סטטיסטיקות לתצוגה"""
        try:
            if not self.emotion_history:
                return {}
            
            # ספירת רגשות
            emotion_counts = {}
            total_emotions = 0
            
            for snapshot in self.emotion_history:
                for emotion in snapshot['emotions']:
                    emotion_type = emotion['type']
                    emotion_counts[emotion_type] = emotion_counts.get(emotion_type, 0) + 1
                    total_emotions += 1
            
            # רגש שכיח ביותר
            most_frequent = max(emotion_counts.items(), key=lambda x: x[1]) if emotion_counts else None
            
            # עוצמה ממוצעת
            if self.intensity_history:
                avg_intensity = sum(item['intensity'] for item in self.intensity_history) / len(self.intensity_history)
            else:
                avg_intensity = 0.0
            
            return {
                'total_emotions_recorded': total_emotions,
                'unique_emotions_count': len(emotion_counts),
                'most_frequent_emotion': {
                    'type': most_frequent[0],
                    'hebrew_name': self.emotion_translations.get(EmotionType(most_frequent[0]), most_frequent[0]),
                    'count': most_frequent[1]
                } if most_frequent else None,
                'average_intensity': avg_intensity,
                'emotion_distribution': emotion_counts,
                'display_updates': self.display_stats['updates_count']
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב סטטיסטיקות: {e}")
            return {}
    
    def _generate_visual_elements(self) -> Dict[str, Any]:
        """יצירת אלמנטים ויזואליים"""
        try:
            return {
                'emotion_wheel': self._create_emotion_wheel_data(),
                'intensity_meter': self._create_intensity_meter_data(),
                'color_palette': self.emotion_colors
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת אלמנטים ויזואליים: {e}")
            return {}
    
    def _create_emotion_wheel_data(self) -> Dict[str, Any]:
        """יצירת נתוני גלגל רגשות"""
        try:
            if not self.emotion_engine:
                return {}
            
            active_emotions = self.emotion_engine.emotion_system.get_active_emotions()
            
            wheel_data = {
                'emotions': [],
                'center_emotion': None
            }
            
            for emotion in active_emotions:
                emotion_data = {
                    'type': emotion.emotion_type.value,
                    'hebrew_name': self.emotion_translations.get(emotion.emotion_type, emotion.emotion_type.value),
                    'intensity': emotion.intensity.value,
                    'color': self.emotion_colors.get(emotion.emotion_type, '#CCCCCC'),
                    'angle': hash(emotion.emotion_type.value) % 360  # זווית לגלגל
                }
                wheel_data['emotions'].append(emotion_data)
            
            # רגש מרכזי (הכי חזק)
            if active_emotions:
                dominant = max(active_emotions, key=lambda x: x.intensity.value)
                wheel_data['center_emotion'] = {
                    'type': dominant.emotion_type.value,
                    'hebrew_name': self.emotion_translations.get(dominant.emotion_type, dominant.emotion_type.value),
                    'intensity': dominant.intensity.value,
                    'color': self.emotion_colors.get(dominant.emotion_type, '#CCCCCC')
                }
            
            return wheel_data
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת גלגל רגשות: {e}")
            return {}
    
    def _create_intensity_meter_data(self) -> Dict[str, Any]:
        """יצירת נתוני מד עוצמה"""
        try:
            if not self.intensity_history:
                return {'current': 0.0, 'trend': 'stable'}
            
            current_intensity = self.intensity_history[-1]['intensity']
            
            # חישוב מגמה
            if len(self.intensity_history) >= 5:
                recent_avg = sum(item['intensity'] for item in list(self.intensity_history)[-5:]) / 5
                previous_avg = sum(item['intensity'] for item in list(self.intensity_history)[-10:-5]) / 5 if len(self.intensity_history) >= 10 else recent_avg
                
                if recent_avg > previous_avg + 0.1:
                    trend = 'increasing'
                elif recent_avg < previous_avg - 0.1:
                    trend = 'decreasing'
                else:
                    trend = 'stable'
            else:
                trend = 'stable'
            
            return {
                'current': current_intensity,
                'trend': trend,
                'percentage': int(current_intensity * 20)  # המרה ל-0-100
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת מד עוצמה: {e}")
            return {'current': 0.0, 'trend': 'stable'}
    
    def _create_dominant_emotion_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לרגש דומיננטי"""
        try:
            current_state = display_data.get('current_state', {})
            dominant_emotion = current_state.get('dominant_emotion')
            dominant_intensity = current_state.get('dominant_intensity', 0.0)
            
            if not dominant_emotion:
                return '<p>אין רגש דומיננטי כרגע</p>'
            
            emotion_type = EmotionType(dominant_emotion)
            hebrew_name = self.emotion_translations.get(emotion_type, dominant_emotion)
            color = self.emotion_colors.get(emotion_type, '#CCCCCC')
            
            return f'''
            <div class="dominant-emotion-circle" style="background-color: {color};">
                <span style="color: white; font-weight: bold;">{hebrew_name}</span>
            </div>
            <h3>{hebrew_name}</h3>
            <p>עוצמה: {dominant_intensity:.2f}</p>
            '''
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת רגש דומיננטי: {str(e)}</p>'
    
    def _create_active_emotions_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לרגשות פעילים"""
        try:
            active_emotions = display_data.get('active_emotions', [])
            
            if not active_emotions:
                return '<p>אין רגשות פעילים כרגע</p>'
            
            html = '<h4>רגשות פעילים:</h4>'
            
            for emotion in active_emotions[:self.display_settings['max_display_emotions']]:
                html += f'''
                <div class="emotion-item">
                    <span class="emotion-name">{emotion['hebrew_name']}</span>
                    <div class="emotion-intensity">
                        <div class="intensity-bar">
                            <div class="intensity-fill" 
                                 style="width: {emotion['intensity_percentage']}%; background-color: {emotion['color']};"
                                 data-width="{emotion['intensity_percentage']}%">
                            </div>
                        </div>
                        <span>{emotion['intensity']:.2f}</span>
                    </div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת רגשות פעילים: {str(e)}</p>'
    
    def _create_intensity_graph_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לגרף עוצמה"""
        try:
            return '''
            <h4>גרף עוצמה רגשית:</h4>
            <div id="intensityChart" style="height: 200px; background: rgba(255,255,255,0.1); border-radius: 5px;">
                <p style="text-align: center; padding-top: 80px;">גרף עוצמה יוצג כאן</p>
            </div>
            '''
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת גרף עוצמה: {str(e)}</p>'
    
    def _create_blends_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לעירובים רגשיים"""
        try:
            blends = display_data.get('emotion_blends', [])
            
            if not blends:
                return '<h4>עירובים רגשיים:</h4><p>אין עירובים פעילים כרגע</p>'
            
            html = '<h4>עירובים רגשיים:</h4>'
            
            for blend in blends[:5]:  # מקסימום 5 עירובים
                html += f'''
                <div class="blend-item">
                    <span>{blend['name']}</span>
                    <div class="blend-colors">
                '''
                
                for emotion in blend['emotions']:
                    html += f'<div class="blend-color" style="background-color: {emotion['color']};"></div>'
                
                html += f'''
                    </div>
                    <span>{blend['overall_intensity']:.2f}</span>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת עירובים: {str(e)}</p>'
    
    def _create_statistics_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לסטטיסטיקות"""
        try:
            stats = display_data.get('statistics', {})
            
            html = '''
            <h4>סטטיסטיקות:</h4>
            <div class="stats-grid">
            '''
            
            if 'total_emotions_recorded' in stats:
                html += f'''
                <div class="stat-item">
                    <span class="stat-value">{stats['total_emotions_recorded']}</span>
                    <span class="stat-label">רגשות נרשמו</span>
                </div>
                '''
            
            if 'average_intensity' in stats:
                html += f'''
                <div class="stat-item">
                    <span class="stat-value">{stats['average_intensity']:.2f}</span>
                    <span class="stat-label">עוצמה ממוצעת</span>
                </div>
                '''
            
            if 'most_frequent_emotion' in stats and stats['most_frequent_emotion']:
                mfe = stats['most_frequent_emotion']
                html += f'''
                <div class="stat-item">
                    <span class="stat-value">{mfe['hebrew_name']}</span>
                    <span class="stat-label">רגש שכיח</span>
                </div>
                '''
            
            html += '</div>'
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת סטטיסטיקות: {str(e)}</p>'
    
    def _get_error_visualization(self, error_message: str) -> str:
        """תצוגת שגיאה"""
        return f'''
        <div class="emotion-display-container" dir="rtl">
            <div style="text-align: center; padding: 40px;">
                <h3 style="color: #ff6b6b;">שגיאה בתצוגת הרגשות</h3>
                <p>{error_message}</p>
                <button onclick="location.reload()" style="padding: 10px 20px; background: #4ecdc4; color: white; border: none; border-radius: 5px;">נסה שוב</button>
            </div>
        </div>
        '''