#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 State Monitor - מוניטור מצבי תודעה
==================================

רכיב UI מתקדם לניטור ותצוגת מצבי התודעה.
מציג 6 רמות תודעה, מעברים ביניהן וניתוח דפוסים.

תכונות מרכזיות:
- ניטור 6 רמות תודעה בזמן אמת
- תצוגת מעברים ודפוסים
- ניהול קשב ואנרגיה
- חיזוי מצבים עתידיים
- ממשק עברי אינטראקטיבי
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from collections import deque, defaultdict

from ..core.state_engine import StateEngine
from ..models.states import (
    ConsciousnessLevel, AttentionState, EmotionalState, 
    CognitiveMode, EnergyLevel, ConsciousnessState
)


class StateMonitor:
    """מוניטור מצבי תודעה עם ויזואליזציה מתקדמת"""
    
    def __init__(self, state_engine: StateEngine = None):
        """אתחול מוניטור מצבי התודעה"""
        self.logger = logging.getLogger(__name__)
        
        # מנוע מצבי התודעה
        self.state_engine = state_engine
        
        # הגדרות תצוגה
        self.monitor_settings = {
            'update_interval': 2000,  # מילישניות
            'show_transitions': True,
            'show_predictions': True,
            'show_energy_meter': True,
            'show_attention_map': True,
            'history_depth': 50,
            'animation_enabled': True
        }
        
        # היסטוריית מצבים לגרפים
        self.state_history: deque = deque(maxlen=100)
        self.transition_history: deque = deque(maxlen=50)
        self.energy_history: deque = deque(maxlen=60)  # דקה אחרונה
        
        # סטטיסטיקות מוניטור
        self.monitor_stats = {
            'states_monitored': 0,
            'transitions_detected': 0,
            'predictions_made': 0,
            'patterns_found': 0,
            'alerts_triggered': 0,
            'monitoring_time': 0.0
        }
        
        # התראות ואירועים
        self.active_alerts = []
        self.alert_thresholds = {
            'low_energy': 0.2,
            'high_stress': 0.8,
            'attention_overload': 1.0,
            'instability': 0.3
        }
        
        # תרגומים עבריים
        self.consciousness_level_translations = {
            ConsciousnessLevel.UNCONSCIOUS: 'חוסר הכרה',
            ConsciousnessLevel.SUBCONSCIOUS: 'תת-מודע',
            ConsciousnessLevel.PRECONSCIOUS: 'טרום-מודע',
            ConsciousnessLevel.CONSCIOUS: 'מודע',
            ConsciousnessLevel.HYPERCONSCIOUS: 'היפר-מודע',
            ConsciousnessLevel.TRANSCENDENT: 'טרנסצנדנטי'
        }
        
        self.attention_state_translations = {
            AttentionState.SCATTERED: 'מפוזר',
            AttentionState.FOCUSED: 'מרוכז',
            AttentionState.DIVIDED: 'מחולק',
            AttentionState.SUSTAINED: 'מתמשך',
            AttentionState.SELECTIVE: 'סלקטיבי',
            AttentionState.ALTERNATING: 'מתחלף',
            AttentionState.ABSORBED: 'שקוע'
        }
        
        self.cognitive_mode_translations = {
            CognitiveMode.ANALYTICAL: 'אנליטי',
            CognitiveMode.CREATIVE: 'יצירתי',
            CognitiveMode.INTUITIVE: 'אינטואיטיבי',
            CognitiveMode.REFLECTIVE: 'הרהורי',
            CognitiveMode.REACTIVE: 'תגובתי',
            CognitiveMode.DELIBERATE: 'מתחשב',
            CognitiveMode.ASSOCIATIVE: 'אסוציאטיבי',
            CognitiveMode.CRITICAL: 'ביקורתי',
            CognitiveMode.EXPLORATORY: 'חקרני',
            CognitiveMode.PROBLEM_SOLVING: 'פותר בעיות'
        }
        
        self.emotional_state_translations = {
            EmotionalState.NEUTRAL: 'נייטרלי',
            EmotionalState.POSITIVE: 'חיובי',
            EmotionalState.NEGATIVE: 'שלילי',
            EmotionalState.MIXED: 'מעורב',
            EmotionalState.EXCITED: 'נרגש',
            EmotionalState.CALM: 'רגוע',
            EmotionalState.STRESSED: 'לחוץ',
            EmotionalState.EUPHORIC: 'אופורי',
            EmotionalState.MELANCHOLIC: 'מלנכולי',
            EmotionalState.ANXIOUS: 'חרד',
            EmotionalState.CONFIDENT: 'בטוח',
            EmotionalState.CURIOUS: 'סקרן',
            EmotionalState.BORED: 'משועמם',
            EmotionalState.PASSIONATE: 'נלהב',
            EmotionalState.CONTEMPLATIVE: 'מהרהר'
        }
        
        self.energy_level_translations = {
            EnergyLevel.EXHAUSTED: 'מותש',
            EnergyLevel.LOW: 'נמוך',
            EnergyLevel.MODERATE: 'בינוני',
            EnergyLevel.HIGH: 'גבוה',
            EnergyLevel.PEAK: 'שיא'
        }
        
        # צבעים לרמות תודעה
        self.consciousness_colors = {
            ConsciousnessLevel.UNCONSCIOUS: '#2c3e50',      # אפור כהה
            ConsciousnessLevel.SUBCONSCIOUS: '#34495e',     # אפור
            ConsciousnessLevel.PRECONSCIOUS: '#7f8c8d',     # אפור בהיר
            ConsciousnessLevel.CONSCIOUS: '#3498db',        # כחול
            ConsciousnessLevel.HYPERCONSCIOUS: '#9b59b6',   # סגול
            ConsciousnessLevel.TRANSCENDENT: '#f1c40f'      # זהב
        }
        
        self.logger.info("מוניטור מצבי תודעה אותחל")
    
    def update_monitor(self) -> Dict[str, Any]:
        """עדכון מוניטור מצבי התודעה"""
        try:
            if not self.state_engine:
                return {'error': 'מנוע מצבי תודעה אינו זמין'}
            
            # קבלת מצב נוכחי
            current_state = self.state_engine.get_current_state()
            
            # עדכון היסטוריות
            self._update_histories(current_state)
            
            # זיהוי דפוסים
            detected_patterns = self.state_engine.detect_state_patterns()
            
            # חיזוי מצב הבא
            predicted_state = self.state_engine.predict_next_state()
            
            # בדיקת התראות
            alerts = self._check_alerts(current_state)
            
            # סטטיסטיקות מתקדמות
            advanced_stats = self._calculate_advanced_statistics()
            
            # נתוני ויזואליזציה
            visualization_data = self._generate_visualization_data(current_state)
            
            # נתוני מוניטור
            monitor_data = {
                'timestamp': datetime.now().isoformat(),
                'current_state': self._format_state_for_display(current_state),
                'state_history': self._get_formatted_history(),
                'transition_analysis': self._analyze_transitions(),
                'detected_patterns': [self._format_pattern(p) for p in detected_patterns],
                'predicted_state': predicted_state,
                'active_alerts': alerts,
                'advanced_statistics': advanced_stats,
                'visualization_data': visualization_data,
                'system_health': self._assess_system_health(current_state)
            }
            
            # עדכון סטטיסטיקות מוניטור
            self.monitor_stats['states_monitored'] += 1
            self.monitor_stats['patterns_found'] = len(detected_patterns)
            self.monitor_stats['alerts_triggered'] = len(alerts)
            
            return monitor_data
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מוניטור: {e}")
            return {'error': str(e)}
    
    def get_monitor_html(self) -> str:
        """יצירת HTML עבור מוניטור מצבי התודעה"""
        try:
            # קבלת נתוני מוניטור עדכניים
            monitor_data = self.update_monitor()
            
            if 'error' in monitor_data:
                return self._get_error_html(monitor_data['error'])
            
            html_content = f'''
            <div class="state-monitor-container" dir="rtl">
                <div class="monitor-header">
                    <h2>📊 מוניטור מצבי תודעה</h2>
                    <div class="monitor-controls">
                        <button onclick="pauseMonitoring()" id="pauseMonitorBtn">השהה</button>
                        <button onclick="resetMonitor()">איפוס</button>
                        <button onclick="exportData()">ייצא נתונים</button>
                    </div>
                </div>
                
                <div class="current-state-panel">
                    {self._create_current_state_html(monitor_data)}
                </div>
                
                <div class="monitor-content">
                    <div class="consciousness-wheel">
                        {self._create_consciousness_wheel_html(monitor_data)}
                    </div>
                    
                    <div class="state-meters">
                        {self._create_state_meters_html(monitor_data)}
                    </div>
                </div>
                
                <div class="monitor-graphs">
                    <div class="state-timeline">
                        {self._create_timeline_html(monitor_data)}
                    </div>
                    
                    <div class="attention-map">
                        {self._create_attention_map_html(monitor_data)}
                    </div>
                </div>
                
                <div class="patterns-and-alerts">
                    <div class="patterns-panel">
                        {self._create_patterns_html(monitor_data)}
                    </div>
                    
                    <div class="alerts-panel">
                        {self._create_alerts_html(monitor_data)}
                    </div>
                </div>
                
                <div class="statistics-panel">
                    {self._create_statistics_html(monitor_data)}
                </div>
            </div>
            '''
            
            return html_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת HTML מוניטור: {e}")
            return self._get_error_html(str(e))
    
    def get_monitor_css(self) -> str:
        """קבלת CSS עבור מוניטור מצבי התודעה"""
        return '''
        .state-monitor-container {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            min-height: 800px;
        }
        
        .monitor-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            padding-bottom: 15px;
        }
        
        .monitor-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        
        .monitor-controls {
            display: flex;
            gap: 10px;
        }
        
        .monitor-controls button {
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s ease;
        }
        
        .monitor-controls button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .current-state-panel {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .consciousness-level-display {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(255,255,255,0.5);
            animation: levelPulse 2s infinite;
        }
        
        @keyframes levelPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .state-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .state-detail-item {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 10px;
            text-align: center;
        }
        
        .detail-label {
            font-size: 12px;
            opacity: 0.8;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-size: 16px;
            font-weight: bold;
        }
        
        .monitor-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .consciousness-wheel {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
            position: relative;
            min-height: 250px;
        }
        
        .wheel-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
            animation: wheelRotate 10s linear infinite;
        }
        
        @keyframes wheelRotate {
            from { transform: translate(-50%, -50%) rotate(0deg); }
            to { transform: translate(-50%, -50%) rotate(360deg); }
        }
        
        .wheel-segment {
            position: absolute;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .wheel-segment:hover {
            transform: scale(1.2);
        }
        
        .wheel-segment.active {
            box-shadow: 0 0 20px rgba(255,255,255,0.8);
            transform: scale(1.3);
        }
        
        .state-meters {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
        }
        
        .meter-item {
            margin-bottom: 20px;
        }
        
        .meter-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .meter-bar {
            height: 10px;
            background: rgba(255,255,255,0.2);
            border-radius: 5px;
            overflow: hidden;
            position: relative;
        }
        
        .meter-fill {
            height: 100%;
            border-radius: 5px;
            transition: width 0.5s ease;
            position: relative;
        }
        
        .meter-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: meterShimmer 2s infinite;
        }
        
        @keyframes meterShimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .monitor-graphs {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .state-timeline {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
            position: relative;
            min-height: 200px;
        }
        
        .timeline-item {
            position: absolute;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .timeline-item:hover {
            transform: scale(1.5);
        }
        
        .timeline-line {
            position: absolute;
            height: 2px;
            background: rgba(255,255,255,0.3);
            top: 10px;
        }
        
        .attention-map {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
            position: relative;
        }
        
        .attention-focus {
            position: absolute;
            border-radius: 50%;
            background: rgba(255,255,255,0.4);
            cursor: pointer;
            transition: all 0.3s ease;
            animation: focusPulse 3s infinite;
        }
        
        @keyframes focusPulse {
            0%, 100% { opacity: 0.4; }
            50% { opacity: 0.8; }
        }
        
        .patterns-and-alerts {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .patterns-panel, .alerts-panel {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
        }
        
        .pattern-item {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 10px;
            border-right: 4px solid #3498db;
        }
        
        .pattern-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .pattern-details {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .alert-item {
            background: rgba(231, 76, 60, 0.2);
            border: 1px solid rgba(231, 76, 60, 0.5);
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 10px;
            animation: alertBlink 1s infinite alternate;
        }
        
        @keyframes alertBlink {
            from { background: rgba(231, 76, 60, 0.2); }
            to { background: rgba(231, 76, 60, 0.4); }
        }
        
        .alert-high { border-color: #e74c3c; }
        .alert-medium { border-color: #f39c12; }
        .alert-low { border-color: #f1c40f; }
        
        .statistics-panel {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }
        
        .stat-card {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .prediction-panel {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
            border: 2px dashed rgba(255,255,255,0.3);
        }
        
        .prediction-title {
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .predicted-state {
            text-align: center;
            font-size: 18px;
            color: #f1c40f;
        }
        
        /* סגנונות ישראליים */
        .hebrew-text {
            font-family: 'Assistant', 'Segoe UI', sans-serif;
            direction: rtl;
        }
        
        .consciousness-level-0 { color: #2c3e50; }
        .consciousness-level-1 { color: #34495e; }
        .consciousness-level-2 { color: #7f8c8d; }
        .consciousness-level-3 { color: #3498db; }
        .consciousness-level-4 { color: #9b59b6; }
        .consciousness-level-5 { color: #f1c40f; }
        '''
    
    def get_monitor_javascript(self) -> str:
        """קבלת JavaScript עבור מוניטור מצבי התודעה"""
        return f'''
        // הגדרות מוניטור מצבי תודעה
        const monitorConfig = {json.dumps(self.monitor_settings, ensure_ascii=False)};
        let monitoringPaused = false;
        let monitorInterval = null;
        let selectedStatePoint = null;
        
        class StateMonitor {{
            constructor() {{
                this.stateData = [];
                this.alertsData = [];
                this.initialize();
            }}
            
            initialize() {{
                this.setupEventListeners();
                this.startMonitoring();
                this.initializeVisualizations();
            }}
            
            setupEventListeners() {{
                // בחירת נקודת מצב בטיימליין
                document.addEventListener('click', (e) => {{
                    if (e.target.classList.contains('timeline-item')) {{
                        this.selectStatePoint(e.target);
                    }}
                }});
                
                // hover על גלגל התודעה
                document.addEventListener('mouseover', (e) => {{
                    if (e.target.classList.contains('wheel-segment')) {{
                        this.highlightLevel(e.target);
                    }}
                }});
                
                // מקשי קיצור
                document.addEventListener('keydown', (e) => {{
                    if (e.ctrlKey) {{
                        switch(e.key) {{
                            case ' ':
                                this.pauseMonitoring();
                                e.preventDefault();
                                break;
                            case 'r':
                                this.resetMonitor();
                                e.preventDefault();
                                break;
                            case 'e':
                                this.exportData();
                                e.preventDefault();
                                break;
                        }}
                    }}
                }});
            }}
            
            startMonitoring() {{
                if (monitorConfig.animation_enabled && !monitoringPaused) {{
                    monitorInterval = setInterval(() => {{
                        this.updateMonitorDisplay();
                    }}, monitorConfig.update_interval);
                }}
            }}
            
            stopMonitoring() {{
                if (monitorInterval) {{
                    clearInterval(monitorInterval);
                    monitorInterval = null;
                }}
            }}
            
            updateMonitorDisplay() {{
                if (monitoringPaused) return;
                
                console.log('מעדכן מוניטור מצבי תודעה...');
                
                // עדכון מצב נוכחי
                this.updateCurrentState();
                
                // עדכון מדדים
                this.updateMeters();
                
                // עדכון טיימליין
                this.updateTimeline();
                
                // עדכון מפת קשב
                this.updateAttentionMap();
                
                // בדיקת התראות
                this.checkAlerts();
            }}
            
            updateCurrentState() {{
                // עדכון תצוגת מצב נוכחי
                const levelDisplay = document.querySelector('.consciousness-level-display');
                if (levelDisplay) {{
                    this.animateStateChange(levelDisplay);
                }}
            }}
            
            animateStateChange(element) {{
                element.style.animation = 'none';
                element.offsetHeight; // trigger reflow
                element.style.animation = 'levelPulse 2s infinite';
            }}
            
            updateMeters() {{
                // עדכון מדדי המצב
                const meters = document.querySelectorAll('.meter-fill');
                meters.forEach(meter => {{
                    const targetWidth = meter.dataset.value || '0%';
                    meter.style.width = targetWidth;
                }});
            }}
            
            updateTimeline() {{
                // עדכון טיימליין מצבים
                console.log('מעדכן טיימליין מצבים...');
                // כאן יהיה קוד לעדכון הטיימליין
            }}
            
            updateAttentionMap() {{
                // עדכון מפת הקשב
                const attentionFoci = document.querySelectorAll('.attention-focus');
                attentionFoci.forEach(focus => {{
                    this.animateAttentionFocus(focus);
                }});
            }}
            
            animateAttentionFocus(element) {{
                const intensity = parseFloat(element.dataset.intensity || 0.5);
                const size = 20 + (intensity * 30);
                element.style.width = size + 'px';
                element.style.height = size + 'px';
            }}
            
            checkAlerts() {{
                // בדיקת התראות חדשות
                const alertsPanel = document.querySelector('.alerts-panel');
                if (alertsPanel) {{
                    this.updateAlertsDisplay();
                }}
            }}
            
            updateAlertsDisplay() {{
                // עדכון תצוגת התראות
                const alertItems = document.querySelectorAll('.alert-item');
                alertItems.forEach(alert => {{
                    this.animateAlert(alert);
                }});
            }}
            
            animateAlert(element) {{
                element.style.animation = 'alertBlink 1s infinite alternate';
            }}
            
            selectStatePoint(element) {{
                // ביטול בחירה קודמת
                document.querySelectorAll('.timeline-item').forEach(item => {{
                    item.classList.remove('selected');
                }});
                
                // בחירת נקודה חדשה
                element.classList.add('selected');
                selectedStatePoint = element.dataset.stateId;
                
                this.showStateDetails(selectedStatePoint);
            }}
            
            showStateDetails(stateId) {{
                console.log('מציג פרטי מצב:', stateId);
                // כאן יהיה קוד להצגת פרטי מצב
            }}
            
            highlightLevel(element) {{
                const level = element.dataset.level;
                console.log('מדגיש רמת תודעה:', level);
                
                // הוספת אפקט הדגשה
                element.style.boxShadow = '0 0 20px rgba(255,255,255,0.8)';
                
                // הסרת הדגשה לאחר זמן קצר
                setTimeout(() => {{
                    element.style.boxShadow = '';
                }}, 2000);
            }}
            
            pauseMonitoring() {{
                monitoringPaused = !monitoringPaused;
                const pauseBtn = document.getElementById('pauseMonitorBtn');
                
                if (monitoringPaused) {{
                    this.stopMonitoring();
                    pauseBtn.textContent = 'המשך';
                    pauseBtn.style.background = 'rgba(46, 204, 113, 0.3)';
                }} else {{
                    this.startMonitoring();
                    pauseBtn.textContent = 'השהה';
                    pauseBtn.style.background = 'rgba(255,255,255,0.2)';
                }}
            }}
            
            resetMonitor() {{
                // איפוס המוניטור
                this.stateData = [];
                this.alertsData = [];
                
                // ניקוי תצוגות
                const timeline = document.querySelector('.state-timeline');
                if (timeline) {{
                    timeline.innerHTML = '<h4>טיימליין מצבים</h4><p>אין נתונים להצגה</p>';
                }}
                
                console.log('מוניטור אופס');
            }}
            
            exportData() {{
                // ייצוא נתוני המוניטור
                const exportData = {{
                    timestamp: new Date().toISOString(),
                    stateData: this.stateData,
                    alertsData: this.alertsData,
                    config: monitorConfig
                }};
                
                const dataStr = JSON.stringify(exportData, null, 2);
                const dataBlob = new Blob([dataStr], {{type: 'application/json'}});
                
                const link = document.createElement('a');
                link.href = URL.createObjectURL(dataBlob);
                link.download = `consciousness_monitor_${{new Date().getTime()}}.json`;
                link.click();
                
                console.log('נתונים יוצאו בהצלחה');
            }}
            
            initializeVisualizations() {{
                // אתחול ויזואליזציות
                this.createConsciousnessWheel();
                this.createStateMeters();
                this.createTimeline();
            }}
            
            createConsciousnessWheel() {{
                // יצירת גלגל התודעה
                const wheel = document.querySelector('.consciousness-wheel');
                if (!wheel) return;
                
                const levels = [
                    'חוסר הכרה', 'תת-מודע', 'טרום-מודע', 
                    'מודע', 'היפר-מודע', 'טרנסצנדנטי'
                ];
                
                levels.forEach((level, index) => {{
                    const segment = document.createElement('div');
                    segment.className = 'wheel-segment';
                    segment.dataset.level = index;
                    segment.textContent = level;
                    
                    // מיקום בעיגול
                    const angle = (index * 60) * (Math.PI / 180);
                    const radius = 80;
                    const x = 50 + Math.cos(angle) * radius;
                    const y = 50 + Math.sin(angle) * radius;
                    
                    segment.style.left = x + '%';
                    segment.style.top = y + '%';
                    segment.style.background = this.getLevelColor(index);
                    
                    wheel.appendChild(segment);
                }});
            }}
            
            getLevelColor(level) {{
                const colors = [
                    '#2c3e50', '#34495e', '#7f8c8d',
                    '#3498db', '#9b59b6', '#f1c40f'
                ];
                return colors[level] || '#95a5a6';
            }}
            
            createStateMeters() {{
                // יצירת מדדי מצב
                console.log('יוצר מדדי מצב...');
            }}
            
            createTimeline() {{
                // יצירת טיימליין
                console.log('יוצר טיימליין מצבים...');
            }}
        }}
        
        // פונקציות גלובליות
        function pauseMonitoring() {{
            window.stateMonitor.pauseMonitoring();
        }}
        
        function resetMonitor() {{
            window.stateMonitor.resetMonitor();
        }}
        
        function exportData() {{
            window.stateMonitor.exportData();
        }}
        
        // אתחול
        document.addEventListener('DOMContentLoaded', function() {{
            window.stateMonitor = new StateMonitor();
        }});
        
        // ניקוי בסגירה
        window.addEventListener('beforeunload', function() {{
            if (window.stateMonitor) {{
                window.stateMonitor.stopMonitoring();
            }}
        }});
        '''
    
    def trigger_state_transition(self, target_level: ConsciousnessLevel = None,
                                target_attention: AttentionState = None,
                                target_cognitive: CognitiveMode = None) -> bool:
        """הפעלת מעבר מצב ידני"""
        try:
            if not self.state_engine:
                return False
            
            success = self.state_engine.transition_to_state(
                target_level=target_level,
                target_attention=target_attention,
                target_cognitive=target_cognitive,
                trigger="manual_ui_trigger"
            )
            
            if success:
                self.monitor_stats['transitions_detected'] += 1
                self.logger.info(f"בוצע מעבר מצב ידני")
            
            return success
            
        except Exception as e:
            self.logger.error(f"שגיאה במעבר מצב ידני: {e}")
            return False
    
    def _update_histories(self, current_state: ConsciousnessState):
        """עדכון היסטוריות המוניטור"""
        try:
            # היסטוריית מצבים
            state_snapshot = {
                'timestamp': datetime.now().isoformat(),
                'consciousness_level': current_state.consciousness_level.value,
                'attention_state': current_state.attention_state.value,
                'cognitive_mode': current_state.cognitive_mode.value,
                'emotional_state': current_state.emotional_state.value,
                'energy_level': current_state.energy_level.value,
                'stability_score': current_state.stability_score
            }
            self.state_history.append(state_snapshot)
            
            # היסטוריית אנרגיה
            energy_snapshot = {
                'timestamp': datetime.now().isoformat(),
                'energy_level': current_state.energy_level.value,
                'stability': current_state.stability_score
            }
            self.energy_history.append(energy_snapshot)
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון היסטוריות: {e}")
    
    def _format_state_for_display(self, state: ConsciousnessState) -> Dict[str, Any]:
        """עיצוב מצב לתצוגה"""
        try:
            return {
                'consciousness_level': {
                    'value': state.consciousness_level.value,
                    'name': state.consciousness_level.name,
                    'hebrew': self.consciousness_level_translations[state.consciousness_level],
                    'color': self.consciousness_colors[state.consciousness_level]
                },
                'attention_state': {
                    'value': state.attention_state.value,
                    'hebrew': self.attention_state_translations[state.attention_state]
                },
                'cognitive_mode': {
                    'value': state.cognitive_mode.value,
                    'hebrew': self.cognitive_mode_translations[state.cognitive_mode]
                },
                'emotional_state': {
                    'value': state.emotional_state.value,
                    'hebrew': self.emotional_state_translations[state.emotional_state]
                },
                'energy_level': {
                    'value': state.energy_level.value,
                    'hebrew': self.energy_level_translations[state.energy_level],
                    'percentage': state.energy_level.value * 20  # המרה ל-0-100
                },
                'metrics': state.metrics.serialize(),
                'stability_score': round(state.stability_score, 2),
                'duration': state.duration.total_seconds(),
                'total_attention': round(state.calculate_total_attention(), 2),
                'is_overloaded': state.is_overloaded(),
                'primary_focus': state.primary_focus.serialize() if state.primary_focus else None,
                'secondary_focuses_count': len(state.secondary_focuses)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב מצב: {e}")
            return {}
    
    def _get_formatted_history(self) -> List[Dict[str, Any]]:
        """קבלת היסטוריה מעוצבת"""
        try:
            return list(self.state_history)[-self.monitor_settings['history_depth']:]
        except Exception:
            return []
    
    def _analyze_transitions(self) -> Dict[str, Any]:
        """ניתוח מעברי מצבים"""
        try:
            if len(self.state_history) < 2:
                return {}
            
            recent_states = list(self.state_history)[-10:]
            transitions = []
            
            for i in range(1, len(recent_states)):
                prev_state = recent_states[i-1]
                curr_state = recent_states[i]
                
                if prev_state['consciousness_level'] != curr_state['consciousness_level']:
                    transition = {
                        'from_level': prev_state['consciousness_level'],
                        'to_level': curr_state['consciousness_level'],
                        'timestamp': curr_state['timestamp'],
                        'direction': 'up' if curr_state['consciousness_level'] > prev_state['consciousness_level'] else 'down'
                    }
                    transitions.append(transition)
            
            return {
                'recent_transitions': transitions,
                'transition_frequency': len(transitions),
                'dominant_direction': self._get_dominant_direction(transitions),
                'stability_trend': self._calculate_stability_trend()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח מעברים: {e}")
            return {}
    
    def _format_pattern(self, pattern) -> Dict[str, Any]:
        """עיצוב דפוס לתצוגה"""
        try:
            return {
                'id': pattern.id,
                'name': pattern.name,
                'description': pattern.description,
                'frequency': pattern.frequency,
                'reliability': round(pattern.reliability, 2),
                'average_duration': round(pattern.average_duration, 2),
                'state_sequence': pattern.state_sequence,
                'triggers': pattern.triggers
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _check_alerts(self, current_state: ConsciousnessState) -> List[Dict[str, Any]]:
        """בדיקת התראות"""
        try:
            alerts = []
            
            # התראת אנרגיה נמוכה
            if current_state.energy_level.value <= self.alert_thresholds['low_energy']:
                alerts.append({
                    'type': 'low_energy',
                    'severity': 'high',
                    'message': 'רמת אנרגיה נמוכה מאוד',
                    'value': current_state.energy_level.value,
                    'threshold': self.alert_thresholds['low_energy']
                })
            
            # התראת עומס קשב
            if current_state.is_overloaded():
                alerts.append({
                    'type': 'attention_overload',
                    'severity': 'medium',
                    'message': 'עומס קשב יתר',
                    'value': current_state.calculate_total_attention(),
                    'threshold': self.alert_thresholds['attention_overload']
                })
            
            # התראת אי-יציבות
            if current_state.stability_score < self.alert_thresholds['instability']:
                alerts.append({
                    'type': 'instability',
                    'severity': 'medium',
                    'message': 'אי-יציבות במצב התודעה',
                    'value': current_state.stability_score,
                    'threshold': self.alert_thresholds['instability']
                })
            
            # עדכון התראות פעילות
            self.active_alerts = alerts
            
            return alerts
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת התראות: {e}")
            return []
    
    def _calculate_advanced_statistics(self) -> Dict[str, Any]:
        """חישוב סטטיסטיקות מתקדמות"""
        try:
            if not self.state_history:
                return {}
            
            recent_states = list(self.state_history)[-20:]
            
            # התפלגות רמות תודעה
            level_distribution = defaultdict(int)
            stability_scores = []
            energy_levels = []
            
            for state in recent_states:
                level_distribution[state['consciousness_level']] += 1
                stability_scores.append(state['stability_score'])
                energy_levels.append(state['energy_level'])
            
            stats = {
                'level_distribution': dict(level_distribution),
                'average_stability': sum(stability_scores) / len(stability_scores),
                'average_energy': sum(energy_levels) / len(energy_levels),
                'stability_trend': self._calculate_stability_trend(),
                'time_in_each_level': self._calculate_time_distribution(),
                'transition_patterns': self._analyze_transition_patterns(),
                'consciousness_complexity': self._calculate_consciousness_complexity()
            }
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב סטטיסטיקות: {e}")
            return {}
    
    def _generate_visualization_data(self, current_state: ConsciousnessState) -> Dict[str, Any]:
        """יצירת נתוני ויזואליזציה"""
        try:
            return {
                'consciousness_wheel_data': self._create_wheel_data(current_state),
                'meter_data': self._create_meter_data(current_state),
                'timeline_data': self._create_timeline_data(),
                'attention_map_data': self._create_attention_map_data(current_state)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת נתוני ויזואליזציה: {e}")
            return {}
    
    def _assess_system_health(self, current_state: ConsciousnessState) -> Dict[str, Any]:
        """הערכת בריאות המערכת"""
        try:
            health_score = 0.0
            factors = []
            
            # גורם יציבות
            stability_factor = current_state.stability_score
            health_score += stability_factor * 0.3
            factors.append(('יציבות', stability_factor))
            
            # גורם אנרגיה
            energy_factor = current_state.energy_level.value / 5.0
            health_score += energy_factor * 0.2
            factors.append(('אנרגיה', energy_factor))
            
            # גורם קשב
            attention_factor = min(1.0, 1.0 / max(0.1, current_state.calculate_total_attention()))
            health_score += attention_factor * 0.2
            factors.append(('קשב', attention_factor))
            
            # גורם מטריקות
            metrics_factor = current_state.metrics.calculate_overall_score()
            health_score += metrics_factor * 0.3
            factors.append(('מטריקות כללי', metrics_factor))
            
            health_status = 'excellent' if health_score > 0.8 else \
                           'good' if health_score > 0.6 else \
                           'fair' if health_score > 0.4 else 'poor'
            
            return {
                'overall_score': round(health_score, 2),
                'status': health_status,
                'status_hebrew': {
                    'excellent': 'מצוין',
                    'good': 'טוב',
                    'fair': 'בינוני',
                    'poor': 'גרוע'
                }[health_status],
                'contributing_factors': factors,
                'recommendations': self._generate_health_recommendations(health_score, factors)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בהערכת בריאות מערכת: {e}")
            return {}
    
    def _get_dominant_direction(self, transitions: List[Dict[str, Any]]) -> str:
        """קבלת כיוון מעברים דומיננטי"""
        if not transitions:
            return 'stable'
        
        up_count = sum(1 for t in transitions if t['direction'] == 'up')
        down_count = sum(1 for t in transitions if t['direction'] == 'down')
        
        if up_count > down_count:
            return 'ascending'
        elif down_count > up_count:
            return 'descending'
        else:
            return 'balanced'
    
    def _calculate_stability_trend(self) -> str:
        """חישוב מגמת יציבות"""
        try:
            if len(self.state_history) < 5:
                return 'insufficient_data'
            
            recent_stability = [s['stability_score'] for s in list(self.state_history)[-5:]]
            early_stability = [s['stability_score'] for s in list(self.state_history)[-10:-5]]
            
            if not early_stability:
                return 'insufficient_data'
            
            recent_avg = sum(recent_stability) / len(recent_stability)
            early_avg = sum(early_stability) / len(early_stability)
            
            if recent_avg > early_avg + 0.1:
                return 'improving'
            elif recent_avg < early_avg - 0.1:
                return 'declining'
            else:
                return 'stable'
                
        except Exception:
            return 'unknown'
    
    def _calculate_time_distribution(self) -> Dict[str, float]:
        """חישוב התפלגות זמן ברמות שונות"""
        try:
            if not self.state_history:
                return {}
            
            level_times = defaultdict(float)
            
            for i in range(1, len(self.state_history)):
                prev_state = self.state_history[i-1]
                curr_state = self.state_history[i]
                
                prev_time = datetime.fromisoformat(prev_state['timestamp'])
                curr_time = datetime.fromisoformat(curr_state['timestamp'])
                duration = (curr_time - prev_time).total_seconds()
                
                level_times[prev_state['consciousness_level']] += duration
            
            return dict(level_times)
            
        except Exception:
            return {}
    
    def _analyze_transition_patterns(self) -> Dict[str, Any]:
        """ניתוח דפוסי מעברים"""
        try:
            if len(self.state_history) < 3:
                return {}
            
            patterns = defaultdict(int)
            
            for i in range(2, len(self.state_history)):
                state1 = self.state_history[i-2]['consciousness_level']
                state2 = self.state_history[i-1]['consciousness_level']
                state3 = self.state_history[i]['consciousness_level']
                
                pattern = f"{state1}->{state2}->{state3}"
                patterns[pattern] += 1
            
            return {
                'common_patterns': dict(patterns),
                'most_common': max(patterns.items(), key=lambda x: x[1]) if patterns else None
            }
            
        except Exception:
            return {}
    
    def _calculate_consciousness_complexity(self) -> float:
        """חישוב מורכבות התודעה"""
        try:
            if not self.state_history:
                return 0.0
            
            recent_states = list(self.state_history)[-10:]
            unique_levels = len(set(s['consciousness_level'] for s in recent_states))
            transition_frequency = len([1 for i in range(1, len(recent_states)) 
                                       if recent_states[i]['consciousness_level'] != recent_states[i-1]['consciousness_level']])
            
            complexity = (unique_levels / 6.0) * 0.5 + (transition_frequency / len(recent_states)) * 0.5
            return min(1.0, complexity)
            
        except Exception:
            return 0.0
    
    def _create_wheel_data(self, current_state: ConsciousnessState) -> Dict[str, Any]:
        """יצירת נתוני גלגל התודעה"""
        try:
            return {
                'current_level': current_state.consciousness_level.value,
                'level_intensities': {
                    level.value: 1.0 if level == current_state.consciousness_level else 0.3
                    for level in ConsciousnessLevel
                },
                'transition_probabilities': {}  # יוגדר לפי חיזוי
            }
        except Exception:
            return {}
    
    def _create_meter_data(self, current_state: ConsciousnessState) -> Dict[str, Any]:
        """יצירת נתוני מדדים"""
        try:
            return {
                'energy': {
                    'value': current_state.energy_level.value,
                    'percentage': current_state.energy_level.value * 20,
                    'color': '#27ae60' if current_state.energy_level.value > 2 else '#e74c3c'
                },
                'stability': {
                    'value': current_state.stability_score,
                    'percentage': current_state.stability_score * 100,
                    'color': '#3498db'
                },
                'attention': {
                    'value': current_state.calculate_total_attention(),
                    'percentage': min(100, current_state.calculate_total_attention() * 100),
                    'color': '#f39c12' if current_state.is_overloaded() else '#2ecc71'
                },
                'awareness': {
                    'value': current_state.metrics.awareness_score,
                    'percentage': current_state.metrics.awareness_score * 100,
                    'color': '#9b59b6'
                }
            }
        except Exception:
            return {}
    
    def _create_timeline_data(self) -> List[Dict[str, Any]]:
        """יצירת נתוני טיימליין"""
        try:
            timeline_points = []
            
            for i, state in enumerate(list(self.state_history)[-20:]):
                point = {
                    'index': i,
                    'timestamp': state['timestamp'],
                    'consciousness_level': state['consciousness_level'],
                    'stability': state['stability_score'],
                    'x': (i / 20) * 100,  # מיקום אחוזי
                    'y': 50 + (state['consciousness_level'] - 2.5) * 10  # מיקום Y לפי רמה
                }
                timeline_points.append(point)
            
            return timeline_points
            
        except Exception:
            return []
    
    def _create_attention_map_data(self, current_state: ConsciousnessState) -> Dict[str, Any]:
        """יצירת נתוני מפת קשב"""
        try:
            attention_data = {
                'primary_focus': None,
                'secondary_focuses': []
            }
            
            if current_state.primary_focus:
                attention_data['primary_focus'] = {
                    'target': current_state.primary_focus.target,
                    'intensity': current_state.primary_focus.intensity,
                    'x': 50,  # מרכז
                    'y': 50,
                    'size': 40 + (current_state.primary_focus.intensity * 20)
                }
            
            for i, focus in enumerate(current_state.secondary_focuses):
                angle = (i * 60) * (3.14159 / 180)  # מיקום בעיגול
                x = 50 + 30 * math.cos(angle)
                y = 50 + 30 * math.sin(angle)
                
                attention_data['secondary_focuses'].append({
                    'target': focus.target,
                    'intensity': focus.intensity,
                    'x': x,
                    'y': y,
                    'size': 20 + (focus.intensity * 15)
                })
            
            return attention_data
            
        except Exception:
            return {}
    
    def _generate_health_recommendations(self, health_score: float, 
                                        factors: List[Tuple[str, float]]) -> List[str]:
        """יצירת המלצות לשיפור בריאות המערכת"""
        try:
            recommendations = []
            
            if health_score < 0.6:
                recommendations.append("מומלץ לבצע איפוס מערכת")
            
            for factor_name, factor_score in factors:
                if factor_score < 0.4:
                    if factor_name == 'אנרגיה':
                        recommendations.append("מומלץ להפחית עומס ולאפשר מנוחה")
                    elif factor_name == 'יציבות':
                        recommendations.append("מומלץ לייצב מעברי מצבים")
                    elif factor_name == 'קשב':
                        recommendations.append("מומלץ להפחית פוקוסים משניים")
            
            if not recommendations:
                recommendations.append("המערכת פועלת באופן תקין")
            
            return recommendations
            
        except Exception:
            return ["שגיאה ביצירת המלצות"]
    
    def _create_current_state_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML למצב נוכחי"""
        try:
            current_state = monitor_data.get('current_state', {})
            consciousness = current_state.get('consciousness_level', {})
            
            html = f'''
            <div class="consciousness-level-display consciousness-level-{consciousness.get('value', 0)}" 
                 style="color: {consciousness.get('color', '#fff')};">
                {consciousness.get('hebrew', 'לא זמין')}
            </div>
            
            <div class="state-details">
                <div class="state-detail-item">
                    <div class="detail-label">מצב קשב</div>
                    <div class="detail-value">{current_state.get('attention_state', {}).get('hebrew', 'לא זמין')}</div>
                </div>
                
                <div class="state-detail-item">
                    <div class="detail-label">מצב קוגניטיבי</div>
                    <div class="detail-value">{current_state.get('cognitive_mode', {}).get('hebrew', 'לא זמין')}</div>
                </div>
                
                <div class="state-detail-item">
                    <div class="detail-label">מצב רגשי</div>
                    <div class="detail-value">{current_state.get('emotional_state', {}).get('hebrew', 'לא זמין')}</div>
                </div>
                
                <div class="state-detail-item">
                    <div class="detail-label">רמת אנרגיה</div>
                    <div class="detail-value">{current_state.get('energy_level', {}).get('hebrew', 'לא זמין')}</div>
                </div>
                
                <div class="state-detail-item">
                    <div class="detail-label">יציבות</div>
                    <div class="detail-value">{current_state.get('stability_score', 0):.2f}</div>
                </div>
            </div>
            '''
            
            # חיזוי מצב הבא
            predicted = monitor_data.get('predicted_state')
            if predicted:
                html += f'''
                <div class="prediction-panel">
                    <div class="prediction-title">חיזוי מצב הבא:</div>
                    <div class="predicted-state">{predicted}</div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת מצב נוכחי: {str(e)}</p>'
    
    def _create_consciousness_wheel_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML לגלגל התודעה"""
        try:
            return '''
            <h4>גלגל התודעה</h4>
            <div class="wheel-center">מצב נוכחי</div>
            <!-- הסגמנטים יתווספו באמצעות JavaScript -->
            '''
        except Exception:
            return '<p>שגיאה בתצוגת גלגל התודעה</p>'
    
    def _create_state_meters_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML למדדי מצב"""
        try:
            visualization = monitor_data.get('visualization_data', {})
            meters = visualization.get('meter_data', {})
            
            html = '<h4>מדדי מצב</h4>'
            
            for meter_name, meter_info in meters.items():
                hebrew_names = {
                    'energy': 'אנרגיה',
                    'stability': 'יציבות',
                    'attention': 'קשב',
                    'awareness': 'מודעות'
                }
                
                name = hebrew_names.get(meter_name, meter_name)
                percentage = meter_info.get('percentage', 0)
                color = meter_info.get('color', '#3498db')
                
                html += f'''
                <div class="meter-item">
                    <div class="meter-label">
                        <span>{name}</span>
                        <span>{percentage:.0f}%</span>
                    </div>
                    <div class="meter-bar">
                        <div class="meter-fill" 
                             style="width: {percentage}%; background: {color};" 
                             data-value="{percentage}%">
                        </div>
                    </div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת מדדים: {str(e)}</p>'
    
    def _create_timeline_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML לטיימליין"""
        try:
            return '''
            <h4>טיימליין מצבים</h4>
            <div style="position: relative; height: 150px;">
                <!-- נקודות הטיימליין יתווספו באמצעות JavaScript -->
                <p style="text-align: center; margin-top: 60px; opacity: 0.7;">טיימליין מצבי התודעה</p>
            </div>
            '''
        except Exception:
            return '<p>שגיאה בתצוגת טיימליין</p>'
    
    def _create_attention_map_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML למפת קשב"""
        try:
            current_state = monitor_data.get('current_state', {})
            primary_focus = current_state.get('primary_focus')
            secondary_count = current_state.get('secondary_focuses_count', 0)
            
            html = '''
            <h4>מפת קשב</h4>
            <div style="position: relative; height: 150px;">
            '''
            
            if primary_focus:
                html += f'''
                <div class="attention-focus" 
                     style="left: 50%; top: 50%; width: 40px; height: 40px;"
                     data-intensity="{primary_focus.get('intensity', 0.5)}"
                     title="פוקוס ראשי: {primary_focus.get('target', 'לא ידוע')}">
                    🎯
                </div>
                '''
            
            # פוקוסים משניים (מיקום רנדומלי לדוגמה)
            import random
            for i in range(secondary_count):
                x = 20 + random.randint(0, 60)
                y = 20 + random.randint(0, 60)
                size = 15 + random.randint(0, 15)
                
                html += f'''
                <div class="attention-focus" 
                     style="left: {x}%; top: {y}%; width: {size}px; height: {size}px;"
                     data-intensity="0.4"
                     title="פוקוס משני {i+1}">
                    ·
                </div>
                '''
            
            html += '</div>'
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת מפת קשב: {str(e)}</p>'
    
    def _create_patterns_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML לדפוסים"""
        try:
            patterns = monitor_data.get('detected_patterns', [])
            
            html = '<h4>דפוסים שזוהו</h4>'
            
            if not patterns:
                html += '<p style="opacity: 0.7;">לא זוהו דפוסים</p>'
                return html
            
            for pattern in patterns[:5]:  # מקסימום 5 דפוסים
                html += f'''
                <div class="pattern-item">
                    <div class="pattern-name">{pattern.get('name', 'דפוס לא ידוע')}</div>
                    <div class="pattern-details">
                        תדירות: {pattern.get('frequency', 0)} | 
                        אמינות: {pattern.get('reliability', 0):.2f}
                    </div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת דפוסים: {str(e)}</p>'
    
    def _create_alerts_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML להתראות"""
        try:
            alerts = monitor_data.get('active_alerts', [])
            
            html = '<h4>התראות פעילות</h4>'
            
            if not alerts:
                html += '<p style="opacity: 0.7; color: #27ae60;">אין התראות פעילות</p>'
                return html
            
            for alert in alerts:
                severity_class = f"alert-{alert.get('severity', 'low')}"
                html += f'''
                <div class="alert-item {severity_class}">
                    <strong>{alert.get('message', 'התראה לא ידועה')}</strong><br>
                    <small>ערך: {alert.get('value', 0):.2f} | סף: {alert.get('threshold', 0):.2f}</small>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת התראות: {str(e)}</p>'
    
    def _create_statistics_html(self, monitor_data: Dict[str, Any]) -> str:
        """יצירת HTML לסטטיסטיקות"""
        try:
            stats = monitor_data.get('advanced_statistics', {})
            system_health = monitor_data.get('system_health', {})
            
            html = '''
            <h4>סטטיסטיקות מתקדמות</h4>
            <div class="stats-grid">
            '''
            
            # בריאות כללית
            health_score = system_health.get('overall_score', 0)
            health_status = system_health.get('status_hebrew', 'לא ידוע')
            
            html += f'''
            <div class="stat-card">
                <span class="stat-value">{health_score:.2f}</span>
                <span class="stat-label">בריאות כללית</span>
            </div>
            
            <div class="stat-card">
                <span class="stat-value">{health_status}</span>
                <span class="stat-label">סטטוס מערכת</span>
            </div>
            '''
            
            # סטטיסטיקות נוספות
            if 'average_stability' in stats:
                html += f'''
                <div class="stat-card">
                    <span class="stat-value">{stats['average_stability']:.2f}</span>
                    <span class="stat-label">יציבות ממוצעת</span>
                </div>
                '''
            
            if 'average_energy' in stats:
                html += f'''
                <div class="stat-card">
                    <span class="stat-value">{stats['average_energy']:.1f}</span>
                    <span class="stat-label">אנרגיה ממוצעת</span>
                </div>
                '''
            
            html += '</div>'
            
            # המלצות
            recommendations = system_health.get('recommendations', [])
            if recommendations:
                html += '<h5>המלצות:</h5><ul>'
                for rec in recommendations:
                    html += f'<li>{rec}</li>'
                html += '</ul>'
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת סטטיסטיקות: {str(e)}</p>'
    
    def _get_error_html(self, error_message: str) -> str:
        """HTML לתצוגת שגיאה"""
        return f'''
        <div class="state-monitor-container" dir="rtl">
            <div style="text-align: center; padding: 40px;">
                <h3 style="color: #ff6b6b;">שגיאה במוניטור מצבי התודעה</h3>
                <p>{error_message}</p>
                <button onclick="location.reload()" style="padding: 10px 20px; background: #4ecdc4; color: white; border: none; border-radius: 5px;">נסה שוב</button>
            </div>
        </div>
        '''