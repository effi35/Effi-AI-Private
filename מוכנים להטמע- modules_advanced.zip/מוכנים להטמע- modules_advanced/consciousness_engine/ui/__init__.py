#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Consciousness Engine - UI Package
===================================

ממשק משתמש עבור מנוע התודעה המתקדם

רכיבי UI זמינים:
- ConsciousnessPanel: פאנל ראשי לתצוגת מצב התודעה
- EmotionDisplay: תצוגת מצב רגשי עם ויזואליזציה
- MemoryExplorer: דפדפן זיכרונות עם חיפוש מתקדם
- ThoughtStream: תצוגת זרם מחשבות בזמן אמת
- StateMonitor: ניטור מצבי תודעה ומעברים
- InsightsPanel: תובנות וניתוח מתקדם
"""

from .consciousness_panel import ConsciousnessPanel
from .emotion_display import EmotionDisplay
from .memory_explorer import MemoryExplorer
from .thought_stream import ThoughtStreamUI
from .state_monitor import StateMonitor
from .insights_panel import InsightsPanel

__all__ = [
    'ConsciousnessPanel',
    'EmotionDisplay',
    'MemoryExplorer', 
    'ThoughtStreamUI',
    'StateMonitor',
    'InsightsPanel'
]

__version__ = "2.0.0-MONSTER"
__author__ = "Effi-AI Consciousness Team"