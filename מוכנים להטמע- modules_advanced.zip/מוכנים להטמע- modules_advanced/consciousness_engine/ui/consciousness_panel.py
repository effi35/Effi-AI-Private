#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Consciousness Panel - פאנל ראשי למנוע התודעה
==============================================

פאנל ממשק המשתמש הראשי עבור מנוע התודעה.
מציג תצוגה כוללת של כל מרכיבי התודעה ומאפשר שליטה מלאה.

תכונות מרכזיות:
- תצוגת מצב התודעה בזמן אמת
- ניהול כל המנועים המרכיבים
- ממשק עברי מלא עם תמיכה RTL
- ויזואליזציה מתקדמת של נתונים
- שליטה ובקרה על כל הפרמטרים
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

from ..core.consciousness_core import ConsciousnessCore
from ..models.config import ConsciousnessConfiguration


class ConsciousnessPanel:
    """פאנל ראשי למנוע התודעה עם ממשק משתמש מלא"""
    
    def __init__(self, consciousness_core: ConsciousnessCore = None):
        """אתחול פאנל התודעה"""
        self.logger = logging.getLogger(__name__)
        
        # מנוע התודעה
        self.consciousness = consciousness_core
        
        # מצב הפאנל
        self.is_active = False
        self.refresh_interval = 1000  # מילישניות
        self.auto_refresh = True
        
        # נתוני תצוגה
        self.display_data = {
            'consciousness_state': {},
            'emotion_state': {},
            'memory_insights': {},
            'thought_activity': {},
            'performance_metrics': {}
        }
        
        # הגדרות תצוגה
        self.view_settings = {
            'language': 'hebrew',
            'theme': 'dark',
            'show_advanced': True,
            'auto_scroll': True,
            'notifications': True,
            'rtl_support': True
        }
        
        # callbacks לעדכוני UI
        self.update_callbacks: List[Callable] = []
        
        self.logger.info("פאנל התודעה אותחל")
    
    def initialize_panel(self) -> bool:
        """אתחול הפאנל והתחברות למנוע התודעה"""
        try:
            if not self.consciousness:
                self.logger.error("לא נמצא מנוע תודעה לאתחול")
                return False
            
            # הפעלת מנוע התודעה אם לא פועל
            if not self.consciousness.is_running:
                if not self.consciousness.start():
                    self.logger.error("נכשלה הפעלת מנוע התודעה")
                    return False
            
            self.is_active = True
            
            # עדכון ראשוני
            self.refresh_display()
            
            self.logger.info("פאנל התודעה הופעל בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול פאנל: {e}")
            return False
    
    def shutdown_panel(self) -> bool:
        """סגירת הפאנל"""
        try:
            self.is_active = False
            self.auto_refresh = False
            
            self.logger.info("פאנל התודעה נסגר")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בסגירת פאנל: {e}")
            return False
    
    def refresh_display(self) -> Dict[str, Any]:
        """רענון תצוגת הפאנל עם נתונים עדכניים"""
        try:
            if not self.consciousness or not self.consciousness.is_running:
                return {}
            
            # קבלת נתונים מכל המנועים
            self.display_data = {
                'timestamp': datetime.now().isoformat(),
                'consciousness_state': self.consciousness.get_current_consciousness_state(),
                'insights': self.consciousness.get_consciousness_insights(),
                'uptime': self.consciousness.get_uptime(),
                'status': self._get_system_status()
            }
            
            # עדכון callbacks
            self._notify_update_callbacks()
            
            return self.display_data
            
        except Exception as e:
            self.logger.error(f"שגיאה ברענון תצוגה: {e}")
            return {}
    
    def process_user_input(self, input_text: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """עיבוד קלט מהמשתמש"""
        try:
            if not self.consciousness:
                return {'error': 'מנוע התודעה אינו זמין'}
            
            # עיבוד הקלט במנוע התודעה
            result = self.consciousness.process_input(
                input_data=input_text,
                input_type="text",
                context=context or {'source': 'consciousness_panel'}
            )
            
            # עדכון תצוגה לאחר עיבוד
            self.refresh_display()
            
            # יצירת תגובה למשתמש
            response = self._format_response_for_user(result)
            
            return response
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד קלט משתמש: {e}")
            return {'error': f'שגיאה בעיבוד: {str(e)}'}
    
    def get_html_interface(self) -> str:
        """יצירת ממשק HTML עבור הפאנל"""
        try:
            html_template = self._load_html_template()
            
            # החלפת placeholders בנתונים אקטואליים
            html_content = html_template.format(
                consciousness_data=json.dumps(self.display_data, ensure_ascii=False, indent=2),
                view_settings=json.dumps(self.view_settings, ensure_ascii=False),
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            
            return html_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת ממשק HTML: {e}")
            return self._get_error_html(str(e))
    
    def get_javascript_code(self) -> str:
        """קבלת קוד JavaScript עבור הפאנל"""
        try:
            js_template = self._load_js_template()
            
            # הגדרות JavaScript
            js_config = {
                'refreshInterval': self.refresh_interval,
                'autoRefresh': self.auto_refresh,
                'language': self.view_settings['language'],
                'rtlSupport': self.view_settings['rtl_support']
            }
            
            js_code = js_template.format(
                config=json.dumps(js_config, ensure_ascii=False)
            )
            
            return js_code
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת קוד JavaScript: {e}")
            return "console.error('שגיאה בטעינת JavaScript');"
    
    def get_css_styles(self) -> str:
        """קבלת סגנונות CSS עבור הפאנל"""
        try:
            css_template = self._load_css_template()
            
            # התאמת צבעים לפי ערכת נושא
            theme_colors = self._get_theme_colors()
            
            css_content = css_template.format(**theme_colors)
            
            return css_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת CSS: {e}")
            return "/* שגיאה בטעינת CSS */"
    
    def toggle_engine(self, engine_name: str) -> Dict[str, Any]:
        """הפעלה/כיבוי של מנוע ספציפי"""
        try:
            if not self.consciousness:
                return {'success': False, 'message': 'מנוע התודעה אינו זמין'}
            
            result = {'success': False, 'message': ''}
            
            if engine_name == 'emotion':
                if hasattr(self.consciousness, 'emotion_engine'):
                    engine = self.consciousness.emotion_engine
                    if engine.is_running:
                        result['success'] = engine.stop()
                        result['message'] = 'מנוע הרגשות נכבה' if result['success'] else 'כשל בכיבוי מנוע הרגשות'
                    else:
                        result['success'] = engine.start()
                        result['message'] = 'מנוע הרגשות הופעל' if result['success'] else 'כשל בהפעלת מנוע הרגשות'
                        
            elif engine_name == 'memory':
                if hasattr(self.consciousness, 'memory_engine'):
                    engine = self.consciousness.memory_engine
                    if engine.is_running:
                        result['success'] = engine.stop()
                        result['message'] = 'מנוע הזיכרון נכבה' if result['success'] else 'כשל בכיבוי מנוע הזיכרון'
                    else:
                        result['success'] = engine.start()
                        result['message'] = 'מנוע הזיכרון הופעל' if result['success'] else 'כשל בהפעלת מנוע הזיכרון'
                        
            elif engine_name == 'thought':
                if hasattr(self.consciousness, 'thought_engine'):
                    engine = self.consciousness.thought_engine
                    if engine.is_running:
                        result['success'] = engine.stop()
                        result['message'] = 'מנוע המחשבות נכבה' if result['success'] else 'כשל בכיבוי מנוע המחשבות'
                    else:
                        result['success'] = engine.start()
                        result['message'] = 'מנוע המחשבות הופעל' if result['success'] else 'כשל בהפעלת מנוע המחשבות'
                        
            elif engine_name == 'state':
                if hasattr(self.consciousness, 'state_engine'):
                    engine = self.consciousness.state_engine
                    if engine.is_running:
                        result['success'] = engine.stop()
                        result['message'] = 'מנוע מצבי התודעה נכבה' if result['success'] else 'כשל בכיבוי מנוע מצבי התודעה'
                    else:
                        result['success'] = engine.start()
                        result['message'] = 'מנוע מצבי התודעה הופעל' if result['success'] else 'כשל בהפעלת מנוע מצבי התודעה'
            else:
                result['message'] = f'מנוע לא ידוע: {engine_name}'
            
            # רענון תצוגה לאחר שינוי
            if result['success']:
                self.refresh_display()
            
            return result
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת/כיבוי מנוע {engine_name}: {e}")
            return {'success': False, 'message': f'שגיאה: {str(e)}'}
    
    def update_settings(self, new_settings: Dict[str, Any]) -> bool:
        """עדכון הגדרות הפאנל"""
        try:
            # עדכון הגדרות תצוגה
            for key, value in new_settings.items():
                if key in self.view_settings:
                    self.view_settings[key] = value
            
            # עדכון מרווח רענון
            if 'refresh_interval' in new_settings:
                self.refresh_interval = new_settings['refresh_interval']
            
            if 'auto_refresh' in new_settings:
                self.auto_refresh = new_settings['auto_refresh']
            
            self.logger.info("הגדרות הפאנל עודכנו")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון הגדרות: {e}")
            return False
    
    def export_consciousness_data(self, format_type: str = "json") -> str:
        """ייצוא נתוני התודעה"""
        try:
            if not self.consciousness:
                return ""
            
            insights = self.consciousness.get_consciousness_insights()
            
            if format_type == "json":
                return json.dumps(insights, ensure_ascii=False, indent=2)
            elif format_type == "summary":
                return self._create_text_summary(insights)
            else:
                return json.dumps(insights, ensure_ascii=False)
                
        except Exception as e:
            self.logger.error(f"שגיאה בייצוא נתונים: {e}")
            return f"שגיאה בייצוא: {str(e)}"
    
    def add_update_callback(self, callback: Callable):
        """הוספת callback לעדכוני תצוגה"""
        self.update_callbacks.append(callback)
    
    def remove_update_callback(self, callback: Callable):
        """הסרת callback"""
        if callback in self.update_callbacks:
            self.update_callbacks.remove(callback)
    
    def _get_system_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מערכת מפורט"""
        try:
            status = {
                'overall_status': 'healthy',
                'engines_status': {},
                'warnings': [],
                'errors': []
            }
            
            if not self.consciousness:
                status['overall_status'] = 'error'
                status['errors'].append('מנוע התודעה אינו זמין')
                return status
            
            # בדיקת סטטוס כל מנוע
            engines = ['emotion_engine', 'memory_engine', 'thought_engine', 'state_engine']
            
            for engine_name in engines:
                if hasattr(self.consciousness, engine_name):
                    engine = getattr(self.consciousness, engine_name)
                    if hasattr(engine, 'get_engine_status'):
                        engine_status = engine.get_engine_status()
                        status['engines_status'][engine_name] = engine_status
                        
                        # בדיקת בעיות
                        if not engine_status.get('is_running', False):
                            status['warnings'].append(f'מנוע {engine_name} אינו פועל')
                    else:
                        status['warnings'].append(f'לא ניתן לקבל סטטוס מ-{engine_name}')
            
            # קביעת סטטוס כללי
            if status['errors']:
                status['overall_status'] = 'error'
            elif status['warnings']:
                status['overall_status'] = 'warning'
            
            return status
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת סטטוס מערכת: {e}")
            return {'overall_status': 'error', 'errors': [str(e)]}
    
    def _format_response_for_user(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """עיצוב תגובה למשתמש"""
        try:
            response = {
                'success': 'error' not in result,
                'timestamp': datetime.now().isoformat(),
                'response_text': '',
                'technical_details': result
            }
            
            if 'error' in result:
                response['response_text'] = f"אירעה שגיאה: {result['error']}"
            else:
                # יצירת תגובה ידידותית
                integrated_response = result.get('integrated_response', {})
                confidence = integrated_response.get('confidence', 0.0)
                
                if confidence > 0.7:
                    response['response_text'] = "הבנתי אותך היטב והעבדתי את מה שאמרת."
                elif confidence > 0.4:
                    response['response_text'] = "הבנתי חלק ממה שאמרת, אבל אשמח להבהרה נוספת."
                else:
                    response['response_text'] = "לא הבנתי את הכוונה במלואה. תוכל לנסח מחדש?"
                
                # הוספת המלצות אם יש
                recommendations = integrated_response.get('recommendations', [])
                if recommendations:
                    response['response_text'] += f"\n\nהמלצות: {', '.join(recommendations)}"
            
            return response
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב תגובה: {e}")
            return {
                'success': False,
                'response_text': f'שגיאה בעיצוב תגובה: {str(e)}',
                'technical_details': result
            }
    
    def _notify_update_callbacks(self):
        """הפעלת כל ה-callbacks לעדכון"""
        try:
            for callback in self.update_callbacks:
                try:
                    callback(self.display_data)
                except Exception as e:
                    self.logger.error(f"שגיאה ב-callback: {e}")
                    
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת callbacks: {e}")
    
    def _load_html_template(self) -> str:
        """טעינת תבנית HTML"""
        try:
            template_path = Path(__file__).parent / "templates" / "consciousness_panel.html"
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                return self._get_default_html_template()
                
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת תבנית HTML: {e}")
            return self._get_default_html_template()
    
    def _load_js_template(self) -> str:
        """טעינת תבנית JavaScript"""
        try:
            template_path = Path(__file__).parent / "templates" / "consciousness_panel.js"
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                return self._get_default_js_template()
                
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת תבנית JS: {e}")
            return self._get_default_js_template()
    
    def _load_css_template(self) -> str:
        """טעינת תבנית CSS"""
        try:
            template_path = Path(__file__).parent / "templates" / "consciousness_panel.css"
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                return self._get_default_css_template()
                
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת תבנית CSS: {e}")
            return self._get_default_css_template()
    
    def _get_theme_colors(self) -> Dict[str, str]:
        """קבלת צבעי ערכת נושא"""
        if self.view_settings['theme'] == 'dark':
            return {
                'bg_primary': '#1a1a1a',
                'bg_secondary': '#2d2d2d',
                'text_primary': '#ffffff',
                'text_secondary': '#cccccc',
                'accent_color': '#0d7377',
                'success_color': '#4caf50',
                'warning_color': '#ff9800',
                'error_color': '#f44336'
            }
        else:  # light theme
            return {
                'bg_primary': '#ffffff',
                'bg_secondary': '#f5f5f5',
                'text_primary': '#333333',
                'text_secondary': '#666666',
                'accent_color': '#2196f3',
                'success_color': '#4caf50',
                'warning_color': '#ff9800',
                'error_color': '#f44336'
            }
    
    def _create_text_summary(self, insights: Dict[str, Any]) -> str:
        """יצירת סיכום טקסטואלי"""
        try:
            summary = "=== סיכום מצב התודעה ===\n\n"
            
            # מידע כללי
            summary += f"זמן: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            if 'uptime' in insights:
                summary += f"זמן פעילות: {insights['uptime']:.2f} שניות\n\n"
            
            # סטטוס מנועים
            if 'consciousness_insights' in insights:
                consciousness_data = insights['consciousness_insights']
                summary += "=== מצב מנועי התודעה ===\n"
                
                for key, value in consciousness_data.items():
                    if isinstance(value, dict) and 'is_running' in value:
                        status = "פועל" if value['is_running'] else "כבוי"
                        summary += f"{key}: {status}\n"
            
            summary += "\n=== תובנות נוספות ===\n"
            if 'emotional_insights' in insights:
                summary += "רגשות: מערכת פעילה\n"
            if 'memory_insights' in insights:
                summary += "זיכרון: מערכת פעילה\n"
            if 'thought_insights' in insights:
                summary += "מחשבות: מערכת פעילה\n"
            
            return summary
            
        except Exception as e:
            return f"שגיאה ביצירת סיכום: {str(e)}"
    
    def _get_default_html_template(self) -> str:
        """תבנית HTML ברירת מחדל"""
        return '''
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>פאנל מנוע התודעה - Effi AI</title>
    <style>{css_content}</style>
</head>
<body>
    <div class="consciousness-panel">
        <header class="panel-header">
            <h1>🧠 מנוע התודעה המתקדם</h1>
            <div class="status-indicator" id="status"></div>
        </header>
        
        <main class="panel-content">
            <div class="data-display" id="consciousnessData">
                <pre>{consciousness_data}</pre>
            </div>
            
            <div class="controls">
                <input type="text" id="userInput" placeholder="הכנס טקסט לעיבוד...">
                <button onclick="processInput()">עבד</button>
                <button onclick="refreshData()">רענן</button>
            </div>
        </main>
    </div>
    
    <script>{js_content}</script>
</body>
</html>
        '''
    
    def _get_default_js_template(self) -> str:
        """תבנית JavaScript ברירת מחדל"""
        return '''
// הגדרות פאנל התודעה
const panelConfig = {config};

// פונקציות ראשיות
function refreshData() {{
    console.log('מרענן נתוני תודעה...');
    // כאן יהיה קוד לרענון נתונים
}}

function processInput() {{
    const input = document.getElementById('userInput').value;
    if (input.trim()) {{
        console.log('מעבד קלט:', input);
        // כאן יהיה קוד לעיבוד קלט
        document.getElementById('userInput').value = '';
    }}
}}

// רענון אוטומטי
if (panelConfig.autoRefresh) {{
    setInterval(refreshData, panelConfig.refreshInterval);
}}

// אתחול
document.addEventListener('DOMContentLoaded', function() {{
    refreshData();
}});
        '''
    
    def _get_default_css_template(self) -> str:
        """תבנית CSS ברירת מחדל"""
        return '''
body {{
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: {bg_primary};
    color: {text_primary};
    direction: rtl;
}}

.consciousness-panel {{
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}}

.panel-header {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding: 20px;
    background-color: {bg_secondary};
    border-radius: 10px;
}}

.panel-header h1 {{
    margin: 0;
    color: {accent_color};
}}

.status-indicator {{
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background-color: {success_color};
}}

.panel-content {{
    display: grid;
    gap: 20px;
}}

.data-display {{
    background-color: {bg_secondary};
    padding: 20px;
    border-radius: 10px;
    max-height: 400px;
    overflow-y: auto;
}}

.data-display pre {{
    margin: 0;
    font-size: 14px;
    line-height: 1.4;
}}

.controls {{
    display: flex;
    gap: 10px;
    padding: 20px;
    background-color: {bg_secondary};
    border-radius: 10px;
}}

.controls input {{
    flex: 1;
    padding: 10px;
    border: 1px solid {text_secondary};
    border-radius: 5px;
    background-color: {bg_primary};
    color: {text_primary};
}}

.controls button {{
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: {accent_color};
    color: white;
    cursor: pointer;
}}

.controls button:hover {{
    opacity: 0.8;
}}
        '''
    
    def _get_error_html(self, error_message: str) -> str:
        """HTML עבור תצוגת שגיאה"""
        return f'''
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <title>שגיאה - פאנל התודעה</title>
</head>
<body style="font-family: Arial; padding: 20px; background: #f5f5f5;">
    <div style="background: white; padding: 20px; border-radius: 10px; text-align: center;">
        <h2 style="color: #d32f2f;">שגיאה בפאנל התודעה</h2>
        <p>{error_message}</p>
        <button onclick="location.reload()" style="padding: 10px 20px; background: #1976d2; color: white; border: none; border-radius: 5px;">נסה שוב</button>
    </div>
</body>
</html>
        '''