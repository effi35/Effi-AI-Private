#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Memory Explorer - דפדפן זיכרונות מתקדם
==========================================

רכיב UI מתקדם לחקירה ותצוגת מערכת הזיכרון.
מאפשר חיפוש, סינון ותצוגה של כל 5 שכבות הזיכרון.

תכונות מרכזיות:
- דפדוף בין 5 שכבות הזיכרון
- חיפוש מתקדם עם תמיכה בעברית
- ויזואליזציה של קשרים בין זיכרונות
- תצוגת היסטוריית גישה
- ממשק עברי מלא עם RTL
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set
from collections import defaultdict

from ..core.memory_engine import MemoryEngine
from ..models.memory import MemoryType, MemoryImportance, MemoryState


class MemoryExplorer:
    """דפדפן זיכרונות מתקדם עם חיפוש וסינון"""
    
    def __init__(self, memory_engine: MemoryEngine = None):
        """אתחול דפדפן הזיכרונות"""
        self.logger = logging.getLogger(__name__)
        
        # מנוע הזיכרון
        self.memory_engine = memory_engine
        
        # הגדרות תצוגה
        self.display_settings = {
            'items_per_page': 20,
            'show_associations': True,
            'show_metadata': True,
            'show_hebrew_content': True,
            'auto_refresh': True,
            'refresh_interval': 5000,  # מילישניות
            'highlight_search': True
        }
        
        # מצב הדפדפן
        self.current_layer = MemoryType.WORKING
        self.current_page = 1
        self.search_query = ""
        self.filter_criteria = {}
        self.sort_by = "last_accessed"
        self.sort_order = "desc"
        
        # נתוני תצוגה נוכחיים
        self.current_memories = []
        self.total_memories = 0
        self.selected_memory = None
        
        # סטטיסטיקות
        self.explorer_stats = {
            'total_searches': 0,
            'memories_viewed': 0,
            'associations_explored': 0,
            'layers_browsed': set(),
            'last_activity': datetime.now()
        }
        
        # תרגומים עבריים
        self.layer_translations = {
            MemoryType.WORKING: 'זיכרון עבודה',
            MemoryType.SHORT_TERM: 'זיכרון קצר טווח',
            MemoryType.EPISODIC: 'זיכרון אפיזודי',
            MemoryType.SEMANTIC: 'זיכרון סמנטי',
            MemoryType.PROCEDURAL: 'זיכרון פרוצדורלי'
        }
        
        self.importance_translations = {
            MemoryImportance.MINIMAL: 'מינימלי',
            MemoryImportance.LOW: 'נמוך',
            MemoryImportance.MEDIUM: 'בינוני',
            MemoryImportance.HIGH: 'גבוה',
            MemoryImportance.CRITICAL: 'קריטי'
        }
        
        self.state_translations = {
            MemoryState.ACTIVE: 'פעיל',
            MemoryState.CONSOLIDATING: 'מתאחד',
            MemoryState.CONSOLIDATED: 'מאוחד',
            MemoryState.DECAYING: 'נפגם',
            MemoryState.ARCHIVED: 'מאורכב'
        }
        
        self.logger.info("דפדפן זיכרונות אותחל")
    
    def browse_layer(self, layer_type: MemoryType, page: int = 1) -> Dict[str, Any]:
        """דפדוף בשכבת זיכרון ספציפית"""
        try:
            if not self.memory_engine:
                return {'error': 'מנוע זיכרון אינו זמין'}
            
            # עדכון מצב נוכחי
            self.current_layer = layer_type
            self.current_page = page
            self.explorer_stats['layers_browsed'].add(layer_type.value)
            
            # קבלת שכבת הזיכרון
            layer = self.memory_engine.memory_system.get_layer(layer_type)
            
            # קבלת זיכרונות מהשכבה
            all_memories = list(layer.items.values())
            self.total_memories = len(all_memories)
            
            # מיון
            sorted_memories = self._sort_memories(all_memories)
            
            # חלוקה לדפים
            start_idx = (page - 1) * self.display_settings['items_per_page']
            end_idx = start_idx + self.display_settings['items_per_page']
            page_memories = sorted_memories[start_idx:end_idx]
            
            # עיצוב לתצוגה
            self.current_memories = [self._format_memory_for_display(memory) for memory in page_memories]
            
            # סטטיסטיקות שכבה
            layer_stats = self._calculate_layer_statistics(all_memories)
            
            return {
                'layer_type': layer_type.value,
                'layer_name': self.layer_translations[layer_type],
                'current_page': page,
                'total_pages': (self.total_memories + self.display_settings['items_per_page'] - 1) // self.display_settings['items_per_page'],
                'total_memories': self.total_memories,
                'memories': self.current_memories,
                'layer_statistics': layer_stats,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בדפדוף שכבת זיכרון: {e}")
            return {'error': str(e)}
    
    def search_memories(self, query: str, layer_types: List[MemoryType] = None, 
                       filters: Dict[str, Any] = None) -> Dict[str, Any]:
        """חיפוש זיכרונות עם סינון מתקדם"""
        try:
            if not self.memory_engine:
                return {'error': 'מנוע זיכרון אינו זמין'}
            
            # עדכון מצב חיפוש
            self.search_query = query
            self.filter_criteria = filters or {}
            self.explorer_stats['total_searches'] += 1
            
            # חיפוש במנוע הזיכרון
            search_results = self.memory_engine.search_memories(
                query=query,
                memory_types=layer_types,
                limit=100  # חיפוש רחב יותר
            )
            
            # החלת סינונים נוספים
            filtered_results = self._apply_filters(search_results, filters or {})
            
            # מיון תוצאות
            sorted_results = self._sort_memories(filtered_results)
            
            # עיצוב לתצוגה
            formatted_results = [self._format_memory_for_display(memory) for memory in sorted_results]
            
            # סטטיסטיקות חיפוש
            search_stats = self._calculate_search_statistics(formatted_results, query)
            
            return {
                'query': query,
                'total_results': len(formatted_results),
                'results': formatted_results[:50],  # הגבלה לתצוגה
                'search_statistics': search_stats,
                'filters_applied': filters or {},
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש זיכרונות: {e}")
            return {'error': str(e)}
    
    def get_memory_details(self, memory_id: str) -> Dict[str, Any]:
        """קבלת פרטים מלאים על זיכרון"""
        try:
            if not self.memory_engine:
                return {'error': 'מנוע זיכרון אינו זמין'}
            
            # קבלת הזיכרון
            memory = self.memory_engine.retrieve_memory(memory_id)
            if not memory:
                return {'error': 'זיכרון לא נמצא'}
            
            self.selected_memory = memory
            self.explorer_stats['memories_viewed'] += 1
            
            # עיצוב פרטי הזיכרון
            memory_details = self._format_memory_details(memory)
            
            # קבלת זיכרונות קשורים
            related_memories = self.memory_engine.get_related_memories(memory_id, max_results=10)
            formatted_related = [self._format_memory_for_display(mem) for mem in related_memories]
            
            # ניתוח קשרים
            associations_analysis = self._analyze_memory_associations(memory)
            
            return {
                'memory_details': memory_details,
                'related_memories': formatted_related,
                'associations_analysis': associations_analysis,
                'access_history': self._get_memory_access_history(memory),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת פרטי זיכרון: {e}")
            return {'error': str(e)}
    
    def get_memory_visualization_data(self) -> Dict[str, Any]:
        """קבלת נתונים לויזואליזציה של הזיכרון"""
        try:
            if not self.memory_engine:
                return {'error': 'מנוע זיכרון אינו זמין'}
            
            # סטטיסטיקות כלליות
            memory_insights = self.memory_engine.get_memory_insights()
            
            # נתוני ויזואליזציה לכל שכבה
            layer_visualization = {}
            for layer_type in MemoryType:
                layer = self.memory_engine.memory_system.get_layer(layer_type)
                layer_viz = self._create_layer_visualization_data(layer, layer_type)
                layer_visualization[layer_type.value] = layer_viz
            
            # מפת קשרים
            connections_map = self._create_connections_map()
            
            # התפלגות זמנית
            temporal_distribution = self._create_temporal_distribution()
            
            return {
                'layer_visualization': layer_visualization,
                'connections_map': connections_map,
                'temporal_distribution': temporal_distribution,
                'memory_insights': memory_insights,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת נתוני ויזואליזציה: {e}")
            return {'error': str(e)}
    
    def get_explorer_html(self) -> str:
        """יצירת HTML עבור דפדפן הזיכרונות"""
        try:
            current_data = self.browse_layer(self.current_layer, self.current_page)
            
            html_content = f'''
            <div class="memory-explorer-container" dir="rtl">
                <div class="explorer-header">
                    <h2>🗃️ דפדפן זיכרונות</h2>
                    <div class="layer-selector">
                        {self._create_layer_selector_html()}
                    </div>
                </div>
                
                <div class="explorer-controls">
                    <div class="search-section">
                        <input type="text" id="memorySearch" placeholder="חפש זיכרונות..." value="{self.search_query}">
                        <button onclick="searchMemories()">חפש</button>
                        <button onclick="clearSearch()">נקה</button>
                    </div>
                    
                    <div class="filter-section">
                        {self._create_filters_html()}
                    </div>
                </div>
                
                <div class="explorer-content">
                    <div class="memories-list">
                        {self._create_memories_list_html(current_data)}
                    </div>
                    
                    <div class="memory-details" id="memoryDetails">
                        <p>בחר זיכרון לצפייה בפרטים</p>
                    </div>
                </div>
                
                <div class="explorer-footer">
                    {self._create_pagination_html(current_data)}
                </div>
            </div>
            '''
            
            return html_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת HTML דפדפן: {e}")
            return f'<div class="error">שגיאה ביצירת דפדפן: {str(e)}</div>'
    
    def get_explorer_css(self) -> str:
        """קבלת CSS עבור דפדפן הזיכרונות"""
        return '''
        .memory-explorer-container {
            background: linear-gradient(135deg, #74b9ff 0%, #0984e3 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            min-height: 600px;
        }
        
        .explorer-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            padding-bottom: 15px;
        }
        
        .explorer-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        
        .layer-selector {
            display: flex;
            gap: 10px;
        }
        
        .layer-tab {
            padding: 8px 16px;
            background: rgba(255,255,255,0.2);
            border: none;
            border-radius: 20px;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 12px;
        }
        
        .layer-tab:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .layer-tab.active {
            background: rgba(255,255,255,0.4);
            font-weight: bold;
        }
        
        .explorer-controls {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .search-section {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .search-section input {
            flex: 1;
            padding: 10px;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 5px;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 14px;
        }
        
        .search-section input::placeholder {
            color: rgba(255,255,255,0.7);
        }
        
        .search-section button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background: rgba(255,255,255,0.2);
            color: white;
            cursor: pointer;
            font-size: 12px;
        }
        
        .search-section button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .filter-section {
            display: flex;
            gap: 10px;
            align-items: center;
            justify-content: flex-end;
        }
        
        .filter-dropdown {
            padding: 8px;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 5px;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 12px;
        }
        
        .explorer-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            min-height: 400px;
        }
        
        .memories-list {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            overflow-y: auto;
            max-height: 400px;
        }
        
        .memory-item {
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border-right: 4px solid transparent;
        }
        
        .memory-item:hover {
            background: rgba(255,255,255,0.2);
            transform: translateX(-5px);
        }
        
        .memory-item.selected {
            background: rgba(255,255,255,0.3);
            border-right-color: #fff;
        }
        
        .memory-title {
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .memory-content {
            font-size: 12px;
            opacity: 0.8;
            margin-bottom: 8px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .memory-meta {
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            opacity: 0.6;
        }
        
        .memory-details {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            overflow-y: auto;
            max-height: 400px;
        }
        
        .detail-section {
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .detail-section:last-child {
            border-bottom: none;
        }
        
        .detail-title {
            font-weight: bold;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .association-item {
            background: rgba(255,255,255,0.1);
            border-radius: 5px;
            padding: 8px;
            margin-bottom: 5px;
            font-size: 12px;
        }
        
        .explorer-footer {
            margin-top: 25px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        
        .pagination-button {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            background: rgba(255,255,255,0.2);
            color: white;
            cursor: pointer;
            font-size: 12px;
        }
        
        .pagination-button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .pagination-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .page-info {
            font-size: 14px;
            margin: 0 15px;
        }
        
        .importance-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .importance-critical { background: #e74c3c; }
        .importance-high { background: #f39c12; }
        .importance-medium { background: #3498db; }
        .importance-low { background: #95a5a6; }
        .importance-minimal { background: #7f8c8d; }
        
        .state-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            margin-left: 5px;
        }
        
        .state-active { background: #27ae60; }
        .state-consolidating { background: #f1c40f; color: #333; }
        .state-consolidated { background: #2ecc71; }
        .state-decaying { background: #e67e22; }
        .state-archived { background: #95a5a6; }
        '''
    
    def get_explorer_javascript(self) -> str:
        """קבלת JavaScript עבור דפדפן הזיכרונות"""
        return f'''
        // הגדרות דפדפן זיכרונות
        const explorerConfig = {json.dumps(self.display_settings, ensure_ascii=False)};
        let currentLayer = "{self.current_layer.value}";
        let currentPage = {self.current_page};
        let selectedMemoryId = null;
        
        class MemoryExplorer {{
            constructor() {{
                this.initialize();
            }}
            
            initialize() {{
                this.setupEventListeners();
                this.startAutoRefresh();
            }}
            
            setupEventListeners() {{
                // חיפוש
                document.getElementById('memorySearch').addEventListener('keypress', (e) => {{
                    if (e.key === 'Enter') {{
                        this.searchMemories();
                    }}
                }});
                
                // בחירת זיכרון
                document.addEventListener('click', (e) => {{
                    if (e.target.classList.contains('memory-item')) {{
                        this.selectMemory(e.target);
                    }}
                }});
                
                // בחירת שכבה
                document.addEventListener('click', (e) => {{
                    if (e.target.classList.contains('layer-tab')) {{
                        this.switchLayer(e.target.dataset.layer);
                    }}
                }});
            }}
            
            searchMemories() {{
                const query = document.getElementById('memorySearch').value;
                console.log('מחפש:', query);
                // כאן יהיה קוד לחיפוש
            }}
            
            clearSearch() {{
                document.getElementById('memorySearch').value = '';
                this.searchMemories();
            }}
            
            selectMemory(memoryElement) {{
                // הסרת בחירה קודמת
                document.querySelectorAll('.memory-item').forEach(item => {{
                    item.classList.remove('selected');
                }});
                
                // בחירת זיכרון חדש
                memoryElement.classList.add('selected');
                selectedMemoryId = memoryElement.dataset.memoryId;
                
                this.loadMemoryDetails(selectedMemoryId);
            }}
            
            loadMemoryDetails(memoryId) {{
                console.log('טוען פרטי זיכרון:', memoryId);
                // כאן יהיה קוד לטעינת פרטי זיכרון
            }}
            
            switchLayer(layerType) {{
                currentLayer = layerType;
                currentPage = 1;
                
                // עדכון תצוגת טאבים
                document.querySelectorAll('.layer-tab').forEach(tab => {{
                    tab.classList.remove('active');
                }});
                document.querySelector(`[data-layer="${{layerType}}"]`).classList.add('active');
                
                this.refreshContent();
            }}
            
            changePage(direction) {{
                if (direction === 'next') {{
                    currentPage++;
                }} else if (direction === 'prev' && currentPage > 1) {{
                    currentPage--;
                }}
                
                this.refreshContent();
            }}
            
            refreshContent() {{
                console.log('מרענן תוכן עבור שכבה:', currentLayer, 'דף:', currentPage);
                // כאן יהיה קוד לרענון תוכן
            }}
            
            startAutoRefresh() {{
                if (explorerConfig.auto_refresh) {{
                    setInterval(() => {{
                        this.refreshContent();
                    }}, explorerConfig.refresh_interval);
                }}
            }}
        }}
        
        // פונקציות גלובליות
        function searchMemories() {{
            window.memoryExplorer.searchMemories();
        }}
        
        function clearSearch() {{
            window.memoryExplorer.clearSearch();
        }}
        
        function changePage(direction) {{
            window.memoryExplorer.changePage(direction);
        }}
        
        function switchLayer(layerType) {{
            window.memoryExplorer.switchLayer(layerType);
        }}
        
        // אתחול
        document.addEventListener('DOMContentLoaded', function() {{
            window.memoryExplorer = new MemoryExplorer();
        }});
        '''
    
    def _sort_memories(self, memories: List) -> List:
        """מיון זיכרונות לפי קריטריון"""
        try:
            if self.sort_by == "last_accessed":
                sorted_memories = sorted(memories, key=lambda x: x.last_accessed, reverse=(self.sort_order == "desc"))
            elif self.sort_by == "created_at":
                sorted_memories = sorted(memories, key=lambda x: x.created_at, reverse=(self.sort_order == "desc"))
            elif self.sort_by == "importance":
                sorted_memories = sorted(memories, key=lambda x: x.importance.value, reverse=(self.sort_order == "desc"))
            elif self.sort_by == "strength":
                sorted_memories = sorted(memories, key=lambda x: x.strength, reverse=(self.sort_order == "desc"))
            else:
                sorted_memories = memories
            
            return sorted_memories
            
        except Exception as e:
            self.logger.error(f"שגיאה במיון זיכרונות: {e}")
            return memories
    
    def _format_memory_for_display(self, memory) -> Dict[str, Any]:
        """עיצוב זיכרון לתצוגה"""
        try:
            # קיצור תוכן לתצוגה
            content_preview = str(memory.content.data)[:100]
            if len(str(memory.content.data)) > 100:
                content_preview += "..."
            
            return {
                'id': memory.id,
                'content_preview': content_preview,
                'content_type': memory.content.content_type,
                'memory_type': memory.memory_type.value,
                'memory_type_hebrew': self.layer_translations[memory.memory_type],
                'importance': memory.importance.value,
                'importance_hebrew': self.importance_translations[memory.importance],
                'state': memory.state.value,
                'state_hebrew': self.state_translations[memory.state],
                'strength': round(memory.strength, 2),
                'consolidation_score': round(memory.consolidation_score, 2),
                'created_at': memory.created_at.strftime("%Y-%m-%d %H:%M"),
                'last_accessed': memory.last_accessed.strftime("%Y-%m-%d %H:%M"),
                'access_count': memory.access_count,
                'emotional_valence': round(memory.emotional_valence, 2),
                'emotional_intensity': round(memory.emotional_intensity, 2),
                'associations_count': len(memory.associations),
                'tags': list(memory.tags)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב זיכרון: {e}")
            return {'id': memory.id, 'error': str(e)}
    
    def _format_memory_details(self, memory) -> Dict[str, Any]:
        """עיצוב פרטי זיכרון מלאים"""
        try:
            details = self._format_memory_for_display(memory)
            
            # הוספת פרטים נוספים
            details.update({
                'full_content': str(memory.content.data),
                'content_metadata': memory.content.metadata,
                'content_encoding': memory.content.encoding,
                'context': memory.context,
                'age_seconds': (datetime.now() - memory.created_at).total_seconds(),
                'time_since_access': (datetime.now() - memory.last_accessed).total_seconds(),
                'associations_detailed': [
                    {
                        'target_id': assoc.target_id,
                        'type': assoc.association_type,
                        'strength': round(assoc.strength, 2),
                        'created_at': assoc.created_at.strftime("%Y-%m-%d %H:%M"),
                        'last_accessed': assoc.last_accessed.strftime("%Y-%m-%d %H:%M")
                    }
                    for assoc in memory.associations
                ]
            })
            
            return details
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב פרטי זיכרון: {e}")
            return {'error': str(e)}
    
    def _apply_filters(self, memories: List, filters: Dict[str, Any]) -> List:
        """החלת סינונים על רשימת זיכרונות"""
        try:
            filtered = memories
            
            # סינון לפי חשיבות
            if 'importance' in filters:
                importance_filter = filters['importance']
                filtered = [m for m in filtered if m.importance.value >= importance_filter]
            
            # סינון לפי מצב
            if 'state' in filters:
                state_filter = filters['state']
                filtered = [m for m in filtered if m.state.value == state_filter]
            
            # סינון לפי עוצמה
            if 'min_strength' in filters:
                min_strength = filters['min_strength']
                filtered = [m for m in filtered if m.strength >= min_strength]
            
            # סינון לפי תוכן עברי
            if 'hebrew_only' in filters and filters['hebrew_only']:
                filtered = [m for m in filtered if self._is_hebrew_content(m.content.data)]
            
            # סינון לפי טווח זמן
            if 'date_from' in filters:
                date_from = datetime.fromisoformat(filters['date_from'])
                filtered = [m for m in filtered if m.created_at >= date_from]
            
            if 'date_to' in filters:
                date_to = datetime.fromisoformat(filters['date_to'])
                filtered = [m for m in filtered if m.created_at <= date_to]
            
            return filtered
            
        except Exception as e:
            self.logger.error(f"שגיאה בהחלת סינונים: {e}")
            return memories
    
    def _calculate_layer_statistics(self, memories: List) -> Dict[str, Any]:
        """חישוב סטטיסטיקות שכבה"""
        try:
            if not memories:
                return {}
            
            stats = {
                'total_memories': len(memories),
                'avg_strength': sum(m.strength for m in memories) / len(memories),
                'avg_consolidation': sum(m.consolidation_score for m in memories) / len(memories),
                'avg_access_count': sum(m.access_count for m in memories) / len(memories),
                'importance_distribution': defaultdict(int),
                'state_distribution': defaultdict(int),
                'content_types': defaultdict(int),
                'hebrew_content_ratio': 0.0,
                'emotional_memories': 0,
                'highly_connected': 0
            }
            
            hebrew_count = 0
            emotional_count = 0
            highly_connected_count = 0
            
            for memory in memories:
                # התפלגות חשיבות
                stats['importance_distribution'][memory.importance.value] += 1
                
                # התפלגות מצבים
                stats['state_distribution'][memory.state.value] += 1
                
                # סוגי תוכן
                stats['content_types'][memory.content.content_type] += 1
                
                # תוכן עברי
                if self._is_hebrew_content(memory.content.data):
                    hebrew_count += 1
                
                # זיכרונות רגשיים
                if abs(memory.emotional_valence) > 0.1 or memory.emotional_intensity > 0.1:
                    emotional_count += 1
                
                # זיכרונות מחוברים היטב
                if len(memory.associations) > 3:
                    highly_connected_count += 1
            
            stats['hebrew_content_ratio'] = hebrew_count / len(memories)
            stats['emotional_memories'] = emotional_count
            stats['highly_connected'] = highly_connected_count
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב סטטיסטיקות שכבה: {e}")
            return {}
    
    def _calculate_search_statistics(self, results: List, query: str) -> Dict[str, Any]:
        """חישוב סטטיסטיקות חיפוש"""
        try:
            stats = {
                'query': query,
                'total_results': len(results),
                'relevance_scores': [],
                'layer_distribution': defaultdict(int),
                'avg_strength': 0.0,
                'hebrew_matches': 0
            }
            
            if not results:
                return stats
            
            hebrew_matches = 0
            total_strength = 0
            
            for result in results:
                # התפלגות שכבות
                stats['layer_distribution'][result['memory_type']] += 1
                
                # עוצמה ממוצעת
                total_strength += result['strength']
                
                # התאמות עבריות
                if self._is_hebrew_content(result['content_preview']):
                    hebrew_matches += 1
            
            stats['avg_strength'] = total_strength / len(results)
            stats['hebrew_matches'] = hebrew_matches
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב סטטיסטיקות חיפוש: {e}")
            return {}
    
    def _is_hebrew_content(self, content: Any) -> bool:
        """בדיקה אם התוכן מכיל עברית"""
        try:
            if not isinstance(content, str):
                return False
            
            import re
            hebrew_chars = len(re.findall(r'[א-ת]', content))
            total_chars = len(re.findall(r'[א-תa-zA-Z]', content))
            
            return (hebrew_chars / total_chars) > 0.3 if total_chars > 0 else False
            
        except Exception:
            return False
    
    def _analyze_memory_associations(self, memory) -> Dict[str, Any]:
        """ניתוח קשרי זיכרון"""
        try:
            if not memory.associations:
                return {'total_associations': 0}
            
            analysis = {
                'total_associations': len(memory.associations),
                'association_types': defaultdict(int),
                'strength_distribution': {
                    'strong': 0,    # > 0.7
                    'medium': 0,    # 0.3-0.7
                    'weak': 0       # < 0.3
                },
                'avg_strength': 0.0,
                'bidirectional_count': 0
            }
            
            total_strength = 0
            
            for assoc in memory.associations:
                # סוג קשר
                analysis['association_types'][assoc.association_type] += 1
                
                # חוזק קשר
                strength = assoc.strength
                total_strength += strength
                
                if strength > 0.7:
                    analysis['strength_distribution']['strong'] += 1
                elif strength > 0.3:
                    analysis['strength_distribution']['medium'] += 1
                else:
                    analysis['strength_distribution']['weak'] += 1
            
            analysis['avg_strength'] = total_strength / len(memory.associations)
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח קשרי זיכרון: {e}")
            return {}
    
    def _get_memory_access_history(self, memory) -> Dict[str, Any]:
        """קבלת היסטוריית גישה לזיכרון"""
        try:
            history = {
                'total_accesses': memory.access_count,
                'created_at': memory.created_at.isoformat(),
                'last_accessed': memory.last_accessed.isoformat(),
                'time_since_creation': (datetime.now() - memory.created_at).total_seconds(),
                'time_since_access': (datetime.now() - memory.last_accessed).total_seconds(),
                'access_frequency': 0.0  # גישות ליום
            }
            
            # חישוב תדירות גישה
            days_since_creation = max(1, (datetime.now() - memory.created_at).days)
            history['access_frequency'] = memory.access_count / days_since_creation
            
            return history
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת היסטוריית גישה: {e}")
            return {}
    
    def _create_layer_visualization_data(self, layer, layer_type: MemoryType) -> Dict[str, Any]:
        """יצירת נתוני ויזואליזציה לשכבה"""
        try:
            memories = list(layer.items.values())
            
            viz_data = {
                'layer_type': layer_type.value,
                'layer_name': self.layer_translations[layer_type],
                'memory_count': len(memories),
                'capacity': layer.capacity,
                'utilization': len(memories) / layer.capacity * 100,
                'nodes': [],
                'connections': []
            }
            
            # יצירת צמתים (זיכרונות)
            for memory in memories[:50]:  # הגבלה לביצועים
                node = {
                    'id': memory.id,
                    'content_preview': str(memory.content.data)[:50],
                    'strength': memory.strength,
                    'importance': memory.importance.value,
                    'connections_count': len(memory.associations)
                }
                viz_data['nodes'].append(node)
                
                # הוספת קשרים
                for assoc in memory.associations:
                    if assoc.target_id in [m.id for m in memories]:
                        connection = {
                            'source': memory.id,
                            'target': assoc.target_id,
                            'strength': assoc.strength,
                            'type': assoc.association_type
                        }
                        viz_data['connections'].append(connection)
            
            return viz_data
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת נתוני ויזואליזציה לשכבה: {e}")
            return {}
    
    def _create_connections_map(self) -> Dict[str, Any]:
        """יצירת מפת קשרים כללית"""
        try:
            connections_map = {
                'total_connections': 0,
                'inter_layer_connections': 0,
                'intra_layer_connections': 0,
                'layer_interactions': defaultdict(lambda: defaultdict(int))
            }
            
            # עבור כל שכבה
            for layer_type in MemoryType:
                layer = self.memory_engine.memory_system.get_layer(layer_type)
                
                for memory in layer.items.values():
                    for assoc in memory.associations:
                        connections_map['total_connections'] += 1
                        
                        # מציאת שכבת היעד
                        target_memory = self.memory_engine.retrieve_memory(assoc.target_id)
                        if target_memory:
                            if target_memory.memory_type == layer_type:
                                connections_map['intra_layer_connections'] += 1
                            else:
                                connections_map['inter_layer_connections'] += 1
                                connections_map['layer_interactions'][layer_type.value][target_memory.memory_type.value] += 1
            
            return connections_map
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת מפת קשרים: {e}")
            return {}
    
    def _create_temporal_distribution(self) -> Dict[str, Any]:
        """יצירת התפלגות זמנית של זיכרונות"""
        try:
            temporal_dist = {
                'hourly': defaultdict(int),
                'daily': defaultdict(int),
                'weekly': defaultdict(int),
                'monthly': defaultdict(int)
            }
            
            # עבור כל שכבה
            for layer_type in MemoryType:
                layer = self.memory_engine.memory_system.get_layer(layer_type)
                
                for memory in layer.items.values():
                    created = memory.created_at
                    
                    # התפלגות שעתית
                    temporal_dist['hourly'][created.hour] += 1
                    
                    # התפלגות יומית
                    temporal_dist['daily'][created.weekday()] += 1
                    
                    # התפלגות שבועית
                    week_number = created.isocalendar()[1]
                    temporal_dist['weekly'][week_number] += 1
                    
                    # התפלגות חודשית
                    temporal_dist['monthly'][created.month] += 1
            
            return temporal_dist
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת התפלגות זמנית: {e}")
            return {}
    
    def _create_layer_selector_html(self) -> str:
        """יצירת HTML לבחירת שכבות"""
        html = ""
        for layer_type in MemoryType:
            active_class = "active" if layer_type == self.current_layer else ""
            html += f'''
            <button class="layer-tab {active_class}" data-layer="{layer_type.value}" onclick="switchLayer('{layer_type.value}')">
                {self.layer_translations[layer_type]}
            </button>
            '''
        return html
    
    def _create_filters_html(self) -> str:
        """יצירת HTML לסינונים"""
        return '''
        <select class="filter-dropdown" id="importanceFilter">
            <option value="">כל רמות החשיבות</option>
            <option value="5">קריטי</option>
            <option value="4">גבוה</option>
            <option value="3">בינוני</option>
            <option value="2">נמוך</option>
            <option value="1">מינימלי</option>
        </select>
        
        <select class="filter-dropdown" id="stateFilter">
            <option value="">כל המצבים</option>
            <option value="active">פעיל</option>
            <option value="consolidating">מתאחד</option>
            <option value="consolidated">מאוחד</option>
            <option value="decaying">נפגם</option>
            <option value="archived">מאורכב</option>
        </select>
        
        <label style="font-size: 12px;">
            <input type="checkbox" id="hebrewOnly"> עברית בלבד
        </label>
        '''
    
    def _create_memories_list_html(self, data: Dict[str, Any]) -> str:
        """יצירת HTML לרשימת זיכרונות"""
        try:
            if 'error' in data:
                return f'<div class="error">שגיאה: {data["error"]}</div>'
            
            memories = data.get('memories', [])
            if not memories:
                return '<div class="no-memories">אין זיכרונות להצגה</div>'
            
            html = ""
            for memory in memories:
                importance_class = f"importance-{memory['importance_hebrew'].lower()}"
                state_class = f"state-{memory['state']}"
                
                html += f'''
                <div class="memory-item" data-memory-id="{memory['id']}">
                    <div class="memory-title">
                        {memory['content_preview']}
                        <span class="importance-badge {importance_class}">{memory['importance_hebrew']}</span>
                        <span class="state-badge {state_class}">{memory['state_hebrew']}</span>
                    </div>
                    <div class="memory-content">
                        סוג: {memory['memory_type_hebrew']} | עוצמה: {memory['strength']} | קשרים: {memory['associations_count']}
                    </div>
                    <div class="memory-meta">
                        <span>נוצר: {memory['created_at']}</span>
                        <span>גישות: {memory['access_count']}</span>
                    </div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<div class="error">שגיאה ביצירת רשימה: {str(e)}</div>'
    
    def _create_pagination_html(self, data: Dict[str, Any]) -> str:
        """יצירת HTML לניווט דפים"""
        try:
            if 'error' in data:
                return ""
            
            current_page = data.get('current_page', 1)
            total_pages = data.get('total_pages', 1)
            
            prev_disabled = "disabled" if current_page <= 1 else ""
            next_disabled = "disabled" if current_page >= total_pages else ""
            
            return f'''
            <button class="pagination-button" {prev_disabled} onclick="changePage('prev')">הקודם</button>
            <span class="page-info">דף {current_page} מתוך {total_pages}</span>
            <button class="pagination-button" {next_disabled} onclick="changePage('next')">הבא</button>
            '''
            
        except Exception as e:
            return f'<div class="error">שגיאה בניווט: {str(e)}</div>'