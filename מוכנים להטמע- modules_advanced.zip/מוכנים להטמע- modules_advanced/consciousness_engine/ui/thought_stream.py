#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Thought Stream UI - תצוגת זרם מחשבות
=====================================

רכיב UI דינמי לתצוגת זרם המחשבות בזמן אמת.
מציג מחשבות פעילות, קשרים ביניהן ותהליכים קוגניטיביים.

תכונות מרכזיות:
- תצוגת זרם מחשבות בזמן אמת
- ויזואליזציה של קשרים בין מחשבות
- מעקב אחר תהליכים קוגניטיביים
- תמיכה בזרמים מרובים
- ממשק עברי אינטראקטיבי
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set
from collections import deque, defaultdict

from ..core.thought_engine import ThoughtEngine
from ..models.thoughts import ThoughtType, ThoughtIntensity, ThoughtState, CognitiveProcess


class ThoughtStreamUI:
    """ממשק תצוגת זרם מחשבות בזמן אמת"""
    
    def __init__(self, thought_engine: ThoughtEngine = None):
        """אתחול תצוגת זרם המחשבות"""
        self.logger = logging.getLogger(__name__)
        
        # מנוע המחשבות
        self.thought_engine = thought_engine
        
        # הגדרות תצוגה
        self.display_settings = {
            'max_visible_thoughts': 10,
            'show_connections': True,
            'show_cognitive_processes': True,
            'animation_enabled': True,
            'update_interval': 1500,  # מילישניות
            'auto_scroll': True,
            'show_timestamps': True,
            'color_by_type': True
        }
        
        # היסטוריית תצוגה
        self.display_history: deque = deque(maxlen=100)
        self.thought_positions: Dict[str, Dict[str, float]] = {}  # לאנימציות
        
        # זרמים פעילים
        self.active_streams = ['main']
        self.selected_stream = 'main'
        
        # סטטיסטיקות תצוגה
        self.stream_stats = {
            'thoughts_displayed': 0,
            'connections_shown': 0,
            'updates_count': 0,
            'last_update': None,
            'most_active_type': None,
            'avg_intensity': 0.0
        }
        
        # מיפוי צבעים לסוגי מחשבות
        self.thought_colors = {
            ThoughtType.ANALYTICAL: '#3498db',      # כחול
            ThoughtType.CREATIVE: '#e74c3c',        # אדום
            ThoughtType.EMOTIONAL: '#f39c12',       # כתום
            ThoughtType.INTUITIVE: '#9b59b6',       # סגול
            ThoughtType.REFLECTIVE: '#1abc9c',      # ירוק-כחול
            ThoughtType.GOAL_ORIENTED: '#27ae60',   # ירוק
            ThoughtType.ASSOCIATIVE: '#34495e',     # אפור כהה
            ThoughtType.ABSTRACT: '#e67e22',        # כתום כהה
            ThoughtType.CONCRETE: '#95a5a6',        # אפור
            ThoughtType.METACOGNITIVE: '#8e44ad'    # סגול כהה
        }
        
        # תרגומים עבריים
        self.thought_type_translations = {
            ThoughtType.ANALYTICAL: 'אנליטית',
            ThoughtType.CREATIVE: 'יצירתית',
            ThoughtType.EMOTIONAL: 'רגשית',
            ThoughtType.INTUITIVE: 'אינטואיטיבית',
            ThoughtType.REFLECTIVE: 'הרהורית',
            ThoughtType.GOAL_ORIENTED: 'מכוונת מטרה',
            ThoughtType.ASSOCIATIVE: 'אסוציאטיבית',
            ThoughtType.ABSTRACT: 'מופשטת',
            ThoughtType.CONCRETE: 'קונקרטית',
            ThoughtType.METACOGNITIVE: 'מטא-קוגניטיבית'
        }
        
        self.intensity_translations = {
            ThoughtIntensity.MINIMAL: 'מינימלית',
            ThoughtIntensity.LOW: 'נמוכה',
            ThoughtIntensity.MODERATE: 'בינונית',
            ThoughtIntensity.HIGH: 'גבוהה',
            ThoughtIntensity.INTENSE: 'אינטנסיבית'
        }
        
        self.state_translations = {
            ThoughtState.EMERGING: 'מתגבשת',
            ThoughtState.ACTIVE: 'פעילה',
            ThoughtState.SUSTAINED: 'מתמשכת',
            ThoughtState.FADING: 'דועכת',
            ThoughtState.COMPLETED: 'הושלמה',
            ThoughtState.INTERRUPTED: 'נקטעה',
            ThoughtState.DORMANT: 'רדומה'
        }
        
        self.cognitive_process_translations = {
            CognitiveProcess.PERCEPTION: 'תפיסה',
            CognitiveProcess.ATTENTION: 'קשב',
            CognitiveProcess.MEMORY_RETRIEVAL: 'אחזור זיכרון',
            CognitiveProcess.REASONING: 'חשיבה',
            CognitiveProcess.PLANNING: 'תכנון',
            CognitiveProcess.DECISION_MAKING: 'קבלת החלטות',
            CognitiveProcess.PROBLEM_SOLVING: 'פתרון בעיות',
            CognitiveProcess.LEARNING: 'למידה',
            CognitiveProcess.IMAGINATION: 'דמיון',
            CognitiveProcess.EVALUATION: 'הערכה'
        }
        
        self.logger.info("תצוגת זרם מחשבות אותחלה")
    
    def update_stream_display(self, stream_id: str = 'main') -> Dict[str, Any]:
        """עדכון תצוגת זרם מחשבות"""
        try:
            if not self.thought_engine:
                return {'error': 'מנוע מחשבות אינו זמין'}
            
            # קבלת מחשבות פעילות מהזרם
            active_thoughts = self.thought_engine.get_active_thoughts(stream_id)
            
            # קבלת מצב קוגניטיבי נוכחי
            cognitive_state = self.thought_engine.get_cognitive_state()
            
            # עיצוב מחשבות לתצוגה
            formatted_thoughts = [self._format_thought_for_display(thought) for thought in active_thoughts]
            
            # יצירת נתוני קשרים
            connections_data = self._generate_connections_data(active_thoughts)
            
            # עדכון היסטוריה
            self._update_display_history(formatted_thoughts)
            
            # סטטיסטיקות זרם
            stream_statistics = self._calculate_stream_statistics(active_thoughts, cognitive_state)
            
            # נתוני תצוגה
            display_data = {
                'stream_id': stream_id,
                'timestamp': datetime.now().isoformat(),
                'active_thoughts': formatted_thoughts,
                'connections': connections_data,
                'cognitive_state': cognitive_state,
                'stream_statistics': stream_statistics,
                'visual_elements': self._generate_visual_elements(active_thoughts),
                'animation_data': self._generate_animation_data(formatted_thoughts)
            }
            
            # עדכון סטטיסטיקות
            self.stream_stats['updates_count'] += 1
            self.stream_stats['last_update'] = datetime.now()
            self.stream_stats['thoughts_displayed'] = len(formatted_thoughts)
            
            return display_data
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון תצוגת זרם: {e}")
            return {'error': str(e)}
    
    def get_stream_html(self) -> str:
        """יצירת HTML עבור תצוגת זרם מחשבות"""
        try:
            # קבלת נתוני תצוגה עדכניים
            display_data = self.update_stream_display(self.selected_stream)
            
            if 'error' in display_data:
                return self._get_error_html(display_data['error'])
            
            html_content = f'''
            <div class="thought-stream-container" dir="rtl">
                <div class="stream-header">
                    <h2>💭 זרם מחשבות</h2>
                    <div class="stream-controls">
                        {self._create_stream_selector_html()}
                        <button onclick="pauseStream()" id="pauseBtn">השהה</button>
                        <button onclick="clearStream()">נקה</button>
                    </div>
                </div>
                
                <div class="cognitive-state-panel">
                    {self._create_cognitive_state_html(display_data)}
                </div>
                
                <div class="stream-content">
                    <div class="thoughts-flow" id="thoughtsFlow">
                        {self._create_thoughts_flow_html(display_data)}
                    </div>
                    
                    <div class="connections-visualization" id="connectionsViz">
                        {self._create_connections_html(display_data)}
                    </div>
                </div>
                
                <div class="stream-statistics">
                    {self._create_statistics_html(display_data)}
                </div>
                
                <div class="thought-input">
                    <input type="text" id="thoughtInput" placeholder="הוסף מחשבה חדשה...">
                    <button onclick="addThought()">הוסף</button>
                </div>
            </div>
            '''
            
            return html_content
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת HTML זרם: {e}")
            return self._get_error_html(str(e))
    
    def get_stream_css(self) -> str:
        """קבלת CSS עבור תצוגת זרם מחשבות"""
        return '''
        .thought-stream-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            min-height: 700px;
            overflow: hidden;
        }
        
        .stream-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            padding-bottom: 15px;
        }
        
        .stream-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        
        .stream-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .stream-selector {
            padding: 6px 12px;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 12px;
        }
        
        .stream-controls button {
            padding: 6px 12px;
            border: none;
            border-radius: 15px;
            background: rgba(255,255,255,0.2);
            color: white;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s ease;
        }
        
        .stream-controls button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .cognitive-state-panel {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .cognitive-indicators {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 10px;
        }
        
        .cognitive-indicator {
            text-align: center;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
        }
        
        .indicator-value {
            font-size: 18px;
            font-weight: bold;
            display: block;
            margin-bottom: 4px;
        }
        
        .indicator-label {
            font-size: 10px;
            opacity: 0.8;
        }
        
        .stream-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            height: 400px;
        }
        
        .thoughts-flow {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            overflow-y: auto;
            position: relative;
        }
        
        .thought-bubble {
            background: rgba(255,255,255,0.2);
            border-radius: 15px;
            padding: 12px;
            margin-bottom: 10px;
            position: relative;
            border-right: 4px solid transparent;
            transition: all 0.3s ease;
            cursor: pointer;
            animation: thoughtAppear 0.5s ease-out;
        }
        
        @keyframes thoughtAppear {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .thought-bubble:hover {
            background: rgba(255,255,255,0.3);
            transform: translateX(-5px);
        }
        
        .thought-bubble.active {
            border-right-color: #fff;
            box-shadow: 0 0 15px rgba(255,255,255,0.3);
        }
        
        .thought-bubble.fading {
            opacity: 0.5;
            animation: thoughtFade 2s ease-out;
        }
        
        @keyframes thoughtFade {
            from { opacity: 1; }
            to { opacity: 0.5; }
        }
        
        .thought-content {
            font-size: 14px;
            line-height: 1.4;
            margin-bottom: 8px;
        }
        
        .thought-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            opacity: 0.7;
        }
        
        .thought-type {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: bold;
            font-size: 9px;
        }
        
        .thought-intensity {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .intensity-dots {
            display: flex;
            gap: 2px;
        }
        
        .intensity-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
        }
        
        .intensity-dot.active {
            background: #fff;
        }
        
        .connections-visualization {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            position: relative;
        }
        
        .connection-node {
            position: absolute;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .connection-node:hover {
            background: rgba(255,255,255,0.5);
            transform: scale(1.2);
        }
        
        .connection-line {
            position: absolute;
            background: rgba(255,255,255,0.3);
            height: 2px;
            transform-origin: left center;
            transition: all 0.3s ease;
        }
        
        .connection-line.strong {
            background: rgba(255,255,255,0.6);
            height: 3px;
        }
        
        .stream-statistics {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 10px;
        }
        
        .stat-item {
            text-align: center;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
        }
        
        .stat-value {
            font-size: 16px;
            font-weight: bold;
            display: block;
        }
        
        .stat-label {
            font-size: 10px;
            opacity: 0.8;
        }
        
        .thought-input {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            padding: 15px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        
        .thought-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 20px;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 14px;
        }
        
        .thought-input input::placeholder {
            color: rgba(255,255,255,0.7);
        }
        
        .thought-input button {
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            cursor: pointer;
            font-size: 14px;
        }
        
        .thought-input button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        /* אנימציות מתקדמות */
        .thought-pulse {
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255,255,255,0.4); }
            70% { box-shadow: 0 0 0 10px rgba(255,255,255,0); }
            100% { box-shadow: 0 0 0 0 rgba(255,255,255,0); }
        }
        
        .cognitive-process-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin: 0 2px;
            background: rgba(255,255,255,0.5);
            animation: processBlink 1s infinite alternate;
        }
        
        @keyframes processBlink {
            from { opacity: 0.3; }
            to { opacity: 1; }
        }
        
        /* סגנונות RTL */
        .thought-bubble {
            text-align: right;
        }
        
        .thought-meta {
            direction: rtl;
        }
        '''
    
    def get_stream_javascript(self) -> str:
        """קבלת JavaScript עבור תצוגת זרם מחשבות"""
        return f'''
        // הגדרות זרם מחשבות
        const streamConfig = {json.dumps(self.display_settings, ensure_ascii=False)};
        let streamPaused = false;
        let updateInterval = null;
        let selectedThought = null;
        
        class ThoughtStreamUI {{
            constructor() {{
                this.thoughtsData = [];
                this.connectionsData = [];
                this.initialize();
            }}
            
            initialize() {{
                this.setupEventListeners();
                this.startAutoUpdate();
                this.initializeAnimations();
            }}
            
            setupEventListeners() {{
                // בחירת מחשבה
                document.addEventListener('click', (e) => {{
                    if (e.target.classList.contains('thought-bubble')) {{
                        this.selectThought(e.target);
                    }}
                }});
                
                // הוספת מחשבה
                document.getElementById('thoughtInput').addEventListener('keypress', (e) => {{
                    if (e.key === 'Enter') {{
                        this.addNewThought();
                    }}
                }});
                
                // ניווט מקלדת
                document.addEventListener('keydown', (e) => {{
                    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {{
                        this.navigateThoughts(e.key === 'ArrowUp' ? -1 : 1);
                        e.preventDefault();
                    }}
                }});
            }}
            
            startAutoUpdate() {{
                if (streamConfig.animation_enabled && !streamPaused) {{
                    updateInterval = setInterval(() => {{
                        this.updateStreamDisplay();
                    }}, streamConfig.update_interval);
                }}
            }}
            
            stopAutoUpdate() {{
                if (updateInterval) {{
                    clearInterval(updateInterval);
                    updateInterval = null;
                }}
            }}
            
            updateStreamDisplay() {{
                if (streamPaused) return;
                
                console.log('מעדכן תצוגת זרם מחשבות...');
                // כאן יהיה קוד לעדכון נתונים מהשרת
                
                this.refreshThoughts();
                this.updateConnections();
                this.updateCognitiveState();
            }}
            
            refreshThoughts() {{
                const thoughtsContainer = document.getElementById('thoughtsFlow');
                if (!thoughtsContainer) return;
                
                // אנימציה של מחשבות חדשות
                this.animateNewThoughts();
                
                // הסרת מחשבות ישנות
                this.removeOldThoughts();
                
                // עדכון עוצמות
                this.updateThoughtIntensities();
            }}
            
            animateNewThoughts() {{
                // אנימציה של מחשבות שנוספו לאחרונה
                const newThoughts = document.querySelectorAll('.thought-bubble.new');
                newThoughts.forEach(thought => {{
                    thought.classList.remove('new');
                    thought.style.animation = 'thoughtAppear 0.5s ease-out';
                }});
            }}
            
            removeOldThoughts() {{
                // הסרת מחשבות ישנות עם אנימציה
                const oldThoughts = document.querySelectorAll('.thought-bubble.old');
                oldThoughts.forEach(thought => {{
                    thought.style.animation = 'thoughtFade 1s ease-out forwards';
                    setTimeout(() => thought.remove(), 1000);
                }});
            }}
            
            updateThoughtIntensities() {{
                // עדכון עוצמת מחשבות
                const thoughts = document.querySelectorAll('.thought-bubble');
                thoughts.forEach(thought => {{
                    const intensity = parseFloat(thought.dataset.intensity || 0);
                    this.updateIntensityDisplay(thought, intensity);
                }});
            }}
            
            updateIntensityDisplay(thoughtElement, intensity) {{
                const intensityDots = thoughtElement.querySelectorAll('.intensity-dot');
                const activeCount = Math.ceil(intensity);
                
                intensityDots.forEach((dot, index) => {{
                    if (index < activeCount) {{
                        dot.classList.add('active');
                    }} else {{
                        dot.classList.remove('active');
                    }}
                }});
            }}
            
            updateConnections() {{
                const connectionsContainer = document.getElementById('connectionsViz');
                if (!connectionsContainer) return;
                
                // עדכון קשרים בין מחשבות
                this.drawConnections();
            }}
            
            drawConnections() {{
                // ציור קשרים בין מחשבות
                console.log('מציר קשרים בין מחשבות...');
                // כאן יהיה קוד לציור קשרים
            }}
            
            updateCognitiveState() {{
                // עדכון מצב קוגניטיבי
                const indicators = document.querySelectorAll('.cognitive-indicator');
                indicators.forEach(indicator => {{
                    this.animateIndicator(indicator);
                }});
            }}
            
            animateIndicator(indicator) {{
                // אנימציה של אינדיקטורים קוגניטיביים
                const value = indicator.querySelector('.indicator-value');
                if (value) {{
                    value.style.animation = 'pulse 1s ease-in-out';
                    setTimeout(() => {{
                        value.style.animation = '';
                    }}, 1000);
                }}
            }}
            
            selectThought(thoughtElement) {{
                // ביטול בחירה קודמת
                document.querySelectorAll('.thought-bubble').forEach(t => {{
                    t.classList.remove('selected');
                }});
                
                // בחירת מחשבה חדשה
                thoughtElement.classList.add('selected');
                selectedThought = thoughtElement.dataset.thoughtId;
                
                // הצגת פרטי מחשבה
                this.showThoughtDetails(selectedThought);
            }}
            
            showThoughtDetails(thoughtId) {{
                console.log('מציג פרטי מחשבה:', thoughtId);
                // כאן יהיה קוד להצגת פרטי מחשבה
            }}
            
            addNewThought() {{
                const input = document.getElementById('thoughtInput');
                const content = input.value.trim();
                
                if (content) {{
                    console.log('מוסיף מחשבה חדשה:', content);
                    // כאן יהיה קוד להוספת מחשבה חדשה
                    input.value = '';
                }}
            }}
            
            navigateThoughts(direction) {{
                const thoughts = document.querySelectorAll('.thought-bubble');
                const currentIndex = Array.from(thoughts).findIndex(t => 
                    t.classList.contains('selected'));
                
                let newIndex = currentIndex + direction;
                if (newIndex < 0) newIndex = thoughts.length - 1;
                if (newIndex >= thoughts.length) newIndex = 0;
                
                if (thoughts[newIndex]) {{
                    this.selectThought(thoughts[newIndex]);
                    thoughts[newIndex].scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                }}
            }}
            
            pauseStream() {{
                streamPaused = !streamPaused;
                const pauseBtn = document.getElementById('pauseBtn');
                
                if (streamPaused) {{
                    this.stopAutoUpdate();
                    pauseBtn.textContent = 'המשך';
                }} else {{
                    this.startAutoUpdate();
                    pauseBtn.textContent = 'השהה';
                }}
            }}
            
            clearStream() {{
                const thoughtsContainer = document.getElementById('thoughtsFlow');
                if (thoughtsContainer) {{
                    thoughtsContainer.innerHTML = '<p style="text-align: center; opacity: 0.7;">זרם המחשבות נוקה</p>';
                }}
                
                selectedThought = null;
            }}
            
            initializeAnimations() {{
                // אתחול אנימציות CSS
                this.addCSSAnimations();
            }}
            
            addCSSAnimations() {{
                // הוספת אנימציות דינמיות
                const style = document.createElement('style');
                style.textContent = `
                    .thought-bubble.highlighted {{
                        animation: thoughtHighlight 2s ease-in-out;
                    }}
                    
                    @keyframes thoughtHighlight {{
                        0%, 100% {{ box-shadow: 0 0 0 0 rgba(255,255,255,0.4); }}
                        50% {{ box-shadow: 0 0 0 10px rgba(255,255,255,0.8); }}
                    }}
                `;
                document.head.appendChild(style);
            }}
        }}
        
        // פונקציות גלובליות
        function pauseStream() {{
            window.thoughtStream.pauseStream();
        }}
        
        function clearStream() {{
            window.thoughtStream.clearStream();
        }}
        
        function addThought() {{
            window.thoughtStream.addNewThought();
        }}
        
        function switchStream(streamId) {{
            console.log('מעבר לזרם:', streamId);
            // כאן יהיה קוד למעבר זרם
        }}
        
        // אתחול
        document.addEventListener('DOMContentLoaded', function() {{
            window.thoughtStream = new ThoughtStreamUI();
        }});
        
        // ניקוי בסגירה
        window.addEventListener('beforeunload', function() {{
            if (window.thoughtStream) {{
                window.thoughtStream.stopAutoUpdate();
            }}
        }});
        '''
    
    def add_manual_thought(self, content: str, thought_type: ThoughtType = ThoughtType.ANALYTICAL) -> bool:
        """הוספת מחשבה ידנית לזרם"""
        try:
            if not self.thought_engine:
                return False
            
            thought_id = self.thought_engine.create_thought(
                content=content,
                thought_type=thought_type,
                context={'source': 'manual_input', 'ui_component': 'thought_stream'}
            )
            
            self.logger.info(f"נוספה מחשבה ידנית: {content[:50]}...")
            return bool(thought_id)
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת מחשבה ידנית: {e}")
            return False
    
    def _format_thought_for_display(self, thought) -> Dict[str, Any]:
        """עיצוב מחשבה לתצוגה"""
        try:
            # קיצור תוכן לתצוגה
            content_preview = str(thought.content.primary_content)
            if len(content_preview) > 150:
                content_preview = content_preview[:150] + "..."
            
            return {
                'id': thought.id,
                'content': content_preview,
                'full_content': str(thought.content.primary_content),
                'type': thought.thought_type.value,
                'type_hebrew': self.thought_type_translations.get(thought.thought_type, thought.thought_type.value),
                'intensity': thought.intensity.value,
                'intensity_hebrew': self.intensity_translations.get(thought.intensity, str(thought.intensity.value)),
                'state': thought.state.value,
                'state_hebrew': self.state_translations.get(thought.state, thought.state.value),
                'color': self.thought_colors.get(thought.thought_type, '#95a5a6'),
                'created_at': thought.created_at.strftime("%H:%M:%S"),
                'duration': (datetime.now() - thought.created_at).total_seconds(),
                'attention_level': thought.attention_level,
                'confidence': thought.confidence,
                'emotional_charge': thought.emotional_charge,
                'connections_count': len(thought.connections),
                'cognitive_processes': [
                    self.cognitive_process_translations.get(proc, proc.value)
                    for proc in thought.cognitive_processes
                ],
                'keywords': list(thought.content.keywords)[:5],  # 5 מילות מפתח ראשונות
                'priority': thought.priority
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיצוב מחשבה: {e}")
            return {'id': thought.id, 'error': str(e)}
    
    def _generate_connections_data(self, thoughts: List) -> List[Dict[str, Any]]:
        """יצירת נתוני קשרים בין מחשבות"""
        try:
            connections = []
            thought_ids = {thought.id for thought in thoughts}
            
            for thought in thoughts:
                for connection in thought.connections:
                    if connection.target_thought_id in thought_ids:
                        connections.append({
                            'source': thought.id,
                            'target': connection.target_thought_id,
                            'type': connection.connection_type,
                            'strength': connection.strength,
                            'bidirectional': connection.bidirectional,
                            'created_at': connection.created_at.strftime("%H:%M:%S")
                        })
            
            return connections
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת נתוני קשרים: {e}")
            return []
    
    def _update_display_history(self, formatted_thoughts: List[Dict[str, Any]]):
        """עדכון היסטוריית התצוגה"""
        try:
            snapshot = {
                'timestamp': datetime.now().isoformat(),
                'thoughts_count': len(formatted_thoughts),
                'dominant_type': self._get_dominant_thought_type(formatted_thoughts),
                'avg_intensity': self._calculate_average_intensity(formatted_thoughts)
            }
            
            self.display_history.append(snapshot)
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון היסטוריית תצוגה: {e}")
    
    def _calculate_stream_statistics(self, thoughts: List, cognitive_state: Dict[str, Any]) -> Dict[str, Any]:
        """חישוב סטטיסטיקות זרם"""
        try:
            if not thoughts:
                return {}
            
            # התפלגות סוגי מחשבות
            type_distribution = defaultdict(int)
            intensity_sum = 0
            total_confidence = 0
            emotional_thoughts = 0
            
            for thought in thoughts:
                type_distribution[thought.thought_type.value] += 1
                intensity_sum += thought.intensity.value
                total_confidence += thought.confidence
                
                if abs(thought.emotional_charge) > 0.1:
                    emotional_thoughts += 1
            
            # סוג מחשבה דומיננטי
            dominant_type = max(type_distribution.items(), key=lambda x: x[1]) if type_distribution else None
            
            stats = {
                'total_thoughts': len(thoughts),
                'type_distribution': dict(type_distribution),
                'dominant_type': {
                    'type': dominant_type[0],
                    'hebrew_name': self.thought_type_translations.get(ThoughtType(dominant_type[0]), dominant_type[0]),
                    'count': dominant_type[1]
                } if dominant_type else None,
                'average_intensity': intensity_sum / len(thoughts),
                'average_confidence': total_confidence / len(thoughts),
                'emotional_thoughts_ratio': emotional_thoughts / len(thoughts),
                'cognitive_complexity': cognitive_state.get('cognitive_complexity', 0.0),
                'stream_coherence': cognitive_state.get('stream_coherence', 0.0),
                'processing_speed': cognitive_state.get('processing_speed', 0.0),
                'active_processes': cognitive_state.get('cognitive_processes', {})
            }
            
            # עדכון סטטיסטיקות כלליות
            self.stream_stats['most_active_type'] = stats.get('dominant_type', {}).get('hebrew_name', 'לא ידוע')
            self.stream_stats['avg_intensity'] = stats['average_intensity']
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב סטטיסטיקות זרם: {e}")
            return {}
    
    def _generate_visual_elements(self, thoughts: List) -> Dict[str, Any]:
        """יצירת אלמנטים ויזואליים"""
        try:
            return {
                'thought_map': self._create_thought_map(thoughts),
                'intensity_graph': self._create_intensity_graph(thoughts),
                'type_distribution_chart': self._create_type_distribution_chart(thoughts)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת אלמנטים ויזואליים: {e}")
            return {}
    
    def _generate_animation_data(self, thoughts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """יצירת נתוני אנימציה"""
        try:
            animation_data = {
                'new_thoughts': [],
                'fading_thoughts': [],
                'position_updates': {}
            }
            
            for thought in thoughts:
                # זיהוי מחשבות חדשות
                if thought['duration'] < 5:  # פחות מ-5 שניות
                    animation_data['new_thoughts'].append(thought['id'])
                
                # זיהוי מחשבות דועכות
                if thought['state'] == 'fading':
                    animation_data['fading_thoughts'].append(thought['id'])
                
                # עדכון מיקומים
                animation_data['position_updates'][thought['id']] = {
                    'intensity': thought['intensity'],
                    'attention_level': thought['attention_level']
                }
            
            return animation_data
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת נתוני אנימציה: {e}")
            return {}
    
    def _get_dominant_thought_type(self, thoughts: List[Dict[str, Any]]) -> Optional[str]:
        """קבלת סוג המחשבה הדומיננטי"""
        try:
            if not thoughts:
                return None
            
            type_counts = defaultdict(int)
            for thought in thoughts:
                type_counts[thought['type']] += 1
            
            dominant = max(type_counts.items(), key=lambda x: x[1])
            return dominant[0]
            
        except Exception:
            return None
    
    def _calculate_average_intensity(self, thoughts: List[Dict[str, Any]]) -> float:
        """חישוב עוצמה ממוצעת"""
        try:
            if not thoughts:
                return 0.0
            
            total_intensity = sum(thought['intensity'] for thought in thoughts)
            return total_intensity / len(thoughts)
            
        except Exception:
            return 0.0
    
    def _create_thought_map(self, thoughts: List) -> Dict[str, Any]:
        """יצירת מפת מחשבות"""
        try:
            return {
                'nodes': [{'id': t.id, 'type': t.thought_type.value, 'intensity': t.intensity.value} for t in thoughts],
                'edges': []  # יוגדר לפי הקשרים
            }
        except Exception:
            return {}
    
    def _create_intensity_graph(self, thoughts: List) -> Dict[str, Any]:
        """יצירת גרף עוצמה"""
        try:
            intensities = [t.intensity.value for t in thoughts]
            return {
                'data': intensities,
                'max': max(intensities) if intensities else 0,
                'min': min(intensities) if intensities else 0,
                'avg': sum(intensities) / len(intensities) if intensities else 0
            }
        except Exception:
            return {}
    
    def _create_type_distribution_chart(self, thoughts: List) -> Dict[str, Any]:
        """יצירת תרשים התפלגות סוגים"""
        try:
            type_counts = defaultdict(int)
            for thought in thoughts:
                type_counts[thought.thought_type.value] += 1
            
            return dict(type_counts)
            
        except Exception:
            return {}
    
    def _create_stream_selector_html(self) -> str:
        """יצירת HTML לבחירת זרם"""
        options = ""
        for stream in self.active_streams:
            selected = "selected" if stream == self.selected_stream else ""
            options += f'<option value="{stream}" {selected}>{stream}</option>'
        
        return f'<select class="stream-selector" onchange="switchStream(this.value)">{options}</select>'
    
    def _create_cognitive_state_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML למצב קוגניטיבי"""
        try:
            cognitive_state = display_data.get('cognitive_state', {})
            
            html = '''
            <h4>מצב קוגניטיבי נוכחי:</h4>
            <div class="cognitive-indicators">
            '''
            
            indicators = [
                ('מורכבות', cognitive_state.get('cognitive_complexity', 0.0)),
                ('קוהרנטיות', cognitive_state.get('stream_coherence', 0.0)),
                ('מהירות', cognitive_state.get('processing_speed', 0.0)),
                ('פוקוס', cognitive_state.get('focus_level', 0.0)),
                ('יצירתיות', cognitive_state.get('creativity_level', 0.0))
            ]
            
            for label, value in indicators:
                percentage = int(value * 100)
                html += f'''
                <div class="cognitive-indicator">
                    <span class="indicator-value">{percentage}%</span>
                    <span class="indicator-label">{label}</span>
                </div>
                '''
            
            html += '</div>'
            
            # תהליכים קוגניטיביים פעילים
            active_processes = cognitive_state.get('cognitive_processes', {})
            if active_processes:
                html += '<div style="margin-top: 10px;">תהליכים פעילים: '
                for process, count in active_processes.items():
                    hebrew_name = self.cognitive_process_translations.get(CognitiveProcess(process), process)
                    html += f'<span class="cognitive-process-indicator" title="{hebrew_name} ({count})"></span>'
                html += '</div>'
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת מצב קוגניטיבי: {str(e)}</p>'
    
    def _create_thoughts_flow_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לזרם מחשבות"""
        try:
            thoughts = display_data.get('active_thoughts', [])
            
            if not thoughts:
                return '<p style="text-align: center; opacity: 0.7;">אין מחשבות פעילות כרגע</p>'
            
            html = ""
            
            for thought in thoughts[:self.display_settings['max_visible_thoughts']]:
                # קביעת מחלקות CSS
                css_classes = ['thought-bubble']
                
                if thought['state'] == 'active':
                    css_classes.append('active')
                elif thought['state'] == 'fading':
                    css_classes.append('fading')
                
                if thought['intensity'] >= 4:
                    css_classes.append('thought-pulse')
                
                # יצירת נקודות עוצמה
                intensity_dots = ""
                for i in range(5):
                    active_class = "active" if i < thought['intensity'] else ""
                    intensity_dots += f'<div class="intensity-dot {active_class}"></div>'
                
                # תהליכים קוגניטיביים
                processes_html = ""
                for process in thought['cognitive_processes'][:3]:  # מקסימום 3
                    processes_html += f'<span class="cognitive-process-tag" title="{process}">{process[:3]}</span>'
                
                html += f'''
                <div class="{' '.join(css_classes)}" 
                     data-thought-id="{thought['id']}" 
                     data-intensity="{thought['intensity']}"
                     style="border-right-color: {thought['color']};">
                    <div class="thought-content">{thought['content']}</div>
                    <div class="thought-meta">
                        <div class="thought-left">
                            <span class="thought-type" style="background-color: {thought['color']};">
                                {thought['type_hebrew']}
                            </span>
                            {processes_html}
                        </div>
                        <div class="thought-right">
                            <div class="thought-intensity">
                                <span>{thought['intensity_hebrew']}</span>
                                <div class="intensity-dots">{intensity_dots}</div>
                            </div>
                            <span class="thought-time">{thought['created_at']}</span>
                        </div>
                    </div>
                </div>
                '''
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת זרם מחשבות: {str(e)}</p>'
    
    def _create_connections_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לתצוגת קשרים"""
        try:
            connections = display_data.get('connections', [])
            
            html = '<h4>קשרים בין מחשבות:</h4>'
            
            if not connections:
                html += '<p style="text-align: center; opacity: 0.7;">אין קשרים פעילים</p>'
                return html
            
            html += '<div class="connections-container" style="position: relative; height: 200px;">'
            
            # נקודות קשר (פשוט לעכשיו)
            for i, conn in enumerate(connections[:10]):  # מקסימום 10 קשרים
                x = 30 + (i % 5) * 40
                y = 30 + (i // 5) * 40
                
                strength_class = "strong" if conn['strength'] > 0.7 else ""
                
                html += f'''
                <div class="connection-node" 
                     style="left: {x}px; top: {y}px;"
                     title="{conn['type']} - עוצמה: {conn['strength']:.2f}">
                    {i+1}
                </div>
                '''
            
            html += '</div>'
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת קשרים: {str(e)}</p>'
    
    def _create_statistics_html(self, display_data: Dict[str, Any]) -> str:
        """יצירת HTML לסטטיסטיקות"""
        try:
            stats = display_data.get('stream_statistics', {})
            
            html = '''
            <h4>סטטיסטיקות זרם:</h4>
            <div class="stats-grid">
            '''
            
            stats_items = [
                ('מחשבות פעילות', stats.get('total_thoughts', 0)),
                ('עוצמה ממוצעת', f"{stats.get('average_intensity', 0.0):.2f}"),
                ('רמת ביטחון', f"{stats.get('average_confidence', 0.0):.2f}"),
                ('מורכבות', f"{stats.get('cognitive_complexity', 0.0):.2f}"),
                ('קוהרנטיות', f"{stats.get('stream_coherence', 0.0):.2f}")
            ]
            
            for label, value in stats_items:
                html += f'''
                <div class="stat-item">
                    <span class="stat-value">{value}</span>
                    <span class="stat-label">{label}</span>
                </div>
                '''
            
            html += '</div>'
            
            # סוג דומיננטי
            dominant = stats.get('dominant_type')
            if dominant:
                html += f'<p style="margin-top: 10px; text-align: center;">סוג דומיננטי: <strong>{dominant["hebrew_name"]}</strong></p>'
            
            return html
            
        except Exception as e:
            return f'<p>שגיאה בתצוגת סטטיסטיקות: {str(e)}</p>'
    
    def _get_error_html(self, error_message: str) -> str:
        """HTML לתצוגת שגיאה"""
        return f'''
        <div class="thought-stream-container" dir="rtl">
            <div style="text-align: center; padding: 40px;">
                <h3 style="color: #ff6b6b;">שגיאה בזרם מחשבות</h3>
                <p>{error_message}</p>
                <button onclick="location.reload()" style="padding: 10px 20px; background: #4ecdc4; color: white; border: none; border-radius: 5px;">נסה שוב</button>
            </div>
        </div>
        '''