"""
Consciousness Engine - Insights Panel
Advanced analytics and insights for consciousness system performance
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import statistics
from ..models.emotions import EmotionType
from ..models.memory import MemoryType
from ..models.thoughts import ThoughtType
from ..models.states import ConsciousnessLevel

class InsightsPanel:
    """Advanced insights and analytics panel for consciousness system"""
    
    def __init__(self):
        self.metrics_history = []
        self.performance_data = {}
        self.pattern_cache = {}
        
    def generate_html(self) -> str:
        """Generate HTML for insights panel"""
        return f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="he">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>לוח תובנות מערכת התודעה</title>
            {self._generate_css()}
        </head>
        <body>
            <div class="insights-container">
                <div class="insights-header">
                    <h1>🧠 לוח תובנות מערכת התודעה</h1>
                    <div class="header-controls">
                        <select id="timeRange" class="time-selector">
                            <option value="1h">שעה אחרונה</option>
                            <option value="24h" selected>24 שעות אחרונות</option>
                            <option value="7d">שבוע אחרון</option>
                            <option value="30d">חודש אחרון</option>
                        </select>
                        <button id="exportData" class="export-btn">📊 ייצא נתונים</button>
                        <button id="refreshInsights" class="refresh-btn">🔄 רענן</button>
                    </div>
                </div>
                
                <div class="insights-grid">
                    <!-- Performance Overview -->
                    <div class="insight-card performance-overview">
                        <h2>📈 סקירת ביצועים</h2>
                        <div class="performance-metrics">
                            <div class="metric-item">
                                <span class="metric-label">יעילות כללית</span>
                                <div class="metric-value">
                                    <span id="overallEfficiency">85%</span>
                                    <div class="efficiency-bar">
                                        <div class="efficiency-fill" style="width: 85%"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="metric-item">
                                <span class="metric-label">זמן תגובה ממוצע</span>
                                <span id="avgResponseTime" class="metric-value">342ms</span>
                            </div>
                            <div class="metric-item">
                                <span class="metric-label">אירועי תודעה</span>
                                <span id="consciousnessEvents" class="metric-value">1,247</span>
                            </div>
                            <div class="metric-item">
                                <span class="metric-label">יציבות מערכת</span>
                                <span id="systemStability" class="metric-value stability-high">גבוהה</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Emotion Analytics -->
                    <div class="insight-card emotion-analytics">
                        <h2>💭 ניתוח רגשות</h2>
                        <div class="emotion-insights">
                            <div class="emotion-distribution">
                                <canvas id="emotionChart" width="300" height="200"></canvas>
                            </div>
                            <div class="emotion-trends">
                                <h3>מגמות רגשיות</h3>
                                <div id="emotionTrends" class="trends-list">
                                    <div class="trend-item positive">
                                        <span class="emotion-name">שמחה</span>
                                        <span class="trend-indicator">↗ +23%</span>
                                    </div>
                                    <div class="trend-item neutral">
                                        <span class="emotion-name">רוגע</span>
                                        <span class="trend-indicator">→ 0%</span>
                                    </div>
                                    <div class="trend-item negative">
                                        <span class="emotion-name">לחץ</span>
                                        <span class="trend-indicator">↘ -15%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Memory Patterns -->
                    <div class="insight-card memory-patterns">
                        <h2>🧮 דפוסי זיכרון</h2>
                        <div class="memory-insights">
                            <div class="memory-layers">
                                <div class="layer-stats">
                                    <div class="layer-item">
                                        <span class="layer-name">זיכרון עבודה</span>
                                        <div class="layer-usage">
                                            <div class="usage-bar" style="width: 78%"></div>
                                            <span class="usage-text">78%</span>
                                        </div>
                                    </div>
                                    <div class="layer-item">
                                        <span class="layer-name">זיכרון קצר מועד</span>
                                        <div class="layer-usage">
                                            <div class="usage-bar" style="width: 65%"></div>
                                            <span class="usage-text">65%</span>
                                        </div>
                                    </div>
                                    <div class="layer-item">
                                        <span class="layer-name">זיכרון אפיזודי</span>
                                        <div class="layer-usage">
                                            <div class="usage-bar" style="width: 42%"></div>
                                            <span class="usage-text">42%</span>
                                        </div>
                                    </div>
                                    <div class="layer-item">
                                        <span class="layer-name">זיכרון סמנטי</span>
                                        <div class="layer-usage">
                                            <div class="usage-bar" style="width: 89%"></div>
                                            <span class="usage-text">89%</span>
                                        </div>
                                    </div>
                                    <div class="layer-item">
                                        <span class="layer-name">זיכרון פרוצדורלי</span>
                                        <div class="layer-usage">
                                            <div class="usage-bar" style="width: 56%"></div>
                                            <span class="usage-text">56%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="memory-recommendations">
                                <h3>המלצות אופטימיזציה</h3>
                                <div class="recommendation-list">
                                    <div class="recommendation">💡 כדאי לנקות זיכרון עבודה - עומס גבוה</div>
                                    <div class="recommendation">⚡ זיכרון סמנטי יעיל - ביצועים מעולים</div>
                                    <div class="recommendation">🔄 המלצה לארגון זיכרון אפיזודי</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Thought Patterns -->
                    <div class="insight-card thought-patterns">
                        <h2>🌊 דפוסי מחשבה</h2>
                        <div class="thought-insights">
                            <div class="thought-flow">
                                <canvas id="thoughtFlowChart" width="400" height="150"></canvas>
                            </div>
                            <div class="cognitive-processes">
                                <h3>תהליכים קוגניטיביים פעילים</h3>
                                <div class="process-grid">
                                    <div class="process-item active">
                                        <span class="process-name">ניתוח</span>
                                        <span class="activity-level">גבוה</span>
                                    </div>
                                    <div class="process-item moderate">
                                        <span class="process-name">סינתזה</span>
                                        <span class="activity-level">בינוני</span>
                                    </div>
                                    <div class="process-item low">
                                        <span class="process-name">יצירתיות</span>
                                        <span class="activity-level">נמוך</span>
                                    </div>
                                    <div class="process-item active">
                                        <span class="process-name">הערכה</span>
                                        <span class="activity-level">גבוה</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Consciousness Levels -->
                    <div class="insight-card consciousness-levels">
                        <h2>🎯 רמות תודעה</h2>
                        <div class="level-insights">
                            <div class="level-timeline">
                                <canvas id="consciousnessTimeline" width="500" height="200"></canvas>
                            </div>
                            <div class="level-statistics">
                                <div class="stat-item">
                                    <span class="stat-label">רמה נוכחית</span>
                                    <span class="stat-value consciousness-conscious">מודעת</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">זמן ברמה נוכחית</span>
                                    <span class="stat-value">14:32</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">מעברים היום</span>
                                    <span class="stat-value">23</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">יציבות</span>
                                    <span class="stat-value stability-good">טובה</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- System Health -->
                    <div class="insight-card system-health">
                        <h2>🏥 בריאות המערכת</h2>
                        <div class="health-dashboard">
                            <div class="health-indicators">
                                <div class="health-item healthy">
                                    <div class="health-icon">💚</div>
                                    <div class="health-info">
                                        <span class="health-name">מנועי רגש</span>
                                        <span class="health-status">תקין</span>
                                    </div>
                                </div>
                                <div class="health-item healthy">
                                    <div class="health-icon">💚</div>
                                    <div class="health-info">
                                        <span class="health-name">מנוע זיכרון</span>
                                        <span class="health-status">תקין</span>
                                    </div>
                                </div>
                                <div class="health-item warning">
                                    <div class="health-icon">💛</div>
                                    <div class="health-info">
                                        <span class="health-name">מנוע מחשבות</span>
                                        <span class="health-status">עומס גבוה</span>
                                    </div>
                                </div>
                                <div class="health-item healthy">
                                    <div class="health-icon">💚</div>
                                    <div class="health-info">
                                        <span class="health-name">מנוע מצבים</span>
                                        <span class="health-status">תקין</span>
                                    </div>
                                </div>
                            </div>
                            <div class="resource-usage">
                                <h3>שימוש במשאבים</h3>
                                <div class="resource-bars">
                                    <div class="resource-item">
                                        <span class="resource-name">מעבד</span>
                                        <div class="resource-bar">
                                            <div class="resource-fill" style="width: 68%"></div>
                                        </div>
                                        <span class="resource-value">68%</span>
                                    </div>
                                    <div class="resource-item">
                                        <span class="resource-name">זיכרון</span>
                                        <div class="resource-bar">
                                            <div class="resource-fill" style="width: 45%"></div>
                                        </div>
                                        <span class="resource-value">45%</span>
                                    </div>
                                    <div class="resource-item">
                                        <span class="resource-name">רשת</span>
                                        <div class="resource-bar">
                                            <div class="resource-fill" style="width: 23%"></div>
                                        </div>
                                        <span class="resource-value">23%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Learning Progress -->
                    <div class="insight-card learning-progress">
                        <h2>📚 התקדמות למידה</h2>
                        <div class="learning-insights">
                            <div class="learning-metrics">
                                <div class="metric-circle">
                                    <canvas id="learningProgress" width="120" height="120"></canvas>
                                    <div class="circle-text">
                                        <span class="circle-value">87%</span>
                                        <span class="circle-label">התקדמות</span>
                                    </div>
                                </div>
                                <div class="learning-stats">
                                    <div class="learning-stat">
                                        <span class="stat-name">דפוסים חדשים שנלמדו</span>
                                        <span class="stat-number">156</span>
                                    </div>
                                    <div class="learning-stat">
                                        <span class="stat-name">שיפורים בביצועים</span>
                                        <span class="stat-number">+12%</span>
                                    </div>
                                    <div class="learning-stat">
                                        <span class="stat-name">התאמות התנהגות</span>
                                        <span class="stat-number">43</span>
                                    </div>
                                </div>
                            </div>
                            <div class="learning-trends">
                                <h3>מגמות למידה</h3>
                                <canvas id="learningTrends" width="300" height="100"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Action Panel -->
                <div class="action-panel">
                    <h2>🎮 פעולות מערכת</h2>
                    <div class="action-buttons">
                        <button id="optimizeSystem" class="action-btn optimize">⚡ אופטימיזציה אוטומטית</button>
                        <button id="clearCache" class="action-btn clear">🧹 נקה מטמון</button>
                        <button id="balanceEmotions" class="action-btn balance">⚖️ איזן רגשות</button>
                        <button id="consolidateMemory" class="action-btn consolidate">💾 גבש זיכרונות</button>
                        <button id="analyzePatterns" class="action-btn analyze">🔍 נתח דפוסים</button>
                        <button id="generateReport" class="action-btn report">📋 צור דוח</button>
                    </div>
                </div>
            </div>
            
            {self._generate_javascript()}
        </body>
        </html>
        """
    
    def _generate_css(self) -> str:
        """Generate CSS for insights panel"""
        return """
        <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
            direction: rtl;
        }
        
        .insights-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .insights-header {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
        }
        
        .insights-header h1 {
            font-size: 2rem;
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0;
        }
        
        .header-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .time-selector, .export-btn, .refresh-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .time-selector:hover, .export-btn:hover, .refresh-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .insights-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .insight-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .insight-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        .insight-card h2 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        
        .performance-metrics {
            display: grid;
            gap: 15px;
        }
        
        .metric-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 10px;
        }
        
        .metric-label {
            font-weight: bold;
            color: #555;
        }
        
        .metric-value {
            font-weight: bold;
            color: #667eea;
        }
        
        .efficiency-bar {
            width: 100px;
            height: 8px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 4px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .efficiency-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        .stability-high {
            color: #4CAF50;
        }
        
        .emotion-insights {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .emotion-distribution {
            text-align: center;
        }
        
        .trends-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .trend-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            border-radius: 8px;
            background: rgba(102, 126, 234, 0.1);
        }
        
        .trend-item.positive {
            border-right: 4px solid #4CAF50;
        }
        
        .trend-item.neutral {
            border-right: 4px solid #FFC107;
        }
        
        .trend-item.negative {
            border-right: 4px solid #F44336;
        }
        
        .memory-layers {
            margin-bottom: 20px;
        }
        
        .layer-stats {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .layer-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .layer-usage {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            max-width: 150px;
        }
        
        .usage-bar {
            height: 8px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            flex-grow: 1;
        }
        
        .usage-text {
            font-weight: bold;
            color: #667eea;
            min-width: 35px;
        }
        
        .recommendation-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .recommendation {
            padding: 10px;
            background: rgba(255, 193, 7, 0.1);
            border-radius: 8px;
            border-right: 4px solid #FFC107;
            font-size: 0.9rem;
        }
        
        .process-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .process-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .process-item.active {
            background: rgba(76, 175, 80, 0.2);
            border: 2px solid #4CAF50;
        }
        
        .process-item.moderate {
            background: rgba(255, 193, 7, 0.2);
            border: 2px solid #FFC107;
        }
        
        .process-item.low {
            background: rgba(244, 67, 54, 0.2);
            border: 2px solid #F44336;
        }
        
        .level-statistics {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 10px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 5px;
        }
        
        .stat-value {
            font-weight: bold;
            font-size: 1.1rem;
            color: #667eea;
        }
        
        .consciousness-conscious {
            color: #4CAF50;
        }
        
        .stability-good {
            color: #4CAF50;
        }
        
        .health-dashboard {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .health-indicators {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .health-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .health-item.healthy {
            background: rgba(76, 175, 80, 0.1);
            border: 1px solid rgba(76, 175, 80, 0.3);
        }
        
        .health-item.warning {
            background: rgba(255, 193, 7, 0.1);
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .health-icon {
            font-size: 1.5rem;
        }
        
        .health-info {
            display: flex;
            flex-direction: column;
        }
        
        .health-name {
            font-weight: bold;
            color: #333;
        }
        
        .health-status {
            font-size: 0.9rem;
            color: #666;
        }
        
        .resource-bars {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .resource-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .resource-name {
            min-width: 60px;
            font-weight: bold;
            color: #555;
        }
        
        .resource-bar {
            flex: 1;
            height: 8px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .resource-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        .resource-value {
            min-width: 40px;
            font-weight: bold;
            color: #667eea;
        }
        
        .learning-insights {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .learning-metrics {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }
        
        .metric-circle {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .circle-text {
            position: absolute;
            text-align: center;
        }
        
        .circle-value {
            display: block;
            font-size: 1.5rem;
            font-weight: bold;
            color: #667eea;
        }
        
        .circle-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        .learning-stats {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .learning-stat {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 8px;
        }
        
        .stat-name {
            color: #555;
        }
        
        .stat-number {
            font-weight: bold;
            color: #667eea;
        }
        
        .action-panel {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .action-panel h2 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .action-btn {
            padding: 15px 20px;
            border: none;
            border-radius: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        
        .action-btn.optimize {
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
        }
        
        .action-btn.clear {
            background: linear-gradient(45deg, #FF9800, #F57C00);
            color: white;
        }
        
        .action-btn.balance {
            background: linear-gradient(45deg, #2196F3, #1976D2);
            color: white;
        }
        
        .action-btn.consolidate {
            background: linear-gradient(45deg, #9C27B0, #7B1FA2);
            color: white;
        }
        
        .action-btn.analyze {
            background: linear-gradient(45deg, #607D8B, #455A64);
            color: white;
        }
        
        .action-btn.report {
            background: linear-gradient(45deg, #795548, #5D4037);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        @media (max-width: 768px) {
            .insights-grid {
                grid-template-columns: 1fr;
            }
            
            .emotion-insights,
            .health-dashboard,
            .learning-insights {
                grid-template-columns: 1fr;
            }
            
            .insights-header {
                flex-direction: column;
                gap: 15px;
            }
            
            .header-controls {
                flex-wrap: wrap;
            }
        }
        
        canvas {
            max-width: 100%;
            height: auto;
        }
        </style>
        """
    
    def _generate_javascript(self) -> str:
        """Generate JavaScript for insights panel"""
        return """
        <script>
        class InsightsPanelController {
            constructor() {
                this.initializeCharts();
                this.bindEvents();
                this.startRealTimeUpdates();
            }
            
            initializeCharts() {
                this.initEmotionChart();
                this.initThoughtFlowChart();
                this.initConsciousnessTimeline();
                this.initLearningProgress();
                this.initLearningTrends();
            }
            
            initEmotionChart() {
                const canvas = document.getElementById('emotionChart');
                const ctx = canvas.getContext('2d');
                
                // Sample emotion data
                const emotions = [
                    { name: 'שמחה', value: 25, color: '#FFD700' },
                    { name: 'רוגע', value: 20, color: '#87CEEB' },
                    { name: 'התלהבות', value: 15, color: '#FF6347' },
                    { name: 'סקרנות', value: 12, color: '#9370DB' },
                    { name: 'אחרים', value: 28, color: '#DDA0DD' }
                ];
                
                this.drawPieChart(ctx, emotions, canvas.width, canvas.height);
            }
            
            drawPieChart(ctx, data, width, height) {
                const centerX = width / 2;
                const centerY = height / 2;
                const radius = Math.min(width, height) / 2 - 20;
                
                let currentAngle = 0;
                const total = data.reduce((sum, item) => sum + item.value, 0);
                
                data.forEach(item => {
                    const sliceAngle = (item.value / total) * 2 * Math.PI;
                    
                    ctx.beginPath();
                    ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
                    ctx.lineTo(centerX, centerY);
                    ctx.fillStyle = item.color;
                    ctx.fill();
                    
                    // Add labels
                    const labelAngle = currentAngle + sliceAngle / 2;
                    const labelX = centerX + Math.cos(labelAngle) * (radius * 0.7);
                    const labelY = centerY + Math.sin(labelAngle) * (radius * 0.7);
                    
                    ctx.fillStyle = '#333';
                    ctx.font = '12px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(item.name, labelX, labelY);
                    
                    currentAngle += sliceAngle;
                });
            }
            
            initThoughtFlowChart() {
                const canvas = document.getElementById('thoughtFlowChart');
                const ctx = canvas.getContext('2d');
                
                // Draw thought flow visualization
                this.drawThoughtFlow(ctx, canvas.width, canvas.height);
            }
            
            drawThoughtFlow(ctx, width, height) {
                const gradient = ctx.createLinearGradient(0, 0, width, 0);
                gradient.addColorStop(0, '#667eea');
                gradient.addColorStop(1, '#764ba2');
                
                ctx.fillStyle = gradient;
                
                // Draw flowing wave pattern
                ctx.beginPath();
                for (let x = 0; x < width; x++) {
                    const y = height/2 + Math.sin(x * 0.02 + Date.now() * 0.001) * 20;
                    if (x === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                }
                ctx.lineWidth = 3;
                ctx.strokeStyle = gradient;
                ctx.stroke();
                
                // Add thought bubbles
                const bubbles = [
                    { x: 50, y: 40, size: 8 },
                    { x: 150, y: 60, size: 12 },
                    { x: 250, y: 30, size: 10 },
                    { x: 350, y: 50, size: 14 }
                ];
                
                bubbles.forEach(bubble => {
                    ctx.beginPath();
                    ctx.arc(bubble.x, bubble.y, bubble.size, 0, 2 * Math.PI);
                    ctx.fillStyle = 'rgba(102, 126, 234, 0.6)';
                    ctx.fill();
                });
            }
            
            initConsciousnessTimeline() {
                const canvas = document.getElementById('consciousnessTimeline');
                const ctx = canvas.getContext('2d');
                
                this.drawConsciousnessTimeline(ctx, canvas.width, canvas.height);
            }
            
            drawConsciousnessTimeline(ctx, width, height) {
                const levels = [
                    { name: 'לא מודע', color: '#B0BEC5', value: 0.2 },
                    { name: 'תת מודע', color: '#90A4AE', value: 0.3 },
                    { name: 'טרום מודע', color: '#78909C', value: 0.4 },
                    { name: 'מודע', color: '#607D8B', value: 0.8 },
                    { name: 'על מודע', color: '#546E7A', value: 0.6 },
                    { name: 'טרנסצנדנטי', color: '#455A64', value: 0.3 }
                ];
                
                const barWidth = width / levels.length;
                
                levels.forEach((level, index) => {
                    const x = index * barWidth;
                    const barHeight = level.value * height;
                    const y = height - barHeight;
                    
                    ctx.fillStyle = level.color;
                    ctx.fillRect(x, y, barWidth - 2, barHeight);
                    
                    // Add labels
                    ctx.fillStyle = '#333';
                    ctx.font = '10px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(level.name, x + barWidth/2, height - 5);
                });
            }
            
            initLearningProgress() {
                const canvas = document.getElementById('learningProgress');
                const ctx = canvas.getContext('2d');
                
                this.drawProgressCircle(ctx, 87, canvas.width, canvas.height);
            }
            
            drawProgressCircle(ctx, progress, width, height) {
                const centerX = width / 2;
                const centerY = height / 2;
                const radius = Math.min(width, height) / 2 - 10;
                
                // Background circle
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                ctx.strokeStyle = '#E0E0E0';
                ctx.lineWidth = 8;
                ctx.stroke();
                
                // Progress arc
                const progressAngle = (progress / 100) * 2 * Math.PI;
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, -Math.PI/2, -Math.PI/2 + progressAngle);
                ctx.strokeStyle = '#667eea';
                ctx.lineWidth = 8;
                ctx.lineCap = 'round';
                ctx.stroke();
            }
            
            initLearningTrends() {
                const canvas = document.getElementById('learningTrends');
                const ctx = canvas.getContext('2d');
                
                this.drawLearningTrends(ctx, canvas.width, canvas.height);
            }
            
            drawLearningTrends(ctx, width, height) {
                const dataPoints = [20, 35, 28, 45, 52, 48, 65, 70, 68, 75];
                const pointSpacing = width / (dataPoints.length - 1);
                
                // Draw trend line
                ctx.beginPath();
                dataPoints.forEach((point, index) => {
                    const x = index * pointSpacing;
                    const y = height - (point / 100) * height;
                    
                    if (index === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                });
                
                ctx.strokeStyle = '#667eea';
                ctx.lineWidth = 3;
                ctx.stroke();
                
                // Draw points
                dataPoints.forEach((point, index) => {
                    const x = index * pointSpacing;
                    const y = height - (point / 100) * height;
                    
                    ctx.beginPath();
                    ctx.arc(x, y, 4, 0, 2 * Math.PI);
                    ctx.fillStyle = '#764ba2';
                    ctx.fill();
                });
            }
            
            bindEvents() {
                // Time range selector
                document.getElementById('timeRange').addEventListener('change', (e) => {
                    this.updateTimeRange(e.target.value);
                });
                
                // Export data
                document.getElementById('exportData').addEventListener('click', () => {
                    this.exportInsightsData();
                });
                
                // Refresh insights
                document.getElementById('refreshInsights').addEventListener('click', () => {
                    this.refreshAllInsights();
                });
                
                // Action buttons
                document.getElementById('optimizeSystem').addEventListener('click', () => {
                    this.optimizeSystem();
                });
                
                document.getElementById('clearCache').addEventListener('click', () => {
                    this.clearSystemCache();
                });
                
                document.getElementById('balanceEmotions').addEventListener('click', () => {
                    this.balanceEmotions();
                });
                
                document.getElementById('consolidateMemory').addEventListener('click', () => {
                    this.consolidateMemory();
                });
                
                document.getElementById('analyzePatterns').addEventListener('click', () => {
                    this.analyzePatterns();
                });
                
                document.getElementById('generateReport').addEventListener('click', () => {
                    this.generateReport();
                });
            }
            
            updateTimeRange(range) {
                console.log(`עדכון טווח זמן: ${range}`);
                // Update all charts and data based on time range
                this.refreshAllInsights();
            }
            
            exportInsightsData() {
                const data = {
                    timestamp: new Date().toISOString(),
                    performance: {
                        efficiency: document.getElementById('overallEfficiency').textContent,
                        responseTime: document.getElementById('avgResponseTime').textContent,
                        events: document.getElementById('consciousnessEvents').textContent,
                        stability: document.getElementById('systemStability').textContent
                    },
                    // Add more data...
                };
                
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `consciousness_insights_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
                URL.revokeObjectURL(url);
                
                this.showNotification('נתוני התובנות יוצאו בהצלחה', 'success');
            }
            
            refreshAllInsights() {
                this.showNotification('מרענן תובנות...', 'info');
                
                // Simulate data refresh
                setTimeout(() => {
                    this.initializeCharts();
                    this.updateMetrics();
                    this.showNotification('התובנות עודכנו בהצלחה', 'success');
                }, 1000);
            }
            
            updateMetrics() {
                // Update performance metrics
                const efficiency = Math.floor(Math.random() * 20) + 80;
                document.getElementById('overallEfficiency').textContent = `${efficiency}%`;
                document.querySelector('.efficiency-fill').style.width = `${efficiency}%`;
                
                const responseTime = Math.floor(Math.random() * 200) + 250;
                document.getElementById('avgResponseTime').textContent = `${responseTime}ms`;
                
                const events = Math.floor(Math.random() * 500) + 1000;
                document.getElementById('consciousnessEvents').textContent = events.toLocaleString();
            }
            
            optimizeSystem() {
                this.showNotification('מתחיל אופטימיזציה אוטומטית...', 'info');
                
                // Simulate optimization process
                setTimeout(() => {
                    this.showNotification('אופטימיזציה הושלמה בהצלחה', 'success');
                    this.updateMetrics();
                }, 2000);
            }
            
            clearSystemCache() {
                this.showNotification('מנקה מטמון המערכת...', 'info');
                
                setTimeout(() => {
                    this.showNotification('מטמון נוקה בהצלחה', 'success');
                }, 1000);
            }
            
            balanceEmotions() {
                this.showNotification('מאזן רגשות...', 'info');
                
                setTimeout(() => {
                    this.initEmotionChart();
                    this.showNotification('איזון רגשות הושלם', 'success');
                }, 1500);
            }
            
            consolidateMemory() {
                this.showNotification('מגבש זיכרונות...', 'info');
                
                setTimeout(() => {
                    this.showNotification('גיבוש זיכרונות הושלם', 'success');
                }, 2000);
            }
            
            analyzePatterns() {
                this.showNotification('מנתח דפוסים...', 'info');
                
                setTimeout(() => {
                    this.showNotification('ניתוח דפוסים הושלם', 'success');
                }, 1500);
            }
            
            generateReport() {
                this.showNotification('יוצר דוח מפורט...', 'info');
                
                const report = this.createDetailedReport();
                const blob = new Blob([report], { type: 'text/html' });
                const url = URL.createObjectURL(blob);
                window.open(url, '_blank');
                
                this.showNotification('דוח נוצר בהצלחה', 'success');
            }
            
            createDetailedReport() {
                return `
                <!DOCTYPE html>
                <html dir="rtl" lang="he">
                <head>
                    <meta charset="UTF-8">
                    <title>דוח תובנות מערכת התודעה</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        h1 { color: #667eea; }
                        .metric { margin: 10px 0; padding: 10px; background: #f5f5f5; border-radius: 5px; }
                    </style>
                </head>
                <body>
                    <h1>דוח תובנות מערכת התודעה</h1>
                    <p>תאריך: ${new Date().toLocaleDateString('he-IL')}</p>
                    <div class="metric">
                        <strong>יעילות כללית:</strong> ${document.getElementById('overallEfficiency').textContent}
                    </div>
                    <div class="metric">
                        <strong>זמן תגובה ממוצע:</strong> ${document.getElementById('avgResponseTime').textContent}
                    </div>
                    <div class="metric">
                        <strong>אירועי תודעה:</strong> ${document.getElementById('consciousnessEvents').textContent}
                    </div>
                    <div class="metric">
                        <strong>יציבות מערכת:</strong> ${document.getElementById('systemStability').textContent}
                    </div>
                </body>
                </html>
                `;
            }
            
            showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `notification ${type}`;
                notification.textContent = message;
                
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 10px;
                    color: white;
                    font-weight: bold;
                    z-index: 1000;
                    transition: all 0.3s ease;
                    ${type === 'success' ? 'background: #4CAF50;' : ''}
                    ${type === 'info' ? 'background: #2196F3;' : ''}
                    ${type === 'warning' ? 'background: #FF9800;' : ''}
                    ${type === 'error' ? 'background: #F44336;' : ''}
                `;
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.style.opacity = '0';
                    setTimeout(() => notification.remove(), 300);
                }, 3000);
            }
            
            startRealTimeUpdates() {
                // Update metrics every 30 seconds
                setInterval(() => {
                    this.updateMetrics();
                }, 30000);
                
                // Update charts every 5 minutes
                setInterval(() => {
                    this.initializeCharts();
                }, 300000);
            }
        }
        
        // Initialize when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            new InsightsPanelController();
        });
        </script>
        """

    def analyze_performance(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze system performance metrics"""
        try:
            analysis = {
                'efficiency': self._calculate_efficiency(data),
                'response_time': self._analyze_response_times(data),
                'stability': self._assess_stability(data),
                'recommendations': self._generate_recommendations(data)
            }
            return analysis
        except Exception as e:
            return {'error': str(e), 'analysis': None}

    def _calculate_efficiency(self, data: Dict[str, Any]) -> float:
        """Calculate overall system efficiency"""
        if not data.get('metrics'):
            return 0.0
        
        metrics = data['metrics']
        success_rate = metrics.get('success_rate', 0)
        response_time = metrics.get('avg_response_time', 1000)
        resource_usage = metrics.get('resource_usage', 100)
        
        # Efficiency calculation
        efficiency = (success_rate * 0.4 + 
                     (1000 / max(response_time, 1)) * 0.3 + 
                     (100 - resource_usage) * 0.3)
        
        return min(max(efficiency, 0), 100)

    def _analyze_response_times(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze response time patterns"""
        response_times = data.get('response_times', [])
        if not response_times:
            return {'avg': 0, 'median': 0, 'p95': 0}
        
        return {
            'avg': statistics.mean(response_times),
            'median': statistics.median(response_times),
            'p95': sorted(response_times)[int(len(response_times) * 0.95)]
        }

    def _assess_stability(self, data: Dict[str, Any]) -> str:
        """Assess system stability"""
        error_rate = data.get('error_rate', 0)
        uptime = data.get('uptime', 0)
        
        if error_rate < 0.01 and uptime > 0.99:
            return 'גבוהה'
        elif error_rate < 0.05 and uptime > 0.95:
            return 'טובה'
        elif error_rate < 0.1 and uptime > 0.9:
            return 'בינונית'
        else:
            return 'נמוכה'

    def _generate_recommendations(self, data: Dict[str, Any]) -> List[str]:
        """Generate optimization recommendations"""
        recommendations = []
        
        if data.get('memory_usage', 0) > 80:
            recommendations.append('כדאי לנקות זיכרון - עומס גבוה')
        
        if data.get('response_time', 0) > 500:
            recommendations.append('יש לאמץ אופטימיזציה לזמני תגובה')
        
        if data.get('error_rate', 0) > 0.05:
            recommendations.append('נדרש שיפור בטיפול בשגיאות')
        
        return recommendations

    def export_insights(self, format_type: str = 'json') -> str:
        """Export insights data"""
        try:
            insights_data = {
                'timestamp': datetime.now().isoformat(),
                'performance': self.performance_data,
                'patterns': self.pattern_cache,
                'recommendations': []
            }
            
            if format_type == 'json':
                return json.dumps(insights_data, ensure_ascii=False, indent=2)
            elif format_type == 'csv':
                return self._to_csv(insights_data)
            else:
                return str(insights_data)
                
        except Exception as e:
            return f"Error exporting insights: {str(e)}"

    def _to_csv(self, data: Dict[str, Any]) -> str:
        """Convert insights data to CSV format"""
        csv_lines = ['metric,value,timestamp']
        timestamp = data.get('timestamp', datetime.now().isoformat())
        
        for key, value in data.get('performance', {}).items():
            csv_lines.append(f"{key},{value},{timestamp}")
        
        return '\n'.join(csv_lines)