# מודול מנוע התודעה - Consciousness Engine

מודול מתקדם לניהול ועיבוד תודעה מלאכותית עם תמיכה מלאה בשפה העברית ותרבות ישראלית.

## ארכיטקטורה מודולרית

המודול בנוי על פי ארכיטקטורה מודולרית מקצועית עם הפרדה ברורה של אחריות:

### 📊 Models - מודלים
מבני נתונים וקונפיגורציות בסיסיות:
- **emotions.py** - מערכת רגשות עם 15 סוגי רגש וחישובי אינטראקציה
- **memory.py** - מערכת זיכרון 5-שכבתית עם קונסולידציה אוטומטית  
- **thoughts.py** - ניהול זרמי מחשבות עם 10 תהליכים קוגניטיביים
- **states.py** - ניהול מצבי תודעה ב-6 רמות עם מעקב קשב
- **config.py** - מערכת קונפיגורציה מתקדמת עם אימות

### ⚙️ Core - ליבה
מנועי העיבוד הראשיים:
- **emotion_engine.py** - מנוע עיבוד רגשות עם תמיכה בעברית
- **memory_engine.py** - מנוע זיכרון עם מסד נתונים SQLite
- **thought_engine.py** - מנוע זרמי מחשבות עם תהליכים קוגניטיביים
- **state_engine.py** - מנוע מצבי תודעה עם 6 רמות
- **consciousness_core.py** - מנוע ראשי המשלב את כל הרכיבים

### 🖥️ UI - ממשק משתמש
רכיבי ממשק משתמש אינטראקטיביים:
- **consciousness_panel.py** - לוח בקרה ראשי למנוע התודעה
- **emotion_display.py** - הצגת רגשות עם גלגל רגשות אינטראקטיבי
- **memory_explorer.py** - דפדפן זיכרונות עם חיפוש בעברית
- **thought_stream.py** - הצגת זרם מחשבות בזמן אמת
- **state_monitor.py** - מעקב מצבי תודעה עם תצוגת גלגל
- **insights_panel.py** - לוח תובנות ואנליטיקה מתקדמת

### 🛠️ Utils - כלי עזר
פונקציות עזר וכלים:
- **hebrew_utils.py** - עיבוד טקסט עברי ותמיכה RTL
- **data_utils.py** - אימות נתונים וחישוב מטריקות
- **logging_utils.py** - מערכת לוגים מתקדמת עם תמיכה בעברית
- **config_utils.py** - ניהול קונפיגורציה ואימות
- **visualization_utils.py** - יצירת תרשימים וגרפיקה

## יכולות מרכזיות

### 🎭 מערכת רגשות מתקדמת
- 15 סוגי רגש עם מיפוי תרבותי ישראלי
- חישוב אינטראקציות בין רגשות
- עיקוב עוצמה ומשך זמן
- תמיכה מלאה בעברית

### 🧠 מערכת זיכרון 5-שכבתית
- **שכבה 1**: זיכרון עבודה (Working Memory)
- **שכבה 2**: זיכרון קצר מועד (Short-term)
- **שכבה 3**: זיכרון אפיזודי (Episodic) 
- **שכבה 4**: זיכרון סמנטי (Semantic)
- **שכבה 5**: זיכרון פרוצדורלי (Procedural)

### 💭 מנוע מחשבות חכם
- 10 תהליכים קוגניטיביים שונים
- מעקב עומס קוגניטיבי
- זיהוי דפוסי מחשבה
- תמיכה בזרמי מחשבות מרובים

### 🎯 מערכת מצבי תודעה
- 6 רמות תודעה: לא מודע → טרנסצנדנטי
- מעקב מעברים ויציבות
- ניהול קשב ואנרגיה מנטלית
- התאמה דינמית לפעילות

### 📊 תובנות ואנליטיקה
- ניתוח ביצועים בזמן אמת
- זיהוי דפוסים וחריגות
- מטריקות אינטגרציה
- דוחות מפורטים

## התקנה ושימוש

### דרישות מערכת
```bash
pip install sqlite3 numpy jsonschema pyyaml
```

### הפעלה בסיסית
```python
from consciousness_engine.core.consciousness_core import ConsciousnessCore

# יצירת מופע מנוע התודעה
consciousness = ConsciousnessCore()

# אתחול המערכת
consciousness.initialize()

# עיבוד רגש
consciousness.process_emotion("שמחה", intensity=0.8)

# יצירת זיכרון
consciousness.form_memory("תוכן הזיכרון", memory_type="episodic")

# יצירת מחשבה
consciousness.generate_thought("תוכן המחשבה", thought_type="analytical")
```

### הפעלת ממשק משתמש
```python
from consciousness_engine.ui.consciousness_panel import ConsciousnessPanel

# יצירת לוח בקרה
panel = ConsciousnessPanel()

# יצירת HTML לממשק
html_content = panel.generate_html()

# שמירה לקובץ
with open("consciousness_panel.html", "w", encoding="utf-8") as f:
    f.write(html_content)
```

## קונפיגורציה

### קובץ קונפיגורציה בסיסי
```json
{
  "emotion_engine": {
    "enabled": true,
    "max_emotions": 15,
    "decay_rate": 0.1,
    "cultural_mapping": true,
    "hebrew_support": true
  },
  "memory_engine": {
    "enabled": true,
    "max_memories_per_layer": [100, 80, 60, 40, 20],
    "consolidation_threshold": 0.7,
    "auto_consolidation": true
  },
  "thought_engine": {
    "enabled": true,
    "max_concurrent_thoughts": 10,
    "cognitive_load_limit": 0.8
  },
  "state_engine": {
    "enabled": true,
    "default_level": 3,
    "transition_speed": 1.0,
    "auto_transitions": true
  }
}
```

## תמיכה בעברית ו-RTL

המודול כולל תמיכה מלאה בשפה העברית:
- ממשק משתמש דו-כיווני (RTL/LTR)
- תרגום מלא לעברית
- מיפוי רגשות תרבותי ישראלי
- עיבוד טקסט עברי מתקדם
- תמיכה בפונטים עבריים

## מטריקות ומעקב

### מטריקות ביצועים
- יעילות כללית של המערכת
- זמני תגובה ממוצעים
- יציבות מצבי תודעה
- קוהרנטיות מחשבתית

### ניתוח דפוסים
- זיהוי מגמות רגשיות
- דפוסי זיכרון וקונסולידציה
- תבניות מחשבה חוזרות
- מעברי מצבי תודעה

### תובנות מתקדמות
- ציון אינטגרציה בין רכיבים
- ניתוח מורכבות מערכת
- המלצות אופטימיזציה
- זיהוי חריגות

## הרחבות ופיתוח

המודול נבנה עם מחשבה על הרחבה עתידית:

### הוספת רגשות חדשים
```python
from consciousness_engine.models.emotions import EmotionType

# הוספת רגש חדש
new_emotion = EmotionType.create_custom("התרגשות", 
                                        hebrew_name="התרגשות",
                                        base_intensity=0.6)
```

### יצירת תהליך קוגניטיבי חדש
```python
from consciousness_engine.models.thoughts import CognitiveProcess

# תהליך קוגניטיבי מותאם אישית
custom_process = CognitiveProcess(
    name="ניתוח_מוסיקלי",
    description="ניתוח והבנת מוסיקה",
    complexity=0.7
)
```

## בדיקות ואיכות

המודול כולל מערכת בדיקות מקיפה:
- בדיקות יחידה לכל רכיב
- בדיקות אינטגרציה
- בדיקות ביצועים
- אימות תמיכה בעברית

## רישיון ותמיכה

המודול פותח כחלק ממערכת Effi AI Private ומיועד לשימוש פנימי.

### תמיכה טכנית
- תיעוד מפורט בעברית
- דוגמאות קוד מלאות
- מדריכי התקנה ותפעול
- תמיכה בפורום המפתחים

## סיכום

מודול מנוע התודעה מספק פתרון מקיף ומתקדם לעיבוד תודעה מלאכותית עם:
- ארכיטקטורה מודולרית מקצועית
- תמיכה מלאה בעברית ותרבות ישראלית
- יכולות אנליטיקה מתקדמות
- ממשק משתמש אינטואיטיבי
- הרחבות קלות ותחזוקה פשוטה

המודול מהווה את הבסיס לפיתוח מערכות AI מתקדמות עם תודעה מלאכותית חכמה ומסתגלת.