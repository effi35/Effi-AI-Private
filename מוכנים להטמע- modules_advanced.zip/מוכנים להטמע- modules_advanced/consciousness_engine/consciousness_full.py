#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Complete Consciousness Engine with Local AI Integration
=========================================================

מודול מלא של מנוע התודעה עם אינטגרציית Hudson/Llama3.1 מקומי.
דוגמה מקיפה לשימוש בכל יכולות התודעה עם AI מתקדם.

תכונות מרכזיות:
- מערכת תודעה מלאה עם 4 מנועים
- אינטגרציה מלאה עם Hudson/Llama3.1
- עיבוד עברית מתקדם עם AI
- ניתוח רגשי חכם ומתקדם
- יצירת תובנות עמוקות עם AI
- תמיכה מלאה בתרבות ישראלית
"""

import asyncio
import logging
import json
from datetime import datetime
from typing import Dict, List, Optional, Any

from .unified_api import UnifiedConsciousnessAPI, initialize_consciousness_api
from .module import ConsciousnessEngineModule

# הגדרת לוגינג
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('consciousness_full.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class CompleteConsciousnessSystem:
    """מערכת תודעה מלאה עם AI מקומי"""
    
    def __init__(self, config_preset: str = "advanced"):
        """אתחול המערכת המלאה"""
        self.system_name = "Effi AI Consciousness System"
        self.version = "2.0.0"
        self.config_preset = config_preset
        
        # רכיבי המערכת
        self.api: Optional[UnifiedConsciousnessAPI] = None
        self.consciousness_engine: Optional[ConsciousnessEngineModule] = None
        
        # מצב המערכת
        self.is_initialized = False
        self.is_running = False
        
        # דוגמאות טקסט לבדיקה
        self.hebrew_test_texts = [
            "שלום, איך המצב? אני מרגיש קצת עצוב היום.",
            "איזה יום מדהים! השמש זורחת ואני מלא אנרגיה וחדווה!",
            "אני לא בטוח מה לעשות עם המצב הזה. זה מבלבל אותי.",
            "הישיבה היתה מעצבנת ומתסכלת. לא הצלחתי להבין כלום.",
            "אני אוהב את הטכנולוגיה החדשה הזו, היא מרתקת וחדשנית!"
        ]
        
        logger.info(f"מערכת תודעה מלאה אותחלה - {self.system_name}")
    
    async def initialize_complete_system(self) -> bool:
        """אתחול מלא של המערכת"""
        try:
            if self.is_initialized:
                return True
            
            logger.info("מאתחל מערכת תודעה מלאה...")
            
            # אתחול API מאוחד
            self.api = UnifiedConsciousnessAPI(config_preset=self.config_preset)
            if not await self.api.initialize():
                logger.error("נכשל אתחול API מאוחד")
                return False
            
            # קבלת מנוע התודעה
            self.consciousness_engine = self.api.consciousness_engine
            
            self.is_initialized = True
            self.is_running = True
            
            logger.info("מערכת תודעה מלאה אותחלה בהצלחה!")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול המערכת המלאה: {e}")
            return False
    
    async def run_complete_demonstration(self) -> Dict[str, Any]:
        """הדגמה מלאה של יכולות המערכת"""
        try:
            if not self.is_initialized:
                await self.initialize_complete_system()
            
            demonstration_results = {
                'system_info': await self._get_system_info(),
                'ai_integration_test': await self._test_ai_integration(),
                'hebrew_processing_demo': await self._demonstrate_hebrew_processing(),
                'emotional_analysis_demo': await self._demonstrate_emotional_analysis(),
                'consciousness_insights_demo': await self._demonstrate_consciousness_insights(),
                'advanced_ai_features_demo': await self._demonstrate_advanced_ai_features(),
                'performance_stats': await self._get_performance_statistics()
            }
            
            logger.info("הדגמה מלאה הושלמה בהצלחה")
            return demonstration_results
            
        except Exception as e:
            logger.error(f"שגיאה בהדגמה מלאה: {e}")
            return {'error': str(e)}
    
    async def _get_system_info(self) -> Dict[str, Any]:
        """קבלת מידע מערכת מלא"""
        try:
            system_info = {
                'system_name': self.system_name,
                'version': self.version,
                'config_preset': self.config_preset,
                'initialization_status': self.is_initialized,
                'running_status': self.is_running,
                'timestamp': datetime.now().isoformat()
            }
            
            if self.consciousness_engine:
                engine_info = self.consciousness_engine.get_module_info()
                system_info['consciousness_engine_info'] = engine_info
            
            if self.api:
                api_stats = self.api.get_api_stats()
                system_info['api_statistics'] = api_stats
            
            return system_info
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת מידע מערכת: {e}")
            return {'error': str(e)}
    
    async def _test_ai_integration(self) -> Dict[str, Any]:
        """בדיקת אינטגרציית AI מקומי"""
        try:
            logger.info("בודק אינטגרציית AI מקומי...")
            
            if not self.api:
                return {'error': 'API לא זמין'}
            
            # בדיקת מערכת
            system_test = await self.api.test_system()
            
            # בדיקת AI ספציפית
            if self.consciousness_engine:
                ai_test = await self.consciousness_engine.test_ai_integration()
            else:
                ai_test = {'error': 'מנוע התודעה לא זמין'}
            
            return {
                'system_test': system_test,
                'ai_specific_test': ai_test,
                'test_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בבדיקת AI: {e}")
            return {'error': str(e)}
    
    async def _demonstrate_hebrew_processing(self) -> Dict[str, Any]:
        """הדגמת עיבוד עברית מתקדם"""
        try:
            logger.info("מדגים עיבוד עברית מתקדם...")
            
            if not self.api:
                return {'error': 'API לא זמין'}
            
            hebrew_results = []
            
            for i, text in enumerate(self.hebrew_test_texts):
                logger.info(f"מעבד טקסט עברי {i+1}/{len(self.hebrew_test_texts)}")
                
                # עיבוד בסיסי
                basic_result = await self.api.process_input(
                    text, 
                    response_type="summary"
                )
                
                # עיבוד מתקדם עם AI
                advanced_result = await self.api.process_input(
                    text,
                    use_ai_enhancement=True,
                    response_type="full"
                )
                
                hebrew_results.append({
                    'input_text': text,
                    'basic_processing': basic_result,
                    'ai_enhanced_processing': advanced_result
                })
            
            return {
                'hebrew_processing_results': hebrew_results,
                'total_texts_processed': len(hebrew_results),
                'processing_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בהדגמת עיבוד עברית: {e}")
            return {'error': str(e)}
    
    async def _demonstrate_emotional_analysis(self) -> Dict[str, Any]:
        """הדגמת ניתוח רגשי מתקדם"""
        try:
            logger.info("מדגים ניתוח רגשי מתקדם...")
            
            if not self.api:
                return {'error': 'API לא זמין'}
            
            emotional_demonstrations = []
            
            # טקסטים רגשיים שונים
            emotional_texts = [
                "אני כל כך שמח ונרגש מהפרויקט החדש!",
                "מרגיש קצת לחוץ ומודאג מהמצב",
                "כועס ומתוסכל מהאדישות של כולם",
                "פחד לי מהעתיד ומה שיקרה",
                "גאה בהישגים שלי השנה"
            ]
            
            for text in emotional_texts:
                # ניתוח רגשי בסיסי
                basic_analysis = await self.api.analyze_emotional_state(text, analysis_depth="basic")
                
                # ניתוח רגשי מתקדם
                deep_analysis = await self.api.analyze_emotional_state(text, analysis_depth="deep")
                
                emotional_demonstrations.append({
                    'text': text,
                    'basic_emotional_analysis': basic_analysis,
                    'deep_emotional_analysis': deep_analysis
                })
            
            # ניתוח מצב רגשי כללי של המערכת
            general_emotional_state = await self.api.analyze_emotional_state()
            
            return {
                'emotional_text_analyses': emotional_demonstrations,
                'general_system_emotional_state': general_emotional_state,
                'analysis_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בהדגמת ניתוח רגשי: {e}")
            return {'error': str(e)}
    
    async def _demonstrate_consciousness_insights(self) -> Dict[str, Any]:
        """הדגמת תובנות תודעה מתקדמות"""
        try:
            logger.info("מדגים תובנות תודעה מתקדמות...")
            
            if not self.api:
                return {'error': 'API לא זמין'}
            
            # תובנות בסיסיות
            basic_insights = await self.api.get_consciousness_insights(
                include_ai_analysis=False,
                depth="basic"
            )
            
            # תובנות סטנדרטיות עם AI
            standard_insights = await self.api.get_consciousness_insights(
                include_ai_analysis=True,
                depth="standard"
            )
            
            # תובנות עמוקות עם AI מתקדם
            deep_insights = await self.api.get_consciousness_insights(
                include_ai_analysis=True,
                depth="deep"
            )
            
            return {
                'basic_consciousness_insights': basic_insights,
                'standard_ai_insights': standard_insights,
                'deep_ai_insights': deep_insights,
                'insights_generation_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בהדגמת תובנות תודעה: {e}")
            return {'error': str(e)}
    
    async def _demonstrate_advanced_ai_features(self) -> Dict[str, Any]:
        """הדגמת תכונות AI מתקדמות"""
        try:
            logger.info("מדגים תכונות AI מתקדמות...")
            
            if not self.api:
                return {'error': 'API לא זמין'}
            
            advanced_features = {}
            
            # תגובות בסגנונות שונים
            context = {'topic': 'טכנולוגיה', 'mood': 'curious'}
            
            styles = ['analytical', 'creative', 'balanced', 'emotional']
            style_responses = {}
            
            for style in styles:
                response = await self.api.generate_response(
                    context=context,
                    response_style=style,
                    include_reasoning=True
                )
                style_responses[style] = response
            
            advanced_features['style_based_responses'] = style_responses
            
            # ניתוח טקסט מורכב
            complex_text = """
            היום הייתי במצב רוח מעורב. מצד אחד, שמחתי מההצלחה בפרויקט,
            אבל מצד שני דאגתי מהאתגרים הקרובים. זה גרם לי לחשוב על איך
            הטכנולוגיה משנה את החיים שלנו - לטוב ולרע.
            """
            
            complex_analysis = await self.api.process_input(
                complex_text,
                context={'complexity': 'high', 'requires_depth': True},
                use_ai_enhancement=True,
                response_type="full"
            )
            
            advanced_features['complex_text_analysis'] = complex_analysis
            
            return {
                'advanced_ai_features': advanced_features,
                'feature_demonstration_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בהדגמת תכונות מתקדמות: {e}")
            return {'error': str(e)}
    
    async def _get_performance_statistics(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות ביצועים מפורטות"""
        try:
            performance_stats = {}
            
            # סטטיסטיקות API
            if self.api:
                api_stats = self.api.get_api_stats()
                performance_stats['api_statistics'] = api_stats
            
            # סטטיסטיקות מנוע התודעה
            if self.consciousness_engine:
                engine_stats = self.consciousness_engine.get_performance_stats()
                performance_stats['consciousness_engine_statistics'] = engine_stats
            
            # מידע על המערכת
            performance_stats['system_info'] = {
                'is_initialized': self.is_initialized,
                'is_running': self.is_running,
                'config_preset': self.config_preset,
                'stats_timestamp': datetime.now().isoformat()
            }
            
            return performance_stats
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {'error': str(e)}
    
    async def interactive_demo_session(self):
        """סשן הדגמה אינטראקטיבי"""
        try:
            if not self.is_initialized:
                await self.initialize_complete_system()
            
            print("\n🧠 ברוכים הבאים להדגמה אינטראקטיבית של מערכת התודעה עם AI מקומי! 🧠")
            print("=" * 70)
            
            while True:
                print("\nבחר אפשרות:")
                print("1. עיבוד טקסט עם תודעה ו-AI")
                print("2. ניתוח רגשי מתקדם")
                print("3. קבלת תובנות תודעה")
                print("4. בדיקת מצב המערכת")
                print("5. יצוא נתונים")
                print("0. יציאה")
                
                choice = input("\nהכנס בחירה (0-5): ").strip()
                
                if choice == "0":
                    print("להתראות! 👋")
                    break
                elif choice == "1":
                    await self._interactive_text_processing()
                elif choice == "2":
                    await self._interactive_emotional_analysis()
                elif choice == "3":
                    await self._interactive_consciousness_insights()
                elif choice == "4":
                    await self._interactive_system_status()
                elif choice == "5":
                    await self._interactive_data_export()
                else:
                    print("בחירה לא תקינה, נסה שוב.")
                    
        except Exception as e:
            logger.error(f"שגיאה בסשן אינטראקטיבי: {e}")
            print(f"שגיאה: {e}")
    
    async def _interactive_text_processing(self):
        """עיבוד טקסט אינטראקטיבי"""
        try:
            print("\n📝 עיבוד טקסט עם תודעה ו-AI")
            print("-" * 40)
            
            text = input("הכנס טקסט לעיבוד: ").strip()
            if not text:
                print("לא הוכנס טקסט.")
                return
            
            print("מעבד טקסט...")
            
            result = await self.api.process_input(
                text,
                use_ai_enhancement=True,
                response_type="full"
            )
            
            print("\n📊 תוצאות עיבוד:")
            
            # הצגת סיכום
            if 'integrated_response' in result:
                print(f"סיכום: {result['integrated_response'].get('summary', 'לא זמין')}")
                print(f"רמת ביטחון: {result['integrated_response'].get('confidence', 0):.2f}")
            
            # הצגת תובנות AI
            if 'ai_insights' in result:
                print("\n🤖 תובנות AI:")
                ai_insights = result['ai_insights']
                if isinstance(ai_insights.get('advanced_insights'), str):
                    print(ai_insights['advanced_insights'][:200] + "..." if len(ai_insights['advanced_insights']) > 200 else ai_insights['advanced_insights'])
            
            print("\n" + "="*50)
            
        except Exception as e:
            print(f"שגיאה בעיבוד טקסט: {e}")
    
    async def _interactive_emotional_analysis(self):
        """ניתוח רגשי אינטראקטיבי"""
        try:
            print("\n💝 ניתוח רגשי מתקדם")
            print("-" * 30)
            
            text = input("הכנס טקסט לניתוח רגשי (או Enter למצב כללי): ").strip()
            
            print("מבצע ניתוח רגשי...")
            
            result = await self.api.analyze_emotional_state(
                input_text=text if text else None,
                analysis_depth="deep"
            )
            
            print("\n😊 תוצאות ניתוח רגשי:")
            
            # הצגת מצב רגשי נוכחי
            current_state = result.get('current_emotional_state', {})
            if current_state:
                print(f"רגש דומיננטי: {current_state.get('dominant_emotion', 'לא זוהה')}")
                print(f"עוצמה כללית: {current_state.get('overall_intensity', 0):.2f}")
                print(f"יציבות רגשית: {current_state.get('emotional_stability', 0):.2f}")
            
            # הצגת המלצות
            if 'emotional_recommendations' in result:
                print("\n💡 המלצות:")
                for rec in result['emotional_recommendations'][:3]:
                    print(f"• {rec}")
            
            print("\n" + "="*50)
            
        except Exception as e:
            print(f"שגיאה בניתוח רגשי: {e}")
    
    async def _interactive_consciousness_insights(self):
        """תובנות תודעה אינטראקטיביות"""
        try:
            print("\n🧠 תובנות תודעה מתקדמות")
            print("-" * 35)
            
            depth = input("בחר עומק ניתוח (basic/standard/deep) [standard]: ").strip().lower()
            if depth not in ['basic', 'standard', 'deep']:
                depth = 'standard'
            
            print(f"מייצר תובנות תודעה (עומק: {depth})...")
            
            insights = await self.api.get_consciousness_insights(
                include_ai_analysis=True,
                depth=depth
            )
            
            print("\n🔍 תובנות תודעה:")
            
            # הצגת מצב תודעה
            if 'consciousness_state' in insights:
                state = insights['consciousness_state']
                print(f"מצב תודעה: {state.get('consciousness_level', 'לא ידוע')}")
                print(f"מוד קוגניטיבי: {state.get('cognitive_mode', 'לא ידוע')}")
                print(f"רמת אנרגיה: {state.get('energy_level', 'לא ידועה')}")
            
            # הצגת תובנות AI
            if 'ai_enhanced_insights' in insights and insights['ai_enhanced_insights']:
                ai_analysis = insights['ai_enhanced_insights'].get('ai_analysis', '')
                if ai_analysis:
                    print(f"\n🤖 ניתוח AI: {ai_analysis[:150]}...")
            
            print("\n" + "="*50)
            
        except Exception as e:
            print(f"שגיאה בקבלת תובנות: {e}")
    
    async def _interactive_system_status(self):
        """מצב מערכת אינטראקטיבי"""
        try:
            print("\n⚙️ מצב המערכת")
            print("-" * 20)
            
            # בדיקת מערכת
            system_test = await self.api.test_system()
            
            print("🔧 סטטוס רכיבים:")
            print(f"API: {system_test.get('api_status', 'לא ידוע')}")
            print(f"מנוע התודעה: {system_test.get('consciousness_engine_status', 'לא ידוע')}")
            print(f"אינטגרציית AI: {system_test.get('ai_integration_status', 'לא ידוע')}")
            print(f"מצב כללי: {system_test.get('overall_status', 'לא ידוע')}")
            
            # סטטיסטיקות
            stats = self.api.get_api_stats()
            if stats:
                print(f"\n📊 סטטיסטיקות:")
                print(f"סה\"כ בקשות: {stats.get('total_requests', 0)}")
                print(f"בקשות מוצלחות: {stats.get('successful_requests', 0)}")
                print(f"שיעור הצלחה: {stats.get('success_rate', 0):.1f}%")
                print(f"שימוש בעברית: {stats.get('hebrew_usage_rate', 0):.1f}%")
            
            print("\n" + "="*50)
            
        except Exception as e:
            print(f"שגיאה בבדיקת מצב מערכת: {e}")
    
    async def _interactive_data_export(self):
        """ייצוא נתונים אינטראקטיבי"""
        try:
            print("\n💾 ייצוא נתונים")
            print("-" * 20)
            
            # יצירת דוח מלא
            full_report = await self.run_complete_demonstration()
            
            filename = f"consciousness_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(full_report, f, ensure_ascii=False, indent=2)
            
            print(f"✅ דוח מלא נשמר בקובץ: {filename}")
            print(f"גודל הקובץ: {len(json.dumps(full_report, ensure_ascii=False))} תווים")
            
            # הצגת סיכום
            print("\n📋 סיכום הדוח:")
            if 'system_info' in full_report:
                print(f"מערכת: {full_report['system_info'].get('system_name', 'לא ידוע')}")
                print(f"גרסה: {full_report['system_info'].get('version', 'לא ידועה')}")
            
            print("\n" + "="*50)
            
        except Exception as e:
            print(f"שגיאה בייצוא נתונים: {e}")
    
    async def shutdown_system(self):
        """כיבוי מערכת מלא"""
        try:
            logger.info("מכבה מערכת תודעה מלאה...")
            
            self.is_running = False
            
            if self.consciousness_engine:
                await self.consciousness_engine.shutdown()
            
            logger.info("מערכת תודעה מלאה נכבתה בהצלחה")
            
        except Exception as e:
            logger.error(f"שגיאה בכיבוי מערכת: {e}")


# פונקציות ראשיות לשימוש חיצוני
async def run_full_consciousness_demo():
    """הרצת הדגמה מלאה של מערכת התודעה"""
    system = CompleteConsciousnessSystem(config_preset="advanced")
    
    try:
        # הדגמה אוטומטית
        print("🧠 מתחיל הדגמה מלאה של מערכת התודעה עם AI מקומי...")
        
        results = await system.run_complete_demonstration()
        
        print("\n✅ הדגמה מלאה הושלמה!")
        print(f"תוצאות נשמרו וזמינות לבדיקה.")
        
        return results
        
    finally:
        await system.shutdown_system()

async def run_interactive_consciousness_session():
    """הרצת סשן אינטראקטיבי עם מערכת התודעה"""
    system = CompleteConsciousnessSystem(config_preset="advanced")
    
    try:
        await system.interactive_demo_session()
    finally:
        await system.shutdown_system()

async def quick_consciousness_test():
    """בדיקה מהירה של מערכת התודעה"""
    try:
        # אתחול מהיר
        await initialize_consciousness_api("standard")
        
        # בדיקה בסיסית
        from .unified_api import process_consciousness_text, analyze_emotions_simple
        
        test_text = "שלום! איך המצב? אני שמח לבדוק את המערכת החדשה."
        
        # עיבוד טקסט
        text_result = await process_consciousness_text(test_text)
        
        # ניתוח רגשי
        emotion_result = await analyze_emotions_simple(test_text)
        
        print("✅ בדיקה מהירה הושלמה בהצלחה!")
        print(f"טקסט עובד: {bool(text_result and 'error' not in text_result)}")
        print(f"ניתוח רגשי פועל: {bool(emotion_result and 'error' not in emotion_result)}")
        
        return {
            'text_processing': text_result,
            'emotion_analysis': emotion_result,
            'test_successful': True
        }
        
    except Exception as e:
        logger.error(f"שגיאה בבדיקה מהירה: {e}")
        return {'test_successful': False, 'error': str(e)}


# נקודת כניסה ראשית
if __name__ == "__main__":
    print("🧠 מערכת התודעה המלאה עם AI מקומי")
    print("=" * 50)
    
    import sys
    
    if len(sys.argv) > 1:
        mode = sys.argv[1].lower()
        
        if mode == "demo":
            asyncio.run(run_full_consciousness_demo())
        elif mode == "interactive":
            asyncio.run(run_interactive_consciousness_session())
        elif mode == "test":
            result = asyncio.run(quick_consciousness_test())
            print(f"תוצאת בדיקה: {result}")
        else:
            print(f"מוד לא ידוע: {mode}")
            print("מודים זמינים: demo, interactive, test")
    else:
        # ברירת מחדל - סשן אינטראקטיבי
        asyncio.run(run_interactive_consciousness_session())