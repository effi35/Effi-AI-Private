#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Memory Engine - מנוע זיכרון 5 שכבות
===================================

מנוע זיכרון מתקדם עם 5 שכבות זיכרון, איחוד אוטומטי,
קשרים דינמיים ותמיכה בעברית וחיפוש סמנטי.

שכבות הזיכרון:
1. זיכרון עבודה (Working Memory) - 20 פריטים, 30 דקות
2. זיכרון קצר טווח (Short-term) - 100 פריטים, 24 שעות  
3. זיכרון אפיזודי (Episodic) - 1000 פריטים, 30 יום
4. זיכרון סמנטי (Semantic) - 10000 פריטים, שנה
5. זיכרון פרוצדורלי (Procedural) - 5000 פריטים, 1000 יום
"""

import asyncio
import logging
import threading
import time
import sqlite3
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple
from pathlib import Path
from collections import defaultdict

from ..models.memory import (
    MemoryType, MemoryImportance, MemoryState, MemoryContent,
    MemoryAssociation, MemoryItem, MemoryLayer, MemorySystem
)
from ..models.config import MemoryConfiguration


class MemoryEngine:
    """מנוע זיכרון מתקדם עם 5 שכבות ויכולות למידה"""
    
    def __init__(self, config: MemoryConfiguration = None, db_path: str = "consciousness_memory.db"):
        """אתחול מנוע הזיכרון"""
        self.config = config or MemoryConfiguration()
        self.logger = logging.getLogger(__name__)
        self.db_path = db_path
        
        # מערכת הזיכרון המרכזית
        self.memory_system = MemorySystem()
        
        # מצב המנוע
        self.is_running = False
        self.consolidation_thread: Optional[threading.Thread] = None
        
        # מטמון וביצועים
        self.search_cache: Dict[str, List[MemoryItem]] = {}
        self.cache_ttl = timedelta(minutes=10)
        self.last_cache_cleanup = datetime.now()
        
        # אינדקס חיפוש לעברית
        self.hebrew_index: Dict[str, Set[str]] = defaultdict(set)  # מילה -> memory_ids
        
        # סטטיסטיקות
        self.stats = {
            'memories_stored': 0,
            'memories_retrieved': 0,
            'consolidations_performed': 0,
            'searches_performed': 0,
            'associations_created': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'start_time': datetime.now()
        }
        
        # דפוסי טקסט עברי
        self.hebrew_patterns = {
            'roots': re.compile(r'[א-ת]{2,4}'),  # שורשים עבריים
            'words': re.compile(r'[א-ת]+'),      # מילים עבריות
            'mixed': re.compile(r'[א-תa-zA-Z0-9]+')  # טקסט מעורב
        }
        
        # אתחול בסיס נתונים
        self._init_database()
        self.logger.info("מנוע הזיכרון אותחל בהצלחה")
    
    def _init_database(self):
        """אתחול בסיס הנתונים לזיכרון"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # טבלת זיכרונות
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS memories (
                        id TEXT PRIMARY KEY,
                        memory_type TEXT NOT NULL,
                        importance INTEGER NOT NULL,
                        state TEXT NOT NULL,
                        content_data TEXT,
                        content_type TEXT,
                        created_at TEXT NOT NULL,
                        last_accessed TEXT NOT NULL,
                        access_count INTEGER DEFAULT 0,
                        emotional_valence REAL DEFAULT 0.0,
                        emotional_intensity REAL DEFAULT 0.0,
                        strength REAL DEFAULT 1.0,
                        consolidation_score REAL DEFAULT 0.0,
                        context_data TEXT,
                        tags TEXT
                    )
                ''')
                
                # טבלת קשרים
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS associations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        source_memory_id TEXT NOT NULL,
                        target_memory_id TEXT NOT NULL,
                        association_type TEXT NOT NULL,
                        strength REAL NOT NULL,
                        created_at TEXT NOT NULL,
                        last_accessed TEXT NOT NULL,
                        FOREIGN KEY (source_memory_id) REFERENCES memories (id),
                        FOREIGN KEY (target_memory_id) REFERENCES memories (id)
                    )
                ''')
                
                # אינדקסים לביצועים
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_memory_type ON memories (memory_type)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_created_at ON memories (created_at)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_last_accessed ON memories (last_accessed)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_associations_source ON associations (source_memory_id)')
                
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"שגיאה באתחול בסיס הנתונים: {e}")
    
    def start(self) -> bool:
        """הפעלת מנוע הזיכרון"""
        try:
            if self.is_running:
                self.logger.warning("מנוע הזיכרון כבר פועל")
                return True
            
            self.is_running = True
            
            # טעינת זיכרונות מבסיס הנתונים
            self._load_memories_from_db()
            
            # הפעלת תהליך איחוד רקע
            self.consolidation_thread = threading.Thread(target=self._consolidation_loop, daemon=True)
            self.consolidation_thread.start()
            
            self.logger.info("מנוע הזיכרון הופעל בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מנוע הזיכרון: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת מנוע הזיכרון"""
        try:
            self.is_running = False
            
            # שמירת זיכרונות לבסיס נתונים
            self._save_memories_to_db()
            
            if self.consolidation_thread:
                self.consolidation_thread.join(timeout=10.0)
            
            self.logger.info("מנוע הזיכרון נעצר בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מנוע הזיכרון: {e}")
            return False
    
    def store_memory(self, content: Any, memory_type: MemoryType = MemoryType.WORKING,
                    importance: MemoryImportance = MemoryImportance.MEDIUM,
                    emotional_valence: float = 0.0, emotional_intensity: float = 0.0,
                    context: Dict[str, Any] = None, tags: Set[str] = None) -> str:
        """שמירת זיכרון חדש במערכת"""
        try:
            # יצירת זיכרון חדש
            memory_id = self.memory_system.store_memory(
                content=content,
                memory_type=memory_type,
                importance=importance,
                emotional_valence=emotional_valence,
                emotional_intensity=emotional_intensity,
                context=context or {}
            )
            
            # הוספת תגיות
            if memory_id and tags:
                memory = self.memory_system.retrieve_memory(memory_id)
                if memory:
                    memory.tags.update(tags)
            
            # עדכון אינדקס עברי
            if memory_id and isinstance(content, str):
                self._update_hebrew_index(memory_id, content)
            
            # יצירת קשרים אוטומטיים
            if self.config.auto_associate and memory_id:
                self._create_automatic_associations(memory_id)
            
            # שמירה לבסיס נתונים
            if memory_id:
                self._save_memory_to_db(memory_id)
                self.stats['memories_stored'] += 1
            
            self.logger.debug(f"נשמר זיכרון חדש: {memory_id}")
            return memory_id
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת זיכרון: {e}")
            return ""
    
    def retrieve_memory(self, memory_id: str) -> Optional[MemoryItem]:
        """אחזור זיכרון לפי מזהה"""
        try:
            memory = self.memory_system.retrieve_memory(memory_id)
            if memory:
                self.stats['memories_retrieved'] += 1
                self.logger.debug(f"אוחזר זיכרון: {memory_id}")
            
            return memory
            
        except Exception as e:
            self.logger.error(f"שגיאה באחזור זיכרון: {e}")
            return None
    
    def search_memories(self, query: str, memory_types: List[MemoryType] = None,
                       limit: int = 20, include_context: bool = True) -> List[MemoryItem]:
        """חיפוש זיכרונות עם תמיכה בעברית"""
        try:
            # בדיקת מטמון
            cache_key = f"{query}_{memory_types}_{limit}"
            if cache_key in self.search_cache:
                self.stats['cache_hits'] += 1
                return self.search_cache[cache_key]
            
            self.stats['cache_misses'] += 1
            self.stats['searches_performed'] += 1
            
            # חיפוש בסיסי במערכת הזיכרון
            basic_results = self.memory_system.search_memories(
                query=query,
                memory_types=memory_types,
                limit=limit * 2  # יותר תוצאות לעיבוד נוסף
            )
            
            # חיפוש משופר לעברית
            hebrew_results = self._search_hebrew_memories(query, memory_types, limit)
            
            # איחוד ודירוג תוצאות
            combined_results = self._combine_and_rank_results(
                basic_results, hebrew_results, query, limit
            )
            
            # שמירה במטמון
            self.search_cache[cache_key] = combined_results
            
            self.logger.debug(f"נמצאו {len(combined_results)} זיכרונות עבור: '{query}'")
            return combined_results
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש זיכרונות: {e}")
            return []
    
    def create_association(self, memory_id1: str, memory_id2: str,
                          association_type: str = "semantic", strength: float = 0.5) -> bool:
        """יצירת קשר בין שני זיכרונות"""
        try:
            memory1 = self.memory_system.retrieve_memory(memory_id1)
            memory2 = self.memory_system.retrieve_memory(memory_id2)
            
            if not memory1 or not memory2:
                return False
            
            # הוספת קשר דו-כיווני
            memory1.add_association(memory_id2, association_type, strength)
            memory2.add_association(memory_id1, association_type, strength)
            
            # שמירה לבסיס נתונים
            self._save_association_to_db(memory_id1, memory_id2, association_type, strength)
            
            self.stats['associations_created'] += 1
            self.logger.debug(f"נוצר קשר בין {memory_id1} ל-{memory_id2}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת קשר: {e}")
            return False
    
    def get_related_memories(self, memory_id: str, max_results: int = 10) -> List[MemoryItem]:
        """קבלת זיכרונות קשורים לזיכרון נתון"""
        try:
            memory = self.memory_system.retrieve_memory(memory_id)
            if not memory:
                return []
            
            related_memories = []
            
            # זיכרונות מקושרים ישירות
            for association in memory.associations:
                related_memory = self.memory_system.retrieve_memory(association.target_id)
                if related_memory:
                    related_memories.append((related_memory, association.strength))
            
            # זיכרונות עם תוכן דומה
            if isinstance(memory.content.data, str) and len(memory.content.data) > 10:
                similar_memories = self.search_memories(
                    memory.content.data[:50],  # חיפוש לפי תחילת התוכן
                    limit=max_results
                )
                
                for similar_memory in similar_memories:
                    if similar_memory.id != memory_id:
                        # חישוב דמיון בסיסי
                        similarity = self._calculate_content_similarity(memory, similar_memory)
                        if similarity > 0.3:
                            related_memories.append((similar_memory, similarity))
            
            # מיון לפי עוצמת הקשר ורלוונטיות
            related_memories.sort(key=lambda x: x[1], reverse=True)
            
            return [mem for mem, _ in related_memories[:max_results]]
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת זיכרונות קשורים: {e}")
            return []
    
    def consolidate_memories(self) -> int:
        """איחוד זיכרונות ידני"""
        try:
            consolidated_count = 0
            
            # איחוד בכל שכבה
            for memory_type in MemoryType:
                layer = self.memory_system.get_layer(memory_type)
                layer.consolidate_layer()
                
                # ספירת זיכרונות שאוחדו
                for memory in layer.items.values():
                    if memory.state == MemoryState.CONSOLIDATED:
                        consolidated_count += 1
            
            # העברת זיכרונות בין שכבות
            self.memory_system._promote_memories()
            
            self.stats['consolidations_performed'] += 1
            self.logger.debug(f"אוחדו {consolidated_count} זיכרונות")
            
            return consolidated_count
            
        except Exception as e:
            self.logger.error(f"שגיאה באיחוד זיכרונות: {e}")
            return 0
    
    def get_memory_insights(self) -> Dict[str, Any]:
        """קבלת תובנות על מערכת הזיכרון"""
        try:
            stats = self.memory_system.get_memory_statistics()
            
            # ניתוח דפוסי זיכרון
            all_memories = []
            for memory_type in MemoryType:
                layer = self.memory_system.get_layer(memory_type)
                all_memories.extend(layer.items.values())
            
            # ניתוח תוכן עברי
            hebrew_memories = sum(1 for mem in all_memories 
                                if self._is_hebrew_content(mem.content.data))
            
            # ניתוח רגשי
            emotional_memories = sum(1 for mem in all_memories 
                                   if abs(mem.emotional_valence) > 0.1 or mem.emotional_intensity > 0.1)
            
            # זיכרונות חזקים
            strong_memories = sum(1 for mem in all_memories if mem.strength > 0.8)
            
            return {
                'layer_statistics': stats,
                'total_memories': len(all_memories),
                'hebrew_memories': hebrew_memories,
                'emotional_memories': emotional_memories,
                'strong_memories': strong_memories,
                'hebrew_percentage': (hebrew_memories / len(all_memories) * 100) if all_memories else 0,
                'processing_stats': self.stats.copy(),
                'cache_efficiency': self._calculate_cache_efficiency(),
                'consolidation_effectiveness': self._calculate_consolidation_effectiveness()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תובנות זיכרון: {e}")
            return {}
    
    def _search_hebrew_memories(self, query: str, memory_types: List[MemoryType], 
                               limit: int) -> List[MemoryItem]:
        """חיפוש מתקדם בזיכרונות עבריים"""
        try:
            hebrew_results = []
            
            # חיפוש במילים עבריות
            hebrew_words = self.hebrew_patterns['words'].findall(query)
            
            for word in hebrew_words:
                if word in self.hebrew_index:
                    memory_ids = self.hebrew_index[word]
                    
                    for memory_id in memory_ids:
                        memory = self.memory_system.retrieve_memory(memory_id)
                        if memory and (not memory_types or memory.memory_type in memory_types):
                            hebrew_results.append(memory)
            
            # הסרת כפילויות
            unique_results = {mem.id: mem for mem in hebrew_results}
            return list(unique_results.values())[:limit]
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש עברי: {e}")
            return []
    
    def _combine_and_rank_results(self, basic_results: List[MemoryItem],
                                 hebrew_results: List[MemoryItem],
                                 query: str, limit: int) -> List[MemoryItem]:
        """איחוד ודירוג תוצאות חיפוש"""
        try:
            # איחוד תוצאות
            all_results = {}
            
            # הוספת תוצאות בסיסיות
            for memory in basic_results:
                all_results[memory.id] = {
                    'memory': memory,
                    'score': memory.access_count * memory.strength
                }
            
            # הוספת תוצאות עבריות עם בונוס
            for memory in hebrew_results:
                if memory.id in all_results:
                    all_results[memory.id]['score'] += 0.5  # בונוס לעברית
                else:
                    all_results[memory.id] = {
                        'memory': memory,
                        'score': memory.access_count * memory.strength + 0.5
                    }
            
            # מיון לפי ציון
            sorted_results = sorted(all_results.values(), 
                                  key=lambda x: x['score'], reverse=True)
            
            return [item['memory'] for item in sorted_results[:limit]]
            
        except Exception as e:
            self.logger.error(f"שגיאה באיחוד תוצאות: {e}")
            return basic_results[:limit]
    
    def _update_hebrew_index(self, memory_id: str, content: str):
        """עדכון אינדקס החיפוש העברי"""
        try:
            if not isinstance(content, str):
                return
            
            hebrew_words = self.hebrew_patterns['words'].findall(content.lower())
            
            for word in hebrew_words:
                if len(word) >= 2:  # מילים עם לפחות 2 אותיות
                    self.hebrew_index[word].add(memory_id)
                    
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון אינדקס עברי: {e}")
    
    def _create_automatic_associations(self, memory_id: str):
        """יצירת קשרים אוטומטיים לזיכרון חדש"""
        try:
            memory = self.memory_system.retrieve_memory(memory_id)
            if not memory:
                return
            
            # חיפוש זיכרונות דומים
            if isinstance(memory.content.data, str) and len(memory.content.data) > 10:
                similar_memories = self.search_memories(
                    memory.content.data[:50],
                    limit=5
                )
                
                for similar_memory in similar_memories:
                    if similar_memory.id != memory_id:
                        # חישוב עוצמת הקשר
                        similarity = self._calculate_content_similarity(memory, similar_memory)
                        
                        if similarity > self.config.association_strength_threshold:
                            self.create_association(
                                memory_id, 
                                similar_memory.id,
                                "semantic",
                                similarity
                            )
                            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת קשרים אוטומטיים: {e}")
    
    def _calculate_content_similarity(self, memory1: MemoryItem, memory2: MemoryItem) -> float:
        """חישוב דמיון בין תוכן זיכרונות"""
        try:
            content1 = str(memory1.content.data).lower()
            content2 = str(memory2.content.data).lower()
            
            # דמיון בסיסי לפי מילים משותפות
            words1 = set(content1.split())
            words2 = set(content2.split())
            
            if not words1 or not words2:
                return 0.0
            
            intersection = len(words1.intersection(words2))
            union = len(words1.union(words2))
            
            return intersection / union if union > 0 else 0.0
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב דמיון: {e}")
            return 0.0
    
    def _is_hebrew_content(self, content: Any) -> bool:
        """בדיקה אם התוכן מכיל עברית"""
        try:
            if not isinstance(content, str):
                return False
            
            hebrew_chars = len(re.findall(r'[א-ת]', content))
            total_chars = len(re.findall(r'[א-תa-zA-Z]', content))
            
            return (hebrew_chars / total_chars) > 0.3 if total_chars > 0 else False
            
        except Exception as e:
            return False
    
    def _consolidation_loop(self):
        """לולאת איחוד רקע"""
        while self.is_running:
            try:
                # איחוד זיכרונות
                self.consolidate_memories()
                
                # ניקוי מטמון
                if datetime.now() - self.last_cache_cleanup > self.cache_ttl:
                    self._cleanup_cache()
                
                # שמירה תקופתית לבסיס נתונים
                self._save_memories_to_db()
                
                # המתנה
                time.sleep(self.config.consolidation_frequency)
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת איחוד: {e}")
                time.sleep(60)  # המתנה ארוכה יותר בשגיאה
    
    def _cleanup_cache(self):
        """ניקוי מטמון חיפוש"""
        try:
            self.search_cache.clear()
            self.last_cache_cleanup = datetime.now()
            self.logger.debug("מטמון החיפוש נוקה")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי מטמון: {e}")
    
    def _calculate_cache_efficiency(self) -> float:
        """חישוב יעילות המטמון"""
        try:
            total_requests = self.stats['cache_hits'] + self.stats['cache_misses']
            if total_requests == 0:
                return 0.0
            
            return self.stats['cache_hits'] / total_requests
            
        except Exception:
            return 0.0
    
    def _calculate_consolidation_effectiveness(self) -> float:
        """חישוב יעילות איחוד הזיכרונות"""
        try:
            all_memories = []
            for memory_type in MemoryType:
                layer = self.memory_system.get_layer(memory_type)
                all_memories.extend(layer.items.values())
            
            if not all_memories:
                return 0.0
            
            consolidated_count = sum(1 for mem in all_memories 
                                   if mem.state == MemoryState.CONSOLIDATED)
            
            return consolidated_count / len(all_memories)
            
        except Exception:
            return 0.0
    
    def _load_memories_from_db(self):
        """טעינת זיכרונות מבסיס הנתונים"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT * FROM memories ORDER BY created_at DESC LIMIT 1000')
                rows = cursor.fetchall()
                
                for row in rows:
                    # יצירת זיכרון מהשורה
                    memory = self._create_memory_from_db_row(row)
                    if memory:
                        # הוספה למערכת הזיכרון
                        layer = self.memory_system.get_layer(memory.memory_type)
                        layer.items[memory.id] = memory
                        
                        # עדכון אינדקס עברי
                        if isinstance(memory.content.data, str):
                            self._update_hebrew_index(memory.id, memory.content.data)
                
                self.logger.info(f"נטענו {len(rows)} זיכרונות מבסיס הנתונים")
                
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת זיכרונות: {e}")
    
    def _save_memories_to_db(self):
        """שמירת זיכרונות לבסיס הנתונים"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                for memory_type in MemoryType:
                    layer = self.memory_system.get_layer(memory_type)
                    
                    for memory in layer.items.values():
                        self._save_memory_to_db_with_cursor(cursor, memory)
                
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת זיכרונות: {e}")
    
    def _save_memory_to_db(self, memory_id: str):
        """שמירת זיכרון יחיד לבסיס הנתונים"""
        try:
            memory = self.memory_system.retrieve_memory(memory_id)
            if not memory:
                return
                
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                self._save_memory_to_db_with_cursor(cursor, memory)
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת זיכרון יחיד: {e}")
    
    def _save_memory_to_db_with_cursor(self, cursor, memory: MemoryItem):
        """שמירת זיכרון עם cursor קיים"""
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO memories (
                    id, memory_type, importance, state, content_data, content_type,
                    created_at, last_accessed, access_count, emotional_valence,
                    emotional_intensity, strength, consolidation_score,
                    context_data, tags
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                memory.id,
                memory.memory_type.value,
                memory.importance.value,
                memory.state.value,
                json.dumps(memory.content.data, ensure_ascii=False),
                memory.content.content_type,
                memory.created_at.isoformat(),
                memory.last_accessed.isoformat(),
                memory.access_count,
                memory.emotional_valence,
                memory.emotional_intensity,
                memory.strength,
                memory.consolidation_score,
                json.dumps(memory.context, ensure_ascii=False),
                json.dumps(list(memory.tags), ensure_ascii=False)
            ))
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת זיכרון לטבלה: {e}")
    
    def _save_association_to_db(self, memory_id1: str, memory_id2: str, 
                               association_type: str, strength: float):
        """שמירת קשר לבסיס הנתונים"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO associations (
                        source_memory_id, target_memory_id, association_type,
                        strength, created_at, last_accessed
                    ) VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    memory_id1, memory_id2, association_type, strength,
                    datetime.now().isoformat(), datetime.now().isoformat()
                ))
                
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת קשר: {e}")
    
    def _create_memory_from_db_row(self, row) -> Optional[MemoryItem]:
        """יצירת זיכרון משורה של בסיס נתונים"""
        try:
            # פענוח הנתונים
            content_data = json.loads(row[4]) if row[4] else ""
            context = json.loads(row[12]) if row[12] else {}
            tags = set(json.loads(row[13])) if row[13] else set()
            
            # יצירת תוכן זיכרון
            content = MemoryContent(
                data=content_data,
                content_type=row[5] or "text"
            )
            
            # יצירת זיכרון
            memory = MemoryItem(
                id=row[0],
                content=content,
                memory_type=MemoryType(row[1]),
                importance=MemoryImportance(row[2]),
                state=MemoryState(row[3]),
                created_at=datetime.fromisoformat(row[6]),
                last_accessed=datetime.fromisoformat(row[7]),
                access_count=row[8] or 0,
                emotional_valence=row[9] or 0.0,
                emotional_intensity=row[10] or 0.0,
                strength=row[11] or 1.0,
                consolidation_score=row[12] or 0.0,
                context=context,
                tags=tags
            )
            
            return memory
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת זיכרון מבסיס נתונים: {e}")
            return None
    
    def get_engine_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מנוע הזיכרון"""
        return {
            'is_running': self.is_running,
            'uptime': (datetime.now() - self.stats['start_time']).total_seconds(),
            'memories_stored': self.stats['memories_stored'],
            'memories_retrieved': self.stats['memories_retrieved'],
            'consolidations_performed': self.stats['consolidations_performed'],
            'searches_performed': self.stats['searches_performed'],
            'associations_created': self.stats['associations_created'],
            'cache_size': len(self.search_cache),
            'hebrew_index_size': len(self.hebrew_index),
            'cache_efficiency': self._calculate_cache_efficiency(),
            'consolidation_effectiveness': self._calculate_consolidation_effectiveness()
        }