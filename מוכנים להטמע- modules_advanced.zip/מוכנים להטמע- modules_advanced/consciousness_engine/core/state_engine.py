#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 State Engine - מנוע מצבי תודעה
==============================

מנוע מתקדם לניהול מצבי תודעה, רמות מודעות, ניהול קשב
ומעברים דינמיים בין מצבים שונים של התודעה.

רמות תודעה:
0. חוסר הכרה (UNCONSCIOUS)
1. תת-מודע (SUBCONSCIOUS) 
2. טרום-מודע (PRECONSCIOUS)
3. מודע (CONSCIOUS)
4. היפר-מודע (HYPERCONSCIOUS)
5. טרנסצנדנטי (TRANSCENDENT)
"""

import asyncio
import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple
from collections import deque
import json

from ..models.states import (
    ConsciousnessLevel, AttentionState, EmotionalState, CognitiveMode,
    EnergyLevel, AttentionFocus, ConsciousnessMetrics, StateTransition,
    ConsciousnessState, StatePattern, StateManager
)
from ..models.config import StateConfiguration


class StateEngine:
    """מנוע מצבי תודעה מתקדם עם ניהול קשב ומעברים דינמיים"""
    
    def __init__(self, config: StateConfiguration = None):
        """אתחול מנוע מצבי התודעה"""
        self.config = config or StateConfiguration()
        self.logger = logging.getLogger(__name__)
        
        # מנהל המצבים המרכזי
        self.state_manager = StateManager()
        
        # מצב המנוע
        self.is_running = False
        self.monitoring_thread: Optional[threading.Thread] = None
        self.transition_thread: Optional[threading.Thread] = None
        
        # ניהול קשב ופוקוס
        self.attention_manager = AttentionManager(self.config)
        self.energy_manager = EnergyManager(self.config)
        
        # היסטוריית מעברים ודפוסים
        self.transition_history: deque = deque(maxlen=100)
        self.detected_patterns: List[StatePattern] = []
        
        # מטריקות ביצועים
        self.performance_metrics = {
            'state_transitions': 0,
            'attention_switches': 0,
            'energy_fluctuations': 0,
            'stability_violations': 0,
            'pattern_matches': 0,
            'overload_events': 0,
            'recovery_events': 0
        }
        
        # סטטיסטיקות
        self.stats = {
            'total_states': 0,
            'consciousness_level_changes': 0,
            'attention_state_changes': 0,
            'cognitive_mode_changes': 0,
            'emotional_state_changes': 0,
            'energy_level_changes': 0,
            'successful_transitions': 0,
            'failed_transitions': 0,
            'start_time': datetime.now()
        }
        
        # הגדרות מיוחדות למצבי תודעה ישראליים
        self.israeli_consciousness_patterns = {
            'sabra_directness': {
                'consciousness_level': ConsciousnessLevel.CONSCIOUS,
                'cognitive_mode': CognitiveMode.ANALYTICAL,
                'attention_state': AttentionState.FOCUSED,
                'characteristics': ['direct', 'pragmatic', 'efficient']
            },
            'mediterranean_relaxed': {
                'consciousness_level': ConsciousnessLevel.CONSCIOUS,
                'cognitive_mode': CognitiveMode.INTUITIVE,
                'attention_state': AttentionState.SCATTERED,
                'characteristics': ['relaxed', 'social', 'flexible']
            },
            'intense_focus': {
                'consciousness_level': ConsciousnessLevel.HYPERCONSCIOUS,
                'cognitive_mode': CognitiveMode.CRITICAL,
                'attention_state': AttentionState.ABSORBED,
                'characteristics': ['intense', 'perfectionist', 'dedicated']
            }
        }
        
        # טריגרים למעברי מצב
        self.state_triggers = {
            'stress': ConsciousnessLevel.CONSCIOUS,
            'relaxation': ConsciousnessLevel.PRECONSCIOUS,
            'deep_focus': ConsciousnessLevel.HYPERCONSCIOUS,
            'meditation': ConsciousnessLevel.TRANSCENDENT,
            'fatigue': ConsciousnessLevel.SUBCONSCIOUS,
            'sleep': ConsciousnessLevel.UNCONSCIOUS
        }
        
        # אתחול מצב התודעה הראשוני
        self._init_initial_state()
        
        self.logger.info("מנוע מצבי התודעה אותחל בהצלחה")
    
    def start(self) -> bool:
        """הפעלת מנוע מצבי התודעה"""
        try:
            if self.is_running:
                self.logger.warning("מנוע מצבי התודעה כבר פועל")
                return True
            
            self.is_running = True
            
            # הפעלת תהליכי רקע
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitoring_thread.start()
            
            if self.config.auto_state_transitions:
                self.transition_thread = threading.Thread(target=self._transition_loop, daemon=True)
                self.transition_thread.start()
            
            # הפעלת מנהלי המשנה
            self.attention_manager.start()
            self.energy_manager.start()
            
            self.logger.info("מנוע מצבי התודעה הופעל בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מנוע מצבי התודעה: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת מנוע מצבי התודעה"""
        try:
            self.is_running = False
            
            # עצירת תהליכי רקע
            if self.monitoring_thread:
                self.monitoring_thread.join(timeout=5.0)
            if self.transition_thread:
                self.transition_thread.join(timeout=5.0)
            
            # עצירת מנהלי המשנה
            self.attention_manager.stop()
            self.energy_manager.stop()
            
            self.logger.info("מנוע מצבי התודעה נעצר בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מנוע מצבי התודעה: {e}")
            return False
    
    def transition_to_state(self, target_level: ConsciousnessLevel = None,
                           target_attention: AttentionState = None,
                           target_cognitive: CognitiveMode = None,
                           target_emotional: EmotionalState = None,
                           trigger: str = "manual") -> bool:
        """מעבר למצב תודעה חדש"""
        try:
            current_state = self.state_manager.current_state
            
            # יצירת מצב חדש עם השינויים הנדרשים
            new_state = ConsciousnessState(
                consciousness_level=target_level or current_state.consciousness_level,
                attention_state=target_attention or current_state.attention_state,
                cognitive_mode=target_cognitive or current_state.cognitive_mode,
                emotional_state=target_emotional or current_state.emotional_state,
                energy_level=current_state.energy_level
            )
            
            # בדיקת תקינות המעבר
            if not self._validate_transition(current_state, new_state):
                self.stats['failed_transitions'] += 1
                return False
            
            # ביצוע המעבר
            transition_start = datetime.now()
            self.state_manager.transition_to_state(new_state, trigger)
            transition_duration = datetime.now() - transition_start
            
            # עדכון מטריקות
            self._update_transition_metrics(current_state, new_state)
            
            # הוספה להיסטוריית מעברים
            transition = StateTransition(
                from_state=current_state.get_state_signature(),
                to_state=new_state.get_state_signature(),
                trigger=trigger,
                duration=transition_duration,
                successful=True
            )
            self.transition_history.append(transition)
            
            self.stats['successful_transitions'] += 1
            self.performance_metrics['state_transitions'] += 1
            
            self.logger.debug(f"מעבר מצב בוצע: {current_state.get_state_signature()} -> {new_state.get_state_signature()}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה במעבר מצב: {e}")
            self.stats['failed_transitions'] += 1
            return False
    
    def set_attention_focus(self, target: str, intensity: float = 0.8,
                           context: Dict[str, Any] = None) -> bool:
        """הגדרת פוקוס קשב ראשי"""
        try:
            current_state = self.state_manager.current_state
            current_state.set_primary_focus(target, intensity, context)
            
            # עדכון מצב הקשב
            self.attention_manager.update_focus(target, intensity)
            
            self.performance_metrics['attention_switches'] += 1
            self.logger.debug(f"נקבע פוקוס קשב: {target} בעוצמה {intensity}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהגדרת פוקוס קשב: {e}")
            return False
    
    def add_secondary_focus(self, target: str, intensity: float = 0.4,
                           context: Dict[str, Any] = None) -> bool:
        """הוספת פוקוס קשב משני"""
        try:
            current_state = self.state_manager.current_state
            
            # בדיקה שלא נחרוג מהמגבלות
            if len(current_state.secondary_focuses) >= self.config.max_attention_focuses:
                self.logger.warning("הגעה למגבלת פוקוסי קשב")
                return False
            
            current_state.add_secondary_focus(target, intensity, context)
            
            # בדיקת עומס קשב
            if current_state.is_overloaded():
                self.performance_metrics['overload_events'] += 1
                self._handle_attention_overload()
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת פוקוס משני: {e}")
            return False
    
    def update_consciousness_metrics(self, **metrics) -> bool:
        """עדכון מטריקות התודעה"""
        try:
            current_state = self.state_manager.current_state
            current_state.update_metrics(**metrics)
            
            # בדיקת צורך במעבר מצב לפי המטריקות
            if self.config.auto_state_transitions:
                self._check_metric_based_transitions(current_state)
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מטריקות: {e}")
            return False
    
    def get_current_state(self) -> ConsciousnessState:
        """קבלת המצב הנוכחי של התודעה"""
        return self.state_manager.current_state
    
    def get_state_history(self, limit: int = 50) -> List[ConsciousnessState]:
        """קבלת היסטוריית מצבי תודעה"""
        return self.state_manager.state_history[-limit:]
    
    def detect_state_patterns(self) -> List[StatePattern]:
        """זיהוי דפוסי מצבי תודעה"""
        try:
            detected = self.state_manager.detect_patterns()
            
            # בדיקת דפוסים ישראליים מיוחדים
            israeli_patterns = self._detect_israeli_patterns()
            detected.extend(israeli_patterns)
            
            self.detected_patterns = detected
            self.performance_metrics['pattern_matches'] += len(detected)
            
            return detected
            
        except Exception as e:
            self.logger.error(f"שגיאה בזיהוי דפוסי מצב: {e}")
            return []
    
    def predict_next_state(self) -> Optional[str]:
        """חיזוי המצב הבא בהתבסס על דפוסים"""
        try:
            # חיזוי בסיסי מהמנהל
            basic_prediction = self.state_manager.predict_next_state()
            
            # שיפור החיזוי עם נתונים נוספים
            enhanced_prediction = self._enhance_prediction(basic_prediction)
            
            return enhanced_prediction or basic_prediction
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיזוי מצב: {e}")
            return None
    
    def get_consciousness_insights(self) -> Dict[str, Any]:
        """קבלת תובנות על מצבי התודעה"""
        try:
            current_state = self.state_manager.current_state
            state_stats = self.state_manager.get_state_statistics()
            
            # ניתוח יציבות
            stability_score = self._calculate_overall_stability()
            
            # ניתוח יעילות קשב
            attention_efficiency = self.attention_manager.get_efficiency_score()
            
            # ניתוח אנרגיה
            energy_analysis = self.energy_manager.get_energy_analysis()
            
            return {
                'current_state': current_state.serialize(),
                'state_statistics': state_stats,
                'stability_score': stability_score,
                'attention_efficiency': attention_efficiency,
                'energy_analysis': energy_analysis,
                'detected_patterns': len(self.detected_patterns),
                'performance_metrics': self.performance_metrics.copy(),
                'consciousness_complexity': self._calculate_consciousness_complexity(),
                'israeli_adaptation_score': self._calculate_israeli_adaptation(),
                'processing_stats': self.stats.copy()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תובנות תודעה: {e}")
            return {}
    
    def _init_initial_state(self):
        """אתחול מצב התודעה הראשוני"""
        try:
            initial_state = ConsciousnessState(
                consciousness_level=ConsciousnessLevel.CONSCIOUS,
                attention_state=AttentionState.FOCUSED,
                cognitive_mode=CognitiveMode.ANALYTICAL,
                emotional_state=EmotionalState.NEUTRAL,
                energy_level=EnergyLevel.MODERATE
            )
            
            # הגדרת מטריקות ראשוניות
            initial_state.metrics.awareness_score = 0.7
            initial_state.metrics.coherence_score = 0.6
            initial_state.metrics.integration_level = 0.5
            
            self.state_manager.current_state = initial_state
            self.stats['total_states'] += 1
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול מצב ראשוני: {e}")
    
    def _monitoring_loop(self):
        """לולאת ניטור מצבי התודעה"""
        while self.is_running:
            try:
                current_state = self.state_manager.current_state
                
                # עדכון משך המצב הנוכחי
                current_state.update_duration()
                
                # ניטור יציבות
                self._monitor_stability(current_state)
                
                # ניטור עומס קשב
                self._monitor_attention_load(current_state)
                
                # ניטור רמת אנרגיה
                self._monitor_energy_level(current_state)
                
                # זיהוי דפוסים
                self.detect_state_patterns()
                
                time.sleep(2.0)  # ניטור כל 2 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת ניטור: {e}")
                time.sleep(5.0)
    
    def _transition_loop(self):
        """לולאת מעברי מצב אוטומטיים"""
        while self.is_running:
            try:
                current_state = self.state_manager.current_state
                
                # בדיקת צורך במעברי מצב אוטומטיים
                suggested_transition = self._analyze_transition_needs(current_state)
                
                if suggested_transition:
                    self.transition_to_state(**suggested_transition)
                
                time.sleep(10.0)  # בדיקה כל 10 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת מעברים: {e}")
                time.sleep(15.0)
    
    def _validate_transition(self, current_state: ConsciousnessState, 
                           new_state: ConsciousnessState) -> bool:
        """בדיקת תקינות מעבר מצב"""
        try:
            # בדיקת מעברים קיצוניים ברמת התודעה
            level_diff = abs(current_state.consciousness_level.value - new_state.consciousness_level.value)
            if level_diff > 2:  # מעבר חד מדי
                self.logger.warning(f"מעבר חד מדי ברמת תודעה: {level_diff}")
                return False
            
            # בדיקת זמינות אנרגיה למעבר
            required_energy = self._calculate_transition_energy_cost(current_state, new_state)
            available_energy = current_state.energy_level.value / 5.0
            
            if required_energy > available_energy:
                self.logger.warning("אין מספיק אנרגיה למעבר")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת תקינות מעבר: {e}")
            return False
    
    def _update_transition_metrics(self, old_state: ConsciousnessState, 
                                 new_state: ConsciousnessState):
        """עדכון מטריקות מעבר"""
        try:
            if old_state.consciousness_level != new_state.consciousness_level:
                self.stats['consciousness_level_changes'] += 1
            
            if old_state.attention_state != new_state.attention_state:
                self.stats['attention_state_changes'] += 1
            
            if old_state.cognitive_mode != new_state.cognitive_mode:
                self.stats['cognitive_mode_changes'] += 1
            
            if old_state.emotional_state != new_state.emotional_state:
                self.stats['emotional_state_changes'] += 1
            
            if old_state.energy_level != new_state.energy_level:
                self.stats['energy_level_changes'] += 1
                
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מטריקות מעבר: {e}")
    
    def _handle_attention_overload(self):
        """טיפול בעומס קשב"""
        try:
            current_state = self.state_manager.current_state
            
            # הפחתת עוצמת פוקוסים משניים
            for focus in current_state.secondary_focuses:
                focus.intensity *= 0.7
            
            # מעבר למצב קשב מפוזר אם נדרש
            if current_state.attention_state == AttentionState.FOCUSED:
                self.transition_to_state(
                    target_attention=AttentionState.DIVIDED,
                    trigger="attention_overload"
                )
            
            self.performance_metrics['recovery_events'] += 1
            self.logger.debug("טופל עומס קשב")
            
        except Exception as e:
            self.logger.error(f"שגיאה בטיפול בעומס קשב: {e}")
    
    def _check_metric_based_transitions(self, current_state: ConsciousnessState):
        """בדיקת צורך במעברים לפי מטריקות"""
        try:
            metrics = current_state.metrics
            
            # מעבר להיפר-מודע אם המטריקות גבוהות
            if (metrics.awareness_score > 0.9 and 
                metrics.meta_awareness > self.config.metacognition_threshold):
                if current_state.consciousness_level != ConsciousnessLevel.HYPERCONSCIOUS:
                    self.transition_to_state(
                        target_level=ConsciousnessLevel.HYPERCONSCIOUS,
                        trigger="high_metrics"
                    )
            
            # מעבר לטרנסצנדנטי במטריקות מקסימליות
            elif (metrics.awareness_score > self.config.transcendence_threshold and
                  metrics.integration_level > 0.9):
                if current_state.consciousness_level != ConsciousnessLevel.TRANSCENDENT:
                    self.transition_to_state(
                        target_level=ConsciousnessLevel.TRANSCENDENT,
                        trigger="transcendent_metrics"
                    )
            
            # מעבר למודעות נמוכה יותר במטריקות נמוכות
            elif metrics.awareness_score < 0.3:
                if current_state.consciousness_level.value > ConsciousnessLevel.PRECONSCIOUS.value:
                    self.transition_to_state(
                        target_level=ConsciousnessLevel.PRECONSCIOUS,
                        trigger="low_awareness"
                    )
                    
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת מעברים לפי מטריקות: {e}")
    
    def _detect_israeli_patterns(self) -> List[StatePattern]:
        """זיהוי דפוסי תודעה ישראליים מיוחדים"""
        try:
            israeli_patterns = []
            recent_states = self.get_state_history(10)
            
            if len(recent_states) < 3:
                return israeli_patterns
            
            # דפוס "צברי ישיר"
            if self._matches_sabra_pattern(recent_states):
                pattern = StatePattern(
                    name="Sabra Directness Pattern",
                    description="דפוס התנהגות צברית ישירה ואנליטית",
                    state_sequence=[state.get_state_signature() for state in recent_states[-3:]],
                    typical_context={'culture': 'israeli', 'style': 'direct'}
                )
                israeli_patterns.append(pattern)
            
            # דפוס "רגיעה ים-תיכונית"
            if self._matches_mediterranean_pattern(recent_states):
                pattern = StatePattern(
                    name="Mediterranean Relaxed Pattern",
                    description="דפוס רגיעה ים-תיכונית עם גמישות קוגניטיבית",
                    state_sequence=[state.get_state_signature() for state in recent_states[-3:]],
                    typical_context={'culture': 'israeli', 'style': 'relaxed'}
                )
                israeli_patterns.append(pattern)
            
            return israeli_patterns
            
        except Exception as e:
            self.logger.error(f"שגיאה בזיהוי דפוסים ישראליים: {e}")
            return []
    
    def _matches_sabra_pattern(self, states: List[ConsciousnessState]) -> bool:
        """בדיקה אם מתאים לדפוס צברי"""
        try:
            if len(states) < 3:
                return False
            
            # בדיקת מאפיינים צבריים: ישירות, אנליטיות, פוקוס
            sabra_count = 0
            for state in states[-3:]:
                if (state.cognitive_mode in [CognitiveMode.ANALYTICAL, CognitiveMode.CRITICAL] and
                    state.attention_state in [AttentionState.FOCUSED, AttentionState.SUSTAINED]):
                    sabra_count += 1
            
            return sabra_count >= 2
            
        except Exception:
            return False
    
    def _matches_mediterranean_pattern(self, states: List[ConsciousnessState]) -> bool:
        """בדיקה אם מתאים לדפוס ים-תיכוני"""
        try:
            if len(states) < 3:
                return False
            
            # בדיקת מאפיינים ים-תיכוניים: גמישות, אינטואיציה, רגיעה
            med_count = 0
            for state in states[-3:]:
                if (state.cognitive_mode in [CognitiveMode.INTUITIVE, CognitiveMode.CREATIVE] and
                    state.emotional_state in [EmotionalState.CALM, EmotionalState.POSITIVE]):
                    med_count += 1
            
            return med_count >= 2
            
        except Exception:
            return False
    
    def _enhance_prediction(self, basic_prediction: Optional[str]) -> Optional[str]:
        """שיפור חיזוי מצב עם נתונים נוספים"""
        try:
            current_state = self.state_manager.current_state
            
            # שיפור לפי אנרגיה
            energy_level = current_state.energy_level.value
            if energy_level <= 2:  # אנרגיה נמוכה
                return "SUBCONSCIOUS_scattered_intuitive_neutral"
            elif energy_level >= 4:  # אנרגיה גבוהה
                return "HYPERCONSCIOUS_focused_analytical_positive"
            
            # שיפור לפי עומס קשב
            if current_state.is_overloaded():
                return "CONSCIOUS_divided_reactive_stressed"
            
            return basic_prediction
            
        except Exception:
            return basic_prediction
    
    def _monitor_stability(self, state: ConsciousnessState):
        """ניטור יציבות המצב"""
        try:
            if state.stability_score < 0.3:
                self.performance_metrics['stability_violations'] += 1
                
                # ניסיון ייצוב
                if self.config.auto_state_transitions:
                    self.transition_to_state(
                        target_attention=AttentionState.FOCUSED,
                        trigger="stability_recovery"
                    )
                    
        except Exception as e:
            self.logger.error(f"שגיאה בניטור יציבות: {e}")
    
    def _monitor_attention_load(self, state: ConsciousnessState):
        """ניטור עומס קשב"""
        try:
            attention_load = state.calculate_total_attention()
            
            if attention_load > 1.2:  # עומס יתר
                self._handle_attention_overload()
                
        except Exception as e:
            self.logger.error(f"שגיאה בניטור עומס קשב: {e}")
    
    def _monitor_energy_level(self, state: ConsciousnessState):
        """ניטור רמת אנרגיה"""
        try:
            energy_value = state.energy_level.value
            
            # בדיקת עייפות
            if energy_value <= 2:
                if state.consciousness_level.value > ConsciousnessLevel.PRECONSCIOUS.value:
                    self.transition_to_state(
                        target_level=ConsciousnessLevel.PRECONSCIOUS,
                        trigger="fatigue"
                    )
                    
        except Exception as e:
            self.logger.error(f"שגיאה בניטור אנרגיה: {e}")
    
    def _analyze_transition_needs(self, current_state: ConsciousnessState) -> Optional[Dict]:
        """ניתוח צרכי מעבר מצב"""
        try:
            transition_needs = {}
            
            # בדיקת זמן במצב הנוכחי
            state_duration = current_state.duration.total_seconds()
            
            # מעבר אוטומטי אחרי זמן ארוך במצב אחד
            if state_duration > 3600:  # שעה במצב אחד
                if current_state.attention_state == AttentionState.FOCUSED:
                    transition_needs['target_attention'] = AttentionState.DIVIDED
                    transition_needs['trigger'] = "duration_based_switch"
            
            return transition_needs if transition_needs else None
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח צרכי מעבר: {e}")
            return None
    
    def _calculate_transition_energy_cost(self, current_state: ConsciousnessState,
                                        new_state: ConsciousnessState) -> float:
        """חישוב עלות אנרגטית של מעבר"""
        try:
            level_change = abs(current_state.consciousness_level.value - new_state.consciousness_level.value)
            attention_change = 1 if current_state.attention_state != new_state.attention_state else 0
            cognitive_change = 1 if current_state.cognitive_mode != new_state.cognitive_mode else 0
            
            total_cost = (level_change * 0.3) + (attention_change * 0.2) + (cognitive_change * 0.1)
            return min(1.0, total_cost)
            
        except Exception:
            return 0.5  # עלות ברירת מחדל
    
    def _calculate_overall_stability(self) -> float:
        """חישוב יציבות כוללת"""
        try:
            recent_transitions = list(self.transition_history)[-10:]
            if not recent_transitions:
                return 1.0
            
            successful_transitions = sum(1 for t in recent_transitions if t.successful)
            stability = successful_transitions / len(recent_transitions)
            
            return stability
            
        except Exception:
            return 0.5
    
    def _calculate_consciousness_complexity(self) -> float:
        """חישוב מורכבות התודעה"""
        try:
            current_state = self.state_manager.current_state
            
            # מורכבות לפי מספר פוקוסים
            focus_complexity = len(current_state.secondary_focuses) / self.config.max_attention_focuses
            
            # מורכבות לפי מטריקות
            metrics_complexity = (
                current_state.metrics.awareness_score +
                current_state.metrics.meta_awareness +
                current_state.metrics.integration_level
            ) / 3.0
            
            # מורכבות לפי רמת תודעה
            level_complexity = current_state.consciousness_level.value / 5.0
            
            total_complexity = (focus_complexity + metrics_complexity + level_complexity) / 3.0
            return min(1.0, total_complexity)
            
        except Exception:
            return 0.5
    
    def _calculate_israeli_adaptation(self) -> float:
        """חישוב הסתגלות תרבותית ישראלית"""
        try:
            israeli_patterns_count = sum(1 for p in self.detected_patterns 
                                       if 'israeli' in p.name.lower() or 'sabra' in p.name.lower())
            
            total_patterns = len(self.detected_patterns)
            if total_patterns == 0:
                return 0.0
            
            base_score = israeli_patterns_count / total_patterns
            
            # בונוס עבור שימוש בדפוסים ישראליים
            current_state = self.state_manager.current_state
            if (current_state.cognitive_mode == CognitiveMode.ANALYTICAL and
                current_state.attention_state == AttentionState.FOCUSED):
                base_score += 0.2  # בונוס לצבריות
            
            return min(1.0, base_score)
            
        except Exception:
            return 0.0
    
    def get_engine_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מנוע מצבי התודעה"""
        current_state = self.state_manager.current_state
        
        return {
            'is_running': self.is_running,
            'uptime': (datetime.now() - self.stats['start_time']).total_seconds(),
            'current_consciousness_level': current_state.consciousness_level.name,
            'current_attention_state': current_state.attention_state.value,
            'current_cognitive_mode': current_state.cognitive_mode.value,
            'current_emotional_state': current_state.emotional_state.value,
            'current_energy_level': current_state.energy_level.value,
            'state_transitions': self.performance_metrics['state_transitions'],
            'successful_transitions': self.stats['successful_transitions'],
            'failed_transitions': self.stats['failed_transitions'],
            'detected_patterns': len(self.detected_patterns),
            'stability_score': self._calculate_overall_stability(),
            'consciousness_complexity': self._calculate_consciousness_complexity(),
            'israeli_adaptation': self._calculate_israeli_adaptation(),
            'attention_overloads': self.performance_metrics['overload_events'],
            'recovery_events': self.performance_metrics['recovery_events']
        }


class AttentionManager:
    """מנהל קשב ופוקוס"""
    
    def __init__(self, config: StateConfiguration):
        self.config = config
        self.active_focuses: Dict[str, float] = {}
        self.focus_history: deque = deque(maxlen=50)
        self.is_running = False
    
    def start(self):
        self.is_running = True
    
    def stop(self):
        self.is_running = False
    
    def update_focus(self, target: str, intensity: float):
        """עדכון פוקוס קשב"""
        self.active_focuses[target] = intensity
        self.focus_history.append((target, intensity, datetime.now()))
    
    def get_efficiency_score(self) -> float:
        """חישוב יעילות קשב"""
        if not self.focus_history:
            return 0.0
        
        recent_focuses = list(self.focus_history)[-10:]
        avg_intensity = sum(focus[1] for focus in recent_focuses) / len(recent_focuses)
        
        return avg_intensity


class EnergyManager:
    """מנהל אנרגיה ועייפות"""
    
    def __init__(self, config: StateConfiguration):
        self.config = config
        self.current_energy = 1.0
        self.energy_history: deque = deque(maxlen=100)
        self.is_running = False
    
    def start(self):
        self.is_running = True
    
    def stop(self):
        self.is_running = False
    
    def update_energy(self, change: float):
        """עדכון רמת אנרגיה"""
        self.current_energy = max(0.0, min(1.0, self.current_energy + change))
        self.energy_history.append((self.current_energy, datetime.now()))
    
    def get_energy_analysis(self) -> Dict[str, Any]:
        """ניתוח מצב האנרגיה"""
        if not self.energy_history:
            return {'current_energy': self.current_energy}
        
        recent_energy = [e[0] for e in list(self.energy_history)[-20:]]
        avg_energy = sum(recent_energy) / len(recent_energy)
        
        return {
            'current_energy': self.current_energy,
            'average_energy': avg_energy,
            'energy_trend': 'increasing' if self.current_energy > avg_energy else 'decreasing'
        }