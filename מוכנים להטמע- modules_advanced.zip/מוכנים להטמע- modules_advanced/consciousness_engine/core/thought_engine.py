#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Thought Engine - מנוע מחשבות וקוגניציה
========================================

מנוע מחשבות מתקדם עם זרמי מחשבות דינמיים, תהליכים קוגניטיביים,
זיהוי דפוסים ותמיכה בחשיבה עברית וישראלית.

תכונות מרכזיות:
- זרמי מחשבות עם ניהול קשב דינמי
- 10 תהליכים קוגניטיביים שונים
- זיהוי ולמידת דפוסי חשיבה
- תמיכה בחשיבה עברית ותרבות ישראלית
- יצירת קשרים אסוציאטיביים
"""

import asyncio
import logging
import threading
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple, Callable
from collections import deque, defaultdict
import re

from ..models.thoughts import (
    ThoughtType, ThoughtIntensity, ThoughtState, CognitiveProcess,
    ThoughtContent, ThoughtConnection, Thought, ThoughtStream, ThoughtPattern
)
from ..models.config import ThoughtConfiguration


class ThoughtEngine:
    """מנוע מחשבות מתקדם עם זרמי תודעה ותהליכים קוגניטיביים"""
    
    def __init__(self, config: ThoughtConfiguration = None):
        """אתחול מנוע המחשבות"""
        self.config = config or ThoughtConfiguration()
        self.logger = logging.getLogger(__name__)
        
        # זרם המחשבות הראשי
        self.main_stream = ThoughtStream("Main Thought Stream")
        self.secondary_streams: Dict[str, ThoughtStream] = {}
        
        # מצב המנוע
        self.is_running = False
        self.processing_thread: Optional[threading.Thread] = None
        self.generation_thread: Optional[threading.Thread] = None
        
        # דפוסי חשיבה
        self.thought_patterns: Dict[str, ThoughtPattern] = {}
        self.pattern_history: deque = deque(maxlen=self.config.pattern_memory_size)
        
        # תהליכים קוגניטיביים פעילים
        self.active_processes: Dict[CognitiveProcess, float] = {}  # תהליך -> עוצמה
        
        # מטמון וביצועים
        self.association_cache: Dict[str, List[str]] = {}
        self.generation_queue: deque = deque()
        
        # סטטיסטיקות
        self.stats = {
            'thoughts_generated': 0,
            'thoughts_processed': 0,
            'patterns_detected': 0,
            'associations_created': 0,
            'cognitive_switches': 0,
            'hebrew_thoughts': 0,
            'creative_thoughts': 0,
            'analytical_thoughts': 0,
            'start_time': datetime.now()
        }
        
        # דפוסי חשיבה עבריים/ישראליים
        self.hebrew_thought_patterns = {
            'ספק': ThoughtType.REFLECTIVE,
            'בטח': ThoughtType.ANALYTICAL,
            'אולי': ThoughtType.INTUITIVE,
            'למה': ThoughtType.ANALYTICAL,
            'איך': ThoughtType.ANALYTICAL,
            'מה אם': ThoughtType.CREATIVE,
            'בעיני': ThoughtType.REFLECTIVE,
            'אני חושב': ThoughtType.REFLECTIVE,
            'נראה לי': ThoughtType.INTUITIVE,
            'ברור ש': ThoughtType.ANALYTICAL
        }
        
        # טריגרים לתהליכים קוגניטיביים
        self.cognitive_triggers = {
            CognitiveProcess.PERCEPTION: ['רואה', 'שומע', 'מרגיש', 'חש'],
            CognitiveProcess.ATTENTION: ['מתרכז', 'קשוב', 'שם לב'],
            CognitiveProcess.MEMORY_RETRIEVAL: ['זוכר', 'נזכר', 'היה לי'],
            CognitiveProcess.REASONING: ['כי', 'אם כן', 'לכן', 'בגלל'],
            CognitiveProcess.PLANNING: ['אתכנן', 'אעשה', 'נצטרך'],
            CognitiveProcess.DECISION_MAKING: ['אחליט', 'בוחר', 'מעדיף'],
            CognitiveProcess.PROBLEM_SOLVING: ['פותר', 'מוצא דרך', 'פתרון'],
            CognitiveProcess.LEARNING: ['למד', 'הבין', 'גילה'],
            CognitiveProcess.IMAGINATION: ['מדמיין', 'חולם', 'יוצר'],
            CognitiveProcess.EVALUATION: ['שופט', 'מעריך', 'בוחן']
        }
        
        # אתחול דפוסים בסיסיים
        self._init_basic_patterns()
        
        self.logger.info("מנוע המחשבות אותחל בהצלחה")
    
    def start(self) -> bool:
        """הפעלת מנוע המחשבות"""
        try:
            if self.is_running:
                self.logger.warning("מנוע המחשבות כבר פועל")
                return True
            
            self.is_running = True
            
            # הפעלת תהליכי רקע
            self.processing_thread = threading.Thread(target=self._processing_loop, daemon=True)
            self.processing_thread.start()
            
            if self.config.auto_generate_thoughts:
                self.generation_thread = threading.Thread(target=self._generation_loop, daemon=True)
                self.generation_thread.start()
            
            self.logger.info("מנוע המחשבות הופעל בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מנוע המחשבות: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת מנוע המחשבות"""
        try:
            self.is_running = False
            
            if self.processing_thread:
                self.processing_thread.join(timeout=5.0)
            if self.generation_thread:
                self.generation_thread.join(timeout=5.0)
            
            self.logger.info("מנוע המחשבות נעצר בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מנוע המחשבות: {e}")
            return False
    
    def create_thought(self, content: Any, thought_type: ThoughtType = ThoughtType.ANALYTICAL,
                      intensity: ThoughtIntensity = ThoughtIntensity.MODERATE,
                      context: Dict[str, Any] = None, stream_id: str = "main") -> str:
        """יצירת מחשבה חדשה"""
        try:
            # יצירת תוכן מחשבה
            thought_content = ThoughtContent(
                primary_content=content,
                content_type=type(content).__name__.lower(),
                language=self._detect_language(str(content))
            )
            
            # זיהוי מילות מפתח וקונספטים
            if isinstance(content, str):
                self._extract_keywords_and_concepts(thought_content, content)
                
                # זיהוי דפוס חשיבה עברי
                detected_type = self._detect_hebrew_thought_type(content)
                if detected_type:
                    thought_type = detected_type
            
            # יצירת המחשבה
            thought = Thought(
                content=thought_content,
                thought_type=thought_type,
                intensity=intensity,
                context=context or {}
            )
            
            # זיהוי תהליכים קוגניטיביים
            self._detect_cognitive_processes(thought, str(content))
            
            # הוספה לזרם המתאים
            target_stream = self.main_stream if stream_id == "main" else self.secondary_streams.get(stream_id)
            if target_stream:
                target_stream.add_thought(thought)
            
            # עדכון סטטיסטיקות
            self.stats['thoughts_generated'] += 1
            if thought_content.language in ['hebrew', 'mixed']:
                self.stats['hebrew_thoughts'] += 1
            if thought_type == ThoughtType.CREATIVE:
                self.stats['creative_thoughts'] += 1
            elif thought_type == ThoughtType.ANALYTICAL:
                self.stats['analytical_thoughts'] += 1
            
            self.logger.debug(f"נוצרה מחשבה חדשה: {thought.id}")
            return thought.id
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת מחשבה: {e}")
            return ""
    
    def process_thought_stream(self, input_text: str, context: Dict[str, Any] = None) -> List[str]:
        """עיבוד טקסט ויצירת זרם מחשבות"""
        try:
            thought_ids = []
            
            # פיצול למשפטים או יחידות חשיבה
            sentences = self._split_into_thought_units(input_text)
            
            for sentence in sentences:
                if len(sentence.strip()) > 3:  # התעלמות ממשפטים קצרים מדי
                    # זיהוי סוג המחשבה
                    thought_type = self._analyze_thought_type(sentence)
                    intensity = self._calculate_thought_intensity(sentence)
                    
                    # יצירת מחשבה
                    thought_id = self.create_thought(
                        content=sentence,
                        thought_type=thought_type,
                        intensity=intensity,
                        context=context
                    )
                    
                    if thought_id:
                        thought_ids.append(thought_id)
            
            # יצירת קשרים בין המחשבות
            self._create_thought_connections(thought_ids)
            
            return thought_ids
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד זרם מחשבות: {e}")
            return []
    
    def get_active_thoughts(self, stream_id: str = "main") -> List[Thought]:
        """קבלת המחשבות הפעילות בזרם"""
        try:
            target_stream = self.main_stream if stream_id == "main" else self.secondary_streams.get(stream_id)
            if target_stream:
                return target_stream.get_active_thoughts()
            return []
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מחשבות פעילות: {e}")
            return []
    
    def find_related_thoughts(self, thought_id: str, max_results: int = 10) -> List[Thought]:
        """מציאת מחשבות קשורות"""
        try:
            # חיפוש בזרם הראשי
            related = self.main_stream.find_related_thoughts(thought_id, max_results)
            
            # חיפוש בזרמים משניים
            for stream in self.secondary_streams.values():
                related.extend(stream.find_related_thoughts(thought_id, max_results // 2))
            
            # הסרת כפילויות ומיון
            unique_related = {t.id: t for t in related if t.id != thought_id}
            return list(unique_related.values())[:max_results]
            
        except Exception as e:
            self.logger.error(f"שגיאה במציאת מחשבות קשורות: {e}")
            return []
    
    def detect_thought_patterns(self) -> List[ThoughtPattern]:
        """זיהוי דפוסי חשיבה"""
        try:
            detected_patterns = []
            recent_thoughts = self.main_stream.get_active_thoughts()
            
            if len(recent_thoughts) < 3:
                return detected_patterns
            
            # בדיקת דפוסים קיימים
            for pattern in self.thought_patterns.values():
                match_score = pattern.matches_sequence(recent_thoughts)
                if match_score > self.config.pattern_threshold:
                    detected_patterns.append(pattern)
                    self.stats['patterns_detected'] += 1
            
            # זיהוי דפוסים חדשים
            new_patterns = self._discover_new_patterns(recent_thoughts)
            detected_patterns.extend(new_patterns)
            
            return detected_patterns
            
        except Exception as e:
            self.logger.error(f"שגיאה בזיהוי דפוסים: {e}")
            return []
    
    def create_secondary_stream(self, name: str, focus_theme: str = "") -> str:
        """יצירת זרם מחשבות משני"""
        try:
            stream_id = f"stream_{len(self.secondary_streams)}_{int(time.time())}"
            
            new_stream = ThoughtStream(
                id=stream_id,
                name=name
            )
            
            if focus_theme:
                new_stream.context = {'focus_theme': focus_theme}
            
            self.secondary_streams[stream_id] = new_stream
            
            self.logger.debug(f"נוצר זרם משני: {name}")
            return stream_id
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת זרם משני: {e}")
            return ""
    
    def merge_streams(self, stream1_id: str, stream2_id: str) -> bool:
        """מיזוג שני זרמי מחשבות"""
        try:
            stream1 = self.secondary_streams.get(stream1_id)
            stream2 = self.secondary_streams.get(stream2_id)
            
            if not stream1 or not stream2:
                return False
            
            # העברת מחשבות מזרם 2 לזרם 1
            for thought in stream2.get_active_thoughts():
                stream1.add_thought(thought)
            
            # מחיקת זרם 2
            del self.secondary_streams[stream2_id]
            
            self.logger.debug(f"מוזגו זרמים: {stream1_id} ו-{stream2_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה במיזוג זרמים: {e}")
            return False
    
    def get_cognitive_state(self) -> Dict[str, Any]:
        """קבלת המצב הקוגניטיבי הנוכחי"""
        try:
            active_thoughts = self.get_active_thoughts()
            
            # ניתוח תהליכים קוגניטיביים פעילים
            cognitive_processes = defaultdict(int)
            for thought in active_thoughts:
                for process in thought.cognitive_processes:
                    cognitive_processes[process.value] += 1
            
            # ניתוח סוגי מחשבות
            thought_types = defaultdict(int)
            for thought in active_thoughts:
                thought_types[thought.thought_type.value] += 1
            
            # חישוב מורכבות קוגניטיבית
            cognitive_complexity = len(cognitive_processes) * len(thought_types) / 10.0
            
            return {
                'active_thoughts_count': len(active_thoughts),
                'cognitive_processes': dict(cognitive_processes),
                'thought_types': dict(thought_types),
                'cognitive_complexity': min(1.0, cognitive_complexity),
                'stream_coherence': self.main_stream.coherence,
                'creativity_level': self.main_stream.creativity,
                'focus_level': self.main_stream.focus_level,
                'processing_speed': self._calculate_processing_speed(),
                'pattern_recognition_active': len(self.thought_patterns) > 0
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מצב קוגניטיבי: {e}")
            return {}
    
    def get_thought_insights(self) -> Dict[str, Any]:
        """קבלת תובנות על דפוסי החשיבה"""
        try:
            all_thoughts = []
            all_thoughts.extend(self.main_stream.thoughts.values())
            
            for stream in self.secondary_streams.values():
                all_thoughts.extend(stream.thoughts.values())
            
            # ניתוח דפוסים
            type_distribution = defaultdict(int)
            language_distribution = defaultdict(int)
            intensity_distribution = defaultdict(int)
            
            for thought in all_thoughts:
                type_distribution[thought.thought_type.value] += 1
                language_distribution[thought.content.language] += 1
                intensity_distribution[thought.intensity.value] += 1
            
            # מחשבה דומיננטית
            most_common_type = max(type_distribution.items(), key=lambda x: x[1]) if type_distribution else None
            
            return {
                'total_thoughts': len(all_thoughts),
                'active_thoughts': len(self.get_active_thoughts()),
                'streams_count': 1 + len(self.secondary_streams),
                'patterns_count': len(self.thought_patterns),
                'type_distribution': dict(type_distribution),
                'language_distribution': dict(language_distribution),
                'intensity_distribution': dict(intensity_distribution),
                'most_common_type': most_common_type[0] if most_common_type else None,
                'hebrew_thought_percentage': (self.stats['hebrew_thoughts'] / max(1, self.stats['thoughts_generated'])) * 100,
                'creativity_ratio': (self.stats['creative_thoughts'] / max(1, self.stats['analytical_thoughts'])),
                'processing_stats': self.stats.copy()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תובנות מחשבה: {e}")
            return {}
    
    def _processing_loop(self):
        """לולאת עיבוד רקע"""
        while self.is_running:
            try:
                # עיבוד זרם ראשי
                self.main_stream.process_stream()
                
                # עיבוד זרמים משניים
                for stream in self.secondary_streams.values():
                    stream.process_stream()
                
                # זיהוי דפוסים
                if self.config.enable_pattern_detection:
                    self.detect_thought_patterns()
                
                # עיבוד קשרים אסוציאטיביים
                self._process_associations()
                
                # ניקוי מטמון
                self._cleanup_caches()
                
                self.stats['thoughts_processed'] += 1
                time.sleep(1.0)
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת עיבוד מחשבות: {e}")
                time.sleep(5.0)
    
    def _generation_loop(self):
        """לולאת יצירת מחשבות אוטומטית"""
        while self.is_running:
            try:
                # יצירת מחשבות ספונטניות בהתבסס על דפוסים
                if len(self.main_stream.get_active_thoughts()) < self.config.max_active_thoughts:
                    self._generate_spontaneous_thought()
                
                time.sleep(self.config.generation_interval)
                
            except Exception as e:
                self.logger.error(f"שגיאה ביצירת מחשבות אוטומטית: {e}")
                time.sleep(30.0)
    
    def _detect_language(self, text: str) -> str:
        """זיהוי שפת הטקסט"""
        try:
            hebrew_chars = len(re.findall(r'[א-ת]', text))
            english_chars = len(re.findall(r'[a-zA-Z]', text))
            total_chars = hebrew_chars + english_chars
            
            if total_chars == 0:
                return "other"
            
            hebrew_ratio = hebrew_chars / total_chars
            
            if hebrew_ratio > 0.7:
                return "hebrew"
            elif hebrew_ratio > 0.3:
                return "mixed"
            else:
                return "english"
                
        except Exception:
            return "unknown"
    
    def _extract_keywords_and_concepts(self, thought_content: ThoughtContent, text: str):
        """חילוץ מילות מפתח וקונספטים"""
        try:
            # מילות מפתח בסיסיות (פשוט פיצול למילים)
            words = re.findall(r'[א-תa-zA-Z]+', text.lower())
            
            # סינון מילות עצירה עבריות בסיסיות
            stop_words = {'של', 'את', 'על', 'עם', 'אל', 'זה', 'זו', 'הוא', 'היא', 'אני', 'אתה', 'אתם'}
            keywords = [word for word in words if len(word) > 2 and word not in stop_words]
            
            thought_content.keywords.update(keywords[:10])  # לקיחת עד 10 מילות מפתח
            
            # זיהוי קונספטים בסיסי
            if any(word in text.lower() for word in ['אהבה', 'שמחה', 'עצב']):
                thought_content.concepts.add('emotions')
            if any(word in text.lower() for word in ['עבודה', 'משימה', 'פרויקט']):
                thought_content.concepts.add('work')
            if any(word in text.lower() for word in ['משפחה', 'חברים', 'אנשים']):
                thought_content.concepts.add('relationships')
                
        except Exception as e:
            self.logger.error(f"שגיאה בחילוץ מילות מפתח: {e}")
    
    def _detect_hebrew_thought_type(self, text: str) -> Optional[ThoughtType]:
        """זיהוי סוג מחשבה לפי דפוסים עבריים"""
        try:
            text_lower = text.lower()
            
            for pattern, thought_type in self.hebrew_thought_patterns.items():
                if pattern in text_lower:
                    return thought_type
            
            return None
            
        except Exception:
            return None
    
    def _detect_cognitive_processes(self, thought: Thought, text: str):
        """זיהוי תהליכים קוגניטיביים בטקסט"""
        try:
            text_lower = text.lower()
            
            for process, triggers in self.cognitive_triggers.items():
                for trigger in triggers:
                    if trigger in text_lower:
                        thought.add_cognitive_process(process)
                        break
                        
        except Exception as e:
            self.logger.error(f"שגיאה בזיהוי תהליכים קוגניטיביים: {e}")
    
    def _split_into_thought_units(self, text: str) -> List[str]:
        """פיצול טקסט ליחידות מחשבה"""
        try:
            # פיצול בסיסי לפי סימני פיסוק
            sentences = re.split(r'[.!?;]\s+', text)
            
            # פיצול נוסף לפי מילות חיבור
            thought_units = []
            for sentence in sentences:
                # פיצול לפי "אבל", "עם זאת", "בנוסף" וכו'
                sub_sentences = re.split(r'\s+(אבל|עם זאת|בנוסף|לעומת זאת|מצד שני)\s+', sentence)
                thought_units.extend([s.strip() for s in sub_sentences if s.strip()])
            
            return thought_units
            
        except Exception as e:
            self.logger.error(f"שגיאה בפיצול ליחידות מחשבה: {e}")
            return [text]
    
    def _analyze_thought_type(self, text: str) -> ThoughtType:
        """ניתוח סוג המחשבה"""
        try:
            text_lower = text.lower()
            
            # בדיקת דפוסים עבריים ראשית
            hebrew_type = self._detect_hebrew_thought_type(text)
            if hebrew_type:
                return hebrew_type
            
            # ניתוח לפי תוכן
            if any(word in text_lower for word in ['למה', 'איך', 'מתי', 'איפה']):
                return ThoughtType.ANALYTICAL
            elif any(word in text_lower for word in ['מדמיין', 'חולם', 'אולי', 'מה אם']):
                return ThoughtType.CREATIVE
            elif any(word in text_lower for word in ['מרגיש', 'רגש', 'אהבה', 'שמחה', 'עצב']):
                return ThoughtType.EMOTIONAL
            elif any(word in text_lower for word in ['אני חושב', 'בעיני', 'דעתי']):
                return ThoughtType.REFLECTIVE
            else:
                return ThoughtType.ANALYTICAL  # ברירת מחדל
                
        except Exception:
            return ThoughtType.ANALYTICAL
    
    def _calculate_thought_intensity(self, text: str) -> ThoughtIntensity:
        """חישוב עוצמת המחשבה"""
        try:
            # גורמים שמשפיעים על עוצמה
            intensity_score = 0
            
            # אורך הטקסט
            length_factor = min(1.0, len(text) / 100.0)
            intensity_score += length_factor * 0.3
            
            # סימני קריאה
            exclamation_count = text.count('!')
            intensity_score += min(0.4, exclamation_count * 0.1)
            
            # מילים רגשיות חזקות
            strong_words = ['מאוד', 'נורא', 'איום', 'מדהים', 'נפלא', 'חלאס']
            for word in strong_words:
                if word in text.lower():
                    intensity_score += 0.2
            
            # המרה לטווח 1-5
            intensity_level = max(1, min(5, int(intensity_score * 5) + 1))
            return ThoughtIntensity(intensity_level)
            
        except Exception:
            return ThoughtIntensity.MODERATE
    
    def _create_thought_connections(self, thought_ids: List[str]):
        """יצירת קשרים בין מחשבות"""
        try:
            for i, thought_id1 in enumerate(thought_ids):
                # קישור למחשבה הקודמת (זמני)
                if i > 0:
                    thought_id2 = thought_ids[i-1]
                    thought1 = self._find_thought_by_id(thought_id1)
                    if thought1:
                        thought1.add_connection(thought_id2, "temporal", 0.7)
                
                # קישור לפי תוכן דומה
                for j, thought_id2 in enumerate(thought_ids):
                    if i != j:
                        similarity = self._calculate_thought_similarity(thought_id1, thought_id2)
                        if similarity > self.config.association_strength_threshold:
                            thought1 = self._find_thought_by_id(thought_id1)
                            if thought1:
                                thought1.add_connection(thought_id2, "semantic", similarity)
                                self.stats['associations_created'] += 1
                                
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת קשרי מחשבות: {e}")
    
    def _find_thought_by_id(self, thought_id: str) -> Optional[Thought]:
        """מציאת מחשבה לפי מזהה"""
        try:
            # חיפוש בזרם הראשי
            if thought_id in self.main_stream.thoughts:
                return self.main_stream.thoughts[thought_id]
            
            # חיפוש בזרמים משניים
            for stream in self.secondary_streams.values():
                if thought_id in stream.thoughts:
                    return stream.thoughts[thought_id]
            
            return None
            
        except Exception:
            return None
    
    def _calculate_thought_similarity(self, thought_id1: str, thought_id2: str) -> float:
        """חישוב דמיון בין מחשבות"""
        try:
            thought1 = self._find_thought_by_id(thought_id1)
            thought2 = self._find_thought_by_id(thought_id2)
            
            if not thought1 or not thought2:
                return 0.0
            
            # דמיון במילות מפתח
            keywords1 = thought1.content.keywords
            keywords2 = thought2.content.keywords
            
            if keywords1 and keywords2:
                intersection = len(keywords1.intersection(keywords2))
                union = len(keywords1.union(keywords2))
                keyword_similarity = intersection / union if union > 0 else 0.0
            else:
                keyword_similarity = 0.0
            
            # דמיון בקונספטים
            concepts1 = thought1.content.concepts
            concepts2 = thought2.content.concepts
            
            if concepts1 and concepts2:
                concept_intersection = len(concepts1.intersection(concepts2))
                concept_union = len(concepts1.union(concepts2))
                concept_similarity = concept_intersection / concept_union if concept_union > 0 else 0.0
            else:
                concept_similarity = 0.0
            
            # דמיון בסוג המחשבה
            type_similarity = 1.0 if thought1.thought_type == thought2.thought_type else 0.0
            
            # חישוב דמיון כולל
            total_similarity = (
                keyword_similarity * 0.5 +
                concept_similarity * 0.3 +
                type_similarity * 0.2
            )
            
            return total_similarity
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב דמיון מחשבות: {e}")
            return 0.0
    
    def _init_basic_patterns(self):
        """אתחול דפוסי חשיבה בסיסיים"""
        try:
            # דפוס חשיבה אנליטית
            analytical_pattern = ThoughtPattern(
                name="Analytical Sequence",
                pattern_type="sequential",
                thought_sequence=[
                    ThoughtType.ANALYTICAL,
                    ThoughtType.ANALYTICAL,
                    ThoughtType.REFLECTIVE
                ],
                triggers=["למה", "איך", "מה הסיבה"]
            )
            self.thought_patterns[analytical_pattern.id] = analytical_pattern
            
            # דפוס חשיבה יצירתית
            creative_pattern = ThoughtPattern(
                name="Creative Flow",
                pattern_type="branching",
                thought_sequence=[
                    ThoughtType.CREATIVE,
                    ThoughtType.INTUITIVE,
                    ThoughtType.CREATIVE
                ],
                triggers=["מה אם", "אולי", "חולם"]
            )
            self.thought_patterns[creative_pattern.id] = creative_pattern
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול דפוסים: {e}")
    
    def _discover_new_patterns(self, recent_thoughts: List[Thought]) -> List[ThoughtPattern]:
        """גילוי דפוסי חשיבה חדשים"""
        try:
            new_patterns = []
            
            if len(recent_thoughts) < 3:
                return new_patterns
            
            # חיפוש רצפים חוזרים
            sequences = []
            for i in range(len(recent_thoughts) - 2):
                sequence = [
                    recent_thoughts[i].thought_type,
                    recent_thoughts[i+1].thought_type,
                    recent_thoughts[i+2].thought_type
                ]
                sequences.append(sequence)
            
            # זיהוי דפוסים חוזרים
            from collections import Counter
            sequence_counts = Counter(tuple(seq) for seq in sequences)
            
            for sequence, count in sequence_counts.items():
                if count >= 2:  # דפוס שחוזר לפחות פעמיים
                    pattern = ThoughtPattern(
                        name=f"Discovered Pattern {len(self.thought_patterns)}",
                        pattern_type="discovered",
                        thought_sequence=list(sequence),
                        frequency=count
                    )
                    new_patterns.append(pattern)
                    self.thought_patterns[pattern.id] = pattern
            
            return new_patterns
            
        except Exception as e:
            self.logger.error(f"שגיאה בגילוי דפוסים חדשים: {e}")
            return []
    
    def _generate_spontaneous_thought(self):
        """יצירת מחשבה ספונטנית"""
        try:
            # בחירת נושא רנדומלי
            themes = [
                "מה אני צריך לעשות היום?",
                "איך אני מרגיש עכשיו?",
                "מה למדתי לאחרונה?",
                "איך אני יכול להשתפר?",
                "מה חשוב לי באמת?"
            ]
            
            theme = random.choice(themes)
            
            # יצירת המחשבה
            self.create_thought(
                content=theme,
                thought_type=ThoughtType.REFLECTIVE,
                intensity=ThoughtIntensity.LOW,
                context={'source': 'spontaneous'}
            )
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת מחשבה ספונטנית: {e}")
    
    def _process_associations(self):
        """עיבוד קשרים אסוציאטיביים"""
        try:
            active_thoughts = self.get_active_thoughts()
            
            for thought in active_thoughts:
                # חיפוש קשרים פוטנציאליים
                for other_thought in active_thoughts:
                    if thought.id != other_thought.id:
                        similarity = self._calculate_thought_similarity(thought.id, other_thought.id)
                        
                        if similarity > 0.6:  # סף גבוה לקשרים אוטומטיים
                            # בדיקה אם הקשר כבר קיים
                            existing_connection = any(
                                conn.target_thought_id == other_thought.id 
                                for conn in thought.connections
                            )
                            
                            if not existing_connection:
                                thought.add_connection(
                                    other_thought.id, 
                                    "associative", 
                                    similarity
                                )
                                self.stats['associations_created'] += 1
                                
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד קשרים: {e}")
    
    def _cleanup_caches(self):
        """ניקוי מטמונים"""
        try:
            # ניקוי מטמון קשרים ישנים
            if len(self.association_cache) > 1000:
                # שמירה על 500 הפריטים האחרונים
                keys_to_remove = list(self.association_cache.keys())[:-500]
                for key in keys_to_remove:
                    del self.association_cache[key]
                    
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי מטמונים: {e}")
    
    def _calculate_processing_speed(self) -> float:
        """חישוב מהירות עיבוד מחשבות"""
        try:
            uptime = (datetime.now() - self.stats['start_time']).total_seconds()
            if uptime == 0:
                return 0.0
            
            thoughts_per_second = self.stats['thoughts_processed'] / uptime
            # נרמול לטווח 0-1
            return min(1.0, thoughts_per_second / 10.0)
            
        except Exception:
            return 0.0
    
    def get_engine_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מנוע המחשבות"""
        return {
            'is_running': self.is_running,
            'uptime': (datetime.now() - self.stats['start_time']).total_seconds(),
            'main_stream_active_thoughts': len(self.main_stream.get_active_thoughts()),
            'secondary_streams_count': len(self.secondary_streams),
            'total_patterns': len(self.thought_patterns),
            'thoughts_generated': self.stats['thoughts_generated'],
            'thoughts_processed': self.stats['thoughts_processed'],
            'patterns_detected': self.stats['patterns_detected'],
            'associations_created': self.stats['associations_created'],
            'hebrew_thoughts_percentage': (self.stats['hebrew_thoughts'] / max(1, self.stats['thoughts_generated'])) * 100,
            'creativity_ratio': self.stats['creative_thoughts'] / max(1, self.stats['analytical_thoughts']),
            'processing_speed': self._calculate_processing_speed()
        }