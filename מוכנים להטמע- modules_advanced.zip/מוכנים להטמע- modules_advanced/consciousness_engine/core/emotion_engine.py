#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Emotion Engine - מנוע רגשות מתקדם
=================================

מנוע רגשות עוצמתי עם 15 רגשות בסיסיים, עירוב רגשי דינמי,
מטריצות אינטראקציה ותמיכה בתרבות הישראלית והעברית.

תכונות מרכזיות:
- 15 רגשות בסיסיים עם עוצמות דינמיות
- עירוב רגשי חכם ואוטומטי
- זיכרון רגשי וקשרים
- תמיכה בעברית ובתרבות הישראלית
- ויסות רגשי אוטומטי
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple
import json
import threading
import time

from ..models.emotions import (
    EmotionType, EmotionIntensity, EmotionState, 
    EmotionInteractionMatrix, EmotionBlend, EmotionSystem
)
from ..models.config import EmotionConfiguration


class EmotionEngine:
    """מנוע רגשות מתקדם עם יכולות למידה והסתגלות"""
    
    def __init__(self, config: EmotionConfiguration = None):
        """אתחול מנוע הרגשות"""
        self.config = config or EmotionConfiguration()
        self.logger = logging.getLogger(__name__)
        
        # מערכת הרגשות המרכזית
        self.emotion_system = EmotionSystem()
        
        # מצב המנוע
        self.is_running = False
        self.processing_thread: Optional[threading.Thread] = None
        
        # מטמון וביצועים
        self.emotion_cache: Dict[str, Any] = {}
        self.cache_ttl = timedelta(minutes=5)
        self.last_cache_cleanup = datetime.now()
        
        # סטטיסטיקות ומטריקות
        self.stats = {
            'emotions_processed': 0,
            'blends_created': 0,
            'regulations_performed': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'start_time': datetime.now()
        }
        
        # הגדרות תרבותיות עבריות/ישראליות
        self.hebrew_emotion_mappings = {
            'שמחה': EmotionType.JOY,
            'עצב': EmotionType.SADNESS,
            'כעס': EmotionType.ANGER,
            'פחד': EmotionType.FEAR,
            'תדהמה': EmotionType.SURPRISE,
            'גועל': EmotionType.DISGUST,
            'בושה': EmotionType.SHAME,
            'אשמה': EmotionType.GUILT,
            'גאווה': EmotionType.PRIDE,
            'קנאה': EmotionType.ENVY,
            'תסכול': EmotionType.FRUSTRATION,
            'התרגשות': EmotionType.EXCITEMENT,
            'רגיעה': EmotionType.CALMNESS,
            'דכאון': EmotionType.MELANCHOLY,
            'שלווה': EmotionType.CONTENTMENT
        }
        
        # ביטויים תרבותיים ישראליים
        self.israeli_expressions = {
            'אח שלי': (EmotionType.JOY, 0.6),
            'איזה כיף': (EmotionType.JOY, 0.8),
            'מה פתאום': (EmotionType.SURPRISE, 0.7),
            'איזה חבל': (EmotionType.SADNESS, 0.6),
            'בלגן': (EmotionType.FRUSTRATION, 0.5),
            'מגניב': (EmotionType.JOY, 0.7),
            'לא נורא': (EmotionType.CALMNESS, 0.5),
            'יופי': (EmotionType.JOY, 0.6),
            'חלאס': (EmotionType.FRUSTRATION, 0.8),
            'בסדר גמור': (EmotionType.CONTENTMENT, 0.7)
        }
        
        self.logger.info("מנוע הרגשות אותחל בהצלחה")
    
    def start(self) -> bool:
        """הפעלת מנוע הרגשות"""
        try:
            if self.is_running:
                self.logger.warning("מנוע הרגשות כבר פועל")
                return True
                
            self.is_running = True
            self.processing_thread = threading.Thread(target=self._processing_loop, daemon=True)
            self.processing_thread.start()
            
            self.logger.info("מנוע הרגשות הופעל בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מנוע הרגשות: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת מנוע הרגשות"""
        try:
            self.is_running = False
            if self.processing_thread:
                self.processing_thread.join(timeout=5.0)
                
            self.logger.info("מנוע הרגשות נעצר בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מנוע הרגשות: {e}")
            return False
    
    def process_emotion(self, emotion_type: EmotionType, intensity: float,
                       context: Dict[str, Any] = None, source: str = "unknown") -> str:
        """עיבוד רגש חדש במערכת"""
        try:
            # יצירת מזהה רגש
            emotion_id = self.emotion_system.add_emotion(
                emotion_type=emotion_type,
                intensity=intensity,
                context=context or {},
                source=source
            )
            
            # עדכון סטטיסטיקות
            self.stats['emotions_processed'] += 1
            
            # בדיקה אם נדרש ויסות רגשי
            if self.config.auto_regulation:
                self._check_emotion_regulation()
            
            # עדכון מטמון
            self._update_emotion_cache(emotion_id, emotion_type, intensity)
            
            self.logger.debug(f"רגש {emotion_type.value} עובד בעוצמה {intensity}")
            return emotion_id
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד רגש: {e}")
            return ""
    
    def process_hebrew_text(self, text: str) -> List[Tuple[EmotionType, float]]:
        """עיבוד טקסט עברי וזיהוי רגשות"""
        detected_emotions = []
        text_lower = text.lower()
        
        try:
            # בדיקת מיפויים עבריים ישירים
            for hebrew_word, emotion_type in self.hebrew_emotion_mappings.items():
                if hebrew_word in text_lower:
                    detected_emotions.append((emotion_type, 0.7))
            
            # בדיקת ביטויים ישראליים
            for expression, (emotion_type, intensity) in self.israeli_expressions.items():
                if expression in text_lower:
                    detected_emotions.append((emotion_type, intensity))
            
            # ניתוח טונאליות בסיסי לעברית
            positive_words = ['טוב', 'יפה', 'נהדר', 'מעולה', 'כיף', 'אהבה', 'שמח']
            negative_words = ['רע', 'גרוע', 'נורא', 'איום', 'עצוב', 'כועס', 'מתוסכל']
            
            positive_count = sum(1 for word in positive_words if word in text_lower)
            negative_count = sum(1 for word in negative_words if word in text_lower)
            
            if positive_count > negative_count:
                detected_emotions.append((EmotionType.JOY, 0.5))
            elif negative_count > positive_count:
                detected_emotions.append((EmotionType.SADNESS, 0.5))
            
            # עיבוד הרגשות שזוהו
            for emotion_type, intensity in detected_emotions:
                self.process_emotion(emotion_type, intensity, 
                                   context={'source': 'hebrew_text', 'text': text[:100]})
            
            return detected_emotions
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד טקסט עברי: {e}")
            return []
    
    def create_emotion_blend(self, emotion_ids: List[str], 
                           blend_name: str = "") -> Optional[str]:
        """יצירת עירוב רגשי מרגשות קיימים"""
        try:
            if len(emotion_ids) < 2:
                self.logger.warning("נדרשים לפחות 2 רגשות ליצירת עירוב")
                return None
            
            # קבלת הרגשות מהמערכת
            emotions = []
            for emotion_id in emotion_ids:
                emotion = self.emotion_system.get_emotion(emotion_id)
                if emotion:
                    emotions.append(emotion)
            
            if len(emotions) < 2:
                self.logger.warning("לא נמצאו מספיק רגשות תקפים לעירוב")
                return None
            
            # יצירת העירוב
            blend_id = self.emotion_system.create_blend(
                emotion_ids=emotion_ids,
                blend_name=blend_name or f"blend_{int(time.time())}"
            )
            
            if blend_id:
                self.stats['blends_created'] += 1
                self.logger.debug(f"נוצר עירוב רגשי: {blend_id}")
            
            return blend_id
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת עירוב רגשי: {e}")
            return None
    
    def get_current_emotional_state(self) -> Dict[str, Any]:
        """קבלת המצב הרגשי הנוכחי"""
        try:
            active_emotions = self.emotion_system.get_active_emotions()
            dominant_emotion = self.emotion_system.get_dominant_emotion()
            
            # חישוב ממוצעי רגשות
            if active_emotions:
                avg_intensity = sum(e.intensity.value for e in active_emotions) / len(active_emotions)
                emotion_types = [e.emotion_type.value for e in active_emotions]
            else:
                avg_intensity = 0.0
                emotion_types = []
            
            return {
                'dominant_emotion': dominant_emotion.emotion_type.value if dominant_emotion else None,
                'dominant_intensity': dominant_emotion.intensity.value if dominant_emotion else 0.0,
                'active_emotions_count': len(active_emotions),
                'average_intensity': avg_intensity,
                'emotion_types': emotion_types,
                'emotional_complexity': len(set(emotion_types)),
                'last_updated': datetime.now().isoformat(),
                'emotional_stability': self._calculate_emotional_stability()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מצב רגשי: {e}")
            return {}
    
    def regulate_emotions(self, target_intensity: float = 0.5) -> bool:
        """ויסות רגשי ידני"""
        try:
            regulated_count = 0
            active_emotions = self.emotion_system.get_active_emotions()
            
            for emotion in active_emotions:
                if emotion.intensity.value > self.config.regulation_threshold:
                    # הפחתת עוצמה בהדרגה
                    new_intensity = max(
                        target_intensity,
                        emotion.intensity.value - self.config.regulation_speed
                    )
                    
                    # עדכון הרגש
                    emotion.intensity = EmotionIntensity(new_intensity)
                    regulated_count += 1
            
            if regulated_count > 0:
                self.stats['regulations_performed'] += 1
                self.logger.debug(f"בוצע ויסות ל-{regulated_count} רגשות")
            
            return regulated_count > 0
            
        except Exception as e:
            self.logger.error(f"שגיאה בויסות רגשי: {e}")
            return False
    
    def add_emotional_memory(self, emotion_id: str, memory_content: str,
                           importance: float = 0.5) -> bool:
        """הוספת זיכרון רגשי"""
        try:
            emotion = self.emotion_system.get_emotion(emotion_id)
            if not emotion:
                return False
            
            # הוספת זיכרון לרגש
            emotion.add_memory(memory_content, importance)
            
            self.logger.debug(f"נוסף זיכרון רגשי לרגש {emotion_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת זיכרון רגשי: {e}")
            return False
    
    def get_emotion_insights(self) -> Dict[str, Any]:
        """קבלת תובנות על דפוסי הרגשות"""
        try:
            active_emotions = self.emotion_system.get_active_emotions()
            all_emotions = self.emotion_system.get_all_emotions()
            
            # ניתוח דפוסים
            emotion_frequency = {}
            for emotion in all_emotions:
                emotion_type = emotion.emotion_type.value
                emotion_frequency[emotion_type] = emotion_frequency.get(emotion_type, 0) + 1
            
            # רגש דומיננטי לאורך זמן
            most_frequent = max(emotion_frequency.items(), key=lambda x: x[1]) if emotion_frequency else None
            
            # חישוב יציבות רגשית
            stability = self._calculate_emotional_stability()
            
            return {
                'total_emotions': len(all_emotions),
                'active_emotions': len(active_emotions),
                'most_frequent_emotion': most_frequent[0] if most_frequent else None,
                'emotion_frequency': emotion_frequency,
                'emotional_stability': stability,
                'processing_stats': self.stats.copy(),
                'hebrew_emotions_detected': self._count_hebrew_emotions(),
                'cultural_adaptation_score': self._calculate_cultural_score()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תובנות רגשות: {e}")
            return {}
    
    def _processing_loop(self):
        """לולאת עיבוד רקע למנוע הרגשות"""
        while self.is_running:
            try:
                # עיבוד ויסות רגשי אוטומטי
                if self.config.auto_regulation:
                    self._check_emotion_regulation()
                
                # ניקוי מטמון
                if datetime.now() - self.last_cache_cleanup > self.cache_ttl:
                    self._cleanup_cache()
                
                # עיבוד אינטראקציות רגשיות
                self._process_emotion_interactions()
                
                # עיבוד דעיכת רגשות
                self._process_emotion_decay()
                
                # המתנה קצרה
                time.sleep(1.0)
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת עיבוד רגשות: {e}")
                time.sleep(5.0)
    
    def _check_emotion_regulation(self):
        """בדיקה אם נדרש ויסות רגשי"""
        try:
            active_emotions = self.emotion_system.get_active_emotions()
            high_intensity_emotions = [
                e for e in active_emotions 
                if e.intensity.value > self.config.regulation_threshold
            ]
            
            if len(high_intensity_emotions) > self.config.max_concurrent_emotions:
                self.regulate_emotions()
                
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת ויסות רגשי: {e}")
    
    def _process_emotion_interactions(self):
        """עיבוד אינטראקציות בין רגשות"""
        try:
            if not self.config.enable_emotion_interactions:
                return
                
            active_emotions = self.emotion_system.get_active_emotions()
            if len(active_emotions) < 2:
                return
            
            # בדיקת אינטראקציות זוגיות
            for i, emotion1 in enumerate(active_emotions):
                for emotion2 in active_emotions[i+1:]:
                    interaction_strength = self.emotion_system.interaction_matrix.get_interaction(
                        emotion1.emotion_type, emotion2.emotion_type
                    )
                    
                    if abs(interaction_strength) > 0.5:
                        # יצירת עירוב אוטומטי אם האינטראקציה חזקה
                        if interaction_strength > 0.7:
                            self.create_emotion_blend([emotion1.id, emotion2.id])
                            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד אינטראקציות רגשיות: {e}")
    
    def _process_emotion_decay(self):
        """עיבוד דעיכת רגשות לאורך זמן"""
        try:
            active_emotions = self.emotion_system.get_active_emotions()
            
            for emotion in active_emotions:
                # חישוב דעיכה
                time_since_creation = datetime.now() - emotion.timestamp
                decay_factor = self.config.emotion_decay_rate * (time_since_creation.seconds / 3600)
                
                # הפחתת עוצמה
                new_intensity = max(0.0, emotion.intensity.value - decay_factor)
                emotion.intensity = EmotionIntensity(new_intensity)
                
                # הסרת רגש אם העוצמה נמוכה מדי
                if new_intensity < 0.1:
                    emotion.state = EmotionState.FADED
                    
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד דעיכת רגשות: {e}")
    
    def _calculate_emotional_stability(self) -> float:
        """חישוב יציבות רגשית"""
        try:
            active_emotions = self.emotion_system.get_active_emotions()
            if not active_emotions:
                return 1.0
            
            # חישוב שונות בעוצמות
            intensities = [e.intensity.value for e in active_emotions]
            if len(intensities) == 1:
                return 1.0
            
            mean_intensity = sum(intensities) / len(intensities)
            variance = sum((x - mean_intensity) ** 2 for x in intensities) / len(intensities)
            
            # יציבות גבוהה = שונות נמוכה
            stability = max(0.0, 1.0 - variance)
            return stability
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב יציבות רגשית: {e}")
            return 0.5
    
    def _count_hebrew_emotions(self) -> int:
        """ספירת רגשות שזוהו מטקסט עברי"""
        count = 0
        for emotion in self.emotion_system.get_all_emotions():
            if emotion.context.get('source') == 'hebrew_text':
                count += 1
        return count
    
    def _calculate_cultural_score(self) -> float:
        """חישוב ציון הסתגלות תרבותית"""
        try:
            hebrew_emotions = self._count_hebrew_emotions()
            total_emotions = len(self.emotion_system.get_all_emotions())
            
            if total_emotions == 0:
                return 0.0
            
            # ציון בסיס לפי רגשות עבריים
            base_score = min(1.0, hebrew_emotions / max(1, total_emotions) * 2)
            
            # בונוס עבור שימוש בביטויים ישראליים
            israeli_expressions_used = 0
            for emotion in self.emotion_system.get_all_emotions():
                if any(expr in emotion.context.get('text', '') 
                      for expr in self.israeli_expressions.keys()):
                    israeli_expressions_used += 1
            
            expression_bonus = min(0.3, israeli_expressions_used / max(1, total_emotions))
            
            return min(1.0, base_score + expression_bonus)
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב ציון תרבותי: {e}")
            return 0.0
    
    def _update_emotion_cache(self, emotion_id: str, emotion_type: EmotionType, intensity: float):
        """עדכון מטמון הרגשות"""
        try:
            cache_key = f"{emotion_type.value}_{int(intensity * 10)}"
            self.emotion_cache[cache_key] = {
                'emotion_id': emotion_id,
                'timestamp': datetime.now(),
                'access_count': self.emotion_cache.get(cache_key, {}).get('access_count', 0) + 1
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מטמון רגשות: {e}")
    
    def _cleanup_cache(self):
        """ניקוי מטמון רגשות"""
        try:
            current_time = datetime.now()
            expired_keys = []
            
            for key, data in self.emotion_cache.items():
                if current_time - data['timestamp'] > self.cache_ttl:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.emotion_cache[key]
            
            self.last_cache_cleanup = current_time
            
            if expired_keys:
                self.logger.debug(f"נוקו {len(expired_keys)} פריטים מהמטמון")
                
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי מטמון: {e}")
    
    def export_emotional_data(self) -> Dict[str, Any]:
        """ייצוא נתוני רגשות למטרות גיבוי או ניתוח"""
        try:
            return {
                'emotion_system_data': self.emotion_system.serialize(),
                'config': self.config.serialize(),
                'stats': self.stats,
                'hebrew_mappings': self.hebrew_emotion_mappings,
                'israeli_expressions': self.israeli_expressions,
                'cache_size': len(self.emotion_cache),
                'export_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בייצוא נתוני רגשות: {e}")
            return {}
    
    def get_engine_status(self) -> Dict[str, Any]:
        """קבלת סטטוס מנוע הרגשות"""
        return {
            'is_running': self.is_running,
            'uptime': (datetime.now() - self.stats['start_time']).total_seconds(),
            'emotions_processed': self.stats['emotions_processed'],
            'blends_created': self.stats['blends_created'],
            'regulations_performed': self.stats['regulations_performed'],
            'cache_size': len(self.emotion_cache),
            'active_emotions': len(self.emotion_system.get_active_emotions()),
            'total_emotions': len(self.emotion_system.get_all_emotions()),
            'emotional_stability': self._calculate_emotional_stability(),
            'cultural_adaptation': self._calculate_cultural_score()
        }