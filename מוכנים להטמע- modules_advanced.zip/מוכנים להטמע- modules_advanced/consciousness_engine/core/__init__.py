#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Consciousness Engine - Core Package
=====================================

מנועי הליבה עבור מנוע התודעה המתקדם

מנועים זמינים:
- EmotionEngine: מנוע רגשות מתקדם עם 15 רגשות ועירוב דינמי
- MemoryEngine: מנוע זיכרון 5 שכבות עם איחוד אוטומטי
- ThoughtEngine: מנוע מחשבות וקוגניציה עם זרמי תודעה
- StateEngine: מנוע מצבי תודעה עם 6 רמות מודעות
- ConsciousnessCore: המנוע המרכזי המאחד הכל עם אינטגרציה מלאה
"""

from .emotion_engine import EmotionEngine
from .memory_engine import MemoryEngine
from .thought_engine import ThoughtEngine
from .state_engine import StateEngine, AttentionManager, EnergyManager
from .consciousness_core import ConsciousnessCore, InterEngineCommunication

__all__ = [
    'EmotionEngine',
    'MemoryEngine', 
    'ThoughtEngine',
    'StateEngine',
    'AttentionManager',
    'EnergyManager',
    'ConsciousnessCore',
    'InterEngineCommunication'
]

__version__ = "2.0.0-MONSTER"
__author__ = "Effi-AI Consciousness Team"