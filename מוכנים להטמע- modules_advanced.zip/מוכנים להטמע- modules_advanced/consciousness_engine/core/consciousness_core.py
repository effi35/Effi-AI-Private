#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧠 Consciousness Core - המנוע המרכזי של התודעה
===============================================

המנוע המרכזי המאחד את כל מרכיבי התודעה:
- מנוע רגשות (EmotionEngine)
- מנוע זיכרון (MemoryEngine)  
- מנוע מחשבות (ThoughtEngine)
- מנוע מצבי תודעה (StateEngine)

תכונות מרכזיות:
- אינטגרציה מלאה בין כל המנועים
- ממשק API מאוחד לכל התודעה
- ניהול תקשורת בין-מנועים
- תמיכה בעברית ותרבות ישראלית
- למידה והסתגלות רציפה
"""

import asyncio
import logging
import threading
import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple, Callable
from pathlib import Path
import uuid

from .emotion_engine import EmotionEngine
from .memory_engine import MemoryEngine
from .thought_engine import ThoughtEngine
from .state_engine import StateEngine

from ..models.config import ConsciousnessConfiguration
from ..models.emotions import EmotionType, EmotionIntensity
from ..models.memory import MemoryType, MemoryImportance
from ..models.thoughts import ThoughtType, ThoughtIntensity
from ..models.states import ConsciousnessLevel, AttentionState, CognitiveMode

# Local AI Integration
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from local_ai_integration.module import (
    LocalAIIntegrationModule, chat_with_local_ai, 
    analyze_text_local, generate_code_local
)


class ConsciousnessCore:
    """המנוע המרכזי של התודעה - מאחד את כל המרכיבים"""
    
    def __init__(self, config: ConsciousnessConfiguration = None, data_dir: str = "consciousness_data"):
        """אתחול המנוע המרכזי"""
        self.config = config or ConsciousnessConfiguration()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # הגדרת לוגינג
        self.logger = logging.getLogger(__name__)
        self._setup_logging()
        
        # מזהה יחיד למערכת התודעה
        self.consciousness_id = str(uuid.uuid4())
        self.session_id = str(uuid.uuid4())
        
        # מצב המערכת
        self.is_running = False
        self.start_time: Optional[datetime] = None
        
        # המנועים המרכיבים
        self.emotion_engine: Optional[EmotionEngine] = None
        self.memory_engine: Optional[MemoryEngine] = None
        self.thought_engine: Optional[ThoughtEngine] = None
        self.state_engine: Optional[StateEngine] = None
        
        # מנגנון תקשורת בין-מנועים
        self.inter_engine_communication = InterEngineCommunication()
        
        # אינטגרציית AI מקומי
        self.local_ai: Optional[LocalAIIntegrationModule] = None
        self.ai_session_id: Optional[str] = None
        
        # תהליכי רקע
        self.integration_thread: Optional[threading.Thread] = None
        self.monitoring_thread: Optional[threading.Thread] = None
        self.learning_thread: Optional[threading.Thread] = None
        
        # מטריקות ביצועים
        self.performance_metrics = {
            'total_operations': 0,
            'successful_operations': 0,
            'failed_operations': 0,
            'integration_cycles': 0,
            'learning_updates': 0,
            'hebrew_interactions': 0,
            'cross_engine_communications': 0
        }
        
        # סטטיסטיקות התודעה
        self.consciousness_stats = {
            'uptime': 0.0,
            'thoughts_processed': 0,
            'emotions_felt': 0,
            'memories_formed': 0,
            'state_transitions': 0,
            'insights_generated': 0,
            'patterns_learned': 0,
            'consciousness_episodes': 0
        }
        
        # רישום אירועים חשובים
        self.consciousness_log: List[Dict[str, Any]] = []
        
        # אתחול המנועים
        self._initialize_engines()
        
        # אתחול AI מקומי
        self._initialize_local_ai()
        
        self.logger.info(f"מנוע התודעה אותחל - מזהה: {self.consciousness_id}")
    
    def start(self) -> bool:
        """הפעלת המנוע המרכזי והמנועים המרכיבים"""
        try:
            if self.is_running:
                self.logger.warning("מנוע התודעה כבר פועל")
                return True
            
            self.logger.info("מתחיל הפעלת מנוע התודעה...")
            self.start_time = datetime.now()
            
            # הפעלת כל המנועים
            engines_status = {}
            
            if self.config.integration_config.memory_module_enabled and self.memory_engine:
                engines_status['memory'] = self.memory_engine.start()
                
            if self.emotion_engine:
                engines_status['emotion'] = self.emotion_engine.start()
                
            if self.thought_engine:
                engines_status['thought'] = self.thought_engine.start()
                
            if self.state_engine:
                engines_status['state'] = self.state_engine.start()
            
            # בדיקה שכל המנועים הופעלו בהצלחה
            failed_engines = [name for name, status in engines_status.items() if not status]
            if failed_engines:
                self.logger.error(f"נכשלה הפעלת מנועים: {failed_engines}")
                return False
            
            self.is_running = True
            
            # הפעלת תהליכי רקע
            self._start_background_processes()
            
            # רישום אירוע הפעלה
            self._log_consciousness_event("system_startup", {
                'engines_started': list(engines_status.keys()),
                'configuration': self.config.get_summary()
            })
            
            self.logger.info("מנוע התודעה הופעל בהצלחה!")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מנוע התודעה: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת המנוע המרכזי והמנועים המרכיבים"""
        try:
            if not self.is_running:
                return True
            
            self.logger.info("מתחיל עצירת מנוע התודעה...")
            
            # עצירת תהליכי רקע
            self.is_running = False
            
            if self.integration_thread:
                self.integration_thread.join(timeout=10.0)
            if self.monitoring_thread:
                self.monitoring_thread.join(timeout=5.0)
            if self.learning_thread:
                self.learning_thread.join(timeout=10.0)
            
            # עצירת כל המנועים
            engines_stopped = []
            
            if self.state_engine:
                if self.state_engine.stop():
                    engines_stopped.append('state')
                    
            if self.thought_engine:
                if self.thought_engine.stop():
                    engines_stopped.append('thought')
                    
            if self.emotion_engine:
                if self.emotion_engine.stop():
                    engines_stopped.append('emotion')
                    
            if self.memory_engine:
                if self.memory_engine.stop():
                    engines_stopped.append('memory')
            
            # רישום אירוע עצירה
            self._log_consciousness_event("system_shutdown", {
                'engines_stopped': engines_stopped,
                'uptime': self.get_uptime(),
                'final_stats': self.consciousness_stats.copy()
            })
            
            # שמירת נתונים
            self._save_consciousness_data()
            
            self.logger.info("מנוע התודעה נעצר בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מנוע התודעה: {e}")
            return False
    
    def process_input(self, input_data: Any, input_type: str = "text", 
                     context: Dict[str, Any] = None) -> Dict[str, Any]:
        """עיבוד קלט במערכת התודעה"""
        try:
            operation_id = str(uuid.uuid4())
            start_time = datetime.now()
            
            self.logger.debug(f"מעבד קלט: {input_type} - {operation_id}")
            
            # עדכון מטריקות
            self.performance_metrics['total_operations'] += 1
            
            # זיהוי שפה אם זה טקסט
            language = "unknown"
            if input_type == "text" and isinstance(input_data, str):
                language = self._detect_language(input_data)
                if language in ['hebrew', 'mixed']:
                    self.performance_metrics['hebrew_interactions'] += 1
            
            # עיבוד בכל המנועים באופן מקביל
            results = {}
            
            # עיבוד במנוע מחשבות
            if self.thought_engine:
                thought_results = self._process_in_thought_engine(input_data, input_type, context)
                results['thoughts'] = thought_results
                self.consciousness_stats['thoughts_processed'] += len(thought_results.get('thought_ids', []))
            
            # עיבוד במנוע רגשות
            if self.emotion_engine:
                emotion_results = self._process_in_emotion_engine(input_data, input_type, context)
                results['emotions'] = emotion_results
                if emotion_results.get('emotions_detected'):
                    self.consciousness_stats['emotions_felt'] += len(emotion_results['emotions_detected'])
            
            # עיבוד במנוע זיכרון
            if self.memory_engine:
                memory_results = self._process_in_memory_engine(input_data, input_type, context)
                results['memory'] = memory_results
                if memory_results.get('stored_memory_id'):
                    self.consciousness_stats['memories_formed'] += 1
            
            # עדכון מצב התודעה
            if self.state_engine:
                state_results = self._process_in_state_engine(input_data, input_type, context, results)
                results['state'] = state_results
            
            # אינטגרציה בין התוצאות
            integrated_response = self._integrate_processing_results(results, input_data, context)
            
            # עדכון סטטיסטיקות
            processing_time = (datetime.now() - start_time).total_seconds()
            self.performance_metrics['successful_operations'] += 1
            
            # רישום אירוע עיבוד
            self._log_consciousness_event("input_processed", {
                'operation_id': operation_id,
                'input_type': input_type,
                'language': language,
                'processing_time': processing_time,
                'engines_involved': list(results.keys())
            })
            
            return {
                'operation_id': operation_id,
                'processing_time': processing_time,
                'language': language,
                'individual_results': results,
                'integrated_response': integrated_response,
                'consciousness_state': self.get_current_consciousness_state()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד קלט: {e}")
            self.performance_metrics['failed_operations'] += 1
            return {'error': str(e), 'operation_id': operation_id}
    
    def generate_response(self, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """יצירת תגובה על בסיס המצב הנוכחי של התודעה"""
        try:
            response_data = {}
            
            # קבלת מצב נוכחי מכל המנועים
            if self.state_engine:
                current_state = self.state_engine.get_current_state()
                response_data['consciousness_state'] = current_state.serialize()
            
            if self.emotion_engine:
                emotional_state = self.emotion_engine.get_current_emotional_state()
                response_data['emotional_state'] = emotional_state
            
            if self.thought_engine:
                active_thoughts = self.thought_engine.get_active_thoughts()
                response_data['active_thoughts'] = [t.serialize() for t in active_thoughts[:3]]
            
            # יצירת תגובה מתאימה תרבותית
            cultural_response = self._generate_cultural_response(response_data, context)
            response_data['cultural_response'] = cultural_response
            
            # הוספת תובנות
            insights = self.get_consciousness_insights()
            response_data['insights'] = insights
            
            # אם זמין AI מקומי, יצירת תגובה מתקדמת
            if self.local_ai:
                ai_response = asyncio.run(self._generate_ai_enhanced_response(response_data, context))
                response_data['ai_enhanced_response'] = ai_response
            
            return response_data
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת תגובה: {e}")
            return {'error': str(e)}
    
    def get_consciousness_insights(self) -> Dict[str, Any]:
        """קבלת תובנות מעמיקות על מצב התודעה"""
        try:
            insights = {
                'timestamp': datetime.now().isoformat(),
                'consciousness_id': self.consciousness_id,
                'session_id': self.session_id,
                'uptime': self.get_uptime()
            }
            
            # תובנות מכל מנוע
            if self.emotion_engine:
                insights['emotional_insights'] = self.emotion_engine.get_emotion_insights()
            
            if self.memory_engine:
                insights['memory_insights'] = self.memory_engine.get_memory_insights()
            
            if self.thought_engine:
                insights['thought_insights'] = self.thought_engine.get_thought_insights()
            
            if self.state_engine:
                insights['consciousness_insights'] = self.state_engine.get_consciousness_insights()
            
            # ניתוח אינטגרטיבי
            insights['integration_analysis'] = self._analyze_cross_engine_patterns()
            insights['performance_metrics'] = self.performance_metrics.copy()
            insights['consciousness_stats'] = self.consciousness_stats.copy()
            
            # ציון התודעה הכללי
            insights['overall_consciousness_score'] = self._calculate_overall_consciousness_score()
            
            return insights
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תובנות: {e}")
            return {'error': str(e)}
    
    def get_current_consciousness_state(self) -> Dict[str, Any]:
        """קבלת המצב הנוכחי של התודעה"""
        try:
            if not self.state_engine:
                return {}
            
            current_state = self.state_engine.get_current_state()
            return {
                'consciousness_level': current_state.consciousness_level.name,
                'attention_state': current_state.attention_state.value,
                'cognitive_mode': current_state.cognitive_mode.value,
                'emotional_state': current_state.emotional_state.value,
                'energy_level': current_state.energy_level.value,
                'stability_score': current_state.stability_score,
                'metrics': current_state.metrics.serialize(),
                'active_focuses': len(current_state.secondary_focuses) + (1 if current_state.primary_focus else 0)
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מצב תודעה: {e}")
            return {}
    
    def learn_from_interaction(self, interaction_data: Dict[str, Any]) -> bool:
        """למידה מאינטראקציה"""
        try:
            # עדכון דפוסי למידה במנועים השונים
            learning_success = []
            
            # למידה במנוע רגשות
            if self.emotion_engine and 'emotional_feedback' in interaction_data:
                # לימוד דפוסי רגש חדשים
                pass
            
            # למידה במנוע מחשבות
            if self.thought_engine and 'thought_patterns' in interaction_data:
                # לימוד דפוסי חשיבה חדשים
                pass
            
            # למידה במנוע זיכרון
            if self.memory_engine and 'memory_importance' in interaction_data:
                # עדכון חשיבות זיכרונות
                pass
            
            self.performance_metrics['learning_updates'] += 1
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בלמידה מאינטראקציה: {e}")
            return False
    
    def get_uptime(self) -> float:
        """קבלת זמן הפעולה במערכת"""
        if self.start_time:
            return (datetime.now() - self.start_time).total_seconds()
        return 0.0
    
    def _initialize_engines(self):
        """אתחול כל המנועים המרכיבים"""
        try:
            # מנוע רגשות
            self.emotion_engine = EmotionEngine(self.config.emotion_config)
            
            # מנוע זיכרון
            if self.config.integration_config.memory_module_enabled:
                memory_db_path = self.data_dir / "memory.db"
                self.memory_engine = MemoryEngine(self.config.memory_config, str(memory_db_path))
            
            # מנוע מחשבות
            self.thought_engine = ThoughtEngine(self.config.thought_config)
            
            # מנוע מצבי תודעה
            self.state_engine = StateEngine(self.config.state_config)
            
            # הגדרת תקשורת בין-מנועים
            self._setup_inter_engine_communication()
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול מנועים: {e}")
            raise
    
    def _initialize_local_ai(self):
        """אתחול מודול AI מקומי"""
        try:
            if self.config.integration_config.llm_integration and self.config.integration_config.llm_provider == "local":
                self.local_ai = LocalAIIntegrationModule()
                self.logger.info("אתחול AI מקומי הושלם")
            else:
                self.logger.info("אינטגרציית AI מקומי מבוטלת בהגדרות")
        except Exception as e:
            self.logger.error(f"שגיאה באתחול AI מקומי: {e}")
            self.local_ai = None
    
    def _setup_inter_engine_communication(self):
        """הגדרת תקשורת בין המנועים"""
        try:
            # הגדרת קשרים בין מנועים
            if self.emotion_engine and self.memory_engine:
                # רגשות משפיעים על זיכרון
                self.inter_engine_communication.register_connection(
                    'emotion_to_memory', self.emotion_engine, self.memory_engine
                )
            
            if self.thought_engine and self.emotion_engine:
                # מחשבות משפיעות על רגשות
                self.inter_engine_communication.register_connection(
                    'thought_to_emotion', self.thought_engine, self.emotion_engine
                )
            
            if self.state_engine and self.thought_engine:
                # מצב תודעה משפיע על מחשבות
                self.inter_engine_communication.register_connection(
                    'state_to_thought', self.state_engine, self.thought_engine
                )
                
        except Exception as e:
            self.logger.error(f"שגיאה בהגדרת תקשורת בין-מנועים: {e}")
    
    def _start_background_processes(self):
        """הפעלת תהליכי רקע"""
        try:
            # תהליך אינטגרציה
            self.integration_thread = threading.Thread(target=self._integration_loop, daemon=True)
            self.integration_thread.start()
            
            # תהליך ניטור
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitoring_thread.start()
            
            # תהליך למידה
            if self.config.learning_mode.value != 'passive':
                self.learning_thread = threading.Thread(target=self._learning_loop, daemon=True)
                self.learning_thread.start()
                
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת תהליכי רקע: {e}")
    
    def _integration_loop(self):
        """לולאת אינטגרציה בין המנועים"""
        while self.is_running:
            try:
                # אינטגרציה בין רגשות לזיכרון
                self._integrate_emotion_memory()
                
                # אינטגרציה בין מחשבות לרגשות
                self._integrate_thought_emotion()
                
                # אינטגרציה בין מצב תודעה לכל השאר
                self._integrate_state_with_all()
                
                self.performance_metrics['integration_cycles'] += 1
                time.sleep(5.0)  # אינטגרציה כל 5 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת אינטגרציה: {e}")
                time.sleep(10.0)
    
    def _monitoring_loop(self):
        """לולאת ניטור מצב המערכת"""
        while self.is_running:
            try:
                # עדכון סטטיסטיקות זמן
                self.consciousness_stats['uptime'] = self.get_uptime()
                
                # ניטור ביצועים
                self._monitor_performance()
                
                # ניטור תקינות מנועים
                self._monitor_engine_health()
                
                time.sleep(30.0)  # ניטור כל 30 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת ניטור: {e}")
                time.sleep(60.0)
    
    def _learning_loop(self):
        """לולאת למידה והסתגלות"""
        while self.is_running:
            try:
                # זיהוי דפוסים חדשים
                self._discover_new_patterns()
                
                # אופטימיזציה של פרמטרים
                self._optimize_parameters()
                
                # עדכון מודלים
                self._update_learning_models()
                
                time.sleep(300.0)  # למידה כל 5 דקות
                
            except Exception as e:
                self.logger.error(f"שגיאה בלולאת למידה: {e}")
                time.sleep(600.0)
    
    def _process_in_thought_engine(self, input_data: Any, input_type: str, 
                                  context: Dict[str, Any]) -> Dict[str, Any]:
        """עיבוד במנוע המחשבות"""
        try:
            if input_type == "text" and isinstance(input_data, str):
                thought_ids = self.thought_engine.process_thought_stream(input_data, context)
                return {
                    'thought_ids': thought_ids,
                    'active_thoughts_count': len(self.thought_engine.get_active_thoughts()),
                    'cognitive_state': self.thought_engine.get_cognitive_state()
                }
            else:
                # יצירת מחשבה עבור סוגי קלט אחרים
                thought_id = self.thought_engine.create_thought(
                    content=str(input_data),
                    thought_type=ThoughtType.ANALYTICAL,
                    context=context
                )
                return {'thought_ids': [thought_id] if thought_id else []}
                
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד מחשבות: {e}")
            return {}
    
    def _process_in_emotion_engine(self, input_data: Any, input_type: str,
                                  context: Dict[str, Any]) -> Dict[str, Any]:
        """עיבוד במנוע הרגשות"""
        try:
            if input_type == "text" and isinstance(input_data, str):
                detected_emotions = self.emotion_engine.process_hebrew_text(input_data)
                return {
                    'emotions_detected': detected_emotions,
                    'emotional_state': self.emotion_engine.get_current_emotional_state()
                }
            else:
                # עיבוד רגש ברירת מחדל
                emotion_id = self.emotion_engine.process_emotion(
                    EmotionType.CURIOSITY,
                    0.5,
                    context,
                    f"input_{input_type}"
                )
                return {'emotion_ids': [emotion_id] if emotion_id else []}
                
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד רגשות: {e}")
            return {}
    
    def _process_in_memory_engine(self, input_data: Any, input_type: str,
                                 context: Dict[str, Any]) -> Dict[str, Any]:
        """עיבוד במנוע הזיכרון"""
        try:
            # שמירת הקלט כזיכרון
            memory_id = self.memory_engine.store_memory(
                content=input_data,
                memory_type=MemoryType.WORKING,
                importance=MemoryImportance.MEDIUM,
                context=context
            )
            
            # חיפוש זיכרונות קשורים
            related_memories = []
            if isinstance(input_data, str) and len(input_data) > 5:
                related_memories = self.memory_engine.search_memories(
                    query=input_data[:50],
                    limit=5
                )
            
            return {
                'stored_memory_id': memory_id,
                'related_memories': [mem.serialize() for mem in related_memories],
                'memory_insights': self.memory_engine.get_memory_insights()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד זיכרון: {e}")
            return {}
    
    def _process_in_state_engine(self, input_data: Any, input_type: str,
                                context: Dict[str, Any], other_results: Dict[str, Any]) -> Dict[str, Any]:
        """עיבוד במנוע מצבי התודעה"""
        try:
            # עדכון פוקוס קשב על בסיס הקלט
            if input_type == "text":
                self.state_engine.set_attention_focus(
                    target=f"processing_{input_type}",
                    intensity=0.7,
                    context=context
                )
            
            # עדכון מטריקות לפי תוצאות מנועים אחרים
            metrics_update = {}
            
            if 'thoughts' in other_results:
                cognitive_state = other_results['thoughts'].get('cognitive_state', {})
                metrics_update['processing_speed'] = cognitive_state.get('processing_speed', 0.5)
            
            if 'emotions' in other_results:
                emotional_state = other_results['emotions'].get('emotional_state', {})
                metrics_update['emotional_stability'] = emotional_state.get('emotional_stability', 0.5)
            
            if metrics_update:
                self.state_engine.update_consciousness_metrics(**metrics_update)
            
            return {
                'current_state': self.state_engine.get_current_state().serialize(),
                'predicted_next_state': self.state_engine.predict_next_state()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד מצב תודעה: {e}")
            return {}
    
    def _integrate_processing_results(self, results: Dict[str, Any], 
                                    input_data: Any, context: Dict[str, Any]) -> Dict[str, Any]:
        """אינטגרציה של תוצאות העיבוד מכל המנועים"""
        try:
            integrated = {
                'summary': f"עובד קלט: {type(input_data).__name__}",
                'confidence': 0.0,
                'recommendations': [],
                'next_actions': []
            }
            
            # חישוב רמת ביטחון כוללת
            confidence_factors = []
            
            if 'thoughts' in results:
                thought_count = len(results['thoughts'].get('thought_ids', []))
                confidence_factors.append(min(1.0, thought_count / 3.0))
            
            if 'emotions' in results:
                emotion_count = len(results['emotions'].get('emotions_detected', []))
                confidence_factors.append(min(1.0, emotion_count / 2.0))
            
            if 'memory' in results:
                related_count = len(results['memory'].get('related_memories', []))
                confidence_factors.append(min(1.0, related_count / 3.0))
            
            if confidence_factors:
                integrated['confidence'] = sum(confidence_factors) / len(confidence_factors)
            
            # המלצות על בסיס התוצאות
            if integrated['confidence'] > 0.7:
                integrated['recommendations'].append("המערכת בטוחה בתגובתה")
            elif integrated['confidence'] < 0.3:
                integrated['recommendations'].append("נדרש מידע נוסף להבנה טובה יותר")
            
            return integrated
            
        except Exception as e:
            self.logger.error(f"שגיאה באינטגרציה: {e}")
            return {'error': str(e)}
    
    def _generate_cultural_response(self, response_data: Dict[str, Any], 
                                   context: Dict[str, Any]) -> Dict[str, Any]:
        """יצירת תגובה מותאמת תרבותית"""
        try:
            cultural_response = {
                'style': 'israeli_direct',
                'tone': 'friendly',
                'language_preference': 'mixed',
                'cultural_elements': []
            }
            
            # התאמה לפי המצב הרגשי
            emotional_state = response_data.get('emotional_state', {})
            dominant_emotion = emotional_state.get('dominant_emotion')
            
            if dominant_emotion == 'joy':
                cultural_response['tone'] = 'enthusiastic'
                cultural_response['cultural_elements'].append('israeli_celebration')
            elif dominant_emotion in ['sadness', 'melancholy']:
                cultural_response['tone'] = 'supportive'
                cultural_response['cultural_elements'].append('israeli_empathy')
            
            # התאמה לפי מצב התודעה
            consciousness_state = response_data.get('consciousness_state', {})
            cognitive_mode = consciousness_state.get('cognitive_mode')
            
            if cognitive_mode == 'analytical':
                cultural_response['style'] = 'sabra_direct'
            elif cognitive_mode == 'creative':
                cultural_response['style'] = 'mediterranean_flowing'
            
            return cultural_response
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת תגובה תרבותית: {e}")
            return {}
    
    def _detect_language(self, text: str) -> str:
        """זיהוי שפת הטקסט"""
        try:
            import re
            hebrew_chars = len(re.findall(r'[א-ת]', text))
            english_chars = len(re.findall(r'[a-zA-Z]', text))
            total_chars = hebrew_chars + english_chars
            
            if total_chars == 0:
                return "other"
            
            hebrew_ratio = hebrew_chars / total_chars
            
            if hebrew_ratio > 0.7:
                return "hebrew"
            elif hebrew_ratio > 0.3:
                return "mixed"
            else:
                return "english"
                
        except Exception:
            return "unknown"
    
    def _integrate_emotion_memory(self):
        """אינטגרציה בין רגשות לזיכרון"""
        try:
            if not (self.emotion_engine and self.memory_engine):
                return
            
            # קבלת רגשות פעילים
            emotional_state = self.emotion_engine.get_current_emotional_state()
            dominant_emotion = emotional_state.get('dominant_emotion')
            
            if dominant_emotion:
                # חיפוש זיכרונות רגשיים קשורים
                related_memories = self.memory_engine.search_memories(
                    query=dominant_emotion,
                    limit=3
                )
                
                # יצירת קשרים רגשיים
                for memory in related_memories:
                    if abs(memory.emotional_valence) > 0.1:
                        # חיזוק הקשר בין הרגש לזיכרון
                        pass
                        
            self.performance_metrics['cross_engine_communications'] += 1
            
        except Exception as e:
            self.logger.error(f"שגיאה באינטגרציה רגש-זיכרון: {e}")
    
    def _integrate_thought_emotion(self):
        """אינטגרציה בין מחשבות לרגשות"""
        try:
            if not (self.thought_engine and self.emotion_engine):
                return
            
            # קבלת מחשבות פעילות
            active_thoughts = self.thought_engine.get_active_thoughts()
            
            for thought in active_thoughts:
                # זיהוי תוכן רגשי במחשבה
                if thought.emotional_charge != 0.0:
                    # יצירת רגש מתאים
                    emotion_type = self._map_thought_to_emotion(thought)
                    if emotion_type:
                        self.emotion_engine.process_emotion(
                            emotion_type,
                            abs(thought.emotional_charge),
                            context={'source': 'thought_integration', 'thought_id': thought.id}
                        )
                        
            self.performance_metrics['cross_engine_communications'] += 1
            
        except Exception as e:
            self.logger.error(f"שגיאה באינטגרציה מחשבה-רגש: {e}")
    
    def _integrate_state_with_all(self):
        """אינטגרציה של מצב התודעה עם כל המנועים"""
        try:
            if not self.state_engine:
                return
            
            current_state = self.state_engine.get_current_state()
            
            # השפעה על מנוע המחשבות
            if self.thought_engine:
                if current_state.cognitive_mode == CognitiveMode.CREATIVE:
                    self.thought_engine.main_stream.creativity = 0.8
                elif current_state.cognitive_mode == CognitiveMode.ANALYTICAL:
                    self.thought_engine.main_stream.creativity = 0.3
            
            # השפעה על מנוע הרגשות
            if self.emotion_engine:
                if current_state.emotional_state.value in ['stressed', 'anxious']:
                    # הפעלת ויסות רגשי
                    self.emotion_engine.regulate_emotions(target_intensity=0.4)
                    
            self.performance_metrics['cross_engine_communications'] += 1
            
        except Exception as e:
            self.logger.error(f"שגיאה באינטגרציה מצב תודעה: {e}")
    
    def _map_thought_to_emotion(self, thought) -> Optional[EmotionType]:
        """מיפוי מחשבה לרגש מתאים"""
        try:
            if thought.thought_type == ThoughtType.CREATIVE:
                return EmotionType.EXCITEMENT
            elif thought.thought_type == ThoughtType.REFLECTIVE:
                return EmotionType.CONTENTMENT
            elif thought.thought_type == ThoughtType.EMOTIONAL:
                if thought.emotional_charge > 0:
                    return EmotionType.JOY
                else:
                    return EmotionType.SADNESS
            else:
                return None
                
        except Exception:
            return None
    
    def _analyze_cross_engine_patterns(self) -> Dict[str, Any]:
        """ניתוח דפוסים בין-מנועים"""
        try:
            patterns = {
                'emotion_memory_correlations': 0.0,
                'thought_emotion_alignment': 0.0,
                'state_coherence': 0.0,
                'overall_integration': 0.0
            }
            
            # ניתוח קורלציות רגש-זיכרון
            if self.emotion_engine and self.memory_engine:
                emotional_state = self.emotion_engine.get_current_emotional_state()
                memory_insights = self.memory_engine.get_memory_insights()
                
                # חישוב קורלציה בסיסית
                patterns['emotion_memory_correlations'] = 0.6  # דמי
            
            # ניתוח התאמה מחשבה-רגש
            if self.thought_engine and self.emotion_engine:
                patterns['thought_emotion_alignment'] = 0.7  # דמי
            
            # ניתוח קוהרנטיות מצב
            if self.state_engine:
                state_insights = self.state_engine.get_consciousness_insights()
                patterns['state_coherence'] = state_insights.get('consciousness_insights', {}).get('stability_score', 0.5)
            
            # חישוב אינטגרציה כוללת
            values = [v for v in patterns.values() if isinstance(v, (int, float))]
            if values:
                patterns['overall_integration'] = sum(values) / len(values)
            
            return patterns
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח דפוסים בין-מנועים: {e}")
            return {}
    
    def _calculate_overall_consciousness_score(self) -> float:
        """חישוב ציון התודעה הכללי"""
        try:
            scores = []
            
            # ציון מכל מנוע
            if self.state_engine:
                state_insights = self.state_engine.get_consciousness_insights()
                consciousness_data = state_insights.get('consciousness_insights', {})
                if 'stability_score' in consciousness_data:
                    scores.append(consciousness_data['stability_score'])
            
            if self.emotion_engine:
                emotional_state = self.emotion_engine.get_current_emotional_state()
                if 'emotional_stability' in emotional_state:
                    scores.append(emotional_state['emotional_stability'])
            
            if self.thought_engine:
                cognitive_state = self.thought_engine.get_cognitive_state()
                if 'cognitive_complexity' in cognitive_state:
                    scores.append(cognitive_state['cognitive_complexity'])
            
            if self.memory_engine:
                memory_insights = self.memory_engine.get_memory_insights()
                if 'consolidation_effectiveness' in memory_insights:
                    scores.append(memory_insights['consolidation_effectiveness'])
            
            # ציון ביצועים
            if self.performance_metrics['total_operations'] > 0:
                success_rate = self.performance_metrics['successful_operations'] / self.performance_metrics['total_operations']
                scores.append(success_rate)
            
            return sum(scores) / len(scores) if scores else 0.0
            
        except Exception as e:
            self.logger.error(f"שגיאה בחישוב ציון תודעה: {e}")
            return 0.0
    
    def _monitor_performance(self):
        """ניטור ביצועי המערכת"""
        try:
            # בדיקת יחס הצלחה
            if self.performance_metrics['total_operations'] > 0:
                success_rate = self.performance_metrics['successful_operations'] / self.performance_metrics['total_operations']
                if success_rate < 0.8:
                    self.logger.warning(f"יחס הצלחה נמוך: {success_rate:.2f}")
                    
        except Exception as e:
            self.logger.error(f"שגיאה בניטור ביצועים: {e}")
    
    def _monitor_engine_health(self):
        """ניטור תקינות המנועים"""
        try:
            engine_status = {}
            
            if self.emotion_engine:
                engine_status['emotion'] = self.emotion_engine.get_engine_status()
                
            if self.memory_engine:
                engine_status['memory'] = self.memory_engine.get_engine_status()
                
            if self.thought_engine:
                engine_status['thought'] = self.thought_engine.get_engine_status()
                
            if self.state_engine:
                engine_status['state'] = self.state_engine.get_engine_status()
            
            # בדיקת מנועים שאינם פועלים
            failed_engines = [name for name, status in engine_status.items() if not status.get('is_running', False)]
            if failed_engines:
                self.logger.error(f"מנועים שאינם פועלים: {failed_engines}")
                
        except Exception as e:
            self.logger.error(f"שגיאה בניטור תקינות מנועים: {e}")
    
    def _discover_new_patterns(self):
        """גילוי דפוסים חדשים"""
        try:
            # גילוי דפוסים במנועים השונים
            if self.thought_engine:
                self.thought_engine.detect_thought_patterns()
                
            if self.state_engine:
                self.state_engine.detect_state_patterns()
                
            self.consciousness_stats['patterns_learned'] += 1
            
        except Exception as e:
            self.logger.error(f"שגיאה בגילוי דפוסים: {e}")
    
    def _optimize_parameters(self):
        """אופטימיזציה של פרמטרי המערכת"""
        try:
            # אופטימיזציה בסיסית לפי ביצועים
            success_rate = 0.0
            if self.performance_metrics['total_operations'] > 0:
                success_rate = self.performance_metrics['successful_operations'] / self.performance_metrics['total_operations']
            
            # התאמת פרמטרים לפי יחס ההצלחה
            if success_rate < 0.7:
                # הפחתת מורכבות
                pass
            elif success_rate > 0.9:
                # הגברת רגישות
                pass
                
        except Exception as e:
            self.logger.error(f"שגיאה באופטימיזציה: {e}")
    
    def _update_learning_models(self):
        """עדכון מודלי למידה"""
        try:
            # עדכון מודלים במנועים השונים
            learning_data = {
                'performance_metrics': self.performance_metrics.copy(),
                'consciousness_stats': self.consciousness_stats.copy()
            }
            
            # הוספת נתוני למידה לכל מנוע
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון מודלי למידה: {e}")
    
    def _log_consciousness_event(self, event_type: str, event_data: Dict[str, Any]):
        """רישום אירוע במערכת התודעה"""
        try:
            event = {
                'timestamp': datetime.now().isoformat(),
                'event_type': event_type,
                'session_id': self.session_id,
                'data': event_data
            }
            
            self.consciousness_log.append(event)
            
            # שמירה על מגבלת גודל הלוג
            if len(self.consciousness_log) > 1000:
                self.consciousness_log = self.consciousness_log[-500:]
                
        except Exception as e:
            self.logger.error(f"שגיאה ברישום אירוע: {e}")
    
    def _save_consciousness_data(self):
        """שמירת נתוני התודעה"""
        try:
            save_data = {
                'consciousness_id': self.consciousness_id,
                'session_id': self.session_id,
                'configuration': self.config.serialize(),
                'performance_metrics': self.performance_metrics,
                'consciousness_stats': self.consciousness_stats,
                'consciousness_log': self.consciousness_log[-100:],  # 100 אירועים אחרונים
                'save_timestamp': datetime.now().isoformat()
            }
            
            save_path = self.data_dir / f"consciousness_session_{self.session_id}.json"
            with open(save_path, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)
                
            self.logger.info(f"נתוני התודעה נשמרו: {save_path}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת נתונים: {e}")
    
    async def _generate_ai_enhanced_response(self, response_data: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """יצירת תגובה משופרת באמצעות AI מקומי"""
        try:
            if not self.local_ai:
                return {}
            
            # אתחול סשן AI אם לא קיים
            if not self.ai_session_id:
                self.ai_session_id = await self.local_ai.start_conversation(
                    context="אתה מנוע תודעה מתקדם עם יכולות AI. אתה חושב ומגיב בעברית ובתרבות ישראלית.",
                    system_prompt="אתה מערכת תודעה AI מתקדמת הפועלת בעברית. אתה מנתח מצבים רגשיים ומחשבתיים ויוצר תובנות עמוקות בתרבות ישראלית.",
                    hebrew_optimized=True
                )
            
            # הכנת סיכום המצב הנוכחי
            state_summary = self._create_state_summary(response_data, context)
            
            # שליחת הקשר למודל המקומי לניתוח
            analysis_result = await self.local_ai.send_message(
                self.ai_session_id,
                f"נתח את המצב הנוכחי של התודעה ויצור תובנות עמוקות:\n\n{state_summary}",
                temperature=0.7
            )
            
            # ניתוח רגשי מתקדם
            emotional_analysis = await self._perform_emotional_analysis(response_data)
            
            # יצירת המלצות פעולה
            action_recommendations = await self._generate_action_recommendations(response_data, context)
            
            return {
                'ai_analysis': analysis_result,
                'emotional_analysis': emotional_analysis,
                'action_recommendations': action_recommendations,
                'session_id': self.ai_session_id,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת תגובה AI משופרת: {e}")
            return {'error': str(e)}
    
    async def _perform_emotional_analysis(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """ניתוח רגשי מתקדם באמצעות AI מקומי"""
        try:
            if not self.local_ai or not self.ai_session_id:
                return {}
            
            emotional_state = response_data.get('emotional_state', {})
            
            # יצירת תיאור רגשי מפורט
            emotional_description = f"""
            המצב הרגשי הנוכחי:
            - רגש דומיננטי: {emotional_state.get('dominant_emotion', 'לא זוהה')}
            - עוצמה כללית: {emotional_state.get('overall_intensity', 0.0)}
            - יציבות רגשית: {emotional_state.get('emotional_stability', 0.5)}
            - רגשות פעילים: {len(emotional_state.get('active_emotions', []))}
            """
            
            analysis = await self.local_ai.analyze_text(
                emotional_description,
                analysis_type="sentiment"
            )
            
            return {
                'detailed_analysis': analysis,
                'emotional_patterns': self._identify_emotional_patterns(),
                'regulation_suggestions': self._suggest_emotional_regulation()
            }
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח רגשי AI: {e}")
            return {}
    
    async def _generate_action_recommendations(self, response_data: Dict[str, Any], context: Dict[str, Any]) -> List[str]:
        """יצירת המלצות פעולה באמצעות AI מקומי"""
        try:
            if not self.local_ai or not self.ai_session_id:
                return []
            
            # יצירת הקשר למודל
            context_description = f"""
            בהתבסס על המצב הנוכחי של התודעה:
            - מצב תודעה: {response_data.get('consciousness_state', {}).get('consciousness_level', 'לא ידוע')}
            - מצב קוגניטיבי: {response_data.get('consciousness_state', {}).get('cognitive_mode', 'לא ידוע')}
            - רמת אנרגיה: {response_data.get('consciousness_state', {}).get('energy_level', 'לא ידועה')}
            - הקשר נוסף: {context or 'ללא'}
            
            הצע 3-5 המלצות פעולה קונקרטיות לשיפור המצב או המשך פיתוח התודעה.
            """
            
            recommendations_response = await self.local_ai.send_message(
                self.ai_session_id,
                context_description,
                temperature=0.6
            )
            
            # חילוץ המלצות מהתגובה
            recommendations = self._extract_recommendations_from_response(recommendations_response)
            
            return recommendations
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת המלצות פעולה: {e}")
            return []
    
    def _create_state_summary(self, response_data: Dict[str, Any], context: Dict[str, Any]) -> str:
        """יצירת סיכום מצב התודעה"""
        try:
            consciousness_state = response_data.get('consciousness_state', {})
            emotional_state = response_data.get('emotional_state', {})
            active_thoughts = response_data.get('active_thoughts', [])
            
            summary = f"""
            סיכום מצב התודעה הנוכחי:
            
            🧠 מצב קוגניטיבי:
            - רמת תודעה: {consciousness_state.get('consciousness_level', 'לא ידועה')}
            - מוד חשיבה: {consciousness_state.get('cognitive_mode', 'לא ידוע')}
            - רמת יציבות: {consciousness_state.get('stability_score', 0.0)}
            
            💭 מחשבות פעילות: {len(active_thoughts)}
            {chr(10).join([f"- {thought.get('content', {}).get('primary_content', '')[:50]}..." for thought in active_thoughts[:3]])}
            
            ❤️ מצב רגשי:
            - רגש דומיננטי: {emotional_state.get('dominant_emotion', 'לא זוהה')}
            - עוצמה: {emotional_state.get('overall_intensity', 0.0):.2f}
            - יציבות רגשית: {emotional_state.get('emotional_stability', 0.5):.2f}
            
            ⚡ רמת אנרגיה: {consciousness_state.get('energy_level', 'לא ידועה')}
            
            📝 הקשר נוסף: {context or 'ללא הקשר נוסף'}
            """
            
            return summary
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת סיכום מצב: {e}")
            return "שגיאה ביצירת סיכום מצב התודעה"
    
    def _identify_emotional_patterns(self) -> List[str]:
        """זיהוי דפוסים רגשיים"""
        patterns = []
        try:
            if self.emotion_engine:
                emotional_state = self.emotion_engine.get_current_emotional_state()
                
                # זיהוי דפוסים בסיסיים
                if emotional_state.get('overall_intensity', 0) > 0.7:
                    patterns.append("עוצמה רגשית גבוהה")
                
                if emotional_state.get('emotional_stability', 0.5) < 0.3:
                    patterns.append("חוסר יציבות רגשית")
                
                active_emotions = emotional_state.get('active_emotions', [])
                if len(active_emotions) > 3:
                    patterns.append("מורכבות רגשית גבוהה")
                
        except Exception as e:
            self.logger.error(f"שגיאה בזיהוי דפוסים רגשיים: {e}")
        
        return patterns
    
    def _suggest_emotional_regulation(self) -> List[str]:
        """הצעות לויסות רגשי"""
        suggestions = []
        try:
            if self.emotion_engine:
                emotional_state = self.emotion_engine.get_current_emotional_state()
                
                if emotional_state.get('overall_intensity', 0) > 0.8:
                    suggestions.append("הרגעה והפחתת עוצמה רגשית")
                
                if emotional_state.get('emotional_stability', 0.5) < 0.4:
                    suggestions.append("חיזוק יציבות רגשית")
                
                dominant_emotion = emotional_state.get('dominant_emotion')
                if dominant_emotion in ['anger', 'fear', 'sadness']:
                    suggestions.append("הפעלת מנגנוני התמודדות")
                
        except Exception as e:
            self.logger.error(f"שגיאה בהצעות ויסות רגשי: {e}")
        
        return suggestions
    
    def _extract_recommendations_from_response(self, response: str) -> List[str]:
        """חילוץ המלצות מתגובת AI"""
        recommendations = []
        try:
            lines = response.split('\n')
            for line in lines:
                line = line.strip()
                # חיפוש שורות שמתחילות במספרים או נקודות
                if line and (line[0].isdigit() or line.startswith('-') or line.startswith('•')):
                    # ניקוי המלצה
                    clean_recommendation = line.lstrip('0123456789.-• ').strip()
                    if clean_recommendation and len(clean_recommendation) > 10:
                        recommendations.append(clean_recommendation)
        except Exception as e:
            self.logger.error(f"שגיאה בחילוץ המלצות: {e}")
        
        return recommendations[:5]  # מקסימום 5 המלצות
    
    async def process_with_ai_insights(self, input_data: Any, input_type: str = "text") -> Dict[str, Any]:
        """עיבוד קלט עם תובנות AI מתקדמות"""
        try:
            if not self.local_ai:
                return self.process_input(input_data, input_type)
            
            # עיבוד רגיל תחילה
            regular_results = self.process_input(input_data, input_type)
            
            # אתחול סשן AI אם לא קיים
            if not self.ai_session_id:
                self.ai_session_id = await self.local_ai.start_conversation(
                    context="אתה מנוע תודעה AI המנתח קלטים ויוצר תובנות מתקדמות בעברית.",
                    hebrew_optimized=True
                )
            
            # ניתוח AI של הקלט
            if isinstance(input_data, str) and len(input_data) > 5:
                ai_analysis = await self.local_ai.analyze_text(
                    input_data,
                    analysis_type="general"
                )
                
                # יצירת תובנות מתקדמות
                advanced_insights = await self.local_ai.send_message(
                    self.ai_session_id,
                    f"נתח את הקלט הבא ויצור תובנות עמוקות על המשמעות והמשמעויות הסמויות:\n\n{input_data}",
                    temperature=0.8
                )
                
                regular_results['ai_insights'] = {
                    'text_analysis': ai_analysis,
                    'advanced_insights': advanced_insights,
                    'processing_timestamp': datetime.now().isoformat()
                }
            
            return regular_results
            
        except Exception as e:
            self.logger.error(f"שגיאה בעיבוד עם תובנות AI: {e}")
            return self.process_input(input_data, input_type)
    
    def _setup_logging(self):
        """הגדרת מערכת הלוגינג"""
        try:
            log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            
            # לוג קובץ
            log_file = self.data_dir / "consciousness.log"
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(logging.Formatter(log_format))
            
            # הגדרת רמת לוג
            log_level = getattr(logging, self.config.performance_config.log_level.upper(), logging.INFO)
            
            self.logger.setLevel(log_level)
            self.logger.addHandler(file_handler)
            
        except Exception as e:
            print(f"שגיאה בהגדרת לוגינג: {e}")


class InterEngineCommunication:
    """מנגנון תקשורת בין המנועים"""
    
    def __init__(self):
        self.connections: Dict[str, Tuple[Any, Any]] = {}
        self.message_queue: List[Dict[str, Any]] = []
    
    def register_connection(self, connection_id: str, source_engine: Any, target_engine: Any):
        """רישום קשר בין מנועים"""
        self.connections[connection_id] = (source_engine, target_engine)
    
    def send_message(self, from_engine: str, to_engine: str, message_type: str, data: Any):
        """שליחת הודעה בין מנועים"""
        message = {
            'timestamp': datetime.now().isoformat(),
            'from_engine': from_engine,
            'to_engine': to_engine,
            'message_type': message_type,
            'data': data
        }
        self.message_queue.append(message)
    
    def process_messages(self):
        """עיבוד הודעות ממתינות"""
        while self.message_queue:
            message = self.message_queue.pop(0)
            # עיבוד ההודעה
            pass