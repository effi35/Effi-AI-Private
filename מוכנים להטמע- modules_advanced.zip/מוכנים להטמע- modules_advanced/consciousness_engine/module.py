#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מודול מנוע התודעה עם אינטגרציית AI מקומי
=============================================

מודול מתקדם המספק יכולות תודעה עם אינטגרציה מלאה למודל Hudson/Llama3.1 המקומי.
הכולל מנועי רגשות, זיכרון, מחשבות ומצבי תודעה עם עיבוד AI מתקדם.

תכונות מרכזיות:
- אינטגרציה מלאה עם Local AI (Hudson/Llama3.1)
- 4 מנועי תודעה מרכזיים
- עיבוד טקסט בעברית עם תובנות AI
- ניתוח רגשי מתקדם
- יצירת המלצות פעולה חכמות
- תמיכה מלאה בתרבות ישראלית
"""

import asyncio
import logging
import json
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from pathlib import Path

from .core.consciousness_core import ConsciousnessCore
from .models.config import ConsciousnessConfiguration, create_config_from_preset

logger = logging.getLogger(__name__)


class ConsciousnessEngineModule:
    """מודול מנוע התודעה עם AI מקומי"""
    
    def __init__(self, config_preset: str = "standard", custom_config: Dict[str, Any] = None):
        """אתחול מודול מנוע התודעה"""
        self.name = "consciousness_engine"
        self.display_name = "מנוע התודעה עם AI מקומי"
        self.description = "מנוע תודעה מתקדם עם אינטגרציית Hudson/Llama3.1 מקומי"
        self.version = "2.0.0"
        self.author = "Effi AI Private System"
        
        # טעינת הגדרות
        try:
            self.config = create_config_from_preset(config_preset)
            if custom_config:
                self.config._update_from_dict(custom_config)
        except Exception as e:
            logger.warning(f"שגיאה בטעינת הגדרות: {e}, משתמש בהגדרות ברירת מחדל")
            self.config = ConsciousnessConfiguration()
        
        # ליבת התודעה
        self.consciousness_core: Optional[ConsciousnessCore] = None
        self.is_initialized = False
        self.is_running = False
        
        # נתוני סטטיסטיקה
        self.stats = {
            'module_start_time': datetime.now(),
            'sessions_created': 0,
            'ai_interactions': 0,
            'consciousness_insights_generated': 0,
            'local_ai_responses': 0
        }
        
        # מטמון תגובות
        self.response_cache = {}
        
        logger.info("מודול מנוע התודעה אותחל")
    
    async def initialize(self) -> bool:
        """אתחול המודול"""
        try:
            if self.is_initialized:
                return True
            
            logger.info("מאתחל מודול מנוע התודעה...")
            
            # יצירת ליבת התודעה
            self.consciousness_core = ConsciousnessCore(
                config=self.config,
                data_dir="consciousness_data"
            )
            
            # הפעלת הליבה
            if not self.consciousness_core.start():
                logger.error("נכשלה הפעלת ליבת התודעה")
                return False
            
            self.is_initialized = True
            self.is_running = True
            
            logger.info("מודול מנוע התודעה אותחל בהצלחה")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה באתחול מודול התודעה: {e}")
            return False
    
    async def process_text_with_consciousness(self, text: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """עיבוד טקסט עם תודעה ו-AI מקומי"""
        try:
            if not self.is_initialized or not self.consciousness_core:
                await self.initialize()
            
            if not self.consciousness_core:
                return {'error': 'מנוע התודעה לא זמין'}
            
            # עיבוד עם תובנות AI מתקדמות
            results = await self.consciousness_core.process_with_ai_insights(
                input_data=text,
                input_type="text"
            )
            
            # הוספת מטא-דאטה
            results['module_info'] = {
                'module': self.name,
                'version': self.version,
                'ai_integration': 'local_hudson_llama3.1',
                'processing_timestamp': datetime.now().isoformat()
            }
            
            # עדכון סטטיסטיקות
            self.stats['ai_interactions'] += 1
            if 'ai_insights' in results:
                self.stats['local_ai_responses'] += 1
            
            return results
            
        except Exception as e:
            logger.error(f"שגיאה בעיבוד טקסט עם תודעה: {e}")
            return {'error': str(e)}
    
    async def generate_consciousness_response(self, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """יצירת תגובה על בסיס מצב התודעה"""
        try:
            if not self.is_initialized or not self.consciousness_core:
                await self.initialize()
            
            if not self.consciousness_core:
                return {'error': 'מנוע התודעה לא זמין'}
            
            # יצירת תגובה עם AI מקומי
            response = self.consciousness_core.generate_response(context)
            
            # הוספת מידע על המודול
            response['module_metadata'] = {
                'consciousness_engine_version': self.version,
                'ai_provider': 'local_hudson_llama3.1',
                'hebrew_optimized': True,
                'cultural_context': 'israeli'
            }
            
            # עדכון סטטיסטיקות
            self.stats['consciousness_insights_generated'] += 1
            
            return response
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת תגובת תודעה: {e}")
            return {'error': str(e)}
    
    async def get_consciousness_insights(self) -> Dict[str, Any]:
        """קבלת תובנות מעמיקות על מצב התודעה"""
        try:
            if not self.consciousness_core:
                return {'error': 'מנוע התודעה לא אותחל'}
            
            insights = self.consciousness_core.get_consciousness_insights()
            
            # הוספת מידע על הביצועים
            insights['module_performance'] = self.get_performance_stats()
            insights['ai_integration_status'] = self._get_ai_integration_status()
            
            return insights
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת תובנות תודעה: {e}")
            return {'error': str(e)}
    
    async def analyze_emotional_state(self, input_text: str = None) -> Dict[str, Any]:
        """ניתוח מצב רגשי מתקדם"""
        try:
            if not self.consciousness_core:
                return {'error': 'מנוע התודעה לא אותחל'}
            
            # קבלת מצב רגשי נוכחי
            current_state = self.consciousness_core.get_current_consciousness_state()
            
            # עיבוד טקסט אם סופק
            if input_text:
                processing_results = await self.process_text_with_consciousness(input_text)
                emotional_analysis = processing_results.get('individual_results', {}).get('emotions', {})
            else:
                emotional_analysis = {}
            
            return {
                'current_emotional_state': current_state.get('emotional_state', {}),
                'text_emotional_analysis': emotional_analysis,
                'ai_integration': 'hudson_llama3.1_local',
                'analysis_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"שגיאה בניתוח רגשי: {e}")
            return {'error': str(e)}
    
    async def create_consciousness_session(self, session_context: Dict[str, Any] = None) -> str:
        """יצירת סשן תודעה חדש"""
        try:
            if not self.consciousness_core:
                await self.initialize()
            
            session_id = f"consciousness_session_{datetime.now().timestamp()}"
            
            # יצירת הקשר לסשן
            if session_context:
                await self.process_text_with_consciousness(
                    text=f"התחלת סשן חדש: {session_context.get('description', 'ללא תיאור')}",
                    context=session_context
                )
            
            self.stats['sessions_created'] += 1
            
            logger.info(f"נוצר סשן תודעה חדש: {session_id}")
            return session_id
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת סשן תודעה: {e}")
            return ""
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """קבלת נתוני ביצועים"""
        try:
            uptime = (datetime.now() - self.stats['module_start_time']).total_seconds()
            
            performance_stats = {
                'module_uptime_seconds': uptime,
                'sessions_created': self.stats['sessions_created'],
                'ai_interactions_total': self.stats['ai_interactions'],
                'local_ai_responses': self.stats['local_ai_responses'],
                'consciousness_insights_generated': self.stats['consciousness_insights_generated'],
                'ai_response_rate': (
                    self.stats['local_ai_responses'] / max(1, self.stats['ai_interactions']) * 100
                ),
                'module_status': 'running' if self.is_running else 'stopped',
                'ai_integration_active': self._is_ai_integration_active()
            }
            
            # הוספת נתוני ביצועים מליבת התודעה
            if self.consciousness_core:
                performance_stats['consciousness_core_stats'] = self.consciousness_core.performance_metrics
                performance_stats['consciousness_stats'] = self.consciousness_core.consciousness_stats
            
            return performance_stats
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת נתוני ביצועים: {e}")
            return {}
    
    def _get_ai_integration_status(self) -> Dict[str, Any]:
        """קבלת סטטוס אינטגרציית AI"""
        try:
            status = {
                'local_ai_enabled': self.config.integration_config.llm_integration,
                'ai_provider': self.config.integration_config.llm_provider,
                'model': 'hudson/llama3.1-uncensored',
                'hebrew_support': True,
                'cultural_context': 'israeli'
            }
            
            if self.consciousness_core and self.consciousness_core.local_ai:
                status['ai_module_initialized'] = True
                status['ai_session_active'] = self.consciousness_core.ai_session_id is not None
            else:
                status['ai_module_initialized'] = False
                status['ai_session_active'] = False
            
            return status
            
        except Exception as e:
            logger.error(f"שגיאה בקבלת סטטוס AI: {e}")
            return {}
    
    def _is_ai_integration_active(self) -> bool:
        """בדיקה אם אינטגרציית AI פעילה"""
        try:
            return (
                self.consciousness_core is not None and
                self.consciousness_core.local_ai is not None and
                self.config.integration_config.llm_integration
            )
        except:
            return False
    
    async def test_ai_integration(self) -> Dict[str, Any]:
        """בדיקת אינטגרציית AI המקומי"""
        try:
            if not self.consciousness_core or not self.consciousness_core.local_ai:
                return {
                    'success': False,
                    'error': 'אינטגרציית AI לא זמינה',
                    'timestamp': datetime.now().isoformat()
                }
            
            # בדיקת תגובה בסיסית
            test_result = await self.consciousness_core.local_ai.test_model_connection(
                test_message="שלום, אני בודק את החיבור למודל התודעה המקומי"
            )
            
            return {
                'success': test_result.get('success', False),
                'response': test_result.get('response', ''),
                'response_time': test_result.get('response_time', 0),
                'model_info': 'hudson/llama3.1-uncensored',
                'hebrew_support': True,
                'timestamp': test_result.get('timestamp', datetime.now().isoformat())
            }
            
        except Exception as e:
            logger.error(f"שגיאה בבדיקת AI: {e}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def shutdown(self):
        """כיבוי המודול"""
        try:
            logger.info("מכבה מודול מנוע התודעה...")
            
            self.is_running = False
            
            if self.consciousness_core:
                self.consciousness_core.stop()
            
            logger.info("מודול מנוע התודעה נכבה בהצלחה")
            
        except Exception as e:
            logger.error(f"שגיאה בכיבוי מודול: {e}")
    
    def get_module_info(self) -> Dict[str, Any]:
        """קבלת מידע על המודול"""
        return {
            'name': self.name,
            'display_name': self.display_name,
            'description': self.description,
            'version': self.version,
            'author': self.author,
            'ai_integration': {
                'enabled': True,
                'provider': 'local',
                'model': 'hudson/llama3.1-uncensored',
                'hebrew_support': True,
                'cultural_context': 'israeli'
            },
            'features': [
                'מנוע רגשות מתקדם',
                'מנוע זיכרון חכם',
                'מנוע מחשבות דינמי',
                'מנוע מצבי תודעה',
                'אינטגרציית AI מקומי',
                'עיבוד עברית מתקדם',
                'ניתוח רגשי AI',
                'יצירת תובנות חכמות',
                'תמיכה בתרבות ישראלית'
            ],
            'configuration': self.config.get_summary(),
            'performance': self.get_performance_stats(),
            'status': {
                'initialized': self.is_initialized,
                'running': self.is_running,
                'ai_integration_active': self._is_ai_integration_active()
            }
        }


# פונקציות API עיקריות למודול
async def create_consciousness_engine(config_preset: str = "standard") -> ConsciousnessEngineModule:
    """יצירת מנוע תודעה חדש"""
    engine = ConsciousnessEngineModule(config_preset=config_preset)
    await engine.initialize()
    return engine


async def process_consciousness_input(text: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
    """עיבוד קלט עם מנוע התודעה והAI המקומי"""
    engine = ConsciousnessEngineModule()
    await engine.initialize()
    return await engine.process_text_with_consciousness(text, context)


async def get_consciousness_response(context: Dict[str, Any] = None) -> Dict[str, Any]:
    """קבלת תגובה מהתודעה הAI"""
    engine = ConsciousnessEngineModule()
    await engine.initialize()
    return await engine.generate_consciousness_response(context)


async def analyze_emotional_state_ai(text: str = None) -> Dict[str, Any]:
    """ניתוח רגשי עם AI מקומי"""
    engine = ConsciousnessEngineModule()
    await engine.initialize()
    return await engine.analyze_emotional_state(text)


# יצוא למודול
__all__ = [
    'ConsciousnessEngineModule',
    'create_consciousness_engine',
    'process_consciousness_input',
    'get_consciousness_response',
    'analyze_emotional_state_ai'
]