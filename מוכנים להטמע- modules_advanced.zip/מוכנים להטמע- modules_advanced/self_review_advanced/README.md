# Self Review Advanced Module

## Overview

The Self Review Advanced module provides comprehensive AI self-assessment capabilities where agents can review their own performance, analyze their outputs, and provide self-feedback using the local Hudson/Llama model.

## Features

- **Performance Self-Assessment**: Automated evaluation of AI responses and actions
- **Output Quality Analysis**: Detailed analysis of generated content quality
- **Self-Feedback Generation**: AI-generated feedback for continuous improvement
- **Learning from Reviews**: Pattern recognition in performance data
- **Improvement Tracking**: Monitor progress over time
- **Local AI Integration**: Uses Hudson/Llama model for privacy-focused reviews

## Directory Structure

```
self_review_advanced/
├── __init__.py           # Module initialization
├── README.md            # This file
├── requirements.txt     # Dependencies
├── metadata.json        # Module metadata
├── module.py           # Main module interface
├── models/             # Data models and types
│   ├── __init__.py
│   ├── review_types.py
│   ├── assessment_models.py
│   └── learning_models.py
├── core/               # Core engines and logic
│   ├── __init__.py
│   ├── self_review_engine.py
│   ├── assessment_engine.py
│   ├── feedback_engine.py
│   ├── learning_engine.py
│   └── quality_analyzer.py
├── ui/                 # User interface components
│   ├── __init__.py
│   ├── review_dashboard.py
│   ├── assessment_panel.py
│   ├── feedback_viewer.py
│   ├── performance_charts.py
│   └── improvement_tracker.py
├── utils/              # Utility functions
│   ├── __init__.py
│   ├── review_utils.py
│   ├── assessment_helpers.py
│   ├── feedback_formatters.py
│   ├── performance_calculators.py
│   └── ollama_integration.py
├── docs/               # Documentation
├── examples/           # Usage examples
├── tests/              # Unit tests
├── config/             # Configuration files
└── data/               # Data storage
```

## Installation

```bash
cd /root/Effi_ai_privet/modules_advanced/self_review_advanced
pip install -r requirements.txt
```

## Usage

```python
from self_review_advanced import SelfReviewEngine

# Initialize the self-review engine
engine = SelfReviewEngine()

# Review an AI response
review_result = engine.review_response(
    original_query="What is machine learning?",
    ai_response="Machine learning is...",
    context={"task_type": "explanation"}
)

# Get performance metrics
metrics = engine.get_performance_metrics()

# Generate improvement suggestions
suggestions = engine.generate_improvement_suggestions()
```

## Configuration

The module can be configured through:
- `config/review_config.json` - Main configuration
- `config/ollama_config.json` - Local AI model settings
- `config/assessment_criteria.json` - Review criteria definitions

## License

Part of the Effi AI Private System.