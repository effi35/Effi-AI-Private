"""
Self Review Advanced - Review Types and Models
מודלים לביקורת עצמית מתקדמת של AI עם ניתוח והערכה עצמית
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime, timedelta
import uuid
import json

class ReviewType(Enum):
    """סוגי ביקורת"""
    TASK_COMPLETION = "task_completion"        # סיום משימה
    OUTPUT_QUALITY = "output_quality"          # איכות פלט
    PERFORMANCE = "performance"                # ביצועים
    ERROR_ANALYSIS = "error_analysis"          # ניתוח שגיאות
    IMPROVEMENT = "improvement"                # שיפור
    LEARNING = "learning"                      # למידה
    SELF_ASSESSMENT = "self_assessment"        # הערכה עצמית
    PEER_COMPARISON = "peer_comparison"        # השוואה לעמיתים
    USER_SATISFACTION = "user_satisfaction"   # שביעות רצון משתמש

class ReviewCriteria(Enum):
    """קריטריוני ביקורת"""
    ACCURACY = "accuracy"                      # דיוק
    COMPLETENESS = "completeness"              # שלמות
    RELEVANCE = "relevance"                    # רלוונטיות
    CLARITY = "clarity"                        # בהירות
    EFFICIENCY = "efficiency"                  # יעילות
    CREATIVITY = "creativity"                  # יצירתיות
    HELPFULNESS = "helpfulness"                # תועלת
    TIMELINESS = "timeliness"                  # זמינות
    PROFESSIONALISM = "professionalism"        # מקצועיות
    CULTURAL_SENSITIVITY = "cultural_sensitivity"  # רגישות תרבותית
    HEBREW_FLUENCY = "hebrew_fluency"          # שטף עברית
    APPROPRIATENESS = "appropriateness"        # הולמות

class ConfidenceLevel(Enum):
    """רמות ביטחון"""
    VERY_LOW = "very_low"          # 0.0-0.2
    LOW = "low"                    # 0.2-0.4
    MEDIUM = "medium"              # 0.4-0.6
    HIGH = "high"                  # 0.6-0.8
    VERY_HIGH = "very_high"        # 0.8-1.0

class ImprovementPriority(Enum):
    """עדיפות שיפור"""
    CRITICAL = "critical"          # דרוש שיפור מיידי
    HIGH = "high"                  # שיפור חשוב
    MEDIUM = "medium"              # שיפור רצוי
    LOW = "low"                    # שיפור נחמד לקבל
    OPTIONAL = "optional"          # שיפור אופציונלי

class ReviewStatus(Enum):
    """סטטוס ביקורת"""
    PENDING = "pending"            # ממתין לביקורת
    IN_PROGRESS = "in_progress"    # בתהליך ביקורת
    COMPLETED = "completed"        # הושלם
    REVIEWED = "reviewed"          # נבדק
    APPROVED = "approved"          # אושר
    NEEDS_IMPROVEMENT = "needs_improvement"  # דרוש שיפור

@dataclass
class CriteriaScore:
    """ציון קריטריון"""
    criteria: ReviewCriteria
    score: float = 0.0                    # 0.0-1.0
    confidence: float = 0.0               # רמת ביטחון בציון
    explanation: str = ""                 # הסבר הציון
    evidence: List[str] = field(default_factory=list)  # ראיות לציון
    improvement_suggestions: List[str] = field(default_factory=list)  # הצעות שיפור
    
    def get_confidence_level(self) -> ConfidenceLevel:
        """קבלת רמת ביטחון"""
        if self.confidence <= 0.2:
            return ConfidenceLevel.VERY_LOW
        elif self.confidence <= 0.4:
            return ConfidenceLevel.LOW
        elif self.confidence <= 0.6:
            return ConfidenceLevel.MEDIUM
        elif self.confidence <= 0.8:
            return ConfidenceLevel.HIGH
        else:
            return ConfidenceLevel.VERY_HIGH
    
    def get_grade_letter(self) -> str:
        """קבלת ציון אות"""
        if self.score >= 0.9:
            return "A+"
        elif self.score >= 0.8:
            return "A"
        elif self.score >= 0.7:
            return "B"
        elif self.score >= 0.6:
            return "C"
        elif self.score >= 0.5:
            return "D"
        else:
            return "F"

@dataclass
class SelfReflection:
    """הרהור עצמי"""
    reflection_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    
    # שאלות הרהור
    what_went_well: str = ""              # מה הלך טוב
    what_could_improve: str = ""          # מה ניתן לשפר
    what_learned: str = ""                # מה נלמד
    what_surprised: str = ""              # מה הפתיע
    
    # הערכה עצמית
    self_assessment: str = ""             # הערכה עצמית כללית
    emotional_state: str = "neutral"     # מצב רגשי במהלך המשימה
    motivation_level: float = 0.5        # רמת מוטיבציה (0-1)
    stress_level: float = 0.5            # רמת לחץ (0-1)
    
    # תובנות
    key_insights: List[str] = field(default_factory=list)  # תובנות מרכזיות
    patterns_noticed: List[str] = field(default_factory=list)  # דפוסים שזוהו
    assumptions_challenged: List[str] = field(default_factory=list)  # הנחות שאותגרו
    
    # מטרות עתידיות
    short_term_goals: List[str] = field(default_factory=list)  # מטרות קצרות טווח
    long_term_goals: List[str] = field(default_factory=list)   # מטרות ארוכות טווח
    learning_objectives: List[str] = field(default_factory=list)  # יעדי למידה

@dataclass
class ImprovementRecommendation:
    """המלצת שיפור"""
    recommendation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    description: str = ""
    priority: ImprovementPriority = ImprovementPriority.MEDIUM
    
    # פרטים
    target_criteria: List[ReviewCriteria] = field(default_factory=list)  # קריטריונים ליעד
    current_score: float = 0.0            # ציון נוכחי
    target_score: float = 0.0             # ציון יעד
    potential_impact: float = 0.0         # השפעה פוטנציאלית
    
    # יישום
    implementation_steps: List[str] = field(default_factory=list)  # שלבי יישום
    required_resources: List[str] = field(default_factory=list)    # משאבים נדרשים
    estimated_effort: str = "medium"      # מאמץ משוער
    estimated_timeframe: str = "1-2 weeks"  # מסגרת זמן משוערת
    
    # מעקב
    success_metrics: List[str] = field(default_factory=list)  # מדדי הצלחה
    tracking_method: str = ""             # שיטת מעקב
    review_date: Optional[datetime] = None  # תאריך ביקורת
    
    # מטאדטה
    source: str = "self_review"           # מקור ההמלצה
    confidence: float = 0.0               # ביטחון בהמלצה
    tags: List[str] = field(default_factory=list)  # תגים

@dataclass
class PerformanceComparison:
    """השוואת ביצועים"""
    comparison_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    comparison_type: str = "temporal"     # temporal, peer, baseline
    
    # נתוני השוואה
    current_performance: Dict[str, float] = field(default_factory=dict)
    reference_performance: Dict[str, float] = field(default_factory=dict)
    
    # ניתוח
    improvements: List[str] = field(default_factory=list)      # שיפורים
    regressions: List[str] = field(default_factory=list)       # החמרות
    stable_areas: List[str] = field(default_factory=list)      # תחומים יציבים
    
    # מטריקות
    overall_change: float = 0.0           # שינוי כללי (-1 to 1)
    improvement_percentage: float = 0.0   # אחוז שיפור
    regression_percentage: float = 0.0    # אחוז החמרה
    
    # תובנות
    insights: List[str] = field(default_factory=list)
    trends: List[str] = field(default_factory=list)

@dataclass
class SelfReviewResult:
    """תוצאת ביקורת עצמית"""
    review_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    review_type: ReviewType
    timestamp: datetime = field(default_factory=datetime.now)
    
    # מידע על המשימה/פלט שנבדק
    task_id: str = ""
    task_name: str = ""
    output_content: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    
    # ציוני קריטריונים
    criteria_scores: List[CriteriaScore] = field(default_factory=list)
    overall_score: float = 0.0            # ציון כללי (0-1)
    weighted_score: float = 0.0           # ציון משוקלל
    
    # הרהור עצמי
    self_reflection: Optional[SelfReflection] = None
    
    # ניתוח
    strengths: List[str] = field(default_factory=list)         # חוזקות
    weaknesses: List[str] = field(default_factory=list)        # חולשות
    opportunities: List[str] = field(default_factory=list)     # הזדמנויות
    threats: List[str] = field(default_factory=list)           # איומים/אתגרים
    
    # שיפורים
    improvement_recommendations: List[ImprovementRecommendation] = field(default_factory=list)
    quick_wins: List[str] = field(default_factory=list)        # שיפורים מהירים
    long_term_improvements: List[str] = field(default_factory=list)  # שיפורים ארוכי טווח
    
    # השוואות
    performance_comparison: Optional[PerformanceComparison] = None
    
    # מטאדטה
    review_duration_minutes: float = 0.0  # משך זמן הביקורת
    ai_confidence: float = 0.0            # ביטחון ה-AI בביקורת
    review_thoroughness: float = 0.0      # יסודיות הביקורת
    status: ReviewStatus = ReviewStatus.COMPLETED
    
    # תגים וקטגוריזציה
    tags: List[str] = field(default_factory=list)
    categories: List[str] = field(default_factory=list)
    
    def add_criteria_score(self, score: CriteriaScore):
        """הוספת ציון קריטריון"""
        self.criteria_scores.append(score)
        self._recalculate_overall_score()
    
    def _recalculate_overall_score(self):
        """חישוב מחדש של הציון הכללי"""
        if not self.criteria_scores:
            self.overall_score = 0.0
            return
        
        # ציון פשוט - ממוצע
        total_score = sum(score.score for score in self.criteria_scores)
        self.overall_score = total_score / len(self.criteria_scores)
        
        # ציון משוקלל - קריטריונים חשובים יותר
        weights = {
            ReviewCriteria.ACCURACY: 1.5,
            ReviewCriteria.COMPLETENESS: 1.3,
            ReviewCriteria.RELEVANCE: 1.2,
            ReviewCriteria.HELPFULNESS: 1.4,
            ReviewCriteria.HEBREW_FLUENCY: 1.1
        }
        
        weighted_sum = 0.0
        total_weight = 0.0
        
        for score in self.criteria_scores:
            weight = weights.get(score.criteria, 1.0)
            weighted_sum += score.score * weight
            total_weight += weight
        
        self.weighted_score = weighted_sum / total_weight if total_weight > 0 else 0.0
    
    def get_priority_improvements(self, limit: int = 3) -> List[ImprovementRecommendation]:
        """קבלת שיפורים בעדיפות גבוהה"""
        high_priority = [
            rec for rec in self.improvement_recommendations
            if rec.priority in [ImprovementPriority.CRITICAL, ImprovementPriority.HIGH]
        ]
        
        # מיון לפי השפעה פוטנציאלית
        high_priority.sort(key=lambda r: r.potential_impact, reverse=True)
        return high_priority[:limit]
    
    def get_grade_summary(self) -> str:
        """קבלת סיכום ציונים"""
        if not self.criteria_scores:
            return "לא נמצאו ציונים"
        
        grades = [score.get_grade_letter() for score in self.criteria_scores]
        grade_counts = {}
        for grade in grades:
            grade_counts[grade] = grade_counts.get(grade, 0) + 1
        
        # הציון הכי נפוץ
        most_common_grade = max(grade_counts.items(), key=lambda x: x[1])[0]
        
        return f"ציון כללי: {most_common_grade}, ציון ממוצע: {self.overall_score:.2f}"
    
    def get_improvement_summary(self) -> str:
        """קבלת סיכום שיפורים"""
        if not self.improvement_recommendations:
            return "לא נמצאו המלצות שיפור"
        
        critical_count = sum(1 for rec in self.improvement_recommendations 
                           if rec.priority == ImprovementPriority.CRITICAL)
        high_count = sum(1 for rec in self.improvement_recommendations 
                        if rec.priority == ImprovementPriority.HIGH)
        
        summary = f"{len(self.improvement_recommendations)} המלצות שיפור"
        if critical_count > 0:
            summary += f", {critical_count} קריטיות"
        if high_count > 0:
            summary += f", {high_count} בעדיפות גבוהה"
        
        return summary

@dataclass
class ReviewHistory:
    """היסטוריית ביקורות"""
    history_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entity_id: str = ""                   # מזהה הישות שנבדקת (משימה, סוכן וכו')
    entity_type: str = "task"             # סוג הישות
    
    # ביקורות
    reviews: List[SelfReviewResult] = field(default_factory=list)
    
    # ניתוח היסטורי
    improvement_trend: str = "stable"     # improving, declining, stable
    learning_rate: float = 0.0            # קצב למידה
    consistency_score: float = 0.0        # ציון עקביות
    
    # מטריקות זמניות
    first_review_date: Optional[datetime] = None
    last_review_date: Optional[datetime] = None
    review_frequency: float = 0.0         # ביקורות לשבוע
    
    def add_review(self, review: SelfReviewResult):
        """הוספת ביקורת להיסטוריה"""
        self.reviews.append(review)
        self.reviews.sort(key=lambda r: r.timestamp)
        
        # עדכון תאריכים
        if not self.first_review_date:
            self.first_review_date = review.timestamp
        self.last_review_date = review.timestamp
        
        # עדכון ניתוח
        self._analyze_trend()
        self._calculate_metrics()
    
    def _analyze_trend(self):
        """ניתוח מגמת שיפור"""
        if len(self.reviews) < 3:
            self.improvement_trend = "insufficient_data"
            return
        
        # השוואת הציונים האחרונים
        recent_scores = [r.overall_score for r in self.reviews[-3:]]
        earlier_scores = [r.overall_score for r in self.reviews[:-3]] if len(self.reviews) > 3 else []
        
        if not earlier_scores:
            self.improvement_trend = "stable"
            return
        
        recent_avg = sum(recent_scores) / len(recent_scores)
        earlier_avg = sum(earlier_scores) / len(earlier_scores)
        
        change = recent_avg - earlier_avg
        
        if change > 0.1:
            self.improvement_trend = "improving"
        elif change < -0.1:
            self.improvement_trend = "declining"
        else:
            self.improvement_trend = "stable"
    
    def _calculate_metrics(self):
        """חישוב מטריקות"""
        if len(self.reviews) < 2:
            return
        
        # קצב למידה - שיפור לאורך זמן
        scores = [r.overall_score for r in self.reviews]
        if len(scores) >= 3:
            # רגרסיה ליניארית פשוטה
            n = len(scores)
            x_mean = (n - 1) / 2
            y_mean = sum(scores) / n
            
            numerator = sum((i - x_mean) * (scores[i] - y_mean) for i in range(n))
            denominator = sum((i - x_mean) ** 2 for i in range(n))
            
            self.learning_rate = numerator / denominator if denominator != 0 else 0.0
        
        # עקביות - סטיית תקן הפוכה
        if len(scores) > 1:
            mean_score = sum(scores) / len(scores)
            variance = sum((score - mean_score) ** 2 for score in scores) / len(scores)
            std_dev = variance ** 0.5
            self.consistency_score = max(1.0 - std_dev, 0.0)
    
    def get_latest_review(self) -> Optional[SelfReviewResult]:
        """קבלת הביקורת האחרונה"""
        return self.reviews[-1] if self.reviews else None
    
    def get_average_score(self) -> float:
        """קבלת ציון ממוצע"""
        if not self.reviews:
            return 0.0
        return sum(r.overall_score for r in self.reviews) / len(self.reviews)
    
    def get_improvement_over_time(self) -> List[Tuple[datetime, float]]:
        """קבלת שיפור לאורך זמן"""
        return [(r.timestamp, r.overall_score) for r in self.reviews]

class ReviewCriteriaWeights:
    """משקלי קריטריוני ביקורת"""
    
    # משקלים ברירת מחדל
    DEFAULT_WEIGHTS = {
        ReviewCriteria.ACCURACY: 1.5,
        ReviewCriteria.COMPLETENESS: 1.3,
        ReviewCriteria.RELEVANCE: 1.2,
        ReviewCriteria.CLARITY: 1.1,
        ReviewCriteria.EFFICIENCY: 1.0,
        ReviewCriteria.CREATIVITY: 0.8,
        ReviewCriteria.HELPFULNESS: 1.4,
        ReviewCriteria.TIMELINESS: 1.0,
        ReviewCriteria.PROFESSIONALISM: 1.0,
        ReviewCriteria.CULTURAL_SENSITIVITY: 1.2,
        ReviewCriteria.HEBREW_FLUENCY: 1.1,
        ReviewCriteria.APPROPRIATENESS: 1.3
    }
    
    # משקלים לפי סוג משימה
    TASK_SPECIFIC_WEIGHTS = {
        "translation": {
            ReviewCriteria.ACCURACY: 2.0,
            ReviewCriteria.HEBREW_FLUENCY: 1.8,
            ReviewCriteria.CULTURAL_SENSITIVITY: 1.5
        },
        "creative_writing": {
            ReviewCriteria.CREATIVITY: 1.8,
            ReviewCriteria.CLARITY: 1.5,
            ReviewCriteria.APPROPRIATENESS: 1.3
        },
        "customer_service": {
            ReviewCriteria.HELPFULNESS: 1.8,
            ReviewCriteria.PROFESSIONALISM: 1.6,
            ReviewCriteria.TIMELINESS: 1.4
        },
        "technical_analysis": {
            ReviewCriteria.ACCURACY: 1.9,
            ReviewCriteria.COMPLETENESS: 1.6,
            ReviewCriteria.CLARITY: 1.4
        }
    }

# פונקציות עזר
def create_criteria_score(criteria: ReviewCriteria, score: float, explanation: str = "") -> CriteriaScore:
    """יצירת ציון קריטריון"""
    return CriteriaScore(
        criteria=criteria,
        score=max(0.0, min(1.0, score)),  # הגבלה ל-0-1
        confidence=0.8,  # ביטחון ברירת מחדל
        explanation=explanation
    )

def calculate_weighted_score(scores: List[CriteriaScore], weights: Dict[ReviewCriteria, float] = None) -> float:
    """חישוב ציון משוקלל"""
    if not scores:
        return 0.0
    
    if weights is None:
        weights = ReviewCriteriaWeights.DEFAULT_WEIGHTS
    
    total_weighted = 0.0
    total_weight = 0.0
    
    for score in scores:
        weight = weights.get(score.criteria, 1.0)
        total_weighted += score.score * weight
        total_weight += weight
    
    return total_weighted / total_weight if total_weight > 0 else 0.0

def create_improvement_recommendation(
    title: str,
    description: str,
    priority: ImprovementPriority = ImprovementPriority.MEDIUM,
    impact: float = 0.5
) -> ImprovementRecommendation:
    """יצירת המלצת שיפור"""
    return ImprovementRecommendation(
        title=title,
        description=description,
        priority=priority,
        potential_impact=impact,
        confidence=0.7
    )