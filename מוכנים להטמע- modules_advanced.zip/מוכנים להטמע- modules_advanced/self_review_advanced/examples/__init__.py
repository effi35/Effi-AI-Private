"""
Examples package for self_review_advanced module.

Contains usage examples and demonstration scripts.
"""