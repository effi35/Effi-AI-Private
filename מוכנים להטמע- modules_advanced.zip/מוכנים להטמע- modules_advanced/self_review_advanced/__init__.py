"""
Self Review Advanced Module - AI Self-Assessment System

This module provides comprehensive AI self-assessment capabilities where agents
can review their own performance, analyze their outputs, and provide self-feedback
using the local Hudson/Llama model.

Features:
- Performance self-assessment
- Output quality analysis
- Self-feedback generation
- Learning from self-review
- Continuous improvement tracking
"""

__version__ = "1.0.0"
__author__ = "Effi AI System"

from .core.self_review_engine import SelfReviewEngine
from .models.review_types import ReviewResult, PerformanceMetrics, FeedbackData
from .ui.review_dashboard import ReviewDashboard
from .utils.review_utils import ReviewUtils

__all__ = [
    'SelfReviewEngine',
    'ReviewResult',
    'PerformanceMetrics', 
    'FeedbackData',
    'ReviewDashboard',
    'ReviewUtils'
]