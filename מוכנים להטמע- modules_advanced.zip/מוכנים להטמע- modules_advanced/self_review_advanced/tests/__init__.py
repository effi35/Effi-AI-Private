"""
Tests package for self_review_advanced module.

Contains unit tests and integration tests.
"""