"""
Self Review Advanced Module - Main Interface

This module provides the main interface for the AI self-assessment system.
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from .core.self_review_engine import SelfReviewEngine
from .models.review_types import ReviewResult, PerformanceMetrics
from .ui.review_dashboard import ReviewDashboard
from .utils.ollama_integration import OllamaIntegration

class SelfReviewAdvancedModule:
    """Main module class for AI self-review functionality."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize the self-review module."""
        self.module_name = "self_review_advanced"
        self.version = "1.0.0"
        self.logger = self._setup_logging()
        
        # Load configuration
        self.config = self._load_config(config_path)
        
        # Initialize components
        self.engine = SelfReviewEngine(self.config)
        self.dashboard = ReviewDashboard(self.config)
        self.ollama = OllamaIntegration(self.config.get('ollama', {}))
        
        self.logger.info(f"Self Review Advanced Module {self.version} initialized")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup module logging."""
        logger = logging.getLogger(f"effi_ai.{self.module_name}")
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _load_config(self, config_path: Optional[str] = None) -> Dict[str, Any]:
        """Load module configuration."""
        if config_path is None:
            config_path = os.path.join(
                os.path.dirname(__file__), 
                'config', 
                'review_config.json'
            )
        
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            self.logger.warning(f"Could not load config from {config_path}: {e}")
        
        # Default configuration
        return {
            "assessment_criteria": {
                "accuracy": 0.3,
                "relevance": 0.3,
                "clarity": 0.2,
                "completeness": 0.2
            },
            "ollama": {
                "model": "llama2",
                "host": "localhost",
                "port": 11434
            },
            "review_frequency": "after_each_response",
            "storage": {
                "reviews_db": "data/reviews.db",
                "metrics_db": "data/metrics.db"
            }
        }
    
    def review_response(
        self, 
        query: str, 
        response: str, 
        context: Optional[Dict[str, Any]] = None
    ) -> ReviewResult:
        """
        Review an AI response for quality and performance.
        
        Args:
            query: The original user query
            response: The AI-generated response
            context: Additional context information
            
        Returns:
            ReviewResult object with assessment details
        """
        try:
            self.logger.info("Starting response review")
            
            # Perform the review using the engine
            review_result = self.engine.review_response(query, response, context)
            
            # Log the review
            self._log_review(review_result)
            
            return review_result
            
        except Exception as e:
            self.logger.error(f"Error during response review: {e}")
            raise
    
    def get_performance_metrics(
        self, 
        timeframe: str = "last_week"
    ) -> PerformanceMetrics:
        """
        Get performance metrics for the specified timeframe.
        
        Args:
            timeframe: Time period for metrics ('last_day', 'last_week', 'last_month')
            
        Returns:
            PerformanceMetrics object
        """
        try:
            return self.engine.get_performance_metrics(timeframe)
        except Exception as e:
            self.logger.error(f"Error getting performance metrics: {e}")
            raise
    
    def generate_improvement_suggestions(self) -> List[str]:
        """
        Generate suggestions for improvement based on recent reviews.
        
        Returns:
            List of improvement suggestions
        """
        try:
            return self.engine.generate_improvement_suggestions()
        except Exception as e:
            self.logger.error(f"Error generating improvement suggestions: {e}")
            raise
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """
        Get data for the review dashboard.
        
        Returns:
            Dictionary containing dashboard data
        """
        try:
            return self.dashboard.get_dashboard_data()
        except Exception as e:
            self.logger.error(f"Error getting dashboard data: {e}")
            raise
    
    def _log_review(self, review_result: ReviewResult) -> None:
        """Log a review result for tracking."""
        try:
            # This would typically save to database
            # For now, just log the essential information
            self.logger.info(
                f"Review completed - Score: {review_result.overall_score:.2f}, "
                f"Areas for improvement: {len(review_result.improvement_areas)}"
            )
        except Exception as e:
            self.logger.error(f"Error logging review: {e}")
    
    def get_module_info(self) -> Dict[str, Any]:
        """Get module information."""
        return {
            "name": self.module_name,
            "version": self.version,
            "description": "Advanced AI self-assessment module",
            "capabilities": [
                "response_review",
                "performance_metrics",
                "improvement_suggestions",
                "dashboard_interface"
            ],
            "status": "active",
            "last_review_count": getattr(self.engine, 'review_count', 0)
        }
    
    def health_check(self) -> Dict[str, Any]:
        """Perform module health check."""
        try:
            # Check Ollama connection
            ollama_status = self.ollama.check_connection()
            
            # Check database connectivity
            db_status = self.engine.check_database()
            
            return {
                "status": "healthy" if ollama_status and db_status else "degraded",
                "ollama_connection": ollama_status,
                "database_connection": db_status,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

# Module instance for external access
module_instance = SelfReviewAdvancedModule()