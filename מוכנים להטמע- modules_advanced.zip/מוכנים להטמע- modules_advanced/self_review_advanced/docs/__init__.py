"""
Documentation package for self_review_advanced module.

Contains module documentation and guides.
"""