"""
Self Review Advanced - Review Engine
מנוע ביקורת עצמית מתקדם עם אינטגרציה למודל Hudson/Llama מקומי
"""

import asyncio
import json
import re
import time
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
import logging
from collections import defaultdict

from ..models.review_types import (
    SelfReviewResult, ReviewType, ReviewCriteria, CriteriaScore,
    SelfReflection, ImprovementRecommendation, PerformanceComparison,
    ImprovementPriority, ReviewStatus, ConfidenceLevel,
    ReviewHistory, ReviewCriteriaWeights,
    create_criteria_score, calculate_weighted_score,
    create_improvement_recommendation
)

class TextAnalyzer:
    """מנתח טקסט לביקורת איכות"""
    
    def __init__(self):
        self.hebrew_patterns = self._init_hebrew_patterns()
        self.quality_indicators = self._init_quality_indicators()
        
    def _init_hebrew_patterns(self) -> Dict[str, List[str]]:
        """אתחול דפוסי עברית"""
        return {
            "formal_language": [
                "בכבוד רב", "אנו מבקשים", "ברצוני להודיע", "לידיעתכם",
                "בהתאם לבקשתכם", "אשמח לסייע", "תודה מראש"
            ],
            "informal_language": [
                "היי", "שלום", "מה קורה", "בסדר גמור", "סבבה",
                "יופי", "אחלה", "מעולה", "תותח"
            ],
            "professional_terms": [
                "ניתוח", "בדיקה", "הערכה", "חקירה", "מחקר",
                "פתרון", "יישום", "ביצוע", "תכנון", "אסטרטגיה"
            ],
            "positive_expressions": [
                "מצוין", "נהדר", "פנטסטי", "מושלם", "יוצא דופן",
                "מרשים", "מעורר השראה", "איכותי", "מקצועי"
            ],
            "negative_expressions": [
                "בעייתי", "לא מתאים", "לא נכון", "שגוי", "לקוי",
                "חסר", "לא שלם", "לא מדויק", "מבלבל"
            ]
        }
    
    def _init_quality_indicators(self) -> Dict[str, Any]:
        """אתחול מדדי איכות"""
        return {
            "sentence_length_optimal": (10, 25),  # אורך משפט אופטימלי במילים
            "paragraph_length_optimal": (3, 8),   # אורך פסקה אופטימלי במשפטים
            "complexity_indicators": [
                "כלומר", "למעשה", "בנוסף", "יתר על כן", "מאידך",
                "לעומת זאת", "אם כי", "עם זאת", "בכל זאת"
            ],
            "clarity_indicators": [
                "לדוגמה", "כגון", "כמו", "בפרט", "בעיקר",
                "ראשית", "שנית", "לבסוף", "לסיכום"
            ]
        }
    
    async def analyze_text_quality(self, text: str) -> Dict[str, float]:
        """ניתוח איכות טקסט"""
        if not text or not text.strip():
            return {criteria.value: 0.0 for criteria in ReviewCriteria}
        
        analysis = {}
        
        # ניתוח דיוק
        analysis[ReviewCriteria.ACCURACY.value] = await self._analyze_accuracy(text)
        
        # ניתוח שלמות
        analysis[ReviewCriteria.COMPLETENESS.value] = await self._analyze_completeness(text)
        
        # ניתוח בהירות
        analysis[ReviewCriteria.CLARITY.value] = await self._analyze_clarity(text)
        
        # ניתוח רלוונטיות
        analysis[ReviewCriteria.RELEVANCE.value] = await self._analyze_relevance(text)
        
        # ניתוח מקצועיות
        analysis[ReviewCriteria.PROFESSIONALISM.value] = await self._analyze_professionalism(text)
        
        # ניתוח שטף עברית
        analysis[ReviewCriteria.HEBREW_FLUENCY.value] = await self._analyze_hebrew_fluency(text)
        
        # ניתוח הולמות
        analysis[ReviewCriteria.APPROPRIATENESS.value] = await self._analyze_appropriateness(text)
        
        # ניתוח תועלת
        analysis[ReviewCriteria.HELPFULNESS.value] = await self._analyze_helpfulness(text)
        
        return analysis
    
    async def _analyze_accuracy(self, text: str) -> float:
        """ניתוח דיוק"""
        score = 0.8  # ברירת מחדל
        
        # בדיקת סתירות
        if "לא" in text and any(pos in text for pos in ["כן", "בהחלט", "בוודאי"]):
            score -= 0.1
        
        # בדיקת עקביות במספרים/תאריכים
        numbers = re.findall(r'\d+', text)
        if len(set(numbers)) != len(numbers) and len(numbers) > 2:
            score -= 0.05  # יותר מדי חזרה על מספרים
        
        # בדיקת טענות קיצוניות
        extreme_words = ["תמיד", "אף פעם", "כולם", "אף אחד", "הכל", "כלום"]
        extreme_count = sum(1 for word in extreme_words if word in text)
        score -= min(extreme_count * 0.05, 0.2)
        
        return max(0.0, min(1.0, score))
    
    async def _analyze_completeness(self, text: str) -> float:
        """ניתוח שלמות"""
        words = text.split()
        word_count = len(words)
        
        # ניקוד לפי אורך
        if word_count < 10:
            length_score = 0.3
        elif word_count < 50:
            length_score = 0.6
        elif word_count < 200:
            length_score = 0.9
        else:
            length_score = 1.0
        
        # בדיקת מבנה
        sentences = re.split(r'[.!?]', text)
        sentence_count = len([s for s in sentences if s.strip()])
        
        structure_score = 0.5
        if sentence_count >= 3:
            structure_score = 0.8
        if sentence_count >= 5:
            structure_score = 1.0
        
        # בדיקת פתיחה וסיכום
        has_intro = any(word in text[:100] for word in ["ראשית", "בהתחלה", "לפני", "כדי"])
        has_conclusion = any(word in text[-100:] for word in ["לסיכום", "לבסוף", "בסופו", "תודה"])
        
        conclusion_score = 0.5
        if has_intro:
            conclusion_score += 0.2
        if has_conclusion:
            conclusion_score += 0.3
        
        return (length_score + structure_score + conclusion_score) / 3
    
    async def _analyze_clarity(self, text: str) -> float:
        """ניתוח בהירות"""
        words = text.split()
        sentences = re.split(r'[.!?]', text)
        
        # אורך משפט ממוצע
        sentence_lengths = [len(s.split()) for s in sentences if s.strip()]
        avg_sentence_length = sum(sentence_lengths) / len(sentence_lengths) if sentence_lengths else 0
        
        optimal_min, optimal_max = self.quality_indicators["sentence_length_optimal"]
        if optimal_min <= avg_sentence_length <= optimal_max:
            length_score = 1.0
        else:
            length_score = max(0.0, 1.0 - abs(avg_sentence_length - (optimal_min + optimal_max) / 2) * 0.05)
        
        # מורכבות משפטים
        complex_indicators = self.quality_indicators["complexity_indicators"]
        complexity_count = sum(1 for indicator in complex_indicators if indicator in text)
        complexity_ratio = complexity_count / len(sentences) if sentences else 0
        complexity_score = min(1.0, complexity_ratio * 2)  # עד 50% מורכבות זה טוב
        
        # מילות קישור וחיבור
        clarity_indicators = self.quality_indicators["clarity_indicators"]
        clarity_count = sum(1 for indicator in clarity_indicators if indicator in text)
        clarity_ratio = clarity_count / len(sentences) if sentences else 0
        clarity_score = min(1.0, clarity_ratio * 3)
        
        return (length_score + complexity_score + clarity_score) / 3
    
    async def _analyze_relevance(self, text: str) -> float:
        """ניתוח רלוונטיות"""
        # ניתוח בסיסי - בפועל יהיה תלוי בהקשר המשימה
        score = 0.7  # ברירת מחדל
        
        # בדיקת חזרות מיותרות
        words = text.lower().split()
        word_freq = {}
        for word in words:
            if len(word) > 3:  # רק מילים משמעותיות
                word_freq[word] = word_freq.get(word, 0) + 1
        
        # עונש על חזרות מוגזמות
        repetition_penalty = 0
        for word, freq in word_freq.items():
            if freq > len(words) * 0.05:  # יותר מ-5% מהטקסט
                repetition_penalty += 0.1
        
        score -= min(repetition_penalty, 0.3)
        
        # בונוס על מילות מפתח רלוונטיות
        professional_terms = self.hebrew_patterns["professional_terms"]
        professional_count = sum(1 for term in professional_terms if term in text)
        if professional_count > 0:
            score += min(professional_count * 0.05, 0.2)
        
        return max(0.0, min(1.0, score))
    
    async def _analyze_professionalism(self, text: str) -> float:
        """ניתוח מקצועיות"""
        formal_words = self.hebrew_patterns["formal_language"]
        informal_words = self.hebrew_patterns["informal_language"]
        
        formal_count = sum(1 for word in formal_words if word in text)
        informal_count = sum(1 for word in informal_words if word in text)
        
        # ניקוד לפי יחס פורמלי/לא פורמלי
        total_markers = formal_count + informal_count
        if total_markers == 0:
            return 0.7  # נייטרלי
        
        formal_ratio = formal_count / total_markers
        
        # העדפה לשפה פורמלית במקצועיות
        if formal_ratio >= 0.7:
            return 1.0
        elif formal_ratio >= 0.5:
            return 0.8
        elif formal_ratio >= 0.3:
            return 0.6
        else:
            return 0.4
    
    async def _analyze_hebrew_fluency(self, text: str) -> float:
        """ניתוח שטף עברית"""
        score = 0.8  # ברירת מחדל
        
        # בדיקת תעתיק שגוי מאנגלית
        english_patterns = re.findall(r'[a-zA-Z]+', text)
        if english_patterns:
            english_ratio = len(' '.join(english_patterns)) / len(text)
            score -= min(english_ratio * 2, 0.4)
        
        # בדיקת שימוש נכון בעברית
        hebrew_chars = len(re.findall(r'[\u0590-\u05FF]', text))
        total_chars = len(re.sub(r'\s', '', text))
        
        if total_chars > 0:
            hebrew_ratio = hebrew_chars / total_chars
            if hebrew_ratio >= 0.8:
                score += 0.1
            elif hebrew_ratio < 0.5:
                score -= 0.2
        
        # בדיקת שגיאות כתיב נפוצות
        common_errors = {
            "אומנם": "אומנם",  # שגיאות דוגמה
            "בקיצור": "בקיצור",
            "לעוופתות": "לעתים קרובות"
        }
        
        for wrong, right in common_errors.items():
            if wrong in text:
                score -= 0.05
        
        return max(0.0, min(1.0, score))
    
    async def _analyze_appropriateness(self, text: str) -> float:
        """ניתוח הולמות"""
        score = 0.8  # ברירת מחדל
        
        # בדיקת טון מתאים
        negative_expressions = self.hebrew_patterns["negative_expressions"]
        positive_expressions = self.hebrew_patterns["positive_expressions"]
        
        negative_count = sum(1 for expr in negative_expressions if expr in text)
        positive_count = sum(1 for expr in positive_expressions if expr in text)
        
        # העדפה לטון חיובי/נייטרלי
        if negative_count > positive_count * 2:
            score -= 0.2
        elif positive_count > 0:
            score += 0.1
        
        # בדיקת אורך מתאים להקשר
        word_count = len(text.split())
        if word_count < 5:
            score -= 0.3  # קצר מדי
        elif word_count > 500:
            score -= 0.1  # ארוך מדי
        
        return max(0.0, min(1.0, score))
    
    async def _analyze_helpfulness(self, text: str) -> float:
        """ניתוח תועלת"""
        score = 0.6  # ברירת מחדל
        
        # בדיקת מילות מפתח מועילות
        helpful_words = [
            "כיצד", "איך", "דרך", "שיטה", "פתרון", "עזרה",
            "המלצה", "הצעה", "טיפ", "עצה", "הוראה", "מדריך"
        ]
        
        helpful_count = sum(1 for word in helpful_words if word in text)
        score += min(helpful_count * 0.05, 0.2)
        
        # בדיקת מבנה מועיל (רשימות, שלבים)
        if "1." in text or "א." in text or "•" in text:
            score += 0.1
        
        # בדיקת דוגמאות
        example_words = ["לדוגמה", "כגון", "למשל", "כמו"]
        if any(word in text for word in example_words):
            score += 0.1
        
        return max(0.0, min(1.0, score))

class SelfReviewEngine:
    """מנוע ביקורת עצמית ראשי"""
    
    def __init__(self, ollama_client=None):
        self.ollama_client = ollama_client
        self.text_analyzer = TextAnalyzer()
        self.review_history = {}
        self.criteria_weights = ReviewCriteriaWeights.DEFAULT_WEIGHTS
        
        # הגדרות
        self.enable_ai_insights = True
        self.enable_detailed_analysis = True
        self.auto_generate_improvements = True
        
        # סטטיסטיקות
        self.review_stats = {
            "total_reviews": 0,
            "average_score": 0.0,
            "improvement_rate": 0.0,
            "common_weaknesses": [],
            "common_strengths": []
        }
    
    async def conduct_self_review(
        self,
        task_id: str,
        task_name: str,
        output_content: str,
        review_type: ReviewType = ReviewType.TASK_COMPLETION,
        context: Dict[str, Any] = None
    ) -> SelfReviewResult:
        """ביצוע ביקורת עצמית מלאה"""
        start_time = time.time()
        
        try:
            # יצירת תוצאת ביקורת
            review_result = SelfReviewResult(
                review_type=review_type,
                task_id=task_id,
                task_name=task_name,
                output_content=output_content,
                context=context or {}
            )
            
            # ניתוח איכות טקסט
            text_analysis = await self.text_analyzer.analyze_text_quality(output_content)
            
            # יצירת ציוני קריטריונים
            for criteria_name, score in text_analysis.items():
                try:
                    criteria = ReviewCriteria(criteria_name)
                    explanation = await self._generate_criteria_explanation(criteria, score, output_content)
                    
                    criteria_score = create_criteria_score(criteria, score, explanation)
                    review_result.add_criteria_score(criteria_score)
                    
                except ValueError:
                    continue  # קריטריון לא ידוע
            
            # הרהור עצמי
            if self.enable_detailed_analysis:
                review_result.self_reflection = await self._generate_self_reflection(
                    output_content, review_result.overall_score
                )
            
            # ניתוח SWOT
            await self._analyze_swot(review_result)
            
            # יצירת המלצות שיפור
            if self.auto_generate_improvements:
                review_result.improvement_recommendations = await self._generate_improvement_recommendations(
                    review_result
                )
            
            # השוואת ביצועים
            review_result.performance_comparison = await self._compare_performance(
                task_id, review_result
            )
            
            # ניתוח AI מתקדם
            if self.enable_ai_insights and self.ollama_client:
                await self._add_ai_insights(review_result)
            
            # עדכון זמן ביקורת
            review_result.review_duration_minutes = (time.time() - start_time) / 60
            
            # שמירת הביקורת
            await self._save_review(review_result)
            
            # עדכון סטטיסטיקות
            self._update_stats(review_result)
            
            logging.info(f"Self-review completed for task {task_name}: {review_result.overall_score:.3f}")
            return review_result
            
        except Exception as e:
            logging.error(f"Self-review error: {str(e)}")
            # החזרת ביקורת בסיסית במקרה של שגיאה
            return SelfReviewResult(
                review_type=review_type,
                task_id=task_id,
                task_name=task_name,
                output_content=output_content,
                overall_score=0.5,
                status=ReviewStatus.NEEDS_IMPROVEMENT
            )
    
    async def _generate_criteria_explanation(
        self,
        criteria: ReviewCriteria,
        score: float,
        content: str
    ) -> str:
        """יצירת הסבר לציון קריטריון"""
        explanations = {
            ReviewCriteria.ACCURACY: {
                (0.9, 1.0): "המידע מדויק ומבוסס היטב",
                (0.7, 0.9): "המידע ברובו מדויק עם חוסרים קלים",
                (0.5, 0.7): "המידע בסיסי אך דורש השלמה",
                (0.0, 0.5): "המידע חסר דיוק או לא מלא"
            },
            ReviewCriteria.CLARITY: {
                (0.9, 1.0): "הטקסט ברור ומובן מאוד",
                (0.7, 0.9): "הטקסט ברור ברובו",
                (0.5, 0.7): "הטקסט מובן אך יכול להיות ברור יותר",
                (0.0, 0.5): "הטקסט לא ברור או מבלבל"
            },
            ReviewCriteria.HELPFULNESS: {
                (0.9, 1.0): "תוכן מועיל מאוד ומעשי",
                (0.7, 0.9): "תוכן מועיל עם ערך מוסף",
                (0.5, 0.7): "תוכן בסיסי שעוזר חלקית",
                (0.0, 0.5): "תוכן לא מועיל או לא רלוונטי"
            }
        }
        
        criteria_explanations = explanations.get(criteria, {})
        
        for (min_score, max_score), explanation in criteria_explanations.items():
            if min_score <= score < max_score:
                return explanation
        
        return f"ציון {score:.2f} עבור {criteria.value}"
    
    async def _generate_self_reflection(self, content: str, overall_score: float) -> SelfReflection:
        """יצירת הרהור עצמי"""
        reflection = SelfReflection()
        
        # ניתוח מה הלך טוב
        if overall_score >= 0.8:
            reflection.what_went_well = "הביצוע היה איכותי עם ציון גבוה ברוב הקריטריונים"
        elif overall_score >= 0.6:
            reflection.what_went_well = "הביצוע היה בסיסי טוב עם מקום לשיפור"
        else:
            reflection.what_went_well = "הושלמה המשימה למרות קשיים"
        
        # ניתוח מה ניתן לשפר
        word_count = len(content.split())
        if word_count < 20:
            reflection.what_could_improve = "להרחיב את התשובה ולתת פרטים נוספים"
        elif "לדוגמה" not in content and "כגון" not in content:
            reflection.what_could_improve = "להוסיף דוגמאות להמחשה"
        else:
            reflection.what_could_improve = "לשפר את הבהירות ואת מבנה התשובה"
        
        # מה נלמד
        reflection.what_learned = "כל ביצוע הוא הזדמנות ללמידה ושיפור"
        
        # מצב רגשי
        if overall_score >= 0.8:
            reflection.emotional_state = "מרוצה"
            reflection.motivation_level = 0.8
        elif overall_score >= 0.6:
            reflection.emotional_state = "אופטימי"
            reflection.motivation_level = 0.7
        else:
            reflection.emotional_state = "נחוש לשפר"
            reflection.motivation_level = 0.9
        
        # מטרות עתידיות
        reflection.short_term_goals = [
            "שיפור איכות התוכן",
            "הוספת דוגמאות רלוונטיות",
            "שיפור בהירות ההסבר"
        ]
        
        reflection.learning_objectives = [
            "להבין טוב יותר את צרכי המשתמש",
            "לשפר את יכולות הניתוח",
            "לפתח סגנון כתיבה ברור יותר"
        ]
        
        return reflection
    
    async def _analyze_swot(self, review_result: SelfReviewResult):
        """ניתוח SWOT (חוזקות, חולשות, הזדמנויות, איומים)"""
        scores_by_criteria = {score.criteria: score.score for score in review_result.criteria_scores}
        
        # חוזקות - קריטריונים עם ציון גבוה
        strengths = []
        for criteria, score in scores_by_criteria.items():
            if score >= 0.8:
                strengths.append(f"{criteria.value} - ציון מעולה ({score:.2f})")
        
        if not strengths:
            strengths.append("הושלמה המשימה בהצלחה")
        
        # חולשות - קריטריונים עם ציון נמוך
        weaknesses = []
        for criteria, score in scores_by_criteria.items():
            if score < 0.6:
                weaknesses.append(f"{criteria.value} - דורש שיפור ({score:.2f})")
        
        if not weaknesses:
            weaknesses.append("לא נמצאו חולשות משמעותיות")
        
        # הזדמנויות
        opportunities = [
            "שיפור מתמיד של היכולות",
            "למידה מכל ביקורת",
            "פיתוח מומחיות בתחומים חדשים"
        ]
        
        # איומים/אתגרים
        threats = []
        if review_result.overall_score < 0.5:
            threats.append("ציון נמוך עלול להשפיע על אמינות")
        if len(weaknesses) > 3:
            threats.append("מספר רב של תחומי שיפור")
        
        if not threats:
            threats.append("התחרות והצורך בשיפור מתמיד")
        
        review_result.strengths = strengths
        review_result.weaknesses = weaknesses
        review_result.opportunities = opportunities
        review_result.threats = threats
    
    async def _generate_improvement_recommendations(
        self,
        review_result: SelfReviewResult
    ) -> List[ImprovementRecommendation]:
        """יצירת המלצות שיפור"""
        recommendations = []
        
        # המלצות לפי ציוני קריטריונים
        for criteria_score in review_result.criteria_scores:
            if criteria_score.score < 0.7:
                priority = ImprovementPriority.HIGH if criteria_score.score < 0.5 else ImprovementPriority.MEDIUM
                
                recommendation = create_improvement_recommendation(
                    title=f"שיפור {criteria_score.criteria.value}",
                    description=f"הציון הנוכחי הוא {criteria_score.score:.2f}, יש מקום לשיפור משמעותי",
                    priority=priority,
                    impact=1.0 - criteria_score.score  # ככל שהציון נמוך יותר, השפעת השיפור גבוהה יותר
                )
                
                # הצעות יישום ספציפיות לכל קריטריון
                if criteria_score.criteria == ReviewCriteria.CLARITY:
                    recommendation.implementation_steps = [
                        "שימוש במשפטים קצרים וברורים",
                        "הוספת דוגמאות להמחשה",
                        "ארגון התוכן בסדר לוגי",
                        "שימוש במילות קישור"
                    ]
                elif criteria_score.criteria == ReviewCriteria.COMPLETENESS:
                    recommendation.implementation_steps = [
                        "הרחבת התשובה בפרטים נוספים",
                        "מתן תשובה לכל חלקי השאלה",
                        "הוספת הקשר רחב יותר",
                        "סיכום המידע העיקרי"
                    ]
                elif criteria_score.criteria == ReviewCriteria.HELPFULNESS:
                    recommendation.implementation_steps = [
                        "הוספת עצות מעשיות",
                        "מתן פתרונות קונקרטיים",
                        "הצעת צעדי פעולה",
                        "התייחסות לצרכי המשתמש"
                    ]
                
                recommendation.target_criteria = [criteria_score.criteria]
                recommendation.current_score = criteria_score.score
                recommendation.target_score = min(criteria_score.score + 0.3, 1.0)
                
                recommendations.append(recommendation)
        
        # המלצה כללית אם הציון הכללי נמוך
        if review_result.overall_score < 0.6:
            general_recommendation = create_improvement_recommendation(
                title="שיפור כללי של איכות הביצוע",
                description="יש להתמקד בשיפור כללי של איכות העבודה",
                priority=ImprovementPriority.HIGH,
                impact=0.8
            )
            
            general_recommendation.implementation_steps = [
                "סקירה מחודשת של הדרישות",
                "הקדשת זמן נוסף לבדיקה עצמית",
                "קבלת משוב מגורמים נוספים",
                "למידת שיטות עבודה משופרות"
            ]
            
            recommendations.append(general_recommendation)
        
        # מיון לפי עדיפות והשפעה
        recommendations.sort(key=lambda r: (r.priority.value, -r.potential_impact))
        
        return recommendations[:5]  # הגבלה ל-5 המלצות עיקריות
    
    async def _compare_performance(self, task_id: str, current_review: SelfReviewResult) -> Optional[PerformanceComparison]:
        """השוואת ביצועים למשימות קודמות"""
        # חיפוש ביקורות קודמות דומות
        entity_id = task_id.split('_')[0] if '_' in task_id else "general"
        
        if entity_id not in self.review_history:
            return None
        
        history = self.review_history[entity_id]
        recent_reviews = history.reviews[-5:]  # 5 האחרונות
        
        if len(recent_reviews) < 2:
            return None
        
        # השוואה לממוצע הביקורות הקודמות
        previous_avg_score = sum(r.overall_score for r in recent_reviews[:-1]) / len(recent_reviews[:-1])
        current_score = current_review.overall_score
        
        comparison = PerformanceComparison(
            comparison_type="temporal",
            current_performance={"overall_score": current_score},
            reference_performance={"overall_score": previous_avg_score}
        )
        
        change = current_score - previous_avg_score
        comparison.overall_change = change
        
        if abs(change) < 0.05:
            comparison.insights.append("ביצועים יציבים ללא שינוי משמעותי")
        elif change > 0.1:
            comparison.improvements.append("שיפור משמעותי בביצועים")
            comparison.insights.append("מגמת שיפור חיובית")
        elif change < -0.1:
            comparison.regressions.append("ירידה בביצועים")
            comparison.insights.append("יש לבחון סיבות לירידה")
        
        return comparison
    
    async def _add_ai_insights(self, review_result: SelfReviewResult):
        """הוספת תובנות AI מתקדמות"""
        if not self.ollama_client:
            return
        
        try:
            # בניית prompt לניתוח AI
            prompt = f"""
            בצע ניתוח מעמיק של הביצוע הבא:
            
            משימה: {review_result.task_name}
            תוכן הפלט: {review_result.output_content[:500]}...
            ציון כללי: {review_result.overall_score:.2f}
            
            חוזקות מזוהות:
            {chr(10).join(review_result.strengths)}
            
            חולשות מזוהות:
            {chr(10).join(review_result.weaknesses)}
            
            אנא ספק:
            1. ניתוח איכות התוכן
            2. הערכת הביצוע מבחינה מקצועית
            3. המלצות ספציפיות לשיפור
            4. הערכת ההתאמה לציבור הישראלי
            
            תן תשובה מקצועית וקצרה בעברית.
            """
            
            # כאן יהיה הקוד לשליחה למודל Ollama
            # לעת עתה מחזירים ניתוח בסיסי
            ai_insight = f"""
            ניתוח AI: הביצוע הושג ברמה של {review_result.get_grade_summary()}.
            התוכן מתאים לקהל הישראלי ומשקף הבנה תרבותית.
            יש להמשיך לשפר את הבהירות והמעשיות.
            """
            
            review_result.metadata["ai_insights"] = ai_insight
            review_result.ai_confidence = 0.75
            
        except Exception as e:
            logging.error(f"AI insights error: {str(e)}")
            review_result.metadata["ai_insights"] = "שגיאה בניתוח AI"
            review_result.ai_confidence = 0.0
    
    async def _save_review(self, review_result: SelfReviewResult):
        """שמירת ביקורת להיסטוריה"""
        entity_id = review_result.task_id.split('_')[0] if '_' in review_result.task_id else "general"
        
        if entity_id not in self.review_history:
            self.review_history[entity_id] = ReviewHistory(
                entity_id=entity_id,
                entity_type="task"
            )
        
        self.review_history[entity_id].add_review(review_result)
    
    def _update_stats(self, review_result: SelfReviewResult):
        """עדכון סטטיסטיקות כלליות"""
        self.review_stats["total_reviews"] += 1
        
        # עדכון ציון ממוצע
        total_reviews = self.review_stats["total_reviews"]
        current_avg = self.review_stats["average_score"]
        new_avg = ((current_avg * (total_reviews - 1)) + review_result.overall_score) / total_reviews
        self.review_stats["average_score"] = new_avg
        
        # עדכון חולשות ושזקות נפוצות
        for weakness in review_result.weaknesses:
            if weakness not in self.review_stats["common_weaknesses"]:
                self.review_stats["common_weaknesses"].append(weakness)
        
        for strength in review_result.strengths:
            if strength not in self.review_stats["common_strengths"]:
                self.review_stats["common_strengths"].append(strength)
    
    # API פונקציות
    
    def get_review_history(self, entity_id: str) -> Optional[ReviewHistory]:
        """קבלת היסטוריית ביקורות"""
        return self.review_history.get(entity_id)
    
    def get_latest_reviews(self, limit: int = 10) -> List[SelfReviewResult]:
        """קבלת ביקורות אחרונות"""
        all_reviews = []
        for history in self.review_history.values():
            all_reviews.extend(history.reviews)
        
        all_reviews.sort(key=lambda r: r.timestamp, reverse=True)
        return all_reviews[:limit]
    
    def get_performance_trends(self, entity_id: str) -> Dict[str, Any]:
        """קבלת מגמות ביצועים"""
        history = self.review_history.get(entity_id)
        if not history:
            return {}
        
        return {
            "improvement_trend": history.improvement_trend,
            "learning_rate": history.learning_rate,
            "consistency_score": history.consistency_score,
            "average_score": history.get_average_score(),
            "score_progression": history.get_improvement_over_time()
        }
    
    def get_system_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות מערכת"""
        return self.review_stats.copy()
    
    async def bulk_review(self, tasks: List[Dict[str, Any]]) -> List[SelfReviewResult]:
        """ביקורת מרובה של משימות"""
        results = []
        
        for task in tasks:
            try:
                result = await self.conduct_self_review(**task)
                results.append(result)
            except Exception as e:
                logging.error(f"Bulk review error for task {task.get('task_id', 'unknown')}: {str(e)}")
        
        return results

# פונקציות עזר
def create_review_engine(ollama_client=None) -> SelfReviewEngine:
    """יצירת מנוע ביקורת עצמית"""
    return SelfReviewEngine(ollama_client)

async def quick_self_review(content: str, task_name: str = "quick_review") -> SelfReviewResult:
    """ביקורת עצמית מהירה"""
    engine = create_review_engine()
    return await engine.conduct_self_review(
        task_id=f"quick_{int(time.time())}",
        task_name=task_name,
        output_content=content,
        review_type=ReviewType.OUTPUT_QUALITY
    )