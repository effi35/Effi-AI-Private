"""
כלים שימושיים למערכת השליטה הדיגיטלית
פונקציות עזר לביצוע קוד, ניהול תהליכים ואבטחה
"""

import os
import sys
import subprocess
import threading
import tempfile
import shutil
import psutil
import docker
import signal
import time
import json
import hashlib
import socket
import platform
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Union
from pathlib import Path
import resource
import pwd
import grp
from contextlib import contextmanager
import ast
import re
import sqlite3

class SecurityManager:
    """מנהל אבטחה למערכת השליטה הדיגיטלית"""
    
    # רשימת פקודות מסוכנות
    DANGEROUS_COMMANDS = {
        'bash': [
            'rm -rf', 'format', 'fdisk', 'mkfs', 'dd if=', 'sudo', 'su',
            'passwd', 'useradd', 'userdel', 'chmod 777', 'chown', 'mount',
            'umount', 'iptables', 'systemctl', 'service', 'kill -9',
            'pkill', 'killall', 'reboot', 'shutdown', 'halt'
        ],
        'python': [
            'os.system', 'subprocess.', 'exec(', 'eval(', '__import__',
            'open(', 'file(', 'input(', 'raw_input(', 'compile(',
            'globals()', 'locals()', 'vars()', 'dir()', 'getattr',
            'setattr', 'delattr', 'hasattr'
        ],
        'javascript': [
            'eval(', 'Function(', 'setTimeout(', 'setInterval(',
            'document.', 'window.', 'global.', 'process.', 'require(',
            'fs.', 'child_process', 'net.', 'http.', 'https.'
        ]
    }
    
    @staticmethod
    def check_code_safety(code: str, language: str, security_level: str = 'medium') -> Dict[str, Any]:
        """בדיקת בטיחות קוד לפני ביצוע"""
        result = {
            'safe': True,
            'warnings': [],
            'errors': [],
            'risk_level': 'low'
        }
        
        if security_level == 'low':
            return result  # אין בדיקות באבטחה נמוכה
        
        dangerous_patterns = SecurityManager.DANGEROUS_COMMANDS.get(language, [])
        
        # בדיקת פקודות מסוכנות
        for pattern in dangerous_patterns:
            if pattern.lower() in code.lower():
                warning = f"זוהתה פקודה מסוכנת: {pattern}"
                result['warnings'].append(warning)
                result['risk_level'] = 'medium'
                
                if security_level == 'high':
                    result['safe'] = False
                    result['errors'].append(f"פקודה חסומה: {pattern}")
                    result['risk_level'] = 'high'
        
        # בדיקות נוספות לפי שפה
        if language == 'python':
            result.update(SecurityManager._check_python_safety(code, security_level))
        elif language == 'bash':
            result.update(SecurityManager._check_bash_safety(code, security_level))
        elif language == 'javascript':
            result.update(SecurityManager._check_javascript_safety(code, security_level))
        
        return result
    
    @staticmethod
    def _check_python_safety(code: str, security_level: str) -> Dict[str, Any]:
        """בדיקת בטיחות קוד Python"""
        result = {'warnings': [], 'errors': []}
        
        try:
            # ניתוח AST לזיהוי מבנים מסוכנים
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                # בדיקת imports מסוכנים
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in ['os', 'subprocess', 'sys', 'shutil']:
                            result['warnings'].append(f"ייבוא מסוכן: {alias.name}")
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module in ['os', 'subprocess', 'sys', 'shutil']:
                        result['warnings'].append(f"ייבוא מסוכן: from {node.module}")
                
                # בדיקת קריאות פונקציה מסוכנות
                elif isinstance(node, ast.Call):
                    if hasattr(node.func, 'id'):
                        if node.func.id in ['exec', 'eval', 'compile']:
                            if security_level == 'high':
                                result['errors'].append(f"פונקציה חסומה: {node.func.id}")
                            else:
                                result['warnings'].append(f"פונקציה מסוכנת: {node.func.id}")
        
        except SyntaxError as e:
            result['warnings'].append(f"שגיאת תחביר: {str(e)}")
        except Exception as e:
            result['warnings'].append(f"שגיאה בניתוח קוד: {str(e)}")
        
        return result
    
    @staticmethod
    def _check_bash_safety(code: str, security_level: str) -> Dict[str, Any]:
        """בדיקת בטיחות קוד Bash"""
        result = {'warnings': [], 'errors': []}
        
        lines = code.split('\n')
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            # בדיקת פקודות מסוכנות
            if any(cmd in line.lower() for cmd in ['rm -rf /', 'format c:', 'dd if=/dev/zero']):
                if security_level == 'high':
                    result['errors'].append(f"שורה {line_num}: פקודה הרסנית חסומה")
                else:
                    result['warnings'].append(f"שורה {line_num}: פקודה מסוכנת זוהתה")
            
            # בדיקת הרשאות root
            if line.startswith('sudo ') or line.startswith('su '):
                result['warnings'].append(f"שורה {line_num}: ניסיון הסלמת הרשאות")
        
        return result
    
    @staticmethod
    def _check_javascript_safety(code: str, security_level: str) -> Dict[str, Any]:
        """בדיקת בטיחות קוד JavaScript"""
        result = {'warnings': [], 'errors': []}
        
        # בדיקת פונקציות מסוכנות
        dangerous_js = ['eval(', 'Function(', 'document.write(', 'innerHTML']
        for func in dangerous_js:
            if func in code:
                if security_level == 'high':
                    result['errors'].append(f"פונקציה חסומה: {func}")
                else:
                    result['warnings'].append(f"פונקציה מסוכנת: {func}")
        
        return result

class ProcessManager:
    """מנהל תהליכים מתקדם"""
    
    def __init__(self):
        self.active_processes = {}
        self.process_limits = {
            'max_processes': 10,
            'max_memory_mb': 512,
            'max_cpu_percent': 80,
            'max_execution_time': 300
        }
    
    def create_process(self, command: List[str], working_dir: str = None,
                      env: Dict[str, str] = None, timeout: int = 300) -> Dict[str, Any]:
        """יצירת תהליך חדש עם ניטור"""
        try:
            # בדיקת מגבלות
            if len(self.active_processes) >= self.process_limits['max_processes']:
                return {
                    'success': False,
                    'error': 'מספר התהליכים הפעילים עבר את המגבלה',
                    'process_id': None
                }
            
            # יצירת התהליך
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=working_dir,
                env=env,
                text=True,
                preexec_fn=os.setsid  # יצירת קבוצת תהליכים חדשה
            )
            
            process_id = f"proc_{process.pid}_{int(time.time())}"
            
            # שמירת מידע על התהליך
            process_info = {
                'process': process,
                'command': command,
                'start_time': datetime.now(),
                'timeout': timeout,
                'working_dir': working_dir,
                'status': 'running'
            }
            
            self.active_processes[process_id] = process_info
            
            # התחלת ניטור התהליך
            threading.Thread(
                target=self._monitor_process, 
                args=(process_id,), 
                daemon=True
            ).start()
            
            return {
                'success': True,
                'process_id': process_id,
                'pid': process.pid,
                'error': None
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'שגיאה ביצירת תהליך: {str(e)}',
                'process_id': None
            }
    
    def _monitor_process(self, process_id: str):
        """ניטור תהליך פעיל"""
        if process_id not in self.active_processes:
            return
        
        process_info = self.active_processes[process_id]
        process = process_info['process']
        start_time = process_info['start_time']
        timeout = process_info['timeout']
        
        try:
            psutil_process = psutil.Process(process.pid)
            
            while process.poll() is None:  # כל עוד התהליך פעיל
                # בדיקת timeout
                elapsed = (datetime.now() - start_time).total_seconds()
                if elapsed > timeout:
                    self.terminate_process(process_id, reason="timeout")
                    break
                
                # בדיקת שימוש משאבים
                try:
                    cpu_percent = psutil_process.cpu_percent()
                    memory_mb = psutil_process.memory_info().rss / (1024 * 1024)
                    
                    if cpu_percent > self.process_limits['max_cpu_percent']:
                        logging.warning(f"תהליך {process_id} עובר מגבלת CPU: {cpu_percent}%")
                    
                    if memory_mb > self.process_limits['max_memory_mb']:
                        self.terminate_process(process_id, reason="memory_limit")
                        break
                        
                except psutil.NoSuchProcess:
                    break  # התהליך נסגר
                
                time.sleep(1)  # בדיקה כל שנייה
            
            # עדכון סטטוס סיום
            if process_id in self.active_processes:
                self.active_processes[process_id]['status'] = 'completed'
                self.active_processes[process_id]['end_time'] = datetime.now()
                
        except Exception as e:
            logging.error(f"שגיאה בניטור תהליך {process_id}: {e}")
    
    def get_process_output(self, process_id: str) -> Dict[str, Any]:
        """קבלת פלט התהליך"""
        if process_id not in self.active_processes:
            return {'success': False, 'error': 'תהליך לא נמצא'}
        
        process_info = self.active_processes[process_id]
        process = process_info['process']
        
        try:
            # אם התהליך הסתיים, נקבל את כל הפלט
            if process.poll() is not None:
                stdout, stderr = process.communicate()
                return {
                    'success': True,
                    'stdout': stdout,
                    'stderr': stderr,
                    'return_code': process.returncode,
                    'status': 'completed'
                }
            else:
                # התהליך עדיין פעיל
                return {
                    'success': True,
                    'stdout': '',
                    'stderr': '',
                    'return_code': None,
                    'status': 'running'
                }
        except Exception as e:
            return {'success': False, 'error': f'שגיאה בקבלת פלט: {str(e)}'}
    
    def terminate_process(self, process_id: str, reason: str = "user_request") -> bool:
        """עצירת תהליך"""
        if process_id not in self.active_processes:
            return False
        
        process_info = self.active_processes[process_id]
        process = process_info['process']
        
        try:
            # ניסיון עצירה רכה
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            
            # המתנה לעצירה
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                # עצירה כפויה
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                process.wait()
            
            # עדכון סטטוס
            process_info['status'] = f'terminated_{reason}'
            process_info['end_time'] = datetime.now()
            
            logging.info(f"תהליך {process_id} נעצר - סיבה: {reason}")
            return True
            
        except Exception as e:
            logging.error(f"שגיאה בעצירת תהליך {process_id}: {e}")
            return False
    
    def cleanup_completed_processes(self):
        """ניקוי תהליכים שהסתיימו"""
        completed_processes = [
            pid for pid, info in self.active_processes.items()
            if info['status'] != 'running'
        ]
        
        for process_id in completed_processes:
            if process_id in self.active_processes:
                del self.active_processes[process_id]
        
        return len(completed_processes)
    
    def get_process_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות תהליכים"""
        active_count = len([p for p in self.active_processes.values() if p['status'] == 'running'])
        
        return {
            'total_processes': len(self.active_processes),
            'active_processes': active_count,
            'completed_processes': len(self.active_processes) - active_count,
            'process_limits': self.process_limits
        }

class SandboxManager:
    """מנהל סביבות sandbox לביצוע בטוח"""
    
    def __init__(self):
        self.docker_client = None
        self.sandbox_containers = {}
        self._init_docker()
    
    def _init_docker(self):
        """אתחול Docker client"""
        try:
            self.docker_client = docker.from_env()
            logging.info("Docker client initialized successfully")
        except Exception as e:
            logging.warning(f"Docker not available: {e}")
            self.docker_client = None
    
    def create_sandbox(self, language: str, code: str, 
                      memory_limit: str = "128m", 
                      cpu_limit: str = "0.5") -> Dict[str, Any]:
        """יצירת sandbox לביצוע קוד"""
        if not self.docker_client:
            return self._create_local_sandbox(language, code)
        
        try:
            # בחירת image לפי שפה
            image_map = {
                'python': 'python:3.9-slim',
                'javascript': 'node:16-slim',
                'bash': 'ubuntu:20.04',
                'java': 'openjdk:11-slim',
                'r': 'r-base:latest'
            }
            
            image = image_map.get(language, 'ubuntu:20.04')
            
            # יצירת container
            container = self.docker_client.containers.run(
                image,
                command='sleep 300',  # שמירה על container חי
                detach=True,
                mem_limit=memory_limit,
                cpu_quota=int(float(cpu_limit) * 100000),
                network_disabled=True,  # ללא גישה לרשת
                remove=True,  # ניקוי אוטומטי
                security_opt=['no-new-privileges'],
                read_only=True,  # מערכת קבצים לקריאה בלבד
                tmpfs={'/tmp': 'rw,noexec,nosuid,size=100m'}
            )
            
            sandbox_id = f"sandbox_{container.id[:12]}"
            self.sandbox_containers[sandbox_id] = container
            
            return {
                'success': True,
                'sandbox_id': sandbox_id,
                'container_id': container.id,
                'image': image
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'שגיאה ביצירת sandbox: {str(e)}',
                'sandbox_id': None
            }
    
    def _create_local_sandbox(self, language: str, code: str) -> Dict[str, Any]:
        """יצירת sandbox מקומי (ללא Docker)"""
        try:
            # יצירת ספרייה זמנית
            temp_dir = tempfile.mkdtemp(prefix='sandbox_')
            
            # הגבלת הרשאות
            os.chmod(temp_dir, 0o755)
            
            sandbox_id = f"local_{os.path.basename(temp_dir)}"
            
            return {
                'success': True,
                'sandbox_id': sandbox_id,
                'temp_dir': temp_dir,
                'type': 'local'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'שגיאה ביצירת sandbox מקומי: {str(e)}',
                'sandbox_id': None
            }
    
    def execute_in_sandbox(self, sandbox_id: str, language: str, 
                          code: str, timeout: int = 30) -> Dict[str, Any]:
        """ביצוע קוד בסביבת sandbox"""
        if sandbox_id not in self.sandbox_containers:
            return {'success': False, 'error': 'Sandbox לא נמצא'}
        
        container = self.sandbox_containers[sandbox_id]
        
        try:
            # יצירת קובץ זמני עם הקוד
            if language == 'python':
                file_content = code
                exec_command = ['python', '-c', file_content]
            elif language == 'javascript':
                file_content = code
                exec_command = ['node', '-e', file_content]
            elif language == 'bash':
                file_content = code
                exec_command = ['bash', '-c', file_content]
            else:
                return {'success': False, 'error': f'שפה לא נתמכת: {language}'}
            
            # ביצוע הקוד
            result = container.exec_run(
                exec_command,
                workdir='/tmp',
                user='nobody',  # הרשאות מינימליות
                environment={'HOME': '/tmp'},
                timeout=timeout
            )
            
            return {
                'success': result.exit_code == 0,
                'output': result.output.decode('utf-8', errors='ignore'),
                'exit_code': result.exit_code,
                'execution_time': timeout  # TODO: מדידת זמן אמיתי
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'שגיאה בביצוע: {str(e)}',
                'output': '',
                'exit_code': -1
            }
    
    def destroy_sandbox(self, sandbox_id: str) -> bool:
        """השמדת sandbox"""
        if sandbox_id not in self.sandbox_containers:
            return False
        
        try:
            container = self.sandbox_containers[sandbox_id]
            container.stop(timeout=5)
            container.remove()
            del self.sandbox_containers[sandbox_id]
            return True
        except Exception as e:
            logging.error(f"שגיאה בהשמדת sandbox: {e}")
            return False

class SystemMonitor:
    """ניטור מערכת מתקדם"""
    
    def __init__(self):
        self.monitoring_data = {
            'cpu_history': [],
            'memory_history': [],
            'disk_history': [],
            'network_history': [],
            'process_history': []
        }
        self.monitoring_active = False
    
    def start_monitoring(self, interval: int = 5):
        """התחלת ניטור מערכת"""
        self.monitoring_active = True
        threading.Thread(target=self._monitoring_loop, args=(interval,), daemon=True).start()
    
    def stop_monitoring(self):
        """עצירת ניטור"""
        self.monitoring_active = False
    
    def _monitoring_loop(self, interval: int):
        """לולאת ניטור רציפה"""
        while self.monitoring_active:
            try:
                timestamp = datetime.now()
                
                # ניטור CPU
                cpu_percent = psutil.cpu_percent(interval=1)
                self.monitoring_data['cpu_history'].append({
                    'timestamp': timestamp,
                    'value': cpu_percent
                })
                
                # ניטור זיכרון
                memory = psutil.virtual_memory()
                self.monitoring_data['memory_history'].append({
                    'timestamp': timestamp,
                    'used_percent': memory.percent,
                    'used_mb': memory.used / (1024 * 1024),
                    'available_mb': memory.available / (1024 * 1024)
                })
                
                # ניטור דיסק
                disk = psutil.disk_usage('/')
                self.monitoring_data['disk_history'].append({
                    'timestamp': timestamp,
                    'used_percent': (disk.used / disk.total) * 100,
                    'used_gb': disk.used / (1024 * 1024 * 1024),
                    'free_gb': disk.free / (1024 * 1024 * 1024)
                })
                
                # ניטור רשת
                net_io = psutil.net_io_counters()
                self.monitoring_data['network_history'].append({
                    'timestamp': timestamp,
                    'bytes_sent': net_io.bytes_sent,
                    'bytes_recv': net_io.bytes_recv,
                    'packets_sent': net_io.packets_sent,
                    'packets_recv': net_io.packets_recv
                })
                
                # שמירה של 1000 רשומות אחרונות בלבד
                for key in self.monitoring_data:
                    if len(self.monitoring_data[key]) > 1000:
                        self.monitoring_data[key] = self.monitoring_data[key][-1000:]
                
                time.sleep(interval)
                
            except Exception as e:
                logging.error(f"שגיאה בניטור מערכת: {e}")
    
    def get_current_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות נוכחיות"""
        try:
            return {
                'cpu': {
                    'percent': psutil.cpu_percent(),
                    'count': psutil.cpu_count(),
                    'freq': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None
                },
                'memory': psutil.virtual_memory()._asdict(),
                'disk': psutil.disk_usage('/')._asdict(),
                'network': psutil.net_io_counters()._asdict(),
                'boot_time': datetime.fromtimestamp(psutil.boot_time()),
                'load_avg': os.getloadavg() if hasattr(os, 'getloadavg') else None
            }
        except Exception as e:
            logging.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    def get_process_list(self) -> List[Dict[str, Any]]:
        """קבלת רשימת תהליכים"""
        processes = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 
                                           'memory_percent', 'status', 'create_time']):
                try:
                    pinfo = proc.info
                    pinfo['create_time'] = datetime.fromtimestamp(pinfo['create_time'])
                    processes.append(pinfo)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            logging.error(f"שגיאה בקבלת רשימת תהליכים: {e}")
        
        return processes
    
    def get_system_info(self) -> Dict[str, Any]:
        """קבלת מידע מערכת כללי"""
        try:
            return {
                'platform': platform.platform(),
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'hostname': socket.gethostname(),
                'python_version': platform.python_version(),
                'uptime': datetime.now() - datetime.fromtimestamp(psutil.boot_time())
            }
        except Exception as e:
            logging.error(f"שגיאה בקבלת מידע מערכת: {e}")
            return {}

class CodeExecutor:
    """מבצע קוד מתקדם עם תמיכה במספר שפות"""
    
    def __init__(self):
        self.supported_languages = {
            'python': self._execute_python,
            'javascript': self._execute_javascript,
            'bash': self._execute_bash,
            'sql': self._execute_sql,
            'r': self._execute_r,
            'java': self._execute_java
        }
        self.temp_dir = tempfile.mkdtemp(prefix='code_executor_')
    
    def execute(self, code: str, language: str, 
                security_level: str = 'medium',
                timeout: int = 30,
                working_dir: str = None) -> Dict[str, Any]:
        """ביצוע קוד עם אבטחה וניטור"""
        
        # בדיקת אבטחה
        security_check = SecurityManager.check_code_safety(code, language, security_level)
        if not security_check['safe']:
            return {
                'success': False,
                'output': '',
                'error': f"קוד חסום מסיבות אבטחה: {'; '.join(security_check['errors'])}",
                'execution_time': 0,
                'security_warnings': security_check['warnings']
            }
        
        # בחירת פונקציית ביצוע
        if language not in self.supported_languages:
            return {
                'success': False,
                'output': '',
                'error': f'שפה לא נתמכת: {language}',
                'execution_time': 0
            }
        
        start_time = time.time()
        
        try:
            # ביצוע הקוד
            executor_func = self.supported_languages[language]
            result = executor_func(code, timeout, working_dir or self.temp_dir)
            
            execution_time = time.time() - start_time
            result['execution_time'] = execution_time
            result['security_warnings'] = security_check['warnings']
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע: {str(e)}',
                'execution_time': time.time() - start_time,
                'security_warnings': security_check['warnings']
            }
    
    def _execute_python(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד Python"""
        try:
            # יצירת קובץ זמני
            code_file = os.path.join(working_dir, f'script_{int(time.time())}.py')
            with open(code_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # ביצוע הקוד
            result = subprocess.run(
                [sys.executable, code_file],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir
            )
            
            # ניקוי
            os.remove(code_file)
            
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else '',
                'return_code': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': f'הקוד חרג מזמן המותר ({timeout} שניות)',
                'return_code': -1
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע Python: {str(e)}',
                'return_code': -1
            }
    
    def _execute_javascript(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד JavaScript"""
        try:
            # בדיקה אם Node.js זמין
            node_check = subprocess.run(['node', '--version'], 
                                      capture_output=True, text=True)
            if node_check.returncode != 0:
                return {
                    'success': False,
                    'output': '',
                    'error': 'Node.js לא מותקן במערכת',
                    'return_code': -1
                }
            
            # יצירת קובץ זמני
            code_file = os.path.join(working_dir, f'script_{int(time.time())}.js')
            with open(code_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # ביצוע הקוד
            result = subprocess.run(
                ['node', code_file],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir
            )
            
            # ניקוי
            os.remove(code_file)
            
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else '',
                'return_code': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': f'הקוד חרג מזמן המותר ({timeout} שניות)',
                'return_code': -1
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע JavaScript: {str(e)}',
                'return_code': -1
            }
    
    def _execute_bash(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד Bash"""
        try:
            # ביצוע ישיר
            result = subprocess.run(
                ['bash', '-c', code],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir
            )
            
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else '',
                'return_code': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': f'הקוד חרג מזמן המותר ({timeout} שניות)',
                'return_code': -1
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע Bash: {str(e)}',
                'return_code': -1
            }
    
    def _execute_sql(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד SQL עם SQLite"""
        try:
            # יצירת בסיס נתונים זמני
            db_file = os.path.join(working_dir, f'temp_db_{int(time.time())}.sqlite')
            
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()
            
            output_lines = []
            
            # ביצוע השאילתות
            for statement in code.split(';'):
                statement = statement.strip()
                if not statement:
                    continue
                
                try:
                    cursor.execute(statement)
                    
                    # אם זו שאילתת SELECT, להציג תוצאות
                    if statement.upper().startswith('SELECT'):
                        results = cursor.fetchall()
                        if results:
                            # הצגת כותרות עמודות
                            columns = [description[0] for description in cursor.description]
                            output_lines.append(' | '.join(columns))
                            output_lines.append('-' * (len(' | '.join(columns))))
                            
                            # הצגת השורות
                            for row in results:
                                output_lines.append(' | '.join(str(cell) for cell in row))
                        else:
                            output_lines.append('אין תוצאות')
                    else:
                        # עבור שאילתות אחרות (INSERT, UPDATE, DELETE)
                        if cursor.rowcount > 0:
                            output_lines.append(f'הושפעו {cursor.rowcount} שורות')
                        else:
                            output_lines.append('השאילתה בוצעה בהצלחה')
                
                except sqlite3.Error as e:
                    output_lines.append(f'שגיאה ב-SQL: {str(e)}')
            
            conn.commit()
            conn.close()
            
            # ניקוי
            if os.path.exists(db_file):
                os.remove(db_file)
            
            return {
                'success': True,
                'output': '\n'.join(output_lines),
                'error': '',
                'return_code': 0
            }
            
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע SQL: {str(e)}',
                'return_code': -1
            }
    
    def _execute_r(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד R"""
        try:
            # בדיקה אם R זמין
            r_check = subprocess.run(['R', '--version'], 
                                   capture_output=True, text=True)
            if r_check.returncode != 0:
                return {
                    'success': False,
                    'output': '',
                    'error': 'R לא מותקן במערכת',
                    'return_code': -1
                }
            
            # יצירת קובץ זמני
            code_file = os.path.join(working_dir, f'script_{int(time.time())}.R')
            with open(code_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # ביצוע הקוד
            result = subprocess.run(
                ['Rscript', code_file],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir
            )
            
            # ניקוי
            os.remove(code_file)
            
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else '',
                'return_code': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': f'הקוד חרג מזמן המותר ({timeout} שניות)',
                'return_code': -1
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע R: {str(e)}',
                'return_code': -1
            }
    
    def _execute_java(self, code: str, timeout: int, working_dir: str) -> Dict[str, Any]:
        """ביצוע קוד Java"""
        try:
            # בדיקה אם Java זמין
            java_check = subprocess.run(['java', '-version'], 
                                      capture_output=True, text=True)
            javac_check = subprocess.run(['javac', '-version'], 
                                       capture_output=True, text=True)
            
            if java_check.returncode != 0 or javac_check.returncode != 0:
                return {
                    'success': False,
                    'output': '',
                    'error': 'Java JDK לא מותקן במערכת',
                    'return_code': -1
                }
            
            # זיהוי שם הקלאס הראשי
            class_match = re.search(r'public\s+class\s+(\w+)', code)
            if not class_match:
                return {
                    'success': False,
                    'output': '',
                    'error': 'לא נמצא קלאס ראשי (public class)',
                    'return_code': -1
                }
            
            class_name = class_match.group(1)
            
            # יצירת קובץ Java
            java_file = os.path.join(working_dir, f'{class_name}.java')
            with open(java_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # קימפול
            compile_result = subprocess.run(
                ['javac', java_file],
                capture_output=True,
                text=True,
                cwd=working_dir
            )
            
            if compile_result.returncode != 0:
                os.remove(java_file)
                return {
                    'success': False,
                    'output': '',
                    'error': f'שגיאת קימפול: {compile_result.stderr}',
                    'return_code': compile_result.returncode
                }
            
            # ביצוע
            run_result = subprocess.run(
                ['java', class_name],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir
            )
            
            # ניקוי
            os.remove(java_file)
            class_file = os.path.join(working_dir, f'{class_name}.class')
            if os.path.exists(class_file):
                os.remove(class_file)
            
            return {
                'success': run_result.returncode == 0,
                'output': run_result.stdout,
                'error': run_result.stderr if run_result.returncode != 0 else '',
                'return_code': run_result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': f'הקוד חרג מזמן המותר ({timeout} שניות)',
                'return_code': -1
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה בביצוע Java: {str(e)}',
                'return_code': -1
            }
    
    def cleanup(self):
        """ניקוי קבצים זמניים"""
        try:
            shutil.rmtree(self.temp_dir)
        except Exception as e:
            logging.error(f"שגיאה בניקוי: {e}")

# פונקציות עזר גלובליות
def get_system_capabilities() -> Dict[str, bool]:
    """בדיקת יכולות המערכת"""
    capabilities = {
        'docker': False,
        'python': False,
        'node': False,
        'java': False,
        'r': False,
        'bash': True  # תמיד זמין בלינוקס
    }
    
    # בדיקת Docker
    try:
        docker.from_env()
        capabilities['docker'] = True
    except:
        pass
    
    # בדיקת Python
    try:
        subprocess.run([sys.executable, '--version'], 
                      capture_output=True, check=True)
        capabilities['python'] = True
    except:
        pass
    
    # בדיקת Node.js
    try:
        subprocess.run(['node', '--version'], 
                      capture_output=True, check=True)
        capabilities['node'] = True
    except:
        pass
    
    # בדיקת Java
    try:
        subprocess.run(['java', '-version'], 
                      capture_output=True, check=True)
        subprocess.run(['javac', '-version'], 
                      capture_output=True, check=True)
        capabilities['java'] = True
    except:
        pass
    
    # בדיקת R
    try:
        subprocess.run(['R', '--version'], 
                      capture_output=True, check=True)
        capabilities['r'] = True
    except:
        pass
    
    return capabilities

def validate_execution_environment() -> Dict[str, Any]:
    """אימות סביבת ביצוע"""
    return {
        'platform': platform.system(),
        'python_version': sys.version,
        'capabilities': get_system_capabilities(),
        'temp_dir_writable': os.access(tempfile.gettempdir(), os.W_OK),
        'current_user': os.getenv('USER', 'unknown'),
        'working_directory': os.getcwd(),
        'environment_variables': dict(os.environ)
    }

def create_secure_temp_file(content: str, extension: str = '.tmp') -> str:
    """יצירת קובץ זמני בטוח"""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(content)
        os.chmod(path, 0o600)  # הרשאות קריאה/כתיבה לבעלים בלבד
        return path
    except Exception as e:
        os.close(fd)
        if os.path.exists(path):
            os.remove(path)
        raise e

def cleanup_temp_files(pattern: str = "temp_*"):
    """ניקוי קבצים זמניים"""
    temp_dir = tempfile.gettempdir()
    for file_path in Path(temp_dir).glob(pattern):
        try:
            if file_path.is_file():
                file_path.unlink()
            elif file_path.is_dir():
                shutil.rmtree(file_path)
        except Exception as e:
            logging.warning(f"לא ניתן למחוק {file_path}: {e}")

def generate_execution_report(results: List[Dict[str, Any]]) -> str:
    """יצירת דוח ביצוע מפורט"""
    if not results:
        return "אין תוצאות ביצוע"
    
    total_executions = len(results)
    successful = sum(1 for r in results if r.get('success', False))
    failed = total_executions - successful
    
    total_time = sum(r.get('execution_time', 0) for r in results)
    avg_time = total_time / total_executions if total_executions > 0 else 0
    
    languages = Counter(r.get('language', 'unknown') for r in results)
    
    report = f"""
דוח ביצוע קוד
=============

סיכום כללי:
- סה"כ ביצועים: {total_executions}
- הצלחות: {successful} ({successful/total_executions*100:.1f}%)
- כשלונות: {failed} ({failed/total_executions*100:.1f}%)
- זמן ביצוע כולל: {total_time:.2f} שניות
- זמן ביצוע ממוצע: {avg_time:.2f} שניות

שפות בשימוש:
"""
    
    for language, count in languages.most_common():
        percentage = (count / total_executions) * 100
        report += f"- {language}: {count} ביצועים ({percentage:.1f}%)\n"
    
    # שגיאות נפוצות
    errors = [r.get('error', '') for r in results if not r.get('success', False) and r.get('error')]
    if errors:
        error_counter = Counter(errors)
        report += "\nשגיאות נפוצות:\n"
        for error, count in error_counter.most_common(5):
            report += f"- {error}: {count} פעמים\n"
    
    report += f"\nהדוח נוצר בתאריך: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    return report