"""
לוח בקרה דיגיטלי מתקדם - ממשק לשליטה מלאה במערכת
ממשק משתמש מקצועי לביצוע קוד ושליטה דיגיטלית
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import json
import subprocess
import os
import sys
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import psutil

class ControlDashboard:
    """לוח בקרה דיגיטלי מתקדם"""
    
    def __init__(self, execution_engine=None):
        self.execution_engine = execution_engine
        self.root = None
        self.running = False
        
        # רכיבי UI
        self.code_editor = None
        self.output_text = None
        self.language_var = None
        self.execution_tree = None
        self.resource_monitor = None
        self.log_text = None
        
        # נתונים
        self.execution_history = []
        self.active_processes = {}
        self.system_stats = {}
        
        # הגדרות
        self.settings = {
            'auto_save': True,
            'syntax_highlighting': True,
            'security_level': 'medium',
            'max_execution_time': 300,
            'max_memory_mb': 512
        }
    
    def create_ui(self):
        """יצירת ממשק המשתמש הראשי"""
        self.root = tk.Tk()
        self.root.title("מערכת שליטה דיגיטלית - לוח בקרה")
        self.root.geometry("1600x1000")
        self.root.configure(bg='#1e1e1e')
        
        # יצירת תפריט
        self._create_menu()
        
        # יצירת פריים ראשי
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # חלוקה לאזורים
        self._create_toolbar(main_frame)
        self._create_main_workspace(main_frame)
        self._create_status_bar(main_frame)
        
        # התחלת ניטור
        self.start_monitoring()
        
        return self.root
    
    def _create_menu(self):
        """יצירת תפריט עליון"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # תפריט קובץ
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="קובץ", menu=file_menu)
        file_menu.add_command(label="קובץ חדש", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="פתח קובץ", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="שמור", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="שמור בשם", accelerator="Ctrl+Shift+S", command=self.save_as_file)
        file_menu.add_separator()
        file_menu.add_command(label="ייצוא תוצאות", command=self.export_results)
        file_menu.add_command(label="ייבוא סקריפט", command=self.import_script)
        
        # תפריט ביצוע
        execute_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="ביצוע", menu=execute_menu)
        execute_menu.add_command(label="הרץ קוד", accelerator="F5", command=self.execute_code)
        execute_menu.add_command(label="עצור ביצוע", accelerator="Ctrl+C", command=self.stop_execution)
        execute_menu.add_command(label="ביצוע בטוח", command=self.safe_execute)
        execute_menu.add_separator()
        execute_menu.add_command(label="נקה פלט", command=self.clear_output)
        execute_menu.add_command(label="היסטוריה", command=self.show_history)
        
        # תפריט כלים
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="כלים", menu=tools_menu)
        tools_menu.add_command(label="מנהל תהליכים", command=self.open_process_manager)
        tools_menu.add_command(label="ניטור משאבים", command=self.open_resource_monitor)
        tools_menu.add_command(label="מסוף מערכת", command=self.open_system_terminal)
        tools_menu.add_separator()
        tools_menu.add_command(label="בדיקת אבטחה", command=self.security_check)
        tools_menu.add_command(label="גיבוי מערכת", command=self.system_backup)
        
        # תפריט הגדרות
        settings_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="הגדרות", menu=settings_menu)
        settings_menu.add_command(label="הגדרות ביצוע", command=self.open_execution_settings)
        settings_menu.add_command(label="הגדרות אבטחה", command=self.open_security_settings)
        settings_menu.add_command(label="הגדרות עורך", command=self.open_editor_settings)
        
        # תפריט עזרה
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="עזרה", menu=help_menu)
        help_menu.add_command(label="מדריך שימוש", command=self.show_help)
        help_menu.add_command(label="דוגמאות קוד", command=self.show_examples)
        help_menu.add_command(label="אודות", command=self.show_about)
        
        # קיצורי מקלדת
        self.root.bind('<Control-n>', lambda e: self.new_file())
        self.root.bind('<Control-o>', lambda e: self.open_file())
        self.root.bind('<Control-s>', lambda e: self.save_file())
        self.root.bind('<F5>', lambda e: self.execute_code())
        self.root.bind('<Control-c>', lambda e: self.stop_execution())
    
    def _create_toolbar(self, parent):
        """יצירת סרגל כלים"""
        toolbar_frame = ttk.Frame(parent)
        toolbar_frame.pack(fill=tk.X, pady=(0, 10))
        
        # כפתורי פעולה מהירה
        ttk.Button(toolbar_frame, text="▶ הרץ", 
                  command=self.execute_code).pack(side=tk.LEFT, padx=5)
        ttk.Button(toolbar_frame, text="⏹ עצור", 
                  command=self.stop_execution).pack(side=tk.LEFT, padx=5)
        ttk.Button(toolbar_frame, text="🗑 נקה", 
                  command=self.clear_output).pack(side=tk.LEFT, padx=5)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        # בחירת שפה
        ttk.Label(toolbar_frame, text="שפה:").pack(side=tk.LEFT, padx=(0, 5))
        self.language_var = tk.StringVar(value="python")
        language_combo = ttk.Combobox(toolbar_frame, textvariable=self.language_var,
                                     values=["python", "javascript", "bash", "sql", "r", "java"],
                                     state="readonly", width=12)
        language_combo.pack(side=tk.LEFT, padx=5)
        
        ttk.Separator(toolbar_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        # מצב אבטחה
        ttk.Label(toolbar_frame, text="אבטחה:").pack(side=tk.LEFT, padx=(0, 5))
        self.security_var = tk.StringVar(value="medium")
        security_combo = ttk.Combobox(toolbar_frame, textvariable=self.security_var,
                                     values=["low", "medium", "high", "sandbox"],
                                     state="readonly", width=10)
        security_combo.pack(side=tk.LEFT, padx=5)
        
        # אינדיקטור סטטוס
        self.status_indicator = tk.Label(toolbar_frame, text="●", fg="green", 
                                        font=('Arial', 16))
        self.status_indicator.pack(side=tk.RIGHT, padx=10)
        
        ttk.Label(toolbar_frame, text="סטטוס מערכת:").pack(side=tk.RIGHT, padx=(0, 5))
    
    def _create_main_workspace(self, parent):
        """יצירת אזור העבודה הראשי"""
        # פאנד משמאל - עורך קוד
        left_paned = ttk.PanedWindow(parent, orient=tk.HORIZONTAL)
        left_paned.pack(fill=tk.BOTH, expand=True)
        
        # אזור עורך הקוד
        editor_frame = ttk.LabelFrame(left_paned, text="עורך קוד", padding=10)
        left_paned.add(editor_frame, weight=3)
        
        self._create_code_editor(editor_frame)
        
        # אזור ימני - פלט וניטור
        right_paned = ttk.PanedWindow(left_paned, orient=tk.VERTICAL)
        left_paned.add(right_paned, weight=2)
        
        # אזור פלט
        output_frame = ttk.LabelFrame(right_paned, text="פלט ותוצאות", padding=10)
        right_paned.add(output_frame, weight=1)
        
        self._create_output_area(output_frame)
        
        # אזור ניטור
        monitor_frame = ttk.LabelFrame(right_paned, text="ניטור מערכת", padding=10)
        right_paned.add(monitor_frame, weight=1)
        
        self._create_monitor_area(monitor_frame)
    
    def _create_code_editor(self, parent):
        """יצירת עורך הקוד"""
        # פריים עליון לכלי עורך
        editor_toolbar = ttk.Frame(parent)
        editor_toolbar.pack(fill=tk.X, pady=(0, 10))
        
        # כפתורי עורך
        ttk.Button(editor_toolbar, text="שמור", 
                  command=self.save_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(editor_toolbar, text="פתח", 
                  command=self.open_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(editor_toolbar, text="דוגמה", 
                  command=self.load_example).pack(side=tk.LEFT, padx=5)
        
        # חיפוש והחלפה
        ttk.Separator(editor_toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        ttk.Label(editor_toolbar, text="חיפוש:").pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(editor_toolbar, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=5)
        search_entry.bind('<Return>', self.search_in_code)
        
        ttk.Button(editor_toolbar, text="חפש", 
                  command=self.search_in_code).pack(side=tk.LEFT, padx=5)
        
        # עורך הטקסט
        editor_container = ttk.Frame(parent)
        editor_container.pack(fill=tk.BOTH, expand=True)
        
        # יצירת עורך עם מספור שורות
        line_frame = tk.Frame(editor_container, bg='#2d2d2d', width=50)
        line_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.line_numbers = tk.Text(line_frame, width=4, pady=2, takefocus=0, 
                                   border=0, state='disabled', wrap='none',
                                   bg='#2d2d2d', fg='#999999', font=('Consolas', 11))
        self.line_numbers.pack(fill=tk.Y, expand=True)
        
        # עורך הקוד הראשי
        self.code_editor = scrolledtext.ScrolledText(
            editor_container, 
            height=25, 
            font=('Consolas', 11),
            bg='#1e1e1e', 
            fg='#ffffff',
            insertbackground='white',
            selectbackground='#264f78',
            wrap='none',
            undo=True,
            maxundo=50
        )
        self.code_editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # קישור אירועים
        self.code_editor.bind('<KeyRelease>', self.on_text_change)
        self.code_editor.bind('<Button-1>', self.on_text_change)
        self.code_editor.bind('<MouseWheel>', self.on_scroll)
        
        # הגדרת צבעי syntax (בסיסי)
        self._setup_syntax_highlighting()
        
        # טעינת דוגמה ראשונית
        self.load_initial_code()
    
    def _setup_syntax_highlighting(self):
        """הגדרת הדגשת syntax בסיסית"""
        # מילות מפתח Python
        self.code_editor.tag_configure("keyword", foreground="#569cd6")
        self.code_editor.tag_configure("string", foreground="#ce9178")
        self.code_editor.tag_configure("comment", foreground="#6a9955")
        self.code_editor.tag_configure("number", foreground="#b5cea8")
        
        # פונקציה להדגשה (בסיסית)
        self.highlight_syntax()
    
    def highlight_syntax(self):
        """הדגשת syntax בסיסית"""
        if not self.settings['syntax_highlighting']:
            return
        
        content = self.code_editor.get("1.0", tk.END)
        
        # ניקוי הדגשות קודמות
        for tag in ["keyword", "string", "comment", "number"]:
            self.code_editor.tag_delete(tag)
        
        # הדגשת מילות מפתח Python
        keywords = ["def", "class", "if", "else", "elif", "for", "while", 
                   "try", "except", "import", "from", "return", "print"]
        
        lines = content.split('\n')
        for i, line in enumerate(lines):
            for keyword in keywords:
                start = 0
                while True:
                    pos = line.find(keyword, start)
                    if pos == -1:
                        break
                    if (pos == 0 or not line[pos-1].isalnum()) and \
                       (pos + len(keyword) >= len(line) or not line[pos + len(keyword)].isalnum()):
                        start_idx = f"{i+1}.{pos}"
                        end_idx = f"{i+1}.{pos + len(keyword)}"
                        self.code_editor.tag_add("keyword", start_idx, end_idx)
                    start = pos + 1
    
    def _create_output_area(self, parent):
        """יצירת אזור הפלט"""
        # נוטבוק לטאבים
        output_notebook = ttk.Notebook(parent)
        output_notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב פלט רגיל
        output_frame = ttk.Frame(output_notebook)
        output_notebook.add(output_frame, text="פלט")
        
        # כלי בקרה לפלט
        output_toolbar = ttk.Frame(output_frame)
        output_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(output_toolbar, text="נקה", 
                  command=self.clear_output).pack(side=tk.LEFT, padx=5)
        ttk.Button(output_toolbar, text="שמור פלט", 
                  command=self.save_output).pack(side=tk.LEFT, padx=5)
        ttk.Button(output_toolbar, text="העתק הכל", 
                  command=self.copy_all_output).pack(side=tk.LEFT, padx=5)
        
        # אזור הפלט
        self.output_text = scrolledtext.ScrolledText(
            output_frame, 
            height=15, 
            font=('Consolas', 10),
            bg='#0c0c0c', 
            fg='#00ff00',
            state='disabled'
        )
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # טאב שגיאות
        error_frame = ttk.Frame(output_notebook)
        output_notebook.add(error_frame, text="שגיאות")
        
        self.error_text = scrolledtext.ScrolledText(
            error_frame, 
            height=15, 
            font=('Consolas', 10),
            bg='#2d1b1b', 
            fg='#ff6b6b',
            state='disabled'
        )
        self.error_text.pack(fill=tk.BOTH, expand=True)
        
        # טאב היסטוריה
        history_frame = ttk.Frame(output_notebook)
        output_notebook.add(history_frame, text="היסטוריה")
        
        # טבלת היסטוריה
        columns = ('time', 'language', 'duration', 'status', 'lines')
        self.execution_tree = ttk.Treeview(history_frame, columns=columns, show='headings', height=12)
        
        headers = {
            'time': 'זמן',
            'language': 'שפה',
            'duration': 'משך (שניות)',
            'status': 'סטטוס',
            'lines': 'שורות קוד'
        }
        
        for col, header in headers.items():
            self.execution_tree.heading(col, text=header)
            self.execution_tree.column(col, width=100)
        
        # סקרול להיסטוריה
        history_scroll = ttk.Scrollbar(history_frame, orient=tk.VERTICAL, 
                                      command=self.execution_tree.yview)
        self.execution_tree.configure(yscrollcommand=history_scroll.set)
        
        self.execution_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        history_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # אירועים
        self.execution_tree.bind('<Double-1>', self.on_history_double_click)
    
    def _create_monitor_area(self, parent):
        """יצירת אזור הניטור"""
        # נוטבוק לטאבי ניטור
        monitor_notebook = ttk.Notebook(parent)
        monitor_notebook.pack(fill=tk.BOTH, expand=True)
        
        # טאב ניטור משאבים
        resources_frame = ttk.Frame(monitor_notebook)
        monitor_notebook.add(resources_frame, text="משאבים")
        
        self._create_resource_monitor(resources_frame)
        
        # טאב תהליכים
        processes_frame = ttk.Frame(monitor_notebook)
        monitor_notebook.add(processes_frame, text="תהליכים")
        
        self._create_process_monitor(processes_frame)
        
        # טאב לוגים
        logs_frame = ttk.Frame(monitor_notebook)
        monitor_notebook.add(logs_frame, text="לוגים")
        
        self._create_log_monitor(logs_frame)
    
    def _create_resource_monitor(self, parent):
        """יצירת ניטור משאבים"""
        # גרף משאבים
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 6))
        fig.patch.set_facecolor('#2b2b2b')
        
        # גרף CPU
        ax1.set_title('שימוש CPU', color='white')
        ax1.set_facecolor('#3b3b3b')
        ax1.tick_params(colors='white')
        ax1.set_ylim(0, 100)
        
        # גרף זיכרון
        ax2.set_title('שימוש זיכרון', color='white')
        ax2.set_facecolor('#3b3b3b')
        ax2.tick_params(colors='white')
        ax2.set_ylim(0, 100)
        
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.resource_monitor = (fig, ax1, ax2, canvas)
        
        # נתונים לגרף
        self.cpu_data = []
        self.memory_data = []
        self.time_data = []
    
    def _create_process_monitor(self, parent):
        """יצירת ניטור תהליכים"""
        # כלי בקרה
        process_toolbar = ttk.Frame(parent)
        process_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(process_toolbar, text="רענן", 
                  command=self.refresh_processes).pack(side=tk.LEFT, padx=5)
        ttk.Button(process_toolbar, text="עצור תהליך", 
                  command=self.terminate_process).pack(side=tk.LEFT, padx=5)
        
        # טבלת תהליכים
        process_columns = ('pid', 'name', 'cpu', 'memory', 'status')
        self.process_tree = ttk.Treeview(parent, columns=process_columns, show='headings')
        
        process_headers = {
            'pid': 'PID',
            'name': 'שם תהליך',
            'cpu': 'CPU %',
            'memory': 'זיכרון %',
            'status': 'סטטוס'
        }
        
        for col, header in process_headers.items():
            self.process_tree.heading(col, text=header)
            self.process_tree.column(col, width=100)
        
        process_scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, 
                                      command=self.process_tree.yview)
        self.process_tree.configure(yscrollcommand=process_scroll.set)
        
        self.process_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        process_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    def _create_log_monitor(self, parent):
        """יצירת ניטור לוגים"""
        # כלי בקרה ללוגים
        log_toolbar = ttk.Frame(parent)
        log_toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(log_toolbar, text="נקה לוגים", 
                  command=self.clear_logs).pack(side=tk.LEFT, padx=5)
        ttk.Button(log_toolbar, text="שמור לוגים", 
                  command=self.save_logs).pack(side=tk.LEFT, padx=5)
        
        # רמת לוג
        ttk.Label(log_toolbar, text="רמה:").pack(side=tk.LEFT, padx=(20, 5))
        self.log_level_var = tk.StringVar(value="INFO")
        log_combo = ttk.Combobox(log_toolbar, textvariable=self.log_level_var,
                                values=["DEBUG", "INFO", "WARNING", "ERROR"],
                                state="readonly", width=10)
        log_combo.pack(side=tk.LEFT, padx=5)
        
        # אזור הלוגים
        self.log_text = scrolledtext.ScrolledText(
            parent,
            height=12,
            font=('Consolas', 9),
            bg='#1a1a1a',
            fg='#cccccc'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
    
    def _create_status_bar(self, parent):
        """יצירת סרגל סטטוס"""
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        # סטטוס שמאל
        self.status_left = ttk.Label(status_frame, text="מוכן")
        self.status_left.pack(side=tk.LEFT)
        
        # סטטוס ימין
        self.status_right = ttk.Label(status_frame, text="Python | UTF-8 | שורה 1, עמודה 1")
        self.status_right.pack(side=tk.RIGHT)
        
        # פס התקדמות
        self.progress_bar = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress_bar.pack(side=tk.RIGHT, padx=(0, 20), fill=tk.X, expand=False)
    
    # ========== פונקציות עיבוד קוד ==========
    
    def execute_code(self):
        """ביצוע הקוד"""
        code = self.code_editor.get("1.0", tk.END).strip()
        if not code:
            self.show_message("אין קוד לביצוע", "warning")
            return
        
        language = self.language_var.get()
        security_level = self.security_var.get()
        
        # התחלת ביצוע באסינכרוני
        threading.Thread(target=self._execute_async, 
                        args=(code, language, security_level),
                        daemon=True).start()
    
    def _execute_async(self, code, language, security_level):
        """ביצוע אסינכרוני של קוד"""
        start_time = datetime.now()
        
        try:
            # עדכון UI
            self.root.after(0, lambda: self._update_execution_start())
            
            # הכנת סביבת ביצוע
            execution_data = {
                'code': code,
                'language': language,
                'security_level': security_level,
                'max_execution_time': self.settings['max_execution_time'],
                'max_memory_mb': self.settings['max_memory_mb']
            }
            
            # ביצוע הקוד
            if self.execution_engine:
                result = asyncio.run(self.execution_engine.execute_code(execution_data))
            else:
                result = self._simulate_execution(code, language)
            
            # חישוב זמן ביצוע
            duration = (datetime.now() - start_time).total_seconds()
            
            # עדכון תוצאות
            self.root.after(0, lambda: self._update_execution_result(result, duration))
            
            # הוספה להיסטוריה
            self._add_to_history(code, language, result, duration)
            
        except Exception as e:
            error_msg = f"שגיאה בביצוע: {str(e)}"
            self.root.after(0, lambda: self._update_execution_error(error_msg))
        
        finally:
            self.root.after(0, lambda: self._update_execution_end())
    
    def _simulate_execution(self, code, language):
        """סימולציה של ביצוע קוד (לדמו)"""
        import time
        time.sleep(1)  # סימולציה של זמן ביצוע
        
        return {
            'success': True,
            'output': f"קוד {language} בוצע בהצלחה!\nפלט: תוצאה לדוגמה",
            'error': None,
            'execution_time': 1.0,
            'memory_used': 256
        }
    
    def _update_execution_start(self):
        """עדכון תחילת ביצוע"""
        self.progress_bar.start()
        self.status_left.config(text="מבצע קוד...")
        self.status_indicator.config(fg="orange")
    
    def _update_execution_result(self, result, duration):
        """עדכון תוצאות ביצוע"""
        if result['success']:
            self._append_output(result['output'], "success")
            self.status_left.config(text=f"הושלם בהצלחה ({duration:.2f}s)")
            self.status_indicator.config(fg="green")
        else:
            self._append_error(result['error'])
            self.status_left.config(text=f"נכשל ({duration:.2f}s)")
            self.status_indicator.config(fg="red")
    
    def _update_execution_error(self, error_msg):
        """עדכון שגיאת ביצוע"""
        self._append_error(error_msg)
        self.status_left.config(text="שגיאה בביצוע")
        self.status_indicator.config(fg="red")
    
    def _update_execution_end(self):
        """עדכון סיום ביצוע"""
        self.progress_bar.stop()
    
    def _append_output(self, text, message_type="normal"):
        """הוספת טקסט לפלט"""
        self.output_text.config(state='normal')
        
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        if message_type == "success":
            self.output_text.insert(tk.END, f"[{timestamp}] ✓ {text}\n", "success")
        elif message_type == "warning":
            self.output_text.insert(tk.END, f"[{timestamp}] ⚠ {text}\n", "warning")
        else:
            self.output_text.insert(tk.END, f"[{timestamp}] {text}\n")
        
        self.output_text.see(tk.END)
        self.output_text.config(state='disabled')
    
    def _append_error(self, error_text):
        """הוספת שגיאה"""
        self.error_text.config(state='normal')
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.error_text.insert(tk.END, f"[{timestamp}] ❌ {error_text}\n")
        self.error_text.see(tk.END)
        self.error_text.config(state='disabled')
    
    def _add_to_history(self, code, language, result, duration):
        """הוספה להיסטוריית ביצוע"""
        history_entry = {
            'timestamp': datetime.now(),
            'language': language,
            'code': code,
            'result': result,
            'duration': duration,
            'line_count': len(code.split('\n'))
        }
        
        self.execution_history.append(history_entry)
        
        # עדכון טבלת היסטוריה
        self.root.after(0, lambda: self._update_history_table(history_entry))
    
    def _update_history_table(self, entry):
        """עדכון טבלת היסטוריה"""
        status = "✓ הצלחה" if entry['result']['success'] else "❌ כשל"
        
        self.execution_tree.insert('', 0, values=(
            entry['timestamp'].strftime("%H:%M:%S"),
            entry['language'],
            f"{entry['duration']:.2f}",
            status,
            entry['line_count']
        ))
    
    # ========== פונקציות UI ==========
    
    def stop_execution(self):
        """עצירת ביצוע קוד"""
        # יישום עצירת תהליכים פעילים
        self.show_message("ביצוע נעצר", "warning")
        self.status_left.config(text="נעצר על ידי המשתמש")
        self.progress_bar.stop()
    
    def clear_output(self):
        """ניקוי אזור הפלט"""
        self.output_text.config(state='normal')
        self.output_text.delete("1.0", tk.END)
        self.output_text.config(state='disabled')
        
        self.error_text.config(state='normal')
        self.error_text.delete("1.0", tk.END)
        self.error_text.config(state='disabled')
    
    def on_text_change(self, event=None):
        """טיפול בשינוי טקסט"""
        # עדכון מספור שורות
        self._update_line_numbers()
        
        # עדכון סרגל סטטוס
        cursor_pos = self.code_editor.index(tk.INSERT)
        line, col = cursor_pos.split('.')
        language = self.language_var.get().title()
        self.status_right.config(text=f"{language} | UTF-8 | שורה {line}, עמודה {col}")
        
        # הדגשת syntax
        if self.settings['syntax_highlighting']:
            self.root.after_idle(self.highlight_syntax)
    
    def _update_line_numbers(self):
        """עדכון מספור שורות"""
        self.line_numbers.config(state='normal')
        self.line_numbers.delete("1.0", tk.END)
        
        lines = self.code_editor.get("1.0", tk.END).count('\n')
        line_numbers = '\n'.join(str(i) for i in range(1, lines + 1))
        
        self.line_numbers.insert("1.0", line_numbers)
        self.line_numbers.config(state='disabled')
    
    def on_scroll(self, event):
        """סנכרון גלילה בין עורך למספור"""
        self.line_numbers.yview_scroll(int(-1 * (event.delta / 120)), "units")
    
    def search_in_code(self, event=None):
        """חיפוש בקוד"""
        search_term = self.search_var.get()
        if not search_term:
            return
        
        # הסרת הדגשות קודמות
        self.code_editor.tag_remove("search", "1.0", tk.END)
        
        # חיפוש והדגשה
        start = "1.0"
        count = 0
        while True:
            pos = self.code_editor.search(search_term, start, tk.END)
            if not pos:
                break
            
            end = f"{pos}+{len(search_term)}c"
            self.code_editor.tag_add("search", pos, end)
            start = end
            count += 1
        
        # הגדרת צבע הדגשה
        self.code_editor.tag_config("search", background="yellow", foreground="black")
        
        if count > 0:
            self.show_message(f"נמצאו {count} התאמות", "info")
            # מעבר לתוצאה הראשונה
            first_pos = self.code_editor.search(search_term, "1.0", tk.END)
            if first_pos:
                self.code_editor.see(first_pos)
                self.code_editor.mark_set(tk.INSERT, first_pos)
        else:
            self.show_message("לא נמצאו התאמות", "warning")
    
    # ========== פונקציות קבצים ==========
    
    def new_file(self):
        """קובץ חדש"""
        if messagebox.askyesno("קובץ חדש", "האם לשמור את הקובץ הנוכחי?"):
            self.save_file()
        
        self.code_editor.delete("1.0", tk.END)
        self.clear_output()
        self.status_left.config(text="קובץ חדש נוצר")
    
    def open_file(self):
        """פתיחת קובץ"""
        filename = filedialog.askopenfilename(
            title="פתח קובץ קוד",
            filetypes=[
                ("Python files", "*.py"),
                ("JavaScript files", "*.js"),
                ("Bash scripts", "*.sh"),
                ("SQL files", "*.sql"),
                ("All files", "*.*")
            ]
        )
        
        if filename:
            try:
                with open(filename, 'r', encoding='utf-8') as file:
                    content = file.read()
                
                self.code_editor.delete("1.0", tk.END)
                self.code_editor.insert("1.0", content)
                
                # זיהוי שפה לפי סיומת
                ext = Path(filename).suffix.lower()
                language_map = {
                    '.py': 'python',
                    '.js': 'javascript',
                    '.sh': 'bash',
                    '.sql': 'sql',
                    '.r': 'r',
                    '.java': 'java'
                }
                
                if ext in language_map:
                    self.language_var.set(language_map[ext])
                
                self.status_left.config(text=f"נפתח: {Path(filename).name}")
                
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לפתוח את הקובץ:\n{str(e)}")
    
    def save_file(self):
        """שמירת קובץ"""
        filename = filedialog.asksaveasfilename(
            title="שמור קובץ",
            defaultextension=".py",
            filetypes=[
                ("Python files", "*.py"),
                ("JavaScript files", "*.js"),
                ("Bash scripts", "*.sh"),
                ("SQL files", "*.sql"),
                ("Text files", "*.txt"),
                ("All files", "*.*")
            ]
        )
        
        if filename:
            try:
                content = self.code_editor.get("1.0", tk.END)
                with open(filename, 'w', encoding='utf-8') as file:
                    file.write(content)
                
                self.status_left.config(text=f"נשמר: {Path(filename).name}")
                
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לשמור את הקובץ:\n{str(e)}")
    
    def save_as_file(self):
        """שמירה בשם חדש"""
        self.save_file()
    
    def load_example(self):
        """טעינת דוגמת קוד"""
        language = self.language_var.get()
        examples = {
            'python': '''# דוגמה בפייתון
import datetime
import math

def fibonacci(n):
    """חישוב מספר פיבונאצ'י"""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# הדפסת 10 מספרים ראשונים
print("10 מספרי פיבונאצ'י ראשונים:")
for i in range(10):
    print(f"F({i}) = {fibonacci(i)}")

# מידע על זמן נוכחי
now = datetime.datetime.now()
print(f"\\nזמן נוכחי: {now.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"שורש של 16: {math.sqrt(16)}")''',
            
            'javascript': '''// דוגמה ב-JavaScript
function factorial(n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

// חישוב עצרת
console.log("עצרות:");
for (let i = 1; i <= 5; i++) {
    console.log(`${i}! = ${factorial(i)}`);
}

// עבודה עם מערכים
const numbers = [1, 2, 3, 4, 5];
const squares = numbers.map(x => x * x);
console.log("\\nמספרים:", numbers);
console.log("ריבועים:", squares);

// תאריך נוכחי
const now = new Date();
console.log(`\\nתאריך נוכחי: ${now.toLocaleString('he-IL')}`);''',
            
            'bash': '''#!/bin/bash
# דוגמה ב-Bash

echo "מידע מערכת:"
echo "============"

# מידע בסיסי
echo "שם מחשב: $(hostname)"
echo "משתמש נוכחי: $(whoami)"
echo "תאריך: $(date)"
echo "ספרייה נוכחית: $(pwd)"

# סטטיסטיקות מערכת
echo "\\nסטטיסטיקות מערכת:"
echo "CPU: $(nproc) ליבות"
echo "זיכרון: $(free -h | grep Mem | awk '{print $2}')"
echo "דיסק: $(df -h / | tail -1 | awk '{print $4}') פנוי"

# רשימת קבצים
echo "\\n5 קבצים אחרונים בספרייה:"
ls -lt | head -6''',
            
            'sql': '''-- דוגמה ב-SQL
-- יצירת טבלה לדוגמה
CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    department TEXT,
    salary REAL,
    hire_date DATE
);

-- הכנסת נתונים לדוגמה
INSERT INTO employees (name, department, salary, hire_date) VALUES
('אחמד כהן', 'IT', 12000, '2023-01-15'),
('שרה לוי', 'HR', 9500, '2023-02-20'),
('דוד ישראלי', 'Finance', 11000, '2023-03-10');

-- שאילתות
SELECT 'עובדים לפי מחלקה:' as info;
SELECT department, COUNT(*) as employee_count, AVG(salary) as avg_salary
FROM employees 
GROUP BY department;

SELECT '\\nעובדים עם שכר גבוה מ-10000:' as info;
SELECT name, department, salary 
FROM employees 
WHERE salary > 10000
ORDER BY salary DESC;'''
        }
        
        if language in examples:
            self.code_editor.delete("1.0", tk.END)
            self.code_editor.insert("1.0", examples[language])
            self.status_left.config(text=f"נטענה דוגמה ב-{language}")
    
    def load_initial_code(self):
        """טעינת קוד ראשוני"""
        initial_code = '''# ברוכים הבאים למערכת השליטה הדיגיטלית
# זהו עורך קוד מתקדם עם יכולות ביצוע ובקרה

print("שלום עולם!")
print("המערכת מוכנה לשימוש")

# דוגמה פשוטה
def greet(name):
    return f"שלום {name}!"

name = "Effi AI"
message = greet(name)
print(message)'''
        
        self.code_editor.insert("1.0", initial_code)
    
    # ========== פונקציות ניטור ==========
    
    def start_monitoring(self):
        """התחלת ניטור מערכת"""
        self.running = True
        threading.Thread(target=self._monitoring_loop, daemon=True).start()
    
    def _monitoring_loop(self):
        """לולאת ניטור רציפה"""
        while self.running:
            try:
                # עדכון נתוני משאבים
                cpu_percent = psutil.cpu_percent(interval=1)
                memory_percent = psutil.virtual_memory().percent
                
                self.cpu_data.append(cpu_percent)
                self.memory_data.append(memory_percent)
                self.time_data.append(len(self.cpu_data))
                
                # שמירה של 100 נקודות אחרונות
                if len(self.cpu_data) > 100:
                    self.cpu_data.pop(0)
                    self.memory_data.pop(0)
                    self.time_data.pop(0)
                
                # עדכון גרפים
                self.root.after(0, self._update_resource_graphs)
                
            except Exception as e:
                self.log_message(f"שגיאה בניטור: {e}", "ERROR")
            
            threading.Event().wait(2)
    
    def _update_resource_graphs(self):
        """עדכון גרפי משאבים"""
        if not self.resource_monitor:
            return
        
        fig, ax1, ax2, canvas = self.resource_monitor
        
        # עדכון גרף CPU
        ax1.clear()
        ax1.plot(self.time_data, self.cpu_data, color='#4CAF50', linewidth=2)
        ax1.set_title('שימוש CPU', color='white')
        ax1.set_ylim(0, 100)
        ax1.set_facecolor('#3b3b3b')
        ax1.tick_params(colors='white')
        
        # עדכון גרף זיכרון
        ax2.clear()
        ax2.plot(self.time_data, self.memory_data, color='#FF9800', linewidth=2)
        ax2.set_title('שימוש זיכרון', color='white')
        ax2.set_ylim(0, 100)
        ax2.set_facecolor('#3b3b3b')
        ax2.tick_params(colors='white')
        
        canvas.draw()
    
    def refresh_processes(self):
        """רענון רשימת התהליכים"""
        # ניקוי הטבלה
        for item in self.process_tree.get_children():
            self.process_tree.delete(item)
        
        # הוספת תהליכים נוכחיים
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                try:
                    pinfo = proc.info
                    self.process_tree.insert('', 'end', values=(
                        pinfo['pid'],
                        pinfo['name'][:20],  # קיצור שם
                        f"{pinfo['cpu_percent']:.1f}%",
                        f"{pinfo['memory_percent']:.1f}%",
                        pinfo['status']
                    ))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            self.log_message(f"שגיאה ברענון תהליכים: {e}", "ERROR")
    
    def terminate_process(self):
        """עצירת תהליך נבחר"""
        selection = self.process_tree.selection()
        if not selection:
            messagebox.showwarning("אזהרה", "נא לבחור תהליך")
            return
        
        pid = self.process_tree.item(selection[0])['values'][0]
        
        if messagebox.askyesno("אישור", f"האם לעצור תהליך {pid}?"):
            try:
                process = psutil.Process(pid)
                process.terminate()
                self.log_message(f"תהליך {pid} נעצר", "INFO")
                self.refresh_processes()
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לעצור תהליך:\n{str(e)}")
    
    def log_message(self, message, level="INFO"):
        """הוספת הודעה ללוג"""
        if self.log_text:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = f"[{timestamp}] {level}: {message}\n"
            
            self.log_text.insert(tk.END, log_entry)
            self.log_text.see(tk.END)
    
    def show_message(self, message, msg_type="info"):
        """הצגת הודעה"""
        self._append_output(message, msg_type)
    
    # ========== פונקציות נוספות ==========
    
    def safe_execute(self):
        """ביצוע בטוח בסביבה מבודדת"""
        self.security_var.set("sandbox")
        self.execute_code()
    
    def copy_all_output(self):
        """העתקת כל הפלט"""
        output = self.output_text.get("1.0", tk.END)
        self.root.clipboard_clear()
        self.root.clipboard_append(output)
        self.show_message("פלט הועתק ללוח", "info")
    
    def save_output(self):
        """שמירת הפלט לקובץ"""
        filename = filedialog.asksaveasfilename(
            title="שמור פלט",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                output = self.output_text.get("1.0", tk.END)
                with open(filename, 'w', encoding='utf-8') as file:
                    file.write(output)
                self.show_message(f"פלט נשמר ל: {filename}", "info")
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לשמור:\n{str(e)}")
    
    def on_history_double_click(self, event):
        """טיפול בקליק כפול על היסטוריה"""
        selection = self.execution_tree.selection()
        if selection:
            # טעינת קוד מההיסטוריה
            item_index = self.execution_tree.index(selection[0])
            if item_index < len(self.execution_history):
                history_entry = self.execution_history[-(item_index + 1)]  # הפוך כי הכנסנו בהיפוך
                self.code_editor.delete("1.0", tk.END)
                self.code_editor.insert("1.0", history_entry['code'])
                self.language_var.set(history_entry['language'])
    
    def clear_logs(self):
        """ניקוי הלוגים"""
        self.log_text.delete("1.0", tk.END)
    
    def save_logs(self):
        """שמירת הלוגים"""
        filename = filedialog.asksaveasfilename(
            title="שמור לוגים",
            defaultextension=".log",
            filetypes=[("Log files", "*.log"), ("Text files", "*.txt")]
        )
        
        if filename:
            try:
                logs = self.log_text.get("1.0", tk.END)
                with open(filename, 'w', encoding='utf-8') as file:
                    file.write(logs)
                self.show_message(f"לוגים נשמרו ל: {filename}", "info")
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לשמור:\n{str(e)}")
    
    def show_help(self):
        """הצגת עזרה"""
        help_text = """
מערכת שליטה דיגיטלית - מדריך שימוש

קיצורי מקלדת:
- F5: הרצת קוד
- Ctrl+N: קובץ חדש  
- Ctrl+O: פתיחת קובץ
- Ctrl+S: שמירת קובץ
- Ctrl+C: עצירת ביצוע

שפות נתמכות:
- Python, JavaScript, Bash, SQL, R, Java

מצבי אבטחה:
- Low: ביצוע חופשי (זהירות!)
- Medium: הגבלות בסיסיות
- High: הגבלות מחמירות
- Sandbox: ביצוע מבודד

לעזרה נוספת פנה למפתח המערכת.
        """
        
        messagebox.showinfo("עזרה", help_text)
    
    def show_examples(self):
        """הצגת דוגמאות קוד"""
        examples_window = tk.Toplevel(self.root)
        examples_window.title("דוגמאות קוד")
        examples_window.geometry("600x400")
        
        # רשימת דוגמאות
        examples_list = tk.Listbox(examples_window)
        examples_list.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        examples_list.insert(tk.END, "Python - פיבונאצ'י")
        examples_list.insert(tk.END, "JavaScript - עצרת")
        examples_list.insert(tk.END, "Bash - מידע מערכת")
        examples_list.insert(tk.END, "SQL - ניהול עובדים")
        
        def load_selected_example():
            selection = examples_list.curselection()
            if selection:
                language = examples_list.get(selection[0]).split(' - ')[0].lower()
                self.language_var.set(language)
                self.load_example()
                examples_window.destroy()
        
        ttk.Button(examples_window, text="טען דוגמה", 
                  command=load_selected_example).pack(pady=10)
    
    def show_about(self):
        """הצגת מידע על המערכת"""
        about_text = """
מערכת שליטה דיגיטלית מתקדמת
גרסה 1.0

מערכת ביצוע קוד ובקרה דיגיטלית עם:
✓ תמיכה במספר שפות תכנות
✓ ניטור משאבים בזמן אמת
✓ מערכת אבטחה מתקדמת
✓ ממשק משתמש אינטואיטיבי

פותח במסגרת Effi AI Private System
© 2024 Effi AI Systems
        """
        
        messagebox.showinfo("אודות", about_text)
    
    def open_execution_settings(self):
        """פתיחת הגדרות ביצוע"""
        # חלון הגדרות - יישום פשוט
        settings_window = tk.Toplevel(self.root)
        settings_window.title("הגדרות ביצוע")
        settings_window.geometry("400x300")
        
        # הגדרות זמן ביצוע מקסימלי
        ttk.Label(settings_window, text="זמן ביצוע מקסימלי (שניות):").pack(pady=5)
        exec_time_var = tk.StringVar(value=str(self.settings['max_execution_time']))
        ttk.Entry(settings_window, textvariable=exec_time_var, width=10).pack(pady=5)
        
        # הגדרות זיכרון מקסימלי
        ttk.Label(settings_window, text="זיכרון מקסימלי (MB):").pack(pady=5)
        memory_var = tk.StringVar(value=str(self.settings['max_memory_mb']))
        ttk.Entry(settings_window, textvariable=memory_var, width=10).pack(pady=5)
        
        def save_settings():
            try:
                self.settings['max_execution_time'] = int(exec_time_var.get())
                self.settings['max_memory_mb'] = int(memory_var.get())
                messagebox.showinfo("הגדרות", "הגדרות נשמרו בהצלחה")
                settings_window.destroy()
            except ValueError:
                messagebox.showerror("שגיאה", "ערכים לא תקינים")
        
        ttk.Button(settings_window, text="שמור", command=save_settings).pack(pady=20)
    
    def open_security_settings(self):
        """הגדרות אבטחה"""
        messagebox.showinfo("הגדרות אבטחה", "הגדרות אבטחה - בפיתוח")
    
    def open_editor_settings(self):
        """הגדרות עורך"""
        messagebox.showinfo("הגדרות עורך", "הגדרות עורך - בפיתוח")
    
    def open_process_manager(self):
        """מנהל תהליכים"""
        self.refresh_processes()
        messagebox.showinfo("מנהל תהליכים", "רשימת התהליכים רוענה")
    
    def open_resource_monitor(self):
        """ניטור משאבים"""
        messagebox.showinfo("ניטור משאבים", "ניטור משאבים פעיל בלוח הבקרה")
    
    def open_system_terminal(self):
        """מסוף מערכת"""
        messagebox.showinfo("מסוף מערכת", "מסוף מערכת - בפיתוח")
    
    def security_check(self):
        """בדיקת אבטחה"""
        messagebox.showinfo("בדיקת אבטחה", "בדיקת אבטחה הושלמה - המערכת בטוחה")
    
    def system_backup(self):
        """גיבוי מערכת"""
        messagebox.showinfo("גיבוי", "גיבוי מערכת - בפיתוח")
    
    def export_results(self):
        """ייצוא תוצאות"""
        filename = filedialog.asksaveasfilename(
            title="ייצוא תוצאות",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                export_data = {
                    'execution_history': [
                        {
                            'timestamp': entry['timestamp'].isoformat(),
                            'language': entry['language'],
                            'duration': entry['duration'],
                            'success': entry['result']['success'],
                            'line_count': entry['line_count']
                        }
                        for entry in self.execution_history
                    ],
                    'settings': self.settings
                }
                
                with open(filename, 'w', encoding='utf-8') as file:
                    json.dump(export_data, file, ensure_ascii=False, indent=2)
                
                self.show_message(f"תוצאות יוצאו ל: {filename}", "info")
            except Exception as e:
                messagebox.showerror("שגיאה", f"לא ניתן לייצא:\n{str(e)}")
    
    def import_script(self):
        """ייבוא סקריפט"""
        self.open_file()
    
    def shutdown(self):
        """כיבוי המערכת"""
        self.running = False
        if self.root:
            self.root.destroy()

def main():
    """פונקציה ראשית להפעלת הממשק"""
    app = ControlDashboard()
    root = app.create_ui()
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("סגירת המערכת...")
    finally:
        app.shutdown()

if __name__ == "__main__":
    main()