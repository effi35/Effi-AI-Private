"""
מודול מערכת שליטה דיגיטלית - Digital Control System
נקודת כניסה ראשית למערכת ביצוע קוד ושליטה דיגיטלית מתקדמת
"""

import asyncio
import logging
import threading
import subprocess
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple
from pathlib import Path
import psutil
import tempfile
import shutil

# ייבוא רכיבי המערכת
from .models.code_execution import CodeExecution, ExecutionResult, ExecutionEnvironment
from .models.security_config import SecurityConfig
from .models.config import ControlSystemConfig

from .core.execution_engine import ExecutionEngine

from .utils.system_utils import (
    SecurityManager, ProcessManager, SandboxManager, 
    SystemMonitor, CodeExecutor, get_system_capabilities
)

class DigitalControlSystem:
    """
    מערכת שליטה דיגיטלית מתקדמת
    מנהלת ביצוע קוד, שליטה במערכת וניטור ביצועים
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        אתחול מערכת השליטה הדיגיטלית
        
        Args:
            config_path: נתיב לקובץ הגדרות (אופציונלי)
        """
        # טעינת הגדרות
        self.config = ControlSystemConfig()
        if config_path:
            self.config.load_from_file(config_path)
        
        # אתחול רכיבי המערכת
        self._init_components()
        
        # אתחול מנוע הביצוע
        self.execution_engine = ExecutionEngine(
            security_config=self.security_config,
            system_config=self.config
        )
        
        # מצב המערכת
        self.is_running = False
        self.start_time = None
        self.execution_history = []
        self.active_executions = {}
        
        # לוגינג
        self.logger = logging.getLogger(__name__)
        self.logger.info("מערכת שליטה דיגיטלית אותחלה בהצלחה")
    
    def _init_components(self):
        """אתחול רכיבי המערכת"""
        # הגדרות אבטחה
        self.security_config = SecurityConfig()
        
        # מנהל תהליכים
        self.process_manager = ProcessManager()
        
        # מנהל Sandbox
        self.sandbox_manager = SandboxManager()
        
        # ניטור מערכת
        self.system_monitor = SystemMonitor()
        
        # מבצע קוד
        self.code_executor = CodeExecutor()
        
        # בדיקת יכולות מערכת
        self.system_capabilities = get_system_capabilities()
        
        self.logger.info("רכיבי המערכת אותחלו")
    
    def start_system(self) -> bool:
        """
        הפעלת המערכת
        
        Returns:
            bool: True אם ההפעלה הצליחה
        """
        try:
            if self.is_running:
                self.logger.warning("המערכת כבר פועלת")
                return True
            
            # הפעלת ניטור מערכת
            self.system_monitor.start_monitoring()
            
            # הפעלת משימות רקע
            self._start_background_tasks()
            
            self.is_running = True
            self.start_time = datetime.now()
            
            self.logger.info("מערכת השליטה הדיגיטלית הופעלה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת המערכת: {e}")
            return False
    
    def stop_system(self) -> bool:
        """
        עצירת המערכת
        
        Returns:
            bool: True אם העצירה הצליחה
        """
        try:
            if not self.is_running:
                self.logger.warning("המערכת כבר מועצרת")
                return True
            
            # עצירת כל הביצועים הפעילים
            self._stop_all_executions()
            
            # עצירת ניטור מערכת
            self.system_monitor.stop_monitoring()
            
            # ניקוי משאבים
            self._cleanup_resources()
            
            self.is_running = False
            
            self.logger.info("מערכת השליטה הדיגיטלית נעצרה בהצלחה")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת המערכת: {e}")
            return False
    
    def _start_background_tasks(self):
        """הפעלת משימות רקע"""
        # משימת ניקוי תהליכים
        cleanup_thread = threading.Thread(
            target=self._cleanup_process_loop, 
            daemon=True
        )
        cleanup_thread.start()
        
        # משימת ניטור ביצועים
        monitor_thread = threading.Thread(
            target=self._performance_monitor_loop, 
            daemon=True
        )
        monitor_thread.start()
        
        self.logger.info("משימות רקע הופעלו")
    
    def _cleanup_process_loop(self):
        """לולאת ניקוי תהליכים"""
        while self.is_running:
            try:
                # ניקוי תהליכים שהסתיימו
                cleaned = self.process_manager.cleanup_completed_processes()
                if cleaned > 0:
                    self.logger.info(f"נוקו {cleaned} תהליכים")
                
                # השהייה
                threading.Event().wait(60)  # כל דקה
                
            except Exception as e:
                self.logger.error(f"שגיאה בניקוי תהליכים: {e}")
    
    def _performance_monitor_loop(self):
        """לולאת ניטור ביצועים"""
        while self.is_running:
            try:
                # רישום ביצועים
                self.system_monitor.record_operation_time("system_check", 0.1)
                
                # השהייה
                threading.Event().wait(30)  # כל 30 שניות
                
            except Exception as e:
                self.logger.error(f"שגיאה בניטור ביצועים: {e}")
    
    # ========== פעולות ביצוע קוד ==========
    
    async def execute_code(self, code: str, language: str, 
                         security_level: str = "medium",
                         timeout: int = None,
                         max_memory_mb: int = None,
                         working_directory: str = None,
                         environment_vars: Dict[str, str] = None) -> Dict[str, Any]:
        """
        ביצוע קוד עם הגדרות מתקדמות
        
        Args:
            code: הקוד לביצוע
            language: שפת התכנות
            security_level: רמת אבטחה (low/medium/high/sandbox)
            timeout: זמן ביצוע מקסימלי בשניות
            max_memory_mb: זיכרון מקסימלי במגה-בייט
            working_directory: ספריית עבודה
            environment_vars: משתני סביבה
        
        Returns:
            Dict[str, Any]: תוצאות הביצוע
        """
        try:
            # בדיקת קוד קלט
            if not code or not code.strip():
                return {
                    'success': False,
                    'output': '',
                    'error': 'לא סופק קוד לביצוע',
                    'execution_time': 0,
                    'process_id': None
                }
            
            # בדיקת תמיכה בשפה
            if language not in self.system_capabilities:
                return {
                    'success': False,
                    'output': '',
                    'error': f'שפה לא נתמכת: {language}',
                    'execution_time': 0,
                    'process_id': None
                }
            
            if not self.system_capabilities[language]:
                return {
                    'success': False,
                    'output': '',
                    'error': f'שפה לא מותקנת במערכת: {language}',
                    'execution_time': 0,
                    'process_id': None
                }
            
            # הגדרות ברירת מחדל
            timeout = timeout or self.config.get('default_timeout', 30)
            max_memory_mb = max_memory_mb or self.config.get('default_memory_limit', 256)
            
            # בדיקת אבטחה
            security_check = SecurityManager.check_code_safety(code, language, security_level)
            if not security_check['safe']:
                return {
                    'success': False,
                    'output': '',
                    'error': f"קוד חסום מסיבות אבטחה: {'; '.join(security_check['errors'])}",
                    'execution_time': 0,
                    'security_warnings': security_check['warnings']
                }
            
            # יצירת סביבת ביצוע
            execution_env = ExecutionEnvironment(
                language=language,
                security_level=security_level,
                max_execution_time=timeout,
                max_memory_mb=max_memory_mb,
                working_directory=working_directory,
                environment_variables=environment_vars or {}
            )
            
            # יצירת אובייקט ביצוע
            execution = CodeExecution(
                code=code,
                language=language,
                environment=execution_env
            )
            
            # ביצוע הקוד
            if security_level == "sandbox":
                result = await self._execute_in_sandbox(execution)
            else:
                result = await self._execute_directly(execution)
            
            # הוספה להיסטוריה
            self._add_to_history(execution, result)
            
            return result.to_dict()
            
        except Exception as e:
            self.logger.error(f"שגיאה בביצוע קוד: {e}")
            return {
                'success': False,
                'output': '',
                'error': f'שגיאה פנימית: {str(e)}',
                'execution_time': 0
            }
    
    async def _execute_directly(self, execution: CodeExecution) -> ExecutionResult:
        """ביצוע קוד ישיר"""
        start_time = datetime.now()
        
        try:
            # ביצוע בעזרת CodeExecutor
            result = self.code_executor.execute(
                code=execution.code,
                language=execution.language,
                security_level=execution.environment.security_level,
                timeout=execution.environment.max_execution_time,
                working_dir=execution.environment.working_directory
            )
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return ExecutionResult(
                success=result['success'],
                output=result.get('output', ''),
                error=result.get('error', ''),
                execution_time=execution_time,
                memory_used=result.get('memory_used', 0),
                return_code=result.get('return_code', 0),
                security_warnings=result.get('security_warnings', [])
            )
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return ExecutionResult(
                success=False,
                output='',
                error=f'שגיאה בביצוע: {str(e)}',
                execution_time=execution_time,
                memory_used=0,
                return_code=-1
            )
    
    async def _execute_in_sandbox(self, execution: CodeExecution) -> ExecutionResult:
        """ביצוע קוד בסביבת sandbox"""
        start_time = datetime.now()
        
        try:
            # יצירת sandbox
            sandbox_result = self.sandbox_manager.create_sandbox(
                language=execution.language,
                code=execution.code,
                memory_limit=f"{execution.environment.max_memory_mb}m"
            )
            
            if not sandbox_result['success']:
                return ExecutionResult(
                    success=False,
                    output='',
                    error=f"שגיאה ביצירת sandbox: {sandbox_result['error']}",
                    execution_time=0,
                    memory_used=0,
                    return_code=-1
                )
            
            sandbox_id = sandbox_result['sandbox_id']
            
            try:
                # ביצוע בסביבה מבודדת
                result = self.sandbox_manager.execute_in_sandbox(
                    sandbox_id=sandbox_id,
                    language=execution.language,
                    code=execution.code,
                    timeout=execution.environment.max_execution_time
                )
                
                execution_time = (datetime.now() - start_time).total_seconds()
                
                return ExecutionResult(
                    success=result['success'],
                    output=result.get('output', ''),
                    error=result.get('error', ''),
                    execution_time=execution_time,
                    memory_used=0,  # לא זמין מ-sandbox
                    return_code=result.get('exit_code', 0),
                    sandbox_id=sandbox_id
                )
                
            finally:
                # ניקוי sandbox
                self.sandbox_manager.destroy_sandbox(sandbox_id)
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return ExecutionResult(
                success=False,
                output='',
                error=f'שגיאה בביצוע sandbox: {str(e)}',
                execution_time=execution_time,
                memory_used=0,
                return_code=-1
            )
    
    def execute_code_sync(self, **kwargs) -> Dict[str, Any]:
        """ביצוע קוד סינכרוני (wrapper לפונקציה אסינכרונית)"""
        return asyncio.run(self.execute_code(**kwargs))
    
    def stop_execution(self, execution_id: str) -> bool:
        """
        עצירת ביצוע קוד פעיל
        
        Args:
            execution_id: מזהה הביצוע
        
        Returns:
            bool: True אם העצירה הצליחה
        """
        try:
            if execution_id in self.active_executions:
                # עצירת התהליך
                success = self.process_manager.terminate_process(
                    execution_id, reason="user_request"
                )
                
                if success:
                    del self.active_executions[execution_id]
                    self.logger.info(f"ביצוע נעצר: {execution_id}")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת ביצוע: {e}")
            return False
    
    def _stop_all_executions(self):
        """עצירת כל הביצועים הפעילים"""
        try:
            execution_ids = list(self.active_executions.keys())
            
            for execution_id in execution_ids:
                self.stop_execution(execution_id)
            
            self.logger.info(f"נעצרו {len(execution_ids)} ביצועים")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת כל הביצועים: {e}")
    
    def _add_to_history(self, execution: CodeExecution, result: ExecutionResult):
        """הוספה להיסטוריית ביצוע"""
        try:
            history_entry = {
                'timestamp': datetime.now(),
                'language': execution.language,
                'code_length': len(execution.code),
                'success': result.success,
                'execution_time': result.execution_time,
                'memory_used': result.memory_used,
                'security_level': execution.environment.security_level,
                'error': result.error if not result.success else None
            }
            
            self.execution_history.append(history_entry)
            
            # שמירה של 1000 רשומות אחרונות בלבד
            if len(self.execution_history) > 1000:
                self.execution_history = self.execution_history[-1000:]
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספה להיסטוריה: {e}")
    
    # ========== ניהול תהליכים ==========
    
    def get_active_processes(self) -> List[Dict[str, Any]]:
        """קבלת רשימת תהליכים פעילים"""
        try:
            return self.system_monitor.get_process_list()
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת תהליכים: {e}")
            return []
    
    def terminate_process(self, pid: int) -> bool:
        """
        עצירת תהליך לפי PID
        
        Args:
            pid: מזהה התהליך
        
        Returns:
            bool: True אם העצירה הצליחה
        """
        try:
            process = psutil.Process(pid)
            process.terminate()
            
            self.logger.info(f"תהליך נעצר: PID {pid}")
            return True
            
        except psutil.NoSuchProcess:
            self.logger.warning(f"תהליך לא נמצא: PID {pid}")
            return False
        except psutil.AccessDenied:
            self.logger.error(f"אין הרשאה לעצור תהליך: PID {pid}")
            return False
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת תהליך: {e}")
            return False
    
    def get_process_info(self, pid: int) -> Optional[Dict[str, Any]]:
        """קבלת מידע על תהליך"""
        try:
            process = psutil.Process(pid)
            
            return {
                'pid': process.pid,
                'name': process.name(),
                'status': process.status(),
                'cpu_percent': process.cpu_percent(),
                'memory_percent': process.memory_percent(),
                'memory_mb': process.memory_info().rss / (1024 * 1024),
                'create_time': datetime.fromtimestamp(process.create_time()),
                'cmdline': ' '.join(process.cmdline()) if process.cmdline() else ''
            }
            
        except psutil.NoSuchProcess:
            return None
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מידע תהליך: {e}")
            return None
    
    # ========== סטטיסטיקות וניטור ==========
    
    def get_system_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות מערכת"""
        try:
            # סטטיסטיקות בסיסיות
            stats = self.system_monitor.get_current_stats()
            
            # סטטיסטיקות ביצועים
            performance = self.system_monitor.get_performance_summary()
            stats.update(performance)
            
            # סטטיסטיקות מערכת השליטה
            stats.update({
                'system_running': self.is_running,
                'active_executions': len(self.active_executions),
                'total_executions': len(self.execution_history),
                'system_capabilities': self.system_capabilities
            })
            
            # זמן פעילות
            if self.start_time:
                uptime = datetime.now() - self.start_time
                stats['uptime_seconds'] = uptime.total_seconds()
                stats['uptime_hours'] = uptime.total_seconds() / 3600
            
            return stats
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת סטטיסטיקות: {e}")
            return {}
    
    def get_execution_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """קבלת היסטוריית ביצוע"""
        try:
            return self.execution_history[-limit:] if limit else self.execution_history
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת היסטוריה: {e}")
            return []
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """קבלת מדדי ביצועים"""
        try:
            return self.system_monitor.get_performance_summary()
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מדדי ביצועים: {e}")
            return {}
    
    def get_memory_trend(self, hours: int = 24) -> List[Dict[str, Any]]:
        """קבלת מגמת שימוש זיכרון"""
        try:
            return self.system_monitor.get_memory_trend(hours)
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת מגמת זיכרון: {e}")
            return []
    
    # ========== הגדרות ותצורה ==========
    
    def update_config(self, **config_updates):
        """עדכון הגדרות מערכת"""
        try:
            for key, value in config_updates.items():
                self.config.set(key, value)
            
            self.logger.info(f"הגדרות עודכנו: {config_updates}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון הגדרות: {e}")
    
    def get_config(self) -> Dict[str, Any]:
        """קבלת הגדרות נוכחיות"""
        return self.config.to_dict()
    
    def update_security_config(self, **security_updates):
        """עדכון הגדרות אבטחה"""
        try:
            for key, value in security_updates.items():
                self.security_config.set(key, value)
            
            self.logger.info(f"הגדרות אבטחה עודכנו: {security_updates}")
            
        except Exception as e:
            self.logger.error(f"שגיאה בעדכון הגדרות אבטחה: {e}")
    
    def get_security_config(self) -> Dict[str, Any]:
        """קבלת הגדרות אבטחה נוכחיות"""
        return self.security_config.to_dict()
    
    # ========== פעולות מערכת ==========
    
    def check_code_security(self, code: str, language: str, 
                           security_level: str) -> Dict[str, Any]:
        """בדיקת אבטחת קוד"""
        try:
            return SecurityManager.check_code_safety(code, language, security_level)
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת אבטחה: {e}")
            return {
                'safe': False,
                'warnings': [],
                'errors': [f'שגיאה בבדיקה: {str(e)}'],
                'risk_level': 'unknown'
            }
    
    def get_supported_languages(self) -> List[str]:
        """קבלת רשימת שפות נתמכות"""
        return [lang for lang, supported in self.system_capabilities.items() if supported]
    
    def validate_environment(self) -> Dict[str, Any]:
        """אימות סביבת המערכת"""
        try:
            from .utils.system_utils import validate_execution_environment
            return validate_execution_environment()
        except Exception as e:
            self.logger.error(f"שגיאה באימות סביבה: {e}")
            return {'valid': False, 'error': str(e)}
    
    def _cleanup_resources(self):
        """ניקוי משאבים"""
        try:
            # ניקוי קבצים זמניים
            temp_dir = tempfile.gettempdir()
            for item in Path(temp_dir).glob("code_executor_*"):
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)
            
            # ניקוי מנוע קוד
            if hasattr(self.code_executor, 'cleanup'):
                self.code_executor.cleanup()
            
            self.logger.info("משאבים נוקו")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניקוי משאבים: {e}")

# ========== פונקציות עזר למודול ==========

def create_control_system(config_path: str = None) -> DigitalControlSystem:
    """
    יצירת מערכת שליטה דיגיטלית חדשה
    
    Args:
        config_path: נתיב לקובץ הגדרות
    
    Returns:
        DigitalControlSystem: מערכת שליטה מאותחלת
    """
    return DigitalControlSystem(config_path)

def run_control_system(config_path: str = None):
    """
    הפעלת מערכת שליטה דיגיטלית כתהליך עצמאי
    
    Args:
        config_path: נתיב לקובץ הגדרות
    """
    system = create_control_system(config_path)
    
    try:
        # הפעלת המערכת
        success = system.start_system()
        if not success:
            logging.error("כשל בהפעלת מערכת השליטה הדיגיטלית")
            return
        
        logging.info("מערכת שליטה דיגיטלית פועלת - לחץ Ctrl+C לעצירה")
        
        # לולאת פעילות ראשית
        try:
            while True:
                # ממתין לפקודות או מבצע משימות רקע
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            logging.info("התקבל סיגנל עצירה")
    
    finally:
        # עצירת המערכת
        system.stop_system()
        logging.info("מערכת שליטה דיגיטלית נעצרה")

def execute_code_cli():
    """ממשק שורת פקודה לביצוע קוד"""
    import argparse
    
    parser = argparse.ArgumentParser(description='מערכת שליטה דיגיטלית - ביצוע קוד')
    parser.add_argument('--code', '-c', required=True, help='הקוד לביצוע')
    parser.add_argument('--language', '-l', required=True, help='שפת התכנות')
    parser.add_argument('--security', '-s', default='medium', 
                       choices=['low', 'medium', 'high', 'sandbox'],
                       help='רמת אבטחה')
    parser.add_argument('--timeout', '-t', type=int, default=30, help='זמן ביצוע מקסימלי')
    parser.add_argument('--memory', '-m', type=int, default=256, help='זיכרון מקסימלי (MB)')
    parser.add_argument('--file', '-f', help='קובץ קוד לביצוע')
    
    args = parser.parse_args()
    
    # קריאת קוד מקובץ אם צוין
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                code = f.read()
        except Exception as e:
            print(f"שגיאה בקריאת קובץ: {e}")
            return
    else:
        code = args.code
    
    # יצירת מערכת השליטה
    system = create_control_system()
    
    try:
        # הפעלת המערכת
        system.start_system()
        
        # ביצוע הקוד
        result = system.execute_code_sync(
            code=code,
            language=args.language,
            security_level=args.security,
            timeout=args.timeout,
            max_memory_mb=args.memory
        )
        
        # הצגת התוצאות
        print("=" * 50)
        print(f"שפה: {args.language}")
        print(f"אבטחה: {args.security}")
        print(f"הצלחה: {'כן' if result['success'] else 'לא'}")
        print(f"זמן ביצוע: {result['execution_time']:.2f} שניות")
        print("=" * 50)
        
        if result['success']:
            print("פלט:")
            print(result['output'])
        else:
            print("שגיאה:")
            print(result['error'])
        
        if result.get('security_warnings'):
            print("\nאזהרות אבטחה:")
            for warning in result['security_warnings']:
                print(f"- {warning}")
    
    finally:
        # עצירת המערכת
        system.stop_system()

# ========== נקודת כניסה ראשית ==========

if __name__ == "__main__":
    import sys
    
    # הגדרת לוגינג
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('control_system.log', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # בדיקת אופן הפעלה
    if len(sys.argv) > 1 and sys.argv[1] == '--cli':
        # מצב שורת פקודה
        execute_code_cli()
    else:
        # מצב שרת
        config_file = sys.argv[1] if len(sys.argv) > 1 else None
        run_control_system(config_file)