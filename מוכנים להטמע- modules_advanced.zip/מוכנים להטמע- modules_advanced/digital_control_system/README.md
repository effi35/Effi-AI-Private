# מערכת שליטה דיגיטלית - Digital Control System

מערכת שליטה דיגיטלית מתקדמת לביצוע קוד ובקרה מלאה במחשב עם אבטחה מתקדמת וסביבות sandbox.

## 🎯 תכונות עיקריות

### 💻 ביצוע קוד מתקדם
- **ExecutionEngine**: מנוע ביצוע תומך במספר שפות תכנות
- **CodeExecution**: מודל ביצוע עם הגדרות אבטחה ומשאבים
- **ExecutionResult**: תוצאות מפורטות עם מדידת ביצועים
- **ExecutionEnvironment**: סביבות ביצוע מותאמות אישית

### 🔒 אבטחה מתקדמת
- **SecurityManager**: ניתוח אבטחת קוד לפני ביצוע
- **SandboxManager**: הרצה מבודדת עם Docker ו-chroot
- **ProcessManager**: ניהול תהליכים עם מגבלות משאבים
- **רמות אבטחה**: Low, Medium, High, Sandbox

### 🖥️ ממשק משתמש מקצועי
- **ControlDashboard**: לוח בקרה מקיף עם עורך קוד
- **עורך קוד מתקדם**: הדגשת syntax ומספור שורות
- **ניטור זמן אמת**: CPU, זיכרון, תהליכים ורשת
- **לוגים מפורטים**: מעקב אחר כל הפעולות

### ⚙️ כלים מתקדמים
- **SystemUtils**: כלים למערכת ואבטחה
- **SystemMonitor**: ניטור ביצועים מתקדם
- **CodeExecutor**: ביצוע קוד במספר שפות
- **SandboxManager**: ניהול סביבות מבודדות

## 🏗️ ארכיטקטורה

```
digital_control_system/
├── models/                    # מבני נתונים וקונפיגורציה
│   ├── code_execution.py     # מודלי ביצוע קוד
│   ├── execution_result.py   # תוצאות ביצוע
│   ├── execution_environment.py # סביבות ביצוע
│   ├── security_config.py    # הגדרות אבטחה
│   └── config.py             # הגדרות מערכת
├── core/                      # מנועי ליבה
│   └── execution_engine.py   # מנוע ביצוע ראשי
├── ui/                        # ממשק משתמש
│   └── control_dashboard.py  # לוח בקרה ראשי
├── utils/                     # כלים שימושיים
│   └── system_utils.py       # פונקציות מערכת
├── module.py                 # נקודת כניסה למודול
├── requirements.txt          # תלויות
└── README.md                # תיעוד זה
```

## 🚀 התקנה ושימוש

### דרישות מערכת
```bash
pip install psutil docker subprocess32 ast numpy matplotlib tkinter
```

### הפעלה בסיסית
```python
from digital_control_system import DigitalControlSystem

# אתחול המערכת
control_system = DigitalControlSystem()

# ביצוע קוד Python
result = control_system.execute_code(
    code="print('Hello World!')",
    language="python",
    security_level="medium"
)

print(f"פלט: {result['output']}")
print(f"הצלחה: {result['success']}")
```

### הפעלת לוח הבקרה
```python
from digital_control_system.ui.control_dashboard import main

# הפעלת ממשק גרפי
main()
```

## 📊 שפות תכנות נתמכות

### שפות בסיסיות
- **Python**: ביצוע מלא עם ספריות
- **JavaScript**: Node.js ו-browser runtime
- **Bash/Shell**: פקודות מערכת ללינוקס
- **SQL**: SQLite ובסיסי נתונים אחרים

### שפות מתקדמות
- **Java**: קימפול והרצה עם JDK
- **R**: עיבוד סטטיסטי ואנליטיקה
- **C/C++**: קימפול עם GCC
- **Go**: ביצוע מהיר ויעיל

## 🔒 רמות אבטחה

### Low - אבטחה נמוכה
```python
result = control_system.execute_code(
    code="import os; print(os.listdir('/'))",
    language="python",
    security_level="low"  # גישה מלאה למערכת
)
```

### Medium - אבטחה בינונית
```python
result = control_system.execute_code(
    code="print('Hello World!')",
    language="python",
    security_level="medium"  # בדיקות בסיסיות
)
```

### High - אבטחה גבוהה
```python
result = control_system.execute_code(
    code="print('Hello World!')",
    language="python",
    security_level="high"  # הגבלות חמורות
)
```

### Sandbox - ביצוע מבודד
```python
result = control_system.execute_code(
    code="print('Hello World!')",
    language="python",
    security_level="sandbox"  # הרצה בקונטיינר
)
```

## ⚡ דוגמאות שימוש מתקדמות

### ביצוע עם הגבלות משאבים
```python
execution_config = {
    'code': 'for i in range(1000000): print(i)',
    'language': 'python',
    'security_level': 'medium',
    'max_execution_time': 10,  # 10 שניות
    'max_memory_mb': 128,      # 128 MB
    'max_cpu_percent': 50      # 50% CPU
}

result = control_system.execute_code(**execution_config)
```

### ביצוע קוד JavaScript
```javascript
// דוגמה לקוד JavaScript
const numbers = [1, 2, 3, 4, 5];
const sum = numbers.reduce((a, b) => a + b, 0);
console.log('Sum:', sum);

// פונקציה אסינכרונית
async function fetchData() {
    return new Promise(resolve => {
        setTimeout(() => resolve('Data loaded'), 1000);
    });
}

fetchData().then(console.log);
```

### ביצוע סקריפט Bash
```bash
#!/bin/bash
echo "מידע מערכת:"
echo "============"
echo "תאריך: $(date)"
echo "משתמש: $(whoami)"
echo "ספרייה: $(pwd)"
echo "זיכרון פנוי: $(free -h | grep Mem | awk '{print $7}')"
```

### ביצוע שאילתת SQL
```sql
-- יצירת טבלה וניהול נתונים
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (name, email) VALUES 
('אחמד כהן', 'ahmed@example.com'),
('שרה לוי', 'sara@example.com');

SELECT name, email FROM users WHERE name LIKE '%כהן%';
```

## 🛠️ הגדרות מתקדמות

### קובץ config.py
```python
EXECUTION_CONFIG = {
    "default_timeout": 30,           # זמן ביצוע מקסימלי בשניות
    "default_memory_limit": 256,     # זיכרון מקסימלי במגה-בייט
    "max_concurrent_executions": 5,  # ביצועים מקבילים
    "enable_networking": False,      # גישה לרשת
    "allow_file_access": True,       # גישה לקבצים
    "sandbox_enabled": True,         # הפעלת sandbox
    "logging_level": "INFO"          # רמת לוגינג
}
```

### הגדרות אבטחה
```python
SECURITY_CONFIG = {
    "dangerous_functions": [         # פונקציות מסוכנות
        "exec", "eval", "compile",
        "os.system", "subprocess.call"
    ],
    "blocked_imports": [             # יבואים חסומים
        "subprocess", "os", "sys"
    ],
    "max_code_length": 10000,        # אורך קוד מקסימלי
    "scan_for_malware": True,        # סריקת malware
    "whitelist_mode": False          # מצב whitelist
}
```

## 📈 ניטור וביצועים

### ניטור משאבים
```python
# קבלת סטטיסטיקות מערכת
stats = control_system.get_system_stats()

print(f"שימוש CPU: {stats['cpu_percent']}%")
print(f"שימוש זיכרון: {stats['memory_percent']}%")
print(f"תהליכים פעילים: {stats['active_processes']}")
print(f"זמן פעילות: {stats['uptime_hours']} שעות")
```

### ניטור תהליכים
```python
# רשימת תהליכים פעילים
processes = control_system.get_active_processes()

for proc in processes:
    print(f"PID: {proc['pid']}")
    print(f"שם: {proc['name']}")
    print(f"CPU: {proc['cpu_percent']}%")
    print(f"זיכרון: {proc['memory_mb']} MB")
    print("---")
```

### היסטוריית ביצועים
```python
# היסטוריית ביצוע קוד
history = control_system.get_execution_history()

for execution in history[-10:]:  # 10 אחרונים
    print(f"זמן: {execution['timestamp']}")
    print(f"שפה: {execution['language']}")
    print(f"משך: {execution['duration']} שניות")
    print(f"הצלחה: {execution['success']}")
    print("---")
```

## 🔧 פיתוח והרחבה

### הוספת שפת תכנות חדשה
```python
from digital_control_system.core.execution_engine import ExecutionEngine

class CustomLanguageExecutor:
    def execute(self, code, timeout=30):
        # יישום ביצוע לשפה חדשה
        pass

# רישום השפה החדשה
ExecutionEngine.register_language('custom_lang', CustomLanguageExecutor)
```

### יצירת בודק אבטחה מותאם
```python
from digital_control_system.utils.system_utils import SecurityManager

class CustomSecurityChecker:
    def check_code_safety(self, code, language):
        # בדיקת אבטחה מותאמת
        return {'safe': True, 'warnings': [], 'errors': []}

# החלפת בודק האבטחה
SecurityManager.set_custom_checker(CustomSecurityChecker())
```

### הוספת סביבת ביצוע חדשה
```python
class CustomExecutionEnvironment:
    def __init__(self, name, config):
        self.name = name
        self.config = config
    
    def setup(self):
        # הכנת הסביבה
        pass
    
    def execute(self, code):
        # ביצוע בסביבה
        pass
    
    def cleanup(self):
        # ניקוי הסביבה
        pass
```

## 🧪 בדיקות ואבטחה

### הרצת בדיקות
```bash
# בדיקות יחידה
python -m pytest tests/unit/

# בדיקות אינטגרציה
python -m pytest tests/integration/

# בדיקות אבטחה
python tests/security_tests.py

# בדיקות ביצועים
python tests/performance_tests.py
```

### בדיקת אבטחה מותאמת
```python
# בדיקת קוד מסוכן
dangerous_code = "import os; os.system('rm -rf /')"
security_result = control_system.check_code_security(
    code=dangerous_code,
    language="python",
    security_level="high"
)

if not security_result['safe']:
    print("קוד מסוכן זוהה!")
    print("שגיאות:", security_result['errors'])
```

## 🐳 הרצה בקונטיינרים

### Dockerfile
```dockerfile
FROM python:3.9-slim

# התקנת תלויות מערכת
RUN apt-get update && apt-get install -y \
    nodejs npm openjdk-11-jdk r-base gcc

# התקנת Python packages
COPY requirements.txt .
RUN pip install -r requirements.txt

# העתקת קוד
COPY . /app
WORKDIR /app

# הרצת המערכת
CMD ["python", "module.py"]
```

### Docker Compose
```yaml
version: '3.8'
services:
  digital-control:
    build: .
    ports:
      - "8080:8080"
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    environment:
      - SECURITY_LEVEL=high
      - LOG_LEVEL=INFO
    restart: unless-stopped
```

## 🌐 API ושילובים

### REST API
```python
from flask import Flask, request, jsonify

app = Flask(__name__)
control_system = DigitalControlSystem()

@app.route('/execute', methods=['POST'])
def execute_code():
    data = request.json
    result = control_system.execute_code(
        code=data['code'],
        language=data['language'],
        security_level=data.get('security_level', 'medium')
    )
    return jsonify(result)

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify(control_system.get_system_stats())
```

### WebSocket לעדכונים בזמן אמת
```python
import socketio

sio = socketio.Server()

@sio.event
def execute_code(sid, data):
    result = control_system.execute_code(**data)
    sio.emit('execution_result', result, room=sid)

@sio.event
def get_system_stats(sid):
    stats = control_system.get_system_stats()
    sio.emit('system_stats', stats, room=sid)
```

## 📞 תמיכה ועזרה

### פתרון בעיות נפוצות

1. **שגיאת הרשאות**
   ```bash
   chmod +x scripts/setup.sh
   sudo ./scripts/setup.sh
   ```

2. **Docker לא זמין**
   ```bash
   sudo systemctl start docker
   sudo usermod -aG docker $USER
   ```

3. **שפה לא נמצאה**
   ```bash
   # התקנת Node.js
   curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

4. **בעיות זיכרון**
   ```python
   # הגדלת מגבלת זיכרון
   control_system.update_config(max_memory_mb=1024)
   ```

### לוגים ודיבוג
```python
import logging

# הפעלת דיבוג מפורט
logging.basicConfig(level=logging.DEBUG)

# קבלת לוגים מפורטים
logs = control_system.get_debug_logs()
for log_entry in logs:
    print(f"[{log_entry['timestamp']}] {log_entry['message']}")
```

## 🔄 עדכונים ושדרוגים

### מהדורה נוכחית: v1.0.0
- ביצוע קוד בשפות מרובות
- אבטחה מתקדמת
- ממשק משתמש גרפי
- ניטור זמן אמת

### תכונות מתוכננות v1.1.0
- תמיכה בשפות נוספות
- API מתקדם
- ממשק Web
- שילוב עם בינה מלאכותית

---

**מערכת שליטה דיגיטלית** - פותח במסגרת **Effi AI Private System**  
© 2024 Effi AI Systems - כל הזכויות שמורות  

שליטה מלאה ובטוחה במחשב 💻🔒