"""
Code Execution Models - מודלים לביצוע קוד
מערכת מתקדמת לביצוע קוד בשפות שונות עם בטיחות ומעקב
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union, Set, Tuple
from datetime import datetime, timedelta
import json
import uuid
import subprocess
import threading
import queue
import signal
import resource
import tempfile
import os

class ExecutionType(Enum):
    """סוגי ביצוע קוד"""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    BASH = "bash"
    POWERSHELL = "powershell"
    HTML = "html"
    CSS = "css"
    SQL = "sql"
    MARKDOWN = "markdown"
    JSON = "json"
    YAML = "yaml"
    DOCKER = "docker"
    KUBERNETES = "kubernetes"
    TERRAFORM = "terraform"
    ANSIBLE = "ansible"

class ExecutionPriority(Enum):
    """עדיפות ביצוע"""
    CRITICAL = 5    # קריטי - ביצוע מיידי
    HIGH = 4        # גבוה
    NORMAL = 3      # רגיל
    LOW = 2         # נמוך
    BACKGROUND = 1  # רקע

class ExecutionStatus(Enum):
    """סטטוס ביצוע"""
    PENDING = "pending"         # ממתין
    RUNNING = "running"         # רץ
    COMPLETED = "completed"     # הושלם
    FAILED = "failed"           # נכשל
    TIMEOUT = "timeout"         # תם הזמן
    CANCELLED = "cancelled"     # בוטל
    PAUSED = "paused"          # מושהה
    KILLED = "killed"          # נהרג

class ExecutionScope(Enum):
    """היקף ביצוע"""
    SANDBOX = "sandbox"         # ארגז חול מבודד
    CONTAINER = "container"     # קונטיינר
    VIRTUAL_ENV = "virtual_env" # סביבה וירטואלית
    SYSTEM = "system"          # מערכת
    REMOTE = "remote"          # מרוחק
    CLOUD = "cloud"            # ענן

class SecurityLevel(Enum):
    """רמת אבטחה"""
    UNRESTRICTED = 0    # ללא הגבלות
    LOW = 1            # הגבלות נמוכות
    MEDIUM = 2         # הגבלות בינוניות
    HIGH = 3           # הגבלות גבוהות
    MAXIMUM = 4        # הגבלות מקסימליות

@dataclass
class ExecutionLimits:
    """הגבלות ביצוע"""
    max_execution_time: int = 300        # זמן מקסימלי בשניות
    max_memory_mb: int = 512            # זיכרון מקסימלי
    max_cpu_percent: int = 50           # CPU מקסימלי
    max_file_size_mb: int = 100         # גודל קובץ מקסימלי
    max_network_calls: int = 10         # קריאות רשת מקסימליות
    max_subprocess: int = 5             # תת-תהליכים מקסימליים
    allowed_modules: Set[str] = None    # מודולים מותרים
    blocked_modules: Set[str] = None    # מודולים חסומים
    allowed_domains: Set[str] = None    # דומיינים מותרים
    blocked_domains: Set[str] = None    # דומיינים חסומים
    
    def __post_init__(self):
        if self.allowed_modules is None:
            self.allowed_modules = set()
        if self.blocked_modules is None:
            self.blocked_modules = set()
        if self.allowed_domains is None:
            self.allowed_domains = set()
        if self.blocked_domains is None:
            self.blocked_domains = set()

@dataclass
class ExecutionEnvironment:
    """סביבת ביצוע"""
    environment_id: str
    name: str
    hebrew_name: str
    execution_type: ExecutionType
    scope: ExecutionScope
    security_level: SecurityLevel
    limits: ExecutionLimits
    
    # נתיבים וקבצים
    working_directory: str
    python_executable: str = "/usr/bin/python3"
    node_executable: str = "/usr/bin/node"
    shell_executable: str = "/bin/bash"
    
    # משתני סביבה
    environment_variables: Dict[str, str] = None
    
    # הגדרות רשת
    network_enabled: bool = True
    internet_access: bool = False
    
    # הגדרות מסד נתונים
    database_access: bool = False
    allowed_databases: Set[str] = None
    
    # הגדרות קבצים
    file_system_access: bool = True
    allowed_paths: Set[str] = None
    blocked_paths: Set[str] = None
    
    # לוגים וניטור
    enable_logging: bool = True
    log_level: str = "INFO"
    
    def __post_init__(self):
        if self.environment_variables is None:
            self.environment_variables = {}
        if self.allowed_databases is None:
            self.allowed_databases = set()
        if self.allowed_paths is None:
            self.allowed_paths = set()
        if self.blocked_paths is None:
            self.blocked_paths = set()

@dataclass
class CodeExecution:
    """ביצוע קוד"""
    execution_id: str
    code: str
    execution_type: ExecutionType
    environment: ExecutionEnvironment
    priority: ExecutionPriority
    
    # מטא-דטה
    title: str = ""
    description: str = ""
    author: str = ""
    created_at: datetime = None
    
    # קבצים נלווים
    additional_files: Dict[str, str] = None  # filename -> content
    input_data: Any = None
    
    # הגדרות ביצוע
    async_execution: bool = False
    auto_install_deps: bool = False
    save_output: bool = True
    
    # בקרה
    can_be_cancelled: bool = True
    can_be_paused: bool = False
    retry_on_failure: bool = False
    max_retries: int = 3
    
    # אבטחה
    requires_approval: bool = False
    approved_by: str = ""
    approval_timestamp: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.additional_files is None:
            self.additional_files = {}
    
    def validate_code(self) -> List[str]:
        """בדיקת תקינות הקוד"""
        warnings = []
        
        # בדיקות בטיחות בסיסיות
        dangerous_patterns = [
            'rm -rf', 'format c:', 'del /s', '__import__("os").system',
            'eval(', 'exec(', 'subprocess.call', 'os.system',
            'import subprocess', 'from subprocess'
        ]
        
        code_lower = self.code.lower()
        for pattern in dangerous_patterns:
            if pattern.lower() in code_lower:
                warnings.append(f"זוהה דפוס מסוכן: {pattern}")
        
        # בדיקת אורך קוד
        if len(self.code) > 100000:  # 100KB
            warnings.append("הקוד ארוך מדי - יכול להאט את הביצוע")
        
        # בדיקת מורכבות
        lines_count = len(self.code.split('\n'))
        if lines_count > 1000:
            warnings.append("הקוד מורכב מדי - מומלץ לפצל")
        
        return warnings
    
    def estimate_execution_time(self) -> int:
        """הערכת זמן ביצוע בשניות"""
        lines_count = len(self.code.split('\n'))
        
        # הערכה בסיסית לפי סוג קוד
        base_time = {
            ExecutionType.PYTHON: lines_count * 0.1,
            ExecutionType.JAVASCRIPT: lines_count * 0.05,
            ExecutionType.BASH: lines_count * 0.2,
            ExecutionType.HTML: 1,
            ExecutionType.CSS: 1,
            ExecutionType.SQL: lines_count * 0.3
        }.get(self.execution_type, lines_count * 0.1)
        
        # התאמה לפי מורכבות
        if 'for ' in self.code or 'while ' in self.code:
            base_time *= 2
        
        if 'import ' in self.code or 'require(' in self.code:
            base_time += 5
        
        return max(1, int(base_time))

@dataclass
class ExecutionMetrics:
    """מדדי ביצוע"""
    start_time: datetime
    end_time: Optional[datetime] = None
    
    # ביצועים
    execution_duration: float = 0.0     # זמן ביצוע בשניות
    memory_usage_mb: float = 0.0        # שימוש בזיכרון
    cpu_usage_percent: float = 0.0      # שימוש במעבד
    
    # קלט/פלט
    input_size_bytes: int = 0           # גודל קלט
    output_size_bytes: int = 0          # גודל פלט
    files_created: int = 0              # קבצים שנוצרו
    files_modified: int = 0             # קבצים ששונו
    
    # רשת
    network_requests: int = 0           # בקשות רשת
    data_downloaded_mb: float = 0.0     # נתונים שהורדו
    data_uploaded_mb: float = 0.0       # נתונים שהועלו
    
    # שגיאות
    warnings_count: int = 0             # אזהרות
    errors_count: int = 0               # שגיאות
    
    def calculate_duration(self):
        """חישוב זמן ביצוע"""
        if self.end_time and self.start_time:
            self.execution_duration = (self.end_time - self.start_time).total_seconds()

@dataclass
class ExecutionResult:
    """תוצאת ביצוע קוד"""
    execution_id: str
    status: ExecutionStatus
    
    # פלטים
    stdout: str = ""                    # פלט רגיל
    stderr: str = ""                    # פלט שגיאות
    return_code: int = 0                # קוד חזרה
    exception_info: str = ""            # מידע על חריגה
    
    # קבצים שנוצרו
    output_files: Dict[str, str] = None # filename -> content/path
    generated_images: List[str] = None  # נתיבי תמונות
    generated_data: Dict[str, Any] = None # נתונים שנוצרו
    
    # מדדים
    metrics: ExecutionMetrics = None
    
    # לוגים ומעקב
    execution_log: List[str] = None     # לוג מפורט
    debug_info: Dict[str, Any] = None   # מידע דיבוג
    
    # תוצאות עיבוד
    parsed_output: Any = None           # פלט מעובד
    visualization_data: Dict[str, Any] = None # נתוני ויזואליזציה
    
    def __post_init__(self):
        if self.output_files is None:
            self.output_files = {}
        if self.generated_images is None:
            self.generated_images = []
        if self.generated_data is None:
            self.generated_data = {}
        if self.execution_log is None:
            self.execution_log = []
        if self.debug_info is None:
            self.debug_info = {}
        if self.visualization_data is None:
            self.visualization_data = {}
    
    def is_successful(self) -> bool:
        """בדיקת הצלחת הביצוע"""
        return self.status == ExecutionStatus.COMPLETED and self.return_code == 0
    
    def has_output(self) -> bool:
        """בדיקת קיום פלט"""
        return bool(self.stdout or self.output_files or self.generated_data)
    
    def get_summary(self) -> str:
        """קבלת סיכום התוצאה"""
        if self.is_successful():
            duration = self.metrics.execution_duration if self.metrics else 0
            return f"ביצוע הושלם בהצלחה ({duration:.2f} שניות)"
        else:
            return f"ביצוע נכשל: {self.status.value}"
    
    def to_dict(self) -> Dict[str, Any]:
        """המרה למילון"""
        return {
            'execution_id': self.execution_id,
            'status': self.status.value,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'return_code': self.return_code,
            'exception_info': self.exception_info,
            'output_files': self.output_files,
            'generated_images': self.generated_images,
            'generated_data': self.generated_data,
            'execution_log': self.execution_log,
            'debug_info': self.debug_info,
            'is_successful': self.is_successful(),
            'has_output': self.has_output(),
            'summary': self.get_summary()
        }

@dataclass
class ExecutionSession:
    """סשן ביצוע מתמשך"""
    session_id: str
    name: str
    environment: ExecutionEnvironment
    created_at: datetime
    
    # מצב הסשן
    is_active: bool = True
    variables: Dict[str, Any] = None    # משתנים משותפים
    imports: Set[str] = None            # מודולים שנטענו
    
    # היסטוריית ביצועים
    executions: List[str] = None        # execution_ids
    total_executions: int = 0
    successful_executions: int = 0
    
    # משאבים
    working_files: Dict[str, str] = None # קבצי עבודה זמניים
    databases_connected: Set[str] = None # מסדי נתונים מחוברים
    
    def __post_init__(self):
        if self.variables is None:
            self.variables = {}
        if self.imports is None:
            self.imports = set()
        if self.executions is None:
            self.executions = []
        if self.working_files is None:
            self.working_files = {}
        if self.databases_connected is None:
            self.databases_connected = set()
    
    def add_execution(self, execution_id: str, successful: bool):
        """הוספת ביצוע לסשן"""
        self.executions.append(execution_id)
        self.total_executions += 1
        if successful:
            self.successful_executions += 1
    
    def get_success_rate(self) -> float:
        """קבלת אחוז הצלחה"""
        if self.total_executions == 0:
            return 0.0
        return self.successful_executions / self.total_executions
    
    def cleanup(self):
        """ניקוי משאבי סשן"""
        # ניקוי קבצים זמניים
        for file_path in self.working_files.values():
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                pass
        
        self.working_files.clear()
        self.is_active = False

class CodeTemplateLibrary:
    """ספריית תבניות קוד מוכנות"""
    
    @staticmethod
    def get_python_templates() -> Dict[str, str]:
        """תבניות Python"""
        return {
            'hello_world': '''
print("שלום עולם!")
print("Python works!")
            ''',
            
            'data_analysis': '''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# יצירת נתונים לדוגמה
data = pd.DataFrame({
    'x': np.random.randn(100),
    'y': np.random.randn(100)
})

# ניתוח בסיסי
print("סטטיסטיקות בסיסיות:")
print(data.describe())

# ויזואליזציה
plt.figure(figsize=(8, 6))
plt.scatter(data['x'], data['y'])
plt.title('גרף פיזור')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()
            ''',
            
            'web_scraping': '''
import requests
from bs4 import BeautifulSoup

# בדיקת אתר (בטוח)
url = "https://httpbin.org/html"
response = requests.get(url)

if response.status_code == 200:
    soup = BeautifulSoup(response.content, 'html.parser')
    title = soup.find('title')
    print(f"כותרת הדף: {title.text if title else 'לא נמצא'}")
else:
    print(f"שגיאה: {response.status_code}")
            ''',
            
            'file_processing': '''
import os
import json

# יצירת קובץ לדוגמה
data = {
    "name": "דוגמה",
    "numbers": [1, 2, 3, 4, 5],
    "info": {"created": "2024"}
}

# שמירה לקובץ
with open('example.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

# קריאה מהקובץ
with open('example.json', 'r', encoding='utf-8') as f:
    loaded_data = json.load(f)

print("נתונים שנטענו:")
print(json.dumps(loaded_data, ensure_ascii=False, indent=2))

# ניקוי
os.remove('example.json')
print("קובץ נמחק בהצלחה")
            '''
        }
    
    @staticmethod
    def get_javascript_templates() -> Dict[str, str]:
        """תבניות JavaScript"""
        return {
            'hello_world': '''
console.log("שלום עולם!");
console.log("JavaScript works!");
            ''',
            
            'dom_manipulation': '''
// יצירת HTML דינמי
const container = document.createElement('div');
container.innerHTML = `
    <h1>ברוכים הבאים</h1>
    <p>זהו דף שנוצר דינמית</p>
    <button onclick="alert('לחצת על הכפתור!')">לחץ כאן</button>
`;

document.body.appendChild(container);
console.log("HTML נוצר בהצלחה");
            ''',
            
            'data_processing': '''
// עיבוד נתונים ב-JavaScript
const data = [
    {name: "אלי", age: 25, city: "תל אביב"},
    {name: "שרה", age: 30, city: "ירושלים"},
    {name: "דוד", age: 35, city: "חיפה"}
];

// סינון וחישובים
const youngPeople = data.filter(person => person.age < 30);
const averageAge = data.reduce((sum, person) => sum + person.age, 0) / data.length;

console.log("אנשים צעירים:", youngPeople);
console.log("גיל ממוצע:", averageAge);

// יצירת HTML table
const table = data.map(person => 
    `<tr><td>${person.name}</td><td>${person.age}</td><td>${person.city}</td></tr>`
).join('');

console.log("טבלה:", `<table>${table}</table>`);
            '''
        }
    
    @staticmethod
    def get_bash_templates() -> Dict[str, str]:
        """תבניות Bash"""
        return {
            'system_info': '''
#!/bin/bash
echo "מידע מערכת:"
echo "============"
echo "תאריך: $(date)"
echo "משתמש: $(whoami)"
echo "תיקייה נוכחית: $(pwd)"
echo "מקום פנוי בדיסק:"
df -h | head -2
echo "זיכרון:"
free -h
            ''',
            
            'file_operations': '''
#!/bin/bash

# יצירת תיקייה זמנית
TEMP_DIR="/tmp/example_$$"
mkdir -p "$TEMP_DIR"
echo "נוצרה תיקייה: $TEMP_DIR"

# יצירת קבצים
echo "שלום עולם" > "$TEMP_DIR/hello.txt"
echo "זהו קובץ שני" > "$TEMP_DIR/file2.txt"

# רשימת קבצים
echo "קבצים בתיקייה:"
ls -la "$TEMP_DIR"

# ניקוי
rm -rf "$TEMP_DIR"
echo "תיקייה נמחקה: $TEMP_DIR"
            ''',
            
            'log_analysis': '''
#!/bin/bash

# יצירת לוג לדוגמה
LOG_FILE="/tmp/example.log"
cat > "$LOG_FILE" << EOF
2024-01-01 10:00:01 INFO: מערכת התחילה
2024-01-01 10:05:15 ERROR: שגיאה בחיבור
2024-01-01 10:06:22 INFO: חיבור התחדש
2024-01-01 10:10:33 WARNING: זיכרון נמוך
2024-01-01 10:15:44 INFO: גיבוי הושלם
EOF

echo "ניתוח לוג:"
echo "=========="
echo "סך שורות: $(wc -l < "$LOG_FILE")"
echo "שגיאות: $(grep -c ERROR "$LOG_FILE")"
echo "אזהרות: $(grep -c WARNING "$LOG_FILE")"
echo "מידע: $(grep -c INFO "$LOG_FILE")"

echo -e "\nשגיאות מפורטות:"
grep ERROR "$LOG_FILE"

# ניקוי
rm -f "$LOG_FILE"
            '''
        }
    
    @staticmethod
    def get_html_templates() -> Dict[str, str]:
        """תבניות HTML"""
        return {
            'basic_page': '''
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>דף בסיסי</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 40px;
            direction: rtl;
        }
        .container { 
            max-width: 800px; 
            margin: 0 auto; 
        }
        h1 { color: #333; }
        .button { 
            background: #007cba; 
            color: white; 
            padding: 10px 20px; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ברוכים הבאים לאתר שלי</h1>
        <p>זהו דף HTML בסיסי עם תמיכה בעברית.</p>
        <button class="button" onclick="alert('שלום!')">לחץ כאן</button>
    </div>
</body>
</html>
            ''',
            
            'dashboard': '''
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <title>דשבורד</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            direction: rtl;
        }
        .dashboard { 
            padding: 20px; 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 20px; 
        }
        .card { 
            background: rgba(255,255,255,0.9); 
            border-radius: 10px; 
            padding: 20px; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.1); 
        }
        .card h3 { 
            color: #333; 
            margin-bottom: 15px; 
        }
        .stat { 
            font-size: 2em; 
            font-weight: bold; 
            color: #007cba; 
        }
    </style>
</head>
<body>
    <h1 style="text-align: center; color: white; padding: 20px;">דשבורד מערכת</h1>
    <div class="dashboard">
        <div class="card">
            <h3>סטטיסטיקות</h3>
            <div class="stat">1,234</div>
            <p>משתמשים פעילים</p>
        </div>
        <div class="card">
            <h3>ביצועים</h3>
            <div class="stat">95%</div>
            <p>זמינות מערכת</p>
        </div>
        <div class="card">
            <h3>נתונים</h3>
            <div class="stat">567 GB</div>
            <p>נפח מידע</p>
        </div>
    </div>
</body>
</html>
            '''
        }