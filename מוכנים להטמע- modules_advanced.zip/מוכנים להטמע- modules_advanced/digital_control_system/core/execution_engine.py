"""
Execution Engine - מנוע ביצוע קוד מתקדם
מנוע עוצמתי לביצוע קוד בשפות שונות עם מערכת אבטחה מתקדמת
"""

import asyncio
import subprocess
import threading
import queue
import signal
import resource
import tempfile
import os
import sys
import time
import psutil
import docker
import shutil
from typing import Dict, List, Optional, Any, Callable, Union
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import logging
import uuid
import json
import base64
import hashlib

from ..models.code_execution import (
    CodeExecution, ExecutionResult, ExecutionEnvironment, ExecutionSession,
    ExecutionType, ExecutionStatus, ExecutionPriority, ExecutionScope,
    SecurityLevel, ExecutionLimits, ExecutionMetrics, CodeTemplateLibrary
)
from ..models.config import DigitalControlConfig

class ExecutionEngine:
    """מנוע ביצוע קוד מתקדם עם יכולות שליטה מלאות"""
    
    def __init__(self, config: DigitalControlConfig = None):
        self.config = config or DigitalControlConfig()
        self.logger = self._setup_logger()
        
        # מנועי ביצוע לפי שפה
        self.execution_handlers = {
            ExecutionType.PYTHON: self._execute_python,
            ExecutionType.JAVASCRIPT: self._execute_javascript,
            ExecutionType.BASH: self._execute_bash,
            ExecutionType.POWERSHELL: self._execute_powershell,
            ExecutionType.HTML: self._execute_html,
            ExecutionType.SQL: self._execute_sql,
            ExecutionType.DOCKER: self._execute_docker
        }
        
        # ביצועים פעילים
        self.active_executions: Dict[str, Dict[str, Any]] = {}
        self.execution_history: List[ExecutionResult] = []
        
        # סשנים פעילים
        self.active_sessions: Dict[str, ExecutionSession] = {}
        
        # thread pools לביצוע מקבילי
        self.thread_executor = ThreadPoolExecutor(max_workers=4)
        self.process_executor = ProcessPoolExecutor(max_workers=2)
        
        # Docker client (אם זמין)
        self.docker_client = self._init_docker_client()
        
        # מטמון תבניות
        self.code_templates = {
            'python': CodeTemplateLibrary.get_python_templates(),
            'javascript': CodeTemplateLibrary.get_javascript_templates(),
            'bash': CodeTemplateLibrary.get_bash_templates(),
            'html': CodeTemplateLibrary.get_html_templates()
        }
        
        # מעקב משאבים
        self.resource_monitor = ResourceMonitor()
        
        # אירועים וקולבקים
        self.event_handlers: Dict[str, List[Callable]] = {}
        
        self.logger.info("מנוע ביצוע קוד הופעל בהצלחה")
    
    def _setup_logger(self) -> logging.Logger:
        """הגדרת מערכת לוגים"""
        logger = logging.getLogger("ExecutionEngine")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%d/%m/%Y %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _init_docker_client(self):
        """אתחול Docker client"""
        try:
            client = docker.from_env()
            client.ping()
            self.logger.info("Docker זמין ומחובר")
            return client
        except Exception as e:
            self.logger.warning(f"Docker לא זמין: {e}")
            return None
    
    async def execute_code(self, execution: CodeExecution) -> ExecutionResult:
        """ביצוע קוד אסינכרוני"""
        
        execution_id = execution.execution_id
        self.logger.info(f"מתחיל ביצוע קוד: {execution_id} ({execution.execution_type.value})")
        
        # יצירת תוצאה ראשונית
        result = ExecutionResult(
            execution_id=execution_id,
            status=ExecutionStatus.PENDING,
            metrics=ExecutionMetrics(start_time=datetime.now())
        )
        
        try:
            # רישום ביצוע פעיל
            self.active_executions[execution_id] = {
                'execution': execution,
                'result': result,
                'start_time': datetime.now(),
                'process': None
            }
            
            # בדיקת אבטחה
            security_check = self._validate_security(execution)
            if not security_check['valid']:
                result.status = ExecutionStatus.FAILED
                result.stderr = f"בדיקת אבטחה נכשלה: {security_check['reason']}"
                return result
            
            # בדיקת משאבים
            if not self._check_available_resources(execution):
                result.status = ExecutionStatus.FAILED
                result.stderr = "אין מספיק משאבים זמינים לביצוע"
                return result
            
            # עדכון סטטוס
            result.status = ExecutionStatus.RUNNING
            self._trigger_event('execution_started', execution_id)
            
            # ביצוע לפי סוג
            handler = self.execution_handlers.get(execution.execution_type)
            if not handler:
                raise ValueError(f"סוג ביצוע לא נתמך: {execution.execution_type}")
            
            # ביצוע בפועל
            if execution.async_execution:
                result = await self._execute_async(handler, execution, result)
            else:
                result = await asyncio.get_event_loop().run_in_executor(
                    self.thread_executor, handler, execution, result
                )
            
            # עדכון סיום
            result.metrics.end_time = datetime.now()
            result.metrics.calculate_duration()
            
            # עדכון סטטוס סופי
            if result.status == ExecutionStatus.RUNNING:
                result.status = ExecutionStatus.COMPLETED if result.return_code == 0 else ExecutionStatus.FAILED
            
            self._trigger_event('execution_completed', execution_id)
            
        except asyncio.TimeoutError:
            result.status = ExecutionStatus.TIMEOUT
            result.stderr = "הביצוע עבר את הזמן המותר"
            self.logger.warning(f"ביצוע עבר זמן: {execution_id}")
            
        except Exception as e:
            result.status = ExecutionStatus.FAILED
            result.stderr = f"שגיאה בביצוע: {str(e)}"
            result.exception_info = str(e)
            self.logger.error(f"שגיאה בביצוע {execution_id}: {e}")
            
        finally:
            # ניקוי ביצוע פעיל
            self.active_executions.pop(execution_id, None)
            
            # שמירה בהיסטוריה
            self.execution_history.append(result)
            
            # ניקוי משאבים
            self._cleanup_execution_resources(execution_id)
        
        self.logger.info(f"ביצוע הושלם: {execution_id} - {result.status.value}")
        return result
    
    def _execute_python(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע קוד Python"""
        
        # יצירת תיקיית עבודה זמנית
        with tempfile.TemporaryDirectory() as temp_dir:
            
            # יצירת קובץ קוד
            code_file = os.path.join(temp_dir, f"code_{execution.execution_id}.py")
            with open(code_file, 'w', encoding='utf-8') as f:
                f.write(execution.code)
            
            # יצירת קבצים נוספים
            for filename, content in execution.additional_files.items():
                file_path = os.path.join(temp_dir, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            # הכנת סביבת ביצוע
            env = os.environ.copy()
            env.update(execution.environment.environment_variables)
            env['PYTHONPATH'] = temp_dir
            
            # הגבלות משאבים
            limits = execution.environment.limits
            
            try:
                # ביצוע עם הגבלות זמן ומשאבים
                process = subprocess.Popen(
                    [execution.environment.python_executable, code_file],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=temp_dir,
                    env=env,
                    text=True,
                    preexec_fn=self._set_resource_limits(limits)
                )
                
                # מעקב ביצוע
                self.active_executions[execution.execution_id]['process'] = process
                
                # המתנה לסיום עם timeout
                stdout, stderr = process.communicate(timeout=limits.max_execution_time)
                
                result.stdout = stdout
                result.stderr = stderr
                result.return_code = process.returncode
                
                # בדיקת קבצים שנוצרו
                output_files = {}
                for file in os.listdir(temp_dir):
                    if file != os.path.basename(code_file) and file not in execution.additional_files:
                        file_path = os.path.join(temp_dir, file)
                        if os.path.isfile(file_path):
                            try:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    output_files[file] = f.read()
                            except:
                                # קובץ בינארי - קריאה כ-base64
                                with open(file_path, 'rb') as f:
                                    output_files[file] = base64.b64encode(f.read()).decode()
                
                result.output_files = output_files
                
            except subprocess.TimeoutExpired:
                process.kill()
                result.status = ExecutionStatus.TIMEOUT
                result.stderr = "הביצוע עבר את הזמן המותר"
                
            except Exception as e:
                result.status = ExecutionStatus.FAILED
                result.stderr = f"שגיאה בביצוע Python: {str(e)}"
        
        return result
    
    def _execute_javascript(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע קוד JavaScript"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            
            # יצירת קובץ קוד
            code_file = os.path.join(temp_dir, f"code_{execution.execution_id}.js")
            with open(code_file, 'w', encoding='utf-8') as f:
                f.write(execution.code)
            
            # יצירת קבצים נוספים
            for filename, content in execution.additional_files.items():
                file_path = os.path.join(temp_dir, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            # הכנת סביבת ביצוע
            env = os.environ.copy()
            env.update(execution.environment.environment_variables)
            
            limits = execution.environment.limits
            
            try:
                # ביצוע עם Node.js
                process = subprocess.Popen(
                    [execution.environment.node_executable, code_file],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=temp_dir,
                    env=env,
                    text=True,
                    preexec_fn=self._set_resource_limits(limits)
                )
                
                self.active_executions[execution.execution_id]['process'] = process
                
                stdout, stderr = process.communicate(timeout=limits.max_execution_time)
                
                result.stdout = stdout
                result.stderr = stderr
                result.return_code = process.returncode
                
            except subprocess.TimeoutExpired:
                process.kill()
                result.status = ExecutionStatus.TIMEOUT
                result.stderr = "הביצוע עבר את הזמן המותר"
                
            except Exception as e:
                result.status = ExecutionStatus.FAILED
                result.stderr = f"שגיאה בביצוע JavaScript: {str(e)}"
        
        return result
    
    def _execute_bash(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע קוד Bash"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            
            # יצירת קובץ סקריפט
            script_file = os.path.join(temp_dir, f"script_{execution.execution_id}.sh")
            with open(script_file, 'w', encoding='utf-8') as f:
                f.write("#!/bin/bash\n")
                f.write("set -e\n")  # יציאה בשגיאה
                f.write(execution.code)
            
            # הגדרת הרשאות
            os.chmod(script_file, 0o755)
            
            # יצירת קבצים נוספים
            for filename, content in execution.additional_files.items():
                file_path = os.path.join(temp_dir, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            # הכנת סביבת ביצוע
            env = os.environ.copy()
            env.update(execution.environment.environment_variables)
            
            limits = execution.environment.limits
            
            try:
                # ביצוע הסקריפט
                process = subprocess.Popen(
                    [execution.environment.shell_executable, script_file],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=temp_dir,
                    env=env,
                    text=True,
                    preexec_fn=self._set_resource_limits(limits)
                )
                
                self.active_executions[execution.execution_id]['process'] = process
                
                stdout, stderr = process.communicate(timeout=limits.max_execution_time)
                
                result.stdout = stdout
                result.stderr = stderr
                result.return_code = process.returncode
                
            except subprocess.TimeoutExpired:
                process.kill()
                result.status = ExecutionStatus.TIMEOUT
                result.stderr = "הביצוע עבר את הזמן המותר"
                
            except Exception as e:
                result.status = ExecutionStatus.FAILED
                result.stderr = f"שגיאה בביצוע Bash: {str(e)}"
        
        return result
    
    def _execute_html(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע/הצגת HTML"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            
            # יצירת קובץ HTML
            html_file = os.path.join(temp_dir, f"page_{execution.execution_id}.html")
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(execution.code)
            
            # יצירת קבצים נוספים (CSS, JS, תמונות)
            for filename, content in execution.additional_files.items():
                file_path = os.path.join(temp_dir, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            result.output_files = {'main.html': execution.code}
            result.output_files.update(execution.additional_files)
            
            # יצירת preview URL (זמני)
            preview_url = f"file://{html_file}"
            result.generated_data = {
                'preview_url': preview_url,
                'file_path': html_file,
                'type': 'html_page'
            }
            
            result.stdout = f"HTML נוצר בהצלחה: {preview_url}"
            result.return_code = 0
        
        return result
    
    def _execute_sql(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע שאילתות SQL"""
        
        # כאן יש לממש חיבור למסד נתונים לפי ההגדרות
        # לצורך הדגמה - סימולציה
        
        try:
            # ניתוח הקוד SQL בסיסי
            sql_code = execution.code.strip()
            
            if sql_code.upper().startswith('SELECT'):
                # שאילתת בחירה - סימולציה
                result.stdout = "שאילתת SELECT בוצעה בהצלחה"
                result.generated_data = {
                    'rows_affected': 5,
                    'execution_time': '0.02 שניות',
                    'query_type': 'SELECT'
                }
            elif sql_code.upper().startswith(('INSERT', 'UPDATE', 'DELETE')):
                # שאילתת עדכון - סימולציה
                result.stdout = "שאילתת עדכון בוצעה בהצלחה"
                result.generated_data = {
                    'rows_affected': 3,
                    'execution_time': '0.01 שניות',
                    'query_type': 'MODIFICATION'
                }
            else:
                result.stdout = "שאילתת SQL בוצעה"
            
            result.return_code = 0
            
        except Exception as e:
            result.status = ExecutionStatus.FAILED
            result.stderr = f"שגיאה בביצוע SQL: {str(e)}"
        
        return result
    
    def _execute_docker(self, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע בקונטיינר Docker"""
        
        if not self.docker_client:
            result.status = ExecutionStatus.FAILED
            result.stderr = "Docker לא זמין במערכת"
            return result
        
        try:
            # בחירת image לפי סוג הקוד
            image_map = {
                ExecutionType.PYTHON: "python:3.9-slim",
                ExecutionType.JAVASCRIPT: "node:16-alpine",
                ExecutionType.BASH: "ubuntu:20.04"
            }
            
            image = image_map.get(execution.execution_type, "ubuntu:20.04")
            
            # יצירת script לביצוע
            script_content = execution.code
            
            # הרצת הקונטיינר
            container = self.docker_client.containers.run(
                image=image,
                command=["sh", "-c", script_content],
                detach=True,
                mem_limit=f"{execution.environment.limits.max_memory_mb}m",
                nano_cpus=int(execution.environment.limits.max_cpu_percent * 10000000),  # נאנו CPUs
                network_disabled=not execution.environment.network_enabled,
                remove=True
            )
            
            # המתנה לסיום
            exit_code = container.wait(timeout=execution.environment.limits.max_execution_time)
            
            # קבלת לוגים
            logs = container.logs(stdout=True, stderr=True).decode('utf-8')
            
            result.stdout = logs
            result.return_code = exit_code['StatusCode']
            
        except Exception as e:
            result.status = ExecutionStatus.FAILED
            result.stderr = f"שגיאה בביצוע Docker: {str(e)}"
        
        return result
    
    def _set_resource_limits(self, limits: ExecutionLimits):
        """הגדרת הגבלות משאבים לתהליך"""
        def set_limits():
            # הגבלת זיכרון
            resource.setrlimit(resource.RLIMIT_AS, (limits.max_memory_mb * 1024 * 1024, -1))
            
            # הגבלת זמן CPU
            resource.setrlimit(resource.RLIMIT_CPU, (limits.max_execution_time, -1))
            
            # הגבלת מספר קבצים פתוחים
            resource.setrlimit(resource.RLIMIT_NOFILE, (100, 200))
            
            # הגבלת מספר תהליכים
            resource.setrlimit(resource.RLIMIT_NPROC, (limits.max_subprocess, -1))
        
        return set_limits
    
    def _validate_security(self, execution: CodeExecution) -> Dict[str, Any]:
        """בדיקת אבטחה מתקדמת"""
        
        warnings = execution.validate_code()
        
        # בדיקות נוספות לפי רמת אבטחה
        security_level = execution.environment.security_level
        
        if security_level == SecurityLevel.MAXIMUM:
            # בדיקות קפדניות
            dangerous_imports = ['os', 'subprocess', 'sys', 'eval', 'exec']
            code_lower = execution.code.lower()
            
            for dangerous in dangerous_imports:
                if dangerous in code_lower:
                    return {
                        'valid': False,
                        'reason': f'מודול מסוכן זוהה: {dangerous}'
                    }
        
        # בדיקת גודל קוד
        if len(execution.code) > 1000000:  # 1MB
            return {
                'valid': False,
                'reason': 'קוד גדול מדי'
            }
        
        return {'valid': True, 'warnings': warnings}
    
    def _check_available_resources(self, execution: CodeExecution) -> bool:
        """בדיקת משאבים זמינים"""
        
        # בדיקת זיכרון זמין
        memory = psutil.virtual_memory()
        required_memory_mb = execution.environment.limits.max_memory_mb
        
        if memory.available < required_memory_mb * 1024 * 1024:
            return False
        
        # בדיקת עומס CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        if cpu_percent > 80:  # מעל 80% עומס
            return False
        
        # בדיקת מספר ביצועים פעילים
        if len(self.active_executions) >= self.config.max_concurrent_executions:
            return False
        
        return True
    
    async def _execute_async(self, handler: Callable, execution: CodeExecution, result: ExecutionResult) -> ExecutionResult:
        """ביצוע אסינכרוני"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self.thread_executor, handler, execution, result)
    
    def cancel_execution(self, execution_id: str) -> bool:
        """ביטול ביצוע פעיל"""
        
        if execution_id not in self.active_executions:
            return False
        
        execution_data = self.active_executions[execution_id]
        process = execution_data.get('process')
        
        if process and process.poll() is None:
            try:
                # ניסיון עצירה עדינה
                process.terminate()
                
                # המתנה קצרה
                time.sleep(1)
                
                # אם עדיין רץ - הרג כפוי
                if process.poll() is None:
                    process.kill()
                
                # עדכון תוצאה
                result = execution_data['result']
                result.status = ExecutionStatus.CANCELLED
                result.stderr = "הביצוע בוטל על ידי המשתמש"
                
                self.logger.info(f"ביצוע בוטל: {execution_id}")
                return True
                
            except Exception as e:
                self.logger.error(f"שגיאה בביטול ביצוע {execution_id}: {e}")
                return False
        
        return False
    
    def pause_execution(self, execution_id: str) -> bool:
        """השהיית ביצוע (אם נתמך)"""
        
        if execution_id not in self.active_executions:
            return False
        
        execution_data = self.active_executions[execution_id]
        process = execution_data.get('process')
        
        if process and process.poll() is None:
            try:
                # שליחת אות השהיה
                process.send_signal(signal.SIGSTOP)
                
                # עדכון סטטוס
                result = execution_data['result']
                result.status = ExecutionStatus.PAUSED
                
                self.logger.info(f"ביצוע הושהה: {execution_id}")
                return True
                
            except Exception as e:
                self.logger.error(f"שגיאה בהשהיית ביצוע {execution_id}: {e}")
                return False
        
        return False
    
    def resume_execution(self, execution_id: str) -> bool:
        """המשך ביצוע מושהה"""
        
        if execution_id not in self.active_executions:
            return False
        
        execution_data = self.active_executions[execution_id]
        process = execution_data.get('process')
        
        if process:
            try:
                # שליחת אות המשך
                process.send_signal(signal.SIGCONT)
                
                # עדכון סטטוס
                result = execution_data['result']
                result.status = ExecutionStatus.RUNNING
                
                self.logger.info(f"ביצוע חודש: {execution_id}")
                return True
                
            except Exception as e:
                self.logger.error(f"שגיאה בחידוש ביצוע {execution_id}: {e}")
                return False
        
        return False
    
    def get_execution_status(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """קבלת סטטוס ביצוע נוכחי"""
        
        if execution_id in self.active_executions:
            execution_data = self.active_executions[execution_id]
            result = execution_data['result']
            
            return {
                'execution_id': execution_id,
                'status': result.status.value,
                'start_time': execution_data['start_time'],
                'elapsed_time': (datetime.now() - execution_data['start_time']).total_seconds(),
                'can_be_cancelled': execution_data['execution'].can_be_cancelled,
                'can_be_paused': execution_data['execution'].can_be_paused
            }
        
        # חיפוש בהיסטוריה
        for result in self.execution_history:
            if result.execution_id == execution_id:
                return {
                    'execution_id': execution_id,
                    'status': result.status.value,
                    'completed': True,
                    'return_code': result.return_code,
                    'has_output': result.has_output()
                }
        
        return None
    
    def get_active_executions(self) -> List[Dict[str, Any]]:
        """קבלת רשימת ביצועים פעילים"""
        
        active_list = []
        
        for execution_id, execution_data in self.active_executions.items():
            result = execution_data['result']
            
            active_list.append({
                'execution_id': execution_id,
                'type': execution_data['execution'].execution_type.value,
                'status': result.status.value,
                'start_time': execution_data['start_time'],
                'elapsed_time': (datetime.now() - execution_data['start_time']).total_seconds(),
                'title': execution_data['execution'].title or 'ללא כותרת'
            })
        
        return active_list
    
    def get_code_templates(self, language: str = None) -> Dict[str, Any]:
        """קבלת תבניות קוד"""
        
        if language:
            return self.code_templates.get(language, {})
        
        return self.code_templates
    
    def create_execution_session(self, name: str, environment: ExecutionEnvironment) -> str:
        """יצירת סשן ביצוע חדש"""
        
        session_id = str(uuid.uuid4())
        
        session = ExecutionSession(
            session_id=session_id,
            name=name,
            environment=environment,
            created_at=datetime.now()
        )
        
        self.active_sessions[session_id] = session
        
        self.logger.info(f"סשן ביצוע נוצר: {name} ({session_id})")
        return session_id
    
    def close_execution_session(self, session_id: str) -> bool:
        """סגירת סשן ביצוע"""
        
        if session_id in self.active_sessions:
            session = self.active_sessions[session_id]
            session.cleanup()
            del self.active_sessions[session_id]
            
            self.logger.info(f"סשן ביצוע נסגר: {session_id}")
            return True
        
        return False
    
    def _cleanup_execution_resources(self, execution_id: str):
        """ניקוי משאבים של ביצוע"""
        
        # ניקוי קבצים זמניים
        # ניקוי קונטיינרים
        # ניקוי תהליכים תלויים
        
        pass
    
    def _trigger_event(self, event_type: str, data: Any):
        """הפעלת אירוע"""
        
        if event_type in self.event_handlers:
            for handler in self.event_handlers[event_type]:
                try:
                    handler(data)
                except Exception as e:
                    self.logger.error(f"שגיאה במטפל אירוע {event_type}: {e}")
    
    def get_system_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות מערכת"""
        
        return {
            'active_executions': len(self.active_executions),
            'total_executions': len(self.execution_history),
            'active_sessions': len(self.active_sessions),
            'successful_executions': len([r for r in self.execution_history if r.is_successful()]),
            'failed_executions': len([r for r in self.execution_history if not r.is_successful()]),
            'memory_usage': psutil.virtual_memory().percent,
            'cpu_usage': psutil.cpu_percent(),
            'docker_available': self.docker_client is not None
        }
    
    def shutdown(self):
        """כיבוי מנוע הביצוע"""
        
        self.logger.info("כיבוי מנוע ביצוע...")
        
        # ביטול כל הביצועים הפעילים
        for execution_id in list(self.active_executions.keys()):
            self.cancel_execution(execution_id)
        
        # סגירת כל הסשנים
        for session_id in list(self.active_sessions.keys()):
            self.close_execution_session(session_id)
        
        # כיבוי thread pools
        self.thread_executor.shutdown(wait=True)
        self.process_executor.shutdown(wait=True)
        
        # סגירת Docker client
        if self.docker_client:
            self.docker_client.close()
        
        self.logger.info("מנוע ביצוע נכבה בהצלחה")

class ResourceMonitor:
    """מוניטור משאבי מערכת"""
    
    def __init__(self):
        self.monitoring = False
        self.monitor_thread = None
        
    def start_monitoring(self):
        """התחלת ניטור"""
        pass
    
    def stop_monitoring(self):
        """עצירת ניטור"""
        pass
    
    def get_current_usage(self) -> Dict[str, float]:
        """קבלת שימוש נוכחי במשאבים"""
        return {
            'cpu_percent': psutil.cpu_percent(),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent
        }