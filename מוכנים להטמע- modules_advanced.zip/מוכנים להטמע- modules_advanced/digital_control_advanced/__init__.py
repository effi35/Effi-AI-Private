"""
Digital Control Advanced Module
==============================

A comprehensive digital control system providing secure code execution,
system control, process management, and security sandboxing capabilities
using local Hudson/Llama models.

Features:
- Multi-language code execution (Python, JavaScript, Bash, Go, Rust, C++, etc.)
- Secure sandboxing environment
- System process management
- Resource monitoring and control
- Security auditing and logging
- Local AI model integration for code analysis
- Real-time execution monitoring
- Error handling and recovery

Author: Effi AI System
Version: 1.0.0
"""

from .core.execution_engine import ExecutionEngine
from .core.sandbox_manager import SandboxManager
from .core.security_monitor import SecurityMonitor
from .core.process_manager import ProcessManager
from .core.ollama_integration import OllamaIntegration
from .models.execution_types import ExecutionRequest, ExecutionResult
from .models.security_types import SecurityPolicy, SecurityEvent
from .models.system_types import SystemResource, ProcessInfo

__version__ = "1.0.0"
__author__ = "Effi AI System"

__all__ = [
    'ExecutionEngine',
    'SandboxManager', 
    'SecurityMonitor',
    'ProcessManager',
    'OllamaIntegration',
    'ExecutionRequest',
    'ExecutionResult',
    'SecurityPolicy',
    'SecurityEvent',
    'SystemResource',
    'ProcessInfo'
]