"""
Digital Control Advanced - Execution Engine
מנוע ביצוע קוד מתקדם עם תמיכה בכל השפות ואבטחה מלאה
"""

import asyncio
import subprocess
import tempfile
import shutil
import os
import psutil
import docker
import time
import signal
import threading
from typing import Dict, List, Any, Optional, AsyncGenerator, Callable
from datetime import datetime, timedelta
import logging
import json
import re
from pathlib import Path
import resource

from ..models.control_types import (
    ExecutionRequest, ExecutionResult, ExecutionStatus, LanguageType,
    ExecutionMode, SecurityLevel, SecurityPolicy, ResourceLimits,
    LanguageConfig, SandboxEnvironment, ProcessInfo,
    LanguageConfigFactory, SecurityPolicyFactory
)

class SecurityMonitor:
    """מוניטור אבטחה לביצוע קוד"""
    
    def __init__(self):
        self.violations = []
        self.monitoring_active = False
        
    def start_monitoring(self, process_id: int, policy: SecurityPolicy):
        """התחלת ניטור אבטחה"""
        self.monitoring_active = True
        self.process_id = process_id
        self.policy = policy
        
        # התחלת thread ניטור
        monitor_thread = threading.Thread(
            target=self._monitor_process,
            args=(process_id, policy),
            daemon=True
        )
        monitor_thread.start()
    
    def stop_monitoring(self):
        """עצירת ניטור"""
        self.monitoring_active = False
    
    def _monitor_process(self, process_id: int, policy: SecurityPolicy):
        """ניטור תהליך"""
        try:
            process = psutil.Process(process_id)
            
            while self.monitoring_active and process.is_running():
                # ניטור שימוש במשאבים
                self._monitor_resources(process, policy)
                
                # ניטור חיבורי רשת
                if not policy.allow_network_access:
                    self._monitor_network(process)
                
                # ניטור קבצים
                self._monitor_file_access(process, policy)
                
                time.sleep(0.5)  # בדיקה כל חצי שנייה
                
        except psutil.NoSuchProcess:
            pass  # התהליך הסתיים
        except Exception as e:
            logging.error(f"Security monitoring error: {str(e)}")
    
    def _monitor_resources(self, process: psutil.Process, policy: SecurityPolicy):
        """ניטור משאבים"""
        try:
            # בדיקת זיכרון
            memory_info = process.memory_info()
            memory_mb = memory_info.rss / 1024 / 1024
            
            if hasattr(policy, 'max_memory_mb') and memory_mb > policy.max_memory_mb:
                self._add_violation(f"Memory limit exceeded: {memory_mb:.1f}MB")
            
            # בדיקת CPU
            cpu_percent = process.cpu_percent()
            if hasattr(policy, 'max_cpu_percent') and cpu_percent > policy.max_cpu_percent:
                self._add_violation(f"CPU limit exceeded: {cpu_percent:.1f}%")
                
        except Exception as e:
            logging.warning(f"Resource monitoring error: {str(e)}")
    
    def _monitor_network(self, process: psutil.Process):
        """ניטור רשת"""
        try:
            connections = process.connections()
            if connections:
                self._add_violation("Unauthorized network access detected")
        except Exception:
            pass
    
    def _monitor_file_access(self, process: psutil.Process, policy: SecurityPolicy):
        """ניטור גישה לקבצים"""
        try:
            open_files = process.open_files()
            
            for file_info in open_files:
                file_path = file_info.path
                
                # בדיקת תבניות חסומות
                for blocked_pattern in policy.blocked_file_patterns:
                    if re.match(blocked_pattern, file_path):
                        self._add_violation(f"Access to blocked file: {file_path}")
                
                # בדיקת כתיבה לקבצים מסוכנים
                if not policy.allow_file_system_write:
                    if '/tmp/' not in file_path and file_info.mode == 'w':
                        self._add_violation(f"Unauthorized file write: {file_path}")
                        
        except Exception:
            pass
    
    def _add_violation(self, violation: str):
        """הוספת הפרת אבטחה"""
        self.violations.append({
            "timestamp": datetime.now().isoformat(),
            "violation": violation,
            "process_id": self.process_id
        })
        logging.warning(f"Security violation: {violation}")

class SandboxManager:
    """מנהל sandbox environments"""
    
    def __init__(self):
        self.docker_client = None
        self.active_containers = {}
        self.sandbox_cache = {}
        
        try:
            self.docker_client = docker.from_env()
        except Exception as e:
            logging.warning(f"Docker not available: {str(e)}")
    
    async def create_sandbox(self, config: SandboxEnvironment) -> str:
        """יצירת sandbox"""
        try:
            if not self.docker_client:
                # Fallback לsandbox מבוסס תיקיות
                return await self._create_filesystem_sandbox(config)
            
            # יצירת Docker container
            container = self.docker_client.containers.run(
                image=config.container_image,
                detach=True,
                mem_limit=f"{config.allocated_memory_mb}m",
                cpu_period=100000,
                cpu_quota=int(config.allocated_cpu_cores * 100000),
                network_disabled=config.network_isolated,
                read_only=False,
                tmpfs={'/tmp': f'size={config.allocated_disk_mb}m'},
                security_opt=['no-new-privileges:true'],
                cap_drop=['ALL'],
                cap_add=['CHOWN', 'DAC_OVERRIDE', 'FOWNER', 'SETGID', 'SETUID'] if config.security_profile != 'strict' else [],
                command='sleep infinity'
            )
            
            self.active_containers[config.sandbox_id] = container
            config.is_active = True
            
            logging.info(f"Created Docker sandbox: {config.sandbox_id}")
            return config.sandbox_id
            
        except Exception as e:
            logging.error(f"Sandbox creation failed: {str(e)}")
            return await self._create_filesystem_sandbox(config)
    
    async def _create_filesystem_sandbox(self, config: SandboxEnvironment) -> str:
        """יצירת sandbox מבוסס מערכת קבצים"""
        sandbox_dir = os.path.join(tempfile.gettempdir(), f"sandbox_{config.sandbox_id}")
        os.makedirs(sandbox_dir, exist_ok=True)
        
        # הגדרת הרשאות מוגבלות
        os.chmod(sandbox_dir, 0o755)
        
        config.base_directory = sandbox_dir
        config.is_active = True
        
        logging.info(f"Created filesystem sandbox: {config.sandbox_id}")
        return config.sandbox_id
    
    async def execute_in_sandbox(
        self,
        sandbox_id: str,
        command: List[str],
        working_dir: str = "/tmp",
        environment: Dict[str, str] = None,
        stdin_data: str = "",
        timeout: int = 30
    ) -> Dict[str, Any]:
        """ביצוע פקודה בsandbox"""
        try:
            if sandbox_id in self.active_containers:
                return await self._execute_in_docker(
                    sandbox_id, command, working_dir, environment, stdin_data, timeout
                )
            else:
                return await self._execute_in_filesystem(
                    sandbox_id, command, working_dir, environment, stdin_data, timeout
                )
        except Exception as e:
            logging.error(f"Sandbox execution error: {str(e)}")
            return {
                "returncode": 1,
                "stdout": "",
                "stderr": str(e),
                "timeout": False
            }
    
    async def _execute_in_docker(
        self,
        sandbox_id: str,
        command: List[str],
        working_dir: str,
        environment: Dict[str, str],
        stdin_data: str,
        timeout: int
    ) -> Dict[str, Any]:
        """ביצוע בDocker container"""
        container = self.active_containers[sandbox_id]
        
        try:
            # יצירת קובץ זמני עם הקוד
            if stdin_data:
                # העברת stdin כקובץ
                container.put_archive('/tmp', self._create_tar_archive('input.txt', stdin_data))
                command = ['sh', '-c', f'cat /tmp/input.txt | {" ".join(command)}']
            
            # ביצוע הפקודה
            result = container.exec_run(
                cmd=command,
                workdir=working_dir,
                environment=environment or {},
                demux=True,
                timeout=timeout
            )
            
            exit_code = result.exit_code
            stdout = result.output[0].decode('utf-8') if result.output[0] else ""
            stderr = result.output[1].decode('utf-8') if result.output[1] else ""
            
            return {
                "returncode": exit_code,
                "stdout": stdout,
                "stderr": stderr,
                "timeout": False
            }
            
        except docker.errors.APIError as e:
            if "timeout" in str(e).lower():
                return {
                    "returncode": 124,
                    "stdout": "",
                    "stderr": "Execution timeout",
                    "timeout": True
                }
            raise
    
    async def _execute_in_filesystem(
        self,
        sandbox_id: str,
        command: List[str],
        working_dir: str,
        environment: Dict[str, str],
        stdin_data: str,
        timeout: int
    ) -> Dict[str, Any]:
        """ביצוע במערכת קבצים"""
        try:
            # הכנת סביבה
            env = os.environ.copy()
            if environment:
                env.update(environment)
            
            # ביצוע הפקודה
            process = await asyncio.create_subprocess_exec(
                *command,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=working_dir,
                env=env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(input=stdin_data.encode()),
                    timeout=timeout
                )
                
                return {
                    "returncode": process.returncode,
                    "stdout": stdout.decode('utf-8'),
                    "stderr": stderr.decode('utf-8'),
                    "timeout": False
                }
                
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                
                return {
                    "returncode": 124,
                    "stdout": "",
                    "stderr": "Execution timeout",
                    "timeout": True
                }
                
        except Exception as e:
            return {
                "returncode": 1,
                "stdout": "",
                "stderr": str(e),
                "timeout": False
            }
    
    def _create_tar_archive(self, filename: str, content: str) -> bytes:
        """יצירת tar archive"""
        import tarfile
        import io
        
        tar_buffer = io.BytesIO()
        with tarfile.open(fileobj=tar_buffer, mode='w') as tar:
            info = tarfile.TarInfo(name=filename)
            info.size = len(content.encode())
            tar.addfile(info, io.BytesIO(content.encode()))
        
        tar_buffer.seek(0)
        return tar_buffer.read()
    
    async def cleanup_sandbox(self, sandbox_id: str):
        """ניקוי sandbox"""
        try:
            if sandbox_id in self.active_containers:
                container = self.active_containers[sandbox_id]
                container.stop(timeout=5)
                container.remove()
                del self.active_containers[sandbox_id]
            
            # ניקוי תיקיות
            sandbox_dir = os.path.join(tempfile.gettempdir(), f"sandbox_{sandbox_id}")
            if os.path.exists(sandbox_dir):
                shutil.rmtree(sandbox_dir, ignore_errors=True)
                
        except Exception as e:
            logging.error(f"Sandbox cleanup error: {str(e)}")

class LanguageExecutor:
    """מפעיל שפות תכנות"""
    
    def __init__(self, sandbox_manager: SandboxManager):
        self.sandbox_manager = sandbox_manager
        self.language_configs = self._initialize_language_configs()
        
    def _initialize_language_configs(self) -> Dict[LanguageType, LanguageConfig]:
        """אתחול הגדרות שפות"""
        return {
            LanguageType.PYTHON: LanguageConfigFactory.create_python_config(),
            LanguageType.JAVASCRIPT: LanguageConfigFactory.create_javascript_config(),
            LanguageType.BASH: LanguageConfigFactory.create_bash_config(),
            LanguageType.GO: LanguageConfigFactory.create_go_config(),
            LanguageType.RUST: LanguageConfigFactory.create_rust_config(),
        }
    
    async def execute_code(
        self,
        request: ExecutionRequest,
        sandbox_id: str
    ) -> ExecutionResult:
        """ביצוע קוד"""
        result = ExecutionResult(request_id=request.request_id)
        result.started_at = datetime.now()
        result.status = ExecutionStatus.RUNNING
        
        try:
            # בחירת הגדרות שפה
            lang_config = self.language_configs.get(request.language)
            if not lang_config:
                result.add_error(f"Unsupported language: {request.language.value}")
                result.mark_failed()
                return result
            
            # הכנת קוד לביצוע
            code_file, command = await self._prepare_code_execution(request, lang_config)
            
            # אבטחה וסינון
            security_check = self._security_check_code(request.code, lang_config, request.security_policy)
            if security_check:
                result.add_security_violation(security_check)
                result.mark_failed()
                return result
            
            # ביצוע הקוד
            execution_start = time.time()
            
            exec_result = await self.sandbox_manager.execute_in_sandbox(
                sandbox_id=sandbox_id,
                command=command,
                working_dir=request.working_directory or "/tmp",
                environment=request.environment_vars,
                stdin_data=request.stdin_data,
                timeout=request.resource_limits.max_execution_time_seconds
            )
            
            execution_time = time.time() - execution_start
            
            # עיבוד תוצאות
            result.stdout = exec_result["stdout"]
            result.stderr = exec_result["stderr"]
            result.return_code = exec_result["returncode"]
            result.execution_time_seconds = execution_time
            
            if exec_result["timeout"]:
                result.status = ExecutionStatus.TIMEOUT
                result.add_error("Execution timeout")
            elif exec_result["returncode"] == 0:
                result.mark_completed()
            else:
                result.mark_failed(f"Process exited with code {exec_result['returncode']}")
            
            # אוסף קבצי פלט אם נדרש
            if request.output_files:
                result.output_files = await self._collect_output_files(
                    sandbox_id, request.output_files
                )
            
        except Exception as e:
            result.add_error(f"Execution error: {str(e)}")
            result.mark_failed()
        
        result.completed_at = datetime.now()
        return result
    
    async def _prepare_code_execution(
        self,
        request: ExecutionRequest,
        lang_config: LanguageConfig
    ) -> tuple[str, List[str]]:
        """הכנת קוד לביצוע"""
        # יצירת קובץ קוד זמני
        code_filename = f"code_{request.request_id}{lang_config.file_extension}"
        
        if request.language == LanguageType.PYTHON:
            command = [lang_config.interpreter_path] + lang_config.default_args + [code_filename]
        elif request.language == LanguageType.JAVASCRIPT:
            command = [lang_config.interpreter_path, code_filename]
        elif request.language == LanguageType.BASH:
            command = [lang_config.interpreter_path] + lang_config.default_args + [code_filename]
        elif request.language == LanguageType.GO:
            command = [lang_config.interpreter_path, "run", code_filename]
        elif request.language == LanguageType.RUST:
            # Rust צריך קומפילציה
            executable = f"code_{request.request_id}"
            command = [
                "sh", "-c", 
                f"{lang_config.compiler_path} {code_filename} -o {executable} && ./{executable}"
            ]
        else:
            command = [lang_config.interpreter_path, code_filename]
        
        return code_filename, command
    
    def _security_check_code(
        self,
        code: str,
        lang_config: LanguageConfig,
        policy: SecurityPolicy
    ) -> Optional[str]:
        """בדיקת אבטחה של קוד"""
        code_lower = code.lower()
        
        # בדיקת פונקציות מסוכנות
        for dangerous_func in lang_config.dangerous_functions:
            if dangerous_func in code_lower:
                return f"Dangerous function detected: {dangerous_func}"
        
        # בדיקת מודולים חסומים
        for blocked_module in policy.blocked_modules:
            patterns = [
                f"import {blocked_module}",
                f"from {blocked_module}",
                f"require('{blocked_module}')",
                f'require("{blocked_module}")'
            ]
            
            for pattern in patterns:
                if pattern.lower() in code_lower:
                    return f"Blocked module usage: {blocked_module}"
        
        # בדיקות ספציפיות לשפה
        if lang_config.language == LanguageType.PYTHON:
            return self._python_security_check(code, policy)
        elif lang_config.language == LanguageType.JAVASCRIPT:
            return self._javascript_security_check(code, policy)
        elif lang_config.language == LanguageType.BASH:
            return self._bash_security_check(code, policy)
        
        return None
    
    def _python_security_check(self, code: str, policy: SecurityPolicy) -> Optional[str]:
        """בדיקת אבטחה Python"""
        dangerous_patterns = [
            r'__import__\s*\(',
            r'exec\s*\(',
            r'eval\s*\(',
            r'compile\s*\(',
            r'open\s*\(',
            r'file\s*\(',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, code, re.IGNORECASE):
                return f"Dangerous Python pattern: {pattern}"
        
        # בדיקת גישה למערכת
        if not policy.allow_system_calls:
            system_patterns = [
                r'os\.system',
                r'subprocess\.',
                r'commands\.',
                r'platform\.',
            ]
            
            for pattern in system_patterns:
                if re.search(pattern, code, re.IGNORECASE):
                    return f"System access not allowed: {pattern}"
        
        return None
    
    def _javascript_security_check(self, code: str, policy: SecurityPolicy) -> Optional[str]:
        """בדיקת אבטחה JavaScript"""
        dangerous_patterns = [
            r'eval\s*\(',
            r'Function\s*\(',
            r'setTimeout\s*\(',
            r'setInterval\s*\(',
            r'require\s*\(',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, code, re.IGNORECASE):
                return f"Dangerous JavaScript pattern: {pattern}"
        
        return None
    
    def _bash_security_check(self, code: str, policy: SecurityPolicy) -> Optional[str]:
        """בדיקת אבטחה Bash"""
        dangerous_commands = [
            'rm ', 'rmdir ', 'mv ', 'cp ', 'chmod ', 'chown ',
            'su ', 'sudo ', 'passwd ', 'crontab ', 'at ',
            'wget ', 'curl ', 'nc ', 'netcat ', 'ssh ', 'scp ',
            'dd ', 'mkfs ', 'fdisk ', 'mount ', 'umount '
        ]
        
        code_lower = code.lower()
        for cmd in dangerous_commands:
            if cmd in code_lower:
                return f"Dangerous Bash command: {cmd.strip()}"
        
        return None
    
    async def _collect_output_files(
        self,
        sandbox_id: str,
        file_patterns: List[str]
    ) -> Dict[str, bytes]:
        """איסוף קבצי פלט"""
        output_files = {}
        
        try:
            for pattern in file_patterns:
                # כאן יהיה קוד לאיסוף קבצים מהsandbox
                # לעת עתה מחזירים מילון ריק
                pass
        except Exception as e:
            logging.error(f"Output file collection error: {str(e)}")
        
        return output_files

class ExecutionEngine:
    """מנוע ביצוע ראשי"""
    
    def __init__(self, ollama_client=None):
        self.sandbox_manager = SandboxManager()
        self.language_executor = LanguageExecutor(self.sandbox_manager)
        self.security_monitor = SecurityMonitor()
        self.ollama_client = ollama_client
        
        # מעקב ביצועים
        self.execution_stats = {
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "security_violations": 0,
            "average_execution_time": 0.0
        }
        
        # תור ביצוע
        self.execution_queue = asyncio.Queue(maxsize=100)
        self.active_executions = {}
        
    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """ביצוע בקשה"""
        try:
            # התחלת מעקב
            self.execution_stats["total_executions"] += 1
            
            # אימות בקשה
            validation_errors = self._validate_request(request)
            if validation_errors:
                result = ExecutionResult(request_id=request.request_id)
                for error in validation_errors:
                    result.add_error(error)
                result.mark_failed()
                return result
            
            # בחירת sandbox
            sandbox_config = self._select_sandbox_config(request)
            sandbox_id = await self.sandbox_manager.create_sandbox(sandbox_config)
            
            try:
                # ביצוע עם ניטור אבטחה
                if request.security_level != SecurityLevel.MINIMAL:
                    self.security_monitor.start_monitoring(
                        os.getpid(),  # בפועל יהיה process_id של הביצוע
                        request.security_policy
                    )
                
                # ביצוע הקוד
                result = await self.language_executor.execute_code(request, sandbox_id)
                
                # הוספת הפרות אבטחה לתוצאה
                if self.security_monitor.violations:
                    for violation in self.security_monitor.violations:
                        result.add_security_violation(violation["violation"])
                
                # עדכון סטטיסטיקות
                if result.status == ExecutionStatus.COMPLETED:
                    self.execution_stats["successful_executions"] += 1
                else:
                    self.execution_stats["failed_executions"] += 1
                
                if self.security_monitor.violations:
                    self.execution_stats["security_violations"] += 1
                
                # עדכון זמן ממוצע
                current_avg = self.execution_stats["average_execution_time"]
                total_exec = self.execution_stats["total_executions"]
                new_avg = ((current_avg * (total_exec - 1)) + result.execution_time_seconds) / total_exec
                self.execution_stats["average_execution_time"] = new_avg
                
                return result
                
            finally:
                # ניקוי
                self.security_monitor.stop_monitoring()
                await self.sandbox_manager.cleanup_sandbox(sandbox_id)
                
        except Exception as e:
            logging.error(f"Execution engine error: {str(e)}")
            result = ExecutionResult(request_id=request.request_id)
            result.add_error(f"Engine error: {str(e)}")
            result.mark_failed()
            return result
    
    def _validate_request(self, request: ExecutionRequest) -> List[str]:
        """אימות בקשת ביצוע"""
        errors = []
        
        if not request.code.strip():
            errors.append("Empty code")
        
        if len(request.code) > 1000000:  # 1MB limit
            errors.append("Code too large")
        
        if request.resource_limits.max_execution_time_seconds > 300:  # 5 minutes max
            errors.append("Execution time limit too high")
        
        if request.resource_limits.max_memory_mb > 2048:  # 2GB max
            errors.append("Memory limit too high")
        
        return errors
    
    def _select_sandbox_config(self, request: ExecutionRequest) -> SandboxEnvironment:
        """בחירת הגדרות sandbox"""
        from ..models.control_types import create_default_sandbox
        
        config = create_default_sandbox()
        config.allocated_memory_mb = request.resource_limits.max_memory_mb
        config.allocated_cpu_cores = min(request.resource_limits.max_cpu_percent / 100, 1.0)
        
        # בחירת תמונת container לפי שפה
        language_images = {
            LanguageType.PYTHON: "python:3.9-alpine",
            LanguageType.JAVASCRIPT: "node:16-alpine",
            LanguageType.GO: "golang:1.19-alpine",
            LanguageType.RUST: "rust:1.65-alpine",
            LanguageType.JAVA: "openjdk:11-alpine",
            LanguageType.BASH: "alpine:latest"
        }
        
        config.container_image = language_images.get(
            request.language,
            "alpine:latest"
        )
        
        # הגדרות אבטחה
        if request.security_level == SecurityLevel.MAXIMUM:
            config.network_isolated = True
            config.security_profile = "strict"
        elif request.security_level == SecurityLevel.MINIMAL:
            config.network_isolated = False
            config.security_profile = "permissive"
        
        return config
    
    async def execute_async(self, request: ExecutionRequest) -> str:
        """ביצוע אסינכרוני - מחזיר execution ID"""
        execution_id = str(uuid.uuid4())
        
        # הוספה לתור
        asyncio.create_task(self._process_async_execution(execution_id, request))
        
        return execution_id
    
    async def _process_async_execution(self, execution_id: str, request: ExecutionRequest):
        """עיבוד ביצוע אסינכרוני"""
        try:
            self.active_executions[execution_id] = {
                "status": ExecutionStatus.PENDING,
                "started_at": datetime.now(),
                "request": request
            }
            
            result = await self.execute(request)
            
            self.active_executions[execution_id] = {
                "status": result.status,
                "result": result,
                "completed_at": datetime.now()
            }
            
        except Exception as e:
            self.active_executions[execution_id] = {
                "status": ExecutionStatus.ERROR,
                "error": str(e),
                "completed_at": datetime.now()
            }
    
    def get_execution_status(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """קבלת סטטוס ביצוע אסינכרוני"""
        return self.active_executions.get(execution_id)
    
    def cancel_execution(self, execution_id: str) -> bool:
        """ביטול ביצוע"""
        if execution_id in self.active_executions:
            execution_info = self.active_executions[execution_id]
            if execution_info["status"] in [ExecutionStatus.PENDING, ExecutionStatus.RUNNING]:
                execution_info["status"] = ExecutionStatus.CANCELLED
                return True
        return False
    
    def get_system_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות מערכת"""
        return {
            "execution_stats": self.execution_stats,
            "active_executions": len([
                e for e in self.active_executions.values()
                if e["status"] in [ExecutionStatus.PENDING, ExecutionStatus.RUNNING]
            ]),
            "total_sandboxes": len(self.sandbox_manager.active_containers),
            "supported_languages": [lang.value for lang in self.language_executor.language_configs.keys()]
        }
    
    async def cleanup_old_executions(self, max_age_hours: int = 24):
        """ניקוי ביצועים ישנים"""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        to_remove = []
        for execution_id, execution_info in self.active_executions.items():
            completed_at = execution_info.get("completed_at")
            if completed_at and completed_at < cutoff_time:
                to_remove.append(execution_id)
        
        for execution_id in to_remove:
            del self.active_executions[execution_id]
        
        logging.info(f"Cleaned up {len(to_remove)} old executions")

# פונקציות עזר
def create_execution_engine(ollama_client=None) -> ExecutionEngine:
    """יצירת מנוע ביצוע"""
    return ExecutionEngine(ollama_client)

async def quick_execute(
    code: str,
    language: LanguageType = LanguageType.PYTHON,
    timeout: int = 30
) -> ExecutionResult:
    """ביצוע מהיר של קוד"""
    engine = create_execution_engine()
    
    request = ExecutionRequest(
        code=code,
        language=language,
        execution_mode=ExecutionMode.SAFE_SANDBOX,
        security_level=SecurityLevel.MEDIUM
    )
    request.resource_limits.max_execution_time_seconds = timeout
    
    return await engine.execute(request)