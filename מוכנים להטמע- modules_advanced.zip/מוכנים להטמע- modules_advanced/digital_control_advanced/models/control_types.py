"""
Digital Control Advanced - Control Types and Models
מודלים לבקרה דיגיטלית מתקדמת עם הרצת קוד בכל השפות
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, Callable, Set
from datetime import datetime, timedelta
import uuid
import json
import os

class LanguageType(Enum):
    """סוגי שפות תכנות נתמכות"""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    BASH = "bash"
    SHELL = "shell"
    ZSH = "zsh"
    FISH = "fish"
    POWERSHELL = "powershell"
    GO = "go"
    RUST = "rust"
    C = "c"
    CPP = "cpp"
    CSHARP = "csharp"
    JAVA = "java"
    KOTLIN = "kotlin"
    SCALA = "scala"
    PHP = "php"
    RUBY = "ruby"
    PERL = "perl"
    LUA = "lua"
    R = "r"
    JULIA = "julia"
    SWIFT = "swift"
    DART = "dart"
    HASKELL = "haskell"
    ERLANG = "erlang"
    ELIXIR = "elixir"
    CLOJURE = "clojure"
    F_SHARP = "fsharp"
    OCAML = "ocaml"
    ASSEMBLY = "assembly"
    SQL = "sql"
    HTML = "html"
    CSS = "css"
    DOCKERFILE = "dockerfile"
    YAML = "yaml"
    JSON = "json"
    XML = "xml"
    MARKDOWN = "markdown"
    LATEX = "latex"

class ExecutionMode(Enum):
    """מצבי ביצוע"""
    SAFE_SANDBOX = "safe_sandbox"         # sandbox בטוח
    RESTRICTED = "restricted"             # מוגבל
    CONTROLLED = "controlled"             # מבוקר
    FULL_ACCESS = "full_access"          # גישה מלאה
    ISOLATED = "isolated"                # מבודד
    VIRTUAL = "virtual"                  # וירטואלי

class SecurityLevel(Enum):
    """רמות אבטחה"""
    MINIMAL = "minimal"                  # מינימלי
    LOW = "low"                         # נמוך
    MEDIUM = "medium"                   # בינוני
    HIGH = "high"                       # גבוה
    MAXIMUM = "maximum"                 # מקסימלי
    PARANOID = "paranoid"               # פרנואידי

class ExecutionStatus(Enum):
    """סטטוסי ביצוע"""
    PENDING = "pending"                 # ממתין
    PREPARING = "preparing"             # מכין
    RUNNING = "running"                 # רץ
    COMPLETED = "completed"             # הושלם
    FAILED = "failed"                   # נכשל
    TIMEOUT = "timeout"                 # timeout
    CANCELLED = "cancelled"             # בוטל
    KILLED = "killed"                   # הופסק בכוח
    ERROR = "error"                     # שגיאה

class ProcessPriority(Enum):
    """עדיפות תהליכים"""
    LOWEST = "lowest"                   # הכי נמוך
    LOW = "low"                        # נמוך
    BELOW_NORMAL = "below_normal"      # מתחת לרגיל
    NORMAL = "normal"                  # רגיל
    ABOVE_NORMAL = "above_normal"      # מעל רגיל
    HIGH = "high"                      # גבוה
    HIGHEST = "highest"                # הכי גבוה
    REALTIME = "realtime"              # זמן אמת

@dataclass
class ResourceLimits:
    """מגבלות משאבים"""
    max_memory_mb: int = 512              # זיכרון מקסימלי במגה
    max_cpu_percent: float = 50.0         # CPU מקסימלי באחוזים
    max_disk_mb: int = 100               # שימוש דיסק מקסימלי
    max_network_kb: int = 1000           # רשת מקסימלית בקילובייט
    max_processes: int = 10              # מספר תהליכים מקסימלי
    max_files: int = 100                 # מספר קבצים מקסימלי
    max_execution_time_seconds: int = 30  # זמן ביצוע מקסימלי
    max_output_size_kb: int = 1000       # גודל פלט מקסימלי
    
    def __post_init__(self):
        """אימות ערכים"""
        if self.max_memory_mb <= 0:
            self.max_memory_mb = 512
        if self.max_cpu_percent <= 0 or self.max_cpu_percent > 100:
            self.max_cpu_percent = 50.0
        if self.max_execution_time_seconds <= 0:
            self.max_execution_time_seconds = 30

@dataclass
class SecurityPolicy:
    """מדיניות אבטחה"""
    allow_network_access: bool = False     # אפשר גישה לרשת
    allow_file_system_read: bool = True    # אפשר קריאת מערכת קבצים
    allow_file_system_write: bool = False  # אפשר כתיבת מערכת קבצים
    allow_subprocess: bool = False         # אפשר תהליכי משנה
    allow_import_modules: bool = True      # אפשר ייבוא מודולים
    allow_system_calls: bool = False       # אפשר קריאות מערכת
    allow_environment_access: bool = False # אפשר גישה למשתני סביבה
    
    # רשימות לבנות ושחורות
    allowed_modules: Set[str] = field(default_factory=set)      # מודולים מותרים
    blocked_modules: Set[str] = field(default_factory=set)      # מודולים חסומים
    allowed_hosts: Set[str] = field(default_factory=set)        # hosts מותרים
    blocked_hosts: Set[str] = field(default_factory=set)        # hosts חסומים
    allowed_file_patterns: Set[str] = field(default_factory=set) # תבניות קבצים מותרות
    blocked_file_patterns: Set[str] = field(default_factory=set) # תבניות קבצים חסומות
    
    # הגדרות מתקדמות
    sandbox_timeout_seconds: int = 60      # timeout sandbox
    max_recursion_depth: int = 100         # עומק רקורסיה מקסימלי
    enable_memory_monitoring: bool = True  # הפעל ניטור זיכרון
    enable_cpu_monitoring: bool = True     # הפעל ניטור CPU
    log_all_operations: bool = True        # רשום כל הפעולות

@dataclass
class LanguageConfig:
    """הגדרות שפת תכנות"""
    language: LanguageType
    interpreter_path: str = ""             # נתיב מפרש
    compiler_path: str = ""                # נתיב קומפיילר
    version: str = ""                      # גרסה
    default_args: List[str] = field(default_factory=list)  # ארגומנטים ברירת מחדל
    environment_vars: Dict[str, str] = field(default_factory=dict)  # משתני סביבה
    file_extension: str = ""               # סיומת קובץ
    supports_interactive: bool = True      # תמיכה באינטראקטיבי
    supports_compilation: bool = False     # תמיכה בקומפילציה
    
    # הגדרות אבטחה ספציפיות לשפה
    dangerous_functions: Set[str] = field(default_factory=set)     # פונקציות מסוכנות
    safe_modules: Set[str] = field(default_factory=set)            # מודולים בטוחים
    required_modules: Set[str] = field(default_factory=set)        # מודולים נדרשים

@dataclass
class ExecutionRequest:
    """בקשת ביצוע קוד"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    code: str = ""                         # הקוד לביצוע
    language: LanguageType = LanguageType.PYTHON
    execution_mode: ExecutionMode = ExecutionMode.SAFE_SANDBOX
    security_level: SecurityLevel = SecurityLevel.MEDIUM
    
    # הגדרות ביצוע
    priority: ProcessPriority = ProcessPriority.NORMAL
    resource_limits: ResourceLimits = field(default_factory=ResourceLimits)
    security_policy: SecurityPolicy = field(default_factory=SecurityPolicy)
    
    # קלט ופלט
    stdin_data: str = ""                   # נתוני קלט סטנדרטי
    working_directory: str = ""            # תיקיית עבודה
    environment_vars: Dict[str, str] = field(default_factory=dict)  # משתני סביבה
    
    # קבצים
    input_files: Dict[str, bytes] = field(default_factory=dict)     # קבצי קלט
    output_files: List[str] = field(default_factory=list)          # קבצי פלט מבוקשים
    
    # הגדרות מתקדמות
    async_execution: bool = False          # ביצוע אסינכרוני
    stream_output: bool = False            # זרימת פלט
    save_state: bool = False               # שמירת מצב
    session_id: Optional[str] = None       # מזהה session
    
    # מטאדטה
    title: str = ""                        # כותרת
    description: str = ""                  # תיאור
    tags: List[str] = field(default_factory=list)      # תגים
    metadata: Dict[str, Any] = field(default_factory=dict)  # מטאדטה נוספת
    
    # זמנים
    created_at: datetime = field(default_factory=datetime.now)
    requested_by: str = "system"           # מי ביקש
    expires_at: Optional[datetime] = None  # מתי פג תוקף

@dataclass
class ExecutionResult:
    """תוצאת ביצוע קוד"""
    request_id: str
    status: ExecutionStatus = ExecutionStatus.PENDING
    
    # תוצאות
    stdout: str = ""                       # פלט סטנדרטי
    stderr: str = ""                       # שגיאות
    return_code: int = 0                   # קוד החזרה
    output_files: Dict[str, bytes] = field(default_factory=dict)  # קבצי פלט
    
    # מידע על ביצוע
    execution_time_seconds: float = 0.0    # זמן ביצוע
    memory_used_mb: float = 0.0            # זיכרון שנוצל
    cpu_time_seconds: float = 0.0          # זמן CPU
    
    # שגיאות ואזהרות
    errors: List[str] = field(default_factory=list)           # שגיאות
    warnings: List[str] = field(default_factory=list)         # אזהרות
    security_violations: List[str] = field(default_factory=list)  # הפרות אבטחה
    
    # מידע טכני
    process_id: Optional[int] = None       # מזהה תהליך
    container_id: Optional[str] = None     # מזהה container
    sandbox_id: Optional[str] = None       # מזהה sandbox
    
    # זמנים
    started_at: Optional[datetime] = None  # התחלת ביצוע
    completed_at: Optional[datetime] = None # סיום ביצוע
    
    # לוגים ומעקב
    execution_log: List[str] = field(default_factory=list)    # לוג ביצוע
    resource_usage: Dict[str, float] = field(default_factory=dict)  # שימוש במשאבים
    
    def add_error(self, error: str):
        """הוספת שגיאה"""
        self.errors.append(error)
        if self.status == ExecutionStatus.RUNNING:
            self.status = ExecutionStatus.ERROR
    
    def add_warning(self, warning: str):
        """הוספת אזהרה"""
        self.warnings.append(warning)
    
    def add_security_violation(self, violation: str):
        """הוספת הפרת אבטחה"""
        self.security_violations.append(violation)
        self.add_error(f"Security violation: {violation}")
    
    def mark_completed(self):
        """סימון השלמה"""
        self.status = ExecutionStatus.COMPLETED
        self.completed_at = datetime.now()
    
    def mark_failed(self, error: str = ""):
        """סימון כשל"""
        self.status = ExecutionStatus.FAILED
        self.completed_at = datetime.now()
        if error:
            self.add_error(error)
    
    def calculate_performance_score(self) -> float:
        """חישוב ציון ביצועים"""
        score = 1.0
        
        # ענישה על זמן ביצוע ארוך
        if self.execution_time_seconds > 10:
            score *= 0.8
        elif self.execution_time_seconds > 30:
            score *= 0.5
        
        # ענישה על שימוש זיכרון גבוה
        if self.memory_used_mb > 100:
            score *= 0.9
        elif self.memory_used_mb > 500:
            score *= 0.7
        
        # ענישה על שגיאות
        if self.errors:
            score *= 0.5
        
        # ענישה על הפרות אבטחה
        if self.security_violations:
            score *= 0.1
        
        return max(score, 0.0)

@dataclass
class SandboxEnvironment:
    """סביבת sandbox"""
    sandbox_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    
    # הגדרות טכניות
    container_image: str = "python:3.9-slim"  # תמונת container
    base_directory: str = "/tmp/sandbox"       # תיקיית בסיס
    network_isolated: bool = True              # בידוד רשת
    
    # משאבים
    allocated_memory_mb: int = 512             # זיכרון מוקצה
    allocated_cpu_cores: float = 0.5          # ליבות CPU מוקצות
    allocated_disk_mb: int = 100              # דיסק מוקצה
    
    # אבטחה
    security_profile: str = "restricted"       # פרופיל אבטחה
    capabilities: Set[str] = field(default_factory=set)  # יכולות
    readonly_paths: Set[str] = field(default_factory=set)  # נתיבים לקריאה בלבד
    
    # מצב
    is_active: bool = False                    # פעיל
    created_at: datetime = field(default_factory=datetime.now)
    last_used: Optional[datetime] = None       # שימוש אחרון
    usage_count: int = 0                       # מספר שימושים
    
    # מטאדטה
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ProcessInfo:
    """מידע על תהליך"""
    process_id: int
    parent_id: Optional[int] = None
    command: str = ""
    arguments: List[str] = field(default_factory=list)
    working_directory: str = ""
    
    # מצב תהליך
    status: str = "running"                    # סטטוס
    priority: int = 0                          # עדיפות
    nice_value: int = 0                        # ערך nice
    
    # שימוש במשאבים
    memory_mb: float = 0.0                     # זיכרון
    cpu_percent: float = 0.0                   # CPU באחוזים
    open_files: int = 0                        # קבצים פתוחים
    threads: int = 1                           # threads
    
    # זמנים
    start_time: datetime = field(default_factory=datetime.now)
    cpu_time_seconds: float = 0.0              # זמן CPU כולל
    
    # מידע רשת
    network_connections: List[Dict[str, Any]] = field(default_factory=list)
    
    def get_age_seconds(self) -> float:
        """קבלת גיל התהליך בשניות"""
        return (datetime.now() - self.start_time).total_seconds()
    
    def is_zombie(self) -> bool:
        """בדיקה אם התהליך zombie"""
        return self.status.lower() in ["zombie", "defunct"]
    
    def is_high_resource_usage(self) -> bool:
        """בדיקה אם התהליך צורך משאבים רבים"""
        return self.memory_mb > 500 or self.cpu_percent > 80

@dataclass
class SystemControl:
    """בקרת מערכת"""
    control_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    operation_type: str = ""                   # סוג פעולה
    target: str = ""                          # יעד הפעולה
    parameters: Dict[str, Any] = field(default_factory=dict)  # פרמטרים
    
    # הרשאות
    required_permissions: Set[str] = field(default_factory=set)  # הרשאות נדרשות
    user_confirmation: bool = True             # נדרש אישור משתמש
    
    # ביצוע
    status: ExecutionStatus = ExecutionStatus.PENDING
    result: Optional[Any] = None               # תוצאה
    error_message: Optional[str] = None        # הודעת שגיאה
    
    # זמנים
    requested_at: datetime = field(default_factory=datetime.now)
    executed_at: Optional[datetime] = None     # זמן ביצוע
    completed_at: Optional[datetime] = None    # זמן השלמה
    
    # בטיחות
    reversible: bool = False                   # הפיך
    backup_created: bool = False               # גיבוי נוצר
    rollback_data: Optional[Dict[str, Any]] = None  # נתוני rollback

class LanguageConfigFactory:
    """יצרן הגדרות שפות תכנות"""
    
    @staticmethod
    def create_python_config() -> LanguageConfig:
        """הגדרות Python"""
        return LanguageConfig(
            language=LanguageType.PYTHON,
            interpreter_path="/usr/bin/python3",
            version="3.9+",
            default_args=["-u"],  # unbuffered output
            file_extension=".py",
            supports_interactive=True,
            supports_compilation=False,
            dangerous_functions={
                "exec", "eval", "compile", "__import__", "open",
                "file", "input", "raw_input", "reload", "vars",
                "globals", "locals", "dir", "help", "exit", "quit"
            },
            safe_modules={
                "math", "random", "datetime", "json", "re",
                "collections", "itertools", "functools", "operator"
            },
            required_modules={"sys", "os"}
        )
    
    @staticmethod
    def create_javascript_config() -> LanguageConfig:
        """הגדרות JavaScript"""
        return LanguageConfig(
            language=LanguageType.JAVASCRIPT,
            interpreter_path="/usr/bin/node",
            version="16+",
            file_extension=".js",
            supports_interactive=True,
            supports_compilation=False,
            dangerous_functions={
                "eval", "Function", "setTimeout", "setInterval",
                "require", "process", "global", "globalThis"
            },
            safe_modules={
                "crypto", "util", "path", "url", "querystring"
            }
        )
    
    @staticmethod
    def create_bash_config() -> LanguageConfig:
        """הגדרות Bash"""
        return LanguageConfig(
            language=LanguageType.BASH,
            interpreter_path="/bin/bash",
            version="5.0+",
            default_args=["-e"],  # exit on error
            file_extension=".sh",
            supports_interactive=True,
            supports_compilation=False,
            dangerous_functions={
                "rm", "rmdir", "mv", "cp", "chmod", "chown",
                "su", "sudo", "passwd", "crontab", "at",
                "wget", "curl", "nc", "netcat", "ssh", "scp"
            }
        )
    
    @staticmethod
    def create_go_config() -> LanguageConfig:
        """הגדרות Go"""
        return LanguageConfig(
            language=LanguageType.GO,
            interpreter_path="/usr/local/go/bin/go",
            compiler_path="/usr/local/go/bin/go",
            version="1.19+",
            default_args=["run"],
            file_extension=".go",
            supports_interactive=False,
            supports_compilation=True,
            safe_modules={
                "fmt", "math", "strings", "time", "encoding/json"
            }
        )
    
    @staticmethod
    def create_rust_config() -> LanguageConfig:
        """הגדרות Rust"""
        return LanguageConfig(
            language=LanguageType.RUST,
            compiler_path="/usr/local/bin/rustc",
            version="1.65+",
            file_extension=".rs",
            supports_interactive=False,
            supports_compilation=True
        )

class SecurityPolicyFactory:
    """יצרן מדיניות אבטחה"""
    
    @staticmethod
    def create_minimal_policy() -> SecurityPolicy:
        """מדיניות מינימלית"""
        return SecurityPolicy(
            allow_network_access=False,
            allow_file_system_read=True,
            allow_file_system_write=False,
            allow_subprocess=False,
            allow_import_modules=True,
            allow_system_calls=False,
            allowed_modules={"math", "json", "re", "datetime"},
            sandbox_timeout_seconds=30
        )
    
    @staticmethod
    def create_safe_policy() -> SecurityPolicy:
        """מדיניות בטוחה"""
        return SecurityPolicy(
            allow_network_access=False,
            allow_file_system_read=True,
            allow_file_system_write=True,
            allow_subprocess=False,
            allow_import_modules=True,
            allow_system_calls=False,
            allowed_modules={
                "math", "json", "re", "datetime", "collections",
                "itertools", "functools", "random", "string"
            },
            blocked_modules={"os", "sys", "subprocess", "socket"},
            sandbox_timeout_seconds=60
        )
    
    @staticmethod
    def create_restricted_policy() -> SecurityPolicy:
        """מדיניות מוגבלת"""
        return SecurityPolicy(
            allow_network_access=True,
            allow_file_system_read=True,
            allow_file_system_write=True,
            allow_subprocess=True,
            allow_import_modules=True,
            allow_system_calls=False,
            allowed_hosts={"httpbin.org", "api.github.com"},
            blocked_hosts={"malware.com", "virus.net"},
            sandbox_timeout_seconds=120
        )

# פונקציות עזר
def validate_execution_request(request: ExecutionRequest) -> List[str]:
    """אימות בקשת ביצוע"""
    errors = []
    
    if not request.code.strip():
        errors.append("קוד ריק")
    
    if len(request.code) > 1000000:  # 1MB
        errors.append("קוד ארוך מדי")
    
    if request.resource_limits.max_execution_time_seconds <= 0:
        errors.append("זמן ביצוע חייב להיות חיובי")
    
    if request.resource_limits.max_memory_mb <= 0:
        errors.append("זיכרון חייב להיות חיובי")
    
    return errors

def create_default_sandbox() -> SandboxEnvironment:
    """יצירת sandbox ברירת מחדל"""
    return SandboxEnvironment(
        name="default",
        description="סביבת sandbox ברירת מחדל",
        container_image="python:3.9-alpine",
        allocated_memory_mb=256,
        allocated_cpu_cores=0.5,
        allocated_disk_mb=50,
        network_isolated=True
    )

def estimate_execution_time(code: str, language: LanguageType) -> float:
    """הערכת זמן ביצוע בשניות"""
    base_time = 1.0  # שנייה בסיס
    
    # הערכה לפי אורך קוד
    code_lines = len(code.split('\n'))
    time_per_line = 0.1
    
    # הערכה לפי שפה
    language_multipliers = {
        LanguageType.PYTHON: 1.0,
        LanguageType.JAVASCRIPT: 0.8,
        LanguageType.BASH: 0.5,
        LanguageType.GO: 1.2,
        LanguageType.RUST: 2.0,
        LanguageType.C: 1.5,
        LanguageType.CPP: 1.5,
        LanguageType.JAVA: 1.3
    }
    
    multiplier = language_multipliers.get(language, 1.0)
    estimated_time = base_time + (code_lines * time_per_line * multiplier)
    
    return min(estimated_time, 300.0)  # מקסימום 5 דקות