"""
Digital Control Advanced Module
===============================

Main module entry point for the digital control system.
Provides comprehensive code execution and system control capabilities.
"""

import asyncio
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from .core.execution_engine import ExecutionEngine
from .core.sandbox_manager import SandboxManager
from .core.security_monitor import SecurityMonitor
from .core.process_manager import ProcessManager
from .core.ollama_integration import OllamaIntegration
from .ui.control_dashboard import ControlDashboard
from .utils.logging_utils import ControlLogger

class DigitalControlAdvanced:
    """
    Advanced digital control system providing secure code execution,
    system management, and process control capabilities.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the digital control system."""
        self.config = config or {}
        self.logger = ControlLogger("DigitalControlAdvanced")
        
        # Initialize core components
        self.execution_engine = ExecutionEngine(self.config.get('execution', {}))
        self.sandbox_manager = SandboxManager(self.config.get('sandbox', {}))
        self.security_monitor = SecurityMonitor(self.config.get('security', {}))
        self.process_manager = ProcessManager(self.config.get('process', {}))
        self.ollama_integration = OllamaIntegration(self.config.get('ollama', {}))
        
        # Initialize UI
        self.dashboard = ControlDashboard(self)
        
        self.is_running = False
        self.logger.info("Digital Control Advanced system initialized")
    
    async def start(self) -> bool:
        """Start the digital control system."""
        try:
            self.logger.info("Starting Digital Control Advanced system...")
            
            # Start core components
            await self.execution_engine.start()
            await self.sandbox_manager.start()
            await self.security_monitor.start()
            await self.process_manager.start()
            await self.ollama_integration.start()
            
            self.is_running = True
            self.logger.info("Digital Control Advanced system started successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to start system: {e}")
            return False
    
    async def stop(self) -> None:
        """Stop the digital control system."""
        try:
            self.logger.info("Stopping Digital Control Advanced system...")
            
            # Stop core components
            await self.execution_engine.stop()
            await self.sandbox_manager.stop()
            await self.security_monitor.stop()
            await self.process_manager.stop()
            await self.ollama_integration.stop()
            
            self.is_running = False
            self.logger.info("Digital Control Advanced system stopped")
            
        except Exception as e:
            self.logger.error(f"Error stopping system: {e}")
    
    async def execute_code(self, 
                          code: str, 
                          language: str, 
                          sandbox: bool = True,
                          security_check: bool = True) -> Dict[str, Any]:
        """
        Execute code with security and sandboxing.
        
        Args:
            code: Code to execute
            language: Programming language
            sandbox: Whether to use sandbox
            security_check: Whether to perform security check
            
        Returns:
            Execution result dictionary
        """
        try:
            # Security analysis if requested
            if security_check:
                security_result = await self.security_monitor.analyze_code(code, language)
                if security_result['threat_level'] == 'HIGH':
                    return {
                        'success': False,
                        'error': 'Code failed security check',
                        'security_analysis': security_result
                    }
            
            # Execute in sandbox if requested
            if sandbox:
                return await self.sandbox_manager.execute_in_sandbox(code, language)
            else:
                return await self.execution_engine.execute(code, language)
                
        except Exception as e:
            self.logger.error(f"Code execution failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status."""
        return {
            'running': self.is_running,
            'execution_engine': await self.execution_engine.get_status(),
            'sandbox_manager': await self.sandbox_manager.get_status(),
            'security_monitor': await self.security_monitor.get_status(),
            'process_manager': await self.process_manager.get_status(),
            'ollama_integration': await self.ollama_integration.get_status(),
            'timestamp': datetime.now().isoformat()
        }
    
    async def get_supported_languages(self) -> List[str]:
        """Get list of supported programming languages."""
        return await self.execution_engine.get_supported_languages()
    
    async def create_sandbox(self, config: Dict[str, Any]) -> str:
        """Create a new sandbox environment."""
        return await self.sandbox_manager.create_sandbox(config)
    
    async def destroy_sandbox(self, sandbox_id: str) -> bool:
        """Destroy a sandbox environment."""
        return await self.sandbox_manager.destroy_sandbox(sandbox_id)
    
    async def monitor_process(self, process_id: int) -> Dict[str, Any]:
        """Monitor a specific process."""
        return await self.process_manager.monitor_process(process_id)
    
    async def kill_process(self, process_id: int) -> bool:
        """Kill a specific process."""
        return await self.process_manager.kill_process(process_id)
    
    async def analyze_with_ai(self, 
                             code: str, 
                             analysis_type: str = "security") -> Dict[str, Any]:
        """
        Analyze code using local AI model.
        
        Args:
            code: Code to analyze
            analysis_type: Type of analysis (security, performance, quality)
            
        Returns:
            AI analysis result
        """
        return await self.ollama_integration.analyze_code(code, analysis_type)
    
    def get_dashboard(self) -> ControlDashboard:
        """Get the control dashboard instance."""
        return self.dashboard

# Module interface functions
async def initialize_module(config: Dict[str, Any]) -> DigitalControlAdvanced:
    """Initialize the digital control advanced module."""
    module = DigitalControlAdvanced(config)
    await module.start()
    return module

async def cleanup_module(module: DigitalControlAdvanced) -> None:
    """Clean up the digital control advanced module."""
    await module.stop()

# Module metadata
MODULE_INFO = {
    "name": "digital_control_advanced",
    "version": "1.0.0",
    "description": "Advanced digital control system with secure code execution",
    "author": "Effi AI System",
    "capabilities": [
        "multi_language_execution",
        "security_sandboxing", 
        "process_management",
        "system_monitoring",
        "ai_code_analysis"
    ],
    "dependencies": [
        "asyncio",
        "docker",
        "psutil",
        "requests",
        "aiofiles"
    ]
}