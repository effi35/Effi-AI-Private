# Digital Control Advanced Module

A comprehensive digital control system providing secure code execution, system control, process management, and security sandboxing capabilities using local Hudson/Llama models.

## Features

### Core Capabilities
- **Multi-Language Code Execution**: Support for Python, JavaScript, Bash, Go, Rust, C++, Java, C#, PHP, Ruby, Perl, R, and SQL
- **Security Sandboxing**: Isolated execution environments with configurable security levels
- **Process Management**: Real-time process monitoring, control, and resource management
- **System Control**: Comprehensive system resource monitoring and control
- **AI-Powered Analysis**: Local Ollama integration for code security and quality analysis

### Security Features
- **Code Sandboxing**: Containerized execution environments with resource isolation
- **Threat Analysis**: Real-time security scanning and threat detection
- **Resource Isolation**: Memory, CPU, and network access controls
- **Access Control**: Fine-grained permission management
- **Audit Logging**: Comprehensive execution and security event logging

### Performance Features
- **Async Execution**: Non-blocking code execution and system operations
- **Resource Monitoring**: Real-time CPU, memory, and I/O monitoring
- **Process Optimization**: Intelligent resource allocation and management
- **Memory Management**: Advanced memory usage tracking and control
- **CPU Limiting**: Configurable CPU usage limits and throttling

## Directory Structure

```
digital_control_advanced/
├── __init__.py                 # Module initialization and exports
├── module.py                   # Main module entry point
├── metadata.json              # Module metadata and configuration
├── requirements.txt           # Python dependencies
├── README.md                  # This file
│
├── models/                    # Data models and type definitions
│   ├── __init__.py
│   ├── execution_types.py     # Code execution data models
│   ├── security_types.py      # Security and threat models
│   ├── system_types.py        # System resource models
│   └── sandbox_types.py       # Sandbox configuration models
│
├── core/                      # Core engines and managers
│   ├── __init__.py
│   ├── execution_engine.py    # Multi-language code execution
│   ├── sandbox_manager.py     # Container and sandbox management
│   ├── security_monitor.py    # Security analysis and monitoring
│   ├── process_manager.py     # System process management
│   ├── ollama_integration.py  # Local AI model integration
│   ├── resource_monitor.py    # System resource monitoring
│   └── language_manager.py    # Programming language support
│
├── ui/                        # User interface components
│   ├── __init__.py
│   ├── control_dashboard.py   # Main control dashboard
│   ├── execution_panel.py     # Code execution interface
│   ├── security_monitor_ui.py # Security monitoring interface
│   ├── process_viewer.py      # Process management interface
│   └── sandbox_config_ui.py   # Sandbox configuration interface
│
├── utils/                     # Utility functions and helpers
│   ├── __init__.py
│   ├── security_utils.py      # Security-related utilities
│   ├── execution_utils.py     # Code execution utilities
│   ├── system_utils.py        # System management utilities
│   ├── sandbox_utils.py       # Sandbox management utilities
│   ├── logging_utils.py       # Logging and monitoring utilities
│   └── validation_utils.py    # Input validation utilities
│
├── config/                    # Configuration templates and schemas
│   ├── __init__.py
│   ├── default_config.json    # Default module configuration
│   ├── security_policies.json # Security policy templates
│   └── language_configs.json  # Language-specific configurations
│
├── docs/                      # Documentation
│   ├── __init__.py
│   ├── api_reference.md       # API documentation
│   ├── security_guide.md      # Security configuration guide
│   ├── language_support.md    # Supported languages documentation
│   └── troubleshooting.md     # Common issues and solutions
│
├── examples/                  # Usage examples
│   ├── __init__.py
│   ├── basic_execution.py     # Basic code execution examples
│   ├── sandbox_usage.py       # Sandbox configuration examples
│   ├── security_analysis.py   # Security analysis examples
│   └── process_management.py  # Process management examples
│
├── tests/                     # Test suite
│   ├── __init__.py
│   ├── test_execution.py      # Execution engine tests
│   ├── test_sandbox.py        # Sandbox manager tests
│   ├── test_security.py       # Security monitor tests
│   ├── test_process.py        # Process manager tests
│   └── test_integration.py    # Integration tests
│
├── sandbox/                   # Sandbox environments and configurations
│   ├── __init__.py
│   ├── containers/            # Container definitions
│   ├── policies/              # Security policies
│   └── templates/             # Environment templates
│
└── security/                  # Security configurations and policies
    ├── __init__.py
    ├── threat_patterns.json   # Known threat patterns
    ├── security_rules.json    # Security validation rules
    └── audit_config.json      # Audit logging configuration
```

## Installation

1. Install system dependencies:
```bash
# Docker (required for sandboxing)
sudo apt-get install docker.io

# Programming language runtimes
sudo apt-get install nodejs golang-go rustc gcc openjdk-11-jdk

# Ollama (for AI analysis)
curl -fsSL https://ollama.ai/install.sh | sh
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Configure the module:
```bash
cp config/default_config.json config/local_config.json
# Edit config/local_config.json as needed
```

## Usage

### Basic Code Execution

```python
from digital_control_advanced import DigitalControlAdvanced

# Initialize the module
control = DigitalControlAdvanced()
await control.start()

# Execute Python code
result = await control.execute_code(
    code="print('Hello, World!')",
    language="python",
    sandbox=True,
    security_check=True
)

print(result)
```

### Sandbox Management

```python
# Create a custom sandbox
sandbox_config = {
    "isolation_level": "high",
    "memory_limit": "512MB",
    "cpu_limit": 1,
    "network_access": False
}

sandbox_id = await control.create_sandbox(sandbox_config)

# Execute code in the sandbox
result = await control.sandbox_manager.execute_in_sandbox(
    code="import os; print(os.listdir('/'))",
    language="python",
    sandbox_id=sandbox_id
)
```

### Security Analysis

```python
# Analyze code for security threats
analysis = await control.analyze_with_ai(
    code="import subprocess; subprocess.run(['rm', '-rf', '/'])",
    analysis_type="security"
)

print(f"Threat Level: {analysis['threat_level']}")
print(f"Security Issues: {analysis['issues']}")
```

### Process Management

```python
# Monitor system processes
processes = await control.process_manager.get_running_processes()

# Monitor specific process
process_info = await control.monitor_process(1234)

# Kill a process if needed
success = await control.kill_process(1234)
```

## Configuration

### Module Configuration

```json
{
  "execution": {
    "timeout": 300,
    "memory_limit": "1GB",
    "cpu_limit": 2,
    "max_concurrent": 10
  },
  "sandbox": {
    "isolation_level": "high",
    "network_access": false,
    "file_system_access": "restricted",
    "container_timeout": 600
  },
  "security": {
    "threat_detection": true,
    "code_analysis": true,
    "logging_level": "INFO",
    "max_execution_time": 300
  },
  "ollama": {
    "model": "llama2",
    "endpoint": "http://localhost:11434",
    "timeout": 30,
    "max_tokens": 2048
  }
}
```

### Security Policies

```json
{
  "high_risk_patterns": [
    "subprocess\\.run",
    "os\\.system",
    "eval\\(",
    "exec\\(",
    "rm -rf",
    "__import__"
  ],
  "blocked_imports": [
    "ctypes",
    "marshal",
    "gc"
  ],
  "resource_limits": {
    "max_memory": "1GB",
    "max_cpu_time": 300,
    "max_file_size": "100MB"
  }
}
```

## Supported Languages

- **Python**: Full support with package management
- **JavaScript/Node.js**: ES6+ support with npm packages
- **Bash**: Shell scripting with sandboxed environment
- **Go**: Compiled execution with module support
- **Rust**: Cargo-based compilation and execution
- **C++**: GCC/Clang compilation with std library
- **Java**: OpenJDK compilation and execution
- **C#**: Mono/.NET Core support
- **PHP**: CLI and web execution modes
- **Ruby**: Gem package support
- **Perl**: CPAN module support
- **R**: Statistical computing with package support
- **SQL**: Multiple database engine support

## Security Features

### Sandboxing Levels

1. **Low**: Basic process isolation
2. **Medium**: Container-based isolation with resource limits
3. **High**: Full system isolation with network restrictions
4. **Maximum**: Air-gapped execution with minimal system access

### Threat Detection

- Static code analysis for malicious patterns
- Dynamic execution monitoring
- Resource usage anomaly detection
- Network activity monitoring
- File system access control

### Audit Logging

- All code executions logged with metadata
- Security events tracked and analyzed
- Performance metrics collected
- Resource usage monitored and logged

## API Reference

### Main Module Class

```python
class DigitalControlAdvanced:
    async def start() -> bool
    async def stop() -> None
    async def execute_code(code: str, language: str, sandbox: bool = True, security_check: bool = True) -> Dict[str, Any]
    async def get_system_status() -> Dict[str, Any]
    async def get_supported_languages() -> List[str]
    async def create_sandbox(config: Dict[str, Any]) -> str
    async def destroy_sandbox(sandbox_id: str) -> bool
    async def monitor_process(process_id: int) -> Dict[str, Any]
    async def kill_process(process_id: int) -> bool
    async def analyze_with_ai(code: str, analysis_type: str = "security") -> Dict[str, Any]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite
6. Submit a pull request

## License

This module is part of the Effi AI Private system and is subject to the project's licensing terms.

## Support

For support and questions:
- Check the documentation in the `docs/` directory
- Review examples in the `examples/` directory
- Run tests to verify functionality
- Check logs for debugging information

## Version History

### 1.0.0 (Current)
- Initial release
- Multi-language code execution
- Security sandboxing
- Process management
- Ollama AI integration
- Comprehensive UI dashboard