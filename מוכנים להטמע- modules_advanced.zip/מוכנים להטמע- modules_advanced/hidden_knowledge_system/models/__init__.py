"""
Hidden Knowledge System Models Package
חבילת מודלי מערכת ידע נסתר

Advanced knowledge system for classified and restricted information.
מערכת ידע מתקדמת למידע מסווג ומוגבל.
"""

from .knowledge_types import (
    ClassifiedDocument, SecurityLevel, AccessControl,
    KnowledgeDomain, InformationCategory, DataClassification,
    RestrictedContent, ClearanceLevel, CompartmentInfo
)

from .research_types import (
    ResearchProject, ExperimentData, HypothesisTest,
    ScientificMethod, ControlledStudy, DataCollection,
    PatentData, InventionRecord, TechnologyLevel
)

from .disclosure_types import (
    DisclosureEvent, WhistleblowerReport, LeakAnalysis,
    InformationBreach, CoverUpAttempt, TransparencyScore,
    PublicInterest, NationalSecurity, EthicalImplication
)

__all__ = [
    # Knowledge types
    'ClassifiedDocument', 'SecurityLevel', 'AccessControl',
    'KnowledgeDomain', 'InformationCategory', 'DataClassification',
    'RestrictedContent', 'ClearanceLevel', 'CompartmentInfo',
    
    # Research types
    'ResearchProject', 'ExperimentData', 'HypothesisTest',
    'ScientificMethod', 'ControlledStudy', 'DataCollection',
    'PatentData', 'InventionRecord', 'TechnologyLevel',
    
    # Disclosure types
    'DisclosureEvent', 'WhistleblowerReport', 'LeakAnalysis',
    'InformationBreach', 'CoverUpAttempt', 'TransparencyScore',
    'PublicInterest', 'NationalSecurity', 'EthicalImplication'
]