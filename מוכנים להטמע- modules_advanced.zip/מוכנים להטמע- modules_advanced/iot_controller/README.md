# בקר IoT Module

בקר לניהול והפעלה אוטומטית של מכשירי IoT

## תכונות

- device_management
- sensor_monitoring
- automation_rules
- data_collection

## התקנה

```bash
pip install -r requirements.txt
```

## שימוש

```python
from iot_controller import module_instance

# הפעלת המודול
module_instance.start()

# ביצוע פעולה
result = module_instance.execute_operation("operation_name", param="value")

# עצירת המודול
module_instance.stop()
```

## תיעוד

מידע מפורט זמין בתיקיית `docs/`

## בדיקות

```bash
pytest tests/
```

## רישיון

MIT License
