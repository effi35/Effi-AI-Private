# מערכת למידה Module

מערכת למידת מכונה אדפטיבית ואימון AI

## תכונות

- model_training
- hyperparameter_tuning
- transfer_learning
- model_evaluation

## התקנה

```bash
pip install -r requirements.txt
```

## שימוש

```python
from learning_system import module_instance

# הפעלת המודול
module_instance.start()

# ביצוע פעולה
result = module_instance.execute_operation("operation_name", param="value")

# עצירת המודול
module_instance.stop()
```

## תיעוד

מידע מפורט זמין בתיקיית `docs/`

## בדיקות

```bash
pytest tests/
```

## רישיון

MIT License
