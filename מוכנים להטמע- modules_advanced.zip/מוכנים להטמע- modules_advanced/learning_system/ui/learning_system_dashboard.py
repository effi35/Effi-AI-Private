#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
מערכת למידה Dashboard - לוח בקרה מערכת למידה
"""

import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)


class LearningSystemDashboard:
    """לוח בקרה מערכת למידה"""
    
    def __init__(self, engine):
        """אתחול לוח הבקרה"""
        self.engine = engine
        self.is_active = False
    
    def start(self) -> bool:
        """הפעלת לוח הבקרה"""
        try:
            logger.info("מפעיל לוח בקרה מערכת למידה")
            self.is_active = True
            return True
        except Exception as e:
            logger.error(f"שגיאה בהפעלת לוח בקרה: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת לוח הבקרה"""
        try:
            logger.info("עוצר לוח בקרה מערכת למידה")
            self.is_active = False
            return True
        except Exception as e:
            logger.error(f"שגיאה בעצירת לוח בקרה: {e}")
            return False
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """קבלת נתוני לוח הבקרה"""
        if not self.engine:
            return {"error": "המנוע לא זמין"}
        
        return {
            "status": self.engine.get_status(),
            "recent_operations": [],
            "performance_metrics": {},
            "alerts": []
        }
    
    def render_html(self) -> str:
        """יצירת HTML ללוח הבקרה"""
        data = self.get_dashboard_data()
        
        html = f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="he">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>לוח בקרה - מערכת למידה</title>
            <style>
                body { font-family: Arial, sans-serif; direction: rtl; }
                .dashboard { padding: 20px; }
                .status-card { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; }
                .active { background-color: #d4edda; }
                .inactive { background-color: #f8d7da; }
            </style>
        </head>
        <body>
            <div class="dashboard">
                <h1>לוח בקרה - מערכת למידה</h1>
                <div class="status-card {"active" if data.get("status", {}).get("is_active") else "inactive"}">
                    <h3>סטטוס מערכת</h3>
                    <p>מצב: {"פעיל" if data.get("status", {}).get("is_active") else "לא פעיל"}</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
