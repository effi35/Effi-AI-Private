"""
Avatar Types and Core Definitions
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import uuid
from datetime import datetime

class AvatarType(Enum):
    """Types of avatars available"""
    REALISTIC = "realistic"
    CARTOON = "cartoon"
    ANIME = "anime"
    STYLIZED = "stylized"
    PROFESSIONAL = "professional"
    CASUAL = "casual"
    FANTASY = "fantasy"
    ROBOTIC = "robotic"

class AvatarGender(Enum):
    """Avatar gender options"""
    MALE = "male"
    FEMALE = "female"
    NON_BINARY = "non_binary"
    NEUTRAL = "neutral"

class AvatarPersonality(Enum):
    """Avatar personality types"""
    FRIENDLY = "friendly"
    PROFESSIONAL = "professional"
    ENERGETIC = "energetic"
    CALM = "calm"
    WISE = "wise"
    PLAYFUL = "playful"
    SERIOUS = "serious"
    CREATIVE = "creative"
    ANALYTICAL = "analytical"
    EMPATHETIC = "empathetic"
    CONFIDENT = "confident"
    HUMBLE = "humble"

class AvatarStyle(Enum):
    """Avatar visual styles"""
    MODERN = "modern"
    CLASSIC = "classic"
    FUTURISTIC = "futuristic"
    VINTAGE = "vintage"
    MINIMALIST = "minimalist"
    DETAILED = "detailed"
    ISRAELI = "israeli"
    INTERNATIONAL = "international"

class CulturalBackground(Enum):
    """Cultural backgrounds for avatars"""
    ISRAELI = "israeli"
    MIDDLE_EASTERN = "middle_eastern"
    EUROPEAN = "european"
    AMERICAN = "american"
    ASIAN = "asian"
    AFRICAN = "african"
    UNIVERSAL = "universal"

@dataclass
class PersonalityTraits:
    """Detailed personality traits"""
    openness: float = 0.5  # 0-1 scale
    conscientiousness: float = 0.5
    extraversion: float = 0.5
    agreeableness: float = 0.5
    neuroticism: float = 0.5
    
    # Cultural traits
    directness: float = 0.7  # Israeli culture tends to be more direct
    warmth: float = 0.8  # Israeli warmth and hospitality
    humor_level: float = 0.6
    formality: float = 0.3  # Generally informal culture
    
    # Communication traits
    gesture_frequency: float = 0.7  # High gesture use in Israeli culture
    eye_contact_intensity: float = 0.8
    personal_space: float = 0.4  # Closer personal space
    emotional_expressiveness: float = 0.8

    def to_dict(self) -> Dict[str, float]:
        """Convert traits to dictionary"""
        return {
            'openness': self.openness,
            'conscientiousness': self.conscientiousness,
            'extraversion': self.extraversion,
            'agreeableness': self.agreeableness,
            'neuroticism': self.neuroticism,
            'directness': self.directness,
            'warmth': self.warmth,
            'humor_level': self.humor_level,
            'formality': self.formality,
            'gesture_frequency': self.gesture_frequency,
            'eye_contact_intensity': self.eye_contact_intensity,
            'personal_space': self.personal_space,
            'emotional_expressiveness': self.emotional_expressiveness
        }

@dataclass
class AvatarMetadata:
    """Avatar metadata and information"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    version: str = "1.0.0"
    creator: str = ""
    tags: List[str] = field(default_factory=list)
    category: str = "general"
    is_active: bool = True
    usage_count: int = 0
    rating: float = 0.0
    
    # Hebrew metadata
    hebrew_name: str = ""
    hebrew_description: str = ""

@dataclass
class AvatarDefinition:
    """Complete avatar definition"""
    metadata: AvatarMetadata
    avatar_type: AvatarType
    gender: AvatarGender
    personality: AvatarPersonality
    style: AvatarStyle
    cultural_background: CulturalBackground
    personality_traits: PersonalityTraits
    
    # Physical characteristics
    age_range: tuple = (25, 35)  # Min, Max age appearance
    height: float = 170.0  # cm
    build: str = "average"  # slim, average, athletic, heavy
    
    # Special characteristics
    special_features: List[str] = field(default_factory=list)
    accessibility_features: List[str] = field(default_factory=list)
    
    # Behavior settings
    interaction_style: str = "balanced"  # formal, casual, balanced
    response_speed: float = 1.0  # Multiplier for response timing
    animation_intensity: float = 0.7  # How animated the avatar is
    
    # Cultural settings for Israeli context
    hebrew_fluency: float = 1.0  # 0-1 scale
    cultural_awareness: float = 0.8  # Understanding of Israeli culture
    religious_sensitivity: float = 0.5  # Awareness of religious contexts
    military_background: bool = False  # Israeli military service background
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert avatar definition to dictionary"""
        return {
            'metadata': {
                'id': self.metadata.id,
                'name': self.metadata.name,
                'description': self.metadata.description,
                'hebrew_name': self.metadata.hebrew_name,
                'hebrew_description': self.metadata.hebrew_description,
                'created_at': self.metadata.created_at.isoformat(),
                'updated_at': self.metadata.updated_at.isoformat(),
                'version': self.metadata.version,
                'creator': self.metadata.creator,
                'tags': self.metadata.tags,
                'category': self.metadata.category,
                'is_active': self.metadata.is_active,
                'usage_count': self.metadata.usage_count,
                'rating': self.metadata.rating
            },
            'avatar_type': self.avatar_type.value,
            'gender': self.gender.value,
            'personality': self.personality.value,
            'style': self.style.value,
            'cultural_background': self.cultural_background.value,
            'personality_traits': self.personality_traits.to_dict(),
            'age_range': self.age_range,
            'height': self.height,
            'build': self.build,
            'special_features': self.special_features,
            'accessibility_features': self.accessibility_features,
            'interaction_style': self.interaction_style,
            'response_speed': self.response_speed,
            'animation_intensity': self.animation_intensity,
            'hebrew_fluency': self.hebrew_fluency,
            'cultural_awareness': self.cultural_awareness,
            'religious_sensitivity': self.religious_sensitivity,
            'military_background': self.military_background
        }

class AvatarPresets:
    """Predefined avatar presets for quick setup"""
    
    @staticmethod
    def get_israeli_assistant() -> AvatarDefinition:
        """Professional Israeli assistant avatar"""
        metadata = AvatarMetadata(
            name="עוזר ישראלי",
            hebrew_name="עוזר ישראלי מקצועי",
            description="Professional Israeli assistant avatar",
            hebrew_description="אווטר עוזר ישראלי מקצועי עם הבנה תרבותית עמוקה",
            category="professional",
            tags=["israeli", "professional", "assistant", "hebrew"]
        )
        
        traits = PersonalityTraits(
            openness=0.7,
            conscientiousness=0.8,
            extraversion=0.6,
            agreeableness=0.8,
            neuroticism=0.2,
            directness=0.8,
            warmth=0.9,
            humor_level=0.5,
            formality=0.6
        )
        
        return AvatarDefinition(
            metadata=metadata,
            avatar_type=AvatarType.PROFESSIONAL,
            gender=AvatarGender.NEUTRAL,
            personality=AvatarPersonality.PROFESSIONAL,
            style=AvatarStyle.MODERN,
            cultural_background=CulturalBackground.ISRAELI,
            personality_traits=traits,
            hebrew_fluency=1.0,
            cultural_awareness=1.0,
            religious_sensitivity=0.8
        )
    
    @staticmethod
    def get_friendly_guide() -> AvatarDefinition:
        """Friendly Israeli guide avatar"""
        metadata = AvatarMetadata(
            name="מדריך ידידותי",
            hebrew_name="מדריך ידידותי",
            description="Friendly Israeli guide avatar",
            hebrew_description="אווטר מדריך ידידותי עם אופי חם וגישה עוזרת",
            category="guide",
            tags=["friendly", "guide", "helpful", "israeli"]
        )
        
        traits = PersonalityTraits(
            openness=0.8,
            conscientiousness=0.7,
            extraversion=0.9,
            agreeableness=0.9,
            neuroticism=0.1,
            directness=0.6,
            warmth=1.0,
            humor_level=0.8,
            formality=0.2
        )
        
        return AvatarDefinition(
            metadata=metadata,
            avatar_type=AvatarType.CASUAL,
            gender=AvatarGender.NEUTRAL,
            personality=AvatarPersonality.FRIENDLY,
            style=AvatarStyle.MODERN,
            cultural_background=CulturalBackground.ISRAELI,
            personality_traits=traits,
            hebrew_fluency=1.0,
            cultural_awareness=0.9,
            religious_sensitivity=0.6
        )
    
    @staticmethod
    def get_tech_expert() -> AvatarDefinition:
        """Technical expert avatar"""
        metadata = AvatarMetadata(
            name="מומחה טכנולוגיה",
            hebrew_name="מומחה טכנולוגיה",
            description="Technical expert avatar with Israeli high-tech background",
            hebrew_description="אווטר מומחה טכנולוגיה עם רקע היי-טק ישראלי",
            category="technical",
            tags=["tech", "expert", "analytical", "israeli", "hitech"]
        )
        
        traits = PersonalityTraits(
            openness=0.9,
            conscientiousness=0.8,
            extraversion=0.5,
            agreeableness=0.6,
            neuroticism=0.3,
            directness=0.9,
            warmth=0.6,
            humor_level=0.4,
            formality=0.4
        )
        
        return AvatarDefinition(
            metadata=metadata,
            avatar_type=AvatarType.PROFESSIONAL,
            gender=AvatarGender.NEUTRAL,
            personality=AvatarPersonality.ANALYTICAL,
            style=AvatarStyle.FUTURISTIC,
            cultural_background=CulturalBackground.ISRAELI,
            personality_traits=traits,
            hebrew_fluency=1.0,
            cultural_awareness=0.8,
            religious_sensitivity=0.4
        )
    
    @staticmethod
    def get_creative_artist() -> AvatarDefinition:
        """Creative artist avatar"""
        metadata = AvatarMetadata(
            name="אמן יוצר",
            hebrew_name="אמן יוצר",
            description="Creative artist avatar with artistic flair",
            hebrew_description="אווטר אמן יוצר עם כשרון אמנותי וחשיבה יצירתית",
            category="creative",
            tags=["creative", "artist", "imaginative", "expressive"]
        )
        
        traits = PersonalityTraits(
            openness=1.0,
            conscientiousness=0.6,
            extraversion=0.7,
            agreeableness=0.8,
            neuroticism=0.4,
            directness=0.5,
            warmth=0.8,
            humor_level=0.9,
            formality=0.1
        )
        
        return AvatarDefinition(
            metadata=metadata,
            avatar_type=AvatarType.STYLIZED,
            gender=AvatarGender.NEUTRAL,
            personality=AvatarPersonality.CREATIVE,
            style=AvatarStyle.DETAILED,
            cultural_background=CulturalBackground.ISRAELI,
            personality_traits=traits,
            hebrew_fluency=1.0,
            cultural_awareness=0.7,
            religious_sensitivity=0.5
        )
    
    @staticmethod
    def get_wise_teacher() -> AvatarDefinition:
        """Wise teacher avatar"""
        metadata = AvatarMetadata(
            name="מורה חכם",
            hebrew_name="מורה חכם",
            description="Wise teacher avatar with deep knowledge",
            hebrew_description="אווטר מורה חכם עם ידע עמוק וסבלנות רבה",
            category="education",
            tags=["wise", "teacher", "patient", "knowledgeable"]
        )
        
        traits = PersonalityTraits(
            openness=0.8,
            conscientiousness=0.9,
            extraversion=0.6,
            agreeableness=0.9,
            neuroticism=0.1,
            directness=0.6,
            warmth=0.8,
            humor_level=0.6,
            formality=0.7
        )
        
        return AvatarDefinition(
            metadata=metadata,
            avatar_type=AvatarType.PROFESSIONAL,
            gender=AvatarGender.NEUTRAL,
            personality=AvatarPersonality.WISE,
            style=AvatarStyle.CLASSIC,
            cultural_background=CulturalBackground.ISRAELI,
            personality_traits=traits,
            age_range=(45, 65),
            hebrew_fluency=1.0,
            cultural_awareness=1.0,
            religious_sensitivity=0.9
        )
    
    @staticmethod
    def get_all_presets() -> Dict[str, AvatarDefinition]:
        """Get all available presets"""
        return {
            'israeli_assistant': AvatarPresets.get_israeli_assistant(),
            'friendly_guide': AvatarPresets.get_friendly_guide(),
            'tech_expert': AvatarPresets.get_tech_expert(),
            'creative_artist': AvatarPresets.get_creative_artist(),
            'wise_teacher': AvatarPresets.get_wise_teacher()
        }
    
    @staticmethod
    def get_preset_names() -> List[str]:
        """Get list of preset names"""
        return [
            'israeli_assistant',
            'friendly_guide', 
            'tech_expert',
            'creative_artist',
            'wise_teacher'
        ]
    
    @staticmethod
    def get_preset_descriptions() -> Dict[str, str]:
        """Get preset descriptions in Hebrew"""
        return {
            'israeli_assistant': 'עוזר ישראלי מקצועי עם הבנה תרבותית עמוקה',
            'friendly_guide': 'מדריך ידידותי עם אופי חם וגישה עוזרת',
            'tech_expert': 'מומחה טכנולוגיה עם רקע היי-טק ישראלי',
            'creative_artist': 'אמן יוצר עם כשרון אמנותי וחשיבה יצירתית',
            'wise_teacher': 'מורה חכם עם ידע עמוק וסבלנות רבה'
        }