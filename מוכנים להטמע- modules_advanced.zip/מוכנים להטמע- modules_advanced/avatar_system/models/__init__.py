"""
Avatar System - Models Package
Data structures and configurations for avatar system
"""

from .avatar_types import AvatarType, AvatarGender, AvatarPersonality, AvatarStyle
from .appearance import AvatarAppearance, FacialFeatures, BodyType, ClothingStyle
from .animations import AnimationType, AnimationState, EmotionAnimation, GestureAnimation
from .voice import VoiceProfile, VoiceSettings, SpeechPattern, LanguageSettings
from .config import AvatarConfig, RenderingConfig, InteractionConfig

__all__ = [
    'AvatarType',
    'AvatarGender', 
    'AvatarPersonality',
    'AvatarStyle',
    'AvatarAppearance',
    'FacialFeatures',
    'BodyType',
    'ClothingStyle',
    'AnimationType',
    'AnimationState',
    'EmotionAnimation',
    'GestureAnimation',
    'VoiceProfile',
    'VoiceSettings',
    'SpeechPattern',
    'LanguageSettings',
    'AvatarConfig',
    'RenderingConfig',
    'InteractionConfig'
]