"""
Avatar Appearance and Visual Characteristics
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
import colorsys

class SkinTone(Enum):
    """Skin tone options"""
    VERY_LIGHT = "very_light"
    LIGHT = "light"
    LIGHT_MEDIUM = "light_medium"
    MEDIUM = "medium"
    MEDIUM_DARK = "medium_dark"
    DARK = "dark"
    VERY_DARK = "very_dark"

class HairColor(Enum):
    """Hair color options"""
    BLACK = "black"
    DARK_BROWN = "dark_brown"
    BROWN = "brown"
    LIGHT_BROWN = "light_brown"
    DIRTY_BLONDE = "dirty_blonde"
    BLONDE = "blonde"
    LIGHT_BLONDE = "light_blonde"
    RED = "red"
    AUBURN = "auburn"
    GRAY = "gray"
    WHITE = "white"
    BLUE = "blue"
    GREEN = "green"
    PURPLE = "purple"
    PINK = "pink"

class HairStyle(Enum):
    """Hair style options"""
    SHORT = "short"
    MEDIUM = "medium"
    LONG = "long"
    CURLY = "curly"
    WAVY = "wavy"
    STRAIGHT = "straight"
    BRAIDED = "braided"
    PONYTAIL = "ponytail"
    BUN = "bun"
    PIXIE = "pixie"
    BOB = "bob"
    BUZZ_CUT = "buzz_cut"
    BALD = "bald"
    AFRO = "afro"
    DREADLOCKS = "dreadlocks"

class EyeColor(Enum):
    """Eye color options"""
    BROWN = "brown"
    DARK_BROWN = "dark_brown"
    HAZEL = "hazel"
    GREEN = "green"
    BLUE = "blue"
    GRAY = "gray"
    AMBER = "amber"
    VIOLET = "violet"

class BodyType(Enum):
    """Body type options"""
    SLIM = "slim"
    ATHLETIC = "athletic"
    AVERAGE = "average"
    CURVY = "curvy"
    HEAVY = "heavy"
    MUSCULAR = "muscular"

class ClothingStyle(Enum):
    """Clothing style options"""
    CASUAL = "casual"
    BUSINESS = "business"
    FORMAL = "formal"
    TRENDY = "trendy"
    VINTAGE = "vintage"
    SPORTY = "sporty"
    BOHEMIAN = "bohemian"
    MINIMALIST = "minimalist"
    ISRAELI_CASUAL = "israeli_casual"
    TECH_CASUAL = "tech_casual"

@dataclass
class ColorRGB:
    """RGB color representation"""
    r: int = 0  # 0-255
    g: int = 0  # 0-255
    b: int = 0  # 0-255
    
    def to_hex(self) -> str:
        """Convert to hex color"""
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"
    
    def to_dict(self) -> Dict[str, int]:
        """Convert to dictionary"""
        return {'r': self.r, 'g': self.g, 'b': self.b}
    
    @classmethod
    def from_hex(cls, hex_color: str) -> 'ColorRGB':
        """Create from hex color"""
        hex_color = hex_color.lstrip('#')
        return cls(
            r=int(hex_color[0:2], 16),
            g=int(hex_color[2:4], 16),
            b=int(hex_color[4:6], 16)
        )

@dataclass
class FacialFeatures:
    """Detailed facial features"""
    # Face shape
    face_shape: str = "oval"  # oval, round, square, heart, diamond
    face_width: float = 0.5  # 0-1 scale
    face_length: float = 0.5
    jawline_definition: float = 0.5
    cheekbone_prominence: float = 0.5
    
    # Eyes
    eye_color: EyeColor = EyeColor.BROWN
    eye_shape: str = "almond"  # almond, round, hooded, monolid
    eye_size: float = 0.5  # 0-1 scale
    eye_spacing: float = 0.5
    eyebrow_thickness: float = 0.5
    eyebrow_arch: float = 0.5
    eyelash_length: float = 0.5
    
    # Nose
    nose_size: float = 0.5  # 0-1 scale
    nose_width: float = 0.5
    nose_bridge_height: float = 0.5
    nose_tip_shape: str = "rounded"  # rounded, pointed, bulbous
    
    # Mouth
    lip_thickness: float = 0.5  # 0-1 scale
    lip_width: float = 0.5
    mouth_corner_angle: float = 0.5  # affects natural expression
    teeth_visibility: float = 0.3
    
    # Other features
    forehead_height: float = 0.5
    chin_prominence: float = 0.5
    dimples: bool = False
    freckles: float = 0.0  # 0-1 intensity
    beauty_marks: List[Tuple[float, float]] = field(default_factory=list)
    
    # Cultural/ethnic features
    ethnic_features: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'face_shape': self.face_shape,
            'face_width': self.face_width,
            'face_length': self.face_length,
            'jawline_definition': self.jawline_definition,
            'cheekbone_prominence': self.cheekbone_prominence,
            'eye_color': self.eye_color.value,
            'eye_shape': self.eye_shape,
            'eye_size': self.eye_size,
            'eye_spacing': self.eye_spacing,
            'eyebrow_thickness': self.eyebrow_thickness,
            'eyebrow_arch': self.eyebrow_arch,
            'eyelash_length': self.eyelash_length,
            'nose_size': self.nose_size,
            'nose_width': self.nose_width,
            'nose_bridge_height': self.nose_bridge_height,
            'nose_tip_shape': self.nose_tip_shape,
            'lip_thickness': self.lip_thickness,
            'lip_width': self.lip_width,
            'mouth_corner_angle': self.mouth_corner_angle,
            'teeth_visibility': self.teeth_visibility,
            'forehead_height': self.forehead_height,
            'chin_prominence': self.chin_prominence,
            'dimples': self.dimples,
            'freckles': self.freckles,
            'beauty_marks': self.beauty_marks,
            'ethnic_features': self.ethnic_features
        }

@dataclass
class HairConfiguration:
    """Hair configuration"""
    color: HairColor = HairColor.BROWN
    style: HairStyle = HairStyle.MEDIUM
    length: float = 0.5  # 0-1 scale
    thickness: float = 0.5
    curliness: float = 0.5  # 0=straight, 1=very curly
    shine: float = 0.5
    
    # Advanced properties
    highlights: Optional[HairColor] = None
    gradient: bool = False
    texture: str = "normal"  # fine, normal, coarse
    volume: float = 0.5
    
    # Cultural styles
    cultural_style: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'color': self.color.value,
            'style': self.style.value,
            'length': self.length,
            'thickness': self.thickness,
            'curliness': self.curliness,
            'shine': self.shine,
            'highlights': self.highlights.value if self.highlights else None,
            'gradient': self.gradient,
            'texture': self.texture,
            'volume': self.volume,
            'cultural_style': self.cultural_style
        }

@dataclass
class ClothingConfiguration:
    """Clothing configuration"""
    style: ClothingStyle = ClothingStyle.CASUAL
    primary_color: ColorRGB = field(default_factory=lambda: ColorRGB(100, 100, 100))
    secondary_color: Optional[ColorRGB] = None
    accent_color: Optional[ColorRGB] = None
    
    # Clothing items
    top_type: str = "shirt"  # shirt, blouse, t-shirt, sweater, jacket
    bottom_type: str = "pants"  # pants, skirt, shorts, dress
    shoes_type: str = "casual"  # casual, formal, sneakers, boots
    accessories: List[str] = field(default_factory=list)
    
    # Style properties
    formality: float = 0.5  # 0-1 scale
    trendiness: float = 0.5
    comfort_level: float = 0.7
    weather_appropriate: str = "temperate"
    
    # Cultural elements
    cultural_elements: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'style': self.style.value,
            'primary_color': self.primary_color.to_dict(),
            'secondary_color': self.secondary_color.to_dict() if self.secondary_color else None,
            'accent_color': self.accent_color.to_dict() if self.accent_color else None,
            'top_type': self.top_type,
            'bottom_type': self.bottom_type,
            'shoes_type': self.shoes_type,
            'accessories': self.accessories,
            'formality': self.formality,
            'trendiness': self.trendiness,
            'comfort_level': self.comfort_level,
            'weather_appropriate': self.weather_appropriate,
            'cultural_elements': self.cultural_elements
        }

@dataclass
class AvatarAppearance:
    """Complete avatar appearance configuration"""
    # Basic physical attributes
    skin_tone: SkinTone = SkinTone.MEDIUM
    height: float = 170.0  # cm
    body_type: BodyType = BodyType.AVERAGE
    age_appearance: int = 30
    
    # Detailed features
    facial_features: FacialFeatures = field(default_factory=FacialFeatures)
    hair: HairConfiguration = field(default_factory=HairConfiguration)
    clothing: ClothingConfiguration = field(default_factory=ClothingConfiguration)
    
    # Style and presentation
    makeup_intensity: float = 0.3  # 0-1 scale
    jewelry: List[str] = field(default_factory=list)
    tattoos: List[Dict[str, Any]] = field(default_factory=list)
    piercings: List[str] = field(default_factory=list)
    
    # Posture and bearing
    posture_confidence: float = 0.7  # 0-1 scale
    posture_openness: float = 0.6
    default_expression: str = "neutral_pleasant"
    
    # Quality and rendering
    detail_level: str = "medium"  # low, medium, high, ultra
    art_style: str = "realistic"  # realistic, stylized, cartoon
    
    # Cultural adaptations
    modesty_level: float = 0.5  # Cultural/religious modesty
    regional_features: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert appearance to dictionary"""
        return {
            'skin_tone': self.skin_tone.value,
            'height': self.height,
            'body_type': self.body_type.value,
            'age_appearance': self.age_appearance,
            'facial_features': self.facial_features.to_dict(),
            'hair': self.hair.to_dict(),
            'clothing': self.clothing.to_dict(),
            'makeup_intensity': self.makeup_intensity,
            'jewelry': self.jewelry,
            'tattoos': self.tattoos,
            'piercings': self.piercings,
            'posture_confidence': self.posture_confidence,
            'posture_openness': self.posture_openness,
            'default_expression': self.default_expression,
            'detail_level': self.detail_level,
            'art_style': self.art_style,
            'modesty_level': self.modesty_level,
            'regional_features': self.regional_features
        }

class AppearancePresets:
    """Predefined appearance presets"""
    
    @staticmethod
    def get_professional_israeli() -> AvatarAppearance:
        """Professional Israeli appearance"""
        facial_features = FacialFeatures(
            face_shape="oval",
            eye_color=EyeColor.BROWN,
            eye_shape="almond",
            eyebrow_thickness=0.6,
            nose_size=0.5,
            lip_thickness=0.5,
            ethnic_features=["mediterranean"]
        )
        
        hair = HairConfiguration(
            color=HairColor.DARK_BROWN,
            style=HairStyle.MEDIUM,
            length=0.6,
            thickness=0.7,
            curliness=0.3
        )
        
        clothing = ClothingConfiguration(
            style=ClothingStyle.BUSINESS,
            primary_color=ColorRGB(50, 50, 100),  # Navy blue
            secondary_color=ColorRGB(255, 255, 255),  # White
            top_type="button_shirt",
            bottom_type="pants",
            formality=0.8,
            comfort_level=0.7
        )
        
        return AvatarAppearance(
            skin_tone=SkinTone.LIGHT_MEDIUM,
            height=172.0,
            body_type=BodyType.AVERAGE,
            age_appearance=32,
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            makeup_intensity=0.4,
            posture_confidence=0.8,
            posture_openness=0.7,
            default_expression="confident_friendly",
            modesty_level=0.6,
            regional_features=["middle_eastern"]
        )
    
    @staticmethod
    def get_casual_friendly() -> AvatarAppearance:
        """Casual friendly appearance"""
        facial_features = FacialFeatures(
            face_shape="round",
            eye_color=EyeColor.HAZEL,
            eye_shape="round",
            eyebrow_thickness=0.5,
            mouth_corner_angle=0.7,  # Natural smile
            dimples=True
        )
        
        hair = HairConfiguration(
            color=HairColor.BROWN,
            style=HairStyle.WAVY,
            length=0.7,
            curliness=0.6,
            volume=0.6
        )
        
        clothing = ClothingConfiguration(
            style=ClothingStyle.ISRAELI_CASUAL,
            primary_color=ColorRGB(70, 130, 180),  # Steel blue
            secondary_color=ColorRGB(255, 255, 255),
            top_type="casual_shirt",
            bottom_type="jeans",
            accessories=["casual_watch"],
            formality=0.3,
            comfort_level=0.9
        )
        
        return AvatarAppearance(
            skin_tone=SkinTone.MEDIUM,
            height=168.0,
            body_type=BodyType.AVERAGE,
            age_appearance=28,
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            makeup_intensity=0.2,
            posture_confidence=0.7,
            posture_openness=0.9,
            default_expression="warm_smile",
            modesty_level=0.4
        )
    
    @staticmethod
    def get_tech_expert() -> AvatarAppearance:
        """Tech expert appearance"""
        facial_features = FacialFeatures(
            face_shape="square",
            eye_color=EyeColor.BLUE,
            eye_shape="almond",
            eyebrow_thickness=0.4,
            nose_bridge_height=0.6,
            lip_thickness=0.4
        )
        
        hair = HairConfiguration(
            color=HairColor.DARK_BROWN,
            style=HairStyle.SHORT,
            length=0.3,
            texture="fine"
        )
        
        clothing = ClothingConfiguration(
            style=ClothingStyle.TECH_CASUAL,
            primary_color=ColorRGB(60, 60, 60),  # Charcoal
            secondary_color=ColorRGB(100, 100, 100),
            top_type="polo_shirt",
            bottom_type="chinos",
            accessories=["smart_watch", "glasses"],
            formality=0.5,
            trendiness=0.7
        )
        
        return AvatarAppearance(
            skin_tone=SkinTone.LIGHT,
            height=175.0,
            body_type=BodyType.SLIM,
            age_appearance=31,
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            makeup_intensity=0.0,
            jewelry=["wedding_ring"],
            posture_confidence=0.8,
            posture_openness=0.5,
            default_expression="thoughtful",
            art_style="realistic"
        )
    
    @staticmethod
    def get_creative_artist() -> AvatarAppearance:
        """Creative artist appearance"""
        facial_features = FacialFeatures(
            face_shape="heart",
            eye_color=EyeColor.GREEN,
            eye_shape="wide",
            eyebrow_thickness=0.7,
            eyebrow_arch=0.8,
            lip_thickness=0.6,
            beauty_marks=[(0.3, 0.6)]  # Beauty mark near mouth
        )
        
        hair = HairConfiguration(
            color=HairColor.AUBURN,
            style=HairStyle.LONG,
            length=0.8,
            curliness=0.7,
            volume=0.8,
            highlights=HairColor.LIGHT_BROWN
        )
        
        clothing = ClothingConfiguration(
            style=ClothingStyle.BOHEMIAN,
            primary_color=ColorRGB(139, 69, 19),  # Saddle brown
            secondary_color=ColorRGB(255, 215, 0),  # Gold
            accent_color=ColorRGB(128, 0, 128),  # Purple
            top_type="artistic_blouse",
            bottom_type="flowing_skirt",
            accessories=["artistic_jewelry", "scarf"],
            formality=0.2,
            trendiness=0.8,
            cultural_elements=["artistic_patterns"]
        )
        
        return AvatarAppearance(
            skin_tone=SkinTone.LIGHT_MEDIUM,
            height=165.0,
            body_type=BodyType.SLIM,
            age_appearance=26,
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            makeup_intensity=0.7,
            jewelry=["artistic_earrings", "rings"],
            posture_confidence=0.7,
            posture_openness=0.8,
            default_expression="inspired",
            art_style="stylized"
        )
    
    @staticmethod
    def get_wise_teacher() -> AvatarAppearance:
        """Wise teacher appearance"""
        facial_features = FacialFeatures(
            face_shape="oval",
            eye_color=EyeColor.BROWN,
            eye_spacing=0.6,
            eyebrow_thickness=0.5,
            forehead_height=0.6,
            mouth_corner_angle=0.6,
            ethnic_features=["wise_lines", "laugh_lines"]
        )
        
        hair = HairConfiguration(
            color=HairColor.GRAY,
            style=HairStyle.SHORT,
            length=0.4,
            thickness=0.5,
            texture="normal"
        )
        
        clothing = ClothingConfiguration(
            style=ClothingStyle.BUSINESS,
            primary_color=ColorRGB(101, 67, 33),  # Brown
            secondary_color=ColorRGB(245, 245, 220),  # Beige
            top_type="cardigan",
            bottom_type="dress_pants",
            accessories=["reading_glasses"],
            formality=0.7,
            comfort_level=0.8
        )
        
        return AvatarAppearance(
            skin_tone=SkinTone.MEDIUM,
            height=170.0,
            body_type=BodyType.AVERAGE,
            age_appearance=52,
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            makeup_intensity=0.1,
            jewelry=["watch"],
            posture_confidence=0.9,
            posture_openness=0.7,
            default_expression="kind_knowing",
            modesty_level=0.8
        )
    
    @staticmethod
    def get_all_presets() -> Dict[str, AvatarAppearance]:
        """Get all appearance presets"""
        return {
            'professional_israeli': AppearancePresets.get_professional_israeli(),
            'casual_friendly': AppearancePresets.get_casual_friendly(),
            'tech_expert': AppearancePresets.get_tech_expert(),
            'creative_artist': AppearancePresets.get_creative_artist(),
            'wise_teacher': AppearancePresets.get_wise_teacher()
        }

class AppearanceGenerator:
    """Generate randomized appearances"""
    
    @staticmethod
    def generate_random_israeli_appearance() -> AvatarAppearance:
        """Generate random Israeli-appropriate appearance"""
        import random
        
        # Common Israeli features
        skin_tones = [SkinTone.LIGHT_MEDIUM, SkinTone.MEDIUM, SkinTone.LIGHT]
        eye_colors = [EyeColor.BROWN, EyeColor.HAZEL, EyeColor.GREEN, EyeColor.BLUE]
        hair_colors = [HairColor.DARK_BROWN, HairColor.BROWN, HairColor.BLACK, HairColor.LIGHT_BROWN]
        
        facial_features = FacialFeatures(
            face_shape=random.choice(["oval", "round", "square"]),
            eye_color=random.choice(eye_colors),
            eyebrow_thickness=random.uniform(0.4, 0.7),
            nose_size=random.uniform(0.4, 0.6),
            ethnic_features=["mediterranean"]
        )
        
        hair = HairConfiguration(
            color=random.choice(hair_colors),
            style=random.choice(list(HairStyle)),
            curliness=random.uniform(0.2, 0.8),
            thickness=random.uniform(0.5, 0.8)
        )
        
        clothing = ClothingConfiguration(
            style=random.choice([ClothingStyle.CASUAL, ClothingStyle.ISRAELI_CASUAL, ClothingStyle.BUSINESS]),
            primary_color=ColorRGB(
                random.randint(50, 200),
                random.randint(50, 200),
                random.randint(50, 200)
            ),
            formality=random.uniform(0.3, 0.8)
        )
        
        return AvatarAppearance(
            skin_tone=random.choice(skin_tones),
            height=random.uniform(160, 180),
            body_type=random.choice(list(BodyType)),
            age_appearance=random.randint(22, 50),
            facial_features=facial_features,
            hair=hair,
            clothing=clothing,
            posture_confidence=random.uniform(0.6, 0.9),
            regional_features=["middle_eastern"]
        )