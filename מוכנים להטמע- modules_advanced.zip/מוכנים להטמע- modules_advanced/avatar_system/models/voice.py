"""
Avatar Voice and Speech Configuration
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
import re

class VoiceGender(Enum):
    """Voice gender options"""
    MALE = "male"
    FEMALE = "female"
    NON_BINARY = "non_binary"
    NEUTRAL = "neutral"

class VoiceAge(Enum):
    """Voice age categories"""
    CHILD = "child"
    YOUNG_ADULT = "young_adult"
    ADULT = "adult"
    MIDDLE_AGED = "middle_aged"
    ELDERLY = "elderly"

class VoiceAccent(Enum):
    """Voice accent options"""
    ISRAELI_HEBREW = "israeli_hebrew"
    AMERICAN_ENGLISH = "american_english"
    BRITISH_ENGLISH = "british_english"
    NEUTRAL_HEBREW = "neutral_hebrew"
    ASHKENAZI_HEBREW = "ashkenazi_hebrew"
    SEPHARDIC_HEBREW = "sephardic_hebrew"
    RUSSIAN_ACCENT = "russian_accent"
    ETHIOPIAN_ACCENT = "ethiopian_accent"
    FRENCH_ACCENT = "french_accent"
    ARABIC_ACCENT = "arabic_accent"

class SpeechStyle(Enum):
    """Speech style options"""
    FORMAL = "formal"
    CASUAL = "casual"
    FRIENDLY = "friendly"
    PROFESSIONAL = "professional"
    ENERGETIC = "energetic"
    CALM = "calm"
    AUTHORITATIVE = "authoritative"
    WARM = "warm"
    ENTHUSIASTIC = "enthusiastic"
    SERIOUS = "serious"

class EmotionalTone(Enum):
    """Emotional tone in speech"""
    NEUTRAL = "neutral"
    HAPPY = "happy"
    SAD = "sad"
    EXCITED = "excited"
    ANGRY = "angry"
    WORRIED = "worried"
    CONFIDENT = "confident"
    UNCERTAIN = "uncertain"
    SURPRISED = "surprised"
    DISAPPOINTED = "disappointed"

@dataclass
class HebrewPhonetics:
    """Hebrew phonetic configuration"""
    # Hebrew-specific pronunciation features
    emphasis_on_stressed_syllables: float = 1.2  # Emphasis multiplier
    guttural_strength: float = 0.8  # Strength of guttural sounds (ח, ע, ר)
    final_letter_pronunciation: Dict[str, str] = field(default_factory=lambda: {
        'ך': 'strong_k',
        'ם': 'strong_m', 
        'ן': 'strong_n',
        'ף': 'strong_f',
        'ץ': 'strong_ts'
    })
    
    # Vowel pronunciation
    kamatz_as_o: bool = True  # Sephardic vs Ashkenazi pronunciation
    segol_pronunciation: str = "eh"  # "eh" or "ay"
    
    # Modern Hebrew features
    foreign_word_adaptation: bool = True  # Adapt foreign words to Hebrew phonetics
    english_loanword_handling: str = "moderate"  # strict, moderate, lenient
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'emphasis_on_stressed_syllables': self.emphasis_on_stressed_syllables,
            'guttural_strength': self.guttural_strength,
            'final_letter_pronunciation': self.final_letter_pronunciation,
            'kamatz_as_o': self.kamatz_as_o,
            'segol_pronunciation': self.segol_pronunciation,
            'foreign_word_adaptation': self.foreign_word_adaptation,
            'english_loanword_handling': self.english_loanword_handling
        }

@dataclass
class SpeechPattern:
    """Speech pattern configuration"""
    # Rhythm and timing
    speaking_rate: float = 1.0  # 0.5-2.0 multiplier
    pause_frequency: float = 0.7  # How often to pause
    pause_duration_multiplier: float = 1.0
    sentence_end_lengthening: float = 1.2  # Lengthen last syllable
    
    # Intonation patterns
    question_intonation_rise: float = 0.8  # How much pitch rises in questions
    statement_intonation_fall: float = 0.6  # How much pitch falls in statements
    emphasis_pitch_change: float = 1.4  # Pitch change for emphasis
    
    # Cultural speech patterns
    israeli_directness: float = 0.8  # Direct communication style
    interruption_tolerance: float = 0.7  # Comfort with interruptions
    overlap_speaking: float = 0.6  # Tendency to speak over others
    gesture_coordination: float = 0.8  # Speech-gesture coordination
    
    # Emotional expressiveness
    emotional_pitch_variance: float = 1.2  # Pitch range for emotions
    emotional_volume_variance: float = 1.1  # Volume range for emotions
    emotional_rate_variance: float = 1.3  # Speed changes for emotions
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'speaking_rate': self.speaking_rate,
            'pause_frequency': self.pause_frequency,
            'pause_duration_multiplier': self.pause_duration_multiplier,
            'sentence_end_lengthening': self.sentence_end_lengthening,
            'question_intonation_rise': self.question_intonation_rise,
            'statement_intonation_fall': self.statement_intonation_fall,
            'emphasis_pitch_change': self.emphasis_pitch_change,
            'israeli_directness': self.israeli_directness,
            'interruption_tolerance': self.interruption_tolerance,
            'overlap_speaking': self.overlap_speaking,
            'gesture_coordination': self.gesture_coordination,
            'emotional_pitch_variance': self.emotional_pitch_variance,
            'emotional_volume_variance': self.emotional_volume_variance,
            'emotional_rate_variance': self.emotional_rate_variance
        }

@dataclass
class LanguageSettings:
    """Language-specific settings"""
    primary_language: str = "hebrew"
    secondary_language: Optional[str] = "english"
    
    # Hebrew settings
    hebrew_phonetics: HebrewPhonetics = field(default_factory=HebrewPhonetics)
    hebrew_fluency: float = 1.0  # 0-1 scale
    biblical_hebrew_influence: float = 0.1  # Ancient pronunciation influence
    modern_slang_usage: float = 0.6  # Modern Hebrew slang
    
    # English settings
    english_fluency: float = 0.8
    english_accent_strength: float = 0.3  # How strong the Hebrew accent is in English
    
    # Code-switching (mixing languages)
    code_switching_frequency: float = 0.4  # How often to mix languages
    technical_terms_in_english: bool = True  # Use English for tech terms
    emotional_expressions_in_hebrew: bool = True  # Express emotions in Hebrew
    
    # Regional variations
    regional_dialect: str = "central_israel"  # central_israel, north, south, jerusalem
    socioeconomic_markers: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'primary_language': self.primary_language,
            'secondary_language': self.secondary_language,
            'hebrew_phonetics': self.hebrew_phonetics.to_dict(),
            'hebrew_fluency': self.hebrew_fluency,
            'biblical_hebrew_influence': self.biblical_hebrew_influence,
            'modern_slang_usage': self.modern_slang_usage,
            'english_fluency': self.english_fluency,
            'english_accent_strength': self.english_accent_strength,
            'code_switching_frequency': self.code_switching_frequency,
            'technical_terms_in_english': self.technical_terms_in_english,
            'emotional_expressions_in_hebrew': self.emotional_expressions_in_hebrew,
            'regional_dialect': self.regional_dialect,
            'socioeconomic_markers': self.socioeconomic_markers
        }

@dataclass
class VoiceSettings:
    """Technical voice settings"""
    # Basic voice parameters
    pitch: float = 1.0  # 0.5-2.0 multiplier
    volume: float = 0.8  # 0-1 scale
    speed: float = 1.0  # 0.5-2.0 multiplier
    
    # Voice quality
    breathiness: float = 0.2  # 0-1 scale
    roughness: float = 0.1  # 0-1 scale
    resonance: float = 0.7  # 0-1 scale
    articulation_precision: float = 0.8  # 0-1 scale
    
    # Dynamic range
    pitch_range: Tuple[float, float] = (0.8, 1.2)  # Min, max pitch multipliers
    volume_range: Tuple[float, float] = (0.6, 1.0)  # Min, max volume
    
    # Environmental adaptation
    background_noise_adaptation: bool = True
    distance_volume_scaling: bool = True
    room_acoustics_simulation: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'pitch': self.pitch,
            'volume': self.volume,
            'speed': self.speed,
            'breathiness': self.breathiness,
            'roughness': self.roughness,
            'resonance': self.resonance,
            'articulation_precision': self.articulation_precision,
            'pitch_range': self.pitch_range,
            'volume_range': self.volume_range,
            'background_noise_adaptation': self.background_noise_adaptation,
            'distance_volume_scaling': self.distance_volume_scaling,
            'room_acoustics_simulation': self.room_acoustics_simulation
        }

@dataclass
class VoiceProfile:
    """Complete voice profile"""
    # Identity
    name: str = "Hebrew Voice"
    description: str = "Israeli Hebrew voice profile"
    
    # Basic characteristics
    gender: VoiceGender = VoiceGender.NEUTRAL
    age: VoiceAge = VoiceAge.ADULT
    accent: VoiceAccent = VoiceAccent.ISRAELI_HEBREW
    
    # Style and personality
    speech_style: SpeechStyle = SpeechStyle.FRIENDLY
    default_emotional_tone: EmotionalTone = EmotionalTone.NEUTRAL
    personality_in_voice: float = 0.7  # How much personality shows in voice
    
    # Technical configuration
    voice_settings: VoiceSettings = field(default_factory=VoiceSettings)
    speech_patterns: SpeechPattern = field(default_factory=SpeechPattern)
    language_settings: LanguageSettings = field(default_factory=LanguageSettings)
    
    # Context adaptation
    formal_context_adjustments: Dict[str, float] = field(default_factory=lambda: {
        'pitch': 0.95,
        'speed': 0.9,
        'volume': 0.85,
        'directness': 0.6
    })
    
    casual_context_adjustments: Dict[str, float] = field(default_factory=lambda: {
        'pitch': 1.05,
        'speed': 1.1,
        'volume': 0.9,
        'directness': 0.9
    })
    
    # Cultural elements
    cultural_expressions: List[str] = field(default_factory=lambda: [
        "אוקיי",  # OK
        "בסדר",  # OK/Fine
        "יאללה",  # Come on/Let's go
        "סבבה",  # Cool/Great
        "רגע",   # Wait a moment
        "נו",    # So?/Come on
        "איזה יופי",  # How nice
        "בלגן",  # Mess
        "חבל על הזמן"  # Waste of time
    ])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert voice profile to dictionary"""
        return {
            'name': self.name,
            'description': self.description,
            'gender': self.gender.value,
            'age': self.age.value,
            'accent': self.accent.value,
            'speech_style': self.speech_style.value,
            'default_emotional_tone': self.default_emotional_tone.value,
            'personality_in_voice': self.personality_in_voice,
            'voice_settings': self.voice_settings.to_dict(),
            'speech_patterns': self.speech_patterns.to_dict(),
            'language_settings': self.language_settings.to_dict(),
            'formal_context_adjustments': self.formal_context_adjustments,
            'casual_context_adjustments': self.casual_context_adjustments,
            'cultural_expressions': self.cultural_expressions
        }

class VoicePresets:
    """Predefined voice presets"""
    
    @staticmethod
    def get_professional_israeli() -> VoiceProfile:
        """Professional Israeli voice"""
        voice_settings = VoiceSettings(
            pitch=1.0,
            volume=0.8,
            speed=0.95,
            articulation_precision=0.9,
            resonance=0.8
        )
        
        speech_patterns = SpeechPattern(
            speaking_rate=0.9,
            pause_frequency=0.8,
            israeli_directness=0.7,
            emotional_expressiveness=0.6
        )
        
        language_settings = LanguageSettings(
            hebrew_fluency=1.0,
            english_fluency=0.9,
            code_switching_frequency=0.3,
            modern_slang_usage=0.4
        )
        
        return VoiceProfile(
            name="מקצועי ישראלי",
            description="קול מקצועי ישראלי לעסקים ופגישות רשמיות",
            gender=VoiceGender.NEUTRAL,
            age=VoiceAge.ADULT,
            accent=VoiceAccent.ISRAELI_HEBREW,
            speech_style=SpeechStyle.PROFESSIONAL,
            voice_settings=voice_settings,
            speech_patterns=speech_patterns,
            language_settings=language_settings
        )
    
    @staticmethod
    def get_friendly_guide() -> VoiceProfile:
        """Friendly guide voice"""
        voice_settings = VoiceSettings(
            pitch=1.1,
            volume=0.85,
            speed=1.0,
            articulation_precision=0.8,
            resonance=0.75
        )
        
        speech_patterns = SpeechPattern(
            speaking_rate=1.0,
            pause_frequency=0.6,
            israeli_directness=0.6,
            emotional_expressiveness=0.9,
            gesture_coordination=0.9
        )
        
        language_settings = LanguageSettings(
            hebrew_fluency=1.0,
            english_fluency=0.7,
            code_switching_frequency=0.4,
            modern_slang_usage=0.7
        )
        
        return VoiceProfile(
            name="מדריך ידידותי",
            description="קול חם וידידותי למדריך ועוזר אישי",
            gender=VoiceGender.NEUTRAL,
            age=VoiceAge.YOUNG_ADULT,
            accent=VoiceAccent.ISRAELI_HEBREW,
            speech_style=SpeechStyle.FRIENDLY,
            default_emotional_tone=EmotionalTone.HAPPY,
            voice_settings=voice_settings,
            speech_patterns=speech_patterns,
            language_settings=language_settings
        )
    
    @staticmethod
    def get_tech_expert() -> VoiceProfile:
        """Tech expert voice"""
        voice_settings = VoiceSettings(
            pitch=0.95,
            volume=0.75,
            speed=1.1,
            articulation_precision=0.95,
            resonance=0.7
        )
        
        speech_patterns = SpeechPattern(
            speaking_rate=1.1,
            pause_frequency=0.9,
            israeli_directness=0.9,
            emotional_expressiveness=0.5
        )
        
        language_settings = LanguageSettings(
            hebrew_fluency=1.0,
            english_fluency=0.95,
            code_switching_frequency=0.6,
            technical_terms_in_english=True,
            modern_slang_usage=0.3
        )
        
        return VoiceProfile(
            name="מומחה טכנולוגיה",
            description="קול מדויק וטכני למומחה היי-טק",
            gender=VoiceGender.NEUTRAL,
            age=VoiceAge.ADULT,
            accent=VoiceAccent.ISRAELI_HEBREW,
            speech_style=SpeechStyle.PROFESSIONAL,
            voice_settings=voice_settings,
            speech_patterns=speech_patterns,
            language_settings=language_settings
        )
    
    @staticmethod
    def get_wise_teacher() -> VoiceProfile:
        """Wise teacher voice"""
        voice_settings = VoiceSettings(
            pitch=0.9,
            volume=0.8,
            speed=0.85,
            articulation_precision=0.95,
            resonance=0.85
        )
        
        speech_patterns = SpeechPattern(
            speaking_rate=0.85,
            pause_frequency=1.2,
            sentence_end_lengthening=1.4,
            israeli_directness=0.5,
            emotional_expressiveness=0.7
        )
        
        language_settings = LanguageSettings(
            hebrew_fluency=1.0,
            english_fluency=0.8,
            biblical_hebrew_influence=0.3,
            modern_slang_usage=0.2,
            code_switching_frequency=0.2
        )
        
        return VoiceProfile(
            name="מורה חכם",
            description="קול חכם ומנוסה למורה ויועץ",
            gender=VoiceGender.NEUTRAL,
            age=VoiceAge.MIDDLE_AGED,
            accent=VoiceAccent.ISRAELI_HEBREW,
            speech_style=SpeechStyle.CALM,
            voice_settings=voice_settings,
            speech_patterns=speech_patterns,
            language_settings=language_settings
        )
    
    @staticmethod
    def get_energetic_youth() -> VoiceProfile:
        """Energetic youth voice"""
        voice_settings = VoiceSettings(
            pitch=1.2,
            volume=0.9,
            speed=1.2,
            articulation_precision=0.7,
            resonance=0.7
        )
        
        speech_patterns = SpeechPattern(
            speaking_rate=1.2,
            pause_frequency=0.5,
            israeli_directness=0.9,
            emotional_expressiveness=1.2,
            overlap_speaking=0.8
        )
        
        language_settings = LanguageSettings(
            hebrew_fluency=1.0,
            english_fluency=0.8,
            code_switching_frequency=0.7,
            modern_slang_usage=0.9
        )
        
        return VoiceProfile(
            name="צעיר אנרגטי",
            description="קול צעיר ואנרגטי מלא חיים",
            gender=VoiceGender.NEUTRAL,
            age=VoiceAge.YOUNG_ADULT,
            accent=VoiceAccent.ISRAELI_HEBREW,
            speech_style=SpeechStyle.ENERGETIC,
            default_emotional_tone=EmotionalTone.EXCITED,
            voice_settings=voice_settings,
            speech_patterns=speech_patterns,
            language_settings=language_settings
        )
    
    @staticmethod
    def get_all_presets() -> Dict[str, VoiceProfile]:
        """Get all voice presets"""
        return {
            'professional_israeli': VoicePresets.get_professional_israeli(),
            'friendly_guide': VoicePresets.get_friendly_guide(),
            'tech_expert': VoicePresets.get_tech_expert(),
            'wise_teacher': VoicePresets.get_wise_teacher(),
            'energetic_youth': VoicePresets.get_energetic_youth()
        }

class SpeechProcessor:
    """Process text for speech synthesis"""
    
    def __init__(self, voice_profile: VoiceProfile):
        self.voice_profile = voice_profile
        self.hebrew_patterns = self._load_hebrew_patterns()
    
    def _load_hebrew_patterns(self) -> Dict[str, str]:
        """Load Hebrew pronunciation patterns"""
        return {
            # Stress patterns
            'ultimate_stress': r'.*[אהחעםןףךץ]$',  # Words ending with these letters
            'penultimate_stress': r'.*[^אהחעםןףךץ][אהחעםןףךץ]$',
            
            # Phonetic patterns
            'silent_aleph': r'^א[בגדהוזחטיכלמנסעפצקרשת]',
            'dagesh_forte': r'[בגדכפת]{2}',
            'shva_na': r'[בגדהוזחטיכלמנסעפצקרשת]ְ[בגדהוזחטיכלמנסעפצקרשת]',
            
            # Modern Hebrew adaptations
            'foreign_sounds': r'[וג׳]|[צ׳]|[ז׳]',
            'english_loanwords': r'\b[A-Za-z]+\b'
        }
    
    def process_text_for_speech(self, text: str) -> Dict[str, Any]:
        """Process text and return speech instructions"""
        # Clean and prepare text
        cleaned_text = self._clean_text(text)
        
        # Analyze Hebrew vs other languages
        language_segments = self._segment_by_language(cleaned_text)
        
        # Generate pronunciation guide
        pronunciation_guide = self._generate_pronunciation_guide(language_segments)
        
        # Apply voice profile settings
        speech_instructions = self._apply_voice_settings(pronunciation_guide)
        
        return {
            'original_text': text,
            'cleaned_text': cleaned_text,
            'language_segments': language_segments,
            'pronunciation_guide': pronunciation_guide,
            'speech_instructions': speech_instructions,
            'estimated_duration': self._estimate_duration(cleaned_text)
        }
    
    def _clean_text(self, text: str) -> str:
        """Clean text for processing"""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Handle Hebrew punctuation
        text = re.sub(r'([א-ת])([.!?])', r'\1 \2', text)
        
        # Normalize quotes
        text = text.replace('"', '"').replace('"', '"')
        text = text.replace(''', "'").replace(''', "'")
        
        return text
    
    def _segment_by_language(self, text: str) -> List[Dict[str, Any]]:
        """Segment text by language"""
        segments = []
        current_segment = ""
        current_language = None
        
        words = text.split()
        
        for word in words:
            word_language = self._detect_word_language(word)
            
            if current_language is None:
                current_language = word_language
                current_segment = word
            elif current_language == word_language:
                current_segment += " " + word
            else:
                # Language changed, save current segment
                if current_segment.strip():
                    segments.append({
                        'text': current_segment.strip(),
                        'language': current_language,
                        'word_count': len(current_segment.split())
                    })
                
                current_segment = word
                current_language = word_language
        
        # Add final segment
        if current_segment.strip():
            segments.append({
                'text': current_segment.strip(),
                'language': current_language,
                'word_count': len(current_segment.split())
            })
        
        return segments
    
    def _detect_word_language(self, word: str) -> str:
        """Detect language of a word"""
        # Hebrew detection
        if re.search(r'[א-ת]', word):
            return 'hebrew'
        
        # English detection
        if re.search(r'[a-zA-Z]', word):
            return 'english'
        
        # Numbers and punctuation
        if re.search(r'^[0-9\.,\!\?\-\(\)]+$', word):
            return 'neutral'
        
        return 'unknown'
    
    def _generate_pronunciation_guide(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate pronunciation guide for segments"""
        guide = []
        
        for segment in segments:
            if segment['language'] == 'hebrew':
                guide.append(self._process_hebrew_segment(segment))
            elif segment['language'] == 'english':
                guide.append(self._process_english_segment(segment))
            else:
                guide.append(self._process_neutral_segment(segment))
        
        return guide
    
    def _process_hebrew_segment(self, segment: Dict[str, Any]) -> Dict[str, Any]:
        """Process Hebrew text segment"""
        text = segment['text']
        
        # Apply Hebrew phonetic rules
        phonetics = self.voice_profile.language_settings.hebrew_phonetics
        
        processed_segment = {
            'text': text,
            'language': 'hebrew',
            'phonetic_adjustments': {
                'guttural_emphasis': phonetics.guttural_strength,
                'stress_pattern': self._analyze_hebrew_stress(text),
                'final_letters': self._handle_final_letters(text),
                'vowel_pronunciation': self._handle_hebrew_vowels(text)
            },
            'cultural_expressions': self._identify_cultural_expressions(text),
            'speech_rate_modifier': 1.0,
            'pitch_pattern': self._generate_hebrew_pitch_pattern(text)
        }
        
        return processed_segment
    
    def _process_english_segment(self, segment: Dict[str, Any]) -> Dict[str, Any]:
        """Process English text segment"""
        text = segment['text']
        
        # Apply Hebrew accent to English
        accent_strength = self.voice_profile.language_settings.english_accent_strength
        
        processed_segment = {
            'text': text,
            'language': 'english',
            'accent_adjustments': {
                'r_pronunciation': 'uvular' if accent_strength > 0.5 else 'standard',
                'th_substitution': accent_strength > 0.7,
                'vowel_shifts': self._calculate_vowel_shifts(accent_strength),
                'consonant_emphasis': accent_strength * 0.8
            },
            'speech_rate_modifier': 0.95,  # Slightly slower for accented English
            'pitch_pattern': self._generate_english_pitch_pattern(text, accent_strength)
        }
        
        return processed_segment
    
    def _process_neutral_segment(self, segment: Dict[str, Any]) -> Dict[str, Any]:
        """Process neutral text (numbers, punctuation)"""
        return {
            'text': segment['text'],
            'language': 'neutral',
            'speech_rate_modifier': 1.0,
            'special_handling': self._identify_special_elements(segment['text'])
        }
    
    def _analyze_hebrew_stress(self, text: str) -> Dict[str, Any]:
        """Analyze Hebrew stress patterns"""
        words = text.split()
        stress_pattern = []
        
        for word in words:
            if re.search(self.hebrew_patterns['ultimate_stress'], word):
                stress_pattern.append('ultimate')
            elif re.search(self.hebrew_patterns['penultimate_stress'], word):
                stress_pattern.append('penultimate')
            else:
                stress_pattern.append('default')
        
        return {
            'pattern': stress_pattern,
            'emphasis_multiplier': self.voice_profile.language_settings.hebrew_phonetics.emphasis_on_stressed_syllables
        }
    
    def _handle_final_letters(self, text: str) -> Dict[str, str]:
        """Handle Hebrew final letter pronunciation"""
        phonetics = self.voice_profile.language_settings.hebrew_phonetics
        final_letters = {}
        
        for final_letter, pronunciation in phonetics.final_letter_pronunciation.items():
            if final_letter in text:
                final_letters[final_letter] = pronunciation
        
        return final_letters
    
    def _handle_hebrew_vowels(self, text: str) -> Dict[str, Any]:
        """Handle Hebrew vowel pronunciation"""
        phonetics = self.voice_profile.language_settings.hebrew_phonetics
        
        return {
            'kamatz_as_o': phonetics.kamatz_as_o,
            'segol_style': phonetics.segol_pronunciation,
            'modern_adaptations': phonetics.foreign_word_adaptation
        }
    
    def _identify_cultural_expressions(self, text: str) -> List[str]:
        """Identify cultural expressions in text"""
        expressions = []
        cultural_list = self.voice_profile.cultural_expressions
        
        for expression in cultural_list:
            if expression in text:
                expressions.append(expression)
        
        return expressions
    
    def _generate_hebrew_pitch_pattern(self, text: str) -> List[float]:
        """Generate pitch pattern for Hebrew text"""
        patterns = self.voice_profile.speech_patterns
        words = text.split()
        pitch_pattern = []
        
        for i, word in enumerate(words):
            base_pitch = 1.0
            
            # Question pattern
            if '?' in word or word.endswith('?'):
                base_pitch *= patterns.question_intonation_rise
            
            # Statement ending
            elif i == len(words) - 1 and word.endswith('.'):
                base_pitch *= patterns.statement_intonation_fall
            
            # Emphasis detection (all caps, exclamation)
            if word.isupper() or '!' in word:
                base_pitch *= patterns.emphasis_pitch_change
            
            pitch_pattern.append(base_pitch)
        
        return pitch_pattern
    
    def _generate_english_pitch_pattern(self, text: str, accent_strength: float) -> List[float]:
        """Generate pitch pattern for English text with Hebrew accent"""
        # Hebrew speakers tend to have different intonation patterns in English
        base_pattern = self._generate_hebrew_pitch_pattern(text)
        
        # Modify for Hebrew accent influence
        modified_pattern = []
        for pitch in base_pattern:
            # Hebrew speakers often use less pitch variation in English
            variation_reduction = accent_strength * 0.3
            modified_pitch = pitch * (1 - variation_reduction)
            modified_pattern.append(modified_pitch)
        
        return modified_pattern
    
    def _calculate_vowel_shifts(self, accent_strength: float) -> Dict[str, str]:
        """Calculate vowel shifts for Hebrew accent in English"""
        if accent_strength < 0.3:
            return {}
        
        shifts = {}
        
        if accent_strength > 0.5:
            shifts.update({
                'æ': 'ɛ',  # cat -> cet
                'ʌ': 'a',  # cup -> cap
                'ɪ': 'i'   # bit -> beat
            })
        
        if accent_strength > 0.7:
            shifts.update({
                'θ': 's',  # think -> sink
                'ð': 'z',  # this -> zis
                'w': 'v'   # water -> vater
            })
        
        return shifts
    
    def _identify_special_elements(self, text: str) -> Dict[str, Any]:
        """Identify special elements in neutral text"""
        special = {}
        
        # Numbers
        if re.search(r'\d', text):
            special['has_numbers'] = True
            special['number_style'] = 'hebrew' if self.voice_profile.language_settings.primary_language == 'hebrew' else 'english'
        
        # Punctuation that affects speech
        if '...' in text:
            special['ellipsis'] = True
        
        if '!' in text:
            special['exclamation'] = True
        
        if '?' in text:
            special['question'] = True
        
        return special
    
    def _apply_voice_settings(self, pronunciation_guide: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Apply voice profile settings to pronunciation guide"""
        settings = self.voice_profile.voice_settings
        patterns = self.voice_profile.speech_patterns
        
        instructions = {
            'global_settings': {
                'base_pitch': settings.pitch,
                'base_volume': settings.volume,
                'base_speed': settings.speed * patterns.speaking_rate,
                'breathiness': settings.breathiness,
                'resonance': settings.resonance
            },
            'segment_instructions': [],
            'timing_instructions': {
                'pause_frequency': patterns.pause_frequency,
                'pause_duration': patterns.pause_duration_multiplier,
                'sentence_end_lengthening': patterns.sentence_end_lengthening
            }
        }
        
        for segment in pronunciation_guide:
            segment_instruction = {
                'segment_data': segment,
                'pitch_multiplier': 1.0,
                'speed_multiplier': segment.get('speech_rate_modifier', 1.0),
                'volume_multiplier': 1.0,
                'special_processing': []
            }
            
            # Apply language-specific adjustments
            if segment['language'] == 'hebrew':
                segment_instruction['special_processing'].append('hebrew_phonetics')
                if segment.get('cultural_expressions'):
                    segment_instruction['special_processing'].append('cultural_emphasis')
            
            elif segment['language'] == 'english':
                segment_instruction['special_processing'].append('hebrew_accent')
                segment_instruction['speed_multiplier'] *= 0.95
            
            instructions['segment_instructions'].append(segment_instruction)
        
        return instructions
    
    def _estimate_duration(self, text: str) -> float:
        """Estimate speech duration in seconds"""
        # Basic estimation: average speaking rate is about 150 words per minute
        word_count = len(text.split())
        base_rate = 150  # words per minute
        
        # Adjust for voice settings
        speed_multiplier = self.voice_profile.voice_settings.speed * self.voice_profile.speech_patterns.speaking_rate
        adjusted_rate = base_rate * speed_multiplier
        
        # Convert to seconds
        duration = (word_count / adjusted_rate) * 60
        
        # Add pause time
        pause_time = word_count * self.voice_profile.speech_patterns.pause_frequency * 0.3
        
        return duration + pause_time