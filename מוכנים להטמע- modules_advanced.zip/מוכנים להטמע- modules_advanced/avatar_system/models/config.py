"""
Avatar System Configuration Models
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
import json

class RenderingQuality(Enum):
    """Rendering quality levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    ULTRA = "ultra"
    ADAPTIVE = "adaptive"

class InteractionMode(Enum):
    """Avatar interaction modes"""
    PASSIVE = "passive"  # Avatar only responds
    ACTIVE = "active"    # Avatar can initiate interactions
    PROACTIVE = "proactive"  # Avatar anticipates needs
    AUTONOMOUS = "autonomous"  # Avatar acts independently

class CulturalAdaptation(Enum):
    """Cultural adaptation levels"""
    MINIMAL = "minimal"
    MODERATE = "moderate"
    FULL = "full"
    DYNAMIC = "dynamic"

class PrivacyLevel(Enum):
    """Privacy protection levels"""
    PUBLIC = "public"
    PRIVATE = "private"
    CONFIDENTIAL = "confidential"
    ANONYMOUS = "anonymous"

@dataclass
class RenderingConfig:
    """Rendering configuration settings"""
    # Quality settings
    quality: RenderingQuality = RenderingQuality.MEDIUM
    target_fps: int = 30
    resolution: tuple = (1920, 1080)
    anti_aliasing: bool = True
    
    # Performance settings
    max_polygons: int = 50000
    texture_quality: str = "medium"  # low, medium, high, ultra
    shadow_quality: str = "medium"
    lighting_quality: str = "medium"
    
    # Optimization settings
    level_of_detail: bool = True
    frustum_culling: bool = True
    occlusion_culling: bool = False
    dynamic_batching: bool = True
    
    # Mobile/web optimizations
    mobile_optimized: bool = False
    web_optimized: bool = True
    compress_textures: bool = True
    reduce_geometry: bool = False
    
    # Real-time adjustments
    adaptive_quality: bool = True
    min_fps_threshold: int = 20
    quality_adjustment_rate: float = 0.1
    
    # Platform-specific settings
    platform_overrides: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'quality': self.quality.value,
            'target_fps': self.target_fps,
            'resolution': self.resolution,
            'anti_aliasing': self.anti_aliasing,
            'max_polygons': self.max_polygons,
            'texture_quality': self.texture_quality,
            'shadow_quality': self.shadow_quality,
            'lighting_quality': self.lighting_quality,
            'level_of_detail': self.level_of_detail,
            'frustum_culling': self.frustum_culling,
            'occlusion_culling': self.occlusion_culling,
            'dynamic_batching': self.dynamic_batching,
            'mobile_optimized': self.mobile_optimized,
            'web_optimized': self.web_optimized,
            'compress_textures': self.compress_textures,
            'reduce_geometry': self.reduce_geometry,
            'adaptive_quality': self.adaptive_quality,
            'min_fps_threshold': self.min_fps_threshold,
            'quality_adjustment_rate': self.quality_adjustment_rate,
            'platform_overrides': self.platform_overrides
        }

@dataclass
class InteractionConfig:
    """Interaction behavior configuration"""
    # Interaction modes
    mode: InteractionMode = InteractionMode.ACTIVE
    responsiveness: float = 0.8  # 0-1 scale
    initiative_level: float = 0.6  # How often avatar initiates interaction
    
    # Attention and focus
    eye_contact_frequency: float = 0.8
    gaze_following: bool = True
    attention_span: float = 30.0  # seconds
    distraction_threshold: float = 0.3
    
    # Response patterns
    response_delay_min: float = 0.2  # seconds
    response_delay_max: float = 1.5
    thinking_time_visible: bool = True
    interrupt_tolerance: float = 0.7
    
    # Cultural interaction patterns
    cultural_adaptation: CulturalAdaptation = CulturalAdaptation.FULL
    personal_space_distance: float = 1.2  # meters
    gesture_frequency: float = 0.7
    directness_level: float = 0.8  # Israeli cultural directness
    
    # Conversation patterns
    conversation_memory_duration: int = 300  # seconds
    topic_switching_tolerance: float = 0.6
    humor_usage: float = 0.5
    emotional_mirroring: float = 0.7
    
    # Accessibility features
    visual_indicators: bool = True
    audio_feedback: bool = True
    gesture_alternatives: bool = True
    speed_adjustments: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'mode': self.mode.value,
            'responsiveness': self.responsiveness,
            'initiative_level': self.initiative_level,
            'eye_contact_frequency': self.eye_contact_frequency,
            'gaze_following': self.gaze_following,
            'attention_span': self.attention_span,
            'distraction_threshold': self.distraction_threshold,
            'response_delay_min': self.response_delay_min,
            'response_delay_max': self.response_delay_max,
            'thinking_time_visible': self.thinking_time_visible,
            'interrupt_tolerance': self.interrupt_tolerance,
            'cultural_adaptation': self.cultural_adaptation.value,
            'personal_space_distance': self.personal_space_distance,
            'gesture_frequency': self.gesture_frequency,
            'directness_level': self.directness_level,
            'conversation_memory_duration': self.conversation_memory_duration,
            'topic_switching_tolerance': self.topic_switching_tolerance,
            'humor_usage': self.humor_usage,
            'emotional_mirroring': self.emotional_mirroring,
            'visual_indicators': self.visual_indicators,
            'audio_feedback': self.audio_feedback,
            'gesture_alternatives': self.gesture_alternatives,
            'speed_adjustments': self.speed_adjustments
        }

@dataclass
class PrivacyConfig:
    """Privacy and security configuration"""
    # Privacy level
    privacy_level: PrivacyLevel = PrivacyLevel.PRIVATE
    
    # Data collection
    collect_interaction_data: bool = True
    anonymize_data: bool = True
    data_retention_days: int = 30
    share_analytics: bool = False
    
    # Biometric data
    facial_recognition: bool = False
    voice_recognition: bool = False
    emotion_detection: bool = True
    gesture_recognition: bool = True
    
    # Content filtering
    content_filtering: bool = True
    language_filtering: bool = True
    cultural_sensitivity: bool = True
    child_safety_mode: bool = False
    
    # Security features
    end_to_end_encryption: bool = True
    secure_authentication: bool = True
    session_timeout: int = 1800  # seconds
    multi_factor_auth: bool = False
    
    # Compliance
    gdpr_compliance: bool = True
    israeli_privacy_law_compliance: bool = True
    export_user_data: bool = True
    delete_user_data: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'privacy_level': self.privacy_level.value,
            'collect_interaction_data': self.collect_interaction_data,
            'anonymize_data': self.anonymize_data,
            'data_retention_days': self.data_retention_days,
            'share_analytics': self.share_analytics,
            'facial_recognition': self.facial_recognition,
            'voice_recognition': self.voice_recognition,
            'emotion_detection': self.emotion_detection,
            'gesture_recognition': self.gesture_recognition,
            'content_filtering': self.content_filtering,
            'language_filtering': self.language_filtering,
            'cultural_sensitivity': self.cultural_sensitivity,
            'child_safety_mode': self.child_safety_mode,
            'end_to_end_encryption': self.end_to_end_encryption,
            'secure_authentication': self.secure_authentication,
            'session_timeout': self.session_timeout,
            'multi_factor_auth': self.multi_factor_auth,
            'gdpr_compliance': self.gdpr_compliance,
            'israeli_privacy_law_compliance': self.israeli_privacy_law_compliance,
            'export_user_data': self.export_user_data,
            'delete_user_data': self.delete_user_data
        }

@dataclass
class LocalizationConfig:
    """Localization and cultural configuration"""
    # Language settings
    primary_language: str = "hebrew"
    secondary_language: str = "english"
    supported_languages: List[str] = field(default_factory=lambda: ["hebrew", "english", "arabic"])
    
    # Regional settings
    country: str = "israel"
    region: str = "middle_east"
    timezone: str = "Asia/Jerusalem"
    currency: str = "ILS"
    
    # Cultural settings
    cultural_context: str = "israeli"
    religious_sensitivity: float = 0.7  # 0-1 scale
    holiday_awareness: bool = True
    cultural_gestures: bool = True
    
    # Date and time formats
    date_format: str = "dd/mm/yyyy"
    time_format: str = "24h"
    week_start: str = "sunday"  # Israeli convention
    
    # Number and measurement formats
    number_format: str = "1,234.56"
    measurement_system: str = "metric"
    temperature_unit: str = "celsius"
    
    # Content localization
    local_references: bool = True
    local_examples: bool = True
    cultural_metaphors: bool = True
    local_humor: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'primary_language': self.primary_language,
            'secondary_language': self.secondary_language,
            'supported_languages': self.supported_languages,
            'country': self.country,
            'region': self.region,
            'timezone': self.timezone,
            'currency': self.currency,
            'cultural_context': self.cultural_context,
            'religious_sensitivity': self.religious_sensitivity,
            'holiday_awareness': self.holiday_awareness,
            'cultural_gestures': self.cultural_gestures,
            'date_format': self.date_format,
            'time_format': self.time_format,
            'week_start': self.week_start,
            'number_format': self.number_format,
            'measurement_system': self.measurement_system,
            'temperature_unit': self.temperature_unit,
            'local_references': self.local_references,
            'local_examples': self.local_examples,
            'cultural_metaphors': self.cultural_metaphors,
            'local_humor': self.local_humor
        }

@dataclass
class PerformanceConfig:
    """Performance optimization configuration"""
    # CPU settings
    max_cpu_usage: float = 0.7  # 0-1 scale
    cpu_priority: str = "normal"  # low, normal, high
    thread_count: int = 4
    
    # Memory settings
    max_memory_usage: int = 2048  # MB
    memory_cleanup_interval: int = 300  # seconds
    cache_size: int = 512  # MB
    
    # GPU settings
    gpu_acceleration: bool = True
    max_gpu_usage: float = 0.8
    gpu_memory_limit: int = 1024  # MB
    
    # Network settings
    max_bandwidth: int = 1000  # KB/s
    compression_enabled: bool = True
    caching_enabled: bool = True
    offline_mode: bool = False
    
    # Animation optimization
    animation_fps_limit: int = 60
    lod_animation: bool = True
    animation_culling: bool = True
    bone_reduction: bool = False
    
    # Background processing
    background_updates: bool = True
    idle_optimization: bool = True
    power_saving_mode: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'max_cpu_usage': self.max_cpu_usage,
            'cpu_priority': self.cpu_priority,
            'thread_count': self.thread_count,
            'max_memory_usage': self.max_memory_usage,
            'memory_cleanup_interval': self.memory_cleanup_interval,
            'cache_size': self.cache_size,
            'gpu_acceleration': self.gpu_acceleration,
            'max_gpu_usage': self.max_gpu_usage,
            'gpu_memory_limit': self.gpu_memory_limit,
            'max_bandwidth': self.max_bandwidth,
            'compression_enabled': self.compression_enabled,
            'caching_enabled': self.caching_enabled,
            'offline_mode': self.offline_mode,
            'animation_fps_limit': self.animation_fps_limit,
            'lod_animation': self.lod_animation,
            'animation_culling': self.animation_culling,
            'bone_reduction': self.bone_reduction,
            'background_updates': self.background_updates,
            'idle_optimization': self.idle_optimization,
            'power_saving_mode': self.power_saving_mode
        }

@dataclass
class AccessibilityConfig:
    """Accessibility configuration"""
    # Visual accessibility
    high_contrast: bool = False
    large_text: bool = False
    reduced_motion: bool = False
    colorblind_support: bool = True
    
    # Audio accessibility
    audio_descriptions: bool = False
    subtitles: bool = False
    sign_language: bool = False
    volume_amplification: bool = False
    
    # Motor accessibility
    gesture_alternatives: bool = True
    voice_commands: bool = True
    eye_tracking: bool = False
    switch_control: bool = False
    
    # Cognitive accessibility
    simplified_interface: bool = False
    reduced_complexity: bool = False
    memory_aids: bool = True
    reading_assistance: bool = False
    
    # Language accessibility
    easy_language: bool = False
    translation_assistance: bool = True
    pronunciation_help: bool = True
    reading_speed_control: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'high_contrast': self.high_contrast,
            'large_text': self.large_text,
            'reduced_motion': self.reduced_motion,
            'colorblind_support': self.colorblind_support,
            'audio_descriptions': self.audio_descriptions,
            'subtitles': self.subtitles,
            'sign_language': self.sign_language,
            'volume_amplification': self.volume_amplification,
            'gesture_alternatives': self.gesture_alternatives,
            'voice_commands': self.voice_commands,
            'eye_tracking': self.eye_tracking,
            'switch_control': self.switch_control,
            'simplified_interface': self.simplified_interface,
            'reduced_complexity': self.reduced_complexity,
            'memory_aids': self.memory_aids,
            'reading_assistance': self.reading_assistance,
            'easy_language': self.easy_language,
            'translation_assistance': self.translation_assistance,
            'pronunciation_help': self.pronunciation_help,
            'reading_speed_control': self.reading_speed_control
        }

@dataclass
class AvatarConfig:
    """Complete avatar system configuration"""
    # Metadata
    config_version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    config_name: str = "default_avatar_config"
    description: str = "Default avatar system configuration"
    
    # Core configurations
    rendering: RenderingConfig = field(default_factory=RenderingConfig)
    interaction: InteractionConfig = field(default_factory=InteractionConfig)
    privacy: PrivacyConfig = field(default_factory=PrivacyConfig)
    localization: LocalizationConfig = field(default_factory=LocalizationConfig)
    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    accessibility: AccessibilityConfig = field(default_factory=AccessibilityConfig)
    
    # Integration settings
    consciousness_integration: bool = True
    external_api_integration: bool = True
    plugin_support: bool = True
    
    # Development settings
    debug_mode: bool = False
    logging_level: str = "info"  # debug, info, warning, error
    analytics_enabled: bool = True
    crash_reporting: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert complete configuration to dictionary"""
        return {
            'config_version': self.config_version,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'config_name': self.config_name,
            'description': self.description,
            'rendering': self.rendering.to_dict(),
            'interaction': self.interaction.to_dict(),
            'privacy': self.privacy.to_dict(),
            'localization': self.localization.to_dict(),
            'performance': self.performance.to_dict(),
            'accessibility': self.accessibility.to_dict(),
            'consciousness_integration': self.consciousness_integration,
            'external_api_integration': self.external_api_integration,
            'plugin_support': self.plugin_support,
            'debug_mode': self.debug_mode,
            'logging_level': self.logging_level,
            'analytics_enabled': self.analytics_enabled,
            'crash_reporting': self.crash_reporting
        }
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AvatarConfig':
        """Create configuration from dictionary"""
        config = cls()
        
        # Update metadata
        if 'config_version' in data:
            config.config_version = data['config_version']
        if 'config_name' in data:
            config.config_name = data['config_name']
        if 'description' in data:
            config.description = data['description']
        
        # Update configurations
        if 'rendering' in data:
            config.rendering = RenderingConfig(**data['rendering'])
        if 'interaction' in data:
            config.interaction = InteractionConfig(**data['interaction'])
        if 'privacy' in data:
            config.privacy = PrivacyConfig(**data['privacy'])
        if 'localization' in data:
            config.localization = LocalizationConfig(**data['localization'])
        if 'performance' in data:
            config.performance = PerformanceConfig(**data['performance'])
        if 'accessibility' in data:
            config.accessibility = AccessibilityConfig(**data['accessibility'])
        
        # Update other settings
        for key in ['consciousness_integration', 'external_api_integration', 
                   'plugin_support', 'debug_mode', 'logging_level', 
                   'analytics_enabled', 'crash_reporting']:
            if key in data:
                setattr(config, key, data[key])
        
        config.updated_at = datetime.now()
        return config

class ConfigPresets:
    """Predefined configuration presets"""
    
    @staticmethod
    def get_high_performance() -> AvatarConfig:
        """High performance configuration"""
        config = AvatarConfig()
        config.config_name = "high_performance"
        config.description = "קונפיגורציה לביצועים גבוהים"
        
        # High performance rendering
        config.rendering.quality = RenderingQuality.HIGH
        config.rendering.target_fps = 60
        config.rendering.adaptive_quality = True
        
        # Responsive interaction
        config.interaction.responsiveness = 0.9
        config.interaction.response_delay_min = 0.1
        config.interaction.response_delay_max = 0.8
        
        # Optimized performance
        config.performance.max_cpu_usage = 0.8
        config.performance.gpu_acceleration = True
        config.performance.animation_fps_limit = 60
        
        return config
    
    @staticmethod
    def get_mobile_optimized() -> AvatarConfig:
        """Mobile optimized configuration"""
        config = AvatarConfig()
        config.config_name = "mobile_optimized"
        config.description = "קונפיגורציה מותאמת למובייל"
        
        # Mobile rendering
        config.rendering.quality = RenderingQuality.MEDIUM
        config.rendering.mobile_optimized = True
        config.rendering.compress_textures = True
        config.rendering.reduce_geometry = True
        
        # Conservative performance
        config.performance.max_cpu_usage = 0.5
        config.performance.max_memory_usage = 1024
        config.performance.animation_fps_limit = 30
        config.performance.power_saving_mode = True
        
        # Simplified interaction
        config.interaction.responsiveness = 0.7
        config.interaction.gesture_frequency = 0.5
        
        return config
    
    @staticmethod
    def get_accessibility_focused() -> AvatarConfig:
        """Accessibility focused configuration"""
        config = AvatarConfig()
        config.config_name = "accessibility_focused"
        config.description = "קונפיגורציה מותאמת נגישות"
        
        # Accessibility features
        config.accessibility.high_contrast = True
        config.accessibility.large_text = True
        config.accessibility.subtitles = True
        config.accessibility.gesture_alternatives = True
        config.accessibility.voice_commands = True
        config.accessibility.pronunciation_help = True
        
        # Slower, more deliberate interaction
        config.interaction.responsiveness = 0.6
        config.interaction.response_delay_min = 0.5
        config.interaction.response_delay_max = 2.0
        config.interaction.thinking_time_visible = True
        
        # Clear visual rendering
        config.rendering.quality = RenderingQuality.HIGH
        config.rendering.anti_aliasing = True
        
        return config
    
    @staticmethod
    def get_privacy_focused() -> AvatarConfig:
        """Privacy focused configuration"""
        config = AvatarConfig()
        config.config_name = "privacy_focused"
        config.description = "קונפיגורציה ממוקדת פרטיות"
        
        # Strong privacy settings
        config.privacy.privacy_level = PrivacyLevel.CONFIDENTIAL
        config.privacy.collect_interaction_data = False
        config.privacy.facial_recognition = False
        config.privacy.voice_recognition = False
        config.privacy.end_to_end_encryption = True
        config.privacy.multi_factor_auth = True
        
        # Reduced tracking
        config.analytics_enabled = False
        config.crash_reporting = False
        
        # Minimal data collection
        config.interaction.conversation_memory_duration = 60
        
        return config
    
    @staticmethod
    def get_israeli_cultural() -> AvatarConfig:
        """Israeli cultural adaptation configuration"""
        config = AvatarConfig()
        config.config_name = "israeli_cultural"
        config.description = "קונפיגורציה מותאמת תרבות ישראלית"
        
        # Full cultural adaptation
        config.interaction.cultural_adaptation = CulturalAdaptation.FULL
        config.interaction.directness_level = 0.9
        config.interaction.gesture_frequency = 0.8
        config.interaction.personal_space_distance = 1.0
        
        # Israeli localization
        config.localization.primary_language = "hebrew"
        config.localization.cultural_context = "israeli"
        config.localization.religious_sensitivity = 0.8
        config.localization.holiday_awareness = True
        config.localization.local_humor = True
        
        # Hebrew-first settings
        config.localization.week_start = "sunday"
        config.localization.date_format = "dd/mm/yyyy"
        config.localization.timezone = "Asia/Jerusalem"
        
        return config
    
    @staticmethod
    def get_all_presets() -> Dict[str, AvatarConfig]:
        """Get all configuration presets"""
        return {
            'high_performance': ConfigPresets.get_high_performance(),
            'mobile_optimized': ConfigPresets.get_mobile_optimized(),
            'accessibility_focused': ConfigPresets.get_accessibility_focused(),
            'privacy_focused': ConfigPresets.get_privacy_focused(),
            'israeli_cultural': ConfigPresets.get_israeli_cultural()
        }
    
    @staticmethod
    def get_preset_descriptions() -> Dict[str, str]:
        """Get preset descriptions in Hebrew"""
        return {
            'high_performance': 'קונפיגורציה לביצועים גבוהים ותגובה מהירה',
            'mobile_optimized': 'קונפיגורציה מותאמת למכשירים ניידים',
            'accessibility_focused': 'קונפיגורציה עם דגש על נגישות ותמיכה',
            'privacy_focused': 'קונפיגורציה עם דגש על פרטיות ואבטחה',
            'israeli_cultural': 'קונפיגורציה מותאמת לתרבות הישראלית'
        }