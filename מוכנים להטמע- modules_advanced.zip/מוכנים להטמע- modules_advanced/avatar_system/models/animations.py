"""
Avatar Animation System and Definitions
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import math

class AnimationType(Enum):
    """Types of animations available"""
    IDLE = "idle"
    GREETING = "greeting"
    TALKING = "talking"
    LISTENING = "listening"
    THINKING = "thinking"
    EXPLAINING = "explaining"
    AGREEING = "agreeing"
    DISAGREEING = "disagreeing"
    SURPRISED = "surprised"
    CONFUSED = "confused"
    HAPPY = "happy"
    SAD = "sad"
    EXCITED = "excited"
    WORRIED = "worried"
    POINTING = "pointing"
    WAVING = "waving"
    NODDING = "nodding"
    SHAKING_HEAD = "shaking_head"
    SHRUGGING = "shrugging"
    CELEBRATION = "celebration"
    FAREWELL = "farewell"

class EmotionIntensity(Enum):
    """Emotion intensity levels"""
    SUBTLE = "subtle"
    MILD = "mild"
    MODERATE = "moderate"
    STRONG = "strong"
    INTENSE = "intense"

class GestureType(Enum):
    """Types of gestures"""
    HAND_GESTURE = "hand_gesture"
    ARM_MOVEMENT = "arm_movement"
    HEAD_MOVEMENT = "head_movement"
    FACIAL_EXPRESSION = "facial_expression"
    BODY_POSTURE = "body_posture"
    EYE_MOVEMENT = "eye_movement"
    MOUTH_MOVEMENT = "mouth_movement"

class AnimationState(Enum):
    """Animation system states"""
    INACTIVE = "inactive"
    PLAYING = "playing"
    PAUSED = "paused"
    TRANSITIONING = "transitioning"
    BLENDING = "blending"
    QUEUED = "queued"

@dataclass
class AnimationKeyframe:
    """Single keyframe in animation"""
    time: float  # Time in seconds
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)  # X, Y, Z
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)  # X, Y, Z rotation
    scale: Tuple[float, float, float] = (1.0, 1.0, 1.0)  # X, Y, Z scale
    properties: Dict[str, Any] = field(default_factory=dict)  # Custom properties
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert keyframe to dictionary"""
        return {
            'time': self.time,
            'position': self.position,
            'rotation': self.rotation,
            'scale': self.scale,
            'properties': self.properties
        }

@dataclass
class AnimationTrack:
    """Animation track for specific body part or property"""
    name: str
    target: str  # Body part or property name
    keyframes: List[AnimationKeyframe] = field(default_factory=list)
    interpolation: str = "linear"  # linear, cubic, ease_in, ease_out
    loop: bool = False
    
    def add_keyframe(self, keyframe: AnimationKeyframe):
        """Add keyframe to track"""
        self.keyframes.append(keyframe)
        # Sort by time
        self.keyframes.sort(key=lambda k: k.time)
    
    def get_value_at_time(self, time: float) -> Dict[str, Any]:
        """Get interpolated value at specific time"""
        if not self.keyframes:
            return {}
        
        # Handle time before first keyframe
        if time <= self.keyframes[0].time:
            return self.keyframes[0].to_dict()
        
        # Handle time after last keyframe
        if time >= self.keyframes[-1].time:
            if self.loop:
                # Loop back to beginning
                duration = self.keyframes[-1].time
                time = time % duration
            else:
                return self.keyframes[-1].to_dict()
        
        # Find surrounding keyframes
        for i in range(len(self.keyframes) - 1):
            curr_kf = self.keyframes[i]
            next_kf = self.keyframes[i + 1]
            
            if curr_kf.time <= time <= next_kf.time:
                # Interpolate between keyframes
                t = (time - curr_kf.time) / (next_kf.time - curr_kf.time)
                return self._interpolate_keyframes(curr_kf, next_kf, t)
        
        return self.keyframes[-1].to_dict()
    
    def _interpolate_keyframes(self, kf1: AnimationKeyframe, kf2: AnimationKeyframe, t: float) -> Dict[str, Any]:
        """Interpolate between two keyframes"""
        # Apply interpolation curve
        if self.interpolation == "ease_in":
            t = t * t
        elif self.interpolation == "ease_out":
            t = 1 - (1 - t) * (1 - t)
        elif self.interpolation == "cubic":
            t = t * t * (3 - 2 * t)
        
        # Interpolate position
        pos = tuple(
            kf1.position[i] + (kf2.position[i] - kf1.position[i]) * t
            for i in range(3)
        )
        
        # Interpolate rotation
        rot = tuple(
            kf1.rotation[i] + (kf2.rotation[i] - kf1.rotation[i]) * t
            for i in range(3)
        )
        
        # Interpolate scale
        scale = tuple(
            kf1.scale[i] + (kf2.scale[i] - kf1.scale[i]) * t
            for i in range(3)
        )
        
        return {
            'time': kf1.time + (kf2.time - kf1.time) * t,
            'position': pos,
            'rotation': rot,
            'scale': scale,
            'properties': self._interpolate_properties(kf1.properties, kf2.properties, t)
        }
    
    def _interpolate_properties(self, props1: Dict[str, Any], props2: Dict[str, Any], t: float) -> Dict[str, Any]:
        """Interpolate custom properties"""
        result = {}
        all_keys = set(props1.keys()) | set(props2.keys())
        
        for key in all_keys:
            val1 = props1.get(key, 0)
            val2 = props2.get(key, 0)
            
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                result[key] = val1 + (val2 - val1) * t
            else:
                result[key] = val2 if t > 0.5 else val1
        
        return result

@dataclass
class EmotionAnimation:
    """Animation for expressing emotions"""
    emotion: str
    intensity: EmotionIntensity
    duration: float = 2.0
    tracks: List[AnimationTrack] = field(default_factory=list)
    
    # Facial expression parameters
    eyebrow_position: float = 0.0  # -1 to 1 (down to up)
    eye_openness: float = 1.0  # 0 to 1
    mouth_shape: float = 0.0  # -1 to 1 (frown to smile)
    mouth_openness: float = 0.0  # 0 to 1
    
    # Cultural expression modifiers
    cultural_modifier: float = 1.0  # Intensity modifier for cultural expression
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert emotion animation to dictionary"""
        return {
            'emotion': self.emotion,
            'intensity': self.intensity.value,
            'duration': self.duration,
            'tracks': [track.__dict__ for track in self.tracks],
            'eyebrow_position': self.eyebrow_position,
            'eye_openness': self.eye_openness,
            'mouth_shape': self.mouth_shape,
            'mouth_openness': self.mouth_openness,
            'cultural_modifier': self.cultural_modifier
        }

@dataclass
class GestureAnimation:
    """Animation for hand and body gestures"""
    gesture_type: GestureType
    name: str
    description: str
    duration: float = 1.5
    tracks: List[AnimationTrack] = field(default_factory=list)
    
    # Cultural context
    cultural_origin: str = "universal"
    cultural_meaning: str = ""
    formality_level: float = 0.5  # 0-1 scale
    
    # Usage context
    conversation_context: List[str] = field(default_factory=list)
    emotional_context: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert gesture animation to dictionary"""
        return {
            'gesture_type': self.gesture_type.value,
            'name': self.name,
            'description': self.description,
            'duration': self.duration,
            'tracks': [track.__dict__ for track in self.tracks],
            'cultural_origin': self.cultural_origin,
            'cultural_meaning': self.cultural_meaning,
            'formality_level': self.formality_level,
            'conversation_context': self.conversation_context,
            'emotional_context': self.emotional_context
        }

@dataclass
class SpeechAnimation:
    """Animation synchronized with speech"""
    phoneme: str  # Phoneme being spoken
    mouth_shape: str  # Mouth shape for phoneme
    tongue_position: float = 0.5
    lip_roundness: float = 0.5
    jaw_openness: float = 0.3
    duration: float = 0.1
    
    # Hebrew-specific phonemes
    is_hebrew_phoneme: bool = False
    hebrew_emphasis: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert speech animation to dictionary"""
        return {
            'phoneme': self.phoneme,
            'mouth_shape': self.mouth_shape,
            'tongue_position': self.tongue_position,
            'lip_roundness': self.lip_roundness,
            'jaw_openness': self.jaw_openness,
            'duration': self.duration,
            'is_hebrew_phoneme': self.is_hebrew_phoneme,
            'hebrew_emphasis': self.hebrew_emphasis
        }

class AnimationLibrary:
    """Library of predefined animations"""
    
    def __init__(self):
        self.emotion_animations = self._create_emotion_animations()
        self.gesture_animations = self._create_gesture_animations()
        self.speech_animations = self._create_speech_animations()
        self.idle_animations = self._create_idle_animations()
    
    def _create_emotion_animations(self) -> Dict[str, EmotionAnimation]:
        """Create emotion animation library"""
        animations = {}
        
        # Joy/Happiness - שמחה
        joy_track = AnimationTrack("facial_expression", "face")
        joy_track.add_keyframe(AnimationKeyframe(0.0, properties={'smile': 0.0}))
        joy_track.add_keyframe(AnimationKeyframe(0.5, properties={'smile': 0.8}))
        joy_track.add_keyframe(AnimationKeyframe(2.0, properties={'smile': 0.6}))
        
        animations['joy'] = EmotionAnimation(
            emotion="joy",
            intensity=EmotionIntensity.MODERATE,
            tracks=[joy_track],
            eyebrow_position=0.3,
            eye_openness=0.9,
            mouth_shape=0.8,
            cultural_modifier=1.2  # Israelis express joy openly
        )
        
        # Sadness - עצב
        sad_track = AnimationTrack("facial_expression", "face")
        sad_track.add_keyframe(AnimationKeyframe(0.0, properties={'sadness': 0.0}))
        sad_track.add_keyframe(AnimationKeyframe(1.0, properties={'sadness': 0.7}))
        
        animations['sadness'] = EmotionAnimation(
            emotion="sadness",
            intensity=EmotionIntensity.MODERATE,
            tracks=[sad_track],
            eyebrow_position=-0.5,
            eye_openness=0.7,
            mouth_shape=-0.4,
            cultural_modifier=0.8  # More reserved expression
        )
        
        # Surprise - הפתעה
        surprise_track = AnimationTrack("facial_expression", "face")
        surprise_track.add_keyframe(AnimationKeyframe(0.0, properties={'surprise': 0.0}))
        surprise_track.add_keyframe(AnimationKeyframe(0.2, properties={'surprise': 1.0}))
        surprise_track.add_keyframe(AnimationKeyframe(1.5, properties={'surprise': 0.3}))
        
        animations['surprise'] = EmotionAnimation(
            emotion="surprise",
            intensity=EmotionIntensity.STRONG,
            duration=1.5,
            tracks=[surprise_track],
            eyebrow_position=0.8,
            eye_openness=1.2,
            mouth_shape=0.2,
            mouth_openness=0.6
        )
        
        # Thinking - חשיבה
        thinking_track = AnimationTrack("head_movement", "head")
        thinking_track.add_keyframe(AnimationKeyframe(0.0, rotation=(0, 0, 0)))
        thinking_track.add_keyframe(AnimationKeyframe(1.0, rotation=(5, -10, 0)))
        thinking_track.add_keyframe(AnimationKeyframe(2.0, rotation=(0, 0, 0)))
        
        animations['thinking'] = EmotionAnimation(
            emotion="thinking",
            intensity=EmotionIntensity.MILD,
            tracks=[thinking_track],
            eyebrow_position=0.2,
            eye_openness=0.8
        )
        
        return animations
    
    def _create_gesture_animations(self) -> Dict[str, GestureAnimation]:
        """Create gesture animation library"""
        animations = {}
        
        # Israeli "Nu?" gesture - נו?
        nu_track = AnimationTrack("hand_gesture", "right_hand")
        nu_track.add_keyframe(AnimationKeyframe(0.0, position=(0, 0, 0), rotation=(0, 0, 0)))
        nu_track.add_keyframe(AnimationKeyframe(0.3, position=(0.2, 0.3, 0.1), rotation=(20, 30, 10)))
        nu_track.add_keyframe(AnimationKeyframe(0.8, position=(0.2, 0.3, 0.1), rotation=(20, 30, 10)))
        nu_track.add_keyframe(AnimationKeyframe(1.2, position=(0, 0, 0), rotation=(0, 0, 0)))
        
        animations['nu_gesture'] = GestureAnimation(
            gesture_type=GestureType.HAND_GESTURE,
            name="Nu Gesture",
            description="Classic Israeli questioning gesture",
            duration=1.2,
            tracks=[nu_track],
            cultural_origin="israeli",
            cultural_meaning="What? Come on! Seriously?",
            formality_level=0.2,
            conversation_context=["questioning", "impatience", "disbelief"]
        )
        
        # Pointing for emphasis
        pointing_track = AnimationTrack("hand_gesture", "right_hand")
        pointing_track.add_keyframe(AnimationKeyframe(0.0, position=(0, 0, 0)))
        pointing_track.add_keyframe(AnimationKeyframe(0.4, position=(0.4, 0.2, 0.3)))
        pointing_track.add_keyframe(AnimationKeyframe(1.0, position=(0, 0, 0)))
        
        animations['emphasis_pointing'] = GestureAnimation(
            gesture_type=GestureType.HAND_GESTURE,
            name="Emphasis Pointing",
            description="Pointing to emphasize a point",
            tracks=[pointing_track],
            cultural_origin="universal",
            formality_level=0.4,
            conversation_context=["explaining", "emphasizing"]
        )
        
        # Waving greeting
        wave_track = AnimationTrack("hand_gesture", "right_hand")
        wave_track.add_keyframe(AnimationKeyframe(0.0, rotation=(0, 0, 0)))
        wave_track.add_keyframe(AnimationKeyframe(0.3, rotation=(0, 0, 30)))
        wave_track.add_keyframe(AnimationKeyframe(0.6, rotation=(0, 0, -30)))
        wave_track.add_keyframe(AnimationKeyframe(0.9, rotation=(0, 0, 30)))
        wave_track.add_keyframe(AnimationKeyframe(1.2, rotation=(0, 0, 0)))
        
        animations['friendly_wave'] = GestureAnimation(
            gesture_type=GestureType.HAND_GESTURE,
            name="Friendly Wave",
            description="Friendly greeting wave",
            tracks=[wave_track],
            cultural_origin="universal",
            formality_level=0.3,
            conversation_context=["greeting", "farewell"]
        )
        
        # Shrugging - characteristic Israeli gesture
        shrug_track = AnimationTrack("shoulder_movement", "shoulders")
        shrug_track.add_keyframe(AnimationKeyframe(0.0, position=(0, 0, 0)))
        shrug_track.add_keyframe(AnimationKeyframe(0.4, position=(0, 0.1, 0)))
        shrug_track.add_keyframe(AnimationKeyframe(1.0, position=(0, 0, 0)))
        
        animations['israeli_shrug'] = GestureAnimation(
            gesture_type=GestureType.BODY_POSTURE,
            name="Israeli Shrug",
            description="Expressive shoulder shrug",
            tracks=[shrug_track],
            cultural_origin="israeli",
            cultural_meaning="I don't know / What can you do?",
            formality_level=0.2,
            conversation_context=["uncertainty", "resignation", "indifference"]
        )
        
        return animations
    
    def _create_speech_animations(self) -> Dict[str, SpeechAnimation]:
        """Create speech animation library"""
        animations = {}
        
        # Common English phonemes
        animations['a'] = SpeechAnimation('a', 'open', jaw_openness=0.8, lip_roundness=0.2)
        animations['e'] = SpeechAnimation('e', 'spread', jaw_openness=0.4, lip_roundness=0.1)
        animations['i'] = SpeechAnimation('i', 'smile', jaw_openness=0.2, lip_roundness=0.0)
        animations['o'] = SpeechAnimation('o', 'round', jaw_openness=0.6, lip_roundness=0.8)
        animations['u'] = SpeechAnimation('u', 'pucker', jaw_openness=0.3, lip_roundness=1.0)
        
        # Hebrew-specific phonemes
        animations['ח'] = SpeechAnimation('ח', 'fricative', 
                                        jaw_openness=0.4, 
                                        tongue_position=0.8,
                                        is_hebrew_phoneme=True,
                                        hebrew_emphasis=1.2)
        
        animations['ר'] = SpeechAnimation('ר', 'trill',
                                        jaw_openness=0.5,
                                        tongue_position=0.7,
                                        is_hebrew_phoneme=True,
                                        hebrew_emphasis=1.1)
        
        animations['ע'] = SpeechAnimation('ע', 'pharyngeal',
                                        jaw_openness=0.6,
                                        tongue_position=0.9,
                                        is_hebrew_phoneme=True,
                                        hebrew_emphasis=1.3)
        
        return animations
    
    def _create_idle_animations(self) -> Dict[str, List[AnimationTrack]]:
        """Create idle animation patterns"""
        animations = {}
        
        # Breathing animation
        breathing_track = AnimationTrack("breathing", "chest")
        breathing_track.loop = True
        breathing_track.add_keyframe(AnimationKeyframe(0.0, scale=(1.0, 1.0, 1.0)))
        breathing_track.add_keyframe(AnimationKeyframe(2.0, scale=(1.02, 1.02, 1.0)))
        breathing_track.add_keyframe(AnimationKeyframe(4.0, scale=(1.0, 1.0, 1.0)))
        
        # Subtle head movement
        head_track = AnimationTrack("subtle_movement", "head")
        head_track.loop = True
        head_track.add_keyframe(AnimationKeyframe(0.0, rotation=(0, 0, 0)))
        head_track.add_keyframe(AnimationKeyframe(8.0, rotation=(2, 1, 0)))
        head_track.add_keyframe(AnimationKeyframe(16.0, rotation=(0, -1, 0)))
        head_track.add_keyframe(AnimationKeyframe(24.0, rotation=(0, 0, 0)))
        
        # Blinking
        blink_track = AnimationTrack("blinking", "eyes")
        blink_track.loop = True
        blink_track.add_keyframe(AnimationKeyframe(0.0, properties={'eye_openness': 1.0}))
        blink_track.add_keyframe(AnimationKeyframe(0.1, properties={'eye_openness': 0.0}))
        blink_track.add_keyframe(AnimationKeyframe(0.2, properties={'eye_openness': 1.0}))
        blink_track.add_keyframe(AnimationKeyframe(3.0, properties={'eye_openness': 1.0}))
        
        animations['default_idle'] = [breathing_track, head_track, blink_track]
        
        return animations
    
    def get_emotion_animation(self, emotion: str, intensity: EmotionIntensity = EmotionIntensity.MODERATE) -> Optional[EmotionAnimation]:
        """Get emotion animation by name"""
        base_animation = self.emotion_animations.get(emotion)
        if base_animation:
            # Create copy with adjusted intensity
            animation = EmotionAnimation(
                emotion=base_animation.emotion,
                intensity=intensity,
                duration=base_animation.duration,
                tracks=base_animation.tracks.copy(),
                eyebrow_position=base_animation.eyebrow_position * self._get_intensity_multiplier(intensity),
                eye_openness=base_animation.eye_openness,
                mouth_shape=base_animation.mouth_shape * self._get_intensity_multiplier(intensity),
                mouth_openness=base_animation.mouth_openness * self._get_intensity_multiplier(intensity),
                cultural_modifier=base_animation.cultural_modifier
            )
            return animation
        return None
    
    def get_gesture_animation(self, gesture_name: str) -> Optional[GestureAnimation]:
        """Get gesture animation by name"""
        return self.gesture_animations.get(gesture_name)
    
    def get_speech_animation(self, phoneme: str) -> Optional[SpeechAnimation]:
        """Get speech animation for phoneme"""
        return self.speech_animations.get(phoneme)
    
    def get_idle_animations(self) -> List[AnimationTrack]:
        """Get default idle animations"""
        return self.idle_animations.get('default_idle', [])
    
    def _get_intensity_multiplier(self, intensity: EmotionIntensity) -> float:
        """Get multiplier for emotion intensity"""
        multipliers = {
            EmotionIntensity.SUBTLE: 0.3,
            EmotionIntensity.MILD: 0.6,
            EmotionIntensity.MODERATE: 1.0,
            EmotionIntensity.STRONG: 1.4,
            EmotionIntensity.INTENSE: 1.8
        }
        return multipliers.get(intensity, 1.0)

@dataclass
class AnimationBlender:
    """Blend multiple animations together"""
    active_animations: List[Tuple[str, float, float]] = field(default_factory=list)  # (name, weight, time)
    blend_mode: str = "additive"  # additive, override, multiply
    
    def add_animation(self, name: str, weight: float = 1.0):
        """Add animation to blend"""
        self.active_animations.append((name, weight, 0.0))
    
    def remove_animation(self, name: str):
        """Remove animation from blend"""
        self.active_animations = [(n, w, t) for n, w, t in self.active_animations if n != name]
    
    def update_time(self, delta_time: float):
        """Update animation times"""
        self.active_animations = [
            (name, weight, time + delta_time) 
            for name, weight, time in self.active_animations
        ]
    
    def get_blended_state(self, animation_library: AnimationLibrary) -> Dict[str, Any]:
        """Get current blended animation state"""
        if not self.active_animations:
            return {}
        
        blended_state = {}
        total_weight = sum(weight for _, weight, _ in self.active_animations)
        
        if total_weight == 0:
            return {}
        
        for name, weight, time in self.active_animations:
            # Get animation data at current time
            # This would integrate with the actual animation system
            normalized_weight = weight / total_weight
            
            # Blend based on mode
            if self.blend_mode == "additive":
                # Add weighted contribution
                pass
            elif self.blend_mode == "override":
                # Higher weights override lower weights
                pass
        
        return blended_state