#!/bin/bash

# Avatar System Module - Installation Script
# ==========================================
# Advanced Avatar System with 50+ Avatars, Lip Sync, and 3D Rendering

echo "🎭 Installing Avatar System Module - MONSTER Version 2.0.0"
echo "=========================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_warning "Running as root. Consider using a virtual environment."
fi

# Check Python version
print_status "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
required_version="3.8"

if ! python3 -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)"; then
    print_error "Python 3.8+ required. Current version: $python_version"
    exit 1
fi
print_success "Python version OK: $python_version"

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 not found. Please install pip3 first."
    exit 1
fi

# Update pip
print_status "Updating pip..."
pip3 install --upgrade pip

# Install system dependencies for OpenCV and dlib
print_status "Installing system dependencies..."

if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    if command -v apt-get &> /dev/null; then
        sudo apt-get update
        sudo apt-get install -y \
            python3-dev \
            libopencv-dev \
            cmake \
            build-essential \
            libgtk-3-dev \
            libboost-all-dev \
            libavcodec-dev \
            libavformat-dev \
            libswscale-dev \
            libv4l-dev \
            libxvidcore-dev \
            libx264-dev \
            libjpeg-dev \
            libpng-dev \
            libtiff-dev \
            gfortran \
            openexr \
            libatlas-base-dev \
            python3-numpy \
            libtbb2 \
            libtbb-dev \
            libdc1394-22-dev \
            libopenexr-dev \
            libgstreamer-plugins-base1.0-dev \
            libgstreamer1.0-dev
    elif command -v yum &> /dev/null; then
        sudo yum update -y
        sudo yum groupinstall -y "Development Tools"
        sudo yum install -y \
            python3-devel \
            opencv-devel \
            cmake \
            gtk3-devel \
            boost-devel \
            numpy \
            tbb-devel
    fi
elif [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    if command -v brew &> /dev/null; then
        brew install opencv
        brew install cmake
        brew install boost
    else
        print_warning "Homebrew not found. Please install it or install dependencies manually."
    fi
fi

# Install Python requirements
print_status "Installing Python requirements..."
pip3 install -r requirements.txt

# Install additional packages for enhanced functionality
print_status "Installing additional packages..."

# Try to install dlib (can be tricky)
print_status "Installing dlib (face recognition library)..."
if ! pip3 install dlib; then
    print_warning "Failed to install dlib. Face tracking features may not work."
    print_warning "You can try: pip3 install cmake && pip3 install dlib"
fi

# Install PyTorch for advanced features (optional)
print_status "Installing PyTorch (optional, for advanced ML features)..."
if ! pip3 install torch torchvision --index-url https://download.pytorch.org/whl/cpu; then
    print_warning "Failed to install PyTorch. Advanced ML features may not work."
fi

# Create directories for avatar data
print_status "Creating avatar directories..."
mkdir -p data/avatars/custom
mkdir -p data/avatars/animations  
mkdir -p data/avatars/exports
mkdir -p data/avatars/cache
mkdir -p logs

# Create configuration file
print_status "Creating configuration file..."
cat > config.json << EOF
{
    "avatar_system": {
        "default_avatar": "sarah_friendly",
        "render_resolution": [512, 512],
        "animation_fps": 30,
        "enable_3d_rendering": true,
        "enable_lip_sync": true,
        "enable_face_tracking": true,
        "cache_rendered_frames": true,
        "max_cache_size_mb": 500,
        "supported_languages": ["he", "en", "ar"],
        "emotion_intensity_default": 0.8,
        "background_color": "#F0F0F0",
        "lighting_type": "soft",
        "anti_aliasing": true,
        "render_shadows": true,
        "export_formats": ["png", "jpg", "gif", "mp4"],
        "database_path": "data/avatars/avatars.db"
    }
}
EOF

# Create sample avatar data
print_status "Creating sample avatar data..."
python3 << EOF
import json
import os

# Create sample custom avatar
sample_avatar = {
    "name": "דוגמה מותאמת",
    "gender": "female",
    "style": "realistic", 
    "age": 25,
    "skin_color": "#FDBCB4",
    "hair_color": "#8B4513",
    "eye_color": "#4169E1",
    "personality_traits": ["friendly", "helpful", "creative"],
    "custom_features": {
        "glasses": False,
        "beard": False,
        "makeup": "natural"
    }
}

os.makedirs("data/avatars/samples", exist_ok=True)
with open("data/avatars/samples/sample_avatar.json", "w", encoding="utf-8") as f:
    json.dump(sample_avatar, f, ensure_ascii=False, indent=2)

print("Sample avatar data created successfully!")
EOF

# Test the installation
print_status "Testing installation..."
python3 << EOF
try:
    import cv2
    import numpy as np
    from module import AvatarSystemModule
    
    print("✅ OpenCV imported successfully")
    print("✅ NumPy imported successfully") 
    print("✅ Avatar module imported successfully")
    
    # Quick test
    avatar_module = AvatarSystemModule()
    print(f"✅ Avatar module initialized: {avatar_module.name} v{avatar_module.version}")
    print(f"✅ Built-in avatars: {len(avatar_module.built_in_avatars)}")
    
    avatar_module.start()
    status = avatar_module.get_status()
    print(f"✅ Module status: {'Active' if status['is_active'] else 'Inactive'}")
    print(f"✅ Total avatars: {status['total_avatars']}")
    avatar_module.stop()
    
    print("🎭 Installation test PASSED!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    exit(1)
except Exception as e:
    print(f"❌ Test failed: {e}")
    exit(1)
EOF

if [ $? -eq 0 ]; then
    print_success "Installation test completed successfully!"
else
    print_error "Installation test failed!"
    exit 1
fi

# Create desktop shortcut (Linux only)
if [[ "$OSTYPE" == "linux-gnu"* ]] && [ "$DISPLAY" ]; then
    print_status "Creating desktop shortcut..."
    cat > ~/Desktop/AvatarSystem.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Avatar System
Comment=Advanced Avatar System with 50+ Avatars
Exec=python3 $(pwd)/module.py
Icon=applications-graphics
Terminal=true
Categories=Graphics;3DGraphics;
EOF
    chmod +x ~/Desktop/AvatarSystem.desktop
fi

# Set permissions
print_status "Setting permissions..."
chmod +x module.py
chmod -R 755 data/

# Create usage documentation
print_status "Creating documentation..."
cat > USAGE.md << EOF
# Avatar System Module - Usage Guide
## 🎭 Advanced Avatar System v2.0.0 - MONSTER

### Features
- 50+ Built-in Avatars
- Advanced Lip Sync (Hebrew & English)
- 150+ Facial Expressions & Emotions
- 3D Real-time Rendering
- Custom Avatar Creation
- Animation Export/Import
- Face Tracking (optional)
- Multi-language Support

### Quick Start
\`\`\`python
from module import AvatarSystemModule

# Initialize
avatar_system = AvatarSystemModule()
avatar_system.start()

# Switch avatar
avatar_system.switch_avatar("sarah_friendly")

# Create speech animation
animation = avatar_system.generate_speech_animation("שלום עולם!", language="he")

# Render animation
frames = avatar_system.render_animation(animation)

# Express emotion
emotion_anim = avatar_system.express_emotion(EmotionType.HAPPY, intensity=0.8)
\`\`\`

### Available Avatars
- שרה הידידותית (Sarah Friendly)
- דוד המקצועי (David Professional)  
- מאיה היצירתית (Maya Creative)
- 10x Anime Characters
- 5x Robot Assistants
- + Many more...

### Supported Languages
- Hebrew (עברית) - Full RTL support
- English
- Arabic (العربية)

### Configuration
Edit \`config.json\` to customize:
- Render resolution
- Animation FPS
- Default avatar
- Language settings
- And much more...
EOF

# Final success message
echo ""
echo "🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉"
echo ""
print_success "AVATAR SYSTEM MODULE INSTALLATION COMPLETE!"
echo ""
echo -e "${PURPLE}📊 INSTALLATION SUMMARY:${NC}"
echo "  ✅ 50+ Built-in Avatars Ready"
echo "  ✅ Advanced Lip Sync Engine"
echo "  ✅ 150+ Facial Expressions"
echo "  ✅ 3D Real-time Rendering"
echo "  ✅ Hebrew & RTL Support"
echo "  ✅ Custom Avatar Creation"
echo "  ✅ Multi-language Support"
echo ""
echo -e "${BLUE}🚀 TO GET STARTED:${NC}"
echo "  python3 module.py              # Test the module"
echo "  python3 -c 'from module import AvatarSystemModule; help(AvatarSystemModule)'"
echo ""
echo -e "${GREEN}📁 DIRECTORIES CREATED:${NC}"
echo "  data/avatars/               # Avatar data"
echo "  data/avatars/custom/        # Custom avatars"
echo "  data/avatars/animations/    # Saved animations" 
echo "  data/avatars/exports/       # Exported files"
echo ""
echo -e "${YELLOW}📖 DOCUMENTATION:${NC}"
echo "  USAGE.md                    # Usage guide"
echo "  config.json                 # Configuration"
echo ""
echo "🎭 Avatar System is now ready to create AMAZING avatars!"
echo "🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉🎭🎉"

exit 0