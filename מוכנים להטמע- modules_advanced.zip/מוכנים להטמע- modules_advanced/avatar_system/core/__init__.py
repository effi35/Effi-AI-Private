"""
Avatar System - Core Package
Core engines and processing components for avatar system
"""

from .avatar_engine import AvatarEngine, AvatarInstance
from .animation_engine import AnimationEngine, AnimationController
from .rendering_engine import RenderingEngine, SceneManager
from .interaction_engine import InteractionEngine, DialogueManager
from .voice_engine import VoiceEngine, SpeechSynthesizer

__all__ = [
    'AvatarEngine',
    'AvatarInstance',
    'AnimationEngine',
    'AnimationController',
    'RenderingEngine',
    'SceneManager',
    'InteractionEngine',
    'DialogueManager',
    'VoiceEngine',
    'SpeechSynthesizer'
]