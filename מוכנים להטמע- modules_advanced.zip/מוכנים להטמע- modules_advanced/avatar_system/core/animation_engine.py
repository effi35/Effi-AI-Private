"""
Animation Engine - Avatar Animation Processing and Control
"""

import threading
import time
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import logging

from ..models.animations import (
    AnimationLibrary, AnimationType, AnimationState, EmotionAnimation,
    GestureAnimation, AnimationTrack, AnimationKeyframe, AnimationBlender
)

class AnimationController:
    """Controls animation playback for a single avatar"""
    
    def __init__(self, avatar_id: str):
        self.avatar_id = avatar_id
        self.current_animations = {}  # track_name -> animation_data
        self.animation_state = AnimationState.INACTIVE
        self.playback_time = 0.0
        self.playback_speed = 1.0
        self.blender = AnimationBlender()
        
        # Animation queue
        self.animation_queue = []
        self.priority_queue = []
        
        # Transition settings
        self.default_blend_duration = 0.3
        self.max_concurrent_animations = 5
        
        # Performance tracking
        self.frames_processed = 0
        self.last_update_time = time.time()
        
        # Thread safety
        self._lock = threading.RLock()
        
        self.logger = logging.getLogger(f"animation_controller_{avatar_id[:8]}")
    
    def play_animation(self, animation: Any, blend_duration: float = None, 
                      priority: int = 0, loop: bool = False) -> str:
        """Play animation with optional blending"""
        with self._lock:
            blend_duration = blend_duration or self.default_blend_duration
            
            animation_id = f"anim_{int(time.time() * 1000)}"
            
            animation_data = {
                'id': animation_id,
                'animation': animation,
                'start_time': self.playback_time,
                'blend_duration': blend_duration,
                'priority': priority,
                'loop': loop,
                'state': 'starting',
                'blend_weight': 0.0,
                'target_weight': 1.0
            }
            
            if priority > 5:
                self.priority_queue.append(animation_data)
                self.priority_queue.sort(key=lambda x: x['priority'], reverse=True)
            else:
                self.animation_queue.append(animation_data)
            
            self.logger.debug(f"Animation queued: {animation_id} (priority: {priority})")
            
            return animation_id
    
    def stop_animation(self, animation_id: str, fade_duration: float = 0.3):
        """Stop specific animation with fade out"""
        with self._lock:
            # Find and mark for stopping
            for track_name, anim_data in self.current_animations.items():
                if anim_data['id'] == animation_id:
                    anim_data['state'] = 'stopping'
                    anim_data['fade_duration'] = fade_duration
                    anim_data['stop_start_time'] = self.playback_time
                    
                    self.logger.debug(f"Animation stopping: {animation_id}")
                    return True
            
            return False
    
    def stop_all_animations(self, fade_duration: float = 0.5):
        """Stop all currently playing animations"""
        with self._lock:
            for anim_data in self.current_animations.values():
                if anim_data['state'] not in ['stopping', 'stopped']:
                    anim_data['state'] = 'stopping'
                    anim_data['fade_duration'] = fade_duration
                    anim_data['stop_start_time'] = self.playback_time
            
            self.logger.debug("All animations stopping")
    
    def update(self, delta_time: float) -> Dict[str, Any]:
        """Update animation controller"""
        with self._lock:
            self.playback_time += delta_time * self.playback_speed
            
            # Process animation queue
            self._process_animation_queue()
            
            # Update current animations
            current_pose = self._update_current_animations(delta_time)
            
            # Clean up finished animations
            self._cleanup_finished_animations()
            
            # Update performance metrics
            self.frames_processed += 1
            
            return current_pose
    
    def _process_animation_queue(self):
        """Process queued animations"""
        # Process priority queue first
        while self.priority_queue and len(self.current_animations) < self.max_concurrent_animations:
            animation_data = self.priority_queue.pop(0)
            self._start_animation(animation_data)
        
        # Process regular queue
        while self.animation_queue and len(self.current_animations) < self.max_concurrent_animations:
            animation_data = self.animation_queue.pop(0)
            self._start_animation(animation_data)
    
    def _start_animation(self, animation_data: Dict[str, Any]):
        """Start playing an animation"""
        animation = animation_data['animation']
        
        if hasattr(animation, 'tracks'):
            # Multi-track animation
            for track in animation.tracks:
                track_key = f"{animation_data['id']}_{track.name}"
                self.current_animations[track_key] = {
                    **animation_data,
                    'track': track,
                    'state': 'blending_in'
                }
        else:
            # Single animation
            track_key = animation_data['id']
            self.current_animations[track_key] = {
                **animation_data,
                'state': 'blending_in'
            }
        
        self.animation_state = AnimationState.PLAYING
    
    def _update_current_animations(self, delta_time: float) -> Dict[str, Any]:
        """Update all current animations and blend results"""
        pose_data = {}
        
        for track_key, anim_data in self.current_animations.items():
            # Update blend weights
            self._update_blend_weights(anim_data, delta_time)
            
            # Get current animation values
            if 'track' in anim_data:
                track_values = self._evaluate_track(anim_data['track'], 
                                                  self.playback_time - anim_data['start_time'])
            else:
                track_values = self._evaluate_animation(anim_data['animation'], 
                                                      self.playback_time - anim_data['start_time'])
            
            # Apply blend weight
            weight = anim_data['blend_weight']
            for property_name, value in track_values.items():
                if property_name not in pose_data:
                    pose_data[property_name] = {'value': 0, 'total_weight': 0}
                
                if isinstance(value, (int, float)):
                    pose_data[property_name]['value'] += value * weight
                    pose_data[property_name]['total_weight'] += weight
                elif isinstance(value, (list, tuple)) and len(value) == 3:
                    # Handle 3D vectors (position, rotation, scale)
                    if 'vector' not in pose_data[property_name]:
                        pose_data[property_name]['vector'] = [0, 0, 0]
                    
                    for i in range(3):
                        pose_data[property_name]['vector'][i] += value[i] * weight
                    pose_data[property_name]['total_weight'] += weight
        
        # Normalize blended values
        final_pose = {}
        for property_name, data in pose_data.items():
            total_weight = data['total_weight']
            if total_weight > 0:
                if 'vector' in data:
                    final_pose[property_name] = [
                        data['vector'][i] / total_weight for i in range(3)
                    ]
                else:
                    final_pose[property_name] = data['value'] / total_weight
        
        return final_pose
    
    def _update_blend_weights(self, anim_data: Dict[str, Any], delta_time: float):
        """Update animation blend weights for smooth transitions"""
        state = anim_data['state']
        
        if state == 'blending_in':
            # Blend in
            blend_progress = (self.playback_time - anim_data['start_time']) / anim_data['blend_duration']
            if blend_progress >= 1.0:
                anim_data['blend_weight'] = anim_data['target_weight']
                anim_data['state'] = 'playing'
            else:
                # Smooth blend curve
                smooth_progress = self._smooth_step(blend_progress)
                anim_data['blend_weight'] = smooth_progress * anim_data['target_weight']
        
        elif state == 'playing':
            anim_data['blend_weight'] = anim_data['target_weight']
        
        elif state == 'stopping':
            # Blend out
            stop_progress = (self.playback_time - anim_data['stop_start_time']) / anim_data['fade_duration']
            if stop_progress >= 1.0:
                anim_data['blend_weight'] = 0.0
                anim_data['state'] = 'stopped'
            else:
                smooth_progress = self._smooth_step(stop_progress)
                start_weight = anim_data.get('stop_weight', anim_data['target_weight'])
                anim_data['blend_weight'] = start_weight * (1.0 - smooth_progress)
    
    def _smooth_step(self, t: float) -> float:
        """Smooth step interpolation function"""
        t = max(0.0, min(1.0, t))
        return t * t * (3.0 - 2.0 * t)
    
    def _evaluate_track(self, track: AnimationTrack, local_time: float) -> Dict[str, Any]:
        """Evaluate animation track at specific time"""
        return track.get_value_at_time(local_time)
    
    def _evaluate_animation(self, animation: Any, local_time: float) -> Dict[str, Any]:
        """Evaluate animation at specific time"""
        if hasattr(animation, 'tracks'):
            combined_values = {}
            for track in animation.tracks:
                track_values = self._evaluate_track(track, local_time)
                combined_values.update(track_values)
            return combined_values
        
        # Handle emotion/gesture animations
        if hasattr(animation, 'duration'):
            progress = min(1.0, local_time / animation.duration)
            return self._evaluate_procedural_animation(animation, progress)
        
        return {}
    
    def _evaluate_procedural_animation(self, animation: Any, progress: float) -> Dict[str, Any]:
        """Evaluate procedural animation (emotions, gestures)"""
        values = {}
        
        if hasattr(animation, 'eyebrow_position'):
            values['eyebrow_position'] = animation.eyebrow_position * progress
        
        if hasattr(animation, 'eye_openness'):
            values['eye_openness'] = animation.eye_openness
        
        if hasattr(animation, 'mouth_shape'):
            values['mouth_shape'] = animation.mouth_shape * progress
        
        if hasattr(animation, 'mouth_openness'):
            values['mouth_openness'] = animation.mouth_openness * progress
        
        return values
    
    def _cleanup_finished_animations(self):
        """Remove finished animations"""
        finished_keys = []
        
        for track_key, anim_data in self.current_animations.items():
            if anim_data['state'] == 'stopped':
                finished_keys.append(track_key)
            elif anim_data['state'] == 'playing' and not anim_data['loop']:
                # Check if animation has finished
                if hasattr(anim_data['animation'], 'duration'):
                    duration = anim_data['animation'].duration
                    elapsed = self.playback_time - anim_data['start_time']
                    if elapsed >= duration:
                        finished_keys.append(track_key)
        
        for key in finished_keys:
            del self.current_animations[key]
            self.logger.debug(f"Animation finished: {key}")
        
        # Update animation state
        if not self.current_animations and not self.animation_queue and not self.priority_queue:
            self.animation_state = AnimationState.INACTIVE
    
    def get_state(self) -> Dict[str, Any]:
        """Get current animation controller state"""
        with self._lock:
            return {
                'avatar_id': self.avatar_id,
                'state': self.animation_state.value,
                'playback_time': self.playback_time,
                'playback_speed': self.playback_speed,
                'active_animations': len(self.current_animations),
                'queued_animations': len(self.animation_queue),
                'priority_animations': len(self.priority_queue),
                'frames_processed': self.frames_processed
            }

class AnimationEngine:
    """Main animation engine managing multiple avatar animation controllers"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.animation_library = AnimationLibrary()
        self.controllers = {}  # avatar_id -> AnimationController
        
        # Engine state
        self.is_running = False
        self.update_thread = None
        self.target_fps = self.config.get('target_fps', 30)
        self.frame_time = 1.0 / self.target_fps
        
        # Performance tracking
        self.total_frames = 0
        self.average_frame_time = 0.0
        self.last_update_time = time.time()
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Cultural animation adaptations
        self.cultural_adaptations = {}
        
        self.logger = logging.getLogger("animation_engine")
    
    def start(self):
        """Start animation engine"""
        with self._lock:
            if self.is_running:
                return
            
            self.is_running = True
            self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
            self.update_thread.start()
            
            self.logger.info("Animation Engine started")
    
    def stop(self):
        """Stop animation engine"""
        with self._lock:
            self.is_running = False
            
            if self.update_thread:
                self.update_thread.join(timeout=5.0)
            
            self.logger.info("Animation Engine stopped")
    
    def register_avatar(self, avatar_id: str) -> AnimationController:
        """Register avatar for animation control"""
        with self._lock:
            if avatar_id not in self.controllers:
                controller = AnimationController(avatar_id)
                self.controllers[avatar_id] = controller
                
                self.logger.info(f"Avatar registered for animation: {avatar_id}")
                
                return controller
            
            return self.controllers[avatar_id]
    
    def unregister_avatar(self, avatar_id: str):
        """Unregister avatar"""
        with self._lock:
            if avatar_id in self.controllers:
                controller = self.controllers[avatar_id]
                controller.stop_all_animations()
                del self.controllers[avatar_id]
                
                self.logger.info(f"Avatar unregistered: {avatar_id}")
    
    def play_emotion_animation(self, avatar_id: str, emotion: str, 
                             intensity: float = 0.5, duration: float = 2.0) -> str:
        """Play emotion animation for avatar"""
        controller = self.controllers.get(avatar_id)
        if not controller:
            return ""
        
        # Get emotion animation from library
        emotion_anim = self.animation_library.get_emotion_animation(emotion)
        if emotion_anim:
            # Adjust intensity
            emotion_anim.duration = duration
            return controller.play_animation(emotion_anim, priority=6)
        
        return ""
    
    def play_gesture_animation(self, avatar_id: str, gesture_name: str,
                             cultural_adaptation: bool = True) -> str:
        """Play gesture animation for avatar"""
        controller = self.controllers.get(avatar_id)
        if not controller:
            return ""
        
        # Get gesture animation from library
        gesture_anim = self.animation_library.get_gesture_animation(gesture_name)
        if gesture_anim:
            # Apply cultural adaptations if enabled
            if cultural_adaptation and gesture_name in self.cultural_adaptations:
                adaptations = self.cultural_adaptations[gesture_name]
                self._apply_cultural_adaptation(gesture_anim, adaptations)
            
            return controller.play_animation(gesture_anim, priority=4)
        
        return ""
    
    def play_idle_animation(self, avatar_id: str) -> List[str]:
        """Play idle animations for avatar"""
        controller = self.controllers.get(avatar_id)
        if not controller:
            return []
        
        # Get idle animations from library
        idle_tracks = self.animation_library.get_idle_animations()
        animation_ids = []
        
        for track in idle_tracks:
            anim_id = controller.play_animation(track, priority=1, loop=True)
            animation_ids.append(anim_id)
        
        return animation_ids
    
    def play_speech_animation(self, avatar_id: str, text: str, 
                            language: str = "hebrew") -> str:
        """Play speech/lip-sync animation"""
        controller = self.controllers.get(avatar_id)
        if not controller:
            return ""
        
        # Generate speech animation based on text
        speech_anim = self._generate_speech_animation(text, language)
        return controller.play_animation(speech_anim, priority=7)
    
    def _generate_speech_animation(self, text: str, language: str) -> Any:
        """Generate speech animation from text"""
        # Simplified speech animation generation
        words = text.split()
        duration = len(words) * 0.6  # Approximate speaking duration
        
        # Create basic lip-sync track
        lip_track = AnimationTrack("lip_sync", "mouth")
        
        current_time = 0.0
        for i, word in enumerate(words):
            word_duration = len(word) * 0.1 + 0.2
            
            # Opening mouth
            lip_track.add_keyframe(AnimationKeyframe(
                current_time,
                properties={'mouth_openness': 0.0}
            ))
            lip_track.add_keyframe(AnimationKeyframe(
                current_time + word_duration * 0.3,
                properties={'mouth_openness': 0.6}
            ))
            lip_track.add_keyframe(AnimationKeyframe(
                current_time + word_duration * 0.7,
                properties={'mouth_openness': 0.4}
            ))
            lip_track.add_keyframe(AnimationKeyframe(
                current_time + word_duration,
                properties={'mouth_openness': 0.0}
            ))
            
            current_time += word_duration + 0.1  # Pause between words
        
        # Create animation object
        class SpeechAnimation:
            def __init__(self, tracks, duration):
                self.tracks = tracks
                self.duration = duration
        
        return SpeechAnimation([lip_track], duration)
    
    def _apply_cultural_adaptation(self, animation: Any, adaptations: Dict[str, Any]):
        """Apply cultural adaptations to animation"""
        if 'intensity_multiplier' in adaptations:
            multiplier = adaptations['intensity_multiplier']
            
            # Apply to gesture animations
            if hasattr(animation, 'tracks'):
                for track in animation.tracks:
                    for keyframe in track.keyframes:
                        # Scale position changes
                        keyframe.position = tuple(p * multiplier for p in keyframe.position)
                        keyframe.rotation = tuple(r * multiplier for r in keyframe.rotation)
        
        if 'speed_multiplier' in adaptations:
            speed_mult = adaptations['speed_multiplier']
            if hasattr(animation, 'duration'):
                animation.duration /= speed_mult
    
    def load_cultural_adaptations(self, cultural_data: Dict[str, Any]):
        """Load cultural animation adaptations"""
        self.cultural_adaptations = cultural_data
        
        # Example adaptations for Israeli culture
        israeli_adaptations = {
            'nu_gesture': {
                'intensity_multiplier': 1.3,
                'speed_multiplier': 1.2
            },
            'israeli_shrug': {
                'intensity_multiplier': 1.4,
                'speed_multiplier': 1.1
            },
            'emphasis_pointing': {
                'intensity_multiplier': 1.2,
                'speed_multiplier': 1.0
            }
        }
        
        self.cultural_adaptations.update(israeli_adaptations)
        self.logger.info("Cultural adaptations loaded")
    
    def _update_loop(self):
        """Main animation update loop"""
        while self.is_running:
            frame_start_time = time.time()
            
            try:
                # Calculate delta time
                current_time = time.time()
                delta_time = current_time - self.last_update_time
                self.last_update_time = current_time
                
                # Update all animation controllers
                for avatar_id, controller in list(self.controllers.items()):
                    controller.update(delta_time)
                
                # Update performance metrics
                self.total_frames += 1
                frame_time = time.time() - frame_start_time
                
                # Update average frame time
                self.average_frame_time = (
                    (self.average_frame_time * (self.total_frames - 1) + frame_time) /
                    self.total_frames
                )
                
                # Sleep to maintain target FPS
                sleep_time = max(0, self.frame_time - frame_time)
                if sleep_time > 0:
                    time.sleep(sleep_time)
                
            except Exception as e:
                self.logger.error(f"Error in animation update loop: {e}")
                time.sleep(0.1)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get animation system status"""
        with self._lock:
            controller_states = {}
            for avatar_id, controller in self.controllers.items():
                controller_states[avatar_id] = controller.get_state()
            
            return {
                'is_running': self.is_running,
                'registered_avatars': len(self.controllers),
                'target_fps': self.target_fps,
                'actual_fps': 1.0 / max(0.001, self.average_frame_time),
                'total_frames': self.total_frames,
                'average_frame_time': self.average_frame_time,
                'cultural_adaptations_loaded': len(self.cultural_adaptations),
                'controllers': controller_states
            }
    
    def get_animation_library_info(self) -> Dict[str, Any]:
        """Get animation library information"""
        return {
            'emotion_animations': len(self.animation_library.emotion_animations),
            'gesture_animations': len(self.animation_library.gesture_animations),
            'speech_animations': len(self.animation_library.speech_animations),
            'idle_animations': len(self.animation_library.idle_animations),
            'available_emotions': list(self.animation_library.emotion_animations.keys()),
            'available_gestures': list(self.animation_library.gesture_animations.keys())
        }