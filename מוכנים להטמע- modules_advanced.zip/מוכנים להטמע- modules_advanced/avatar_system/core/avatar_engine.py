"""
Avatar Engine - Core Avatar Management and Processing
"""

import json
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Tuple
import uuid
import logging

from ..models.avatar_types import AvatarDefinition, AvatarPresets
from ..models.appearance import AvatarAppearance
from ..models.animations import AnimationLibrary, EmotionAnimation, GestureAnimation
from ..models.voice import VoiceProfile
from ..models.config import AvatarConfig

class AvatarInstance:
    """Individual avatar instance with state management"""
    
    def __init__(self, definition: AvatarDefinition, config: AvatarConfig):
        self.id = str(uuid.uuid4())
        self.definition = definition
        self.config = config
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
        
        # Current state
        self.current_emotion = "neutral"
        self.emotion_intensity = 0.5
        self.current_animation = None
        self.animation_queue = []
        self.voice_state = "idle"
        
        # Interaction state
        self.conversation_context = []
        self.user_preferences = {}
        self.learned_behaviors = {}
        
        # Performance tracking
        self.interaction_count = 0
        self.total_speaking_time = 0.0
        self.average_response_time = 0.0
        self.user_satisfaction_score = 0.0
        
        # Cultural context
        self.cultural_adaptations = {}
        self.language_preferences = ["hebrew", "english"]
        self.communication_style = "israeli_direct"
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Event handlers
        self.event_handlers = {}
        
        # Initialize logger
        self.logger = logging.getLogger(f"avatar_instance_{self.id[:8]}")
    
    def update_emotion(self, emotion: str, intensity: float, duration: float = 2.0):
        """Update avatar emotion"""
        with self._lock:
            self.current_emotion = emotion
            self.emotion_intensity = max(0.0, min(1.0, intensity))
            self.last_activity = datetime.now()
            
            # Log emotion change
            self.logger.info(f"Emotion updated: {emotion} (intensity: {intensity:.2f})")
            
            # Trigger emotion change event
            self._trigger_event('emotion_changed', {
                'emotion': emotion,
                'intensity': intensity,
                'duration': duration
            })
    
    def queue_animation(self, animation_name: str, priority: int = 0, 
                       blend_duration: float = 0.3):
        """Queue animation for playback"""
        with self._lock:
            animation_data = {
                'name': animation_name,
                'priority': priority,
                'blend_duration': blend_duration,
                'queued_at': datetime.now(),
                'id': str(uuid.uuid4())
            }
            
            # Insert based on priority
            inserted = False
            for i, existing in enumerate(self.animation_queue):
                if priority > existing['priority']:
                    self.animation_queue.insert(i, animation_data)
                    inserted = True
                    break
            
            if not inserted:
                self.animation_queue.append(animation_data)
            
            self.logger.debug(f"Animation queued: {animation_name} (priority: {priority})")
    
    def speak(self, text: str, emotion: str = None, interrupt: bool = False):
        """Make avatar speak text"""
        with self._lock:
            if interrupt or self.voice_state == "idle":
                self.voice_state = "speaking"
                
                # Apply emotion if specified
                if emotion:
                    self.update_emotion(emotion, self.emotion_intensity)
                
                # Log speaking activity
                self.logger.info(f"Speaking: {text[:50]}...")
                
                # Update statistics
                self.total_speaking_time += len(text.split()) * 0.6  # Rough estimate
                
                # Trigger speech event
                self._trigger_event('speech_started', {
                    'text': text,
                    'emotion': emotion,
                    'interrupt': interrupt
                })
    
    def add_to_conversation_context(self, message: str, speaker: str = "user", 
                                   emotion: str = None):
        """Add message to conversation context"""
        with self._lock:
            context_entry = {
                'timestamp': datetime.now(),
                'message': message,
                'speaker': speaker,
                'emotion': emotion
            }
            
            self.conversation_context.append(context_entry)
            
            # Limit context size based on configuration
            max_context = self.config.interaction.conversation_memory_duration
            cutoff_time = datetime.now() - timedelta(seconds=max_context)
            
            self.conversation_context = [
                entry for entry in self.conversation_context
                if entry['timestamp'] > cutoff_time
            ]
    
    def learn_user_preference(self, category: str, preference: str, weight: float = 1.0):
        """Learn user preference"""
        with self._lock:
            if category not in self.user_preferences:
                self.user_preferences[category] = {}
            
            if preference not in self.user_preferences[category]:
                self.user_preferences[category][preference] = 0.0
            
            # Update preference weight
            current_weight = self.user_preferences[category][preference]
            self.user_preferences[category][preference] = min(5.0, current_weight + weight)
            
            self.logger.debug(f"Learned preference: {category}/{preference} = {weight}")
    
    def adapt_cultural_behavior(self, behavior: str, adaptation_level: float):
        """Adapt cultural behavior"""
        with self._lock:
            self.cultural_adaptations[behavior] = max(0.0, min(1.0, adaptation_level))
            self.logger.debug(f"Cultural adaptation: {behavior} = {adaptation_level:.2f}")
    
    def get_response_suggestion(self, context: str) -> Dict[str, Any]:
        """Get AI-suggested response based on avatar personality and context"""
        personality_traits = self.definition.personality_traits
        
        # Base response characteristics on personality
        response_traits = {
            'directness': personality_traits.directness,
            'warmth': personality_traits.warmth,
            'humor_level': personality_traits.humor_level,
            'formality': personality_traits.formality,
            'emotional_expressiveness': personality_traits.emotional_expressiveness
        }
        
        # Adjust based on cultural adaptations
        for trait, value in response_traits.items():
            if trait in self.cultural_adaptations:
                response_traits[trait] = (value + self.cultural_adaptations[trait]) / 2
        
        # Consider conversation context
        recent_emotions = [
            entry.get('emotion') for entry in self.conversation_context[-5:]
            if entry.get('emotion')
        ]
        
        suggested_emotion = self.current_emotion
        if recent_emotions:
            # Simple emotion mirroring
            emotion_counts = {}
            for emotion in recent_emotions:
                emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
            suggested_emotion = max(emotion_counts, key=emotion_counts.get)
        
        return {
            'suggested_emotion': suggested_emotion,
            'response_traits': response_traits,
            'context_analysis': {
                'recent_topics': self._extract_recent_topics(),
                'user_mood': self._analyze_user_mood(),
                'conversation_flow': self._analyze_conversation_flow()
            },
            'cultural_considerations': self.cultural_adaptations
        }
    
    def _extract_recent_topics(self) -> List[str]:
        """Extract recent conversation topics"""
        # Simple keyword extraction from recent messages
        recent_messages = [
            entry['message'] for entry in self.conversation_context[-10:]
            if entry['speaker'] == 'user'
        ]
        
        # Basic topic extraction (would be more sophisticated in real implementation)
        topics = []
        for message in recent_messages:
            words = message.lower().split()
            # Extract nouns, proper nouns, and technical terms
            topics.extend([word for word in words if len(word) > 3])
        
        # Return most frequent topics
        topic_counts = {}
        for topic in topics:
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
        
        return sorted(topic_counts.keys(), key=topic_counts.get, reverse=True)[:5]
    
    def _analyze_user_mood(self) -> str:
        """Analyze user mood from recent interactions"""
        recent_emotions = [
            entry.get('emotion') for entry in self.conversation_context[-10:]
            if entry.get('emotion') and entry['speaker'] == 'user'
        ]
        
        if not recent_emotions:
            return "neutral"
        
        # Simple mood analysis
        positive_emotions = ['happy', 'excited', 'joy', 'satisfied']
        negative_emotions = ['sad', 'angry', 'frustrated', 'worried']
        
        positive_count = sum(1 for emotion in recent_emotions if emotion in positive_emotions)
        negative_count = sum(1 for emotion in recent_emotions if emotion in negative_emotions)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"
    
    def _analyze_conversation_flow(self) -> str:
        """Analyze conversation flow pattern"""
        if len(self.conversation_context) < 3:
            return "starting"
        
        recent_speakers = [
            entry['speaker'] for entry in self.conversation_context[-6:]
        ]
        
        # Analyze turn-taking patterns
        user_turns = sum(1 for speaker in recent_speakers if speaker == 'user')
        avatar_turns = sum(1 for speaker in recent_speakers if speaker == 'avatar')
        
        if user_turns > avatar_turns * 1.5:
            return "user_dominated"
        elif avatar_turns > user_turns * 1.5:
            return "avatar_dominated"
        else:
            return "balanced"
    
    def update_satisfaction_score(self, feedback: float):
        """Update user satisfaction score"""
        with self._lock:
            # Weighted average with recent feedback having more impact
            current_score = self.user_satisfaction_score
            self.user_satisfaction_score = (current_score * 0.8 + feedback * 0.2)
            
            self.logger.info(f"Satisfaction updated: {self.user_satisfaction_score:.2f}")
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get avatar performance metrics"""
        with self._lock:
            active_time = (datetime.now() - self.created_at).total_seconds()
            
            return {
                'id': self.id,
                'uptime_seconds': active_time,
                'interaction_count': self.interaction_count,
                'total_speaking_time': self.total_speaking_time,
                'average_response_time': self.average_response_time,
                'user_satisfaction_score': self.user_satisfaction_score,
                'conversation_context_size': len(self.conversation_context),
                'learned_preferences_count': sum(len(prefs) for prefs in self.user_preferences.values()),
                'cultural_adaptations_count': len(self.cultural_adaptations),
                'current_emotion': self.current_emotion,
                'emotion_intensity': self.emotion_intensity,
                'voice_state': self.voice_state,
                'animation_queue_size': len(self.animation_queue)
            }
    
    def register_event_handler(self, event_type: str, handler: Callable):
        """Register event handler"""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
    
    def _trigger_event(self, event_type: str, data: Dict[str, Any]):
        """Trigger event handlers"""
        if event_type in self.event_handlers:
            for handler in self.event_handlers[event_type]:
                try:
                    handler(self, event_type, data)
                except Exception as e:
                    self.logger.error(f"Error in event handler: {e}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert avatar instance to dictionary"""
        with self._lock:
            return {
                'id': self.id,
                'definition': self.definition.to_dict(),
                'created_at': self.created_at.isoformat(),
                'last_activity': self.last_activity.isoformat(),
                'current_emotion': self.current_emotion,
                'emotion_intensity': self.emotion_intensity,
                'voice_state': self.voice_state,
                'interaction_count': self.interaction_count,
                'user_preferences': self.user_preferences,
                'cultural_adaptations': self.cultural_adaptations,
                'performance_metrics': self.get_performance_metrics()
            }

class AvatarEngine:
    """Main avatar engine for managing avatar instances and orchestrating operations"""
    
    def __init__(self, config: AvatarConfig):
        self.config = config
        self.instances = {}  # avatar_id -> AvatarInstance
        self.animation_library = AnimationLibrary()
        
        # Engine state
        self.is_running = False
        self.update_thread = None
        self.last_update = datetime.now()
        
        # Performance tracking
        self.total_avatars_created = 0
        self.total_interactions = 0
        self.system_load = 0.0
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Integration with other systems
        self.consciousness_integration = None
        self.external_integrations = {}
        
        # Event system
        self.global_event_handlers = {}
        
        # Initialize logger
        self.logger = logging.getLogger("avatar_engine")
        
        # Cultural knowledge base
        self.cultural_knowledge = self._load_cultural_knowledge()
    
    def start(self):
        """Start the avatar engine"""
        with self._lock:
            if self.is_running:
                return
            
            self.is_running = True
            self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
            self.update_thread.start()
            
            self.logger.info("Avatar Engine started")
    
    def stop(self):
        """Stop the avatar engine"""
        with self._lock:
            self.is_running = False
            
            if self.update_thread:
                self.update_thread.join(timeout=5.0)
            
            self.logger.info("Avatar Engine stopped")
    
    def create_avatar(self, definition: AvatarDefinition, 
                     custom_config: Optional[AvatarConfig] = None) -> str:
        """Create new avatar instance"""
        with self._lock:
            config = custom_config or self.config
            avatar = AvatarInstance(definition, config)
            
            self.instances[avatar.id] = avatar
            self.total_avatars_created += 1
            
            # Apply cultural adaptations
            self._apply_cultural_adaptations(avatar)
            
            # Register global event handlers
            for event_type, handlers in self.global_event_handlers.items():
                for handler in handlers:
                    avatar.register_event_handler(event_type, handler)
            
            self.logger.info(f"Avatar created: {avatar.id} ({definition.metadata.name})")
            
            return avatar.id
    
    def create_avatar_from_preset(self, preset_name: str) -> str:
        """Create avatar from preset"""
        presets = AvatarPresets.get_all_presets()
        if preset_name not in presets:
            raise ValueError(f"Unknown preset: {preset_name}")
        
        definition = presets[preset_name]
        return self.create_avatar(definition)
    
    def get_avatar(self, avatar_id: str) -> Optional[AvatarInstance]:
        """Get avatar instance by ID"""
        return self.instances.get(avatar_id)
    
    def remove_avatar(self, avatar_id: str) -> bool:
        """Remove avatar instance"""
        with self._lock:
            if avatar_id in self.instances:
                avatar = self.instances[avatar_id]
                
                # Cleanup
                avatar._trigger_event('avatar_destroyed', {'id': avatar_id})
                
                del self.instances[avatar_id]
                self.logger.info(f"Avatar removed: {avatar_id}")
                return True
            
            return False
    
    def process_user_input(self, avatar_id: str, input_text: str, 
                          context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process user input for specific avatar"""
        avatar = self.get_avatar(avatar_id)
        if not avatar:
            return {'error': 'Avatar not found'}
        
        start_time = time.time()
        
        # Add to conversation context
        avatar.add_to_conversation_context(input_text, "user")
        
        # Get response suggestion
        response_data = avatar.get_response_suggestion(input_text)
        
        # Update interaction statistics
        avatar.interaction_count += 1
        self.total_interactions += 1
        
        response_time = time.time() - start_time
        avatar.average_response_time = (
            (avatar.average_response_time * (avatar.interaction_count - 1) + response_time) /
            avatar.interaction_count
        )
        
        # Cultural processing
        cultural_response = self._process_cultural_context(avatar, input_text, context)
        
        # Trigger interaction event
        avatar._trigger_event('user_interaction', {
            'input': input_text,
            'context': context,
            'response_time': response_time
        })
        
        return {
            'avatar_id': avatar_id,
            'response_suggestion': response_data,
            'cultural_adaptation': cultural_response,
            'processing_time': response_time,
            'avatar_state': {
                'emotion': avatar.current_emotion,
                'emotion_intensity': avatar.emotion_intensity,
                'voice_state': avatar.voice_state
            }
        }
    
    def update_avatar_emotion(self, avatar_id: str, emotion: str, 
                            intensity: float, duration: float = 2.0):
        """Update avatar emotion"""
        avatar = self.get_avatar(avatar_id)
        if avatar:
            avatar.update_emotion(emotion, intensity, duration)
            
            # Queue appropriate animation
            emotion_animation = self.animation_library.get_emotion_animation(emotion)
            if emotion_animation:
                avatar.queue_animation(f"emotion_{emotion}", priority=5)
    
    def make_avatar_speak(self, avatar_id: str, text: str, 
                         emotion: str = None, interrupt: bool = False):
        """Make avatar speak"""
        avatar = self.get_avatar(avatar_id)
        if avatar:
            avatar.speak(text, emotion, interrupt)
            
            # Add to conversation context
            avatar.add_to_conversation_context(text, "avatar", emotion)
            
            # Queue talking animation
            avatar.queue_animation("talking", priority=3)
    
    def integrate_consciousness_engine(self, consciousness_engine):
        """Integrate with consciousness engine"""
        self.consciousness_integration = consciousness_engine
        
        # Register for consciousness events
        if hasattr(consciousness_engine, 'register_observer'):
            consciousness_engine.register_observer(self._handle_consciousness_event)
        
        self.logger.info("Consciousness engine integrated")
    
    def _handle_consciousness_event(self, event_type: str, data: Dict[str, Any]):
        """Handle consciousness engine events"""
        # Apply consciousness changes to all avatars
        for avatar in self.instances.values():
            if event_type == 'emotion_change':
                emotion = data.get('emotion', 'neutral')
                intensity = data.get('intensity', 0.5)
                avatar.update_emotion(emotion, intensity)
            
            elif event_type == 'memory_formation':
                # Learn from memory formations
                memory_content = data.get('content', '')
                if 'user_preference' in memory_content.lower():
                    # Extract and learn preferences
                    pass
            
            elif event_type == 'thought_pattern':
                # Adapt behavior based on thought patterns
                pattern = data.get('pattern', '')
                if pattern in ['analytical', 'creative', 'empathetic']:
                    avatar.adapt_cultural_behavior('thinking_style', 0.8)
    
    def _apply_cultural_adaptations(self, avatar: AvatarInstance):
        """Apply cultural adaptations to avatar"""
        cultural_bg = avatar.definition.cultural_background.value
        personality = avatar.definition.personality_traits
        
        if cultural_bg == 'israeli':
            # Israeli cultural adaptations
            avatar.adapt_cultural_behavior('directness', personality.directness * 1.2)
            avatar.adapt_cultural_behavior('warmth', personality.warmth * 1.1)
            avatar.adapt_cultural_behavior('gesture_frequency', personality.gesture_frequency * 1.3)
            avatar.adapt_cultural_behavior('interruption_tolerance', 0.8)
            
            # Learn Israeli expressions
            israeli_expressions = [
                "יאללה", "בסדר", "סבבה", "נו", "איזה יופי",
                "חבל על הזמן", "בלגן", "רגע", "אוקיי"
            ]
            
            for expression in israeli_expressions:
                avatar.learn_user_preference('expressions', expression, 1.0)
    
    def _process_cultural_context(self, avatar: AvatarInstance, 
                                input_text: str, context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Process cultural context for response"""
        cultural_response = {
            'detected_culture': 'israeli',
            'language_preference': 'hebrew',
            'formality_level': 0.5,
            'directness_suggestion': avatar.definition.personality_traits.directness,
            'gesture_suggestions': [],
            'cultural_references': []
        }
        
        # Detect Hebrew text
        hebrew_chars = sum(1 for char in input_text if '\u0590' <= char <= '\u05FF')
        if hebrew_chars > len(input_text) * 0.3:
            cultural_response['language_preference'] = 'hebrew'
            cultural_response['directness_suggestion'] *= 1.2
        
        # Detect cultural cues
        cultural_cues = self.cultural_knowledge.get('israeli_cues', [])
        detected_cues = [cue for cue in cultural_cues if cue.lower() in input_text.lower()]
        
        if detected_cues:
            cultural_response['cultural_references'] = detected_cues
            cultural_response['formality_level'] *= 0.8  # More casual with cultural references
        
        # Suggest appropriate gestures
        if avatar.definition.personality_traits.gesture_frequency > 0.6:
            gesture_suggestions = ['hand_emphasis', 'expressive_face', 'body_lean']
            cultural_response['gesture_suggestions'] = gesture_suggestions
        
        return cultural_response
    
    def _load_cultural_knowledge(self) -> Dict[str, Any]:
        """Load cultural knowledge base"""
        return {
            'israeli_cues': [
                'שבת', 'חג', 'צה"ל', 'קיבוץ', 'פלאפל', 'חומוס',
                'תל אביב', 'ירושלים', 'חיפה', 'אילת', 'באר שבע',
                'סבבה', 'יאללה', 'נו', 'בסדר', 'חבל על הזמן'
            ],
            'formality_indicators': [
                'כבוד', 'אדון', 'גברת', 'מר', 'פרופסור', 'דוקטור'
            ],
            'emotional_expressions': [
                'איזה יופי', 'בלגן', 'קשה', 'נפלא', 'מעולה'
            ]
        }
    
    def _update_loop(self):
        """Main update loop"""
        while self.is_running:
            try:
                current_time = datetime.now()
                delta_time = (current_time - self.last_update).total_seconds()
                
                # Update all avatar instances
                for avatar_id, avatar in list(self.instances.items()):
                    self._update_avatar(avatar, delta_time)
                
                # Update system metrics
                self._update_system_metrics()
                
                self.last_update = current_time
                
                # Sleep for next update
                time.sleep(0.033)  # ~30 FPS
                
            except Exception as e:
                self.logger.error(f"Error in update loop: {e}")
                time.sleep(1.0)
    
    def _update_avatar(self, avatar: AvatarInstance, delta_time: float):
        """Update individual avatar"""
        with avatar._lock:
            # Process animation queue
            if avatar.animation_queue:
                current_animation = avatar.animation_queue[0]
                # Animation processing would go here
                avatar.animation_queue.pop(0)
            
            # Update emotion decay
            if avatar.emotion_intensity > 0.1:
                decay_rate = 0.1 * delta_time  # Decay rate
                avatar.emotion_intensity = max(0.1, avatar.emotion_intensity - decay_rate)
            
            # Update voice state
            if avatar.voice_state == "speaking":
                # Check if speaking should end (simplified)
                avatar.voice_state = "idle"
    
    def _update_system_metrics(self):
        """Update system performance metrics"""
        active_avatars = len(self.instances)
        
        # Calculate system load (simplified)
        base_load = active_avatars * 0.1
        animation_load = sum(len(avatar.animation_queue) for avatar in self.instances.values()) * 0.05
        
        self.system_load = min(1.0, base_load + animation_load)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get system status and metrics"""
        with self._lock:
            return {
                'is_running': self.is_running,
                'active_avatars': len(self.instances),
                'total_avatars_created': self.total_avatars_created,
                'total_interactions': self.total_interactions,
                'system_load': self.system_load,
                'uptime_seconds': (datetime.now() - self.last_update).total_seconds(),
                'avatar_list': [
                    {
                        'id': avatar.id,
                        'name': avatar.definition.metadata.name,
                        'emotion': avatar.current_emotion,
                        'state': avatar.voice_state,
                        'interactions': avatar.interaction_count
                    }
                    for avatar in self.instances.values()
                ],
                'configuration': {
                    'rendering_quality': self.config.rendering.quality.value,
                    'interaction_mode': self.config.interaction.mode.value,
                    'cultural_adaptation': self.config.interaction.cultural_adaptation.value
                }
            }
    
    def register_global_event_handler(self, event_type: str, handler: Callable):
        """Register global event handler for all avatars"""
        if event_type not in self.global_event_handlers:
            self.global_event_handlers[event_type] = []
        
        self.global_event_handlers[event_type].append(handler)
        
        # Register with existing avatars
        for avatar in self.instances.values():
            avatar.register_event_handler(event_type, handler)
    
    def export_avatar_data(self, avatar_id: str) -> Optional[Dict[str, Any]]:
        """Export avatar data for backup or transfer"""
        avatar = self.get_avatar(avatar_id)
        if avatar:
            return avatar.to_dict()
        return None
    
    def import_avatar_data(self, avatar_data: Dict[str, Any]) -> str:
        """Import avatar data from backup"""
        # Create avatar from imported data
        definition_data = avatar_data['definition']
        definition = AvatarDefinition(**definition_data)
        
        avatar_id = self.create_avatar(definition)
        avatar = self.get_avatar(avatar_id)
        
        if avatar:
            # Restore state
            avatar.user_preferences = avatar_data.get('user_preferences', {})
            avatar.cultural_adaptations = avatar_data.get('cultural_adaptations', {})
            avatar.interaction_count = avatar_data.get('interaction_count', 0)
            
            self.logger.info(f"Avatar data imported: {avatar_id}")
        
        return avatar_id