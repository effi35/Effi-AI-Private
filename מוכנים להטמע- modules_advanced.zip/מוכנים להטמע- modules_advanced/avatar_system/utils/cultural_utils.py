"""
Cultural Adaptation and Hebrew Processing Utilities
"""

import re
import unicodedata
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from enum import Enum

class CulturalContext(Enum):
    """Cultural context types"""
    ISRAELI = "israeli"
    MIDDLE_EASTERN = "middle_eastern"
    RELIGIOUS = "religious"
    SECULAR = "secular"
    PROFESSIONAL = "professional"
    CASUAL = "casual"
    FAMILY = "family"

class CulturalAdapter:
    """Adapts avatar behavior to cultural contexts"""
    
    def __init__(self):
        self.cultural_rules = self._load_cultural_rules()
        self.religious_calendar = self._load_religious_calendar()
        self.cultural_expressions = self._load_cultural_expressions()
        
    def _load_cultural_rules(self) -> Dict[str, Any]:
        """Load cultural adaptation rules"""
        return {
            'israeli': {
                'directness': 0.9,  # Very direct communication
                'personal_space': 0.6,  # Closer personal space
                'eye_contact': 0.9,  # Strong eye contact
                'gesture_frequency': 0.8,  # High gesture use
                'interruption_tolerance': 0.8,  # Comfortable with interruptions
                'formality': 0.3,  # Generally informal
                'time_flexibility': 0.7,  # More flexible with time
                'family_importance': 0.9,  # Family is very important
                'humor_frequency': 0.7,  # Frequent use of humor
                'emotional_expression': 0.8  # Open emotional expression
            },
            'religious': {
                'modesty_level': 0.8,
                'religious_references': 0.6,
                'sabbath_awareness': 1.0,
                'holiday_recognition': 1.0,
                'kosher_awareness': 0.8,
                'prayer_time_sensitivity': 0.9,
                'gender_interaction_rules': 0.7
            },
            'professional': {
                'directness': 0.7,
                'formality': 0.8,
                'time_precision': 0.9,
                'achievement_focus': 0.8,
                'hierarchy_respect': 0.6,
                'efficiency_emphasis': 0.9
            }
        }
    
    def _load_religious_calendar(self) -> Dict[str, Any]:
        """Load Hebrew/Jewish calendar awareness"""
        return {
            'weekly': {
                'sabbath': {
                    'start': 'friday_evening',
                    'end': 'saturday_evening',
                    'restrictions': ['work', 'technology', 'travel'],
                    'greetings': ['שבת שלום', 'גוט שבת']
                }
            },
            'holidays': {
                'rosh_hashana': {
                    'greeting': 'שנה טובה',
                    'duration': 2,
                    'customs': ['apples_honey', 'prayer', 'reflection']
                },
                'yom_kippur': {
                    'greeting': 'גמר חתימה טובה',
                    'duration': 1,
                    'customs': ['fasting', 'prayer', 'forgiveness']
                },
                'passover': {
                    'greeting': 'חג שמח',
                    'duration': 8,
                    'customs': ['seder', 'matzah', 'family_gathering']
                },
                'independence_day': {
                    'greeting': 'חג עצמאות שמח',
                    'duration': 1,
                    'customs': ['bbq', 'flags', 'patriotic_songs']
                }
            }
        }
    
    def _load_cultural_expressions(self) -> Dict[str, Any]:
        """Load cultural expressions and their meanings"""
        return {
            'greetings': {
                'שלום': {'context': 'universal', 'formality': 0.5},
                'שלום שלום': {'context': 'casual', 'formality': 0.2},
                'בוקר טוב': {'context': 'morning', 'formality': 0.4},
                'לילה טוב': {'context': 'evening', 'formality': 0.4},
                'היי': {'context': 'casual', 'formality': 0.1},
                'איך המצב': {'context': 'casual', 'formality': 0.2}
            },
            'agreements': {
                'בסדר': {'meaning': 'okay', 'enthusiasm': 0.5},
                'סבבה': {'meaning': 'cool/great', 'enthusiasm': 0.8},
                'יופי': {'meaning': 'great', 'enthusiasm': 0.9},
                'מעולה': {'meaning': 'excellent', 'enthusiasm': 0.9},
                'אוקיי': {'meaning': 'okay', 'enthusiasm': 0.4}
            },
            'urgency': {
                'יאללה': {'meaning': 'come_on/lets_go', 'urgency': 0.8},
                'בזז': {'meaning': 'hurry_up', 'urgency': 0.9},
                'רגע': {'meaning': 'wait_a_moment', 'urgency': 0.3},
                'מהר': {'meaning': 'quickly', 'urgency': 0.9}
            },
            'emotions': {
                'איזה בלגן': {'emotion': 'frustration', 'intensity': 0.7},
                'חבל על הזמן': {'emotion': 'disappointment', 'intensity': 0.8},
                'איזה יופי': {'emotion': 'joy', 'intensity': 0.9},
                'קשה לי': {'emotion': 'difficulty', 'intensity': 0.6}
            }
        }
    
    def adapt_response_to_culture(self, response: str, context: CulturalContext, 
                                 user_profile: Dict[str, Any] = None) -> str:
        """Adapt response text to cultural context"""
        adapted_response = response
        
        # Apply cultural rules
        if context == CulturalContext.ISRAELI:
            adapted_response = self._apply_israeli_adaptations(adapted_response)
        elif context == CulturalContext.RELIGIOUS:
            adapted_response = self._apply_religious_adaptations(adapted_response)
        elif context == CulturalContext.PROFESSIONAL:
            adapted_response = self._apply_professional_adaptations(adapted_response)
        
        # Apply user profile adaptations
        if user_profile:
            adapted_response = self._apply_user_profile_adaptations(
                adapted_response, user_profile
            )
        
        return adapted_response
    
    def _apply_israeli_adaptations(self, text: str) -> str:
        """Apply Israeli cultural adaptations"""
        # Add Israeli expressions where appropriate
        if 'yes' in text.lower() or 'ok' in text.lower():
            text = text.replace('yes', 'בסדר').replace('ok', 'אוקיי')
        
        # Add warmth and directness
        if text.endswith('.'):
            israeli_endings = ['!', '.', ', נכון?', ', אוקיי?']
            text = text[:-1] + israeli_endings[hash(text) % len(israeli_endings)]
        
        # Add cultural expressions
        if 'great' in text.lower():
            text = text.replace('great', 'איזה יופי')
        
        return text
    
    def _apply_religious_adaptations(self, text: str) -> str:
        """Apply religious sensitivity adaptations"""
        # Check for sabbath/holiday context
        current_time = datetime.now()
        
        if self._is_sabbath_time(current_time):
            if 'work' in text.lower():
                text += ' (אבל זכור שזה שבת)'
        
        # Add appropriate religious references
        if 'good luck' in text.lower():
            text = text.replace('good luck', 'בהצלחה ובעזרת השם')
        
        return text
    
    def _apply_professional_adaptations(self, text: str) -> str:
        """Apply professional context adaptations"""
        # Make more formal
        casual_replacements = {
            'היי': 'שלום',
            'סבבה': 'מצוין',
            'יאללה': 'בואו נתקדם'
        }
        
        for casual, formal in casual_replacements.items():
            text = text.replace(casual, formal)
        
        return text
    
    def _apply_user_profile_adaptations(self, text: str, profile: Dict[str, Any]) -> str:
        """Apply user-specific adaptations"""
        # Adapt based on user preferences
        directness = profile.get('directness_preference', 0.5)
        formality = profile.get('formality_preference', 0.5)
        
        if directness > 0.7:
            # More direct communication
            text = self._make_more_direct(text)
        elif directness < 0.3:
            # More indirect communication
            text = self._make_more_indirect(text)
        
        if formality > 0.7:
            text = self._make_more_formal(text)
        elif formality < 0.3:
            text = self._make_more_casual(text)
        
        return text
    
    def _make_more_direct(self, text: str) -> str:
        """Make text more direct"""
        # Remove hedging language
        hedges = ['אולי', 'כנראה', 'יכול להיות ש', 'אני חושב ש']
        for hedge in hedges:
            text = text.replace(hedge + ' ', '')
        
        return text
    
    def _make_more_indirect(self, text: str) -> str:
        """Make text more indirect"""
        # Add hedging language
        if not any(hedge in text for hedge in ['אולי', 'כנראה', 'יכול להיות']):
            text = 'אני חושב ש' + text
        
        return text
    
    def _make_more_formal(self, text: str) -> str:
        """Make text more formal"""
        formal_replacements = {
            'אתה': 'אתם',
            'בסדר': 'מצוין',
            'סבבה': 'מעולה'
        }
        
        for casual, formal in formal_replacements.items():
            text = text.replace(casual, formal)
        
        return text
    
    def _make_more_casual(self, text: str) -> str:
        """Make text more casual"""
        casual_replacements = {
            'מצוין': 'סבבה',
            'מעולה': 'יופי',
            'אתם': 'אתה'
        }
        
        for formal, casual in casual_replacements.items():
            text = text.replace(formal, casual)
        
        return text
    
    def _is_sabbath_time(self, current_time: datetime) -> bool:
        """Check if current time is during Sabbath"""
        # Simplified check - Friday evening to Saturday evening
        weekday = current_time.weekday()
        hour = current_time.hour
        
        if weekday == 4 and hour >= 18:  # Friday evening
            return True
        elif weekday == 5:  # Saturday
            return True
        elif weekday == 6 and hour < 20:  # Saturday evening
            return True
        
        return False
    
    def get_appropriate_greeting(self, context: CulturalContext, 
                               time_of_day: str = None) -> str:
        """Get culturally appropriate greeting"""
        if time_of_day is None:
            hour = datetime.now().hour
            if 5 <= hour < 12:
                time_of_day = 'morning'
            elif 12 <= hour < 18:
                time_of_day = 'afternoon'
            else:
                time_of_day = 'evening'
        
        greetings = {
            'morning': {
                CulturalContext.ISRAELI: 'בוקר טוב!',
                CulturalContext.RELIGIOUS: 'בוקר טוב ומבורך!',
                CulturalContext.PROFESSIONAL: 'בוקר טוב וברוכים הבאים',
                CulturalContext.CASUAL: 'בוקר!'
            },
            'afternoon': {
                CulturalContext.ISRAELI: 'שלום!',
                CulturalContext.RELIGIOUS: 'שלום וברכה!',
                CulturalContext.PROFESSIONAL: 'שלום וברוכים הבאים',
                CulturalContext.CASUAL: 'היי!'
            },
            'evening': {
                CulturalContext.ISRAELI: 'ערב טוב!',
                CulturalContext.RELIGIOUS: 'ערב טוב ומבורך!',
                CulturalContext.PROFESSIONAL: 'ערב טוב',
                CulturalContext.CASUAL: 'מה נשמע?'
            }
        }
        
        return greetings.get(time_of_day, {}).get(context, 'שלום!')
    
    def detect_cultural_cues(self, text: str) -> Dict[str, Any]:
        """Detect cultural cues in user input"""
        cues = {
            'religious_references': [],
            'israeli_expressions': [],
            'formality_level': 0.5,
            'emotional_intensity': 0.5,
            'urgency_level': 0.5
        }
        
        text_lower = text.lower()
        
        # Detect religious references
        religious_terms = ['שבת', 'חג', 'ברוך', 'השם', 'מזל טוב', 'אמן']
        for term in religious_terms:
            if term in text_lower:
                cues['religious_references'].append(term)
        
        # Detect Israeli expressions
        for category, expressions in self.cultural_expressions.items():
            for expr, data in expressions.items():
                if expr in text:
                    cues['israeli_expressions'].append({
                        'expression': expr,
                        'category': category,
                        'data': data
                    })
                    
                    # Update intensity levels based on expression
                    if category == 'urgency':
                        cues['urgency_level'] = max(cues['urgency_level'], 
                                                   data.get('urgency', 0.5))
                    elif category == 'emotions':
                        cues['emotional_intensity'] = max(cues['emotional_intensity'],
                                                         data.get('intensity', 0.5))
                    elif category == 'greetings':
                        cues['formality_level'] = data.get('formality', 0.5)
        
        return cues
    
    def get_cultural_response_style(self, cultural_cues: Dict[str, Any]) -> Dict[str, float]:
        """Get response style based on cultural cues"""
        style = {
            'directness': 0.7,
            'warmth': 0.8,
            'formality': 0.5,
            'emotional_expression': 0.7,
            'gesture_frequency': 0.8
        }
        
        # Adjust based on detected cues
        if cultural_cues['religious_references']:
            style['formality'] = min(1.0, style['formality'] + 0.2)
            style['directness'] = max(0.3, style['directness'] - 0.1)
        
        if cultural_cues['israeli_expressions']:
            style['warmth'] = min(1.0, style['warmth'] + 0.1)
            style['gesture_frequency'] = min(1.0, style['gesture_frequency'] + 0.1)
        
        style['formality'] = cultural_cues['formality_level']
        
        return style

class HebrewProcessor:
    """Hebrew language processing utilities"""
    
    def __init__(self):
        self.hebrew_patterns = self._load_hebrew_patterns()
        self.hebrew_stopwords = self._load_hebrew_stopwords()
        
    def _load_hebrew_patterns(self) -> Dict[str, str]:
        """Load Hebrew language patterns"""
        return {
            'question_words': r'\b(מה|איך|למה|מתי|איפה|מי|כמה|איזה)\b',
            'negation': r'\b(לא|אין|בלי|ללא)\b',
            'emphasis': r'\b(מאוד|ממש|באמת|בהחלט|לגמרי)\b',
            'politeness': r'\b(בבקשה|תודה|סליחה|אני מצטער)\b',
            'time_expressions': r'\b(היום|מחר|אתמול|השבוע|החודש)\b',
            'family_terms': r'\b(אבא|אמא|אח|אחות|סבא|סבתא|משפחה)\b'
        }
    
    def _load_hebrew_stopwords(self) -> List[str]:
        """Load Hebrew stopwords"""
        return [
            'של', 'את', 'על', 'אל', 'עם', 'בין', 'אחר', 'כל', 'יש', 'זה',
            'זאת', 'הוא', 'היא', 'הם', 'הן', 'אני', 'אתה', 'את', 'אנחנו',
            'אתם', 'אתן', 'כי', 'אם', 'או', 'גם', 'רק', 'עוד', 'כבר', 'לא'
        ]
    
    def analyze_hebrew_text(self, text: str) -> Dict[str, Any]:
        """Analyze Hebrew text for linguistic features"""
        analysis = {
            'word_count': len(text.split()),
            'character_count': len(text),
            'hebrew_ratio': self._calculate_hebrew_ratio(text),
            'sentence_count': len(re.split(r'[.!?]+', text)),
            'question_count': len(re.findall(r'\?', text)),
            'exclamation_count': len(re.findall(r'!', text)),
            'detected_patterns': {},
            'sentiment_indicators': [],
            'complexity_score': 0.0
        }
        
        # Detect patterns
        for pattern_name, pattern in self.hebrew_patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                analysis['detected_patterns'][pattern_name] = len(matches)
        
        # Analyze sentiment indicators
        analysis['sentiment_indicators'] = self._detect_sentiment_indicators(text)
        
        # Calculate complexity
        analysis['complexity_score'] = self._calculate_complexity(text, analysis)
        
        return analysis
    
    def _calculate_hebrew_ratio(self, text: str) -> float:
        """Calculate ratio of Hebrew characters in text"""
        hebrew_chars = sum(1 for char in text if '\u0590' <= char <= '\u05FF')
        total_chars = len([char for char in text if char.isalnum()])
        
        return hebrew_chars / max(1, total_chars)
    
    def _detect_sentiment_indicators(self, text: str) -> List[Dict[str, Any]]:
        """Detect sentiment indicators in Hebrew text"""
        positive_words = ['טוב', 'מעולה', 'נפלא', 'יופי', 'סבבה', 'מדהים', 'משמח']
        negative_words = ['רע', 'גרוע', 'נורא', 'קשה', 'בעיה', 'לא טוב', 'מאכזב']
        
        indicators = []
        text_lower = text.lower()
        
        for word in positive_words:
            if word in text_lower:
                indicators.append({
                    'word': word,
                    'sentiment': 'positive',
                    'strength': 0.7
                })
        
        for word in negative_words:
            if word in text_lower:
                indicators.append({
                    'word': word,
                    'sentiment': 'negative',
                    'strength': 0.7
                })
        
        return indicators
    
    def _calculate_complexity(self, text: str, analysis: Dict[str, Any]) -> float:
        """Calculate text complexity score"""
        # Simple complexity calculation
        base_score = 0.5
        
        # Word length factor
        words = text.split()
        if words:
            avg_word_length = sum(len(word) for word in words) / len(words)
            base_score += min(0.3, avg_word_length / 10)
        
        # Pattern diversity factor
        pattern_count = len(analysis['detected_patterns'])
        base_score += min(0.2, pattern_count / 10)
        
        return min(1.0, base_score)
    
    def extract_keywords(self, text: str, top_n: int = 10) -> List[Tuple[str, float]]:
        """Extract keywords from Hebrew text"""
        words = re.findall(r'[א-ת]+', text.lower())
        
        # Filter stopwords
        filtered_words = [word for word in words if word not in self.hebrew_stopwords]
        
        # Count frequencies
        word_freq = {}
        for word in filtered_words:
            word_freq[word] = word_freq.get(word, 0) + 1
        
        # Calculate scores (simplified TF)
        total_words = len(filtered_words)
        keyword_scores = []
        
        for word, freq in word_freq.items():
            if len(word) > 2:  # Skip very short words
                score = freq / total_words
                keyword_scores.append((word, score))
        
        # Sort by score and return top N
        keyword_scores.sort(key=lambda x: x[1], reverse=True)
        return keyword_scores[:top_n]
    
    def normalize_hebrew_text(self, text: str) -> str:
        """Normalize Hebrew text"""
        # Remove diacritics (nikud)
        normalized = ''.join(char for char in text 
                           if not (0x0591 <= ord(char) <= 0x05C7))
        
        # Normalize Unicode
        normalized = unicodedata.normalize('NFKC', normalized)
        
        # Fix common issues
        normalized = re.sub(r'\s+', ' ', normalized)  # Multiple spaces
        normalized = re.sub(r'([א-ת])([.!?])', r'\1 \2', normalized)  # Space before punctuation
        
        return normalized.strip()
    
    def detect_hebrew_dialects(self, text: str) -> Dict[str, float]:
        """Detect Hebrew dialect/accent indicators"""
        dialects = {
            'ashkenazi': 0.0,
            'sephardic': 0.0,
            'yemenite': 0.0,
            'modern_israeli': 0.0
        }
        
        # Modern Israeli indicators
        modern_terms = ['אוקיי', 'סבבה', 'יאללה', 'בזז', 'מגניב']
        for term in modern_terms:
            if term in text:
                dialects['modern_israeli'] += 0.2
        
        # Sephardic indicators (pronunciation differences)
        if 'ע' in text or 'ח' in text:
            dialects['sephardic'] += 0.1
        
        # Normalize scores
        max_score = max(dialects.values())
        if max_score > 0:
            for key in dialects:
                dialects[key] /= max_score
        
        return dialects