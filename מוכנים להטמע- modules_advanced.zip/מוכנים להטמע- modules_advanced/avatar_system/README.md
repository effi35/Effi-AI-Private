# מודול מערכת אווטרים - Avatar System

מודול מתקדם לניהול ובקרת אווטרים דיגיטליים עם תמיכה מלאה בתרבות ישראלית ושפה עברית.

## ארכיטקטורה מודולרית מקצועית

המודול בנוי על פי ארכיטקטורה מודולרית עם הפרדה ברורה של אחריות:

### 📊 Models - מודלים
מבני נתונים וקונפיגורציות בסיסיות:
- **avatar_types.py** - הגדרות סוגי אווטרים ואישיות עם טרייטים תרבותיים
- **appearance.py** - מראה חיצוני מפורט עם תכונות פנים וסגנון לבוש
- **animations.py** - מערכת אנימציות מתקדמת עם רגשות ומחוות ישראליות
- **voice.py** - פרופילי קול עם הגיה עברית ודפוסי דיבור תרבותיים
- **config.py** - קונפיגורציות מערכת מקיפות עם הגדרות ביצועים

### ⚙️ Core - ליבה
מנועי העיבוד הראשיים:
- **avatar_engine.py** - מנוע ראשי לניהול אווטרים ועיבוד אינטראקציות
- **animation_engine.py** - מנוע אנימציות עם בלנדינג וקונטרול מתקדם
- **rendering_engine.py** - מנוע רינדור עם אופטימיזציות ביצועים
- **interaction_engine.py** - מנוע אינטראקציה עם התאמה תרבותית
- **voice_engine.py** - מנוע קול וסינתזת דיבור עם תמיכה בעברית

### 🖥️ UI - ממשק משתמש
רכיבי ממשק אינטואיטיביים:
- **avatar_panel.py** - לוח בקרה ראשי עם בחירת אווטרים ובקרה מלאה
- **avatar_gallery.py** - גלריית אווטרים עם תצוגה מקדימה ומידע
- **animation_controls.py** - בקרי אנימציה עם תצוגה חזותית
- **voice_settings.py** - הגדרות קול מתקדמות עם בדיקת הגיה
- **avatar_creator.py** - כלי יצירת אווטרים מותאמים אישית
- **interaction_monitor.py** - מעקב אינטראקציות וביצועים

### 🛠️ Utils - כלי עזר
פונקציות עזר מתקדמות:
- **cultural_utils.py** - התאמה תרבותית ועיבוד עברית מתקדם
- **avatar_utils.py** - כלי אימות ועיבוד אווטרים
- **animation_utils.py** - עזרי אנימציה ומעברים
- **voice_utils.py** - עיבוד קול וניתוח פונמות
- **rendering_utils.py** - אופטימיזציות רינדור וביצועים

## יכולות מרכזיות

### 🤖 ניהול אווטרים מתקדם
- **5 אווטרים מוכנים מראש**: עוזר ישראלי, מדריך ידידותי, מומחה טכנולוגיה, אמן יוצר, מורה חכם
- **יוצר אווטרים מותאם אישית** עם בחירת מראה, אישיות ותרבות
- **התאמה דינמית** לאישיות המשתמש והקשר התרבותי
- **למידה אדפטיבית** מהעדפות המשתמש ודפוסי אינטראקציה

### 🎭 מערכת אנימציות עשירה
- **אנימציות רגשיות**: 15 רגשות שונים עם עוצמות משתנות
- **מחוות ישראליות**: כולל המחווה הקלאסית "נו?" ותנועות יד אופייניות
- **אנימציות דיבור**: סינכרון שפתיים מתקדם עם הגיה עברית
- **אנימציות רקע**: נשימה, עמידה טבעית, תנועות עיניים
- **מעברים חלקים**: בלנדינג אנימציות עם מעברים טבעיים

### 🎤 מערכת קול מתקדמת
- **הגיה עברית מדויקת**: עם התאמה לדיאלקטים שונים
- **דפוסי דיבור ישראליים**: ישירות, חמימות, שימוש במחוות
- **קוד-סוויצ'ינג**: מעבר טבעי בין עברית לאנגלית
- **ביטויים תרבותיים**: שילוב ביטויים ישראליים אותנטיים
- **התאמת טון**: הקשר רשמי/בלתי רשמי, גיל, מקצוע

### 🌍 התאמה תרבותית מלאה
- **הבנת תרבות ישראלית**: ישירות, חמימות, קרבה אישית
- **מודעות דתית**: התחשבות בשבת, חגים, כשרות
- **ביטויים מקומיים**: "יאללה", "סבבה", "נו", "בסדר", "איזה יופי"
- **התאמה אזורית**: דיאלקטים ומבטאים שונים
- **זיהוי הקשר**: פורמלי/קז'ואל, משפחתי/עסקי

### 📊 ניתוח וביצועים
- **מעקב אינטראקציות בזמן אמת**
- **ניתוח שביעות רצון משתמשים**
- **אופטימיזציית ביצועים אוטומטית**
- **דוחות מפורטים** על שימוש ולמידה
- **מטריקות אנימציות** ויעילות מערכת

## התקנה ותצורה

### דרישות מערכת
```bash
pip install numpy scipy librosa pydub
pip install opencv-python pillow matplotlib
pip install nltk transformers torch
```

### הפעלה בסיסית
```python
from avatar_system.core.avatar_engine import AvatarEngine
from avatar_system.models.config import AvatarConfig

# יצירת מנוע אווטרים
config = AvatarConfig()
avatar_engine = AvatarEngine(config)
avatar_engine.start()

# יצירת אווטר מהגדרות מוכנות
avatar_id = avatar_engine.create_avatar_from_preset('israeli_assistant')

# אינטראקציה עם האווטר
response = avatar_engine.process_user_input(
    avatar_id, 
    "שלום! איך אתה יכול לעזור לי?"
)

# הפעלת רגש
avatar_engine.update_avatar_emotion(avatar_id, 'happy', 0.8)

# דיבור
avatar_engine.make_avatar_speak(
    avatar_id, 
    "שלום! אני שמח לראות אותך היום. איך אפשר לעזור?"
)
```

### יצירת אווטר מותאם אישית
```python
from avatar_system.models.avatar_types import AvatarDefinition, PersonalityTraits
from avatar_system.models.appearance import AvatarAppearance

# הגדרת תכונות אישיות
traits = PersonalityTraits(
    openness=0.8,
    extraversion=0.9,
    directness=0.9,  # ישראלי טיפוסי
    warmth=0.9,
    humor_level=0.7
)

# יצירת הגדרות אווטר
definition = AvatarDefinition(
    avatar_type=AvatarType.PROFESSIONAL,
    personality_traits=traits,
    cultural_background=CulturalBackground.ISRAELI,
    hebrew_fluency=1.0,
    cultural_awareness=0.9
)

# יצירת האווטר
avatar_id = avatar_engine.create_avatar(definition)
```

### הפעלת ממשק משתמש
```python
from avatar_system.ui.avatar_panel import AvatarPanel

# יצירת לוח בקרה
panel = AvatarPanel()

# יצירת HTML לממשק
html_content = panel.generate_html()

# שמירה לקובץ והפעלה
with open("avatar_panel.html", "w", encoding="utf-8") as f:
    f.write(html_content)

print("לוח הבקרה נוצר בהצלחה! פתח את avatar_panel.html בדפדפן")
```

## קונפיגורציה מתקדמת

### הגדרות ביצועים
```json
{
  "rendering": {
    "quality": "high",
    "target_fps": 30,
    "resolution": [1920, 1080],
    "mobile_optimized": false
  },
  "interaction": {
    "mode": "active",
    "responsiveness": 0.8,
    "cultural_adaptation": "full",
    "directness_level": 0.8
  },
  "voice": {
    "hebrew_accent": "israeli_hebrew",
    "code_switching_frequency": 0.4,
    "emotional_expression": 0.8
  }
}
```

### התאמה תרבותית
```python
from avatar_system.utils.cultural_utils import CulturalAdapter

adapter = CulturalAdapter()

# התאמת תגובה לתרבות ישראלית
adapted_response = adapter.adapt_response_to_culture(
    "That's great!",
    CulturalContext.ISRAELI
)
# תוצאה: "איזה יופי!"

# זיהוי רמזים תרבותיים
cues = adapter.detect_cultural_cues("יאללה, בואו נתחיל")
print(cues['israeli_expressions'])
# תוצאה: [{'expression': 'יאללה', 'category': 'urgency', 'urgency': 0.8}]
```

## תכונות מתקדמות

### אינטגרציה עם מנוע התודעה
```python
# חיבור למנוע התודעה
from consciousness_engine.core.consciousness_core import ConsciousnessCore

consciousness = ConsciousnessCore()
avatar_engine.integrate_consciousness_engine(consciousness)

# האווטר יגיב אוטומטית לשינויי רגש במנוע התודעה
```

### למידה אדפטיבית
```python
# האווטר לומד מהעדפות המשתמש
avatar = avatar_engine.get_avatar(avatar_id)
avatar.learn_user_preference('communication_style', 'direct', 0.8)
avatar.adapt_cultural_behavior('humor_usage', 0.9)
```

### ניתוח ביצועים
```python
# קבלת מדדי ביצועים
metrics = avatar.get_performance_metrics()
print(f"אינטראקציות: {metrics['interaction_count']}")
print(f"שביעות רצון: {metrics['user_satisfaction_score']:.2f}")
print(f"העדפות נלמדות: {metrics['learned_preferences_count']}")
```

## אווטרים מוכנים מראש

### 1. עוזר ישראלי מקצועי
- **אישיות**: מקצועי, ישיר, יעיל
- **תרבות**: הבנה עמוקה של עסקים ישראליים
- **שפה**: עברית מקצועית עם אנגלית טכנית
- **מומחיות**: עסקים, טכנולוגיה, ניהול

### 2. מדריך ידידותי
- **אישיות**: חם, תומך, סבלני
- **תרבות**: חמימות ישראלית אופיינית
- **שפה**: עברית יומיומית וידידותית
- **מומחיות**: הדרכה, חינוך, תמיכה

### 3. מומחה טכנולוגיה
- **אישיות**: אנליטי, מדויק, חדשני
- **תרבות**: סביבת היי-טק ישראלית
- **שפה**: טכנית עם מונחים באנגלית
- **מומחיות**: פיתוח, טכנולוגיה, חדשנות

### 4. אמן יוצר
- **אישיות**: יצירתי, רגשי, מעורר השראה
- **תרבות**: סצנת האמנות הישראלית
- **שפה**: ביטויית ומלאת דימויים
- **מומחיות**: אמנות, עיצוב, יצירתיות

### 5. מורה חכם
- **אישיות**: סבלני, מנוסה, מנחה
- **תרבות**: מסורת החינוך הישראלית
- **שפה**: ברורה ומדויקת עם דוגמאות
- **מומחיות**: חינוך, הוראה, ייעוץ

## תמיכה בנגישות

המודול כולל תמיכה מלאה בנגישות:
- **תמיכה בכיוון RTL** לעברית
- **ניגודיות גבוהה** לקושי ראייה
- **בקרת קול** למוגבלויות מוטוריות
- **כתוביות** לקושי שמיעה
- **ממשק מפושט** לאתגרים קוגניטיביים

## אבטחה ופרטיות

- **הצפנה מקצה לקצה** של כל האינטראקציות
- **אחסון מקומי** של נתונים רגישים
- **אנונימיזציה** של נתוני אנליטיקה
- **ציות ל-GDPR** וחוקי הפרטיות הישראליים
- **בקרת גישה** מתקדמת

## תחזוקה ותמיכה

- **עדכונים אוטומטיים** של מודלי קול ואנימציה
- **גיבוי אוטומטי** של העדפות משתמש
- **ניטור בריאות מערכת** ואתרור בעיות
- **תמיכה טכנית** בעברית
- **תיעוד מפורט** ודוגמאות קוד

## רישיון ותמיכה

המודול פותח כחלק ממערכת Effi AI Private ומיועד לשימוש פנימי.

### קהילת מפתחים
- תיעוד מקיף בעברית
- דוגמאות קוד מעשיות
- פורום תמיכה בעברית
- סדנאות פיתוח

## סיכום

מודול Avatar System מספק פתרון מקיף ומתקדם לאווטרים דיגיטליים עם:
- **ארכיטקטורה מודולרית מקצועית**
- **התאמה מלאה לתרבות הישראלית**
- **יכולות אנימציה וקול מתקדמות**
- **למידה אדפטיבית חכמה**
- **ממשק משתמש אינטואיטיבי**
- **ביצועים מעולים ויציבות גבוהה**

המודול מהווה את הבסיס לפיתוח חוויות אינטראקציה טבעיות ומעוררות השראה עם אווטרים דיגיטליים מתקדמים.