#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🧪 Avatar System Module - Test Suite
===================================

מערכת בדיקות מקיפה למודול האווטארים המתקדם
"""

import os
import sys
import time
import unittest
import tempfile
import numpy as np
from unittest.mock import patch, MagicMock

# הוספת הנתיב למודול
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from module import (
        AvatarSystemModule,
        AvatarConfig,
        AvatarGender,
        AvatarStyle,
        EmotionType,
        LipSyncEngine,
        FacialExpressionEngine,
        Avatar3DRenderer,
        AvatarDatabase,
        AnimationFrame
    )
except ImportError as e:
    print(f"❌ Import Error: {e}")
    print("Make sure all dependencies are installed: pip install -r requirements.txt")
    sys.exit(1)

class TestAvatarConfig(unittest.TestCase):
    """בדיקות עבור AvatarConfig"""
    
    def test_avatar_config_creation(self):
        """בדיקת יצירת הגדרות אווטאר"""
        config = AvatarConfig(
            name="Test Avatar",
            gender=AvatarGender.FEMALE,
            style=AvatarStyle.REALISTIC,
            age=25
        )
        
        self.assertEqual(config.name, "Test Avatar")
        self.assertEqual(config.gender, AvatarGender.FEMALE)
        self.assertEqual(config.style, AvatarStyle.REALISTIC)
        self.assertEqual(config.age, 25)
        self.assertIsNotNone(config.personality_traits)
        self.assertIsNotNone(config.custom_features)

class TestLipSyncEngine(unittest.TestCase):
    """בדיקות עבור מנוע סנכרון שפתיים"""
    
    def setUp(self):
        self.lip_sync = LipSyncEngine()
    
    def test_hebrew_phonemes(self):
        """בדיקת המרת טקסט עברי לפונמות"""
        text = "שלום"
        phonemes = self.lip_sync.text_to_phonemes(text, "he")
        
        self.assertIsInstance(phonemes, list)
        self.assertGreater(len(phonemes), 0)
        self.assertIn('sh', phonemes)  # שי"ן
    
    def test_english_phonemes(self):
        """בדיקת המרת טקסט אנגלי לפונמות"""
        text = "hello"
        phonemes = self.lip_sync.text_to_phonemes(text, "en")
        
        self.assertIsInstance(phonemes, list)
        self.assertEqual(len(phonemes), len(text))
    
    def test_lip_sync_generation(self):
        """בדיקת יצירת אנימציית סנכרון שפתיים"""
        text = "שלום עולם"
        duration = 2.0
        frames = self.lip_sync.generate_lip_sync(text, duration, "he")
        
        self.assertIsInstance(frames, list)
        self.assertGreater(len(frames), 0)
        
        for frame in frames:
            self.assertIsInstance(frame, AnimationFrame)
            self.assertGreaterEqual(frame.timestamp, 0.0)
            self.assertLessEqual(frame.timestamp, duration)

class TestFacialExpressionEngine(unittest.TestCase):
    """בדיקות עבור מנוע ביטויי פנים"""
    
    def setUp(self):
        self.facial_engine = FacialExpressionEngine()
    
    def test_expression_data_retrieval(self):
        """בדיקת קבלת נתוני ביטוי פנים"""
        expression_data = self.facial_engine.get_expression_data(EmotionType.HAPPY)
        
        self.assertIsInstance(expression_data, dict)
        self.assertIn('mouth', expression_data)
        self.assertIn('eyes', expression_data)
        self.assertIn('eyebrows', expression_data)
        self.assertIn('cheeks', expression_data)
    
    def test_intensity_scaling(self):
        """בדיקת סקלת עוצמת רגש"""
        intensity = 0.5
        expression_data = self.facial_engine.get_expression_data(EmotionType.HAPPY, intensity)
        
        # בדיקה שהעוצמה משפיעה על הערכים
        base_data = self.facial_engine.get_expression_data(EmotionType.HAPPY, 1.0)
        
        self.assertNotEqual(expression_data, base_data)

class TestAvatar3DRenderer(unittest.TestCase):
    """בדיקות עבור רינדרר תלת מימדי"""
    
    def setUp(self):
        self.config = AvatarConfig(
            name="Test Renderer Avatar",
            gender=AvatarGender.NEUTRAL,
            style=AvatarStyle.CARTOON
        )
        self.renderer = Avatar3DRenderer(self.config)
    
    def test_renderer_initialization(self):
        """בדיקת אתחול רינדרר"""
        self.assertEqual(self.renderer.config, self.config)
        self.assertIsNotNone(self.renderer.facial_engine)
        self.assertIsNotNone(self.renderer.render_settings)
    
    @patch('cv2.circle')
    @patch('cv2.ellipse')
    @patch('cv2.line')
    def test_frame_rendering(self, mock_line, mock_ellipse, mock_circle):
        """בדיקת רינדור פריים"""
        frame = AnimationFrame(
            timestamp=0.0,
            mouth_shape='ah',
            eye_position=(0.0, 0.0),
            eyebrow_position=0.0,
            head_rotation=(0.0, 0.0, 0.0),
            facial_expression=EmotionType.NEUTRAL
        )
        
        rendered_frame = self.renderer.render_frame(frame)
        
        self.assertIsInstance(rendered_frame, np.ndarray)
        self.assertEqual(len(rendered_frame.shape), 3)  # Height, Width, Channels
        
        # בדיקה שפונקציות הרינדור נקראו
        mock_circle.assert_called()

class TestAvatarDatabase(unittest.TestCase):
    """בדיקות עבור מסד נתונים של אווטארים"""
    
    def setUp(self):
        # יצירת מסד נתונים זמני
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        self.database = AvatarDatabase(self.temp_db.name)
        
        self.test_config = AvatarConfig(
            name="Test DB Avatar",
            gender=AvatarGender.MALE,
            style=AvatarStyle.REALISTIC
        )
    
    def tearDown(self):
        # ניקוי מסד נתונים זמני
        os.unlink(self.temp_db.name)
    
    def test_database_initialization(self):
        """בדיקת אתחול מסד נתונים"""
        self.assertTrue(os.path.exists(self.temp_db.name))
    
    def test_save_and_load_avatar(self):
        """בדיקת שמירה וטעינה של אווטאר"""
        # שמירה
        avatar_id = self.database.save_avatar(self.test_config)
        self.assertGreater(avatar_id, 0)
        
        # טעינה
        loaded_config = self.database.load_avatar(self.test_config.name)
        self.assertIsNotNone(loaded_config)
        self.assertEqual(loaded_config.name, self.test_config.name)
        self.assertEqual(loaded_config.gender, self.test_config.gender)
        self.assertEqual(loaded_config.style, self.test_config.style)
    
    def test_list_avatars(self):
        """בדיקת רשימת אווטארים"""
        # שמירת אווטאר
        self.database.save_avatar(self.test_config)
        
        # קבלת רשימה
        avatars = self.database.list_avatars()
        
        self.assertIsInstance(avatars, list)
        self.assertGreater(len(avatars), 0)
        self.assertEqual(avatars[0]['name'], self.test_config.name)

class TestAvatarSystemModule(unittest.TestCase):
    """בדיקות עבור המודול הראשי"""
    
    def setUp(self):
        self.avatar_module = AvatarSystemModule()
    
    def test_module_initialization(self):
        """בדיקת אתחול המודול"""
        self.assertEqual(self.avatar_module.name, "avatar_system")
        self.assertIn("MONSTER", self.avatar_module.version)
        self.assertFalse(self.avatar_module.is_active)
        self.assertIsNotNone(self.avatar_module.built_in_avatars)
        self.assertGreater(len(self.avatar_module.built_in_avatars), 0)
    
    def test_module_start_stop(self):
        """בדיקת הפעלה ועצירה של המודול"""
        # הפעלה
        result = self.avatar_module.start()
        self.assertTrue(result)
        self.assertTrue(self.avatar_module.is_active)
        
        # עצירה
        result = self.avatar_module.stop()
        self.assertTrue(result)
        self.assertFalse(self.avatar_module.is_active)
    
    def test_built_in_avatars(self):
        """בדיקת אווטארים מובנים"""
        avatars = self.avatar_module.built_in_avatars
        
        # בדיקת מספר מינימלי של אווטארים
        self.assertGreaterEqual(len(avatars), 15)
        
        # בדיקת קיום אווטארים ספציפיים
        self.assertIn('sarah_friendly', avatars)
        self.assertIn('david_professional', avatars)
        self.assertIn('maya_creative', avatars)
        
        # בדיקת תקינות הגדרות אווטאר
        for name, config in avatars.items():
            self.assertIsInstance(config, AvatarConfig)
            self.assertIsNotNone(config.name)
            self.assertIsInstance(config.gender, AvatarGender)
            self.assertIsInstance(config.style, AvatarStyle)
    
    def test_avatar_switching(self):
        """בדיקת החלפת אווטאר"""
        self.avatar_module.start()
        
        # החלפה לאווטאר קיים
        result = self.avatar_module.switch_avatar('sarah_friendly')
        self.assertTrue(result)
        self.assertIsNotNone(self.avatar_module.current_avatar)
        self.assertEqual(self.avatar_module.current_avatar.name, "שרה הידידותית")
        
        # החלפה לאווטאר לא קיים
        result = self.avatar_module.switch_avatar('nonexistent_avatar')
        self.assertFalse(result)
    
    def test_speech_animation_generation(self):
        """בדיקת יצירת אנימציית דיבור"""
        self.avatar_module.start()
        self.avatar_module.switch_avatar('sarah_friendly')
        
        text = "שלום עולם!"
        animation = self.avatar_module.generate_speech_animation(text, language="he")
        
        self.assertIsInstance(animation, list)
        self.assertGreater(len(animation), 0)
        
        for frame in animation:
            self.assertIsInstance(frame, AnimationFrame)
    
    def test_emotion_expression(self):
        """בדיקת ביטוי רגשות"""
        self.avatar_module.start()
        
        emotion_animation = self.avatar_module.express_emotion(
            EmotionType.HAPPY, 
            intensity=0.8, 
            duration=1.0
        )
        
        self.assertIsInstance(emotion_animation, list)
        self.assertGreater(len(emotion_animation), 0)
        
        for frame in emotion_animation:
            self.assertIsInstance(frame, AnimationFrame)
            self.assertEqual(frame.facial_expression, EmotionType.HAPPY)
    
    def test_custom_avatar_creation(self):
        """בדיקת יצירת אווטאר מותאם אישית"""
        self.avatar_module.start()
        
        custom_config = AvatarConfig(
            name="Test Custom Avatar",
            gender=AvatarGender.FEMALE,
            style=AvatarStyle.CARTOON,
            age=30,
            personality_traits=["test", "custom"]
        )
        
        result = self.avatar_module.create_custom_avatar(custom_config)
        self.assertTrue(result)
        
        # בדיקה שהאווטאר נוסף
        self.assertIn("Test Custom Avatar", self.avatar_module.built_in_avatars)
    
    def test_get_status(self):
        """בדיקת קבלת מצב המודול"""
        status = self.avatar_module.get_status()
        
        self.assertIsInstance(status, dict)
        self.assertIn('name', status)
        self.assertIn('version', status)
        self.assertIn('is_active', status)
        self.assertIn('total_avatars', status)
        self.assertIn('features', status)
        
        # בדיקת תכונות ספציפיות
        features = status['features']
        self.assertIn("50+ Built-in Avatars", features)
        self.assertIn("Hebrew & RTL Support", features)

class TestPerformance(unittest.TestCase):
    """בדיקות ביצועים"""
    
    def setUp(self):
        self.avatar_module = AvatarSystemModule()
        self.avatar_module.start()
        self.avatar_module.switch_avatar('sarah_friendly')
    
    def test_animation_generation_performance(self):
        """בדיקת ביצועי יצירת אנימציה"""
        text = "זה טקסט לבדיקת ביצועים של המערכת"
        
        start_time = time.time()
        animation = self.avatar_module.generate_speech_animation(text, language="he")
        end_time = time.time()
        
        # בדיקה שהאנימציה נוצרה במהירות סבירה (פחות מ-5 שניות)
        self.assertLess(end_time - start_time, 5.0)
        self.assertGreater(len(animation), 0)
    
    def test_memory_usage(self):
        """בדיקת שימוש בזיכרון"""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        memory_before = process.memory_info().rss / 1024 / 1024  # MB
        
        # יצירת מספר אנימציות
        for i in range(10):
            animation = self.avatar_module.generate_speech_animation(f"טקסט מספר {i}", language="he")
            frames = self.avatar_module.render_animation(animation[:5])  # רק 5 פריימים
        
        memory_after = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = memory_after - memory_before
        
        # בדיקה שעליית הזיכרון לא חורגת מ-500MB
        self.assertLess(memory_increase, 500)

class TestIntegration(unittest.TestCase):
    """בדיקות אינטגרציה"""
    
    def test_full_workflow(self):
        """בדיקת תהליך עבודה מלא"""
        # 1. אתחול מודול
        avatar_module = AvatarSystemModule()
        self.assertTrue(avatar_module.start())
        
        # 2. החלפת אווטאר
        self.assertTrue(avatar_module.switch_avatar('sarah_friendly'))
        
        # 3. יצירת אנימציית דיבור
        text = "שלום! איך שלומך היום?"
        animation = avatar_module.generate_speech_animation(text, language="he")
        self.assertGreater(len(animation), 0)
        
        # 4. רינדור האנימציה (רק פריימים בודדים לבדיקה)
        sample_frames = animation[:3]  # 3 פריימי דוגמה
        rendered_frames = avatar_module.render_animation(sample_frames)
        self.assertEqual(len(rendered_frames), len(sample_frames))
        
        # 5. ביטוי רגש
        emotion_animation = avatar_module.express_emotion(EmotionType.HAPPY, 0.7, 1.0)
        self.assertGreater(len(emotion_animation), 0)
        
        # 6. יצירת אווטאר מותאם אישית
        custom_config = AvatarConfig(
            name="Integration Test Avatar",
            gender=AvatarGender.NEUTRAL,
            style=AvatarStyle.ABSTRACT
        )
        self.assertTrue(avatar_module.create_custom_avatar(custom_config))
        
        # 7. בדיקת סטטוס
        status = avatar_module.get_status()
        self.assertTrue(status['is_active'])
        self.assertGreater(status['total_avatars'], 15)
        
        # 8. עצירת מודול
        self.assertTrue(avatar_module.stop())

def run_performance_benchmark():
    """הרצת בנצ'מרק ביצועים"""
    print("\n🚀 Running Performance Benchmark...")
    print("=" * 50)
    
    avatar_module = AvatarSystemModule()
    avatar_module.start()
    avatar_module.switch_avatar('sarah_friendly')
    
    # בדיקת זמן יצירת אנימציה
    texts = [
        "שלום עולם!",
        "איך אתה מרגיש היום?",
        "בוא נדבר על מזג האוויר",
        "מה תכניותיך לסוף השבוע?",
        "אני שמח לעזור לך בכל שאלה"
    ]
    
    total_time = 0
    total_frames = 0
    
    for text in texts:
        start_time = time.time()
        animation = avatar_module.generate_speech_animation(text, language="he")
        end_time = time.time()
        
        duration = end_time - start_time
        total_time += duration
        total_frames += len(animation)
        
        print(f"📝 '{text[:20]}...' - {len(animation)} frames in {duration:.3f}s")
    
    avg_time = total_time / len(texts)
    avg_frames = total_frames / len(texts)
    
    print("-" * 50)
    print(f"⏱️  Average time per animation: {avg_time:.3f}s")
    print(f"🎬 Average frames per animation: {avg_frames:.1f}")
    print(f"🎯 Total frames generated: {total_frames}")
    print(f"⚡ Frames per second: {total_frames/total_time:.1f} FPS")
    
    avatar_module.stop()

if __name__ == '__main__':
    print("🧪 Avatar System Module - Test Suite")
    print("=" * 40)
    
    # הרצת בדיקות יחידה
    print("\n1️⃣  Running Unit Tests...")
    unittest.main(argv=[''], exit=False, verbosity=2)
    
    # הרצת בנצ'מרק ביצועים
    print("\n2️⃣  Running Performance Benchmark...")
    try:
        run_performance_benchmark()
    except Exception as e:
        print(f"❌ Benchmark failed: {e}")
    
    print("\n✅ Test Suite Completed!")
    print("🎭 Avatar System Module is ready for production!")