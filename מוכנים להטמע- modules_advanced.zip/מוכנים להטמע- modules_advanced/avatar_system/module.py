#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🎭 AVATAR SYSTEM MODULE - מערכת אווטארים מתקדמת
====================================================

מודול מתקדם לניהול אווטארים עם יכולות מתקדמות:
- 50+ אווטארים מובנים
- יצירת אווטארים מותאמים אישית
- סנכרון שפתיים מתקדם לעברית ואנגלית
- 150+ אנימציות ורגשות
- זיהוי פנים ומעקב אחר עיניים
- רינדור 3D בזמן אמת
- תמיכה מלאה בעברית וRTL
- ייצוא ויבוא אווטארים
- מערכת שמירה וטעינה
- אפקטים ויזואליים מתקדמים

Created by: Effi-AI Team
Version: 2.0.0 - ADVANCED MONSTER
"""

import os
import cv2
import json
import math
import time
import numpy as np
import logging
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import base64
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)

class AvatarGender(Enum):
    """מגדר אווטאר"""
    MALE = "male"
    FEMALE = "female"
    NEUTRAL = "neutral"

class AvatarStyle(Enum):
    """סגנון אווטאר"""
    REALISTIC = "realistic"
    CARTOON = "cartoon"
    ANIME = "anime"
    PIXEL = "pixel"
    ABSTRACT = "abstract"

class EmotionType(Enum):
    """סוגי רגשות"""
    NEUTRAL = "neutral"
    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    SURPRISED = "surprised"
    DISGUSTED = "disgusted"
    FEARFUL = "fearful"
    EXCITED = "excited"
    CONFUSED = "confused"
    THINKING = "thinking"
    SPEAKING = "speaking"
    LISTENING = "listening"
    SLEEPING = "sleeping"
    WINKING = "winking"
    LAUGHING = "laughing"

@dataclass
class AvatarConfig:
    """הגדרות אווטאר"""
    name: str
    gender: AvatarGender
    style: AvatarStyle
    age: int = 25
    skin_color: str = "#FDBCB4"
    hair_color: str = "#8B4513"
    eye_color: str = "#4169E1"
    height: float = 1.75
    voice_pitch: float = 1.0
    personality_traits: List[str] = None
    custom_features: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.personality_traits is None:
            self.personality_traits = ["friendly", "helpful"]
        if self.custom_features is None:
            self.custom_features = {}

@dataclass
class AnimationFrame:
    """פריים אנימציה"""
    timestamp: float
    mouth_shape: str
    eye_position: Tuple[float, float]
    eyebrow_position: float
    head_rotation: Tuple[float, float, float]
    facial_expression: EmotionType
    intensity: float = 1.0

class LipSyncEngine:
    """מנוע סנכרון שפתיים מתקדם"""
    
    def __init__(self):
        self.hebrew_phonemes = {
            'א': 'ah', 'ב': 'b', 'ג': 'g', 'ד': 'd', 'ה': 'h',
            'ו': 'v', 'ז': 'z', 'ח': 'ch', 'ט': 't', 'י': 'y',
            'כ': 'k', 'ל': 'l', 'מ': 'm', 'ן': 'n', 'נ': 'n',
            'ס': 's', 'ע': 'a', 'פ': 'p', 'צ': 'ts', 'ק': 'k',
            'ר': 'r', 'ש': 'sh', 'ת': 't'
        }
        
        self.mouth_shapes = {
            'ah': {'width': 0.8, 'height': 0.6, 'shape': 'oval'},
            'ee': {'width': 0.4, 'height': 0.2, 'shape': 'line'},
            'oh': {'width': 0.6, 'height': 0.8, 'shape': 'circle'},
            'b': {'width': 0.0, 'height': 0.0, 'shape': 'closed'},
            'm': {'width': 0.0, 'height': 0.0, 'shape': 'closed'},
            'p': {'width': 0.0, 'height': 0.0, 'shape': 'closed'},
            'f': {'width': 0.3, 'height': 0.1, 'shape': 'narrow'},
            'v': {'width': 0.3, 'height': 0.1, 'shape': 'narrow'},
            'th': {'width': 0.2, 'height': 0.1, 'shape': 'tongue'},
            'l': {'width': 0.4, 'height': 0.3, 'shape': 'tongue_up'},
            'r': {'width': 0.5, 'height': 0.4, 'shape': 'rounded'},
            's': {'width': 0.3, 'height': 0.2, 'shape': 'smile'},
            'sh': {'width': 0.4, 'height': 0.3, 'shape': 'pucker'},
            'ch': {'width': 0.4, 'height': 0.3, 'shape': 'pucker'},
            'k': {'width': 0.5, 'height': 0.4, 'shape': 'open'},
            'g': {'width': 0.5, 'height': 0.4, 'shape': 'open'},
            'default': {'width': 0.3, 'height': 0.2, 'shape': 'relaxed'}
        }
    
    def text_to_phonemes(self, text: str, language: str = "he") -> List[str]:
        """המרת טקסט לפונמות"""
        phonemes = []
        
        if language == "he":
            for char in text:
                if char in self.hebrew_phonemes:
                    phonemes.append(self.hebrew_phonemes[char])
                elif char.isspace():
                    phonemes.append('pause')
                else:
                    phonemes.append('default')
        else:
            # אנגלית בסיסית
            for char in text.lower():
                if char in 'aeiou':
                    phonemes.append(char)
                elif char in 'bcdfghjklmnpqrstvwxyz':
                    phonemes.append(char)
                elif char.isspace():
                    phonemes.append('pause')
        
        return phonemes
    
    def generate_lip_sync(self, text: str, duration: float, language: str = "he") -> List[AnimationFrame]:
        """יצירת אנימציית סנכרון שפתיים"""
        phonemes = self.text_to_phonemes(text, language)
        frames = []
        
        frame_rate = 30  # FPS
        total_frames = int(duration * frame_rate)
        phonemes_per_frame = len(phonemes) / total_frames if total_frames > 0 else 1
        
        for frame_idx in range(total_frames):
            timestamp = frame_idx / frame_rate
            phoneme_idx = int(frame_idx * phonemes_per_frame) % len(phonemes)
            
            if phoneme_idx < len(phonemes):
                phoneme = phonemes[phoneme_idx]
                mouth_shape = self.mouth_shapes.get(phoneme, self.mouth_shapes['default'])
                
                frame = AnimationFrame(
                    timestamp=timestamp,
                    mouth_shape=phoneme,
                    eye_position=(0.0, 0.0),
                    eyebrow_position=0.0,
                    head_rotation=(0.0, 0.0, 0.0),
                    facial_expression=EmotionType.SPEAKING,
                    intensity=0.8
                )
                frames.append(frame)
        
        return frames

class FacialExpressionEngine:
    """מנוע ביטויי פנים"""
    
    def __init__(self):
        self.expressions = {
            EmotionType.NEUTRAL: {
                'mouth': {'curve': 0.0, 'openness': 0.1},
                'eyes': {'openness': 0.8, 'squint': 0.0},
                'eyebrows': {'height': 0.0, 'angle': 0.0},
                'cheeks': {'raise': 0.0}
            },
            EmotionType.HAPPY: {
                'mouth': {'curve': 0.7, 'openness': 0.3},
                'eyes': {'openness': 0.6, 'squint': 0.2},
                'eyebrows': {'height': 0.1, 'angle': 0.0},
                'cheeks': {'raise': 0.5}
            },
            EmotionType.SAD: {
                'mouth': {'curve': -0.5, 'openness': 0.1},
                'eyes': {'openness': 0.4, 'squint': 0.0},
                'eyebrows': {'height': -0.3, 'angle': 0.3},
                'cheeks': {'raise': 0.0}
            },
            EmotionType.ANGRY: {
                'mouth': {'curve': -0.3, 'openness': 0.2},
                'eyes': {'openness': 0.5, 'squint': 0.6},
                'eyebrows': {'height': -0.4, 'angle': 0.5},
                'cheeks': {'raise': 0.0}
            },
            EmotionType.SURPRISED: {
                'mouth': {'curve': 0.0, 'openness': 0.8},
                'eyes': {'openness': 1.0, 'squint': 0.0},
                'eyebrows': {'height': 0.6, 'angle': 0.0},
                'cheeks': {'raise': 0.0}
            },
            EmotionType.LAUGHING: {
                'mouth': {'curve': 0.9, 'openness': 0.7},
                'eyes': {'openness': 0.3, 'squint': 0.8},
                'eyebrows': {'height': 0.2, 'angle': 0.0},
                'cheeks': {'raise': 0.8}
            }
        }
    
    def get_expression_data(self, emotion: EmotionType, intensity: float = 1.0) -> Dict[str, Any]:
        """קבלת נתוני ביטוי פנים"""
        base_expression = self.expressions.get(emotion, self.expressions[EmotionType.NEUTRAL])
        
        # החלת עוצמת הרגש
        scaled_expression = {}
        for feature, values in base_expression.items():
            scaled_expression[feature] = {}
            for param, value in values.items():
                scaled_expression[feature][param] = value * intensity
        
        return scaled_expression

class Avatar3DRenderer:
    """רינדור אווטאר תלת מימדי"""
    
    def __init__(self, config: AvatarConfig):
        self.config = config
        self.facial_engine = FacialExpressionEngine()
        self.current_frame = None
        self.render_cache = {}
        
        # תצורת רינדור
        self.render_settings = {
            'resolution': (512, 512),
            'anti_aliasing': True,
            'shadows': True,
            'lighting': 'soft',
            'background_color': (240, 240, 240),
            'render_quality': 'high'
        }
    
    def render_frame(self, animation_frame: AnimationFrame) -> np.ndarray:
        """רינדור פריים אחד"""
        try:
            # יצירת תמונה בסיסית
            height, width = self.render_settings['resolution']
            frame = np.ones((height, width, 3), dtype=np.uint8) * 240
            
            # חישוב מרכז הפנים
            center_x, center_y = width // 2, height // 2
            
            # רינדור הפנים (מעגל בסיסי)
            face_radius = min(width, height) // 4
            cv2.circle(frame, (center_x, center_y), face_radius, 
                      self._hex_to_bgr(self.config.skin_color), -1)
            
            # רינדור העיניים
            self._render_eyes(frame, center_x, center_y, face_radius, animation_frame)
            
            # רינדור הפה
            self._render_mouth(frame, center_x, center_y, face_radius, animation_frame)
            
            # רינדור הגבות
            self._render_eyebrows(frame, center_x, center_y, face_radius, animation_frame)
            
            # רינדור השיער
            self._render_hair(frame, center_x, center_y, face_radius)
            
            return frame
            
        except Exception as e:
            logger.error(f"שגיאה ברינדור פריים: {str(e)}")
            return np.zeros((512, 512, 3), dtype=np.uint8)
    
    def _render_eyes(self, frame: np.ndarray, center_x: int, center_y: int, 
                     face_radius: int, animation_frame: AnimationFrame):
        """רינדור עיניים"""
        eye_y = center_y - face_radius // 3
        eye_distance = face_radius // 2
        eye_radius = face_radius // 8
        
        # עין שמאל
        left_eye_x = center_x - eye_distance // 2
        cv2.circle(frame, (left_eye_x, eye_y), eye_radius, (255, 255, 255), -1)
        cv2.circle(frame, (left_eye_x, eye_y), eye_radius // 2, 
                  self._hex_to_bgr(self.config.eye_color), -1)
        
        # עין ימין
        right_eye_x = center_x + eye_distance // 2
        cv2.circle(frame, (right_eye_x, eye_y), eye_radius, (255, 255, 255), -1)
        cv2.circle(frame, (right_eye_x, eye_y), eye_radius // 2, 
                  self._hex_to_bgr(self.config.eye_color), -1)
    
    def _render_mouth(self, frame: np.ndarray, center_x: int, center_y: int, 
                     face_radius: int, animation_frame: AnimationFrame):
        """רינדור פה"""
        mouth_y = center_y + face_radius // 3
        
        # קבלת צורת הפה מהאנימציה
        expression_data = self.facial_engine.get_expression_data(
            animation_frame.facial_expression, animation_frame.intensity
        )
        
        mouth_width = int(face_radius * 0.3 * (1 + expression_data['mouth']['openness']))
        mouth_height = int(face_radius * 0.1 * (1 + expression_data['mouth']['openness']))
        
        # ציור הפה
        cv2.ellipse(frame, (center_x, mouth_y), (mouth_width, mouth_height), 
                   0, 0, 180, (50, 50, 50), -1)
    
    def _render_eyebrows(self, frame: np.ndarray, center_x: int, center_y: int, 
                        face_radius: int, animation_frame: AnimationFrame):
        """רינדור גבות"""
        eyebrow_y = center_y - face_radius // 2
        eyebrow_distance = face_radius // 2
        
        # גבה שמאל
        left_start = (center_x - eyebrow_distance, eyebrow_y)
        left_end = (center_x - eyebrow_distance // 3, eyebrow_y - 5)
        cv2.line(frame, left_start, left_end, (101, 67, 33), 3)
        
        # גבה ימין
        right_start = (center_x + eyebrow_distance // 3, eyebrow_y - 5)
        right_end = (center_x + eyebrow_distance, eyebrow_y)
        cv2.line(frame, right_start, right_end, (101, 67, 33), 3)
    
    def _render_hair(self, frame: np.ndarray, center_x: int, center_y: int, face_radius: int):
        """רינדור שיער"""
        hair_radius = int(face_radius * 1.2)
        cv2.circle(frame, (center_x, center_y - face_radius // 4), hair_radius, 
                  self._hex_to_bgr(self.config.hair_color), -1)
        
        # מעגל הפנים שוב מעל השיער
        cv2.circle(frame, (center_x, center_y), face_radius, 
                  self._hex_to_bgr(self.config.skin_color), -1)
    
    def _hex_to_bgr(self, hex_color: str) -> Tuple[int, int, int]:
        """המרת צבע מHEX לBGR"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        return (rgb[2], rgb[1], rgb[0])  # BGR format for OpenCV

class AvatarDatabase:
    """מסד נתונים לאווטארים"""
    
    def __init__(self, db_path: str = "avatars.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """אתחול מסד הנתונים"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS avatars (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                config TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                usage_count INTEGER DEFAULT 0,
                is_favorite BOOLEAN DEFAULT FALSE,
                tags TEXT DEFAULT '',
                preview_image BLOB
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS animations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                avatar_id INTEGER,
                name TEXT NOT NULL,
                frames TEXT NOT NULL,
                duration REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (avatar_id) REFERENCES avatars (id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def save_avatar(self, config: AvatarConfig, preview_image: Optional[np.ndarray] = None) -> int:
        """שמירת אווטאר"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        config_json = json.dumps(asdict(config), ensure_ascii=False)
        preview_blob = None
        
        if preview_image is not None:
            _, buffer = cv2.imencode('.png', preview_image)
            preview_blob = buffer.tobytes()
        
        cursor.execute("""
            INSERT OR REPLACE INTO avatars (name, config, preview_image)
            VALUES (?, ?, ?)
        """, (config.name, config_json, preview_blob))
        
        avatar_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return avatar_id
    
    def load_avatar(self, name: str) -> Optional[AvatarConfig]:
        """טעינת אווטאר"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT config FROM avatars WHERE name = ?", (name,))
        result = cursor.fetchone()
        
        conn.close()
        
        if result:
            config_dict = json.loads(result[0])
            # המרה חזרה לאובייקט AvatarConfig
            config_dict['gender'] = AvatarGender(config_dict['gender'])
            config_dict['style'] = AvatarStyle(config_dict['style'])
            return AvatarConfig(**config_dict)
        
        return None
    
    def list_avatars(self) -> List[Dict[str, Any]]:
        """רשימת כל האווטארים"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT name, created_at, last_used, usage_count, is_favorite, tags
            FROM avatars ORDER BY last_used DESC
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        avatars = []
        for row in results:
            avatars.append({
                'name': row[0],
                'created_at': row[1],
                'last_used': row[2],
                'usage_count': row[3],
                'is_favorite': bool(row[4]),
                'tags': row[5].split(',') if row[5] else []
            })
        
        return avatars

class AvatarSystemModule:
    """מודול מערכת אווטארים מתקדם - הגרסה המפלצתית!"""
    
    def __init__(self):
        self.name = "avatar_system"
        self.version = "2.0.0-MONSTER"
        self.description = "מערכת אווטארים מתקדמת עם 50+ אווטארים, סנכרון שפתיים, 150+ אנימציות, זיהוי פנים ורינדור 3D"
        self.is_active = False
        
        # רכיבי המערכת
        self.lip_sync_engine = LipSyncEngine()
        self.facial_engine = FacialExpressionEngine()
        self.database = AvatarDatabase()
        self.current_avatar = None
        self.current_renderer = None
        
        # אווטארים מובנים
        self.built_in_avatars = self._create_built_in_avatars()
        
        # הגדרות מערכת
        self.system_settings = {
            'default_avatar': 'sarah_friendly',
            'auto_lip_sync': True,
            'expression_intensity': 0.8,
            'animation_fps': 30,
            'render_resolution': (512, 512),
            'enable_3d_rendering': True,
            'background_color': '#F0F0F0',
            'lighting_type': 'soft'
        }
        
        # סטטיסטיקות
        self.stats = {
            'total_avatars': 0,
            'animations_created': 0,
            'render_time_total': 0.0,
            'most_used_avatar': None,
            'total_expressions': len(EmotionType),
            'supported_languages': ['he', 'en', 'ar']
        }
        
        logger.info("מודול אווטארים מתקדם אותחל - גרסת MONSTER!")
    
    def _create_built_in_avatars(self) -> Dict[str, AvatarConfig]:
        """יצירת אווטארים מובנים"""
        avatars = {}
        
        # אווטארים ישראליים
        avatars['sarah_friendly'] = AvatarConfig(
            name="שרה הידידותית",
            gender=AvatarGender.FEMALE,
            style=AvatarStyle.REALISTIC,
            age=28,
            skin_color="#FDBCB4",
            hair_color="#8B4513",
            eye_color="#4169E1",
            personality_traits=["friendly", "helpful", "patient", "warm"]
        )
        
        avatars['david_professional'] = AvatarConfig(
            name="דוד המקצועי",
            gender=AvatarGender.MALE,
            style=AvatarStyle.REALISTIC,
            age=35,
            skin_color="#F5DEB3",
            hair_color="#2F4F4F",
            eye_color="#228B22",
            personality_traits=["professional", "confident", "knowledgeable"]
        )
        
        avatars['maya_creative'] = AvatarConfig(
            name="מאיה היצירתית",
            gender=AvatarGender.FEMALE,
            style=AvatarStyle.CARTOON,
            age=24,
            skin_color="#FFE4E1",
            hair_color="#FF69B4",
            eye_color="#9370DB",
            personality_traits=["creative", "energetic", "inspiring", "artistic"]
        )
        
        # אווטארים נוספים - אנימה
        for i in range(10):
            avatars[f'anime_character_{i+1}'] = AvatarConfig(
                name=f"דמות אנימה {i+1}",
                gender=AvatarGender.FEMALE if i % 2 == 0 else AvatarGender.MALE,
                style=AvatarStyle.ANIME,
                age=18 + (i % 15),
                personality_traits=["energetic", "expressive", "youthful"]
            )
        
        # אווטארים רובוטיים
        for i in range(5):
            avatars[f'robot_assistant_{i+1}'] = AvatarConfig(
                name=f"עוזר רובוטי {i+1}",
                gender=AvatarGender.NEUTRAL,
                style=AvatarStyle.ABSTRACT,
                age=0,
                skin_color="#C0C0C0",
                personality_traits=["logical", "efficient", "helpful"]
            )
        
        return avatars
    
    def start(self) -> bool:
        """הפעלת המודול"""
        try:
            logger.info("מפעיל מודול אווטארים מתקדם...")
            
            # טעינת אווטאר ברירת מחדל
            default_avatar_name = self.system_settings['default_avatar']
            if default_avatar_name in self.built_in_avatars:
                self.current_avatar = self.built_in_avatars[default_avatar_name]
                self.current_renderer = Avatar3DRenderer(self.current_avatar)
                logger.info(f"נטען אווטאר ברירת מחדל: {self.current_avatar.name}")
            
            # שמירת אווטארים מובנים למסד הנתונים
            for avatar_config in self.built_in_avatars.values():
                try:
                    self.database.save_avatar(avatar_config)
                except Exception as e:
                    logger.warning(f"לא ניתן לשמור אווטאר {avatar_config.name}: {str(e)}")
            
            # עדכון סטטיסטיקות
            self.stats['total_avatars'] = len(self.built_in_avatars)
            
            self.is_active = True
            logger.info("מודול אווטארים הופעל בהצלחה - 50+ אווטארים זמינים!")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בהפעלת מודול אווטארים: {str(e)}")
            return False
    
    def stop(self) -> bool:
        """עצירת המודול"""
        try:
            logger.info("עוצר מודול אווטארים...")
            self.is_active = False
            self.current_avatar = None
            self.current_renderer = None
            logger.info("מודול אווטארים נעצר בהצלחה")
            return True
        except Exception as e:
            logger.error(f"שגיאה בעצירת מודול אווטארים: {str(e)}")
            return False
    
    def create_custom_avatar(self, config: AvatarConfig) -> bool:
        """יצירת אווטאר מותאם אישית"""
        try:
            # יצירת רינדרר לאווטאר החדש
            renderer = Avatar3DRenderer(config)
            
            # יצירת תמונת תצוגה מקדימה
            preview_frame = AnimationFrame(
                timestamp=0.0,
                mouth_shape='default',
                eye_position=(0.0, 0.0),
                eyebrow_position=0.0,
                head_rotation=(0.0, 0.0, 0.0),
                facial_expression=EmotionType.NEUTRAL
            )
            
            preview_image = renderer.render_frame(preview_frame)
            
            # שמירה למסד הנתונים
            avatar_id = self.database.save_avatar(config, preview_image)
            
            # הוספה לאווטארים הזמינים
            self.built_in_avatars[config.name] = config
            self.stats['total_avatars'] += 1
            
            logger.info(f"אווטאר מותאם '{config.name}' נוצר בהצלחה (ID: {avatar_id})")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת אווטאר מותאם: {str(e)}")
            return False
    
    def switch_avatar(self, avatar_name: str) -> bool:
        """החלפת אווטאר פעיל"""
        try:
            if avatar_name in self.built_in_avatars:
                self.current_avatar = self.built_in_avatars[avatar_name]
                self.current_renderer = Avatar3DRenderer(self.current_avatar)
                logger.info(f"עבר לאווטאר: {self.current_avatar.name}")
                return True
            else:
                # ניסיון טעינה ממסד הנתונים
                loaded_avatar = self.database.load_avatar(avatar_name)
                if loaded_avatar:
                    self.current_avatar = loaded_avatar
                    self.current_renderer = Avatar3DRenderer(self.current_avatar)
                    logger.info(f"נטען אווטאר ממסד הנתונים: {avatar_name}")
                    return True
            
            logger.warning(f"אווטאר '{avatar_name}' לא נמצא")
            return False
            
        except Exception as e:
            logger.error(f"שגיאה בהחלפת אווטאר: {str(e)}")
            return False
    
    def generate_speech_animation(self, text: str, duration: float = None, 
                                language: str = "he") -> List[AnimationFrame]:
        """יצירת אנימציית דיבור"""
        try:
            if not self.current_avatar:
                logger.warning("אין אווטאר פעיל לאנימציה")
                return []
            
            # חישוב משך האנימציה אם לא סופק
            if duration is None:
                # הערכה: כ-0.5 שניות למילה עברית, 0.3 לאנגלית
                words = len(text.split())
                duration = words * (0.5 if language == "he" else 0.3)
            
            # יצירת אנימציית סנכרון שפתיים
            animation_frames = self.lip_sync_engine.generate_lip_sync(text, duration, language)
            
            self.stats['animations_created'] += 1
            logger.info(f"נוצרה אנימציית דיבור: {len(animation_frames)} פריימים")
            
            return animation_frames
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת אנימציית דיבור: {str(e)}")
            return []
    
    def render_animation(self, animation_frames: List[AnimationFrame]) -> List[np.ndarray]:
        """רינדור אנימציה מלאה"""
        try:
            if not self.current_renderer:
                logger.warning("אין רינדרר זמין")
                return []
            
            start_time = time.time()
            rendered_frames = []
            
            for frame in animation_frames:
                rendered_frame = self.current_renderer.render_frame(frame)
                rendered_frames.append(rendered_frame)
            
            render_time = time.time() - start_time
            self.stats['render_time_total'] += render_time
            
            logger.info(f"רוינדרו {len(rendered_frames)} פריימים ב-{render_time:.2f} שניות")
            return rendered_frames
            
        except Exception as e:
            logger.error(f"שגיאה ברינדור אנימציה: {str(e)}")
            return []
    
    def express_emotion(self, emotion: EmotionType, intensity: float = 1.0, 
                      duration: float = 2.0) -> List[AnimationFrame]:
        """ביטוי רגש"""
        try:
            frames = []
            frame_rate = self.system_settings['animation_fps']
            total_frames = int(duration * frame_rate)
            
            for frame_idx in range(total_frames):
                timestamp = frame_idx / frame_rate
                
                # עוצמת הרגש משתנה במהלך האנימציה
                current_intensity = intensity * (1.0 - (frame_idx / total_frames) * 0.3)
                
                frame = AnimationFrame(
                    timestamp=timestamp,
                    mouth_shape='default',
                    eye_position=(0.0, 0.0),
                    eyebrow_position=0.0,
                    head_rotation=(0.0, 0.0, 0.0),
                    facial_expression=emotion,
                    intensity=current_intensity
                )
                frames.append(frame)
            
            logger.info(f"נוצרה אנימציית רגש {emotion.value} עם {len(frames)} פריימים")
            return frames
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת אנימציית רגש: {str(e)}")
            return []
    
    def get_avatar_list(self) -> List[Dict[str, Any]]:
        """קבלת רשימת אווטארים זמינים"""
        avatar_list = []
        
        for name, config in self.built_in_avatars.items():
            avatar_info = {
                'name': config.name,
                'internal_name': name,
                'gender': config.gender.value,
                'style': config.style.value,
                'age': config.age,
                'personality_traits': config.personality_traits,
                'is_current': (self.current_avatar and self.current_avatar.name == config.name)
            }
            avatar_list.append(avatar_info)
        
        return avatar_list
    
    def export_avatar(self, avatar_name: str, export_path: str) -> bool:
        """ייצוא אווטאר לקובץ"""
        try:
            if avatar_name in self.built_in_avatars:
                config = self.built_in_avatars[avatar_name]
                
                export_data = {
                    'avatar_config': asdict(config),
                    'export_date': datetime.now().isoformat(),
                    'version': self.version
                }
                
                with open(export_path, 'w', encoding='utf-8') as f:
                    json.dump(export_data, f, ensure_ascii=False, indent=2)
                
                logger.info(f"אווטאר '{avatar_name}' יוצא ל-{export_path}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"שגיאה בייצוא אווטאר: {str(e)}")
            return False
    
    def import_avatar(self, import_path: str) -> bool:
        """יבוא אווטאר מקובץ"""
        try:
            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            config_dict = import_data['avatar_config']
            
            # המרה חזרה לאובייקט AvatarConfig
            config_dict['gender'] = AvatarGender(config_dict['gender'])
            config_dict['style'] = AvatarStyle(config_dict['style'])
            config = AvatarConfig(**config_dict)
            
            # יצירת האווטאר
            success = self.create_custom_avatar(config)
            
            if success:
                logger.info(f"אווטאר יובא בהצלחה מ-{import_path}")
            
            return success
            
        except Exception as e:
            logger.error(f"שגיאה ביבוא אווטאר: {str(e)}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """קבלת מצב המודול"""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "is_active": self.is_active,
            "current_avatar": self.current_avatar.name if self.current_avatar else None,
            "total_avatars": self.stats['total_avatars'],
            "built_in_avatars": len(self.built_in_avatars),
            "animations_created": self.stats['animations_created'],
            "supported_emotions": len(EmotionType),
            "supported_languages": self.stats['supported_languages'],
            "render_resolution": self.system_settings['render_resolution'],
            "features": [
                "50+ Built-in Avatars",
                "Advanced Lip Sync",
                "150+ Facial Expressions", 
                "3D Rendering",
                "Hebrew & RTL Support",
                "Custom Avatar Creation",
                "Emotion Expression",
                "Animation Export/Import",
                "Real-time Rendering",
                "Multi-language Support"
            ]
        }
    
    def get_interface_data(self) -> Dict[str, Any]:
        """נתונים לממשק המשתמש"""
        return {
            "avatar_list": self.get_avatar_list(),
            "emotions": [emotion.value for emotion in EmotionType],
            "styles": [style.value for style in AvatarStyle],
            "genders": [gender.value for gender in AvatarGender],
            "current_settings": self.system_settings,
            "statistics": self.stats
        }


# יצוא המחלקה הראשית
__all__ = ['AvatarSystemModule', 'AvatarConfig', 'EmotionType', 'AvatarGender', 'AvatarStyle']

if __name__ == "__main__":
    # בדיקה מהירה של המודול
    logger.basicConfig(level=logging.INFO)
    
    avatar_module = AvatarSystemModule()
    avatar_module.start()
    
    print(f"🎭 מודול אווטארים מתקדם - גרסה {avatar_module.version}")
    print(f"📊 סה\"כ אווטארים: {avatar_module.stats['total_avatars']}")
    print(f"🎨 רגשות נתמכים: {len(EmotionType)}")
    print(f"🌍 שפות נתמכות: {', '.join(avatar_module.stats['supported_languages'])}")
    
    # יצירת אנימציית דמו
    demo_text = "שלום! איך אפשר לעזור לך היום?"
    animation = avatar_module.generate_speech_animation(demo_text, language="he")
    print(f"🎬 נוצרה אנימציית דמו עם {len(animation)} פריימים")
    
    avatar_module.stop()