"""
Avatar Panel - Main Avatar System Interface
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime

class AvatarPanel:
    """Main avatar system control panel"""
    
    def __init__(self):
        self.panel_id = "avatar_panel"
        self.current_avatar = None
        self.available_presets = []
        self.interaction_history = []
        
    def generate_html(self) -> str:
        """Generate HTML for avatar panel"""
        return f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="he">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>לוח בקרת אווטרים</title>
            {self._generate_css()}
        </head>
        <body>
            <div class="avatar-panel-container">
                <div class="panel-header">
                    <h1>🤖 מערכת אווטרים מתקדמת</h1>
                    <div class="header-controls">
                        <button id="refreshPanel" class="control-btn">🔄 רענן</button>
                        <button id="fullscreenToggle" class="control-btn">⛶ מסך מלא</button>
                        <button id="settingsPanel" class="control-btn">⚙️ הגדרות</button>
                    </div>
                </div>
                
                <div class="main-content">
                    <!-- Avatar Selection Section -->
                    <div class="section avatar-selection">
                        <h2>בחירת אווטר</h2>
                        <div class="avatar-gallery">
                            <div class="avatar-preset" data-preset="israeli_assistant">
                                <div class="avatar-preview">
                                    <div class="avatar-icon">👨‍💼</div>
                                    <div class="avatar-status online"></div>
                                </div>
                                <div class="avatar-info">
                                    <h3>עוזר ישראלי</h3>
                                    <p>עוזר מקצועי עם הבנה תרבותית עמוקה</p>
                                    <div class="avatar-stats">
                                        <span class="stat">📊 יעילות: 94%</span>
                                        <span class="stat">💬 אינטראקציות: 1,247</span>
                                    </div>
                                </div>
                                <button class="select-avatar-btn">בחר אווטר</button>
                            </div>
                            
                            <div class="avatar-preset" data-preset="friendly_guide">
                                <div class="avatar-preview">
                                    <div class="avatar-icon">😊</div>
                                    <div class="avatar-status online"></div>
                                </div>
                                <div class="avatar-info">
                                    <h3>מדריך ידידותי</h3>
                                    <p>מדריך חם וידידותי עם אופי עוזר</p>
                                    <div class="avatar-stats">
                                        <span class="stat">📊 יעילות: 98%</span>
                                        <span class="stat">💬 אינטראקציות: 2,156</span>
                                    </div>
                                </div>
                                <button class="select-avatar-btn">בחר אווטר</button>
                            </div>
                            
                            <div class="avatar-preset" data-preset="tech_expert">
                                <div class="avatar-preview">
                                    <div class="avatar-icon">👩‍💻</div>
                                    <div class="avatar-status online"></div>
                                </div>
                                <div class="avatar-info">
                                    <h3>מומחה טכנולוגיה</h3>
                                    <p>מומחה היי-טק עם ידע טכני מתקדם</p>
                                    <div class="avatar-stats">
                                        <span class="stat">📊 יעילות: 91%</span>
                                        <span class="stat">💬 אינטראקציות: 856</span>
                                    </div>
                                </div>
                                <button class="select-avatar-btn">בחר אווטר</button>
                            </div>
                            
                            <div class="avatar-preset" data-preset="creative_artist">
                                <div class="avatar-preview">
                                    <div class="avatar-icon">🎨</div>
                                    <div class="avatar-status online"></div>
                                </div>
                                <div class="avatar-info">
                                    <h3>אמן יוצר</h3>
                                    <p>אמן יצירתי עם חשיבה מחוץ לקופסה</p>
                                    <div class="avatar-stats">
                                        <span class="stat">📊 יעילות: 89%</span>
                                        <span class="stat">💬 אינטראקציות: 634</span>
                                    </div>
                                </div>
                                <button class="select-avatar-btn">בחר אווטר</button>
                            </div>
                            
                            <div class="avatar-preset" data-preset="wise_teacher">
                                <div class="avatar-preview">
                                    <div class="avatar-icon">👨‍🏫</div>
                                    <div class="avatar-status online"></div>
                                </div>
                                <div class="avatar-info">
                                    <h3>מורה חכם</h3>
                                    <p>מורה מנוסה עם ידע עמוק וסבלנות</p>
                                    <div class="avatar-stats">
                                        <span class="stat">📊 יעילות: 96%</span>
                                        <span class="stat">💬 אינטראקציות: 1,423</span>
                                    </div>
                                </div>
                                <button class="select-avatar-btn">בחר אווטר</button>
                            </div>
                            
                            <div class="avatar-preset create-new">
                                <div class="create-icon">➕</div>
                                <div class="create-info">
                                    <h3>צור אווטר חדש</h3>
                                    <p>עצב אווטר מותאם אישית</p>
                                </div>
                                <button class="create-avatar-btn">התחל יצירה</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Current Avatar Section -->
                    <div class="section current-avatar" id="currentAvatarSection" style="display: none;">
                        <h2>אווטר נוכחי</h2>
                        <div class="avatar-display">
                            <div class="avatar-viewport">
                                <div class="avatar-3d-view">
                                    <div class="avatar-model" id="avatarModel">
                                        <div class="avatar-face">
                                            <div class="eyes">
                                                <div class="eye left-eye"></div>
                                                <div class="eye right-eye"></div>
                                            </div>
                                            <div class="mouth" id="avatarMouth"></div>
                                        </div>
                                    </div>
                                    <div class="avatar-controls-overlay">
                                        <button class="control-btn" id="emotionBtn">😊 רגשות</button>
                                        <button class="control-btn" id="gestureBtn">👋 מחוות</button>
                                        <button class="control-btn" id="voiceBtn">🎤 קול</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="avatar-info-panel">
                                <div class="avatar-details">
                                    <h3 id="avatarName">שם האווטר</h3>
                                    <p id="avatarDescription">תיאור האווטר</p>
                                    
                                    <div class="avatar-metrics">
                                        <div class="metric">
                                            <span class="metric-label">רגש נוכחי</span>
                                            <span class="metric-value" id="currentEmotion">נייטרלי</span>
                                        </div>
                                        <div class="metric">
                                            <span class="metric-label">עוצמת רגש</span>
                                            <div class="intensity-bar">
                                                <div class="intensity-fill" id="emotionIntensity" style="width: 50%"></div>
                                            </div>
                                        </div>
                                        <div class="metric">
                                            <span class="metric-label">מצב קול</span>
                                            <span class="metric-value" id="voiceState">מוכן</span>
                                        </div>
                                        <div class="metric">
                                            <span class="metric-label">אנימציה</span>
                                            <span class="metric-value" id="animationState">במנוחה</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="quick-actions">
                                    <h4>פעולות מהירות</h4>
                                    <div class="action-buttons">
                                        <button class="action-btn emotion" data-emotion="happy">😊 שמח</button>
                                        <button class="action-btn emotion" data-emotion="thinking">🤔 חושב</button>
                                        <button class="action-btn emotion" data-emotion="excited">🤩 נרגש</button>
                                        <button class="action-btn gesture" data-gesture="wave">👋 נפנף</button>
                                        <button class="action-btn gesture" data-gesture="point">👉 הצבע</button>
                                        <button class="action-btn gesture" data-gesture="shrug">🤷 משך כתפיים</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Interaction Section -->
                    <div class="section interaction-area">
                        <h2>אזור אינטראקציה</h2>
                        <div class="interaction-interface">
                            <div class="conversation-area">
                                <div class="conversation-history" id="conversationHistory">
                                    <div class="message user-message">
                                        <div class="message-avatar">👤</div>
                                        <div class="message-content">
                                            <p>שלום! איך אתה יכול לעזור לי היום?</p>
                                            <span class="message-time">14:32</span>
                                        </div>
                                    </div>
                                    <div class="message avatar-message">
                                        <div class="message-avatar">🤖</div>
                                        <div class="message-content">
                                            <p>שלום וברוכים הבאים! אני כאן לעזור לך בכל שאלה או משימה. איך אפשר לסייע?</p>
                                            <span class="message-time">14:32</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="input-area">
                                    <div class="input-controls">
                                        <button class="input-btn" id="voiceInputBtn">🎤 קלט קולי</button>
                                        <button class="input-btn" id="emojiBtn">😊 אמוטיקונים</button>
                                        <button class="input-btn" id="attachBtn">📎 צרף קובץ</button>
                                    </div>
                                    <div class="text-input-container">
                                        <textarea id="messageInput" placeholder="כתוב הודעה..." rows="3"></textarea>
                                        <button id="sendMessage" class="send-btn">שלח</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="interaction-controls">
                                <div class="control-group">
                                    <h4>בקרת אינטראקציה</h4>
                                    <div class="control-item">
                                        <label>מהירות תגובה</label>
                                        <input type="range" id="responseSpeed" min="0.5" max="2" value="1" step="0.1">
                                        <span id="responseSpeedValue">1.0x</span>
                                    </div>
                                    <div class="control-item">
                                        <label>רמת ביטוי רגשי</label>
                                        <input type="range" id="emotionalExpression" min="0" max="1" value="0.7" step="0.1">
                                        <span id="emotionalExpressionValue">70%</span>
                                    </div>
                                    <div class="control-item">
                                        <label>תדירות מחוות</label>
                                        <input type="range" id="gestureFrequency" min="0" max="1" value="0.8" step="0.1">
                                        <span id="gestureFrequencyValue">80%</span>
                                    </div>
                                </div>
                                
                                <div class="control-group">
                                    <h4>הגדרות תרבותיות</h4>
                                    <div class="control-item">
                                        <label>רמת ישירות</label>
                                        <input type="range" id="directnessLevel" min="0" max="1" value="0.8" step="0.1">
                                        <span id="directnessValue">80%</span>
                                    </div>
                                    <div class="control-item">
                                        <label>חמימות</label>
                                        <input type="range" id="warmthLevel" min="0" max="1" value="0.9" step="0.1">
                                        <span id="warmthValue">90%</span>
                                    </div>
                                    <div class="control-item">
                                        <label>שימוש בהומור</label>
                                        <input type="range" id="humorLevel" min="0" max="1" value="0.5" step="0.1">
                                        <span id="humorValue">50%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Statistics Section -->
                    <div class="section statistics">
                        <h2>סטטיסטיקות ומדדים</h2>
                        <div class="stats-grid">
                            <div class="stat-card">
                                <h3>ביצועי מערכת</h3>
                                <div class="stat-items">
                                    <div class="stat-item">
                                        <span class="stat-label">FPS ממוצע</span>
                                        <span class="stat-value" id="averageFPS">30</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">זמן עיבוד</span>
                                        <span class="stat-value" id="processingTime">245ms</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">עומס מערכת</span>
                                        <div class="load-bar">
                                            <div class="load-fill" id="systemLoad" style="width: 35%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <h3>אינטראקציות</h3>
                                <div class="stat-items">
                                    <div class="stat-item">
                                        <span class="stat-label">הודעות היום</span>
                                        <span class="stat-value" id="todayMessages">147</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">זמן דיבור</span>
                                        <span class="stat-value" id="speakingTime">12:34</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">שביעות רצון</span>
                                        <div class="satisfaction-bar">
                                            <div class="satisfaction-fill" style="width: 92%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <h3>למידה והתאמה</h3>
                                <div class="stat-items">
                                    <div class="stat-item">
                                        <span class="stat-label">העדפות נלמדות</span>
                                        <span class="stat-value" id="learnedPreferences">23</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">התאמות תרבותיות</span>
                                        <span class="stat-value" id="culturalAdaptations">8</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-label">שיפור ביצועים</span>
                                        <span class="stat-value improvement">+12%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Floating Action Menu -->
                <div class="floating-menu" id="floatingMenu">
                    <button class="fab-main" id="fabMain">⚙️</button>
                    <div class="fab-options" id="fabOptions">
                        <button class="fab-option" data-action="save">💾 שמור</button>
                        <button class="fab-option" data-action="export">📤 ייצא</button>
                        <button class="fab-option" data-action="import">📥 ייבא</button>
                        <button class="fab-option" data-action="reset">🔄 איפוס</button>
                        <button class="fab-option" data-action="help">❓ עזרה</button>
                    </div>
                </div>
                
                <!-- Status Bar -->
                <div class="status-bar">
                    <div class="status-left">
                        <span class="status-item">🟢 מחובר</span>
                        <span class="status-item">⚡ ביצועים טובים</span>
                        <span class="status-item" id="avatarStatus">🤖 מוכן</span>
                    </div>
                    <div class="status-right">
                        <span class="status-item" id="currentTime">14:32</span>
                        <span class="status-item">🌐 עברית</span>
                    </div>
                </div>
            </div>
            
            {self._generate_javascript()}
        </body>
        </html>
        """
    
    def _generate_css(self) -> str:
        """Generate CSS for avatar panel"""
        return """
        <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
            direction: rtl;
            overflow-x: hidden;
        }
        
        .avatar-panel-container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .panel-header {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .panel-header h1 {
            font-size: 2rem;
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0;
        }
        
        .header-controls {
            display: flex;
            gap: 10px;
        }
        
        .control-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .control-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .main-content {
            flex: 1;
            display: grid;
            gap: 20px;
        }
        
        .section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .section:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .section h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        
        /* Avatar Gallery Styles */
        .avatar-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .avatar-preset {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 15px;
            padding: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .avatar-preset:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
        
        .avatar-preset.create-new {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            min-height: 200px;
        }
        
        .avatar-preview {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            margin-bottom: 15px;
        }
        
        .avatar-icon {
            font-size: 3rem;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-bottom: 10px;
        }
        
        .avatar-status {
            position: absolute;
            bottom: 5px;
            right: 5px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            border: 2px solid white;
        }
        
        .avatar-status.online {
            background: #4CAF50;
        }
        
        .avatar-info h3 {
            font-size: 1.2rem;
            margin-bottom: 8px;
            color: #333;
        }
        
        .avatar-info p {
            color: #666;
            margin-bottom: 15px;
            line-height: 1.4;
        }
        
        .avatar-stats {
            display: flex;
            flex-direction: column;
            gap: 5px;
            margin-bottom: 15px;
        }
        
        .stat {
            font-size: 0.9rem;
            color: #555;
        }
        
        .select-avatar-btn, .create-avatar-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .select-avatar-btn:hover, .create-avatar-btn:hover {
            background: linear-gradient(45deg, #5a6fd8, #6841a0);
            transform: translateY(-2px);
        }
        
        .create-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.8;
        }
        
        .create-info h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        
        .create-info p {
            margin-bottom: 20px;
            opacity: 0.9;
        }
        
        /* Current Avatar Styles */
        .avatar-display {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        
        .avatar-viewport {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 20px;
            position: relative;
            min-height: 300px;
        }
        
        .avatar-3d-view {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .avatar-model {
            width: 150px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            backdrop-filter: blur(10px);
        }
        
        .avatar-face {
            position: relative;
        }
        
        .eyes {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .eye {
            width: 15px;
            height: 15px;
            background: white;
            border-radius: 50%;
            position: relative;
        }
        
        .eye::after {
            content: '';
            position: absolute;
            top: 2px;
            left: 2px;
            width: 6px;
            height: 6px;
            background: #333;
            border-radius: 50%;
            animation: blink 3s infinite;
        }
        
        .mouth {
            width: 30px;
            height: 15px;
            border: 2px solid white;
            border-top: none;
            border-radius: 0 0 30px 30px;
            margin: 0 auto;
        }
        
        @keyframes blink {
            0%, 90%, 100% { transform: scaleY(1); }
            95% { transform: scaleY(0.1); }
        }
        
        .avatar-controls-overlay {
            position: absolute;
            bottom: 15px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
        }
        
        .avatar-controls-overlay .control-btn {
            padding: 8px 12px;
            font-size: 0.9rem;
        }
        
        .avatar-info-panel {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .avatar-details {
            background: rgba(102, 126, 234, 0.1);
            padding: 20px;
            border-radius: 15px;
        }
        
        .avatar-details h3 {
            font-size: 1.4rem;
            margin-bottom: 10px;
            color: #667eea;
        }
        
        .avatar-details p {
            color: #666;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        .avatar-metrics {
            display: grid;
            gap: 15px;
        }
        
        .metric {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .metric-label {
            font-weight: bold;
            color: #555;
        }
        
        .metric-value {
            font-weight: bold;
            color: #667eea;
        }
        
        .intensity-bar {
            width: 100px;
            height: 8px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .intensity-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        .quick-actions {
            background: rgba(102, 126, 234, 0.1);
            padding: 20px;
            border-radius: 15px;
        }
        
        .quick-actions h4 {
            margin-bottom: 15px;
            color: #555;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 10px;
        }
        
        .action-btn {
            padding: 10px 12px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        /* Interaction Styles */
        .interaction-interface {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .conversation-area {
            display: flex;
            flex-direction: column;
            height: 500px;
        }
        
        .conversation-history {
            flex: 1;
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            overflow-y: auto;
            margin-bottom: 20px;
        }
        
        .message {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: flex-start;
        }
        
        .message.user-message {
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(45deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            flex-shrink: 0;
        }
        
        .message-content {
            background: white;
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 70%;
            position: relative;
        }
        
        .user-message .message-content {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        
        .message-content p {
            margin: 0;
            line-height: 1.4;
        }
        
        .message-time {
            font-size: 0.8rem;
            opacity: 0.7;
            display: block;
            margin-top: 5px;
        }
        
        .input-area {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .input-controls {
            display: flex;
            gap: 10px;
        }
        
        .input-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .input-btn:hover {
            background: rgba(102, 126, 234, 0.2);
        }
        
        .text-input-container {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        #messageInput {
            flex: 1;
            padding: 12px;
            border: 2px solid rgba(102, 126, 234, 0.2);
            border-radius: 10px;
            font-family: inherit;
            font-size: 1rem;
            resize: vertical;
            min-height: 80px;
        }
        
        #messageInput:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .send-btn {
            padding: 12px 20px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .send-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .interaction-controls {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        
        .control-group {
            background: rgba(102, 126, 234, 0.1);
            padding: 20px;
            border-radius: 15px;
        }
        
        .control-group h4 {
            margin-bottom: 15px;
            color: #555;
        }
        
        .control-item {
            margin-bottom: 15px;
        }
        
        .control-item label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        
        .control-item input[type="range"] {
            width: 100%;
            margin-bottom: 5px;
        }
        
        .control-item span {
            font-size: 0.9rem;
            color: #667eea;
            font-weight: bold;
        }
        
        /* Statistics Styles */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            padding: 20px;
            border-radius: 15px;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card h3 {
            margin-bottom: 15px;
            color: #667eea;
            font-size: 1.2rem;
        }
        
        .stat-items {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-label {
            color: #555;
            font-weight: 500;
        }
        
        .stat-value {
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-value.improvement {
            color: #4CAF50;
        }
        
        .load-bar, .satisfaction-bar {
            width: 100px;
            height: 8px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .load-fill, .satisfaction-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        /* Floating Menu */
        .floating-menu {
            position: fixed;
            bottom: 30px;
            left: 30px;
            z-index: 1000;
        }
        
        .fab-main {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }
        
        .fab-main:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
        }
        
        .fab-options {
            position: absolute;
            bottom: 70px;
            left: 0;
            display: none;
            flex-direction: column;
            gap: 10px;
        }
        
        .fab-options.show {
            display: flex;
            animation: fadeInUp 0.3s ease;
        }
        
        .fab-option {
            padding: 12px 20px;
            border: none;
            border-radius: 25px;
            background: white;
            color: #667eea;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            white-space: nowrap;
        }
        
        .fab-option:hover {
            background: #667eea;
            color: white;
            transform: translateX(10px);
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Status Bar */
        .status-bar {
            background: rgba(255, 255, 255, 0.9);
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
        }
        
        .status-left, .status-right {
            display: flex;
            gap: 20px;
        }
        
        .status-item {
            font-size: 0.9rem;
            color: #555;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .avatar-panel-container {
                padding: 10px;
            }
            
            .panel-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .avatar-gallery {
                grid-template-columns: 1fr;
            }
            
            .avatar-display {
                grid-template-columns: 1fr;
            }
            
            .interaction-interface {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .floating-menu {
                bottom: 20px;
                left: 20px;
            }
            
            .status-bar {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
        </style>
        """
    
    def _generate_javascript(self) -> str:
        """Generate JavaScript for avatar panel"""
        return """
        <script>
        class AvatarPanelController {
            constructor() {
                this.currentAvatar = null;
                this.conversationHistory = [];
                this.systemMetrics = {};
                this.isVoiceRecording = false;
                
                this.initializeEventListeners();
                this.startRealTimeUpdates();
                this.updateTime();
            }
            
            initializeEventListeners() {
                // Avatar selection
                document.querySelectorAll('.select-avatar-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const preset = e.target.closest('.avatar-preset').dataset.preset;
                        this.selectAvatar(preset);
                    });
                });
                
                // Create new avatar
                document.querySelector('.create-avatar-btn')?.addEventListener('click', () => {
                    this.openAvatarCreator();
                });
                
                // Quick actions
                document.querySelectorAll('.action-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        if (btn.classList.contains('emotion')) {
                            this.triggerEmotion(btn.dataset.emotion);
                        } else if (btn.classList.contains('gesture')) {
                            this.triggerGesture(btn.dataset.gesture);
                        }
                    });
                });
                
                // Message sending
                document.getElementById('sendMessage').addEventListener('click', () => {
                    this.sendMessage();
                });
                
                document.getElementById('messageInput').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.sendMessage();
                    }
                });
                
                // Voice input
                document.getElementById('voiceInputBtn').addEventListener('click', () => {
                    this.toggleVoiceInput();
                });
                
                // Control sliders
                this.initializeControlSliders();
                
                // Floating menu
                document.getElementById('fabMain').addEventListener('click', () => {
                    this.toggleFloatingMenu();
                });
                
                document.querySelectorAll('.fab-option').forEach(option => {
                    option.addEventListener('click', (e) => {
                        this.handleFabAction(e.target.dataset.action);
                    });
                });
                
                // Header controls
                document.getElementById('refreshPanel').addEventListener('click', () => {
                    this.refreshPanel();
                });
                
                document.getElementById('fullscreenToggle').addEventListener('click', () => {
                    this.toggleFullscreen();
                });
                
                document.getElementById('settingsPanel').addEventListener('click', () => {
                    this.openSettings();
                });
            }
            
            initializeControlSliders() {
                const sliders = [
                    'responseSpeed', 'emotionalExpression', 'gestureFrequency',
                    'directnessLevel', 'warmthLevel', 'humorLevel'
                ];
                
                sliders.forEach(sliderId => {
                    const slider = document.getElementById(sliderId);
                    const valueDisplay = document.getElementById(sliderId + 'Value');
                    
                    if (slider && valueDisplay) {
                        slider.addEventListener('input', (e) => {
                            const value = parseFloat(e.target.value);
                            this.updateSliderDisplay(sliderId, value);
                            this.updateAvatarSetting(sliderId, value);
                        });
                    }
                });
            }
            
            updateSliderDisplay(sliderId, value) {
                const valueDisplay = document.getElementById(sliderId + 'Value');
                if (valueDisplay) {
                    if (sliderId === 'responseSpeed') {
                        valueDisplay.textContent = value.toFixed(1) + 'x';
                    } else {
                        valueDisplay.textContent = Math.round(value * 100) + '%';
                    }
                }
            }
            
            selectAvatar(preset) {
                this.currentAvatar = preset;
                
                // Update UI to show selected avatar
                document.getElementById('currentAvatarSection').style.display = 'block';
                
                // Update avatar info based on preset
                const avatarInfo = this.getAvatarInfo(preset);
                document.getElementById('avatarName').textContent = avatarInfo.name;
                document.getElementById('avatarDescription').textContent = avatarInfo.description;
                
                // Update metrics
                document.getElementById('currentEmotion').textContent = 'נייטרלי';
                document.getElementById('emotionIntensity').style.width = '50%';
                document.getElementById('voiceState').textContent = 'מוכן';
                document.getElementById('animationState').textContent = 'במנוחה';
                
                // Add selection animation
                this.animateAvatarSelection();
                
                this.showNotification('אווטר נבחר בהצלחה: ' + avatarInfo.name, 'success');
            }
            
            getAvatarInfo(preset) {
                const presets = {
                    'israeli_assistant': {
                        name: 'עוזר ישראלי',
                        description: 'עוזר מקצועי עם הבנה תרבותית עמוקה'
                    },
                    'friendly_guide': {
                        name: 'מדריך ידידותי',
                        description: 'מדריך חם וידידותי עם אופי עוזר'
                    },
                    'tech_expert': {
                        name: 'מומחה טכנולוגיה',
                        description: 'מומחה היי-טק עם ידע טכני מתקדם'
                    },
                    'creative_artist': {
                        name: 'אמן יוצר',
                        description: 'אמן יצירתי עם חשיבה מחוץ לקופסה'
                    },
                    'wise_teacher': {
                        name: 'מורה חכם',
                        description: 'מורה מנוסה עם ידע עמוק וסבלנות'
                    }
                };
                
                return presets[preset] || { name: 'אווטר', description: 'תיאור אווטר' };
            }
            
            animateAvatarSelection() {
                const avatarModel = document.getElementById('avatarModel');
                avatarModel.style.animation = 'pulse 0.5s ease';
                
                setTimeout(() => {
                    avatarModel.style.animation = '';
                }, 500);
            }
            
            triggerEmotion(emotion) {
                if (!this.currentAvatar) {
                    this.showNotification('בחר אווטר תחילה', 'warning');
                    return;
                }
                
                // Update emotion display
                const emotionNames = {
                    'happy': 'שמח',
                    'thinking': 'חושב',
                    'excited': 'נרגש'
                };
                
                document.getElementById('currentEmotion').textContent = emotionNames[emotion] || emotion;
                
                // Animate emotion change
                const mouth = document.getElementById('avatarMouth');
                
                if (emotion === 'happy') {
                    mouth.style.borderRadius = '30px 30px 0 0';
                    mouth.style.borderTop = '2px solid white';
                    mouth.style.borderBottom = 'none';
                    document.getElementById('emotionIntensity').style.width = '80%';
                } else if (emotion === 'thinking') {
                    mouth.style.borderRadius = '0 0 30px 30px';
                    mouth.style.borderTop = 'none';
                    mouth.style.borderBottom = '2px solid white';
                    document.getElementById('emotionIntensity').style.width = '40%';
                } else if (emotion === 'excited') {
                    mouth.style.borderRadius = '50%';
                    mouth.style.border = '2px solid white';
                    document.getElementById('emotionIntensity').style.width = '95%';
                }
                
                this.showNotification('רגש הופעל: ' + emotionNames[emotion], 'success');
                
                // Reset after delay
                setTimeout(() => {
                    mouth.style.borderRadius = '0 0 30px 30px';
                    mouth.style.borderTop = 'none';
                    mouth.style.borderBottom = '2px solid white';
                    document.getElementById('currentEmotion').textContent = 'נייטרלי';
                    document.getElementById('emotionIntensity').style.width = '50%';
                }, 3000);
            }
            
            triggerGesture(gesture) {
                if (!this.currentAvatar) {
                    this.showNotification('בחר אווטר תחילה', 'warning');
                    return;
                }
                
                const gestureNames = {
                    'wave': 'נפנף',
                    'point': 'הצבע',
                    'shrug': 'משך כתפיים'
                };
                
                // Animate gesture
                const avatarModel = document.getElementById('avatarModel');
                
                if (gesture === 'wave') {
                    avatarModel.style.transform = 'rotate(5deg)';
                    setTimeout(() => {
                        avatarModel.style.transform = 'rotate(-5deg)';
                        setTimeout(() => {
                            avatarModel.style.transform = 'rotate(0deg)';
                        }, 200);
                    }, 200);
                } else if (gesture === 'point') {
                    avatarModel.style.transform = 'translateX(10px)';
                    setTimeout(() => {
                        avatarModel.style.transform = 'translateX(0)';
                    }, 500);
                } else if (gesture === 'shrug') {
                    avatarModel.style.transform = 'translateY(-10px)';
                    setTimeout(() => {
                        avatarModel.style.transform = 'translateY(0)';
                    }, 300);
                }
                
                this.showNotification('מחווה הופעלה: ' + gestureNames[gesture], 'success');
            }
            
            sendMessage() {
                const messageInput = document.getElementById('messageInput');
                const message = messageInput.value.trim();
                
                if (!message) return;
                
                if (!this.currentAvatar) {
                    this.showNotification('בחר אווטר תחילה', 'warning');
                    return;
                }
                
                // Add user message to conversation
                this.addMessageToConversation(message, 'user');
                
                // Clear input
                messageInput.value = '';
                
                // Simulate avatar response
                setTimeout(() => {
                    const response = this.generateAvatarResponse(message);
                    this.addMessageToConversation(response, 'avatar');
                    
                    // Trigger talking animation
                    this.animateTalking(response.length * 50);
                }, 1000 + Math.random() * 2000);
            }
            
            addMessageToConversation(message, sender) {
                const conversationHistory = document.getElementById('conversationHistory');
                const messageEl = document.createElement('div');
                messageEl.className = `message ${sender}-message`;
                
                const currentTime = new Date().toLocaleTimeString('he-IL', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                
                const avatar = sender === 'user' ? '👤' : '🤖';
                
                messageEl.innerHTML = `
                    <div class="message-avatar">${avatar}</div>
                    <div class="message-content">
                        <p>${message}</p>
                        <span class="message-time">${currentTime}</span>
                    </div>
                `;
                
                conversationHistory.appendChild(messageEl);
                conversationHistory.scrollTop = conversationHistory.scrollHeight;
                
                // Add to history
                this.conversationHistory.push({
                    message,
                    sender,
                    timestamp: new Date()
                });
                
                // Update statistics
                const todayMessages = document.getElementById('todayMessages');
                const currentCount = parseInt(todayMessages.textContent) + 1;
                todayMessages.textContent = currentCount;
            }
            
            generateAvatarResponse(userMessage) {
                const responses = [
                    'תודה על השאלה! אני כאן לעזור לך.',
                    'זה נושא מעניין. בואו נחקור אותו יחד.',
                    'אני מבין את הנקודה שלך. יש לי כמה רעיונות.',
                    'שאלה מצוינת! הנה מה שאני חושב...',
                    'זה באמת חשוב. בואו נפתח את זה.',
                    'אני שמח שהעלית את זה. הנה התשובה שלי:',
                    'מעניין מאוד! יש לי כמה נקודות להוסיף.',
                    'זהו נושא קרוב ללבי. בואו נדבר עליו.'
                ];
                
                return responses[Math.floor(Math.random() * responses.length)];
            }
            
            animateTalking(duration) {
                const mouth = document.getElementById('avatarMouth');
                document.getElementById('voiceState').textContent = 'מדבר';
                
                const talkInterval = setInterval(() => {
                    const openness = 0.5 + Math.random() * 0.5;
                    mouth.style.height = (15 * openness) + 'px';
                }, 150);
                
                setTimeout(() => {
                    clearInterval(talkInterval);
                    mouth.style.height = '15px';
                    document.getElementById('voiceState').textContent = 'מוכן';
                }, duration);
            }
            
            toggleVoiceInput() {
                const voiceBtn = document.getElementById('voiceInputBtn');
                
                if (!this.isVoiceRecording) {
                    this.isVoiceRecording = true;
                    voiceBtn.textContent = '🔴 הקלטה...';
                    voiceBtn.style.background = '#F44336';
                    
                    // Simulate voice recognition
                    setTimeout(() => {
                        this.isVoiceRecording = false;
                        voiceBtn.textContent = '🎤 קלט קולי';
                        voiceBtn.style.background = '';
                        
                        // Add recognized text to input
                        document.getElementById('messageInput').value = 'טקסט שזוהה מהקלט הקולי';
                        this.showNotification('הקלט הקולי זוהה בהצלחה', 'success');
                    }, 3000);
                } else {
                    this.isVoiceRecording = false;
                    voiceBtn.textContent = '🎤 קלט קולי';
                    voiceBtn.style.background = '';
                }
            }
            
            updateAvatarSetting(setting, value) {
                if (!this.currentAvatar) return;
                
                console.log(`עדכון הגדרה: ${setting} = ${value}`);
                // Here you would update the actual avatar settings
            }
            
            toggleFloatingMenu() {
                const fabOptions = document.getElementById('fabOptions');
                fabOptions.classList.toggle('show');
            }
            
            handleFabAction(action) {
                this.toggleFloatingMenu();
                
                switch (action) {
                    case 'save':
                        this.saveConfiguration();
                        break;
                    case 'export':
                        this.exportData();
                        break;
                    case 'import':
                        this.importData();
                        break;
                    case 'reset':
                        this.resetSystem();
                        break;
                    case 'help':
                        this.showHelp();
                        break;
                }
            }
            
            saveConfiguration() {
                const config = {
                    currentAvatar: this.currentAvatar,
                    conversationHistory: this.conversationHistory,
                    settings: this.getCurrentSettings()
                };
                
                localStorage.setItem('avatarPanelConfig', JSON.stringify(config));
                this.showNotification('קונפיגורציה נשמרה בהצלחה', 'success');
            }
            
            exportData() {
                const data = {
                    avatar: this.currentAvatar,
                    conversations: this.conversationHistory,
                    metrics: this.systemMetrics,
                    timestamp: new Date().toISOString()
                };
                
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `avatar_data_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
                URL.revokeObjectURL(url);
                
                this.showNotification('נתונים יוצאו בהצלחה', 'success');
            }
            
            getCurrentSettings() {
                const sliders = ['responseSpeed', 'emotionalExpression', 'gestureFrequency',
                               'directnessLevel', 'warmthLevel', 'humorLevel'];
                
                const settings = {};
                sliders.forEach(slider => {
                    const element = document.getElementById(slider);
                    if (element) {
                        settings[slider] = parseFloat(element.value);
                    }
                });
                
                return settings;
            }
            
            startRealTimeUpdates() {
                setInterval(() => {
                    this.updateSystemMetrics();
                }, 2000);
                
                setInterval(() => {
                    this.updateTime();
                }, 1000);
            }
            
            updateSystemMetrics() {
                // Simulate metrics updates
                const fps = 28 + Math.random() * 4;
                const processingTime = 200 + Math.random() * 100;
                const systemLoad = 30 + Math.random() * 20;
                
                document.getElementById('averageFPS').textContent = Math.round(fps);
                document.getElementById('processingTime').textContent = Math.round(processingTime) + 'ms';
                document.getElementById('systemLoad').style.width = systemLoad + '%';
                
                // Update speaking time
                const speakingMinutes = Math.floor(Math.random() * 5);
                const speakingSeconds = Math.floor(Math.random() * 60);
                document.getElementById('speakingTime').textContent = 
                    `12:${speakingMinutes.toString().padStart(2, '0')}:${speakingSeconds.toString().padStart(2, '0')}`;
            }
            
            updateTime() {
                const now = new Date();
                const timeString = now.toLocaleTimeString('he-IL', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                document.getElementById('currentTime').textContent = timeString;
            }
            
            refreshPanel() {
                this.showNotification('מרענן לוח בקרה...', 'info');
                
                setTimeout(() => {
                    this.updateSystemMetrics();
                    this.showNotification('לוח הבקרה עודכן בהצלחה', 'success');
                }, 1000);
            }
            
            toggleFullscreen() {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                } else {
                    document.exitFullscreen();
                }
            }
            
            openSettings() {
                this.showNotification('פותח הגדרות מתקדמות...', 'info');
            }
            
            openAvatarCreator() {
                this.showNotification('פותח יוצר האווטרים...', 'info');
            }
            
            showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `notification ${type}`;
                notification.textContent = message;
                
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 10px;
                    color: white;
                    font-weight: bold;
                    z-index: 1000;
                    transition: all 0.3s ease;
                    ${type === 'success' ? 'background: #4CAF50;' : ''}
                    ${type === 'info' ? 'background: #2196F3;' : ''}
                    ${type === 'warning' ? 'background: #FF9800;' : ''}
                    ${type === 'error' ? 'background: #F44336;' : ''}
                `;
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.style.opacity = '0';
                    setTimeout(() => notification.remove(), 300);
                }, 3000);
            }
        }
        
        // Initialize when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            new AvatarPanelController();
        });
        </script>
        """