"""
Execution Profiling Types
סוגי פרופיילינג הרצה

Comprehensive models for execution profiling and performance analysis.
מודלים מקיפים לפרופיילינג הרצה וניתוח ביצועים.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from enum import Enum
import json

class ProfilingLevel(Enum):
    """Profiling detail levels"""
    BASIC = "basic"                # בסיסי
    DETAILED = "detailed"          # מפורט
    COMPREHENSIVE = "comprehensive" # מקיף
    DEBUG = "debug"                # דיבוג

class ResourceType(Enum):
    """Resource types for monitoring"""
    CPU = "cpu"                    # מעבד
    MEMORY = "memory"              # זיכרון
    DISK_IO = "disk_io"           # דיסק I/O
    NETWORK_IO = "network_io"     # רשת I/O
    GPU = "gpu"                   # כרטיס גרפי
    DATABASE = "database"         # מסד נתונים
    API_CALLS = "api_calls"       # קריאות API
    FILE_OPERATIONS = "file_ops"  # פעולות קבצים

class BottleneckType(Enum):
    """Performance bottleneck types"""
    CPU_BOUND = "cpu_bound"        # מוגבל על ידי מעבד
    MEMORY_BOUND = "memory_bound"  # מוגבל על ידי זיכרון
    IO_BOUND = "io_bound"         # מוגבל על ידי I/O
    NETWORK_BOUND = "network_bound" # מוגבל על ידי רשת
    DATABASE_BOUND = "database_bound" # מוגבל על ידי מסד נתונים
    LOCK_CONTENTION = "lock_contention" # מוגבל על ידי נעילות
    ALGORITHM_INEFFICIENT = "algorithm_inefficient" # אלגוריתם לא יעיל

class StepCategory(Enum):
    """Execution step categories"""
    INITIALIZATION = "initialization"   # אתחול
    DATA_PROCESSING = "data_processing" # עיבוד נתונים
    API_CALL = "api_call"              # קריאת API
    DATABASE_QUERY = "database_query"  # שאילתת מסד נתונים
    FILE_IO = "file_io"                # פעולות קבצים
    COMPUTATION = "computation"         # חישוב
    CLEANUP = "cleanup"                # ניקוי
    VALIDATION = "validation"          # אימות
    COMMUNICATION = "communication"     # תקשורת

@dataclass
class ProfilerConfig:
    """
    Configuration for execution profiler
    תצורה לפרופיילר הרצה
    """
    profiling_level: ProfilingLevel = ProfilingLevel.DETAILED
    enable_cpu_profiling: bool = True
    enable_memory_profiling: bool = True
    enable_io_profiling: bool = True
    enable_api_profiling: bool = True
    enable_database_profiling: bool = True
    
    # Sampling intervals (seconds)
    cpu_sample_interval: float = 0.1
    memory_sample_interval: float = 0.5
    io_sample_interval: float = 1.0
    
    # Thresholds for alerts
    cpu_threshold: float = 80.0      # %
    memory_threshold: float = 85.0   # %
    execution_time_threshold: float = 10.0  # seconds
    api_response_threshold: float = 5.0     # seconds
    
    # Resource limits
    max_memory_usage: int = 2048     # MB
    max_execution_time: int = 300    # seconds
    max_api_calls: int = 1000        # per session
    max_file_operations: int = 500   # per session
    
    # Data retention
    max_sessions: int = 100
    session_retention_days: int = 7
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'profiling_level': self.profiling_level.value,
            'enable_cpu_profiling': self.enable_cpu_profiling,
            'enable_memory_profiling': self.enable_memory_profiling,
            'enable_io_profiling': self.enable_io_profiling,
            'enable_api_profiling': self.enable_api_profiling,
            'enable_database_profiling': self.enable_database_profiling,
            'cpu_sample_interval': self.cpu_sample_interval,
            'memory_sample_interval': self.memory_sample_interval,
            'io_sample_interval': self.io_sample_interval,
            'cpu_threshold': self.cpu_threshold,
            'memory_threshold': self.memory_threshold,
            'execution_time_threshold': self.execution_time_threshold,
            'api_response_threshold': self.api_response_threshold,
            'max_memory_usage': self.max_memory_usage,
            'max_execution_time': self.max_execution_time,
            'max_api_calls': self.max_api_calls,
            'max_file_operations': self.max_file_operations,
            'max_sessions': self.max_sessions,
            'session_retention_days': self.session_retention_days
        }

@dataclass
class ResourceUsage:
    """
    Resource usage measurement at specific time
    מדידת שימוש במשאבים בזמן ספציפי
    """
    timestamp: datetime
    resource_type: ResourceType
    value: float
    unit: str
    percentage: Optional[float] = None
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'resource_type': self.resource_type.value,
            'value': self.value,
            'unit': self.unit,
            'percentage': self.percentage,
            'details': self.details
        }

@dataclass
class ExecutionStep:
    """
    Individual execution step with detailed metrics
    שלב הרצה בודד עם מדדים מפורטים
    """
    step_id: str
    name: str
    category: StepCategory
    start_time: datetime
    end_time: Optional[datetime] = None
    duration: float = 0.0  # seconds
    
    # Resource usage during this step
    cpu_usage: List[ResourceUsage] = field(default_factory=list)
    memory_usage: List[ResourceUsage] = field(default_factory=list)
    io_usage: List[ResourceUsage] = field(default_factory=list)
    
    # Step-specific metrics
    api_calls: int = 0
    database_queries: int = 0
    file_operations: int = 0
    network_requests: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    
    # Performance indicators
    cpu_time: float = 0.0          # CPU time consumed
    wall_time: float = 0.0         # Wall clock time
    memory_peak: float = 0.0       # Peak memory usage (MB)
    io_read_bytes: int = 0         # Bytes read
    io_write_bytes: int = 0        # Bytes written
    network_bytes_sent: int = 0    # Network bytes sent
    network_bytes_received: int = 0 # Network bytes received
    
    # Error tracking
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Context information
    function_name: str = ""
    module_name: str = ""
    line_number: Optional[int] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    return_value: Optional[Any] = None
    
    def mark_completed(self):
        """Mark step as completed and calculate duration"""
        self.end_time = datetime.now()
        if self.start_time:
            self.duration = (self.end_time - self.start_time).total_seconds()
            self.wall_time = self.duration
    
    def add_resource_usage(self, usage: ResourceUsage):
        """Add resource usage measurement"""
        if usage.resource_type == ResourceType.CPU:
            self.cpu_usage.append(usage)
        elif usage.resource_type == ResourceType.MEMORY:
            self.memory_usage.append(usage)
        elif usage.resource_type in [ResourceType.DISK_IO, ResourceType.NETWORK_IO]:
            self.io_usage.append(usage)
    
    def get_average_cpu_usage(self) -> float:
        """Get average CPU usage during this step"""
        if not self.cpu_usage:
            return 0.0
        return sum(usage.value for usage in self.cpu_usage) / len(self.cpu_usage)
    
    def get_peak_memory_usage(self) -> float:
        """Get peak memory usage during this step"""
        if not self.memory_usage:
            return 0.0
        return max(usage.value for usage in self.memory_usage)
    
    def is_bottleneck(self, cpu_threshold: float = 80.0, memory_threshold: float = 85.0) -> bool:
        """Check if this step is a performance bottleneck"""
        avg_cpu = self.get_average_cpu_usage()
        peak_memory = self.get_peak_memory_usage()
        
        return (avg_cpu > cpu_threshold or 
                peak_memory > memory_threshold or 
                self.duration > 5.0)  # More than 5 seconds
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'step_id': self.step_id,
            'name': self.name,
            'category': self.category.value,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': self.duration,
            'cpu_usage': [usage.to_dict() for usage in self.cpu_usage],
            'memory_usage': [usage.to_dict() for usage in self.memory_usage],
            'io_usage': [usage.to_dict() for usage in self.io_usage],
            'api_calls': self.api_calls,
            'database_queries': self.database_queries,
            'file_operations': self.file_operations,
            'network_requests': self.network_requests,
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'cpu_time': self.cpu_time,
            'wall_time': self.wall_time,
            'memory_peak': self.memory_peak,
            'io_read_bytes': self.io_read_bytes,
            'io_write_bytes': self.io_write_bytes,
            'network_bytes_sent': self.network_bytes_sent,
            'network_bytes_received': self.network_bytes_received,
            'errors': self.errors,
            'warnings': self.warnings,
            'function_name': self.function_name,
            'module_name': self.module_name,
            'line_number': self.line_number,
            'parameters': self.parameters,
            'return_value': str(self.return_value) if self.return_value else None,
            'average_cpu': self.get_average_cpu_usage(),
            'peak_memory': self.get_peak_memory_usage(),
            'is_bottleneck': self.is_bottleneck()
        }

@dataclass
class PerformanceMetric:
    """
    Performance metric with historical tracking
    מדד ביצועים עם מעקב היסטורי
    """
    metric_name: str
    current_value: float
    unit: str
    timestamp: datetime = field(default_factory=datetime.now)
    historical_values: List[Tuple[datetime, float]] = field(default_factory=list)
    baseline_value: Optional[float] = None
    threshold_warning: Optional[float] = None
    threshold_critical: Optional[float] = None
    
    def add_value(self, value: float, timestamp: Optional[datetime] = None):
        """Add new value to historical tracking"""
        if timestamp is None:
            timestamp = datetime.now()
        
        self.historical_values.append((timestamp, value))
        self.current_value = value
        self.timestamp = timestamp
        
        # Keep only last 1000 values
        if len(self.historical_values) > 1000:
            self.historical_values = self.historical_values[-1000:]
    
    def get_trend(self) -> str:
        """Get performance trend (improving, degrading, stable)"""
        if len(self.historical_values) < 10:
            return "insufficient_data"
        
        recent = [value for _, value in self.historical_values[-10:]]
        older = [value for _, value in self.historical_values[-20:-10]]
        
        if not older:
            return "insufficient_data"
        
        recent_avg = sum(recent) / len(recent)
        older_avg = sum(older) / len(older)
        
        change_percent = ((recent_avg - older_avg) / older_avg) * 100 if older_avg != 0 else 0
        
        if change_percent > 5:
            return "improving"
        elif change_percent < -5:
            return "degrading"
        else:
            return "stable"
    
    def is_critical(self) -> bool:
        """Check if current value exceeds critical threshold"""
        if self.threshold_critical is None:
            return False
        return self.current_value > self.threshold_critical
    
    def is_warning(self) -> bool:
        """Check if current value exceeds warning threshold"""
        if self.threshold_warning is None:
            return False
        return self.current_value > self.threshold_warning
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'metric_name': self.metric_name,
            'current_value': self.current_value,
            'unit': self.unit,
            'timestamp': self.timestamp.isoformat(),
            'baseline_value': self.baseline_value,
            'threshold_warning': self.threshold_warning,
            'threshold_critical': self.threshold_critical,
            'trend': self.get_trend(),
            'is_critical': self.is_critical(),
            'is_warning': self.is_warning(),
            'historical_count': len(self.historical_values)
        }

@dataclass
class ExecutionBottleneck:
    """
    Identified performance bottleneck
    צוואר בקבוק ביצועים מזוהה
    """
    bottleneck_id: str
    bottleneck_type: BottleneckType
    severity: str  # low, medium, high, critical
    description: str
    description_hebrew: str
    affected_steps: List[str] = field(default_factory=list)
    impact_percentage: float = 0.0  # % of total execution time
    
    # Metrics
    cpu_impact: float = 0.0
    memory_impact: float = 0.0
    io_impact: float = 0.0
    time_impact: float = 0.0  # seconds
    
    # Evidence
    evidence: List[str] = field(default_factory=list)
    measurements: Dict[str, float] = field(default_factory=dict)
    
    # Recommendations
    recommendations: List[str] = field(default_factory=list)
    recommendations_hebrew: List[str] = field(default_factory=list)
    estimated_improvement: float = 0.0  # % improvement if fixed
    
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'bottleneck_id': self.bottleneck_id,
            'bottleneck_type': self.bottleneck_type.value,
            'severity': self.severity,
            'description': self.description,
            'description_hebrew': self.description_hebrew,
            'affected_steps': self.affected_steps,
            'impact_percentage': self.impact_percentage,
            'cpu_impact': self.cpu_impact,
            'memory_impact': self.memory_impact,
            'io_impact': self.io_impact,
            'time_impact': self.time_impact,
            'evidence': self.evidence,
            'measurements': self.measurements,
            'recommendations': self.recommendations,
            'recommendations_hebrew': self.recommendations_hebrew,
            'estimated_improvement': self.estimated_improvement,
            'timestamp': self.timestamp.isoformat()
        }

@dataclass
class ProfilingSession:
    """
    Complete profiling session with all metrics and analysis
    סשן פרופיילינג מלא עם כל המדדים והניתוח
    """
    session_id: str
    name: str
    start_time: datetime
    end_time: Optional[datetime] = None
    total_duration: float = 0.0
    
    # Configuration
    config: ProfilerConfig = field(default_factory=ProfilerConfig)
    
    # Execution steps
    steps: List[ExecutionStep] = field(default_factory=list)
    
    # Overall metrics
    total_cpu_time: float = 0.0
    peak_memory_usage: float = 0.0
    total_io_bytes: int = 0
    total_network_bytes: int = 0
    total_api_calls: int = 0
    total_database_queries: int = 0
    total_file_operations: int = 0
    
    # Performance analysis
    bottlenecks: List[ExecutionBottleneck] = field(default_factory=list)
    performance_metrics: Dict[str, PerformanceMetric] = field(default_factory=dict)
    
    # Summary
    success: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    performance_score: float = 0.0  # 0-100
    efficiency_rating: str = ""     # excellent, good, fair, poor
    
    # Context
    module_name: str = ""
    function_name: str = ""
    environment: str = "development"
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_step(self, step: ExecutionStep):
        """Add execution step to session"""
        self.steps.append(step)
        
        # Update totals
        self.total_cpu_time += step.cpu_time
        self.peak_memory_usage = max(self.peak_memory_usage, step.get_peak_memory_usage())
        self.total_io_bytes += step.io_read_bytes + step.io_write_bytes
        self.total_network_bytes += step.network_bytes_sent + step.network_bytes_received
        self.total_api_calls += step.api_calls
        self.total_database_queries += step.database_queries
        self.total_file_operations += step.file_operations
        
        # Add errors and warnings
        self.errors.extend(step.errors)
        self.warnings.extend(step.warnings)
    
    def complete_session(self):
        """Mark session as completed and calculate final metrics"""
        self.end_time = datetime.now()
        if self.start_time:
            self.total_duration = (self.end_time - self.start_time).total_seconds()
        
        # Calculate performance score
        self.calculate_performance_score()
        
        # Determine efficiency rating
        self.determine_efficiency_rating()
    
    def calculate_performance_score(self):
        """Calculate overall performance score (0-100)"""
        if not self.steps:
            self.performance_score = 0.0
            return
        
        # Factors for scoring
        duration_factor = min(1.0, 10.0 / max(self.total_duration, 0.1))  # Prefer faster execution
        cpu_factor = min(1.0, 50.0 / max(self.total_cpu_time, 0.1))      # Prefer less CPU time
        memory_factor = min(1.0, 1000.0 / max(self.peak_memory_usage, 1.0))  # Prefer less memory
        error_factor = 1.0 - min(1.0, len(self.errors) / 10.0)           # Penalize errors
        
        # Bottleneck penalty
        bottleneck_penalty = min(1.0, len(self.bottlenecks) / 5.0)
        
        # Calculate weighted score
        weights = [0.3, 0.2, 0.2, 0.2, 0.1]
        factors = [duration_factor, cpu_factor, memory_factor, error_factor, 1.0 - bottleneck_penalty]
        
        self.performance_score = sum(w * f for w, f in zip(weights, factors)) * 100
        self.performance_score = max(0.0, min(100.0, self.performance_score))
    
    def determine_efficiency_rating(self):
        """Determine efficiency rating based on performance score"""
        if self.performance_score >= 90:
            self.efficiency_rating = "excellent"
        elif self.performance_score >= 75:
            self.efficiency_rating = "good"
        elif self.performance_score >= 50:
            self.efficiency_rating = "fair"
        else:
            self.efficiency_rating = "poor"
    
    def get_hebrew_efficiency_rating(self) -> str:
        """Get efficiency rating in Hebrew"""
        rating_map = {
            "excellent": "מצוין",
            "good": "טוב",
            "fair": "בינוני",
            "poor": "גרוע"
        }
        return rating_map.get(self.efficiency_rating, "לא ידוע")
    
    def get_bottlenecks_by_severity(self, severity: str) -> List[ExecutionBottleneck]:
        """Get bottlenecks by severity level"""
        return [bottleneck for bottleneck in self.bottlenecks 
                if bottleneck.severity == severity]
    
    def get_slowest_steps(self, count: int = 5) -> List[ExecutionStep]:
        """Get the slowest execution steps"""
        return sorted(self.steps, key=lambda x: x.duration, reverse=True)[:count]
    
    def get_resource_intensive_steps(self, resource_type: ResourceType, count: int = 5) -> List[ExecutionStep]:
        """Get steps with highest resource usage"""
        if resource_type == ResourceType.CPU:
            return sorted(self.steps, key=lambda x: x.get_average_cpu_usage(), reverse=True)[:count]
        elif resource_type == ResourceType.MEMORY:
            return sorted(self.steps, key=lambda x: x.get_peak_memory_usage(), reverse=True)[:count]
        else:
            return self.steps[:count]  # Default to first steps
    
    def add_bottleneck(self, bottleneck: ExecutionBottleneck):
        """Add identified bottleneck"""
        self.bottlenecks.append(bottleneck)
    
    def add_performance_metric(self, metric: PerformanceMetric):
        """Add performance metric"""
        self.performance_metrics[metric.metric_name] = metric
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to comprehensive dictionary"""
        return {
            'session_id': self.session_id,
            'name': self.name,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'total_duration': self.total_duration,
            'config': self.config.to_dict(),
            'steps': [step.to_dict() for step in self.steps],
            'total_cpu_time': self.total_cpu_time,
            'peak_memory_usage': self.peak_memory_usage,
            'total_io_bytes': self.total_io_bytes,
            'total_network_bytes': self.total_network_bytes,
            'total_api_calls': self.total_api_calls,
            'total_database_queries': self.total_database_queries,
            'total_file_operations': self.total_file_operations,
            'bottlenecks': [bottleneck.to_dict() for bottleneck in self.bottlenecks],
            'performance_metrics': {k: v.to_dict() for k, v in self.performance_metrics.items()},
            'success': self.success,
            'errors': self.errors,
            'warnings': self.warnings,
            'performance_score': self.performance_score,
            'efficiency_rating': self.efficiency_rating,
            'efficiency_rating_hebrew': self.get_hebrew_efficiency_rating(),
            'module_name': self.module_name,
            'function_name': self.function_name,
            'environment': self.environment,
            'tags': self.tags,
            'metadata': self.metadata,
            'step_count': len(self.steps),
            'bottleneck_count': len(self.bottlenecks),
            'critical_bottlenecks': len(self.get_bottlenecks_by_severity('critical')),
            'slowest_steps': [step.to_dict() for step in self.get_slowest_steps(3)]
        }

# Specialized profile types
@dataclass 
class ResourceProfile:
    """Resource usage profile"""
    session_id: str
    resource_type: ResourceType
    measurements: List[ResourceUsage] = field(default_factory=list)
    peak_usage: float = 0.0
    average_usage: float = 0.0
    minimum_usage: float = 0.0
    
    def add_measurement(self, usage: ResourceUsage):
        """Add resource usage measurement"""
        self.measurements.append(usage)
        values = [m.value for m in self.measurements]
        self.peak_usage = max(values)
        self.average_usage = sum(values) / len(values)
        self.minimum_usage = min(values)

@dataclass
class TimeProfile:
    """Time-based execution profile"""
    session_id: str
    total_time: float = 0.0
    cpu_time: float = 0.0
    wait_time: float = 0.0
    io_time: float = 0.0
    network_time: float = 0.0
    
    def get_efficiency_ratio(self) -> float:
        """Get CPU efficiency ratio"""
        if self.total_time == 0:
            return 0.0
        return self.cpu_time / self.total_time

@dataclass
class APIProfile:
    """API call profiling"""
    session_id: str
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    average_response_time: float = 0.0
    slowest_call_time: float = 0.0
    fastest_call_time: float = float('inf')
    
    def get_success_rate(self) -> float:
        """Get API call success rate"""
        if self.total_calls == 0:
            return 0.0
        return self.successful_calls / self.total_calls