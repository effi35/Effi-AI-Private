#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Agent Engine - מנוע יצירת וניהול סוכנים
המנוע המרכזי לכל פעולות הסוכנים במערכת
"""

import json
import os
import uuid
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import asdict

from ..models.agent_types import (
    Agent, AgentStatus, AgentRole, AgentPersonality, 
    AgentCapabilities, AgentInteraction, AgentTrainingSession
)
from ..models.personality_types import PERSONALITY_TRAITS, COMMUNICATION_STYLES, RESPONSE_TONES
from ..models.capability_types import DEFAULT_CAPABILITIES, DEFAULT_API_INTEGRATIONS
from ..utils.agent_utils import AgentValidator, AgentSerializer
from ..utils.hebrew_utils import HebrewTextProcessor

# Local AI Integration
from ...local_ai_integration.core.ollama_client import OllamaClient
from ...local_ai_integration.models.ollama_integration import InferenceRequest, InferenceMode
from ...local_ai_integration.utils.local_ai_utils import (
    MessageProcessor, PromptTemplates, ResponseProcessor, LocalAIConfig
)

logger = logging.getLogger(__name__)


class AgentEngine:
    """מנוע יצירת וניהול סוכנים"""
    
    def __init__(self, data_dir: str = None):
        """אתחול מנוע הסוכנים"""
        self.data_dir = data_dir or "/root/Effi_ai_privet/data/agents"
        self.agents_storage = {}
        self.active_agents = {}
        self.template_manager = None  # Will be injected
        self.skill_manager = None     # Will be injected
        self.training_engine = None   # Will be injected
        self.personality_engine = None # Will be injected
        
        # Hebrew support
        self.hebrew_processor = HebrewTextProcessor()
        
        # Agent validator and serializer
        self.validator = AgentValidator()
        self.serializer = AgentSerializer()
        
        # Local AI Integration
        self.local_ai_client: Optional[OllamaClient] = None
        self.ai_enabled: bool = True
        self.ai_model_name: str = LocalAIConfig.DEFAULT_MODEL
        
        # Performance tracking
        self.performance_metrics = {
            "total_agents_created": 0,
            "active_agents_count": 0,
            "successful_interactions": 0,
            "failed_interactions": 0,
            "average_response_time": 0.0
        }
        
        self._ensure_directories()
        self._load_existing_agents()
        self._initialize_local_ai()
    
    def _ensure_directories(self):
        """יצירת תיקיות נדרשות"""
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(os.path.join(self.data_dir, "agents"), exist_ok=True)
        os.makedirs(os.path.join(self.data_dir, "sessions"), exist_ok=True)
        os.makedirs(os.path.join(self.data_dir, "interactions"), exist_ok=True)
        os.makedirs(os.path.join(self.data_dir, "backups"), exist_ok=True)
    
    def _load_existing_agents(self):
        """טעינת סוכנים קיימים"""
        agents_dir = os.path.join(self.data_dir, "agents")
        if not os.path.exists(agents_dir):
            return
        
        for filename in os.listdir(agents_dir):
            if filename.endswith('.json'):
                try:
                    agent_path = os.path.join(agents_dir, filename)
                    with open(agent_path, 'r', encoding='utf-8') as f:
                        agent_data = json.load(f)
                    
                    agent = self.serializer.deserialize_agent(agent_data)
                    self.agents_storage[agent.id] = agent
                    logger.info(f"נטען סוכן: {agent.name}")
                    
                except Exception as e:
                    logger.error(f"שגיאה בטעינת סוכן {filename}: {e}")
    
    def _initialize_local_ai(self):
        """אתחול אינטגרציית בינה מלאכותית מקומית"""
        try:
            self.local_ai_client = OllamaClient()
            logger.info(f"Local AI client initialized for agent creation with model: {self.ai_model_name}")
        except Exception as e:
            logger.warning(f"Failed to initialize local AI for agents: {e}")
            self.ai_enabled = False
    
    def create_agent(
        self,
        name: str,
        description: str,
        role: AgentRole = AgentRole.ASSISTANT,
        template_id: str = None,
        personality_config: Dict[str, Any] = None,
        capabilities_config: Dict[str, Any] = None,
        custom_config: Dict[str, Any] = None
    ) -> Optional[str]:
        """יצירת סוכן חדש"""
        try:
            # Generate unique ID
            agent_id = str(uuid.uuid4())
            
            # Validate inputs
            if not self.validator.validate_agent_name(name):
                raise ValueError(f"שם סוכן לא תקין: {name}")
            
            # Create personality
            personality = self._create_personality(
                name, personality_config, template_id
            )
            
            # Create capabilities
            capabilities = self._create_capabilities(
                capabilities_config, template_id
            )
            
            # Create agent instance
            agent = Agent(
                id=agent_id,
                name=name,
                description=description,
                role=role,
                personality=personality,
                capabilities=capabilities,
                creator_id=custom_config.get("creator_id") if custom_config else None,
                parent_template=template_id
            )
            
            # Validate agent
            if not self.validator.validate_agent(agent):
                raise ValueError("תצורת סוכן לא תקינה")
            
            # Save agent
            self._save_agent(agent)
            self.agents_storage[agent_id] = agent
            
            # Update metrics
            self.performance_metrics["total_agents_created"] += 1
            
            logger.info(f"נוצר סוכן חדש: {name} (ID: {agent_id})")
            return agent_id
            
        except Exception as e:
            logger.error(f"שגיאה ביצירת סוכן: {e}")
            return None
    
    def _create_personality(
        self, 
        name: str, 
        config: Dict[str, Any] = None,
        template_id: str = None
    ) -> AgentPersonality:
        """יצירת אישיות סוכן"""
        # Default personality
        personality = AgentPersonality(name=name)
        
        # Load from template if provided
        if template_id and self.template_manager:
            template_personality = self.template_manager.get_personality_template(template_id)
            if template_personality:
                personality = AgentPersonality(**template_personality)
        
        # Apply custom configuration
        if config:
            for field, value in config.items():
                if hasattr(personality, field):
                    setattr(personality, field, value)
        
        # Ensure trait values are valid (0.0-1.0)
        for trait_name, trait_value in personality.traits.items():
            if trait_name in PERSONALITY_TRAITS:
                trait_def = PERSONALITY_TRAITS[trait_name]
                personality.traits[trait_name] = max(
                    trait_def.min_value,
                    min(trait_def.max_value, trait_value)
                )
        
        return personality
    
    def _create_capabilities(
        self,
        config: Dict[str, Any] = None,
        template_id: str = None
    ) -> AgentCapabilities:
        """יצירת יכולות סוכן"""
        # Default capabilities
        capabilities = AgentCapabilities()
        
        # Load from template if provided
        if template_id and self.template_manager:
            template_capabilities = self.template_manager.get_capabilities_template(template_id)
            if template_capabilities:
                capabilities = AgentCapabilities(**template_capabilities)
        
        # Apply custom configuration
        if config:
            for field, value in config.items():
                if hasattr(capabilities, field):
                    setattr(capabilities, field, value)
        
        return capabilities
    
    def activate_agent(self, agent_id: str) -> bool:
        """הפעלת סוכן"""
        if agent_id not in self.agents_storage:
            logger.error(f"סוכן לא נמצא: {agent_id}")
            return False
        
        try:
            agent = self.agents_storage[agent_id]
            
            # Create active session
            session_id = str(uuid.uuid4())
            session_data = {
                "session_id": session_id,
                "agent_id": agent_id,
                "start_time": datetime.now().isoformat(),
                "interactions": [],
                "context": {},
                "performance": {
                    "response_times": [],
                    "success_count": 0,
                    "error_count": 0
                }
            }
            
            self.active_agents[agent_id] = session_data
            agent.status = AgentStatus.ACTIVE
            agent.current_session = session_id
            agent.last_active = datetime.now().isoformat()
            
            # Update metrics
            self.performance_metrics["active_agents_count"] += 1
            
            self._save_agent(agent)
            logger.info(f"סוכן הופעל: {agent.name}")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בהפעלת סוכן: {e}")
            return False
    
    def deactivate_agent(self, agent_id: str) -> bool:
        """כיבוי סוכן"""
        if agent_id not in self.active_agents:
            return True  # Already inactive
        
        try:
            # Save session data
            session_data = self.active_agents[agent_id]
            self._save_session(session_data)
            
            # Update agent
            if agent_id in self.agents_storage:
                agent = self.agents_storage[agent_id]
                agent.status = AgentStatus.INACTIVE
                agent.current_session = None
                agent.last_active = datetime.now().isoformat()
                self._save_agent(agent)
            
            # Remove from active agents
            del self.active_agents[agent_id]
            
            # Update metrics
            self.performance_metrics["active_agents_count"] -= 1
            
            logger.info(f"סוכן נכבה: {agent_id}")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בכיבוי סוכן: {e}")
            return False
    
    async def interact_with_agent(
        self,
        agent_id: str,
        message: str,
        context: Dict[str, Any] = None,
        user_id: str = None
    ) -> Optional[str]:
        """אינטראקציה עם סוכן"""
        if agent_id not in self.active_agents:
            logger.error(f"סוכן לא פעיל: {agent_id}")
            return None
        
        try:
            start_time = datetime.now()
            agent = self.agents_storage[agent_id]
            session = self.active_agents[agent_id]
            
            # Create interaction record
            interaction = AgentInteraction(
                id=str(uuid.uuid4()),
                agent_id=agent_id,
                user_id=user_id,
                input_message=message,
                context=context or {}
            )
            
            # Generate response using local AI
            if self.ai_enabled and self.local_ai_client:
                response = await self._generate_ai_response(agent, message, context, session["interactions"])
            elif self.personality_engine:
                response = self.personality_engine.generate_response(
                    agent, message, context, session["interactions"]
                )
            else:
                response = self._generate_basic_response(agent, message)
            
            # Complete interaction record
            end_time = datetime.now()
            interaction.output_message = response
            interaction.response_time = (end_time - start_time).total_seconds()
            
            # Save interaction
            session["interactions"].append(asdict(interaction))
            session["performance"]["response_times"].append(interaction.response_time)
            session["performance"]["success_count"] += 1
            
            # Update agent metrics
            agent.metrics.total_interactions += 1
            agent.metrics.successful_interactions += 1
            agent.metrics.average_response_time = (
                (agent.metrics.average_response_time * (agent.metrics.total_interactions - 1) +
                 interaction.response_time) / agent.metrics.total_interactions
            )
            
            # Update system metrics
            self.performance_metrics["successful_interactions"] += 1
            
            self._save_interaction(interaction)
            logger.info(f"אינטראקציה הושלמה עם סוכן {agent.name}")
            
            return response
            
        except Exception as e:
            logger.error(f"שגיאה באינטראקציה עם סוכן: {e}")
            
            # Update error metrics
            if agent_id in self.active_agents:
                self.active_agents[agent_id]["performance"]["error_count"] += 1
            if agent_id in self.agents_storage:
                self.agents_storage[agent_id].metrics.failed_interactions += 1
            self.performance_metrics["failed_interactions"] += 1
            
            return None
    
    def _generate_basic_response(self, agent: Agent, message: str) -> str:
        """יצירת תגובה בסיסית"""
        personality = agent.personality
        
        # Hebrew processing
        processed_message = self.hebrew_processor.process_text(message)
        
        # Basic response based on communication style
        style_responses = {
            "formal": f"שלום, בנוגע לבקשתך '{processed_message}', אוכל לסייע בצורה מקצועית.",
            "casual": f"היי! ראיתי את ההודעה שלך '{processed_message}', בואו נעבוד על זה יחד!",
            "educational": f"זו שאלה מעניינת! לגבי '{processed_message}', הנה מה שאני יכול להסביר:",
            "supportive": f"אני כאן כדי לעזור! בנוגע ל'{processed_message}', נמצא פתרון יחד.",
            "analytical": f"לאחר ניתוח הבקשה '{processed_message}', אוכל לספק את המידע הבא:",
            "creative": f"איזה אתגר מעניין! '{processed_message}' נותן לי רעיונות יצירתיים..."
        }
        
        base_response = style_responses.get(
            personality.communication_style,
            f"תודה על ההודעה '{processed_message}', אשמח לעזור!"
        )
        
        # Add personality touches
        if personality.humor_level > 0.7:
            base_response += " (ואולי גם עם קצת הומור 😊)"
        
        if personality.empathy_level > 0.8:
            base_response += " אני מבין שזה חשוב לך."
        
        return base_response
    
    async def _generate_ai_response(self, agent: Agent, message: str, context: Dict[str, Any], interactions: List[Dict]) -> str:
        """
        יצירת תגובה באמצעות בינה מלאכותית מקומית
        Generate response using local AI
        """
        try:
            # Prepare personality context
            personality_context = f"""
אתה {agent.name}, סוכן AI עם האישיות הבאה:
- תפקיד: {agent.role.value}
- סגנון תקשורת: {agent.personality.communication_style}
- רמת הומור: {agent.personality.humor_level}
- רמת אמפתיה: {agent.personality.empathy_level}
- רמת ישירות: {agent.personality.directness}
- תיאור: {agent.description}

התגב בעברית בהתאם לאישיותך ותן מענה מועיל למשתמש.
"""
            
            # Get recent conversation context
            recent_interactions = interactions[-5:] if interactions else []
            conversation_context = "\n".join([
                f"משתמש: {inter.get('input_message', '')}\nאתה: {inter.get('output_message', '')}"
                for inter in recent_interactions
            ])
            
            # Format the full prompt
            full_prompt = f"""{personality_context}

הקשר השיחה:
{conversation_context}

הודעה נוכחית מהמשתמש: {message}

תגובה:"""
            
            # Create chat session if needed
            session_id = f"agent_{agent.id}_{uuid.uuid4()}"
            
            # Generate response
            async with self.local_ai_client as client:
                response = await client.chat(session_id, full_prompt, self.ai_model_name)
            
            # Clean and process response
            cleaned_response = ResponseProcessor.clean_hebrew_response(response)
            
            return cleaned_response if cleaned_response else self._generate_basic_response(agent, message)
            
        except Exception as e:
            logger.error(f"AI response generation error: {e}")
            return self._generate_basic_response(agent, message)
    
    async def create_agent_with_ai(self, requirements: str, language: str = "hebrew") -> Optional[str]:
        """
        יצירת סוכן באמצעות בינה מלאכותית מקומית
        Create agent using local AI based on requirements
        """
        try:
            if not self.ai_enabled or not self.local_ai_client:
                logger.warning("AI not available for agent creation")
                return None
            
            # Prepare AI prompt for agent creation
            prompt = f"""
צור הגדרה מלאה לסוכן AI חדש על בסיס הדרישות הבאות:
{requirements}

ספק את הפרטים הבאים בפורמט JSON:
{{
  "name": "שם הסוכן",
  "description": "תיאור מפורט של הסוכן",
  "role": "assistant/specialist/researcher/creator",
  "personality": {{
    "communication_style": "formal/casual/educational/supportive",
    "humor_level": 0.5,
    "empathy_level": 0.8,
    "directness": 0.7,
    "creativity": 0.6,
    "analytical_thinking": 0.8
  }},
  "capabilities": {{
    "text_processing": true,
    "multilingual_support": true,
    "technical_knowledge": true,
    "creative_writing": false,
    "data_analysis": false
  }}
}}

התגב רק עם ה-JSON בלבד:"""
            
            # Generate agent definition
            request = InferenceRequest(
                model_name=self.ai_model_name,
                prompt=prompt,
                mode=InferenceMode.COMPLETION,
                temperature=0.7,
                max_tokens=1000,
                request_id=str(uuid.uuid4())
            )
            
            async with self.local_ai_client as client:
                result = await client.generate(request)
            
            if result.success:
                # Parse JSON response
                try:
                    agent_def = json.loads(result.response.strip())
                    
                    # Create agent from AI definition
                    agent_id = self.create_agent(
                        name=agent_def.get("name", "AI Generated Agent"),
                        description=agent_def.get("description", "סוכן שנוצר על ידי בינה מלאכותית"),
                        role=AgentRole(agent_def.get("role", "assistant")),
                        personality_config=agent_def.get("personality", {}),
                        capabilities_config=agent_def.get("capabilities", {}),
                        custom_config={"created_by_ai": True, "ai_requirements": requirements}
                    )
                    
                    if agent_id:
                        logger.info(f"AI-generated agent created successfully: {agent_id}")
                        return agent_id
                    
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse AI agent definition: {e}")
                    return None
            
            return None
            
        except Exception as e:
            logger.error(f"AI agent creation error: {e}")
            return None
    
    def get_agent(self, agent_id: str) -> Optional[Agent]:
        """קבלת סוכן לפי ID"""
        return self.agents_storage.get(agent_id)
    
    def list_agents(self, active_only: bool = False) -> List[Dict[str, Any]]:
        """רשימת כל הסוכנים"""
        agents_list = []
        
        for agent_id, agent in self.agents_storage.items():
            if active_only and agent_id not in self.active_agents:
                continue
            
            agent_info = {
                "id": agent.id,
                "name": agent.name,
                "description": agent.description,
                "role": agent.role.value,
                "status": agent.status.value,
                "created_at": agent.created_at,
                "last_active": agent.last_active,
                "total_interactions": agent.metrics.total_interactions,
                "success_rate": (
                    agent.metrics.successful_interactions / agent.metrics.total_interactions
                    if agent.metrics.total_interactions > 0 else 0.0
                )
            }
            
            if agent_id in self.active_agents:
                session = self.active_agents[agent_id]
                agent_info["session_interactions"] = len(session["interactions"])
                agent_info["session_start"] = session["start_time"]
            
            agents_list.append(agent_info)
        
        return agents_list
    
    def update_agent_personality(
        self,
        agent_id: str,
        personality_updates: Dict[str, Any]
    ) -> bool:
        """עדכון אישיות סוכן"""
        if agent_id not in self.agents_storage:
            return False
        
        try:
            agent = self.agents_storage[agent_id]
            
            # Update personality fields
            for field, value in personality_updates.items():
                if hasattr(agent.personality, field):
                    setattr(agent.personality, field, value)
            
            # Validate trait values
            for trait_name, trait_value in agent.personality.traits.items():
                if trait_name in PERSONALITY_TRAITS:
                    trait_def = PERSONALITY_TRAITS[trait_name]
                    agent.personality.traits[trait_name] = max(
                        trait_def.min_value,
                        min(trait_def.max_value, trait_value)
                    )
            
            agent.last_updated = datetime.now().isoformat()
            self._save_agent(agent)
            
            logger.info(f"עודכנה אישיות סוכן: {agent.name}")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה בעדכון אישיות סוכן: {e}")
            return False
    
    def delete_agent(self, agent_id: str) -> bool:
        """מחיקת סוכן"""
        if agent_id not in self.agents_storage:
            return False
        
        try:
            # Deactivate if active
            if agent_id in self.active_agents:
                self.deactivate_agent(agent_id)
            
            agent = self.agents_storage[agent_id]
            agent_name = agent.name
            
            # Delete agent file
            agent_file = os.path.join(self.data_dir, "agents", f"{agent_id}.json")
            if os.path.exists(agent_file):
                os.remove(agent_file)
            
            # Remove from storage
            del self.agents_storage[agent_id]
            
            logger.info(f"נמחק סוכן: {agent_name}")
            return True
            
        except Exception as e:
            logger.error(f"שגיאה במחיקת סוכן: {e}")
            return False
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """קבלת מדדי ביצועים"""
        # Calculate additional metrics
        total_interactions = (
            self.performance_metrics["successful_interactions"] +
            self.performance_metrics["failed_interactions"]
        )
        
        success_rate = (
            self.performance_metrics["successful_interactions"] / total_interactions
            if total_interactions > 0 else 0.0
        )
        
        # Calculate average response time across all active sessions
        total_response_times = []
        for session in self.active_agents.values():
            total_response_times.extend(session["performance"]["response_times"])
        
        avg_response_time = (
            sum(total_response_times) / len(total_response_times)
            if total_response_times else 0.0
        )
        
        return {
            **self.performance_metrics,
            "total_interactions": total_interactions,
            "success_rate": success_rate,
            "current_avg_response_time": avg_response_time,
            "agents_storage_count": len(self.agents_storage),
            "ai_integration": {
                "enabled": self.ai_enabled,
                "model_name": self.ai_model_name,
                "client_status": "connected" if self.local_ai_client else "disconnected"
            }
        }
    
    def _save_agent(self, agent: Agent):
        """שמירת סוכן לקובץ"""
        try:
            agent_file = os.path.join(self.data_dir, "agents", f"{agent.id}.json")
            agent_data = self.serializer.serialize_agent(agent)
            
            with open(agent_file, 'w', encoding='utf-8') as f:
                json.dump(agent_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"שגיאה בשמירת סוכן: {e}")
    
    def _save_session(self, session_data: Dict[str, Any]):
        """שמירת נתוני סשן"""
        try:
            session_file = os.path.join(
                self.data_dir, "sessions", f"{session_data['session_id']}.json"
            )
            
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"שגיאה בשמירת סשן: {e}")
    
    def _save_interaction(self, interaction: AgentInteraction):
        """שמירת אינטראקציה"""
        try:
            interaction_file = os.path.join(
                self.data_dir, "interactions", f"{interaction.id}.json"
            )
            
            interaction_data = asdict(interaction)
            
            with open(interaction_file, 'w', encoding='utf-8') as f:
                json.dump(interaction_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"שגיאה בשמירת אינטראקציה: {e}")