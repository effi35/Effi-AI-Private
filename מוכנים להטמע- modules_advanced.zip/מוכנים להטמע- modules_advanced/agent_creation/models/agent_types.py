#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Agent Types - סוגי סוכנים ומבני נתונים עיקריים
מכיל את ההגדרות הבסיסיות לסוכני AI
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
from enum import Enum


class AgentStatus(Enum):
    """סטטוס סוכן"""
    INACTIVE = "inactive"
    ACTIVE = "active"
    TRAINING = "training"
    SUSPENDED = "suspended"
    ERROR = "error"


class AgentRole(Enum):
    """תפקיד סוכן"""
    ASSISTANT = "assistant"  # עוזר כללי
    RESEARCHER = "researcher"  # חוקר
    CREATIVE = "creative"  # יוצר
    TECHNICAL = "technical"  # מומחה טכני
    EDUCATOR = "educator"  # מחנך
    ANALYST = "analyst"  # אנליסט
    CUSTOM = "custom"  # מותאם אישית


@dataclass
class AgentPersonality:
    """אישיות סוכן"""
    name: str
    traits: Dict[str, float] = field(default_factory=dict)  # תכונות אישיות (0.0-1.0)
    communication_style: str = "supportive"
    expertise_areas: List[str] = field(default_factory=list)
    language_preference: str = "he"
    response_tone: str = "helpful"
    cultural_sensitivity: float = 0.8
    humor_level: float = 0.5
    formality_level: float = 0.6
    empathy_level: float = 0.8
    creativity_level: float = 0.6
    assertiveness_level: float = 0.5


@dataclass
class AgentCapabilities:
    """יכולות סוכן"""
    text_processing: bool = True
    voice_interaction: bool = False
    image_analysis: bool = False
    video_processing: bool = False
    web_search: bool = False
    file_operations: bool = False
    api_integrations: List[str] = field(default_factory=list)
    custom_skills: Dict[str, Any] = field(default_factory=dict)
    learning_enabled: bool = True
    memory_enabled: bool = True
    multilingual: bool = True
    real_time_processing: bool = False
    offline_capabilities: List[str] = field(default_factory=list)


@dataclass
class AgentSkill:
    """כישור סוכן"""
    name: str
    description: str
    skill_type: str  # "built-in", "learned", "custom"
    proficiency_level: float  # 0.0-1.0
    usage_count: int = 0
    last_used: Optional[str] = None
    prerequisites: List[str] = field(default_factory=list)
    related_skills: List[str] = field(default_factory=list)
    training_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentMemory:
    """זיכרון סוכן"""
    short_term: List[Dict[str, Any]] = field(default_factory=list)
    long_term: Dict[str, Any] = field(default_factory=dict)
    episodic: List[Dict[str, Any]] = field(default_factory=list)  # זיכרון אפיזודי
    semantic: Dict[str, Any] = field(default_factory=dict)  # זיכרון סמנטי
    procedural: Dict[str, Any] = field(default_factory=dict)  # זיכרון פרוצדורלי
    working_memory_size: int = 1000
    retention_period: int = 30  # ימים
    memory_priority_weights: Dict[str, float] = field(default_factory=dict)


@dataclass
class AgentMetrics:
    """מדדי ביצועים של סוכן"""
    total_interactions: int = 0
    successful_interactions: int = 0
    failed_interactions: int = 0
    average_response_time: float = 0.0
    satisfaction_scores: List[float] = field(default_factory=list)
    learning_progress: Dict[str, float] = field(default_factory=dict)
    skill_usage_stats: Dict[str, int] = field(default_factory=dict)
    error_frequency: Dict[str, int] = field(default_factory=dict)
    improvement_rate: float = 0.0
    last_performance_review: Optional[str] = None


@dataclass
class AgentConfiguration:
    """תצורת סוכן"""
    max_context_length: int = 4000
    response_timeout: int = 30  # שניות
    memory_cleanup_interval: int = 24  # שעות
    learning_rate: float = 0.01
    confidence_threshold: float = 0.7
    error_tolerance: float = 0.1
    auto_improvement: bool = True
    privacy_mode: bool = True
    debug_mode: bool = False
    logging_level: str = "INFO"
    custom_parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Agent:
    """סוכן AI מלא"""
    id: str
    name: str
    description: str
    role: AgentRole
    personality: AgentPersonality
    capabilities: AgentCapabilities
    skills: List[AgentSkill] = field(default_factory=list)
    memory: AgentMemory = field(default_factory=AgentMemory)
    metrics: AgentMetrics = field(default_factory=AgentMetrics)
    configuration: AgentConfiguration = field(default_factory=AgentConfiguration)
    
    # System fields
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_active: str = field(default_factory=lambda: datetime.now().isoformat())
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    status: AgentStatus = AgentStatus.INACTIVE
    version: str = "1.0.0"
    creator_id: Optional[str] = None
    parent_template: Optional[str] = None
    
    # Runtime fields
    current_session: Optional[str] = None
    active_context: Dict[str, Any] = field(default_factory=dict)
    pending_tasks: List[Dict[str, Any]] = field(default_factory=list)
    custom_prompts: Dict[str, str] = field(default_factory=dict)
    training_history: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class AgentTemplate:
    """תבנית סוכן"""
    id: str
    name: str
    description: str
    category: str
    role: AgentRole
    personality_template: Dict[str, Any]
    capabilities_template: Dict[str, Any]
    default_skills: List[Dict[str, Any]] = field(default_factory=list)
    configuration_template: Dict[str, Any] = field(default_factory=dict)
    
    # Template metadata
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    created_by: Optional[str] = None
    version: str = "1.0.0"
    usage_count: int = 0
    rating: float = 0.0
    tags: List[str] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)
    
    # Localization
    display_name_he: str = ""
    description_he: str = ""
    personality_description_he: str = ""
    capabilities_description_he: str = ""


@dataclass
class AgentInteraction:
    """אינטראקציה עם סוכן"""
    id: str
    agent_id: str
    user_id: Optional[str]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    input_message: str = ""
    output_message: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Performance tracking
    response_time: float = 0.0
    tokens_used: int = 0
    satisfaction_score: Optional[float] = None
    error_occurred: bool = False
    error_details: Optional[str] = None
    
    # Learning data
    feedback_received: Optional[str] = None
    improvement_suggestions: List[str] = field(default_factory=list)
    skills_used: List[str] = field(default_factory=list)


@dataclass
class AgentTrainingSession:
    """סשן אימון סוכן"""
    id: str
    agent_id: str
    training_type: str  # "supervised", "reinforcement", "self_improvement"
    start_time: str = field(default_factory=lambda: datetime.now().isoformat())
    end_time: Optional[str] = None
    training_data: List[Dict[str, Any]] = field(default_factory=list)
    performance_before: Dict[str, float] = field(default_factory=dict)
    performance_after: Dict[str, float] = field(default_factory=dict)
    improvement_metrics: Dict[str, float] = field(default_factory=dict)
    training_notes: str = ""
    success: bool = False