#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Personality Types - סוגי אישיות למערכת יצירת סוכנים
מכיל הגדרות מפורטות של תכונות אישיות וסגנונות תקשורת
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


class TraitCategory(Enum):
    """קטגוריות תכונות אישיות"""
    EMOTIONAL = "emotional"  # רגשיות
    SOCIAL = "social"  # חברתיות
    COGNITIVE = "cognitive"  # קוגניטיבית
    BEHAVIORAL = "behavioral"  # התנהגותית
    CULTURAL = "cultural"  # תרבותית


@dataclass
class PersonalityTrait:
    """תכונת אישיות"""
    name: str
    name_he: str
    description: str
    description_he: str
    category: TraitCategory
    min_value: float = 0.0
    max_value: float = 1.0
    default_value: float = 0.5
    impact_weight: float = 1.0
    related_traits: List[str] = field(default_factory=list)
    opposing_traits: List[str] = field(default_factory=list)
    behavioral_indicators: List[str] = field(default_factory=list)


@dataclass
class CommunicationStyle:
    """סגנון תקשורת"""
    name: str
    name_he: str
    description: str
    description_he: str
    characteristics: List[str] = field(default_factory=list)
    example_phrases: List[str] = field(default_factory=list)
    example_phrases_he: List[str] = field(default_factory=list)
    tone_modifiers: Dict[str, float] = field(default_factory=dict)
    suitable_contexts: List[str] = field(default_factory=list)
    personality_fit: Dict[str, float] = field(default_factory=dict)


@dataclass
class ResponseTone:
    """טון תגובה"""
    name: str
    name_he: str
    description: str
    description_he: str
    emotional_indicators: Dict[str, float] = field(default_factory=dict)
    linguistic_features: List[str] = field(default_factory=list)
    example_words: List[str] = field(default_factory=list)
    example_words_he: List[str] = field(default_factory=list)
    appropriateness_score: Dict[str, float] = field(default_factory=dict)


@dataclass
class EmotionalProfile:
    """פרופיל רגשי"""
    base_emotions: Dict[str, float] = field(default_factory=dict)
    emotional_stability: float = 0.5
    emotional_range: float = 0.5
    emotional_recovery_rate: float = 0.5
    empathy_sensitivity: float = 0.5
    stress_tolerance: float = 0.5
    excitement_threshold: float = 0.5
    emotional_expression_style: str = "balanced"
    emotional_triggers: List[str] = field(default_factory=list)
    emotional_regulation_strategies: List[str] = field(default_factory=list)


@dataclass
class BehaviorPattern:
    """דפוס התנהגות"""
    name: str
    name_he: str
    description: str
    description_he: str
    trigger_conditions: List[str] = field(default_factory=list)
    behavioral_responses: List[str] = field(default_factory=list)
    frequency: str = "normal"  # "rare", "normal", "frequent"
    intensity: float = 0.5
    adaptability: float = 0.5
    learning_impact: float = 0.0
    cultural_variations: Dict[str, Any] = field(default_factory=dict)


# Predefined personality traits
PERSONALITY_TRAITS = {
    "friendliness": PersonalityTrait(
        name="friendliness",
        name_he="ידידותיות",
        description="Level of warmth and approachability",
        description_he="רמת החמימות והנגישות בתקשורת",
        category=TraitCategory.SOCIAL,
        behavioral_indicators=["warm greetings", "positive language", "encouraging responses"],
        related_traits=["empathy", "humor"],
        opposing_traits=["coldness", "formality"]
    ),
    
    "professionalism": PersonalityTrait(
        name="professionalism",
        name_he="מקצועיות",
        description="Level of formal and precise communication",
        description_he="רמת הפורמליות והדיוק בתקשורת",
        category=TraitCategory.BEHAVIORAL,
        behavioral_indicators=["formal language", "structured responses", "clear boundaries"],
        related_traits=["precision", "reliability"],
        opposing_traits=["casualness", "informality"]
    ),
    
    "creativity": PersonalityTrait(
        name="creativity",
        name_he="יצירתיות",
        description="Level of innovative and out-of-the-box thinking",
        description_he="רמת החדשנות והחשיבה מחוץ לקופסה",
        category=TraitCategory.COGNITIVE,
        behavioral_indicators=["novel solutions", "metaphorical language", "imaginative examples"],
        related_traits=["curiosity", "openness"],
        opposing_traits=["conventionality", "rigidity"]
    ),
    
    "empathy": PersonalityTrait(
        name="empathy",
        name_he="אמפתיה",
        description="Level of understanding and relating to user emotions",
        description_he="רמת ההבנה והזדהות עם רגשות המשתמש",
        category=TraitCategory.EMOTIONAL,
        behavioral_indicators=["emotional validation", "supportive language", "perspective taking"],
        related_traits=["friendliness", "patience"],
        opposing_traits=["detachment", "indifference"]
    ),
    
    "humor": PersonalityTrait(
        name="humor",
        name_he="הומור",
        description="Level of humor and playfulness in communication",
        description_he="רמת השימוש בהומור ורוח בתקשורת",
        category=TraitCategory.SOCIAL,
        behavioral_indicators=["jokes", "puns", "light-hearted comments"],
        related_traits=["friendliness", "creativity"],
        opposing_traits=["seriousness", "formality"]
    ),
    
    "patience": PersonalityTrait(
        name="patience",
        name_he="סבלנות",
        description="Level of patience and willingness to explain",
        description_he="רמת הסבלנות והנכונות להסביר בפירוט",
        category=TraitCategory.BEHAVIORAL,
        behavioral_indicators=["detailed explanations", "repetition when needed", "calm responses"],
        related_traits=["empathy", "supportiveness"],
        opposing_traits=["impatience", "rushed responses"]
    ),
    
    "assertiveness": PersonalityTrait(
        name="assertiveness",
        name_he="אסרטיביות",
        description="Level of confidence and directness",
        description_he="רמת הביטחון והישירות בתקשורת",
        category=TraitCategory.BEHAVIORAL,
        behavioral_indicators=["direct communication", "confident statements", "clear boundaries"],
        related_traits=["leadership", "decisiveness"],
        opposing_traits=["passivity", "hesitation"]
    ),
    
    "curiosity": PersonalityTrait(
        name="curiosity",
        name_he="סקרנות",
        description="Level of interest in learning and exploration",
        description_he="רמת העניין בלמידה וחקירת נושאים חדשים",
        category=TraitCategory.COGNITIVE,
        behavioral_indicators=["asking questions", "exploring topics", "seeking clarification"],
        related_traits=["creativity", "openness"],
        opposing_traits=["disinterest", "closed-mindedness"]
    )
}

# Predefined communication styles
COMMUNICATION_STYLES = {
    "formal": CommunicationStyle(
        name="formal",
        name_he="פורמלי",
        description="Formal and professional communication",
        description_he="תקשורת רשמית ומקצועית",
        characteristics=["structured", "polite", "respectful", "precise"],
        example_phrases=["I would be pleased to assist", "Please allow me to explain", "I recommend"],
        example_phrases_he=["אשמח לסייע", "אנא הרשו לי להסביר", "אני ממליץ"],
        tone_modifiers={"professionalism": 1.0, "friendliness": 0.3}
    ),
    
    "casual": CommunicationStyle(
        name="casual",
        name_he="מזדמן",
        description="Relaxed and friendly communication",
        description_he="תקשורת נינוחה וחברותית",
        characteristics=["relaxed", "approachable", "conversational", "warm"],
        example_phrases=["Hey there!", "No worries", "Let's figure this out together"],
        example_phrases_he=["היי!", "אין בעיה", "בואו נפתור את זה יחד"],
        tone_modifiers={"friendliness": 1.0, "professionalism": 0.4}
    ),
    
    "educational": CommunicationStyle(
        name="educational",
        name_he="חינוכי",
        description="Teaching-focused communication",
        description_he="תקשורת מוקדת הוראה והסבר",
        characteristics=["explanatory", "structured", "patient", "encouraging"],
        example_phrases=["Let me break this down", "Think of it this way", "Here's an example"],
        example_phrases_he=["בואו נפרק את זה", "חשבו על זה ככה", "הנה דוגמה"],
        tone_modifiers={"patience": 1.0, "clarity": 1.0}
    ),
    
    "supportive": CommunicationStyle(
        name="supportive",
        name_he="תומך",
        description="Supportive and encouraging communication",
        description_he="תקשורת תומכת ומעודדת",
        characteristics=["encouraging", "empathetic", "reassuring", "positive"],
        example_phrases=["You're doing great", "I understand", "We'll work through this"],
        example_phrases_he=["אתם עושים נהדר", "אני מבין", "נעבור על זה יחד"],
        tone_modifiers={"empathy": 1.0, "encouragement": 1.0}
    ),
    
    "analytical": CommunicationStyle(
        name="analytical",
        name_he="אנליטי",
        description="Data-focused analytical communication",
        description_he="תקשורת אנליטית מוקדת נתונים",
        characteristics=["logical", "systematic", "precise", "evidence-based"],
        example_phrases=["Based on the data", "Let's analyze this", "The evidence suggests"],
        example_phrases_he=["על פי הנתונים", "בואו ננתח את זה", "העדויות מצביעות על"],
        tone_modifiers={"precision": 1.0, "logic": 1.0}
    ),
    
    "creative": CommunicationStyle(
        name="creative",
        name_he="יצירתי",
        description="Creative and innovative communication",
        description_he="תקשורת יצירתית וחדשנית",
        characteristics=["imaginative", "metaphorical", "inspiring", "original"],
        example_phrases=["Imagine if we", "Picture this", "What if we tried"],
        example_phrases_he=["תארו לעצמכם אם", "דמיינו את זה", "מה אם ננסה"],
        tone_modifiers={"creativity": 1.0, "inspiration": 1.0}
    )
}

# Predefined response tones
RESPONSE_TONES = {
    "helpful": ResponseTone(
        name="helpful",
        name_he="מועיל",
        description="Helpful and solution-oriented tone",
        description_he="טון מועיל וממוקד פתרונות",
        emotional_indicators={"positivity": 0.8, "eagerness": 0.7},
        example_words=["certainly", "gladly", "solution", "assist"],
        example_words_he=["בוודאי", "בשמחה", "פתרון", "לסייע"]
    ),
    
    "informative": ResponseTone(
        name="informative",
        name_he="אינפורמטיבי",
        description="Information-focused neutral tone",
        description_he="טון נייטרלי ממוקד מידע",
        emotional_indicators={"neutrality": 0.9, "clarity": 0.8},
        example_words=["according to", "specifically", "details", "information"],
        example_words_he=["על פי", "באופן ספציפי", "פרטים", "מידע"]
    ),
    
    "inspiring": ResponseTone(
        name="inspiring",
        name_he="מעורר השראה",
        description="Motivational and inspiring tone",
        description_he="טון מעורר השראה ומניע",
        emotional_indicators={"enthusiasm": 0.9, "optimism": 0.8},
        example_words=["amazing", "potential", "achieve", "inspire"],
        example_words_he=["מדהים", "פוטנציאל", "להשיג", "להעניק השראה"]
    ),
    
    "precise": ResponseTone(
        name="precise",
        name_he="מדויק",
        description="Precise and technical tone",
        description_he="טון מדויק וטכני",
        emotional_indicators={"precision": 0.9, "technicality": 0.8},
        example_words=["exactly", "precisely", "specifically", "technical"],
        example_words_he=["בדיוק", "במדויק", "באופן ספציפי", "טכני"]
    )
}