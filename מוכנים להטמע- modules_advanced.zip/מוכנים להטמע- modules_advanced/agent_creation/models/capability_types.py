#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Capability Types - סוגי יכולות למערכת יצירת סוכנים
מכיל הגדרות מפורטות של יכולות, כישורים ואינטגרציות
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


class CapabilityLevel(Enum):
    """רמות יכולת"""
    BASIC = "basic"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class SkillType(Enum):
    """סוגי כישורים"""
    BUILT_IN = "built_in"  # מובנה
    LEARNED = "learned"  # נלמד
    CUSTOM = "custom"  # מותאם אישית
    PLUGIN = "plugin"  # תוסף


@dataclass
class Capability:
    """יכולת בסיסית"""
    name: str
    name_he: str
    description: str
    description_he: str
    category: str
    level: CapabilityLevel
    prerequisites: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    resource_requirements: Dict[str, Any] = field(default_factory=dict)
    performance_metrics: List[str] = field(default_factory=list)
    enabled: bool = True
    configuration: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SkillLevel:
    """רמת כישור"""
    level: CapabilityLevel
    proficiency: float  # 0.0-1.0
    confidence: float  # 0.0-1.0
    experience_points: int = 0
    usage_frequency: float = 0.0
    success_rate: float = 0.0
    improvement_rate: float = 0.0
    last_improvement: Optional[str] = None
    training_sessions: int = 0
    benchmarks: Dict[str, float] = field(default_factory=dict)


@dataclass
class APIIntegration:
    """אינטגרציה עם API"""
    name: str
    name_he: str
    service_type: str
    endpoint_url: str
    authentication_type: str  # "api_key", "oauth", "basic", "none"
    required_credentials: List[str] = field(default_factory=list)
    supported_operations: List[str] = field(default_factory=list)
    rate_limits: Dict[str, int] = field(default_factory=dict)
    data_formats: List[str] = field(default_factory=list)
    error_handling: Dict[str, str] = field(default_factory=dict)
    configuration: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    status: str = "inactive"


@dataclass
class CustomSkill:
    """כישור מותאם אישית"""
    id: str
    name: str
    name_he: str
    description: str
    description_he: str
    skill_type: SkillType
    implementation_code: str = ""
    trigger_patterns: List[str] = field(default_factory=list)
    expected_inputs: List[str] = field(default_factory=list)
    expected_outputs: List[str] = field(default_factory=list)
    examples: List[Dict[str, str]] = field(default_factory=list)
    test_cases: List[Dict[str, Any]] = field(default_factory=list)
    performance_benchmarks: Dict[str, float] = field(default_factory=dict)
    training_data: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LearningCapability:
    """יכולת למידה"""
    learning_type: str  # "supervised", "unsupervised", "reinforcement"
    adaptation_speed: float = 0.5  # 0.0-1.0
    memory_integration: bool = True
    pattern_recognition: bool = True
    feedback_processing: bool = True
    self_evaluation: bool = True
    knowledge_transfer: bool = True
    learning_strategies: List[str] = field(default_factory=list)
    learning_goals: List[str] = field(default_factory=list)
    progress_tracking: Dict[str, float] = field(default_factory=dict)
    learning_history: List[Dict[str, Any]] = field(default_factory=list)


# Predefined capabilities
DEFAULT_CAPABILITIES = {
    "text_processing": Capability(
        name="text_processing",
        name_he="עיבוד טקסט",
        description="Advanced text processing and analysis",
        description_he="עיבוד וניתוח טקסט מתקדם",
        category="nlp",
        level=CapabilityLevel.ADVANCED,
        performance_metrics=["accuracy", "speed", "comprehension"]
    ),
    
    "voice_interaction": Capability(
        name="voice_interaction",
        name_he="אינטראקציה קולית",
        description="Voice recognition and synthesis",
        description_he="זיהוי קול וסינתזה קולית",
        category="audio",
        level=CapabilityLevel.INTERMEDIATE,
        prerequisites=["text_processing"],
        resource_requirements={"audio_processing": True, "microphone": True}
    ),
    
    "image_analysis": Capability(
        name="image_analysis",
        name_he="ניתוח תמונות",
        description="Computer vision and image understanding",
        description_he="ראייה ממוחשבת והבנת תמונות",
        category="vision",
        level=CapabilityLevel.ADVANCED,
        resource_requirements={"gpu": True, "image_processing": True}
    ),
    
    "web_search": Capability(
        name="web_search",
        name_he="חיפוש ברשת",
        description="Web search and information retrieval",
        description_he="חיפוש ברשת ואחזור מידע",
        category="information",
        level=CapabilityLevel.BASIC,
        dependencies=["internet_connection"]
    ),
    
    "file_operations": Capability(
        name="file_operations",
        name_he="פעולות קבצים",
        description="File system operations and management",
        description_he="פעולות מערכת קבצים וניהול",
        category="system",
        level=CapabilityLevel.INTERMEDIATE,
        resource_requirements={"file_system_access": True}
    ),
    
    "code_generation": Capability(
        name="code_generation",
        name_he="יצירת קוד",
        description="Code generation and programming assistance",
        description_he="יצירת קוד וסיוע בתכנות",
        category="programming",
        level=CapabilityLevel.EXPERT,
        prerequisites=["text_processing", "file_operations"]
    ),
    
    "data_analysis": Capability(
        name="data_analysis",
        name_he="ניתוח נתונים",
        description="Data analysis and statistical processing",
        description_he="ניתוח נתונים ועיבוד סטטיסטי",
        category="analytics",
        level=CapabilityLevel.ADVANCED,
        prerequisites=["file_operations"]
    ),
    
    "creative_writing": Capability(
        name="creative_writing",
        name_he="כתיבה יצירתית",
        description="Creative content generation and writing",
        description_he="יצירת תוכן יצירתי וכתיבה",
        category="creativity",
        level=CapabilityLevel.INTERMEDIATE,
        prerequisites=["text_processing"]
    )
}

# Predefined API integrations
DEFAULT_API_INTEGRATIONS = {
    "search_engines": APIIntegration(
        name="search_engines",
        name_he="מנועי חיפוש",
        service_type="search",
        endpoint_url="https://api.search.com",
        authentication_type="api_key",
        required_credentials=["api_key"],
        supported_operations=["search", "advanced_search", "image_search"],
        rate_limits={"requests_per_minute": 100},
        data_formats=["json", "xml"]
    ),
    
    "translation_service": APIIntegration(
        name="translation_service",
        name_he="שירות תרגום",
        service_type="translation",
        endpoint_url="https://api.translate.com",
        authentication_type="api_key",
        required_credentials=["api_key"],
        supported_operations=["translate", "detect_language", "list_languages"],
        rate_limits={"requests_per_hour": 1000},
        data_formats=["json"]
    ),
    
    "weather_service": APIIntegration(
        name="weather_service",
        name_he="שירות מזג אוויר",
        service_type="weather",
        endpoint_url="https://api.weather.com",
        authentication_type="api_key",
        required_credentials=["api_key"],
        supported_operations=["current_weather", "forecast", "historical"],
        rate_limits={"requests_per_day": 5000},
        data_formats=["json"]
    )
}