#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Agent Creation Module - ����� ����� ������
����� ������ ������, ����� ������ �� ����� AI ������� �����
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from .core.agent_engine import AgentEngine
from .core.template_manager import TemplateManager
from .core.skill_manager import SkillManager
from .core.training_engine import TrainingEngine
from .core.personality_engine import PersonalityEngine
from .ui.agent_dashboard import AgentDashboard
from .models.agent_types import AgentRole, AgentStatus

logger = logging.getLogger(__name__)


class AgentCreationModule:
    """����� ����� ������"""
    
    def __init__(self):
        """Initialize the Agent Creation Module"""
        self.name = "agent_creation"
        self.version = "2.0.0"
        self.description = "����� ������ ������ ������ ����� AI"
        self.hebrew_name = "����� ����� ������"
        self.is_active = False
        
        # Core engines
        self.agent_engine = None
        self.template_manager = None
        self.skill_manager = None
        self.training_engine = None
        self.personality_engine = None
        
        # UI components
        self.dashboard = None
        
        # Module state
        self.statistics = {
            "total_agents": 0,
            "active_agents": 0,
            "successful_interactions": 0,
            "training_sessions": 0,
            "templates_used": 0
        }
    
    def start(self) -> bool:
        """����� ������"""
        try:
            logger.info(f"[����� ����� ������] ����� �����...")
            
            # Initialize core engines
            self.agent_engine = AgentEngine()
            self.template_manager = TemplateManager()
            self.skill_manager = SkillManager()
            self.training_engine = TrainingEngine()
            self.personality_engine = PersonalityEngine()
            
            # Connect engines
            self.agent_engine.template_manager = self.template_manager
            self.agent_engine.skill_manager = self.skill_manager
            self.agent_engine.training_engine = self.training_engine
            self.agent_engine.personality_engine = self.personality_engine
            
            # Initialize UI
            self.dashboard = AgentDashboard(self.agent_engine)
            
            # Update statistics
            self._update_statistics()
            
            self.is_active = True
            logger.info(f"[����� ����� ������] ����� ������")
            return True
            
        except Exception as e:
            logger.error(f"[����� ����� ������] ����� ������: {e}")
            return False
    
    def stop(self) -> bool:
        """����� ������"""
        try:
            logger.info(f"[����� ����� ������] ����...")
            
            # Deactivate all active agents
            if self.agent_engine:
                active_agents = self.agent_engine.list_agents(active_only=True)
                for agent_info in active_agents:
                    self.agent_engine.deactivate_agent(agent_info["id"])
            
            # Save final statistics
            self._update_statistics()
            
            self.is_active = False
            logger.info(f"[����� ����� ������] ���� ������")
            return True
            
        except Exception as e:
            logger.error(f"[����� ����� ������] ����� ������: {e}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """���� ����� ������"""
        status = {
            "module": self.name,
            "hebrew_name": self.hebrew_name,
            "version": self.version,
            "description": self.description,
            "is_active": self.is_active,
            "statistics": self.statistics.copy()
        }
        
        if self.agent_engine:
            performance = self.agent_engine.get_performance_metrics()
            status["performance"] = performance
            
            # Get active agents info
            active_agents = self.agent_engine.list_agents(active_only=True)
            status["active_agents"] = [
                {
                    "id": agent["id"],
                    "name": agent["name"],
                    "role": agent["role"],
                    "interactions": agent.get("session_interactions", 0)
                }
                for agent in active_agents
            ]
        
        return status
    
    def create_agent(
        self,
        name: str,
        description: str,
        role: str = "assistant",
        template_id: str = None,
        personality_config: Dict[str, Any] = None,
        capabilities_config: Dict[str, Any] = None,
        **kwargs
    ) -> Optional[str]:
        """����� ���� ���"""
        if not self.is_active or not self.agent_engine:
            logger.error("����� ����� ������� �� �����")
            return None
        
        try:
            # Convert role string to enum
            agent_role = AgentRole(role) if role in [r.value for r in AgentRole] else AgentRole.ASSISTANT
            
            agent_id = self.agent_engine.create_agent(
                name=name,
                description=description,
                role=agent_role,
                template_id=template_id,
                personality_config=personality_config,
                capabilities_config=capabilities_config,
                custom_config=kwargs
            )
            
            if agent_id:
                self._update_statistics()
                logger.info(f"���� ���� ���: {name}")
            
            return agent_id
            
        except Exception as e:
            logger.error(f"����� ������ ����: {e}")
            return None
    
    def activate_agent(self, agent_id: str) -> bool:
        """����� ����"""
        if not self.is_active or not self.agent_engine:
            return False
        
        success = self.agent_engine.activate_agent(agent_id)
        if success:
            self._update_statistics()
        
        return success
    
    def deactivate_agent(self, agent_id: str) -> bool:
        """����� ����"""
        if not self.is_active or not self.agent_engine:
            return False
        
        success = self.agent_engine.deactivate_agent(agent_id)
        if success:
            self._update_statistics()
        
        return success
    
    def interact_with_agent(
        self,
        agent_id: str,
        message: str,
        context: Dict[str, Any] = None,
        user_id: str = None
    ) -> Optional[str]:
        """���������� �� ����"""
        if not self.is_active or not self.agent_engine:
            return None
        
        response = self.agent_engine.interact_with_agent(
            agent_id=agent_id,
            message=message,
            context=context,
            user_id=user_id
        )
        
        if response:
            self._update_statistics()
        
        return response
    
    def list_agents(self, active_only: bool = False) -> List[Dict[str, Any]]:
        """����� ������"""
        if not self.is_active or not self.agent_engine:
            return []
        
        return self.agent_engine.list_agents(active_only=active_only)
    
    def get_agent_info(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """���� �� ���� ������"""
        if not self.is_active or not self.agent_engine:
            return None
        
        agent = self.agent_engine.get_agent(agent_id)
        if not agent:
            return None
        
        return {
            "id": agent.id,
            "name": agent.name,
            "description": agent.description,
            "role": agent.role.value,
            "status": agent.status.value,
            "created_at": agent.created_at,
            "last_active": agent.last_active,
            "personality": {
                "communication_style": agent.personality.communication_style,
                "traits": agent.personality.traits,
                "language_preference": agent.personality.language_preference
            },
            "capabilities": {
                "text_processing": agent.capabilities.text_processing,
                "voice_interaction": agent.capabilities.voice_interaction,
                "image_analysis": agent.capabilities.image_analysis,
                "web_search": agent.capabilities.web_search,
                "api_integrations": agent.capabilities.api_integrations
            },
            "metrics": {
                "total_interactions": agent.metrics.total_interactions,
                "successful_interactions": agent.metrics.successful_interactions,
                "average_response_time": agent.metrics.average_response_time
            }
        }
    
    def train_agent(
        self,
        agent_id: str,
        training_data: List[Dict[str, Any]],
        training_type: str = "supervised"
    ) -> bool:
        """����� ����"""
        if not self.is_active or not self.training_engine:
            return False
        
        try:
            success = self.training_engine.train_agent(
                agent_id=agent_id,
                training_data=training_data,
                training_type=training_type
            )
            
            if success:
                self.statistics["training_sessions"] += 1
                logger.info(f"����� ���� {agent_id} ����� ������")
            
            return success
            
        except Exception as e:
            logger.error(f"����� ������ ����: {e}")
            return False
    
    def update_agent_personality(
        self,
        agent_id: str,
        personality_updates: Dict[str, Any]
    ) -> bool:
        """����� ������ ����"""
        if not self.is_active or not self.agent_engine:
            return False
        
        return self.agent_engine.update_agent_personality(
            agent_id=agent_id,
            personality_updates=personality_updates
        )
    
    def delete_agent(self, agent_id: str) -> bool:
        """����� ����"""
        if not self.is_active or not self.agent_engine:
            return False
        
        success = self.agent_engine.delete_agent(agent_id)
        if success:
            self._update_statistics()
        
        return success
    
    def get_available_templates(self) -> List[Dict[str, Any]]:
        """���� ������ ������"""
        if not self.is_active or not self.template_manager:
            return []
        
        return self.template_manager.list_templates()
    
    def get_personality_traits(self) -> Dict[str, Any]:
        """���� ������ ������ ������"""
        if not self.is_active or not self.personality_engine:
            return {}
        
        return self.personality_engine.get_available_traits()
    
    def execute_operation(self, operation: str, **kwargs) -> Any:
        """����� ����� �� ������"""
        operations = {
            "create_agent": self.create_agent,
            "activate_agent": self.activate_agent,
            "deactivate_agent": self.deactivate_agent,
            "interact_with_agent": self.interact_with_agent,
            "list_agents": self.list_agents,
            "get_agent_info": self.get_agent_info,
            "train_agent": self.train_agent,
            "update_agent_personality": self.update_agent_personality,
            "delete_agent": self.delete_agent,
            "get_available_templates": self.get_available_templates,
            "get_personality_traits": self.get_personality_traits
        }
        
        if operation in operations:
            try:
                return operations[operation](**kwargs)
            except Exception as e:
                logger.error(f"����� ������ ����� {operation}: {e}")
                return None
        else:
            logger.warning(f"����� �� �����: {operation}")
            return None
    
    def _update_statistics(self):
        """����� ����������"""
        if self.agent_engine:
            metrics = self.agent_engine.get_performance_metrics()
            self.statistics["total_agents"] = metrics.get("agents_storage_count", 0)
            self.statistics["active_agents"] = metrics.get("active_agents_count", 0)
            self.statistics["successful_interactions"] = metrics.get("successful_interactions", 0)


# Module instance for import
module_instance = AgentCreationModule()