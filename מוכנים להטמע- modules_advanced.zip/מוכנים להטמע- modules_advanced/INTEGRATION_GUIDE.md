# 🔗 מדריך אינטגרציה למערכת המרכזית

## 📋 סקירה כללית

כל המודולים במערכת מוכנים לאינטגרציה במערכת המרכזית עם ממשק גרפי. המודולים בנויים בארכיטקטורה מודולרית ומספקים API endpoints מוכנים לחיבור.

---

## 🎛️ רשימת כפתורים מומלצים לממשק:

### 1. **כפתור "החבר החכם שלי"** 🤖💙
```json
{
  "button_name": "החבר החכם שלי",
  "description": "שיחה עם עוזר AI אישי חכם",
  "module": "personal_ai_assistant",
  "action": "open_chat_interface",
  "icon": "🤖",
  "color": "#4CAF50"
}
```
**מה זה עושה:** פותח ממשק שיחה עם העוזר האישי עם אישיות חמה

### 2. **כפתור "יצירת קוד חכם"** 💻
```json
{
  "button_name": "יצירת קוד חכם", 
  "description": "יצירת קוד בכל השפות עם AI",
  "module": "advanced_coding_system",
  "action": "open_code_generator",
  "icon": "💻",
  "color": "#2196F3"
}
```
**מה זה עושה:** פותח ממשק ליצירת קוד מתקדם עם הסברים

### 3. **כפתור "מנוע התודעה"** 🧠
```json
{
  "button_name": "מנוע התודעה",
  "description": "ניתוח רגשי ותודעה מתקדם",
  "module": "consciousness_engine", 
  "action": "open_consciousness_dashboard",
  "icon": "🧠",
  "color": "#9C27B0"
}
```
**מה זה עושה:** פותח ממשק לניתוח מצב רגשי ותודעה

### 4. **כפתור "בסיס הידע החכם"** 📚
```json
{
  "button_name": "בסיס הידע החכם",
  "description": "חיפוש וניתוח מידע חכם",
  "module": "knowledge_base",
  "action": "open_knowledge_search",
  "icon": "📚", 
  "color": "#FF9800"
}
```
**מה זה עושה:** פותח ממשק לחיפוש וניתוח מידע עם AI

### 5. **כפתור "עיבוד קול חכם"** 🗣️
```json
{
  "button_name": "עיבוד קול חכם",
  "description": "זיהוי דיבור וסינתזת קול",
  "module": "voice_processing",
  "action": "open_voice_interface", 
  "icon": "🗣️",
  "color": "#E91E63"
}
```
**מה זה עושה:** פותח ממשק לעיבוד קול - דיבור לטקסט וטקסט לדיבור

### 6. **כפתור "מנתח הטקסט"** 📊
```json
{
  "button_name": "מנתח הטקסט",
  "description": "ניתוח טקסט מתקדם עם AI",
  "module": "nlp_advanced",
  "action": "open_text_analyzer",
  "icon": "📊",
  "color": "#607D8B"
}
```
**מה זה עושה:** פותח ממשק לניתוח טקסט - סנטימנט, תרגום, סיכום

---

## 🔌 Integration API Endpoints:

### למודול personal_ai_assistant:
```python
# הפעלה מהירה
POST /api/assistant/quick_chat
Body: {"message": "היי! איך אתה?"}

# יצירת עוזר חדש  
POST /api/assistant/create
Body: {"name": "שלי", "personality": "friendly"}

# שיחה עם עוזר
POST /api/assistant/{name}/chat
Body: {"message": "עזור לי עם קוד", "context": "תכנות"}
```

### למודול advanced_coding_system:
```python
# יצירת קוד
POST /api/coding/generate
Body: {"language": "python", "task": "צור משחק", "context": "פשוט"}

# ניתוח קוד
POST /api/coding/analyze  
Body: {"code": "print('hello')", "language": "python"}

# תיקון קוד
POST /api/coding/fix
Body: {"code": "broken code", "language": "python"}
```

### למודול consciousness_engine:
```python
# ניתוח רגשי
POST /api/consciousness/analyze
Body: {"text": "אני מרגיש עצוב", "depth": "deep"}

# מצב תודעה
GET /api/consciousness/state

# המלצות
POST /api/consciousness/recommendations
Body: {"current_state": "sad", "context": "work"}
```

---

## 📁 מבנה הקבצים שצריך לקחת:

### ✅ **התיקייה `/modules_advanced/` - זה הכול!**

```
/root/Effi_ai_privet/modules_advanced/
├── personal_ai_assistant/          # העוזר האישי
├── advanced_coding_system/         # מערכת קידוד מתקדמת  
├── consciousness_engine/           # מנוע התודעה
├── knowledge_base/                 # בסיס הידע
├── voice_processing/               # עיבוד קול
├── nlp_advanced/                   # עיבוד שפה מתקדם
├── local_ai_integration/           # האינטגרציה למודל המקומי
├── system_core/                    # ליבת המערכת
└── [שאר המודולים...]
```

### ❌ **אין צורך בקבצים נוספים מחוץ לתיקייה הזו!**

---

## 🛠️ הוראות התקנה למפתחי המערכת:

### 1. **העתקת המודולים:**
```bash
# העתק את כל התיקייה modules_advanced למערכת המרכזית
cp -r /root/Effi_ai_privet/modules_advanced/ [נתיב_המערכת_המרכזית]/
```

### 2. **התקנת Dependencies:**
```bash
# כל מודול יש לו קובץ requirements.txt או metadata.json עם התלויות
pip install -r modules_advanced/personal_ai_assistant/requirements.txt
pip install -r modules_advanced/advanced_coding_system/requirements.txt
# וכן הלאה לכל מודול...
```

### 3. **אתחול המודולים:**
```python
# בקוד המערכת המרכזית
import sys
sys.path.append('modules_advanced')

# ייבוא המודולים
from personal_ai_assistant import get_module as get_assistant
from advanced_coding_system import create_module as get_coding
from consciousness_engine import UnifiedAPI as get_consciousness

# אתחול
assistant = await get_assistant()
coding = await get_coding()  
consciousness = get_consciousness()
```

---

## 🎨 הצעות לעיצוב הכפתורים:

### כפתור רחב עם אייקון:
```css
.ai-module-button {
    width: 200px;
    height: 80px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
}

.ai-module-button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}
```

### דוגמה לכפתור "החבר החכם":
```html
<button class="ai-module-button" style="background: linear-gradient(45deg, #4CAF50, #45a049);">
    <span style="font-size: 24px;">🤖</span>
    <span>החבר החכם שלי</span>
</button>
```

---

## 📋 רשימת המודולים הזמינים:

| מודול | תיאור | כפתור מומלץ | צבע |
|--------|---------|-------------|-----|
| personal_ai_assistant | עוזר אישי חכם | "החבר החכם שלי" 🤖 | ירוק |
| advanced_coding_system | יצירת קוד מתקדם | "יצירת קוד חכם" 💻 | כחול |
| consciousness_engine | ניתוח תודעה | "מנוע התודעה" 🧠 | סגול |
| knowledge_base | בסיס ידע חכם | "בסיס הידע החכם" 📚 | כתום |
| voice_processing | עיבוד קול | "עיבוד קול חכם" 🗣️ | ורוד |
| nlp_advanced | עיבוד שפה | "מנתח הטקסט" 📊 | אפור |
| local_ai_integration | חיבור AI מקומי | "הגדרות AI" ⚙️ | אדום |

---

## 🔧 דוגמה לקוד אינטגרציה:

### JavaScript לכפתור "החבר החכם":
```javascript
async function openPersonalAssistant() {
    try {
        // פתיחת חלון צ'אט
        const chatWindow = window.open('/ai_chat.html', 'AI_Chat', 'width=600,height=800');
        
        // או טעינה באותו חלון
        const response = await fetch('/api/assistant/quick_chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: 'היי! איך אתה?'})
        });
        
        const data = await response.json();
        displayChatMessage(data.response);
        
    } catch (error) {
        console.error('שגיאה בפתיחת העוזר:', error);
        alert('שגיאה בחיבור לעוזר החכם');
    }
}
```

### Python Flask Route דוגמה:
```python
from flask import Flask, request, jsonify
from modules_advanced.personal_ai_assistant import quick_chat

@app.route('/api/assistant/quick_chat', methods=['POST'])
async def assistant_chat():
    data = request.json
    message = data.get('message', '')
    
    try:
        response = await quick_chat(message)
        return jsonify({'success': True, 'response': response})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
```

---

## ✅ **סיכום - מה המפתחים צריכים לעשות:**

1. **📁 העתיק את התיקייה** `modules_advanced/` למערכת
2. **🔌 הוסף את הכפתורים** לממשק הגרפי 
3. **⚙️ חבר את ה-API calls** לכל כפתור
4. **🎨 עצב את הכפתורים** כמו שאתה רוצה
5. **✅ הכול מוכן לעבודה!**

**המודולים עצמאיים לחלוטין - אין צורך בקבצים נוספים מחוץ לתיקייה!** 🎉