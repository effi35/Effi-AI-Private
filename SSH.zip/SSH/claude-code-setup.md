# 🚀 מדריך התקנה מקיף 2025 - Claude Code + VS Code + כל החידושים

## 🔥 חידושים חשובים מ-Claude 4 (מאי 2025)
- **Claude Code GA** - זמין לכולם (לא רק preview)
- **SDK רשמי** - TypeScript ו-Python
- **אינטגרציות IDE** - VS Code ו-JetBrains (Beta)
- **GitHub Actions** - Claude Code רץ ברקע
- **MCP Servers מרוחקים** - חיבור לכלים חיצוניים
- **Extended Thinking** - חשיבה עמוקה עם כלים

## 📋 דרישות מקדימות מעודכנות
- [ ] **מנוי Claude**: Pro ($15), Max ($100-200), או Enterprise
- [ ] **VS Code** עדכני + **Terminal** מתקדם
- [ ] **Node.js 20+** ו-**Python 3.10+**
- [ ] **Git** מוגדר
- [ ] **WSL2** ב-Windows (חובה!)

## 🔧 שלב 1: התקנת Claude Code המעודכנת

### התקנה גלובלית:
```bash
# Mac/Linux/WSL
npm install -g @anthropic-ai/claude-code

# בדיקת התקנה
claude --version
```

### הגדרת API Key:
```bash
# יצירת API Key ב-Anthropic Console
export ANTHROPIC_API_KEY="sk-ant-api..."

# הוספה ל-.bashrc/.zshrc
echo 'export ANTHROPIC_API_KEY="sk-ant-api..."' >> ~/.bashrc
source ~/.bashrc
```

## 🛠️ שלב 2: התקנת הרחבות Claude ל-IDE

### VS Code Extension (Beta):
```bash
# התקנה ישירות מ-Claude Code
cd your-project
claude
# בתוך Claude, הקלד:
/install-vscode
```

### JetBrains Extension:
```bash
# בתוך Claude Code:
/install-jetbrains
```

## 🗂️ שלב 3: מבנה תיקיות מתקדם עם SDK

```bash
# סקריפט התקנה משודרג
cat > ~/setup-claude-workspace-2025.sh << 'EOF'
#!/bin/bash

# צבעים
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}🚀 מתקין סביבת Claude Code 2025...${NC}"

# מבנה תיקיות מורחב
WORKSPACE="$HOME/ClaudeProjects"
mkdir -p "$WORKSPACE"/{
    projects,
    backups/{daily,weekly,git},
    logs/{claude,git,mcp},
    configs/{claude,mcp,github},
    templates/{web,python,node,react,sdk},
    shared-resources/{assets,libs,docs},
    documentation,
    scripts,
    sdk-apps,
    mcp-servers,
    .claude/{commands,cache,settings}
}

# התקנת Claude Code SDK
echo -e "${YELLOW}📦 מתקין Claude Code SDK...${NC}"
cd "$WORKSPACE/sdk-apps"

# TypeScript SDK
mkdir claude-sdk-typescript && cd claude-sdk-typescript
npm init -y
npm install @anthropic-ai/claude-code
cat > example.ts << 'TS'
import { query, type SDKMessage } from "@anthropic-ai/claude-code";

async function main() {
  const messages: SDKMessage[] = [];
  
  for await (const message of query({
    prompt: "Create a React component for a todo list",
    options: {
      maxTurns: 3,
      allowedTools: ["Read", "Write"],
      permissionMode: "acceptEdits"
    }
  })) {
    messages.push(message);
    console.log(message);
  }
}

main();
TS

# Python SDK
cd "$WORKSPACE/sdk-apps"
mkdir claude-sdk-python && cd claude-sdk-python
python3 -m venv venv
source venv/bin/activate
pip install claude-code-sdk

cat > example.py << 'PY'
import asyncio
from claude_code_sdk import query, ClaudeCodeOptions

async def main():
    options = ClaudeCodeOptions(
        max_turns=3,
        allowed_tools=["Read", "Write", "Bash"],
        permission_mode="acceptEdits"
    )
    
    async for message in query(
        prompt="Create a Flask API with authentication",
        options=options
    ):
        print(message)

asyncio.run(main())
PY

echo -e "${GREEN}✅ Claude Code SDK מותקן!${NC}"
EOF

chmod +x ~/setup-claude-workspace-2025.sh
./setup-claude-workspace-2025.sh
```

## 🔌 שלב 4: הגדרת MCP Servers (חדש!)

### MCP Servers מקומיים:
```bash
# יצירת קובץ הגדרות Claude
mkdir -p ~/.claude
cat > ~/.claude/claude.json << 'EOF'
{
  "mcpServers": {
    "filesystem": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem"],
      "env": {
        "ALLOWED_DIRECTORIES": "~/ClaudeProjects/projects"
      }
    },
    "github": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "ghp_YOUR_TOKEN_HERE"
      }
    },
    "web-search": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-omnisearch"],
      "env": {
        "BRAVE_API_KEY": "",
        "TAVILY_API_KEY": ""
      }
    }
  }
}
EOF
```

### MCP Servers מרוחקים (Remote):
```bash
# הוספת שרתים מרוחקים
claude mcp add-remote

# דוגמאות לשרתים פופולריים:
# - Zapier (חיבור ל-5000+ אפליקציות)
# - Linear (ניהול משימות)
# - Sentry (ניהול שגיאות)
# - Atlassian (Jira/Confluence)
```

### SSH MCP Server (חדש!):
```bash
# התקנת SSH MCP
cd ~/ClaudeProjects/mcp-servers
git clone https://github.com/your-mcp/sshclient
cd sshclient
npm install
npm run build

# הוספה ל-Claude
cat >> ~/.claude/claude.json << 'EOF'
,
    "sshclient": {
      "command": "node",
      "args": ["~/ClaudeProjects/mcp-servers/sshclient/build/index.js"]
    }
EOF
```

## 🎤 שלב 5: תמיכה קולית מתקדמת (כולל עברית!)

### 1. תמיכה קולית בסיסית (אנגלית):
```bash
# התקנת VS Code Speech
code --install-extension ms-vscode.vscode-speech

# הגדרות
cat > ~/.vscode/voice-settings.json << 'EOF'
{
  "accessibility.voice.keywordActivation": true,
  "accessibility.voice.speechLanguage": "en-US",
  "accessibility.voice.autoSendOnPause": true
}
EOF
```

### 2. תמיכה בעברית - פתרון מותאם:
```bash
# יצירת מערכת קולית לעברית
cat > ~/ClaudeProjects/scripts/hebrew-voice-system.py << 'EOF'
#!/usr/bin/env python3
import speech_recognition as sr
import pyttsx3
import asyncio
import json
import sys
from pathlib import Path

class HebrewVoiceAssistant:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.engine = pyttsx3.init()
        self.last_input_file = Path("/tmp/claude_voice_input.txt")
        
    def setup_hebrew(self):
        """הגדרת תמיכה בעברית"""
        # הגדרת קול עברי אם קיים
        voices = self.engine.getProperty('voices')
        for voice in voices:
            if 'hebrew' in voice.name.lower() or 'he' in voice.id:
                self.engine.setProperty('voice', voice.id)
                break
                
    def listen_hebrew(self):
        """האזנה וזיהוי בעברית"""
        with sr.Microphone() as source:
            print("🎤 מקשיב... דבר בעברית!")
            self.recognizer.adjust_for_ambient_noise(source)
            audio = self.recognizer.listen(source, timeout=10)
            
        try:
            # זיהוי עם Google (תומך עברית)
            text = self.recognizer.recognize_google(audio, language="he-IL")
            print(f"📝 זוהה: {text}")
            
            # שמירה לקובץ
            self.last_input_file.write_text(text, encoding='utf-8')
            
            # שליחה ל-Claude
            return text
            
        except sr.UnknownValueError:
            print("❌ לא הצלחתי להבין")
            return None
            
    def speak_hebrew(self, text):
        """דיבור בעברית"""
        self.engine.say(text)
        self.engine.runAndWait()

# הרצה
if __name__ == "__main__":
    assistant = HebrewVoiceAssistant()
    assistant.setup_hebrew()
    
    while True:
        text = assistant.listen_hebrew()
        if text:
            # כאן תוכל לשלוח ל-Claude
            print(f"שולח ל-Claude: {text}")
            # assistant.speak_hebrew("קיבלתי, מעבד...")
EOF

chmod +x ~/ClaudeProjects/scripts/hebrew-voice-system.py

# התקנת תלויות
pip install SpeechRecognition pyttsx3 pyaudio
```

### 3. Chrome Extension לעברית:
```bash
# יצירת תוסף Chrome לתמיכה קולית
mkdir -p ~/ClaudeProjects/chrome-hebrew-voice
cd ~/ClaudeProjects/chrome-hebrew-voice

cat > manifest.json << 'EOF'
{
  "manifest_version": 3,
  "name": "Claude Hebrew Voice",
  "version": "1.0.0",
  "description": "תמיכה קולית בעברית ל-Claude",
  "permissions": ["activeTab", "storage"],
  "action": {
    "default_popup": "popup.html"
  },
  "content_scripts": [{
    "matches": ["https://claude.ai/*"],
    "js": ["content.js"]
  }]
}
EOF
```

## 🚀 שלב 6: GitHub Actions Integration

```bash
# יצירת GitHub Action עם Claude Code
mkdir -p .github/workflows
cat > .github/workflows/claude-code-review.yml << 'EOF'
name: Claude Code Review

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  claude-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Claude Code
        run: |
          npm install -g @anthropic-ai/claude-code
          
      - name: Run Claude Code Review
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          claude-code --json "Review this PR for potential issues" \
            --context "$(git diff origin/main...HEAD)"
            
      - name: Comment on PR
        uses: actions/github-script@v7
        with:
          script: |
            // Parse Claude's response and comment
EOF
```

## 🔄 שלב 7: סנכרון בין מחשבים

```bash
# מערכת סנכרון הגדרות
cat > ~/ClaudeProjects/scripts/sync-settings.sh << 'EOF'
#!/bin/bash

SYNC_REPO="git@github.com:YOUR_USERNAME/claude-settings.git"
SYNC_DIR="$HOME/.claude-sync"

# פונקציית סנכרון
sync_settings() {
    # Clone או Pull
    if [ ! -d "$SYNC_DIR" ]; then
        git clone "$SYNC_REPO" "$SYNC_DIR"
    else
        cd "$SYNC_DIR" && git pull
    fi
    
    # סנכרון קבצים
    cp "$SYNC_DIR/claude.json" ~/.claude/
    cp "$SYNC_DIR/aliases.sh" ~/.claude/
    cp -r "$SYNC_DIR/commands/" ~/.claude/commands/
    
    echo "✅ הגדרות סונכרנו!"
}

# העלאת הגדרות
upload_settings() {
    cp ~/.claude/claude.json "$SYNC_DIR/"
    cp -r ~/.claude/commands/ "$SYNC_DIR/"
    
    cd "$SYNC_DIR"
    git add .
    git commit -m "Update settings from $(hostname)"
    git push
    
    echo "✅ הגדרות הועלו!"
}

# בחירת פעולה
case "$1" in
    sync) sync_settings ;;
    upload) upload_settings ;;
    *) echo "Usage: $0 {sync|upload}" ;;
esac
EOF

chmod +x ~/ClaudeProjects/scripts/sync-settings.sh
```

## 🌐 שלב 8: עבודה מרוחקת על שרת

```bash
# הגדרת Claude Code על שרת מרוחק
cat > ~/ClaudeProjects/scripts/remote-claude-setup.sh << 'EOF'
#!/bin/bash

# התחברות לשרת והתקנה
ssh user@your-server << 'REMOTE'
    # התקנת Node.js
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    
    # התקנת Claude Code
    npm install -g @anthropic-ai/claude-code
    
    # הגדרת API Key
    echo 'export ANTHROPIC_API_KEY="..."' >> ~/.bashrc
    
    # יצירת סקריפט עזר
    cat > ~/claude-remote.sh << 'SCRIPT'
    #!/bin/bash
    export ANTHROPIC_API_KEY="..."
    claude "$@"
SCRIPT
    chmod +x ~/claude-remote.sh
REMOTE

# יצירת Alias מקומי
echo 'alias claude-remote="ssh user@your-server ~/claude-remote.sh"' >> ~/.bashrc
EOF
```

## 💡 שלב 9: כלים וטיפים מתקדמים

### 1. Extended Thinking (חדש!):
```typescript
// TypeScript SDK עם Extended Thinking
import { query } from "@anthropic-ai/claude-code";

async function complexTask() {
  const options = {
    model: "claude-opus-4",
    thinking: {
      enabled: true,
      budget: 50000 // tokens
    },
    headers: {
      "anthropic-beta": "thinking-2025-01-31"
    }
  };
  
  for await (const msg of query({
    prompt: "think hard about this architecture",
    options
  })) {
    console.log(msg);
  }
}
```

### 2. פקודות Claude מתקדמות:
```bash
# יצירת פקודות מותאמות אישית
mkdir -p ~/.claude/commands

# פקודה לבדיקת ביצועים
cat > ~/.claude/commands/performance.md << 'EOF'
נתח את הביצועים של הקוד הנוכחי:
1. זהה בעיות ביצועים
2. הצע אופטימיזציות
3. כתוב benchmarks
4. השווה לפני ואחרי
EOF

# פקודה לתיעוד אוטומטי
cat > ~/.claude/commands/autodoc.md << 'EOF'
צור תיעוד מלא לפרויקט:
1. README.md מקיף
2. תיעוד API
3. דוגמאות שימוש
4. מדריך התקנה
EOF
```

### 3. חיבור לכלים חיצוניים:
```json
// הוספה ל-~/.claude/claude.json
{
  "mcpServers": {
    "slack": {
      "type": "remote",
      "url": "https://mcp.slack.com/v1",
      "auth": "oauth"
    },
    "notion": {
      "type": "remote", 
      "url": "https://mcp.notion.so/v1",
      "auth": "oauth"
    },
    "google-drive": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-gdrive"],
      "env": {
        "GOOGLE_CLIENT_ID": "...",
        "GOOGLE_CLIENT_SECRET": "..."
      }
    }
  }
}
```

## 🚦 שלב 10: בדיקה וניטור מתקדמים

```bash
# סקריפט בדיקה מקיף
cat > ~/ClaudeProjects/scripts/advanced-check.sh << 'EOF'
#!/bin/bash

echo "🔍 בדיקת מערכת Claude Code 2025..."

# בדיקת גרסאות
echo -e "\n📦 גרסאות:"
claude --version
node --version
python3 --version

# בדיקת MCP Servers
echo -e "\n🔌 MCP Servers:"
claude mcp list

# בדיקת SDK
echo -e "\n🛠️ SDK Status:"
if [ -f ~/ClaudeProjects/sdk-apps/claude-sdk-typescript/package.json ]; then
    echo "✅ TypeScript SDK מותקן"
fi

if [ -d ~/ClaudeProjects/sdk-apps/claude-sdk-python/venv ]; then
    echo "✅ Python SDK מותקן"
fi

# בדיקת Extensions
echo -e "\n🧩 VS Code Extensions:"
code --list-extensions | grep -E "(claude|copilot|mcp)"

# בדיקת חיבור
echo -e "\n🌐 בדיקת חיבור:"
if claude-code --json "say hello" 2>/dev/null | grep -q "Hello"; then
    echo "✅ Claude Code מחובר ועובד"
else
    echo "❌ בעיה בחיבור"
fi

echo -e "\n✨ בדיקה הושלמה!"
EOF

chmod +x ~/ClaudeProjects/scripts/advanced-check.sh
```

## 📚 משאבים נוספים מעודכנים

### תיעוד רשמי:
- **Claude Code**: https://docs.anthropic.com/claude-code
- **SDK Docs**: https://docs.anthropic.com/claude-code/sdk
- **MCP Protocol**: https://modelcontextprotocol.io
- **API Reference**: https://docs.anthropic.com/api

### קהילה ותמיכה:
- **GitHub**: https://github.com/anthropics/claude-code
- **MCP Community**: https://claudemcp.com
- **Discord**: קהילת מפתחים

### כלים נוספים:
- **Neovim Plugin**: claudecode.nvim
- **Chrome Extensions**: Claude Voice, Hebrew RTL
- **GitHub Actions**: claude-code-action

## 🎯 סיכום - מה חדש ומה משודרג?

### ✅ מה יש לך עכשיו:
1. **Claude Code GA** - גרסה יציבה, לא preview
2. **SDK רשמי** - TypeScript + Python
3. **IDE Integration** - ישירות ב-VS Code
4. **MCP Servers** - חיבור לכל כלי שתרצה
5. **Extended Thinking** - חשיבה עמוקה עם כלים
6. **GitHub Actions** - אוטומציה מלאה
7. **תמיכה קולית** - כולל פתרון לעברית
8. **סנכרון הגדרות** - בין כל המחשבים
9. **עבודה מרוחקת** - על שרתים
10. **קהילה פעילה** - המון כלים ותוספים

### 🚀 התחלה מהירה:
```bash
# בדיקת הכל
~/ClaudeProjects/scripts/advanced-check.sh

# יצירת פרויקט ראשון
cd ~/ClaudeProjects/projects
claude-code "Create a full-stack app with React and FastAPI"

# הפעלת Extended Thinking
claude-code "think harder about the best architecture for a real-time chat app"
```

**מוכן להתחיל? יאללה בוא נבנה משהו מדהים! 🔥**