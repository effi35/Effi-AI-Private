# 🚀 Claude בתוך VS Code - התקנה מלאה + סנכרון

## 🎯 מה זה נותן לך?
- **Claude בתוך VS Code** - לא צריך Terminal נפרד
- **כפתור ייעודי** - Claude זמין תמיד בצד
- **רואה את הקוד שלך** - עובד על הקבצים הפתוחים
- **סנכרון בין מחשבים** - התקנה אחת לכולם

## 📋 אפשרויות זמינות

### 1️⃣ **Claude Code Extension (הרשמי - Beta)**
- Extension רשמי של Anthropic
- משתלב עם Claude Code שבטרמינל
- עריכות inline בקבצים

### 2️⃣ **Continue.dev (המומלץ)**
- Extension פופולרי מאוד
- תומך בהרבה מודלים כולל Claude
- ממשק יפה ונוח

### 3️⃣ **Cline (Formerly Claude Dev)**
- Extension חזק מאוד
- יכולות אוטונומיות
- עובד מצוין עם Claude

### 4️⃣ **Cursor IDE**
- VS Code fork עם Claude מובנה
- החוויה הכי טובה
- עולה כסף ($20/חודש)

## 🛠️ סקריפט התקנה אוטומטי

```bash
#!/bin/bash
# save as: install-claude-vscode.sh

echo "🚀 Claude + VS Code Installer"
echo "============================="

# הגדרות
WORKSPACE="$HOME/ClaudeVSCode"
SYNC_REPO="https://github.com/YOUR_USERNAME/claude-vscode-sync.git"

# יצירת מבנה תיקיות
setup_directories() {
    echo "📁 יוצר מבנה תיקיות..."
    mkdir -p "$WORKSPACE"/{
        extensions,
        configs,
        scripts,
        sync
    }
}

# התקנת VS Code Extensions
install_extensions() {
    echo "🧩 מתקין Extensions..."
    
    # רשימת extensions
    extensions=(
        # Claude integrations
        "Continue.continue"              # Continue (המומלץ!)
        "saoudrizwan.claude-dev"        # Cline
        "anthropic.claude-code-beta"    # Claude Code Official (אם זמין)
        
        # תומכים
        "ms-vscode.vscode-speech"       # דיבור
        "GitHub.copilot"                # Copilot
        "GitHub.copilot-chat"           # Copilot Chat
        
        # כלי עזר
        "ritwickdey.LiveServer"
        "esbenp.prettier-vscode"
        "dbaeumer.vscode-eslint"
    )
    
    for ext in "${extensions[@]}"; do
        echo "Installing: $ext"
        code --install-extension "$ext" --force
    done
}

# הגדרת Continue עם Claude
setup_continue() {
    echo "⚙️ מגדיר Continue..."
    
    mkdir -p "$HOME/.continue"
    cat > "$HOME/.continue/config.json" << 'EOF'
{
  "models": [
    {
      "title": "Claude Opus",
      "provider": "anthropic",
      "model": "claude-3-opus-20240229",
      "apiKey": "${ANTHROPIC_API_KEY}"
    },
    {
      "title": "Claude Sonnet",
      "provider": "anthropic", 
      "model": "claude-3-5-sonnet-20240620",
      "apiKey": "${ANTHROPIC_API_KEY}"
    }
  ],
  "tabAutocompleteModel": {
    "title": "Claude Instant",
    "provider": "anthropic",
    "model": "claude-instant-1.2",
    "apiKey": "${ANTHROPIC_API_KEY}"
  },
  "allowAnonymousTelemetry": false,
  "embeddingsProvider": {
    "provider": "transformers.js"
  }
}
EOF
}

# הגדרת Cline
setup_cline() {
    echo "⚙️ מגדיר Cline..."
    
    # הגדרות Cline ב-VS Code
    cat > "$WORKSPACE/configs/cline-settings.json" << 'EOF'
{
  "claude-dev.apiKey": "${ANTHROPIC_API_KEY}",
  "claude-dev.model": "claude-3-opus-20240229",
  "claude-dev.autoApprove": false,
  "claude-dev.showThinking": true,
  "claude-dev.customInstructions": "תמיד כתוב הערות בעברית"
}
EOF
}

# יצירת סקריפט סנכרון
create_sync_script() {
    echo "🔄 יוצר סקריפט סנכרון..."
    
    cat > "$WORKSPACE/scripts/sync-settings.sh" << 'EOF'
#!/bin/bash

SYNC_DIR="$HOME/ClaudeVSCode/sync"
GITHUB_REPO="YOUR_GITHUB_REPO"

# סנכרון הגדרות
sync_up() {
    echo "📤 מעלה הגדרות..."
    
    # העתק הגדרות
    cp -r ~/.continue "$SYNC_DIR/"
    cp -r ~/.vscode/extensions "$SYNC_DIR/vscode-extensions/"
    
    # VS Code settings
    cp "$HOME/Library/Application Support/Code/User/settings.json" "$SYNC_DIR/" 2>/dev/null || \
    cp "$HOME/.config/Code/User/settings.json" "$SYNC_DIR/" 2>/dev/null
    
    # Git
    cd "$SYNC_DIR"
    git add .
    git commit -m "Sync settings from $(hostname)"
    git push
}

sync_down() {
    echo "📥 מוריד הגדרות..."
    
    cd "$SYNC_DIR"
    git pull
    
    # החזר הגדרות
    cp -r "$SYNC_DIR/.continue" ~/
    cp "$SYNC_DIR/settings.json" "$HOME/.config/Code/User/" 2>/dev/null
}

case "$1" in
    up) sync_up ;;
    down) sync_down ;;
    *) echo "Usage: $0 {up|down}" ;;
esac
EOF

    chmod +x "$WORKSPACE/scripts/sync-settings.sh"
}

# יצירת קובץ ZIP להעברה
create_portable_package() {
    echo "📦 יוצר חבילה ניידת..."
    
    cd "$WORKSPACE"
    
    # יצירת installer.bat ל-Windows
    cat > installer.bat << 'EOF'
@echo off
echo Installing Claude VS Code Integration...

REM Install VS Code extensions
call code --install-extension Continue.continue
call code --install-extension saoudrizwan.claude-dev

REM Copy configurations
xcopy configs %APPDATA%\Code\User\ /E /Y

echo Installation complete!
pause
EOF

    # יצירת installer.sh ל-Mac/Linux  
    cat > installer.sh << 'EOF'
#!/bin/bash
echo "Installing Claude VS Code Integration..."

# Install extensions
./scripts/install-extensions.sh

# Copy configurations
cp -r configs/* ~/.config/Code/User/

echo "Installation complete!"
EOF

    chmod +x installer.sh
    
    # יצירת ZIP
    zip -r claude-vscode-pack.zip .
    echo "✅ חבילה נוצרה: claude-vscode-pack.zip"
}

# סקריפט עזר לבדיקה
create_test_script() {
    cat > "$WORKSPACE/test-claude.sh" << 'EOF'
#!/bin/bash

echo "🔍 בודק התקנת Claude ב-VS Code..."

# בדיקת extensions
echo "Extensions מותקנים:"
code --list-extensions | grep -E "(continue|claude|copilot)"

# בדיקת API Key
if [ -n "$ANTHROPIC_API_KEY" ]; then
    echo "✅ API Key configured"
else
    echo "❌ API Key missing"
fi

# פתיחת VS Code עם Continue
echo "פותח VS Code..."
code --new-window --goto "$PWD"

echo "
💡 טיפים:
1. חפש את האייקון של Continue בצד שמאל
2. לחץ עליו ובחר Claude כמודל
3. התחל לשאול שאלות!
"
EOF
    chmod +x "$WORKSPACE/test-claude.sh"
}

# התקנה ראשית
main_install() {
    echo "🎯 מתחיל התקנה..."
    
    # בדיקת VS Code
    if ! command -v code &> /dev/null; then
        echo "❌ VS Code לא מותקן!"
        echo "הורד מ: https://code.visualstudio.com/"
        exit 1
    fi
    
    # בדיקת API Key
    if [ -z "$ANTHROPIC_API_KEY" ]; then
        read -p "Enter your Anthropic API Key: " api_key
        export ANTHROPIC_API_KEY="$api_key"
        echo "export ANTHROPIC_API_KEY='$api_key'" >> ~/.bashrc
    fi
    
    # התקנה
    setup_directories
    install_extensions
    setup_continue
    setup_cline
    create_sync_script
    create_test_script
    create_portable_package
    
    echo "
✅ התקנה הושלמה!

📁 קבצים נוצרו ב: $WORKSPACE
📦 חבילה ניידת: $WORKSPACE/claude-vscode-pack.zip

🚀 להתחיל:
1. פתח VS Code
2. חפש Continue בסרגל הצד
3. בחר Claude כמודל
4. התחל לעבוד!

💾 לסנכרון בין מחשבים:
- העלאה: ~/ClaudeVSCode/scripts/sync-settings.sh up
- הורדה: ~/ClaudeVSCode/scripts/sync-settings.sh down
"
}

# הרצה
main_install
```

## 📱 התקנה במחשב נוסף

### שיטה 1: דרך GitHub (מומלץ)
```bash
# במחשב הראשון - העלה
cd ~/ClaudeVSCode
git init
git add .
git commit -m "My Claude VSCode setup"
git remote add origin YOUR_GITHUB_REPO
git push

# במחשב השני - הורד
git clone YOUR_GITHUB_REPO ~/ClaudeVSCode
cd ~/ClaudeVSCode
./installer.sh
```

### שיטה 2: עם קובץ ZIP
```bash
# במחשב הראשון
cd ~/ClaudeVSCode
zip -r claude-setup.zip .

# העבר את הקובץ למחשב השני (USB/Email/Cloud)

# במחשב השני
unzip claude-setup.zip -d ~/ClaudeVSCode
cd ~/ClaudeVSCode
./installer.sh
```

### שיטה 3: One-liner מהאינטרנט
```bash
# אם תעלה את הסקריפט ל-GitHub Gist
curl -fsSL https://gist.github.com/YOUR_GIST/install.sh | bash
```

## 🎮 איך להשתמש

### עם Continue (המומלץ):
1. פתח VS Code
2. לחץ על אייקון Continue בצד (או Ctrl+L)
3. בחר Claude מהרשימה
4. התחל לכתוב!

### עם Cline:
1. Ctrl+Shift+P
2. הקלד "Cline"
3. בחר "Start New Chat"

### קיצורי מקלדת:
- **Ctrl+L** - פתח Continue
- **Ctrl+I** - Inline chat
- **Ctrl+K** - Quick question

## 🔧 טיפים וטריקים

### 1. הגדרות מתקדמות ל-Continue:
```json
{
  "models": [
    {
      "title": "Claude Opus - Deep Thinking",
      "provider": "anthropic",
      "model": "claude-3-opus-20240229",
      "apiKey": "${ANTHROPIC_API_KEY}",
      "contextLength": 200000,
      "systemMessage": "You are an expert developer. Always think step by step."
    }
  ],
  "slashCommands": [
    {
      "name": "test",
      "description": "Write unit tests",
      "prompt": "Write comprehensive unit tests for the selected code"
    },
    {
      "name": "hebrew",
      "description": "תשובה בעברית",
      "prompt": "ענה בעברית בלבד"
    }
  ]
}
```

### 2. Custom Keybindings:
```json
// keybindings.json
[
  {
    "key": "alt+c",
    "command": "continue.focusContinueInput"
  },
  {
    "key": "alt+enter", 
    "command": "continue.submitQuery"
  }
]
```

## 🎯 סיכום - מה קיבלת?

1. **Claude בתוך VS Code** - לא צריך לצאת מהעורך
2. **סנכרון אוטומטי** - עובד על כל המחשבים שלך
3. **חבילת ZIP** - להתקנה מהירה במחשבים נוספים
4. **כל ההגדרות** - מוכנות לשימוש

**רוצה שאעזור לך להתקין? או שיש משהו ספציפי שאתה רוצה לשנות?** 🚀