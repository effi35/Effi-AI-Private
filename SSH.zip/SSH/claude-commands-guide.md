# 📚 מדריך פקודות Claude Code - כל מה שצריך לדעת!

## 🎯 פקודות בסיסיות - חובה לדעת

### 1. הפעלה והתחלה:
```bash
# הפעלה רגילה
claude

# הפעלה בתיקייה ספציפית
claude .

# הפעלה עם פרומפט ישיר
claude "צור אפליקציית React"

# הפעלה עם קובץ
claude < instructions.txt

# הפעלה בלי אינטראקציה (לאוטומציה)
claude --no-interactive "בצע משימה"
```

### 2. המשך מאותה נקודה:
```bash
# המשך שיחה אחרונה
claude --continue

# בחירת שיחה להמשך
claude --continue-from
# (יפתח תפריט עם כל השיחות)

# שמירת שיחה לקובץ
claude --save conversation.md

# טעינת שיחה משמורה
claude --load conversation.md

# הצגת היסטוריה
claude --history
```

### 3. סריקת קבצים ותיקיות:
```bash
# סריקת כל הפרויקט
claude "סרוק את כל הקבצים בפרויקט"

# סריקה עם פילטר
claude "סרוק רק קבצי Python"

# סריקה עמוקה עם ניתוח
claude "think hard and analyze the entire codebase structure"

# יצירת מפת פרויקט
claude "create a complete project map with all files and dependencies"
```

### 4. עבודה עם קבצים:
```bash
# קריאת קובץ ספציפי
claude "read src/main.py and explain it"

# עריכת קובץ
claude "edit config.json and add new settings"

# יצירת קבצים חדשים
claude "create a new Flask API in app.py"

# מחיקת קבצים
claude "delete all .tmp files"
```

## 🔓 הרשאות אוטומטיות - עבודה בלי הפרעות!

### 1. מצבי הרשאות:
```bash
# מצב אישור אוטומטי לעריכות
claude --permission-mode acceptEdits

# מצב אישור אוטומטי לכל הפעולות (זהירות!)
claude --permission-mode acceptAll

# מצב אישור אוטומטי עם timeout
claude --permission-mode auto --timeout 3600  # שעה אחת

# דילוג על כל ההרשאות (מסוכן אבל יעיל)
claude --dangerously-skip-permissions
```

### 2. סקריפט הרשאות חכם:
```bash
# auto-claude.sh - הרצה אוטומטית עם הרשאות
cat > ~/auto-claude.sh << 'EOF'
#!/bin/bash

# הגדרות
TIMEOUT=${1:-3600}  # ברירת מחדל: שעה
TASK=${2:-"continue working on the current task"}

echo "🤖 Claude Auto Mode"
echo "⏱️  Timeout: $TIMEOUT seconds"
echo "📋 Task: $TASK"
echo "========================"

# יצירת קובץ הרשאות זמני
cat > /tmp/claude-permissions.json << PERM
{
  "autoApprove": true,
  "timeout": $TIMEOUT,
  "allowedActions": [
    "read", "write", "create", "delete",
    "execute", "git", "install"
  ],
  "restrictions": [
    "no system files",
    "no credentials",
    "no sensitive data"
  ]
}
PERM

# הפעלת Claude במצב אוטומטי
claude \
  --permission-mode acceptAll \
  --permission-config /tmp/claude-permissions.json \
  --max-turns 50 \
  --timeout $TIMEOUT \
  "$TASK"

# ניקוי
rm /tmp/claude-permissions.json
echo "✅ Auto mode completed!"
EOF

chmod +x ~/auto-claude.sh
```

### 3. יצירת פרופילי הרשאות:
```bash
# profiles/safe-mode.json - מצב בטוח
cat > ~/.claude/profiles/safe-mode.json << 'EOF'
{
  "name": "Safe Mode",
  "permissions": {
    "read": true,
    "write": false,
    "execute": false,
    "git": false
  }
}
EOF

# profiles/dev-mode.json - מצב פיתוח
cat > ~/.claude/profiles/dev-mode.json << 'EOF'
{
  "name": "Development Mode",
  "permissions": {
    "read": true,
    "write": true,
    "execute": true,
    "git": true,
    "install": true
  },
  "autoApprove": ["read", "write"],
  "requireApproval": ["execute", "install", "git push"]
}
EOF

# profiles/auto-mode.json - מצב אוטומטי מלא
cat > ~/.claude/profiles/auto-mode.json << 'EOF'
{
  "name": "Full Auto Mode",
  "permissions": {
    "all": true
  },
  "autoApprove": true,
  "timeout": 7200,
  "notifications": {
    "email": "your@email.com",
    "webhook": "https://your-webhook.com/claude-updates"
  }
}
EOF

# שימוש בפרופיל
claude --profile dev-mode
claude --profile auto-mode
```

## 🔧 פקודות מתקדמות

### 1. עבודה עם Git:
```bash
# סטטוס וcommit
claude "git status and commit all changes with a descriptive message"

# יצירת branch
claude "create a new feature branch for user authentication"

# מיזוג ופתרון קונפליקטים
claude "merge main branch and resolve any conflicts"

# היסטוריה וניתוח
claude "analyze git history and find who changed this function"
```

### 2. Model Control:
```bash
# שימוש במודל ספציפי
claude --model claude-opus-4

# החלפת מודל באמצע
/model opus  # בתוך Claude

# Extended thinking
claude "think harder about this problem"
claude "ultrathink about the architecture"
```

### 3. עבודה עם MCP Tools:
```bash
# רשימת כלים זמינים
/mcp

# הוספת MCP server
claude mcp add

# חיבור לכלי ספציפי
/mcp connect github
/mcp connect slack

# שימוש בכלי
claude "search my emails for the project proposal"
claude "create a Jira ticket for this bug"
```

## 📋 Cheat Sheet - פקודות מהירות

```bash
# === בתוך Claude ===
/help          # עזרה
/clear         # נקה שיחה
/save          # שמור שיחה
/exit          # יציאה
/model         # החלף מודל
/mcp           # כלי MCP
/think         # חשיבה עמוקה
/vim           # מצב Vim
/config        # הגדרות

# === מיוחדות ===
/terminal-setup     # הגדרת Terminal
/install-vscode     # התקנת Extension
/install-github-app # GitHub integration
/bug               # דיווח באג

# === קיצורי מקלדת ===
Ctrl+C         # עצור פעולה
Ctrl+D         # יציאה
Shift+Enter    # שורה חדשה (ב-iTerm2)
Tab            # השלמה אוטומטית
```

## 🤖 סקריפטים לעבודה אוטומטית

### 1. Background Worker:
```bash
# claude-worker.sh - עבודה ברקע
cat > ~/claude-worker.sh << 'EOF'
#!/bin/bash

# הגדרות
PROJECT_DIR="$1"
TASK_FILE="$2"
LOG_FILE="/tmp/claude-worker.log"

# פונקציית עבודה
work_in_background() {
    cd "$PROJECT_DIR"
    
    # קריאת משימות
    TASKS=$(cat "$TASK_FILE")
    
    # הפעלת Claude
    nohup claude \
        --dangerously-skip-permissions \
        --max-turns 100 \
        --output-format json \
        "$TASKS" > "$LOG_FILE" 2>&1 &
    
    echo $! > /tmp/claude-worker.pid
    echo "🤖 Claude worker started (PID: $(cat /tmp/claude-worker.pid))"
}

# פקודות
case "${3:-start}" in
    start)
        work_in_background
        ;;
    stop)
        kill $(cat /tmp/claude-worker.pid)
        echo "✋ Claude worker stopped"
        ;;
    status)
        if ps -p $(cat /tmp/claude-worker.pid) > /dev/null; then
            echo "✅ Claude worker is running"
            tail -n 20 "$LOG_FILE"
        else
            echo "❌ Claude worker is not running"
        fi
        ;;
    logs)
        tail -f "$LOG_FILE"
        ;;
esac
EOF

chmod +x ~/claude-worker.sh
```

### 2. Task Queue System:
```bash
# claude-queue.sh - מערכת תורים
cat > ~/claude-queue.sh << 'EOF'
#!/bin/bash

QUEUE_DIR="$HOME/.claude/queue"
mkdir -p "$QUEUE_DIR"

# הוספת משימה לתור
add_task() {
    local priority="${1:-normal}"
    local task="$2"
    local id=$(date +%s%N)
    
    cat > "$QUEUE_DIR/${priority}_${id}.task" << TASK
{
  "id": "$id",
  "priority": "$priority",
  "task": "$task",
  "created": "$(date -Iseconds)",
  "status": "pending"
}
TASK
    
    echo "📝 Task added: $id"
}

# עיבוד תור
process_queue() {
    echo "🔄 Processing queue..."
    
    # סדר עדיפויות: urgent -> high -> normal -> low
    for priority in urgent high normal low; do
        for task_file in "$QUEUE_DIR/${priority}_"*.task 2>/dev/null; do
            [ -f "$task_file" ] || continue
            
            # קריאת משימה
            task=$(jq -r .task "$task_file")
            id=$(jq -r .id "$task_file")
            
            echo "⚡ Processing task $id ($priority)"
            
            # הפעלת Claude
            claude --permission-mode acceptAll "$task"
            
            # סימון כהושלם
            mv "$task_file" "${task_file%.task}.done"
        done
    done
}

# ממשק
case "$1" in
    add)
        add_task "$2" "$3"
        ;;
    process)
        process_queue
        ;;
    list)
        echo "📋 Pending tasks:"
        ls -la "$QUEUE_DIR"/*.task 2>/dev/null | wc -l
        ;;
    clear)
        rm -f "$QUEUE_DIR"/*.task
        echo "🗑️ Queue cleared"
        ;;
esac
EOF

chmod +x ~/claude-queue.sh
```

### 3. Monitoring Dashboard:
```bash
# claude-monitor.sh - מערכת ניטור
cat > ~/claude-monitor.sh << 'EOF'
#!/bin/bash

while true; do
    clear
    echo "📊 Claude Code Monitor Dashboard"
    echo "================================"
    echo "🕐 $(date)"
    echo ""
    
    # סטטוס Claude
    if pgrep -f "claude" > /dev/null; then
        echo "✅ Claude Status: RUNNING"
        echo "   PID: $(pgrep -f claude)"
        echo "   CPU: $(ps aux | grep claude | awk '{print $3}')%"
        echo "   MEM: $(ps aux | grep claude | awk '{print $4}')%"
    else
        echo "❌ Claude Status: NOT RUNNING"
    fi
    
    echo ""
    
    # משימות בתור
    echo "📋 Queue Status:"
    echo "   Pending: $(ls ~/.claude/queue/*.task 2>/dev/null | wc -l)"
    echo "   Completed: $(ls ~/.claude/queue/*.done 2>/dev/null | wc -l)"
    
    echo ""
    
    # קבצים שנערכו לאחרונה
    echo "📝 Recently Modified Files:"
    find . -type f -mmin -5 2>/dev/null | head -5
    
    echo ""
    
    # לוגים אחרונים
    echo "📜 Recent Logs:"
    tail -n 5 /tmp/claude-worker.log 2>/dev/null || echo "   No logs"
    
    sleep 5
done
EOF

chmod +x ~/claude-monitor.sh
```

## 🚀 Quick Start Commands

```bash
# === התקנה מהירה ===
# 1. הכל במכה אחת
~/all-in-one-setup.sh

# 2. בדיקת מערכת
~/claude-checklist.sh

# === עבודה יומיומית ===
# עבודה רגילה
claude

# עבודה אוטומטית לשעה
~/auto-claude.sh 3600 "continue developing the API"

# הוספת משימה לתור
~/claude-queue.sh add high "fix all eslint errors"

# עיבוד תור משימות
~/claude-queue.sh process

# === ניטור ===
# הפעלת מוניטור
~/claude-monitor.sh

# בדיקת סטטוס
~/claude-worker.sh status

# === גיבוי וסנכרון ===
# גיבוי ידני
~/backup-claude.sh

# סנכרון הגדרות
~/sync-settings.sh upload
```

## 💡 טיפים להרשאות

### 1. **למשימות קצרות** (עד 30 דקות):
```bash
claude --permission-mode acceptEdits
```

### 2. **לעבודה ממושכת** (שעות):
```bash
~/auto-claude.sh 7200 "complete the entire feature"
```

### 3. **לעבודה בלילה**:
```bash
# הוסף משימות לתור
~/claude-queue.sh add urgent "deploy to production"
~/claude-queue.sh add high "run all tests"
~/claude-queue.sh add normal "update documentation"

# הפעל עיבוד אוטומטי
nohup ~/claude-queue.sh process &
```

### 4. **למצב פיתוח מלא**:
```bash
claude --profile auto-mode --dangerously-skip-permissions
```

## 🎯 סיכום

עכשיו יש לך:
1. ✅ **כל הפקודות** - מהבסיסיות ועד המתקדמות
2. ✅ **הרשאות אוטומטיות** - עבודה בלי הפרעות
3. ✅ **המשך מאותה נקודה** - שמירה וטעינה
4. ✅ **עבודה ברקע** - תורים ו-workers
5. ✅ **ניטור מלא** - dashboard חי
6. ✅ **פרופילי הרשאות** - לכל סיטואציה

**הכל מוכן! תשתמש בפקודות האלה ותחסוך המון זמן!** 🚀