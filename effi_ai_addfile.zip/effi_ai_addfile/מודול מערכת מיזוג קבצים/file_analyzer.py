import os
import hashlib
import re
import magic  # לזיהוי סוגי קבצים
import chardet
import subprocess
from typing import Dict, List, Any, Tuple, Set, Optional
import importlib

# בדיקה והתקנת תלויות דינמית למקרה שחסרות
required_modules = {
    "nltk": ["tokenize", "stem"],
    "pygments": ["lexers", "token"],
    "pillow": ["Image"],
    "python-magic": []
}

class LanguageDetector:
    """מחלקה לזיהוי שפות תכנות"""
    
    def __init__(self):
        self.language_patterns = {
            "python": [r'\.py$', r'import\s+', r'from\s+\w+\s+import', r'def\s+\w+\s*\(', r'class\s+\w+\s*\('],
            "javascript": [r'\.js$', r'\.jsx$', r'function\s+\w+\s*\(', r'const\s+\w+\s*=', r'var\s+\w+\s*=', r'let\s+\w+\s*=', r'import\s+.*from', r'export\s+'],
            "typescript": [r'\.ts$', r'\.tsx$', r'interface\s+\w+', r'type\s+\w+', r'class\s+\w+'],
            "java": [r'\.java$', r'public\s+class', r'private\s+\w+', r'protected\s+\w+', r'package\s+\w+', r'import\s+\w+'],
            "c": [r'\.c$', r'\.h$', r'#include', r'int\s+main\s*\('],
            "cpp": [r'\.cpp$', r'\.hpp$', r'#include', r'namespace\s+\w+', r'template\s*<'],
            "csharp": [r'\.cs$', r'namespace\s+\w+', r'using\s+\w+', r'public\s+class'],
            "go": [r'\.go$', r'package\s+\w+', r'import\s+\(', r'func\s+\w+\s*\('],
            "ruby": [r'\.rb$', r'require\s+', r'def\s+\w+', r'class\s+\w+', r'module\s+\w+'],
            "php": [r'\.php$', r'\<\?php', r'function\s+\w+\s*\(', r'class\s+\w+'],
            "rust": [r'\.rs$', r'fn\s+\w+', r'struct\s+\w+', r'impl\s+', r'use\s+\w+'],
            "swift": [r'\.swift$', r'import\s+\w+', r'func\s+\w+', r'class\s+\w+', r'struct\s+\w+'],
            "kotlin": [r'\.kt$', r'fun\s+\w+', r'class\s+\w+', r'val\s+\w+', r'var\s+\w+'],
            "scala": [r'\.scala$', r'def\s+\w+', r'class\s+\w+', r'object\s+\w+', r'trait\s+\w+'],
            "html": [r'\.html$', r'\.htm$', r'\<html', r'\<head', r'\<body'],
            "css": [r'\.css$', r'\{', r'\.[\w-]+\s*\{', r'#[\w-]+\s*\{'],
            "xml": [r'\.xml$', r'\<\?xml', r'\<[a-zA-Z]+(\s+[\w-]+=\".*?\")*\s*\/?\>'],
            "json": [r'\.json$', r'\{\"', r'\[\"'],
            "yaml": [r'\.ya?ml$', r'[\w-]+\s*:\s*[\w\s-]+'],
            "dart": [r'\.dart$', r'void\s+main', r'class\s+\w+', r'import\s+'],
            "shell": [r'\.sh$', r'\#\!/bin/', r'function\s+\w+\s*\{'],
            "sql": [r'\.sql$', r'SELECT', r'INSERT', r'CREATE\s+TABLE']
        }
        
    def detect_language(self, file_path: str, content: Optional[str] = None) -> str:
        """זיהוי שפת התכנות לפי תוכן ושם הקובץ"""
        file_name = os.path.basename(file_path).lower()
        
        if content is None:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(4096)  # קריאת 4KB ראשונים מספיקה לרוב
            except:
                content = ""
        
        # בדיקה לפי סיומת וביטויים רגולריים
        scores = {lang: 0 for lang in self.language_patterns}
        
        for lang, patterns in self.language_patterns.items():
            # בדיקת סיומת (ניקוד גבוה)
            for pattern in patterns:
                if pattern.startswith(r'\.') and re.search(pattern, file_name):
                    scores[lang] += 10
                elif content and re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                    scores[lang] += 1
        
        # בחירת השפה עם הניקוד הגבוה ביותר
        if max(scores.values()) > 0:
            return max(scores.items(), key=lambda x: x[1])[0]
        
        # אם לא זוהתה שפה, ננסה לפי סיומת
        ext = os.path.splitext(file_path)[1].lower()
        ext_to_lang = {
            '.py': 'python', '.js': 'javascript', '.ts': 'typescript', 
            '.java': 'java', '.c': 'c', '.cpp': 'cpp', '.cs': 'csharp',
            '.go': 'go', '.rb': 'ruby', '.php': 'php', '.rs': 'rust',
            '.swift': 'swift', '.kt': 'kotlin', '.scala': 'scala',
            '.html': 'html', '.css': 'css', '.xml': 'xml', '.json': 'json',
            '.yml': 'yaml', '.yaml': 'yaml', '.dart': 'dart', '.sh': 'shell',
            '.sql': 'sql', '.jsx': 'javascript', '.tsx': 'typescript'
        }
        
        return ext_to_lang.get(ext, 'unknown')

class MediaAnalyzer:
    """מחלקה לניתוח קבצי מדיה (תמונות, וידאו, אודיו)"""
    
    def __init__(self):
        self.supported_extensions = {
            'image': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp', '.svg'],
            'video': ['.mp4', '.avi', '.mov', '.wmv