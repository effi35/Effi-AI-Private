# הוראות התקנה והפעלה מפורטות
## מאחד קוד חכם Pro - מודול למערכת Effi-AI Private

## 📋 תוכן עניינים
- [דרישות מערכת](#דרישות-מערכת)
- [התקנה בסביבת לינוקס/מק](#התקנה-בסביבת-לינוקסמק)
- [התקנה בסביבת חלונות](#התקנה-בסביבת-חלונות)
- [בדיקת תקינות ההתקנה](#בדיקת-תקינות-ההתקנה)
- [הפעלת השרת](#הפעלת-השרת)
- [הגדרות מתקדמות](#הגדרות-מתקדמות)
- [התקנה כ-PWA](#התקנה-כ-pwa)
- [פתרון בעיות התקנה נפוצות](#פתרון-בעיות-התקנה-נפוצות)
- [הסרת התקנה](#הסרת-התקנה)

## 🖥️ דרישות מערכת

### דרישות חומרה מינימליות:
- **מעבד**: כל מעבד מודרני עם 2 ליבות ומעלה
- **זיכרון RAM**: 1GB פנוי לפחות
- **דיסק**: 500MB פנויים לפחות
- **רשת**: חיבור אינטרנט להורדת תלויות (נדרש רק בהתקנה)

### דרישות תוכנה:
- **מערכת הפעלה**: Windows 10+, macOS 10.14+, או Linux (Ubuntu 18.04+, Debian 10+, וכו')
- **Python**: גרסה 3.6 ומעלה
- **pip**: גרסה עדכנית
- **דפדפן**: Chrome 76+, Firefox 67+, Safari 13+, Edge 79+ (לתמיכה מלאה ב-PWA)
- **הרשאות**: הרשאות כתיבה לתיקיית ההתקנה

### בדיקת דרישות:
```bash
# בדיקת גרסת Python
python3 --version
# או בחלונות לעתים:
python --version

# בדיקת pip
pip --version
# או לעתים:
pip3 --version

# בדיקת מקום פנוי בדיסק (לינוקס/מק)
df -h .

# בדיקת זיכרון RAM (לינוקס)
free -h
```

## 📥 התקנה בסביבת לינוקס/מק

### 1. הכנת סביבת העבודה:
```bash
# 1. יצירת תיקייה לפרויקט (אופציונלי)
mkdir -p ~/effi-ai/modules
cd ~/effi-ai/modules

# 2. הורדת הקוד ממאגר Git (אם זמין)
git clone https://github.com/effi-ai/smart-code-merger-pro.git
cd smart-code-merger-pro

# אם אין גישה ל-Git, אפשר להוריד את חבילת הקוד
# curl -LO https://example.com/smart-code-merger-pro.zip
# unzip smart-code-merger-pro.zip
# cd smart-code-merger-pro
```

### 2. הרצת סקריפט ההתקנה:
```bash
# 1. הענקת הרשאות הרצה לסקריפט
chmod +x install.sh

# 2. הרצת סקריפט ההתקנה
./install.sh
```

### 3. התקנה ידנית (אם הסקריפט נכשל):
```bash
# 1. יצירת סביבה וירטואלית (אופציונלי אך מומלץ)
python3 -m venv venv
source venv/bin/activate

# 2. התקנת תלויות
pip install -r requirements.txt

# 3. יצירת תיקיות נדרשות
mkdir -p smart_code_merger_pro/logs
mkdir -p smart_code_merger_pro/uploads
mkdir -p smart_code_merger_pro/temp
```

## 🪟 התקנה בסביבת חלונות

### 1. הכנת סביבת העבודה:
```powershell
# 1. יצירת תיקייה לפרויקט (אופציונלי)
mkdir "C:\effi-ai\modules"
cd "C:\effi-ai\modules"

# 2. הורדת הקוד ממאגר Git (אם זמין)
git clone https://github.com/effi-ai/smart-code-merger-pro.git
cd smart-code-merger-pro

# אם אין גישה ל-Git, הורד את חבילת הקוד והוצא אותה לתיקייה
```

### 2. הרצת סקריפט ההתקנה:
```powershell
# שיטה 1: הרצה דרך פאוורשל
.\install.sh

# שיטה 2: באמצעות bash אם מותקן (WSL או Git Bash)
bash install.sh
```

### 3. התקנה ידנית (אם הסקריפט נכשל):
```powershell
# 1. יצירת סביבה וירטואלית (אופציונלי אך מומלץ)
python -m venv venv
.\venv\Scripts\activate

# 2. התקנת תלויות
pip install -r requirements.txt

# 3. יצירת תיקיות נדרשות
mkdir smart_code_merger_pro\logs
mkdir smart_code_merger_pro\uploads
mkdir smart_code_merger_pro\temp
```

## ✅ בדיקת תקינות ההתקנה

```bash
# 1. בדיקת מבנה הקבצים והתיקיות
ls -la  # בלינוקס/מק
dir     # בחלונות

# 2. בדיקת הימצאות קבצים קריטיים
if [ -f "pwa_server.py" ] && [ -f "smart_code_merger_pro/module.py" ] && [ -f "smart_code_merger_pro/metadata.json" ]; then
    echo "ההתקנה נראית תקינה"
else
    echo "חסרים קבצים קריטיים"
fi

# 3. בדיקת תלויות Python
pip list | grep -E "flask|werkzeug|nltk|fuzzywuzzy|numpy"
```

בדיקה מקיפה יותר:
```bash
# הרצת סקריפט בדיקה (אם זמין)
python tests/check_installation.py
```

## 🚀 הפעלת השרת

### הפעלה בסיסית:
```bash
# הפעלת שרת ה-PWA
python pwa_server.py
```

לאחר ההפעלה, תראה הודעה כמו:
```
✅ שרת PWA פעיל בכתובת http://localhost:5000
```

גש לכתובת זו בדפדפן כדי להשתמש במאחד קוד חכם Pro.

### הפעלה עם פרמטרים:
```bash
# שינוי פורט
PORT=8080 python pwa_server.py

# הפעלה עם מצב דיבאג מכובה (לשימוש בסביבת ייצור)
python pwa_server.py --no-debug

# הגדרת תיקיית לוגים מותאמת
LOGS_DIR=/var/log/smart_code_merger python pwa_server.py
```

### הפעלה כשירות מערכת (systemd) בלינוקס:
```bash
# 1. יצירת קובץ שירות
sudo nano /etc/systemd/system/smart-code-merger.service
```

תוכן הקובץ:
```ini
[Unit]
Description=Smart Code Merger Pro PWA Server
After=network.target

[Service]
User=username
WorkingDirectory=/path/to/smart-code-merger-pro
ExecStart=/usr/bin/python3 /path/to/smart-code-merger-pro/pwa_server.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

```bash
# 2. טעינת השירות והפעלתו
sudo systemctl daemon-reload
sudo systemctl enable smart-code-merger
sudo systemctl start smart-code-merger

# 3. בדיקת סטטוס
sudo systemctl status smart-code-merger
```

## ⚙️ הגדרות מתקדמות

### קובץ תצורה (config.json):
אם תצטרך להתאים את התנהגות המערכת, צור או ערוך את קובץ התצורה:

```bash
nano smart_code_merger_pro/config.json
```

דוגמה לתצורה מותאמת:
```json
{
  "file_types": "*.py;*.js;*.html;*.css;*.java;*.xml;*.json;*.md;*.txt;*.jsx;*.ts;*.tsx",
  "project_detection": {
    "min_files_for_project": 3,
    "key_files": ["package.json", ".gitignore", "README.md", "setup.py", "pom.xml", "tsconfig.json"],
    "min_relationship_score": 0.5,
    "use_advanced_analysis": true
  },
  "merger": {
    "preserve_comments": true,
    "date_based_priority": true,
    "smart_structure_analysis": true,
    "conflict_resolution": "smart",
    "create_zip": true
  },
  "file_handling": {
    "process_binary_files": true,
    "process_documents": true,
    "excluded_extensions": [".exe", ".dll", ".so", ".pyc", ".pyo", ".pyd", ".class"]
  },
  "logging": {
    "level": "INFO",
    "max_size_mb": 10,
    "backup_count": 5
  },
  "performance": {
    "max_threads": 4,
    "chunk_size": 500000
  },
  "ui": {
    "theme": "light",
    "animations": true,
    "expanded_info": true
  }
}
```

### הגדרת לוגים:
```bash
nano smart_code_merger_pro/logging.json
```

דוגמה להגדרות לוגים מתקדמות:
```json
{
  "version": 1,
  "disable_existing_loggers": false,
  "formatters": {
    "standard": {
      "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    },
    "detailed": {
      "format": "%(asctime)s - %(name)s - %(levelname)s - %(module)s - %(funcName)s - %(lineno)d - %(message)s"
    }
  },
  "handlers": {
    "console": {
      "class": "logging.StreamHandler",
      "level": "INFO",
      "formatter": "standard",
      "stream": "ext://sys.stdout"
    },
    "file": {
      "class": "logging.handlers.RotatingFileHandler",
      "level": "DEBUG",
      "formatter": "detailed",
      "filename": "smart_code_merger_pro/logs/app.log",
      "maxBytes": 10485760,
      "backupCount": 5,
      "encoding": "utf8"
    }
  },
  "loggers": {
    "": {
      "handlers": ["console", "file"],
      "level": "INFO",
      "propagate": true
    }
  }
}
```

## 📱 התקנה כ-PWA

המודול תומך בהתקנה כ-Progressive Web App (PWA), המאפשר גישה מהירה יותר וחוויית משתמש דומה לאפליקציה מקומית:

### בכרום (Chrome):
1. פתח את הדפדפן בכתובת `http://localhost:5000`
2. חפש את אייקון ההתקנה (➕) בשורת הכתובת
3. לחץ על האייקון והמשך בהוראות ההתקנה
4. האפליקציה תותקן ותופיע בתפריט ההתחלה/מסך הבית

### בפיירפוקס (Firefox):
1. פתח את הדפדפן בכתובת `http://localhost:5000`
2. חפש את אייקון ההתקנה (🏠) בשורת הכתובת
3. לחץ על "התקן" (Install)
4. האפליקציה תותקן ותופיע בתפריט ההתחלה/מסך הבית

### בסאפרי (Safari - macOS/iOS):
1. פתח את הדפדפן בכתובת `http://localhost:5000`
2. לחץ על כפתור השיתוף (Share - 📤)
3. בחר ב"הוסף למסך הבית" (Add to Home Screen)
4. לחץ על "הוסף" (Add)

### בקצה (Edge):
1. פתח את הדפדפן בכתובת `http://localhost:5000`
2. לחץ על "..." בפינה הימנית העליונה
3. בחר ב"יישומים" (Apps) ולאחר מכן "התקן אתר זה כאפליקציה" (Install this site as an app)
4. אשר את ההתקנה

## 🔧 פתרון בעיות התקנה נפוצות

### בעיית הרשאות (לינוקס/מק):
```bash
# הענקת הרשאות הרצה
chmod +x install.sh
chmod +x pwa_server.py

# הענקת הרשאות כתיבה לתיקיות
chmod -R 755 smart_code_merger_pro/
```

### בעיית תלויות חסרות:
```bash
# התקנה מחדש של כל התלויות
pip install -r requirements.txt --force-reinstall

# בדיקת התקנת תלויות ספציפיות
pip show flask
pip show nltk
```

### בעיית פורט תפוס:
```bash
# בדיקת מי משתמש בפורט 5000
# לינוקס:
sudo lsof -i :5000
# מק:
sudo lsof -i tcp:5000
# חלונות:
netstat -ano | findstr :5000

# שינוי הפורט בקוד
# פתח את pwa_server.py ושנה את השורה:
# port = int(os.environ.get('PORT', 5000))
# לפורט אחר, למשל:
# port = int(os.environ.get('PORT', 8080))
```

### בעיות Python בחלונות:
```powershell
# בדיקת ברירת המחדל של Python
python --version

# אם יש שגיאה, נסה להשתמש בנתיב מלא
C:\Python39\python.exe pwa_server.py

# או הוסף את Python לנתיב (PATH)
```

### בעיית קידוד תווים:
```bash
# הגדרת קידוד בהרצת הסקריפט
export PYTHONIOENCODING=utf-8
python pwa_server.py

# בחלונות:
set PYTHONIOENCODING=utf-8
python pwa_server.py
```

### אבחון מתקדם:
```bash
# הרצת השרת במצב דיבאג מפורט
python -m pdb pwa_server.py

# בדיקת לוגים אחרונים
tail -n 50 smart_code_merger_pro/logs/app.log
```

## 🗑️ הסרת התקנה

אם תרצה להסיר את ההתקנה של המודול:

### לינוקס/מק:
```bash
# 1. עצירת השרת אם הוא פועל
pkill -f pwa_server.py

# 2. אם המודול מותקן כשירות מערכת
sudo systemctl stop smart-code-merger
sudo systemctl disable smart-code-merger
sudo rm /etc/systemd/system/smart-code-merger.service
sudo systemctl daemon-reload

# 3. מחיקת תיקיית הפרויקט
rm -rf /path/to/smart-code-merger-pro

# 4. הסרת התלויות (אופציונלי, אם הותקנו בסביבה גלובלית)
pip uninstall -r /path/to/backed-up-requirements.txt
```

### חלונות:
```powershell
# 1. עצירת השרת אם הוא פועל
taskkill /F /IM python.exe /FI "WINDOWTITLE eq pwa_server"

# 2. מחיקת תיקיית הפרויקט
rmdir /S /Q "C:\path\to\smart-code-merger-pro"

# 3. הסרת התלויות (אופציונלי)
pip uninstall -r "C:\path\to\backed-up-requirements.txt"
```

## ✅ סיכום

לאחר ביצוע ההתקנה וההפעלה בהצלחה:
1. השרת ירוץ בכתובת `http://localhost:5000` (או הפורט שהגדרת)
2. תוכל לגשת לממשק המשתמש דרך הדפדפן
3. תוכל להתקין את האפליקציה כ-PWA לגישה מהירה יותר
4. המודול יהיה מוכן לשימוש כחלק ממערכת Effi-AI Private

אם נתקלת בבעיות או שאלות נוספות, אנא פנה למדריך פתרון הבעיות המורחב או צור קשר עם צוות התמיכה.
