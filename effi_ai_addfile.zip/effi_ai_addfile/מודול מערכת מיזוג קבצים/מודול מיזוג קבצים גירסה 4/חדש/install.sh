#!/bin/bash

# סקריפט התקנה למאחד קוד חכם Pro 2.0
# ===================================

echo "🚀 התקנת מאחד קוד חכם Pro 2.0 מתחילה..."
echo "============================================="

# תיקיית בסיס
BASE_DIR="$(pwd)/smart_code_merger_pro"
mkdir -p "$BASE_DIR"

# יצירת תיקיות
echo "📁 יוצר מבנה תיקיות..."
mkdir -p "$BASE_DIR/core"
mkdir -p "$BASE_DIR/utils"
mkdir -p "$BASE_DIR/ui"
mkdir -p "$BASE_DIR/api"
mkdir -p "$BASE_DIR/api/endpoints"
mkdir -p "$BASE_DIR/models"
mkdir -p "$BASE_DIR/assets/css"
mkdir -p "$BASE_DIR/assets/js"
mkdir -p "$BASE_DIR/assets/images"
mkdir -p "$BASE_DIR/pwa"
mkdir -p "$BASE_DIR/logs"
mkdir -p "$BASE_DIR/uploads"
mkdir -p "$BASE_DIR/temp"
mkdir -p "$BASE_DIR/versions"
mkdir -p "$BASE_DIR/security_reports"
mkdir -p "$BASE_DIR/sandboxes"
mkdir -p "$BASE_DIR/remote_cache"
mkdir -p "$BASE_DIR/docs/api_docs"
mkdir -p "$BASE_DIR/docs/user_guide"
mkdir -p "$BASE_DIR/docs/developer_docs"
mkdir -p "$BASE_DIR/docs/images"

echo "✅ מבנה תיקיות נוצר בהצלחה!"

# התקנת תלויות Python
echo "📦 מתקין תלויות Python..."

# בדיקה אם pip זמין
if command -v pip3 &>/dev/null; then
    PIP_CMD="pip3"
elif command -v pip &>/dev/null; then
    PIP_CMD="pip"
else
    echo "❌ שגיאה: pip לא נמצא. אנא התקן Python ו-pip לפני המשך ההתקנה."
    exit 1
fi

# יצירת קובץ requirements.txt
cat > "$BASE_DIR/requirements.txt" << 'EOF'
Flask>=2.1.1
Flask-Cors>=3.0.10
werkzeug>=2.1.1
python-dateutil>=2.8.2
chardet>=4.0.0
numpy>=1.22.0
nltk>=3.7
fuzzywuzzy>=0.18.0
scikit-learn>=1.0.2
tensorflow>=2.9.0
joblib>=1.1.0
pandas>=1.4.2
pillow>=9.1.0
pytesseract>=0.3.9
python-magic>=0.4.25
pytest>=7.1.2
gitpython>=3.1.27
bandit>=1.7.4
safety>=2.1.1
difflib-unified>=0.2.0
pygments>=2.12.0
jsonschema>=4.6.0
requests>=2.28.0
boto3>=1.24.0
pymongo>=4.1.1
paramiko>=2.11.0
webdav3.client>=3.14.6
pysmb>=1.2.9
beautifulsoup4>=4.11.1
EOF

# התקנת התלויות
$PIP_CMD install -r "$BASE_DIR/requirements.txt"

echo "✅ תלויות Python הותקנו בהצלחה!"

# יצירת קובץ metadata.json
echo "📄 יוצר קובץ metadata.json..."

cat > "$BASE_DIR/metadata.json" << 'EOF'
{
  "name": "smart_code_merger_pro",
  "version": "2.0.0",
  "description": "מודול חכם מורחב לאיחוד קבצי ZIP עם קוד ממקורות שונים, ניתוח מעמיק, ניהול גרסאות וסריקת אבטחה",
  "author": "Claude AI",
  "license": "MIT",
  "main": "module.py",
  "module_dependencies": [],
  "dependencies": {
    "python_packages": [
      "python-dateutil>=2.8.2",
      "chardet>=4.0.0",
      "numpy>=1.22.0",
      "nltk>=3.7",
      "fuzzywuzzy>=0.18.0",
      "flask>=2.1.1",
      "flask-cors>=3.0.10",
      "werkzeug>=2.1.1",
      "scikit-learn>=1.0.2",
      "tensorflow>=2.9.0",
      "joblib>=1.1.0",
      "pandas>=1.4.2",
      "pillow>=9.1.0",
      "pytesseract>=0.3.9",
      "python-magic>=0.4.25",
      "pytest>=7.1.2",
      "gitpython>=3.1.27",
      "bandit>=1.7.4",
      "safety>=2.1.1",
      "difflib-unified>=0.2.0"
    ]
  },
  "ui_components": {
    "settings_tab": true,
    "main_tab": true,
    "diff_viewer": true,
    "version_manager": true,
    "security_scanner": true
  },
  "hooks": [
    "system_startup",
    "system_shutdown",
    "project_detection",
    "file_merge",
    "security_scan",
    "version_change"
  ],
  "features": {
    "project_detection": true,
    "content_analysis": true,
    "system_merge": true,
    "document_analysis": true,
    "version_management": true,
    "security_scanning": true,
    "code_completion": true,
    "code_running": true,
    "media_handling": true,
    "remote_storage": true,
    "export_import": true,
    "ci_cd_integration": true
  }
}
EOF

echo "✅ קובץ metadata.json נוצר בהצלחה!"

# יצירת קובץ config.json
echo "📄 יוצר קובץ config.json..."

cat > "$BASE_DIR/config.json" << 'EOF'
{
  "file_types": "*.py;*.js;*.html;*.css;*.java;*.xml;*.json;*.md;*.txt;*.c;*.cpp;*.cs;*.go;*.rb;*.php;*.scala;*.swift;*.ts;*.jsx;*.tsx;*.vue;*.rs;*.kt;*.dart;*.sql;*.sh;*.bat;*.yaml;*.yml;*.toml;*.ini;*.config;*.jpg;*.png;*.gif;*.svg;*.mp4;*.mp3;*.wav;*.pdf;*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx",
  "project_detection": {
    "min_files_for_project": 2,
    "key_files": [
      "package.json", ".gitignore", "README.md", "setup.py", "pom.xml", 
      "build.gradle", "Makefile", "CMakeLists.txt", ".travis.yml", 
      "Dockerfile", "docker-compose.yml", "requirements.txt", "Cargo.toml",
      "pubspec.yaml", "tsconfig.json", "tslint.json", ".eslintrc"
    ],
    "min_relationship_score": 0.5,
    "use_advanced_analysis": true,
    "use_machine_learning": true,
    "ml_model_path": "models/project_detector.pkl",
    "crosscheck_percent": 100
  },
  "merger": {
    "preserve_comments": true,
    "date_based_priority": true,
    "smart_structure_analysis": true,
    "conflict_resolution": "smart",
    "create_zip": true,
    "max_sources": 10,
    "backup_originals": true
  },
  "version_management": {
    "enabled": true,
    "max_versions": 10,
    "compression": "gzip",
    "storage_path": "versions",
    "include_metadata": true,
    "branch_tracking": true
  },
  "file_handling": {
    "process_binary_files": true,
    "process_documents": true,
    "process_media": true,
    "excluded_extensions": [".exe", ".dll", ".so", ".pyc", ".pyo", ".pyd", ".class", ".o", ".obj"],
    "max_file_size_mb": 50,
    "detect_encoding": true
  },
  "security_scanning": {
    "enabled": true,
    "scan_level": "medium",
    "excluded_patterns": ["node_modules", "venv", "__pycache__", ".git"],
    "vulnerability_db_update": true,
    "report_path": "security_reports"
  },
  "code_completion": {
    "enabled": true,
    "suggestions_limit": 5,
    "context_lines": 10,
    "supported_languages": ["python", "javascript", "java", "c", "cpp"]
  },
  "code_running": {
    "enabled": true,
    "sandbox_enabled": true,
    "timeout_seconds": 30,
    "memory_limit_mb": 512,
    "supported_languages": ["python", "javascript", "bash"]
  },
  "system_merge": {
    "allow_cross_technology": true,
    "detect_conflicts": true,
    "rename_conflicts": true,
    "create_zip": true,
    "smart_integration": true
  },
  "remote_storage": {
    "enabled": true,
    "types": ["local", "ssh", "s3", "ftp", "webdav", "smb", "nfs"],
    "timeout_seconds": 30,
    "cache_enabled": true,
    "cache_expiry_seconds": 3600
  },
  "logging": {
    "level": "INFO",
    "max_size_mb": 10,
    "backup_count": 5,
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "log_requests": true,
    "performance_metrics": true
  },
  "performance": {
    "max_threads": 8,
    "chunk_size": 1000000,
    "cache_enabled": true,
    "cache_size_mb": 100,
    "batch_processing": true
  },
  "ui": {
    "theme": "auto",
    "animations": true,
    "expanded_info": true,
    "max_file_preview_kb": 500,
    "syntax_highlighting": true,
    "show_line_numbers": true,
    "auto_refresh": true,
    "multi_file_view": true
  },
  "api": {
    "enabled": true,
    "require_auth": true,
    "rate_limit": 100,
    "cors_enabled": true,
    "versions": ["v1", "v2"],
    "documentation": true,
    "swagger_enabled": true
  },
  "export_import": {
    "formats": ["json", "yaml", "xml", "csv"],
    "include_settings": true,
    "include_versions": true,
    "import_validation": true
  },
  "ci_cd": {
    "providers": ["jenkins", "github", "gitlab", "travis", "circle", "azure", "aws"],
    "webhook_enabled": true,
    "artifact_storage": true,
    "report_generation": true
  }
}
EOF

echo "✅ קובץ config.json נוצר בהצלחה!"

# יצירת קובץ languages_config.json
echo "📄 יוצר קובץ languages_config.json..."

cat > "$BASE_DIR/languages_config.json" << 'EOF'
{
  "python": {
    "command": "python",
    "extension": ".py",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["python", "--version"]
  },
  "javascript": {
    "command": "node",
    "extension": ".js",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["node", "--version"]
  },
  "typescript": {
    "command": "ts-node",
    "extension": ".ts",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["ts-node", "--version"]
  },
  "bash": {
    "command": "bash",
    "extension": ".sh",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["bash", "--version"]
  },
  "java": {
    "command": "java",
    "extension": ".java",
    "compile_command": "javac",
    "compile_args": [],
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["java", "--version"]
  },
  "c": {
    "command": "./a.out",
    "extension": ".c",
    "compile_command": "gcc",
    "compile_args": ["-o", "a.out"],
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["gcc", "--version"]
  },
  "cpp": {
    "command": "./a.out",
    "extension": ".cpp",
    "compile_command": "g++",
    "compile_args": ["-o", "a.out"],
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["g++", "--version"]
  },
  "php": {
    "command": "php",
    "extension": ".php",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["php", "--version"]
  },
  "ruby": {
    "command": "ruby",
    "extension": ".rb",
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["ruby", "--version"]
  },
  "go": {
    "command": "go",
    "extension": ".go",
    "args": ["run"],
    "env": {},
    "file_position": "{file}",
    "version_command": ["go", "version"]
  },
  "rust": {
    "command": "./target/debug/main",
    "extension": ".rs",
    "compile_command": "rustc",
    "compile_args": ["-o", "target/debug/main"],
    "args": [],
    "env": {},
    "file_position": "{file}",
    "version_command": ["rustc", "--version"]
  }
}
EOF

echo "✅ קובץ languages_config.json נוצר בהצלחה!"

# יצירת קובץ module.py - הקובץ המרכזי והחשוב ביותר!
echo "📝 יוצר קובץ module.py המרכזי..."

cat > "$BASE_DIR/module.py" << 'EOF'
#!/usr/bin/env python3
"""
מודול ראשי למאחד קוד חכם Pro 2.0

מודול זה מכיל את הלוגיקה המרכזית למערכת איחוד קוד חכם.
כולל: זיהוי פרויקטים, ניתוח קשרים, מיזוג קבצים, ניהול גרסאות,
סריקות אבטחה, הרצת קוד, השלמת קוד, וגישה לאחסון מרוחק.
"""

import os
import sys
import json
import logging
import datetime
import tempfile
import zipfile
import shutil
import uuid
import hashlib
import re
from typing import Dict, List, Tuple, Any, Optional, Union

# הגדרת לוגר
logger = logging.getLogger(__name__)

class SmartCodeMergerProModule:
    """מחלקה ראשית למודול איחוד קוד חכם Pro 2.0"""

    def __init__(self):
        """אתחול המודול"""
        self.name = "smart_code_merger_pro"
        self.version = "2.0.0"
        self.description = "מודול חכם מורחב לאיחוד קבצי ZIP עם קוד ממקורות שונים"
        
        # נתיבים
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_path = os.path.join(self.base_dir, "config.json")
        self.languages_config_path = os.path.join(self.base_dir, "languages_config.json")
        
        # תיקיות
        self.versions_dir = os.path.join(self.base_dir, "versions")
        self.security_reports_dir = os.path.join(self.base_dir, "security_reports")
        self.sandboxes_dir = os.path.join(self.base_dir, "sandboxes")
        self.remote_cache_dir = os.path.join(self.base_dir, "remote_cache")
        self.temp_dir = os.path.join(self.base_dir, "temp")
        
        # מצב
        self.initialized = False
        self.config = {}
        self.languages_config = {}
        self.zip_files = []
        self.target_directory = ""
        self.detected_projects = {}
        self.orphan_files = {}
        self.remote_connections = {}
        
        # זיהוי פרויקטים
        self.project_detector = None
        self.file_analyzer = None
        self.relationship_graph = None
        
        # רכיבים נוספים
        self.version_manager = None
        self.security_scanner = None
        self.code_runner = None
        self.code_completer = None
        self.remote_storage = None

    def initialize(self) -> bool:
        """אתחול המודול וטעינת הגדרות"""
        try:
            # יצירת תיקיות אם לא קיימות
            os.makedirs(self.versions_dir, exist_ok=True)
            os.makedirs(self.security_reports_dir, exist_ok=True)
            os.makedirs(self.sandboxes_dir, exist_ok=True)
            os.makedirs(self.remote_cache_dir, exist_ok=True)
            os.makedirs(self.temp_dir, exist_ok=True)
            
            # טעינת הגדרות
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            else:
                logger.error("קובץ הגדרות לא נמצא: %s", self.config_path)
                return False
            
            # טעינת הגדרות שפות
            if os.path.exists(self.languages_config_path):
                with open(self.languages_config_path, 'r', encoding='utf-8') as f:
                    self.languages_config = json.load(f)
            else:
                logger.warning("קובץ הגדרות שפות לא נמצא: %s", self.languages_config_path)
            
            # הגדרת רמת לוגים
            log_level = self.config.get("logging", {}).get("level", "INFO")
            logging.basicConfig(
                level=getattr(logging, log_level),
                format=self.config.get("logging", {}).get("format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"),
                handlers=[
                    logging.FileHandler(os.path.join(self.base_dir, "logs", "module.log")),
                    logging.StreamHandler()
                ]
            )
            
            # אתחול רכיבים
            self.initialize_components()
            
            self.initialized = True
            logger.info("מודול אותחל בהצלחה: %s גרסה %s", self.name, self.version)
            return True
            
        except Exception as e:
            logger.error("שגיאה באתחול המודול: %s", str(e), exc_info=True)
            return False

    def initialize_components(self) -> None:
        """אתחול רכיבי המודול"""
        # בעתיד, יאתחל את כל הרכיבים הפנימיים
        # כרגע סימולציה בלבד
        self.project_detector = ProjectDetector(self.config.get("project_detection", {}))
        self.file_analyzer = FileAnalyzer(self.config.get("file_handling", {}))
        self.relationship_graph = RelationshipGraph()
        
        # רכיבים חדשים
        if self.config.get("version_management", {}).get("enabled", True):
            self.version_manager = VersionManager(
                self.versions_dir,
                self.config.get("version_management", {})
            )
        
        if self.config.get("security_scanning", {}).get("enabled", True):
            self.security_scanner = SecurityScanner(
                self.security_reports_dir,
                self.config.get("security_scanning", {})
            )
        
        if self.config.get("code_running", {}).get("enabled", True):
            self.code_runner = CodeRunner(
                self.sandboxes_dir,
                self.languages_config,
                self.config.get("code_running", {})
            )
        
        if self.config.get("code_completion", {}).get("enabled", True):
            self.code_completer = CodeCompleter(
                self.config.get("code_completion", {})
            )
        
        if self.config.get("remote_storage", {}).get("enabled", True):
            self.remote_storage = RemoteStorage(
                self.remote_cache_dir,
                self.config.get("remote_storage", {})
            )

    def select_zip_files(self, zip_files: List[str]) -> bool:
        """בחירת קבצי ZIP לניתוח ומיזוג"""
        if not self.initialized:
            logger.error("המודול לא אותחל")
            return False
        
        valid_zip_files = []
        for zip_file in zip_files:
            if not os.path.exists(zip_file):
                logger.warning("קובץ ZIP לא נמצא: %s", zip_file)
                continue
                
            if not zipfile.is_zipfile(zip_file):
                logger.warning("קובץ אינו בפורמט ZIP תקין: %s", zip_file)
                continue
                
            valid_zip_files.append(zip_file)
        
        if not valid_zip_files:
            logger.error("לא נמצאו קבצי ZIP תקינים")
            return False
        
        self.zip_files = valid_zip_files
        logger.info("נבחרו %d קבצי ZIP לניתוח", len(valid_zip_files))
        return True

    def set_target_directory(self, target_directory: str) -> bool:
        """הגדרת תיקיית יעד למיזוג"""
        if not self.initialized:
            logger.error("המודול לא אותחל")
            return False
        
        if not os.path.exists(target_directory):
            try:
                os.makedirs(target_directory, exist_ok=True)
                logger.info("נוצרה תיקיית יעד: %s", target_directory)
            except Exception as e:
                logger.error("שגיאה ביצירת תיקיית יעד: %s", str(e))
                return False
        
        self.target_directory = target_directory
        logger.info("הוגדרה תיקיית יעד: %s", target_directory)
        return True

    def analyze_projects(self) -> Dict[str, Any]:
        """ניתוח פרויקטים בקבצי ZIP"""
        if not self.initialized:
            logger.error("המודול לא אותחל")
            return {"status": "error", "error": "המודול לא אותחל"}
        
        if not self.zip_files:
            logger.error("לא נבחרו קבצי ZIP")
            return {"status": "error", "error": "לא נבחרו קבצי ZIP"}
        
        if not self.target_directory:
            logger.error("לא הוגדרה תיקיית יעד")
            return {"status": "error", "error": "לא הוגדרה תיקיית יעד"}
        
        logger.info("מתחיל ניתוח פרויקטים...")
        
        try:
            # שלב 1: חילוץ קבצים מה-ZIP לתיקייה זמנית
            extract_dir = os.path.join(self.temp_dir, f"extract_{uuid.uuid4().hex}")
            os.makedirs(extract_dir, exist_ok=True)
            
            all_files = {}
            for zip_file in self.zip_files:
                files = self._extract_zip(zip_file, extract_dir)
                all_files.update(files)
            
            if not all_files:
                logger.error("לא נמצאו קבצים בקבצי ה-ZIP")
                return {"status": "error", "error": "לא נמצאו קבצים בקבצי ה-ZIP"}
            
            # שלב 2: ניתוח קבצים
            logger.info("מנתח %d קבצים...", len(all_files))
            analyzed_files = {}
            
            for file_path, file_info in all_files.items():
                analysis = self.file_analyzer.analyze_file(file_path)
                if analysis:
                    analyzed_files[file_path] = {
                        **file_info,
                        **analysis
                    }
            
            # שלב 3: בניית גרף קשרים
            logger.info("בונה גרף קשרים...")
            self.relationship_graph.build_graph(analyzed_files)
            
            # שלב 4: זיהוי פרויקטים
            logger.info("מזהה פרויקטים...")
            projects = self.project_detector.detect_projects(analyzed_files, self.relationship_graph)
            
            # שלב 5: זיהוי קבצים "יתומים" שלא שייכים לאף פרויקט
            orphan_files = {}
            for file_path, file_info in analyzed_files.items():
                if not any(file_path in project["files"] for project in projects.values()):
                    orphan_files[file_path] = file_info
            
            # שמירת תוצאות
            self.detected_projects = projects
            self.orphan_files = orphan_files
            
            logger.info("ניתוח פרויקטים הסתיים: זוהו %d פרויקטים ו-%d קבצים יתומים",
                      len(projects), len(orphan_files))
            
            # ניקוי תיקייה זמנית (אופציונלי)
            # shutil.rmtree(extract_dir)
            
            return {
                "status": "success",
                "detected_projects": projects,
                "orphan_files": orphan_files,
                "file_count": len(analyzed_files)
            }
            
        except Exception as e:
            logger.error("שגיאה בניתוח פרויקטים: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בניתוח פרויקטים: {str(e)}"}

    def _extract_zip(self, zip_file: str, extract_dir: str) -> Dict[str, Dict[str, Any]]:
        """חילוץ קבצים מקובץ ZIP"""
        logger.info("מחלץ קובץ ZIP: %s", zip_file)
        
        files = {}
        try:
            with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                # יצירת תיקייה ספציפית לקובץ ZIP זה
                zip_name = os.path.splitext(os.path.basename(zip_file))[0]
                zip_extract_dir = os.path.join(extract_dir, zip_name)
                os.makedirs(zip_extract_dir, exist_ok=True)
                
                # חילוץ כל הקבצים
                zip_ref.extractall(zip_extract_dir)
                
                # איסוף מידע על הקבצים
                for zip_info in zip_ref.infolist():
                    if zip_info.is_dir():
                        continue
                    
                    # בניית נתיב מלא לקובץ
                    file_path = os.path.join(zip_extract_dir, zip_info.filename)
                    
                    # בדיקה אם הקובץ תואם את סוגי הקבצים שהוגדרו
                    if not self._is_supported_file(file_path):
                        continue
                    
                    # אם הגענו לכאן, זהו קובץ תקין לניתוח
                    file_size = os.path.getsize(file_path)
                    
                    # בדיקת מגבלת גודל קובץ
                    max_size = self.config.get("file_handling", {}).get("max_file_size_mb", 50) * 1024 * 1024
                    if file_size > max_size:
                        logger.warning("קובץ גדול מדי: %s (%d בתים)", file_path, file_size)
                        continue
                    
                    # הוספת מידע על הקובץ
                    files[file_path] = {
                        "original_path": zip_info.filename,
                        "source_zip": zip_file,
                        "size": file_size,
                        "date": datetime.datetime(*zip_info.date_time)
                    }
        
        except Exception as e:
            logger.error("שגיאה בחילוץ קובץ ZIP: %s", str(e), exc_info=True)
        
        logger.info("חולצו %d קבצים מקובץ ZIP: %s", len(files), zip_file)
        return files

    def _is_supported_file(self, file_path: str) -> bool:
        """בדיקה אם הקובץ נתמך לניתוח"""
        # קבלת סוגי קבצים מהקונפיגורציה
        file_types_str = self.config.get("file_types", "*.py;*.js;*.html;*.css;*.java;*.xml;*.json;*.md;*.txt")
        file_types = file_types_str.split(';')
        
        # בדיקה אם הקובץ נמצא ברשימת הסוגים הנתמכים
        file_ext = os.path.splitext(file_path)[1].lower()
        
        # בדיקה אם הסיומת נמצאת ברשימת ההרחבות המוחרגות
        excluded_extensions = self.config.get("file_handling", {}).get("excluded_extensions", [])
        if file_ext in excluded_extensions:
            return False
        
        # בדיקה אם הקובץ תואם לאחד מסוגי הקבצים המוגדרים
        for file_type in file_types:
            if file_type.startswith('*.'):
                # בדיקת סיומת
                if file_ext == file_type[1:]:
                    return True
            elif '*' in file_type:
                # תבנית מורכבת יותר - שימוש ב-regex
                pattern = file_type.replace('.', '\\.').replace('*', '.*')
                if re.match(pattern, os.path.basename(file_path)):
                    return True
        
        return False

    def merge_project(self, project_id: str) -> Dict[str, Any]:
        """מיזוג פרויקט ספציפי"""
        if not self.initialized:
            logger.error("המודול לא אותחל")
            return {"status": "error", "error": "המודול לא אותחל"}
        
        if not self.detected_projects:
            logger.error("לא זוהו פרויקטים")
            return {"status": "error", "error": "לא זוהו פרויקטים"}
        
        if project_id not in self.detected_projects:
            logger.error("מזהה פרויקט לא תקין: %s", project_id)
            return {"status": "error", "error": f"מזהה פרויקט לא תקין: {project_id}"}
        
        project = self.detected_projects[project_id]
        project_name = project.get("name", project_id)
        
        logger.info("מתחיל מיזוג פרויקט: %s", project_name)
        
        try:
            # יצירת תיקיית יעד לפרויקט
            output_dir = os.path.join(self.target_directory, project_name)
            os.makedirs(output_dir, exist_ok=True)
            
            # העתקת קבצים לתיקיית היעד
            files_count = 0
            for file_path in project["files"]:
                # שמירה על מבנה התיקיות המקורי
                rel_path = os.path.relpath(file_path, self.temp_dir)
                # הסרת החלק הראשון של הנתיב היחסי (שם קובץ ה-ZIP)
                rel_parts = rel_path.split(os.path.sep)[1:]
                target_rel_path = os.path.join(*rel_parts)
                target_path = os.path.join(output_dir, target_rel_path)
                
                # יצירת תיקיות במידת הצורך
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                
                # העתקת הקובץ
                shutil.copy2(file_path, target_path)
                files_count += 1
                
                # שמירת גרסה ראשונית
                if self.version_manager:
                    self.version_manager.save_version(
                        target_path,
                        target_rel_path,
                        {
                            "project_id": project_id,
                            "project_name": project_name,
                            "original_path": project["files"][file_path].get("original_path", ""),
                            "source_zip": project["files"][file_path].get("source_zip", ""),
                            "version": "1.0.0",
                            "date": datetime.datetime.now().isoformat()
                        }
                    )
            
            logger.info("מיזוג פרויקט הסתיים: %s (%d קבצים)", project_name, files_count)
            
            return {
                "status": "success",
                "project_id": project_id,
                "project_name": project_name,
                "output_dir": output_dir,
                "files_count": files_count
            }
            
        except Exception as e:
            logger.error("שגיאה במיזוג פרויקט: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה במיזוג פרויקט: {str(e)}"}

    def merge_multiple_projects(self, project_ids: List[str], target_name: str) -> Dict[str, Any]:
        """מיזוג מרובה של מספר פרויקטים לפרויקט אחד"""
        if not self.initialized:
            logger.error("המודול לא אותחל")
            return {"status": "error", "error": "המודול לא אותחל"}
        
        if not self.detected_projects:
            logger.error("לא זוהו פרויקטים")
            return {"status": "error", "error": "לא זוהו פרויקטים"}
        
        if not project_ids or len(project_ids) < 2:
            logger.error("נדרשים לפחות שני פרויקטים למיזוג מרובה")
            return {"status": "error", "error": "נדרשים לפחות שני פרויקטים למיזוג מרובה"}
        
        # בדיקת תקינות מזהי הפרויקטים
        invalid_ids = [pid for pid in project_ids if pid not in self.detected_projects]
        if invalid_ids:
            logger.error("מזהי פרויקטים לא תקינים: %s", ", ".join(invalid_ids))
            return {"status": "error", "error": f"מזהי פרויקטים לא תקינים: {', '.join(invalid_ids)}"}
        
        logger.info("מתחיל מיזוג מרובה של %d פרויקטים: %s", len(project_ids), target_name)
        
        try:
            # יצירת תיקיית יעד למיזוג
            output_dir = os.path.join(self.target_directory, target_name)
            os.makedirs(output_dir, exist_ok=True)
            
            # איסוף כל הקבצים מכל הפרויקטים
            all_files = {}
            for project_id in project_ids:
                project = self.detected_projects[project_id]
                for file_path, file_info in project["files"].items():
                    # כאן יש לבדוק התנגשויות (קבצים זהים במיקומים זהים)
                    # לצורך פשטות, נשתמש בנתיב יחסי כמפתח
                    rel_path = os.path.relpath(file_path, self.temp_dir)
                    rel_parts = rel_path.split(os.path.sep)[1:]  # הסרת שם קובץ ה-ZIP
                    rel_key = os.path.join(*rel_parts)
                    
                    # בדיקת התנגשות
                    if rel_key in all_files:
                        # טיפול בהתנגשות
                        if self.config.get("system_merge", {}).get("rename_conflicts", True):
                            # שינוי שם הקובץ במקרה של התנגשות
                            base_name, ext = os.path.splitext(rel_key)
                            new_rel_key = f"{base_name}_from_{project_id}{ext}"
                            all_files[new_rel_key] = {
                                "file_path": file_path,
                                "file_info": file_info,
                                "project_id": project_id
                            }
                            logger.warning("התנגשות קבצים: %s (שונה ל-%s)", rel_key, new_rel_key)
                        else:
                            # שימוש בתאריך כדי לקבוע איזה קובץ לקחת
                            if self.config.get("merger", {}).get("date_based_priority", True):
                                existing_date = all_files[rel_key]["file_info"].get("date", datetime.datetime(2000, 1, 1))
                                current_date = file_info.get("date", datetime.datetime(2000, 1, 1))
                                
                                if current_date > existing_date:
                                    # החלפת הקובץ הקיים בחדש יותר
                                    all_files[rel_key] = {
                                        "file_path": file_path,
                                        "file_info": file_info,
                                        "project_id": project_id
                                    }
                                    logger.info("החלפת קובץ בגרסה חדשה יותר: %s", rel_key)
                            
                            logger.warning("התנגשות קבצים: %s (עדיפות לפי תאריך)", rel_key)
                    else:
                        # אין התנגשות, הוספת הקובץ לרשימה
                        all_files[rel_key] = {
                            "file_path": file_path,
                            "file_info": file_info,
                            "project_id": project_id
                        }
            
            # העתקת הקבצים לתיקיית היעד
            files_count = 0
            for rel_key, file_data in all_files.items():
                target_path = os.path.join(output_dir, rel_key)
                
                # יצירת תיקיות במידת הצורך
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                
                # העתקת הקובץ
                shutil.copy2(file_data["file_path"], target_path)
                files_count += 1
                
                # שמירת גרסה ראשונית
                if self.version_manager:
                    self.version_manager.save_version(
                        target_path,
                        rel_key,
                        {
                            "project_id": file_data["project_id"],
                            "source_projects": project_ids,
                            "target_name": target_name,
                            "original_path": file_data["file_info"].get("original_path", ""),
                            "source_zip": file_data["file_info"].get("source_zip", ""),
                            "version": "1.0.0",
                            "date": datetime.datetime.now().isoformat()
                        }
                    )
            
            logger.info("מיזוג מרובה הסתיים: %s (%d קבצים)", target_name, files_count)
            
            return {
                "status": "success",
                "source_projects": project_ids,
                "target_name": target_name,
                "output_dir": output_dir,
                "files_count": files_count
            }
            
        except Exception as e:
            logger.error("שגיאה במיזוג מרובה: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה במיזוג מרובה: {str(e)}"}

    def get_file_versions(self, file_path: str) -> List[Dict[str, Any]]:
        """קבלת גרסאות של קובץ"""
        if not self.initialized or not self.version_manager:
            logger.error("המודול לא אותחל או שניהול גרסאות לא פעיל")
            return []
        
        try:
            # קבלת רשימת גרסאות מהמנהל
            versions = self.version_manager.get_versions(file_path)
            return versions
            
        except Exception as e:
            logger.error("שגיאה בקבלת גרסאות: %s", str(e), exc_info=True)
            return []

    def compare_file_versions(self, version_id1: str, version_id2: str) -> Dict[str, Any]:
        """השוואת שתי גרסאות של קובץ"""
        if not self.initialized or not self.version_manager:
            logger.error("המודול לא אותחל או שניהול גרסאות לא פעיל")
            return {"status": "error", "error": "המודול לא אותחל או שניהול גרסאות לא פעיל"}
        
        try:
            # השוואת גרסאות
            comparison = self.version_manager.compare_versions(version_id1, version_id2)
            return comparison
            
        except Exception as e:
            logger.error("שגיאה בהשוואת גרסאות: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהשוואת גרסאות: {str(e)}"}

    def scan_project_security(self, project_id: str) -> Dict[str, Any]:
        """סריקת אבטחה של פרויקט"""
        if not self.initialized or not self.security_scanner:
            logger.error("המודול לא אותחל או שסריקת אבטחה לא פעילה")
            return {"status": "error", "error": "המודול לא אותחל או שסריקת אבטחה לא פעילה"}
        
        if not self.detected_projects or project_id not in self.detected_projects:
            logger.error("פרויקט לא נמצא: %s", project_id)
            return {"status": "error", "error": f"פרויקט לא נמצא: {project_id}"}
        
        try:
            # קבלת רשימת קבצים לסריקה
            project = self.detected_projects[project_id]
            files_to_scan = list(project["files"].keys())
            
            # סריקת הקבצים
            scan_results = self.security_scanner.scan_files(files_to_scan, project_id)
            return scan_results
            
        except Exception as e:
            logger.error("שגיאה בסריקת אבטחה: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בסריקת אבטחה: {str(e)}"}

    def run_code(self, file_path: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """הרצת קוד בסביבה מבודדת"""
        if not self.initialized or not self.code_runner:
            logger.error("המודול לא אותחל או שהרצת קוד לא פעילה")
            return {"status": "error", "error": "המודול לא אותחל או שהרצת קוד לא פעילה"}
        
        if not os.path.exists(file_path):
            logger.error("קובץ לא נמצא: %s", file_path)
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        try:
            # הרצת הקוד
            if parameters is None:
                parameters = {}
                
            run_results = self.code_runner.run_file(file_path, parameters)
            return run_results
            
        except Exception as e:
            logger.error("שגיאה בהרצת קוד: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהרצת קוד: {str(e)}"}

    def detect_missing_parts(self, file_path: str) -> Dict[str, Any]:
        """זיהוי חלקים חסרים בקוד"""
        if not self.initialized or not self.code_completer:
            logger.error("המודול לא אותחל או שהשלמת קוד לא פעילה")
            return {"status": "error", "error": "המודול לא אותחל או שהשלמת קוד לא פעילה"}
        
        if not os.path.exists(file_path):
            logger.error("קובץ לא נמצא: %s", file_path)
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        try:
            # זיהוי חלקים חסרים
            missing_parts = self.code_completer.detect_missing_parts(file_path)
            return missing_parts
            
        except Exception as e:
            logger.error("שגיאה בזיהוי חלקים חסרים: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בזיהוי חלקים חסרים: {str(e)}"}

    def complete_code(self, file_path: str, missing_parts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """השלמת חלקים חסרים בקוד"""
        if not self.initialized or not self.code_completer:
            logger.error("המודול לא אותחל או שהשלמת קוד לא פעילה")
            return {"status": "error", "error": "המודול לא אותחל או שהשלמת קוד לא פעילה"}
        
        if not os.path.exists(file_path):
            logger.error("קובץ לא נמצא: %s", file_path)
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        try:
            # השלמת חלקים חסרים
            completion_results = self.code_completer.complete_code(file_path, missing_parts)
            return completion_results
            
        except Exception as e:
            logger.error("שגיאה בהשלמת קוד: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהשלמת קוד: {str(e)}"}

    def connect_remote_storage(self, storage_type: str, connection_params: Dict[str, Any]) -> str:
        """התחברות למערכת קבצים מרוחקת"""
        if not self.initialized or not self.remote_storage:
            logger.error("המודול לא אותחל או שאחסון מרוחק לא פעיל")
            return ""
        
        try:
            # בדיקה אם סוג האחסון נתמך
            supported_types = self.config.get("remote_storage", {}).get("types", [])
            if storage_type not in supported_types:
                logger.error("סוג אחסון לא נתמך: %s", storage_type)
                return ""
            
            # התחברות לאחסון
            connection_id = self.remote_storage.connect(storage_type, connection_params)
            
            if connection_id:
                # שמירת החיבור
                self.remote_connections[connection_id] = {
                    "storage_type": storage_type,
                    "connection_params": connection_params,
                    "created_at": datetime.datetime.now().isoformat()
                }
                
                logger.info("חיבור לאחסון מרוחק הצליח: %s (%s)", storage_type, connection_id)
                return connection_id
            else:
                logger.error("חיבור לאחסון מרוחק נכשל: %s", storage_type)
                return ""
            
        except Exception as e:
            logger.error("שגיאה בהתחברות לאחסון מרוחק: %s", str(e), exc_info=True)
            return ""

    def list_remote_files(self, path: str, connection_id: str = None) -> List[Dict[str, Any]]:
        """קבלת רשימת קבצים מאחסון מרוחק"""
        if not self.initialized or not self.remote_storage:
            logger.error("המודול לא אותחל או שאחסון מרוחק לא פעיל")
            return []
        
        if connection_id and connection_id not in self.remote_connections:
            logger.error("מזהה חיבור לא תקין: %s", connection_id)
            return []
        
        try:
            # קבלת רשימת קבצים
            files = self.remote_storage.list_files(path, connection_id)
            return files
            
        except Exception as e:
            logger.error("שגיאה בקבלת רשימת קבצים מרוחקים: %s", str(e), exc_info=True)
            return []

    def download_remote_file(self, remote_path: str, local_path: str, connection_id: str = None) -> Dict[str, Any]:
        """הורדת קובץ מאחסון מרוחק"""
        if not self.initialized or not self.remote_storage:
            logger.error("המודול לא אותחל או שאחסון מרוחק לא פעיל")
            return {"status": "error", "error": "המודול לא אותחל או שאחסון מרוחק לא פעיל"}
        
        if connection_id and connection_id not in self.remote_connections:
            logger.error("מזהה חיבור לא תקין: %s", connection_id)
            return {"status": "error", "error": f"מזהה חיבור לא תקין: {connection_id}"}
        
        try:
            # הורדת הקובץ
            result = self.remote_storage.download_file(remote_path, local_path, connection_id)
            return result
            
        except Exception as e:
            logger.error("שגיאה בהורדת קובץ מרוחק: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהורדת קובץ מרוחק: {str(e)}"}


# רכיבים נוספים

class ProjectDetector:
    """מחלקה לזיהוי פרויקטים בקבצים"""
    
    def __init__(self, config: Dict[str, Any]):
        """אתחול גלאי הפרויקטים"""
        self.config = config
        self.key_files = config.get("key_files", [])
        self.min_files_for_project = config.get("min_files_for_project", 2)
        self.min_relationship_score = config.get("min_relationship_score", 0.5)
    
    def detect_projects(self, files: Dict[str, Dict[str, Any]], relationship_graph) -> Dict[str, Dict[str, Any]]:
        """זיהוי פרויקטים באוסף קבצים"""
        logger.info("מתחיל זיהוי פרויקטים...")
        
        # שלב 1: זיהוי קבצים מרכזיים
        key_file_matches = self._identify_key_files(files)
        
        # שלב 2: יצירת פרויקטים ראשוניים סביב קבצים מרכזיים
        initial_projects = self._create_initial_projects(key_file_matches)
        
        # שלב 3: הקצאת קבצים נוספים לפרויקטים
        projects = self._assign_files_to_projects(initial_projects, files, relationship_graph)
        
        # שלב 4: סינון פרויקטים קטנים מדי
        filtered_projects = {}
        for project_id, project in projects.items():
            if len(project["files"]) >= self.min_files_for_project:
                filtered_projects[project_id] = project
                logger.info("זוהה פרויקט: %s (%d קבצים)", project.get("name", project_id), len(project["files"]))
        
        return filtered_projects
    
    def _identify_key_files(self, files: Dict[str, Dict[str, Any]]) -> Dict[str, List[str]]:
        """זיהוי קבצים מרכזיים בפרויקטים"""
        key_file_matches = {}
        
        for file_path, file_info in files.items():
            file_name = os.path.basename(file_path)
            
            # בדיקה אם הקובץ הוא קובץ מרכזי
            for key_file in self.key_files:
                if file_name == key_file:
                    # קובץ מרכזי זוהה - הוספה לרשימה
                    if key_file not in key_file_matches:
                        key_file_matches[key_file] = []
                    
                    key_file_matches[key_file].append(file_path)
        
        return key_file_matches
    
    def _create_initial_projects(self, key_file_matches: Dict[str, List[str]]) -> Dict[str, Dict[str, Any]]:
        """יצירת פרויקטים ראשוניים סביב קבצים מרכזיים"""
        projects = {}
        
        for key_file, file_paths in key_file_matches.items():
            for i, file_path in enumerate(file_paths):
                # יצירת מזהה ייחודי לפרויקט
                parent_dir = os.path.basename(os.path.dirname(file_path))
                project_id = f"project_{parent_dir}_{i}"
                
                # יצירת פרויקט חדש
                projects[project_id] = {
                    "id": project_id,
                    "name": parent_dir,
                    "key_file": key_file,
                    "root": os.path.dirname(file_path),
                    "files": {file_path: {"type": "key_file", "score": 1.0}}
                }
        
        return projects
    
    def _assign_files_to_projects(self, projects: Dict[str, Dict[str, Any]], files: Dict[str, Dict[str, Any]], relationship_graph) -> Dict[str, Dict[str, Any]]:
        """הקצאת קבצים נוספים לפרויקטים"""
        # רשימת קבצים שכבר הוקצו לפרויקטים
        assigned_files = set()
        for project in projects.values():
            assigned_files.update(project["files"].keys())
        
        # הקצאת קבצים לפי מבנה תיקיות
        for file_path, file_info in files.items():
            if file_path in assigned_files:
                continue
            
            # מציאת הפרויקט עם שורש התיקייה הקרוב ביותר
            best_project = None
            best_depth = -1
            
            file_dir = os.path.dirname(file_path)
            for project_id, project in projects.items():
                project_root = project["root"]
                
                # בדיקה אם הקובץ נמצא בתיקיית השורש של הפרויקט או בתת-תיקייה
                if file_dir.startswith(project_root):
                    # חישוב עומק התיקייה
                    relative_path = os.path.relpath(file_dir, project_root)
                    depth = 0 if relative_path == '.' else relative_path.count(os.path.sep) + 1
                    
                    if depth > best_depth:
                        best_project = project_id
                        best_depth = depth
            
            if best_project:
                # הוספת הקובץ לפרויקט
                score = 1.0 / (best_depth + 1)  # ככל שהעומק גדול יותר, הציון נמוך יותר
                projects[best_project]["files"][file_path] = {
                    "type": "structure",
                    "score": score
                }
                assigned_files.add(file_path)
        
        return projects


class FileAnalyzer:
    """מחלקה לניתוח קבצים"""
    
    def __init__(self, config: Dict[str, Any]):
        """אתחול מנתח הקבצים"""
        self.config = config
        self.process_binary_files = config.get("process_binary_files", True)
        self.process_documents = config.get("process_documents", True)
        self.process_media = config.get("process_media", True)
        self.detect_encoding = config.get("detect_encoding", True)
    
    def analyze_file(self, file_path: str) -> Dict[str, Any]:
        """ניתוח קובץ וחילוץ מידע"""
        if not os.path.exists(file_path):
            logger.error("קובץ לא נמצא: %s", file_path)
            return {}
        
        try:
            # בדיקת סוג הקובץ
            file_type = self._detect_file_type(file_path)
            
            # מידע בסיסי
            file_info = {
                "type": file_type,
                "size": os.path.getsize(file_path),
                "last_modified": datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).isoformat()
            }
            
            # ניתוח מתקדם לפי סוג הקובץ
            if file_type == "text":
                text_info = self._analyze_text_file(file_path)
                file_info.update(text_info)
            elif file_type == "binary" and self.process_binary_files:
                binary_info = self._analyze_binary_file(file_path)
                file_info.update(binary_info)
            
            return file_info
            
        except Exception as e:
            logger.error("שגיאה בניתוח קובץ %s: %s", file_path, str(e), exc_info=True)
            return {"type": "unknown", "error": str(e)}
    
    def _detect_file_type(self, file_path: str) -> str:
        """זיהוי סוג הקובץ"""
        # בדיקה לפי סיומת
        ext = os.path.splitext(file_path)[1].lower()
        
        # סיומות של קבצי טקסט נפוצים
        text_extensions = [
            '.txt', '.py', '.js', '.html', '.css', '.java', '.c', '.cpp', '.h', '.cs', 
            '.php', '.rb', '.pl', '.sh', '.bat', '.xml', '.json', '.csv', '.yaml', '.yml',
            '.md', '.rst', '.ini', '.conf', '.cfg', '.properties'
        ]
        
        if ext in text_extensions:
            return "text"
        
        # אם לא זוהה לפי סיומת, ננסה לבדוק לפי תוכן
        try:
            # קריאת 1024 בתים ראשונים
            with open(file_path, 'rb') as f:
                header = f.read(1024)
            
            # בדיקה אם התוכן הוא טקסט או בינארי
            is_text = True
            for byte in header:
                if byte < 7 or byte > 127 and byte < 192:
                    is_text = False
                    break
            
            if is_text:
                return "text"
            else:
                return "binary"
                
        except Exception:
            return "unknown"
    
    def _analyze_text_file(self, file_path: str) -> Dict[str, Any]:
        """ניתוח קובץ טקסט"""
        # זיהוי סוג הקובץ לפי סיומת
        ext = os.path.splitext(file_path)[1].lower()
        
        # ניסיון לזהות שפת תכנות
        language = "unknown"
        if ext == '.py':
            language = "python"
        elif ext in ['.js', '.jsx']:
            language = "javascript"
        elif ext in ['.ts', '.tsx']:
            language = "typescript"
        elif ext in ['.html', '.htm']:
            language = "html"
        elif ext == '.css':
            language = "css"
        elif ext in ['.java', '.class']:
            language = "java"
        elif ext in ['.c', '.cpp', '.h', '.hpp']:
            language = "c/c++"
        elif ext == '.cs':
            language = "csharp"
        elif ext == '.go':
            language = "go"
        elif ext == '.rb':
            language = "ruby"
        elif ext == '.php':
            language = "php"
        elif ext in ['.sh', '.bash']:
            language = "bash"
        elif ext in ['.json', '.jsonl']:
            language = "json"
        elif ext in ['.xml', '.svg']:
            language = "xml"
        elif ext in ['.yaml', '.yml']:
            language = "yaml"
        elif ext == '.md':
            language = "markdown"
        
        # מידע בסיסי
        info = {
            "language": language,
            "subtype": language if language != "unknown" else "text"
        }
        
        try:
            # ניסיון לקרוא את הקובץ
            encoding = 'utf-8'
            if self.detect_encoding:
                # ניחוש קידוד
                with open(file_path, 'rb') as f:
                    raw = f.read(4)
                
                # זיהוי לפי BOM
                if raw.startswith(b'\xef\xbb\xbf'):
                    encoding = 'utf-8-sig'
                elif raw.startswith(b'\xff\xfe'):
                    encoding = 'utf-16-le'
                elif raw.startswith(b'\xfe\xff'):
                    encoding = 'utf-16-be'
            
            with open(file_path, 'r', encoding=encoding, errors='replace') as f:
                content = f.read()
            
            # חישוב כמות שורות
            lines = content.split('\n')
            info["line_count"] = len(lines)
            
            return info
            
        except Exception as e:
            logger.warning("שגיאה בניתוח קובץ טקסט %s: %s", file_path, str(e))
            return info
    
    def _analyze_binary_file(self, file_path: str) -> Dict[str, Any]:
        """ניתוח קובץ בינארי"""
        # ברירת מחדל - מידע בסיסי בלבד
        return {"subtype": "binary"}


class RelationshipGraph:
    """מחלקה לניהול גרף קשרים בין קבצים"""
    
    def __init__(self):
        """אתחול גרף הקשרים"""
        self.graph = {}  # גרף של קשרים בין קבצים
    
    def build_graph(self, files: Dict[str, Dict[str, Any]]) -> None:
        """בניית גרף קשרים בין קבצים"""
        logger.info("בונה גרף קשרים בין %d קבצים...", len(files))
        
        # איפוס גרף
        self.graph = {}
        
        # אתחול גרף
        for file_path in files:
            self.graph[file_path] = {}
        
        # חיפוש קשרים בין קבצים
        for file1_path, file1_info in files.items():
            for file2_path, file2_info in files.items():
                if file1_path == file2_path:
                    continue
                
                # חישוב ציון קשר בין שני הקבצים
                relationship_score = self._calculate_relationship(file1_path, file1_info, file2_path, file2_info)
                
                if relationship_score > 0:
                    # הוספת קשר לגרף
                    self.graph[file1_path][file2_path] = relationship_score
                    self.graph[file2_path][file1_path] = relationship_score
        
        logger.info("גרף קשרים נבנה: %d קבצים, %d קשרים", 
                   len(self.graph), sum(len(connections) for connections in self.graph.values()) // 2)
    
    def get_related_files(self, file_path: str) -> Dict[str, float]:
        """קבלת רשימת קבצים קשורים לקובץ נתון"""
        if file_path not in self.graph:
            return {}
        
        return self.graph[file_path]
    
    def get_relationship_score(self, file1: str, file2: str) -> float:
        """קבלת ציון קשר בין שני קבצים"""
        if file1 not in self.graph or file2 not in self.graph[file1]:
            return 0
        
        return self.graph[file1][file2]
    
    def _calculate_relationship(self, file1_path: str, file1_info: Dict[str, Any], file2_path: str, file2_info: Dict[str, Any]) -> float:
        """חישוב ציון הקשר בין שני קבצים"""
        
        # קשר לפי מיקום בתיקיות
        dir1 = os.path.dirname(file1_path)
        dir2 = os.path.dirname(file2_path)
        
        if dir1 == dir2:
            # קבצים באותה תיקייה
            return 0.8
        
        if dir1.startswith(dir2) or dir2.startswith(dir1):
            # קבצים בתיקיות מקוננות
            common_prefix = os.path.commonpath([dir1, dir2])
            dir1_rel = os.path.relpath(dir1, common_prefix)
            dir2_rel = os.path.relpath(dir2, common_prefix)
            
            # חישוב עומק היחסי
            depth1 = dir1_rel.count(os.path.sep) + 1 if dir1_rel != '.' else 0
            depth2 = dir2_rel.count(os.path.sep) + 1 if dir2_rel != '.' else 0
            total_depth = depth1 + depth2
            
            if total_depth == 0:
                # תיקיות זהות (לא אמור לקרות אם כבר בדקנו לעיל)
                return 0.8
            elif total_depth == 1:
                # תיקייה מקוננת ישירה
                return 0.7
            else:
                # תיקיות מקוננות בעומק גדול יותר
                score = max(0.1, 0.7 - (total_depth - 1) * 0.1)
                return score
        
        # קשר לפי שפה משותפת
        language1 = file1_info.get("language", "unknown")
        language2 = file2_info.get("language", "unknown")
        
        if language1 != "unknown" and language2 != "unknown" and language1 == language2:
            return 0.3
        
        return 0


class VersionManager:
    """מחלקה לניהול גרסאות של קבצים"""
    
    def __init__(self, versions_dir: str, config: Dict[str, Any]):
        """אתחול מנהל הגרסאות"""
        self.versions_dir = versions_dir
        self.config = config
        
        self.max_versions = config.get("max_versions", 10)
        self.compression = config.get("compression", "gzip")
        self.include_metadata = config.get("include_metadata", True)
        
        # יצירת תיקיית גרסאות אם לא קיימת
        os.makedirs(self.versions_dir, exist_ok=True)
        
        # קובץ אינדקס לגרסאות
        self.index_file = os.path.join(self.versions_dir, "versions_index.json")
        self.index = self._load_index()
    
    def save_version(self, file_path: str, rel_path: str, metadata: Dict[str, Any] = None) -> str:
        """שמירת גרסה של קובץ"""
        if not os.path.exists(file_path):
            logger.error("קובץ לא נמצא: %s", file_path)
            return ""
        
        try:
            # יצירת מזהה ייחודי לגרסה
            version_id = self._generate_version_id(file_path)
            
            # יצירת שם קובץ לגרסה
            version_file = os.path.join(self.versions_dir, f"{version_id}")
            
            # העתקת הקובץ לארכיון הגרסאות
            self._copy_file_to_version(file_path, version_file)
            
            # הוספת הגרסה לאינדקס
            if rel_path not in self.index:
                self.index[rel_path] = []
            
            version_info = {
                "id": version_id,
                "date": datetime.datetime.now().isoformat(),
                "size": os.path.getsize(file_path)
            }
            
            if metadata:
                version_info["metadata"] = metadata
            
            # הוספת הגרסה לרשימה
            self.index[rel_path].append(version_info)
            
            # שמירת אינדקס מעודכן
            self._save_index()
            
            # טיפול במגבלת כמות גרסאות
            if len(self.index[rel_path]) > self.max_versions:
                # מחיקת הגרסה הישנה ביותר
                oldest_version = self.index[rel_path][0]
                oldest_file = os.path.join(self.versions_dir, oldest_version["id"])
                
                if os.path.exists(oldest_file):
                    os.remove(oldest_file)
                
                # הסרה מהאינדקס
                self.index[rel_path].pop(0)
                self._save_index()
            
            logger.debug("נשמרה גרסה חדשה: %s (%s)", rel_path, version_id)
            return version_id
            
        except Exception as e:
            logger.error("שגיאה בשמירת גרסה: %s", str(e), exc_info=True)
            return ""
    
    def get_versions(self, rel_path: str) -> List[Dict[str, Any]]:
        """קבלת רשימת גרסאות של קובץ"""
        if rel_path not in self.index:
            return []
        
        return self.index[rel_path]
    
    def compare_versions(self, version_id1: str, version_id2: str) -> Dict[str, Any]:
        """השוואת שתי גרסאות"""
        version_file1 = os.path.join(self.versions_dir, version_id1)
        version_file2 = os.path.join(self.versions_dir, version_id2)
        
        if not os.path.exists(version_file1) or not os.path.exists(version_file2):
            return {"status": "error", "error": "אחת הגרסאות לא נמצאה"}
        
        try:
            # קריאת תוכן הגרסאות
            content1 = self._read_version_content(version_file1)
            content2 = self._read_version_content(version_file2)
            
            # השוואה בסיסית
            if content1 == content2:
                return {
                    "status": "success",
                    "is_identical": True,
                    "differences": []
                }
            
            # השוואה מפורטת
            lines1 = content1.decode('utf-8', errors='replace').splitlines()
            lines2 = content2.decode('utf-8', errors='replace').splitlines()
            
            # חישוב הבדלים
            import difflib
            diff = list(difflib.ndiff(lines1, lines2))
            
            differences = []
            for i, line in enumerate(diff):
                if line.startswith('- '):
                    differences.append({
                        "type": "removed",
                        "line": i + 1,
                        "content": line[2:]
                    })
                elif line.startswith('+ '):
                    differences.append({
                        "type": "added",
                        "line": i + 1,
                        "content": line[2:]
                    })
                elif line.startswith('? '):
                    # סימון שינויים בתוך שורה
                    continue
            
            return {
                "status": "success",
                "is_identical": False,
                "differences": differences
            }
            
        except Exception as e:
            logger.error("שגיאה בהשוואת גרסאות: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהשוואת גרסאות: {str(e)}"}
    
    def restore_version(self, version_id: str, target_path: str) -> bool:
        """שחזור גרסה"""
        version_file = os.path.join(self.versions_dir, version_id)
        
        if not os.path.exists(version_file):
            logger.error("גרסה לא נמצאה: %s", version_id)
            return False
        
        try:
            # יצירת תיקיית יעד במידת הצורך
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            
            # שחזור הגרסה
            content = self._read_version_content(version_file)
            
            with open(target_path, 'wb') as f:
                f.write(content)
            
            logger.info("גרסה שוחזרה בהצלחה: %s -> %s", version_id, target_path)
            return True
            
        except Exception as e:
            logger.error("שגיאה בשחזור גרסה: %s", str(e), exc_info=True)
            return False
    
    def _generate_version_id(self, file_path: str) -> str:
        """יצירת מזהה ייחודי לגרסה"""
        # שילוב של hash של התוכן, שם הקובץ וזמן
        content_hash = self._calculate_file_hash(file_path)
        file_name = os.path.basename(file_path)
        timestamp = int(datetime.datetime.now().timestamp())
        
        version_id = f"v_{content_hash[:10]}_{timestamp}_{file_name.replace('.', '_')}"
        return version_id
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """חישוב hash של קובץ"""
        hasher = hashlib.sha256()
        
        with open(file_path, 'rb') as f:
            # קריאת הקובץ בחלקים כדי לחסוך בזיכרון
            chunk = f.read(65536)
            while chunk:
                hasher.update(chunk)
                chunk = f.read(65536)
        
        return hasher.hexdigest()
    
    def _copy_file_to_version(self, file_path: str, version_file: str) -> None:
        """העתקת קובץ לארכיון הגרסאות"""
        if self.compression == "gzip":
            import gzip
            with open(file_path, 'rb') as f_in, gzip.open(version_file, 'wb') as f_out:
                f_out.write(f_in.read())
        else:
            shutil.copy2(file_path, version_file)
    
    def _read_version_content(self, version_file: str) -> bytes:
        """קריאת תוכן גרסה"""
        if self.compression == "gzip":
            import gzip
            with gzip.open(version_file, 'rb') as f:
                return f.read()
        else:
            with open(version_file, 'rb') as f:
                return f.read()
    
    def _load_index(self) -> Dict[str, List[Dict[str, Any]]]:
        """טעינת אינדקס הגרסאות"""
        if os.path.exists(self.index_file):
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error("שגיאה בטעינת אינדקס גרסאות: %s", str(e))
        
        return {}
    
    def _save_index(self) -> None:
        """שמירת אינדקס הגרסאות"""
        try:
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(self.index, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error("שגיאה בשמירת אינדקס גרסאות: %s", str(e))


class SecurityScanner:
    """מחלקה לסריקת אבטחה של קבצים"""
    
    def __init__(self, reports_dir: str, config: Dict[str, Any]):
        """אתחול סורק האבטחה"""
        self.reports_dir = reports_dir
        self.config = config
        
        self.scan_level = config.get("scan_level", "medium")
        self.excluded_patterns = config.get("excluded_patterns", [])
        
        # יצירת תיקיית דוחות אם לא קיימת
        os.makedirs(self.reports_dir, exist_ok=True)
    
    def scan_files(self, files: List[str], project_id: str) -> Dict[str, Any]:
        """סריקת אבטחה של קבצים"""
        logger.info("מתחיל סריקת אבטחה ל-%d קבצים, פרויקט %s", len(files), project_id)
        
        try:
            # סינון קבצים לפי תבניות מוחרגות
            files_to_scan = []
            for file_path in files:
                # בדיקה אם הקובץ מתאים לתבנית מוחרגת
                exclude = False
                for pattern in self.excluded_patterns:
                    if pattern in file_path:
                        exclude = True
                        break
                
                if not exclude:
                    files_to_scan.append(file_path)
            
            logger.debug("%d קבצים לסריקה (לאחר סינון)", len(files_to_scan))
            
            # סריקת הקבצים
            issues = []
            
            for file_path in files_to_scan:
                file_issues = self._scan_file(file_path)
                if file_issues:
                    issues.extend(file_issues)
            
            # יצירת דוח סריקה
            report = {
                "project_id": project_id,
                "scan_date": datetime.datetime.now().isoformat(),
                "files_scanned": len(files_to_scan),
                "issues_found": len(issues),
                "issues": issues
            }
            
            # שמירת הדוח
            report_file = os.path.join(self.reports_dir, f"security_scan_{project_id}_{uuid.uuid4().hex[:8]}.json")
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            # קיצור הדוח להחזרה
            if len(issues) > 100:
                # קיצור רשימת הבעיות אם יש יותר מדי
                report["issues"] = issues[:100]
                report["issues_truncated"] = True
            
            logger.info("סריקת אבטחה הסתיימה: %d בעיות נמצאו", len(issues))
            
            # החזרת תוצאות הסריקה
            return {
                "status": "success",
                "report": report,
                "report_file": report_file
            }
            
        except Exception as e:
            logger.error("שגיאה בסריקת אבטחה: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בסריקת אבטחה: {str(e)}"}
    
    def scan_file(self, file_path: str) -> List[Dict[str, Any]]:
        """סריקת אבטחה של קובץ בודד"""
        try:
            return self._scan_file(file_path)
        except Exception as e:
            logger.error("שגיאה בסריקת קובץ: %s - %s", file_path, str(e), exc_info=True)
            return []
    
    def _scan_file(self, file_path: str) -> List[Dict[str, Any]]:
        """סריקת אבטחה של קובץ בודד"""
        # בדיקת סוג הקובץ
        ext = os.path.splitext(file_path)[1].lower()
        
        issues = []
        
        # בחירת סורק לפי סוג הקובץ
        if ext in ['.py']:
            python_issues = self._scan_python_file(file_path)
            issues.extend(python_issues)
        elif ext in ['.js', '.ts', '.jsx', '.tsx']:
            js_issues = self._scan_js_file(file_path)
            issues.extend(js_issues)
        elif ext in ['.java']:
            java_issues = self._scan_java_file(file_path)
            issues.extend(java_issues)
        
        # סריקות כלליות
        # חיפוש סיסמאות
        password_issues = self._scan_for_passwords(file_path)
        issues.extend(password_issues)
        
        return issues
    
    def _scan_python_file(self, file_path: str) -> List[Dict[str, Any]]:
        """סריקת אבטחה לקובץ פייתון"""
        issues = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.splitlines()
            
            # חיפוש דפוסי קוד מסוכנים
            patterns = [
                {
                    "pattern": r"eval\s*\(",
                    "name": "eval() usage",
                    "severity": "high",
                    "description": "שימוש בפונקציית eval() עלול להוביל להרצת קוד זדוני"
                },
                {
                    "pattern": r"exec\s*\(",
                    "name": "exec() usage",
                    "severity": "high",
                    "description": "שימוש בפונקציית exec() עלול להוביל להרצת קוד זדוני"
                },
                {
                    "pattern": r"os\.system\s*\(|subprocess\.call\s*\(|subprocess\.Popen\s*\(",
                    "name": "Shell command execution",
                    "severity": "medium",
                    "description": "הרצת פקודות מעטפת ללא סניטציה עלולה להוביל להזרקת פקודות"
                }
            ]
            
            # סריקת דפוסים
            for i, line in enumerate(lines, 1):
                for pattern_info in patterns:
                    pattern = pattern_info["pattern"]
                    if re.search(pattern, line):
                        issues.append({
                            "file": file_path,
                            "line": i,
                            "code": line.strip(),
                            "name": pattern_info["name"],
                            "severity": pattern_info["severity"],
                            "description": pattern_info["description"]
                        })
            
            return issues
            
        except Exception as e:
            logger.warning("שגיאה בסריקת קובץ פייתון %s: %s", file_path, str(e))
            return []
    
    def _scan_js_file(self, file_path: str) -> List[Dict[str, Any]]:
        """סריקת אבטחה לקובץ JavaScript/TypeScript"""
        issues = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.splitlines()
            
            # חיפוש דפוסי קוד מסוכנים
            patterns = [
                {
                    "pattern": r"eval\s*\(",
                    "name": "eval() usage",
                    "severity": "high",
                    "description": "שימוש בפונקציית eval() עלול להוביל להרצת קוד זדוני"
                },
                {
                    "pattern": r"document\.write\s*\(",
                    "name": "document.write() usage",
                    "severity": "medium",
                    "description": "שימוש ב-document.write() עלול להוביל להזרקת קוד HTML"
                },
                {
                    "pattern": r"\.innerHTML\s*=",
                    "name": "innerHTML assignment",
                    "severity": "medium",
                    "description": "שימוש ב-innerHTML ללא סניטציה עלול להוביל להזרקת קוד HTML (XSS)"
                }
            ]
            
            # סריקת דפוסים
            for i, line in enumerate(lines, 1):
                for pattern_info in patterns:
                    pattern = pattern_info["pattern"]
                    if re.search(pattern, line):
                        issues.append({
                            "file": file_path,
                            "line": i,
                            "code": line.strip(),
                            "name": pattern_info["name"],
                            "severity": pattern_info["severity"],
                            "description": pattern_info["description"]
                        })
            
            return issues
            
        except Exception as e:
            logger.warning("שגיאה בסריקת קובץ JavaScript %s: %s", file_path, str(e))
            return []
    
    def _scan_java_file(self, file_path: str) -> List[Dict[str, Any]]:
        """סריקת אבטחה לקובץ Java"""
        # מימוש בסיסי - להרחיב בעתיד
        return []
    
    def _scan_for_passwords(self, file_path: str) -> List[Dict[str, Any]]:
        """חיפוש סיסמאות בקוד"""
        issues = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.splitlines()
            
            # חיפוש דפוסים של סיסמאות
            patterns = [
                r"(?:password|passwd|pwd)\s*=\s*[\"\']((?!\$\{).{3,}?)[\"\']",
                r"(?:password|passwd|pwd)\s*:\s*[\"\']((?!\$\{).{3,}?)[\"\']",
                r"(?:secret|api_key|apikey)\s*=\s*[\"\']((?!\$\{).{3,}?)[\"\']",
                r"(?:secret|api_key|apikey)\s*:\s*[\"\']((?!\$\{).{3,}?)[\"\']"
            ]
            
            # סריקת דפוסים
            for i, line in enumerate(lines, 1):
                for pattern in patterns:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # בדיקה שזו לא סיסמה דמה או הערת פיתוח
                        password = match.group(1)
                        dummy_passwords = ["password", "example", "change_me", "your_password", "test", "123", "secret"]
                        
                        is_dummy = False
                        for dummy in dummy_passwords:
                            if dummy in password.lower():
                                is_dummy = True
                                break
                        
                        if not is_dummy:
                            issues.append({
                                "file": file_path,
                                "line": i,
                                "code": line.replace(password, "***"),
                                "name": "Hardcoded credential",
                                "severity": "high",
                                "description": "נמצאה סיסמה או מפתח API מקודד קשיח בקוד"
                            })
            
            return issues
            
        except Exception as e:
            logger.warning("שגיאה בחיפוש סיסמאות בקובץ %s: %s", file_path, str(e))
            return []


class CodeRunner:
    """מחלקה להרצת קוד בסביבה מבודדת"""
    
    def __init__(self, sandboxes_dir: str, languages_config: Dict[str, Dict[str, Any]], config: Dict[str, Any]):
        """אתחול מריץ הקוד"""
        self.sandboxes_dir = sandboxes_dir
        self.languages_config = languages_config
        self.config = config
        
        self.sandbox_enabled = config.get("sandbox_enabled", True)
        self.timeout_seconds = config.get("timeout_seconds", 30)
        self.memory_limit_mb = config.get("memory_limit_mb", 512)
        self.supported_languages = config.get("supported_languages", ["python", "javascript", "bash"])
        
        # יצירת תיקיית סנדבוקסים אם לא קיימת
        os.makedirs(self.sandboxes_dir, exist_ok=True)
    
    def run_file(self, file_path: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """הרצת קובץ קוד"""
        if not os.path.exists(file_path):
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        # זיהוי שפת התכנות לפי סיומת הקובץ
        ext = os.path.splitext(file_path)[1].lower()
        language = self._detect_language(ext)
        
        if not language:
            return {"status": "error", "error": f"שפת התכנות לא נתמכת: {ext}"}
        
        if not parameters:
            parameters = {}
        
        return self._run_in_sandbox(file_path, language, parameters)
    
    def run_snippet(self, code: str, language: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """הרצת קטע קוד"""
        if language not in self.supported_languages:
            return {"status": "error", "error": f"שפת התכנות לא נתמכת: {language}"}
        
        if not parameters:
            parameters = {}
        
        # כתיבת הקוד לקובץ זמני
        try:
            lang_ext = self.languages_config.get(language, {}).get("extension", f".{language}")
            temp_file = os.path.join(self.sandboxes_dir, f"snippet_{uuid.uuid4().hex}{lang_ext}")
            
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # הרצת הקוד
            result = self._run_in_sandbox(temp_file, language, parameters)
            
            # ניקוי
            if os.path.exists(temp_file):
                os.remove(temp_file)
            
            return result
            
        except Exception as e:
            logger.error("שגיאה בהרצת קטע קוד: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהרצת קטע קוד: {str(e)}"}
    
    def _detect_language(self, ext: str) -> str:
        """זיהוי שפת תכנות לפי סיומת קובץ"""
        ext_to_lang = {
            '.py': 'python',
            '.js': 'javascript',
            '.sh': 'bash',
            '.ts': 'typescript',
            '.java': 'java',
            '.c': 'c',
            '.cpp': 'cpp',
            '.cs': 'csharp',
            '.go': 'go',
            '.rb': 'ruby',
            '.php': 'php',
            '.rs': 'rust',
            '.swift': 'swift',
            '.kt': 'kotlin'
        }
        
        language = ext_to_lang.get(ext)
        
        if language and language in self.supported_languages:
            return language
        
        return ""
    
    def _run_in_sandbox(self, file_path: str, language: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """הרצת קוד בסביבה מבודדת"""
        try:
            # קבלת הגדרות השפה
            lang_config = self.languages_config.get(language, {})
            if not lang_config:
                return {"status": "error", "error": f"הגדרות שפה לא נמצאו: {language}"}
            
            # הכנת פקודת הרצה
            command = lang_config.get("command", language)
            args = lang_config.get("args", [])
            
            # עריכת פרמטרים
            cmd_args = []
            for arg in args:
                cmd_args.append(arg)
            
            # הוספת שם הקובץ
            file_position = lang_config.get("file_position", "{file}")
            if file_position == "{file}":
                cmd_args.append(file_path)
            else:
                modified_file_position = file_position.replace("{file}", file_path)
                cmd_args.append(modified_file_position)
            
            # הוספת פרמטרים נוספים מהמשתמש
            if "args" in parameters:
                user_args = parameters["args"]
                if isinstance(user_args, list):
                    cmd_args.extend(user_args)
            
            # בדיקה אם צריך קימפול
            if "compile_command" in lang_config:
                compile_cmd = lang_config["compile_command"]
                compile_args = lang_config.get("compile_args", [])
                
                # בניית פקודת קימפול
                compile_cmd_args = [compile_cmd]
                compile_cmd_args.append(file_path)
                compile_cmd_args.extend(compile_args)
                
                # קימפול
                import subprocess
                compile_process = subprocess.run(
                    compile_cmd_args,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=self.timeout_seconds,
                    text=True
                )
                
                if compile_process.returncode != 0:
                    return {
                        "status": "error",
                        "error": "שגיאה בקימפול",
                        "stdout": compile_process.stdout,
                        "stderr": compile_process.stderr,
                        "returncode": compile_process.returncode
                    }
            
            # הרצת הקוד
            import subprocess
            process = subprocess.run(
                [command] + cmd_args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self.timeout_seconds,
                text=True
            )
            
            return {
                "status": "success" if process.returncode == 0 else "error",
                "stdout": process.stdout,
                "stderr": process.stderr,
                "returncode": process.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {"status": "error", "error": f"זמן הריצה עבר את ההגבלה: {self.timeout_seconds} שניות"}
        except Exception as e:
            logger.error("שגיאה בהרצת קוד: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהרצת קוד: {str(e)}"}


class CodeCompleter:
    """מחלקה להשלמת קוד חסר"""
    
    def __init__(self, config: Dict[str, Any]):
        """אתחול משלים הקוד"""
        self.config = config
        self.suggestions_limit = config.get("suggestions_limit", 5)
        self.context_lines = config.get("context_lines", 10)
        self.supported_languages = config.get("supported_languages", ["python", "javascript", "java", "c", "cpp"])
    
    def detect_missing_parts(self, file_path: str) -> Dict[str, Any]:
        """זיהוי חלקים חסרים בקוד"""
        if not os.path.exists(file_path):
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        # זיהוי שפת התכנות
        ext = os.path.splitext(file_path)[1].lower()
        language = self._detect_language(ext)
        
        if not language:
            return {"status": "error", "error": f"שפת התכנות לא נתמכת: {ext}"}
        
        try:
            # קריאת הקובץ
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
            
            # זיהוי חלקים חסרים
            missing_parts = []
            
            # מימוש בסיסי - זיהוי תבניות נפוצות של חלקים חסרים
            if language == "python":
                missing_parts = self._detect_missing_parts_python(content)
            elif language in ["javascript", "typescript"]:
                missing_parts = self._detect_missing_parts_js(content)
            elif language == "java":
                missing_parts = self._detect_missing_parts_java(content)
            
            return {
                "status": "success",
                "language": language,
                "missing_parts": missing_parts,
                "file_path": file_path
            }
            
        except Exception as e:
            logger.error("שגיאה בזיהוי חלקים חסרים: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בזיהוי חלקים חסרים: {str(e)}"}
    
    def complete_code(self, file_path: str, missing_parts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """השלמת חלקים חסרים בקוד"""
        if not os.path.exists(file_path):
            return {"status": "error", "error": f"קובץ לא נמצא: {file_path}"}
        
        # זיהוי שפת התכנות
        ext = os.path.splitext(file_path)[1].lower()
        language = self._detect_language(ext)
        
        if not language:
            return {"status": "error", "error": f"שפת התכנות לא נתמכת: {ext}"}
        
        try:
            # קריאת הקובץ
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
            
            # השלמת כל חלק חסר
            completed_content = content
            completions = []
            
            for part in missing_parts:
                part_type = part.get("type", "")
                start_line = part.get("start_line", 0)
                end_line = part.get("end_line", 0)
                name = part.get("name", "")
                
                # הכנת לוגיקה להשלמה
                if language == "python":
                    completion = self._complete_part_python(content, part)
                elif language in ["javascript", "typescript"]:
                    completion = self._complete_part_js(content, part)
                elif language == "java":
                    completion = self._complete_part_java(content, part)
                else:
                    completion = {"status": "error", "error": f"שפת התכנות לא נתמכת להשלמה: {language}"}
                
                if completion.get("status") == "success":
                    completed_content = completion.get("completed_content", completed_content)
                    completions.append({
                        "type": part_type,
                        "name": name,
                        "start_line": start_line,
                        "end_line": end_line,
                        "completion": completion.get("completion", "")
                    })
            
            # שמירת הקוד המושלם לקובץ זמני
            temp_file = f"{file_path}.completed"
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(completed_content)
            
            return {
                "status": "success",
                "language": language,
                "completions": completions,
                "original_file": file_path,
                "completed_file": temp_file
            }
            
        except Exception as e:
            logger.error("שגיאה בהשלמת קוד: %s", str(e), exc_info=True)
            return {"status": "error", "error": f"שגיאה בהשלמת קוד: {str(e)}"}
    
    def suggest_completions(self, file_path: str, line: int, column: int) -> List[Dict[str, Any]]:
        """הצעת השלמות קוד"""
        # מימוש בסיסי - רק להדגמה
        return [
            {
                "text": "השלמה לדוגמה 1",
                "description": "תיאור לדוגמה 1"
            },
            {
                "text": "השלמה לדוגמה 2",
                "description": "תיאור לדוגמה 2"
            }
        ]
    
    def _detect_language(self, ext: str) -> str:
        """זיהוי שפת תכנות לפי סיומת קובץ"""
        ext_to_lang = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.java': 'java',
            '.c': 'c',
            '.cpp': 'cpp',
            '.h': 'c',
            '.hpp': 'cpp'
        }
        
        language = ext_to_lang.get(ext)
        
        if language and language in self.supported_languages:
            return language
        
        return ""
    
    def _detect_missing_parts_python(self, content: str) -> List[Dict[str, Any]]:
        """זיהוי חלקים חסרים בקוד פייתון"""
        missing_parts = []
        lines = content.splitlines()
        
        # חיפוש פונקציות חסרות
        function_pattern = r"def\s+([a-zA-Z0-9_]+)\s*\([^)]*\)\s*:(?:\s*#\s*TODO.*)?(?:\s*pass)?"
        for i, line in enumerate(lines):
            match = re.match(function_pattern, line)
            if match and (i+1 >= len(lines) or lines[i+1].strip() == "pass" or "TODO" in line):
                function_name = match.group(1)
                missing_parts.append({
                    "type": "function",
                    "name": function_name,
                    "start_line": i,
                    "end_line": i + 1
                })
        
        # חיפוש מחלקות חסרות
        class_pattern = r"class\s+([a-zA-Z0-9_]+)(?:\([^)]*\))?\s*:(?:\s*#\s*TODO.*)?(?:\s*pass)?"
        for i, line in enumerate(lines):
            match = re.match(class_pattern, line)
            if match and (i+1 >= len(lines) or lines[i+1].strip() == "pass" or "TODO" in line):
                class_name = match.group(1)
                missing_parts.append({
                    "type": "class",
                    "name": class_name,
                    "start_line": i,
                    "end_line": i + 1
                })
        
        return missing_parts
    
    def _detect_missing_parts_js(self, content: str) -> List[Dict[str, Any]]:
        """זיהוי חלקים חסרים בקוד JavaScript/TypeScript"""
        missing_parts = []
        lines = content.splitlines()
        
        # חיפוש פונקציות חסרות
        function_pattern = r"function\s+([a-zA-Z0-9_]+)\s*\([^)]*\)\s*{(?:\s*//\s*TODO.*)?(?:\s*}|$)"
        for i, line in enumerate(lines):
            match = re.match(function_pattern, line)
            if match and (i+1 >= len(lines) or re.match(r"\s*}|//\s*TODO", lines[i+1])):
                function_name = match.group(1)
                missing_parts.append({
                    "type": "function",
                    "name": function_name,
                    "start_line": i,
                    "end_line": i + 1
                })
        
        # חיפוש מחלקות חסרות
        class_pattern = r"class\s+([a-zA-Z0-9_]+)(?:\s+extends\s+[a-zA-Z0-9_]+)?\s*{(?:\s*//\s*TODO.*)?(?:\s*}|$)"
        for i, line in enumerate(lines):
            match = re.match(class_pattern, line)
            if match and (i+1 >= len(lines) or re.match(r"\s*}|//\s*TODO", lines[i+1])):
                class_name = match.group(1)
                missing_parts.append({
                    "type": "class",
                    "name": class_name,
                    "start_line": i,
                    "end_line": i + 1
                })
        
        return missing_parts
    
    def _detect_missing_parts_java(self, content: str) -> List[Dict[str, Any]]:
        """זיהוי חלקים חסרים בקוד Java"""
        # מימוש בסיסי - להרחיב בעתיד
        return []
    
    def _complete_part_python(self, content: str, part: Dict[str, Any]) -> Dict[str, Any]:
        """השלמת חלק חסר בקוד פייתון"""
        part_type = part.get("type", "")
        name = part.get("name", "")
        start_line = part.get("start_line", 0)
        
        lines = content.splitlines()
        completed_content = content
        
        if part_type == "function":
            # השלמת פונקציה בסיסית
            indentation = re.match(r"^(\s*)", lines[start_line]).group(1)
            function_def = lines[start_line]
            
            completion = f"\n{indentation}    # TODO: להשלים את הפונקציה\n{indentation}    pass"
            
            # החלפת השורה המקורית
            lines[start_line] = function_def + completion
            completed_content = "\n".join(lines)
            
            return {
                "status": "success",
                "completion": completion,
                "completed_content": completed_content
            }
        
        elif part_type == "class":
            # השלמת מחלקה בסיסית
            indentation = re.match(r"^(\s*)", lines[start_line]).group(1)
            class_def = lines[start_line]
            
            completion = f"\n{indentation}    # TODO: להשלים את המחלקה\n{indentation}    pass"
            
            # החלפת השורה המקורית
            lines[start_line] = class_def + completion
            completed_content = "\n".join(lines)
            
            return {
                "status": "success",
                "completion": completion,
                "completed_content": completed_content
            }
        
        return {"status": "error", "error": f"סוג חלק לא נתמך: {part_type}"}
    
    def _complete_part_js(self, content: str, part: Dict[str, Any]) -> Dict[str, Any]:
        """השלמת חלק חסר בקוד JavaScript/TypeScript"""
        part_type = part.get("type", "")
        name = part.get("name", "")
        start_line = part.get("start_line", 0)
        
        lines = content.splitlines()
        completed_content = content
        
        if part_type == "function":
            # השלמת פונקציה בסיסית
            indentation = re.match(r"^(\s*)", lines[start_line]).group(1)
            function_def = lines[start_line]
            
            completion = f"\n{indentation}    // TODO: להשלים את הפונקציה\n{indentation}    return null;\n{indentation}}}"
            
            # החלפת השורה המקורית
            lines[start_line] = function_def
            
            # הוספת שורות ההשלמה
            if start_line + 1 < len(lines) and re.match(r"\s*}", lines[start_line + 1]):
                lines[start_line + 1] = completion
            else:
                lines.insert(start_line + 1, completion)
            
            completed_content = "\n".join(lines)
            
            return {
                "status": "success",
                "completion": completion,
                "completed_content": completed_content
            }
        
        elif part_type == "class":
            # השלמת מחלקה בסיסית
            indentation = re.match(r"^(\s*)", lines[start_line]).group(1)
            class_def = lines[start_line]
            
            completion = f"\n{indentation}    // TODO: להשלים את המחלקה\n{indentation}    constructor() {{\n{indentation}        // אתחול\n{indentation}    }}\n{indentation}}}"
            
            # החלפת השורה המקורית
            lines[start_line] = class_def
            
            # הוספת שורות ההשלמה
            if start_line + 1 < len(lines) and re.match(r"\s*}", lines[start_line + 1]):
                lines[start_line + 1] = completion
            else:
                lines.insert(start_line + 1, completion)
            
            completed_content = "\n".join(lines)
            
            return {
                "status": "success",
                "completion": completion,
                "completed_content": completed_content
            }
        
        return {"status": "error", "error": f"סוג חלק לא נתמך: {part_type}"}
    
    def _complete_part_java(self, content: str, part: Dict[str, Any]) -> Dict[str, Any]:
        """השלמת חלק חסר בקוד Java"""
        # מימוש בסיסי - להרחיב בעתיד
        return {"status": "error", "error": "השלמה לא נתמכת עבור Java"}


class RemoteStorage:
    """מחלקה לגישה למערכות קבצים מרוחקות"""
    
    def __init__(self, cache_dir: str, config: Dict[str, Any]):
        """אתחול מנהל האחסון המרוחק"""
        self.cache_dir = cache_dir
        self.config = config
        
        self.types = config.get("types", ["local", "ssh", "s3", "ftp", "webdav", "smb", "nfs"])
        self.timeout_seconds = config.get("timeout_seconds", 30)
        self.cache_enabled = config.get("cache_enabled", True)
        self.cache_expiry_seconds = config.get("cache_expiry_seconds", 3600)
        
        # מידע על חיבורים
        self.connections = {}
        
        # יצירת תיקיית מטמון אם לא קיימת
        os.makedirs(self.cache_dir, exist_ok=True)
    
    def connect(self, storage_type: str, connection_params: Dict[str, Any]) -> str:
        """התחברות למערכת קבצים מרוחקת"""
        if storage_type not in self.types:
            logger.error("סוג אחסון לא נתמך: %s", storage_type)
            return ""
        
        try:
            # יצירת מזהה ייחודי לחיבור
            connection_id = f"{storage_type}_{uuid.uuid4().hex}"
            
            # בדיקת חיבור (פשוטה)
            valid_connection = self._validate_connection(storage_type, connection_params)
            
            if not valid_connection:
                logger.error("חיבור לא תקין: %s", storage_type)
                return ""
            
            # שמירת החיבור
            self.connections[connection_id] = {
                "type": storage_type,
                "params": connection_params,
                "created_at": datetime.datetime.now().isoformat()
            }
            
            return connection_id
            
        except Exception as e:
            logger.error("שגיאה בחיבור לאחסון מרוחק: %s", str(e), exc_info=True