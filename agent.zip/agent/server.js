
// Middleware: בדיקת הרשאות לפי תפקיד
const permissions = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'permissions.json'), 'utf8'));

app.use((req, res, next) => {
  if (!req.session.user) return res.redirect('/interface/login.html');

  const role = req.session.user.role;
  const path = req.path;

  const allowMap = {
    settings: ['/interface/pages/settings_dashboard.html'],
    users: ['/interface/pages/user_management.html'],
    chat: ['/interface/pages/chat_multimedia.html'],
    archive: ['/interface/pages/archive.html'],
    agents: ['/interface/pages/agents.html'],
    reports: ['/interface/pages/reports.html'],
    profile: ['/interface/pages/my_profile.html']
  };

  const allowed = permissions[role] || [];
  const allowedPaths = allowed.flatMap(key => allowMap[key] || []);
  if (allowedPaths.some(p => path.includes(p))) {
    next();
  } else {
    res.status(403).send("אין לך הרשאה לגשת לעמוד זה.");
  }
});


const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const AgentMonitor = require('./modules/agent_monitor');
const activeMonitors = {};

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

const agentConfigPath = path.join(__dirname, 'config', 'agent_config.json');
let agentConfig = require(agentConfigPath);

function startMonitorsForAgents() {
  const agentsDataPath = path.join(__dirname, 'config', 'agent_config.json');
  const agents = JSON.parse(fs.readFileSync(agentsDataPath, 'utf8'));

  agents.forEach(agent => {
    if (!activeMonitors[agent.id]) {
      const monitor = new AgentMonitor(agent.id);
      monitor.startMonitoring();
      activeMonitors[agent.id] = monitor;
      console.log(`Started monitor for agent ${agent.name}`);
    }
  });
}

startMonitorsForAgents();

// שליחת מייל רגילה
app.post('/send-email', async (req, res) => {
  const { subject, text } = req.body;

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'aifi.trader.bot@gmail.com',
        pass: 'vfdj yedl gmnn zexj'
      }
    });

    await transporter.sendMail({
      from: '"AI Agent" <aifi.trader.bot@gmail.com>',
      to: 'effi35@gmail.com',
      subject,
      text
    });

    res.json({ status: 'Email sent successfully!' });
  } catch (error) {
    console.error('Failed to send email:', error);
    res.status(500).json({ status: 'Failed to send email', error: error.message });
  }
});

app.post('/create-agent', (req, res) => {
  const { mode } = req.body;
  let agentSettings = {};

  if (mode === 'simple') {
    agentSettings = agentConfig.default_agent;
  } else if (mode === 'extended') {
    agentSettings = agentConfig.advanced_agent;
  } else {
    return res.status(400).json({ status: 'Invalid agent mode!' });
  }

  const agentResult = {
    agent_id: `agent_${Date.now()}`,
    config: agentSettings,
    status: 'created',
    created_at: new Date()
  };

  const savePath = path.join(__dirname, 'agents', `${agentResult.agent_id}.json`);
  fs.writeFileSync(savePath, JSON.stringify(agentResult, null, 2));

  res.json({ status: 'Agent created', agent: agentResult });
});

app.get('/ping', (req, res) => {
  res.json({ status: 'pong', timestamp: new Date() });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

app.get('/api/agents', (req, res) => {
  try {
    const agentsData = fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8');
    const agents = JSON.parse(agentsData);
    res.json(agents);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error reading agents' });
  }
});

app.delete('/api/agents/:id', (req, res) => {
  try {
    const agentId = req.params.id;
    const agentsData = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8'));
    const updatedAgents = agentsData.filter(agent => agent.id !== agentId);

    fs.writeFileSync(path.join(__dirname, 'config', 'agent_config.json'), JSON.stringify(updatedAgents, null, 2));
    res.status(200).send('Agent deleted.');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error deleting agent.');
  }
});

app.post('/api/agents/:id/send', (req, res) => {
  try {
    const agentId = req.params.id;
    const agentsData = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8'));
    const agent = agentsData.find(a => a.id === agentId);

    if (!agent) return res.status(404).send('Agent not found');

    const resultPath = path.join(__dirname, 'agents', 'results', `${agentId}.json`);
    if (!fs.existsSync(resultPath)) return res.status(404).send('Result not found');

    const resultContent = fs.readFileSync(resultPath, 'utf8');

    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'aifi.trader.bot@gmail.com',
        pass: 'vfdj yedl gmnn zexj'
      }
    });

    const mailOptions = {
      from: 'aifi.trader.bot@gmail.com',
      to: 'effi35@gmail.com',
      subject: `Agent ${agent.name} Result`,
      text: resultContent
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Failed to send email.');
      }
      console.log('Email sent: ' + info.response);
      res.status(200).send('Email sent successfully.');
    });

  } catch (error) {
    console.error(error);
    res.status(500).send('Error sending result.');
  }
});

app.post('/run-agent-now/:id', (req, res) => {
  const agentId = req.params.id;
  const agentPath = path.join(__dirname, 'config', 'agent_config.json');
  const agents = JSON.parse(fs.readFileSync(agentPath, 'utf8'));

  const agent = agents.find(a => a.id === agentId);

  if (!agent) {
    return res.status(404).json({ message: 'Agent not found' });
  }

  agent.status = 'Running';
  fs.writeFileSync(agentPath, JSON.stringify(agents, null, 2));

  setTimeout(() => {
    const success = Math.random() > 0.2;
    agent.status = success ? 'Success' : 'Failed';

    const resultPath = path.join(__dirname, 'agents', 'results', `${agent.id}.json`);
    const resultData = {
      agentId: agent.id,
      status: agent.status,
      data: success ? "המשימה בוצעה בהצלחה!" : "המשימה נכשלה.",
      timestamp: new Date().toISOString()
    };
    fs.writeFileSync(resultPath, JSON.stringify(resultData, null, 2));
    fs.writeFileSync(agentPath, JSON.stringify(agents, null, 2));
  }, 5000);

  res.json({ message: 'הסוכן הופעל' });
});

app.get('/get-all-results', (req, res) => {
  const resultsFolder = path.join(__dirname, 'agents', 'results');
  const resultFiles = fs.readdirSync(resultsFolder);

  const allResults = resultFiles.map(file => {
    const content = fs.readFileSync(path.join(resultsFolder, file), 'utf8');
    return JSON.parse(content);
  });

  res.json(allResults);
});



// Socket.IO setup
const http = require('http').createServer(app);
const io = require('socket.io')(http);

http.listen(PORT, () => {
  console.log(`Server running with socket.io on port ${PORT}`);
});

// Emit live updates
function saveResultWithSocket(agentId, action, status, details) {
    const result = {
        agentId,
        action,
        status,
        details,
        timestamp: new Date().toISOString()
    };
    io.emit('new_action', result);
}



// === CREATE AGENT API ===
const fs = require('fs');
const path = require('path');

app.post('/api/create-agent', (req, res) => {
  const { name, description, extended, tasks } = req.body;
  const id = name.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();
  const agentDir = path.join(__dirname, '../agents/', id);
  const configDir = path.join(agentDir, 'configs');
  const scriptsDir = path.join(agentDir, 'scripts');
  const outputsDir = path.join(agentDir, 'outputs');
  const logsDir = path.join(agentDir, 'logs');

  // Ensure all directories exist
  [agentDir, configDir, scriptsDir, outputsDir, logsDir].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  // Build config
  const config = {
    agent_name: name,
    description,
    extended,
    tasks,
    created: new Date().toISOString(),
    status: "Pending"
  };

  // Save agent config file
  const configPath = path.join(configDir, `${id}_config.json`);
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');

  res.json({ success: true, agentId: id });
});



// === SEND EMAIL API ===
const nodemailer = require('nodemailer');

app.post('/send-email', async (req, res) => {
  const { subject, body, to } = req.body;
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'your_gmail_account@gmail.com',
      pass: 'your_gmail_password'
    }
  });

  const mailOptions = {
    from: 'SuperAgent <your_gmail_account@gmail.com>',
    to: to || 'admin@example.com',
    subject: subject || 'Super Agent Notification',
    html: `<p>${body}</p>`
  };

  try {
    await transporter.sendMail(mailOptions);
    res.json({ success: true });
  } catch (error) {
    console.error('Email send error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});



// === GET & SAVE Agent Result ===
const resultBase = path.join(__dirname, '../agents');

app.get('/get-agent-result/:agentId', (req, res) => {
  const agentId = req.params.agentId;
  const filePath = path.join(resultBase, agentId, 'outputs', agentId + '_result.json');
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      res.json(JSON.parse(content));
    } else {
      res.status(404).json({ error: 'Result not found' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error reading result file' });
  }
});

app.post('/save-agent-result/:agentId', (req, res) => {
  const agentId = req.params.agentId;
  const filePath = path.join(resultBase, agentId, 'outputs', agentId + '_result.json');
  try {
    fs.writeFileSync(filePath, JSON.stringify(req.body, null, 2), 'utf-8');
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Error saving result file' });
  }
});



const multer = require('multer');
const upload = multer({ dest: 'tmp/' });

app.post('/upload-file', upload.single('file'), (req, res) => {
  const agentId = req.body.agentId;
  const file = req.file;
  const dest = path.join(__dirname, '../agents', agentId, 'inputs', file.originalname);
  fs.renameSync(file.path, dest);
  res.json({ success: true, message: 'הקובץ נשמר לתיקיית הקלט של הסוכן.' });
});



const bodyParser = require('body-parser');
app.use(bodyParser.json());

const chatDir = path.join(__dirname, '../agents', 'default', 'chats');
if (!fs.existsSync(chatDir)) fs.mkdirSync(chatDir, { recursive: true });

app.post('/chat', async (req, res) => {
  const settings = JSON.parse(fs.readFileSync(path.join(__dirname, '../config/settings.json'), 'utf-8'));
  const provider = settings.default_ai_provider;
  const messages = req.body.messages || [];

  if (provider === 'custom' && settings.custom_ai_url) {
    try {
      const reply = await axios.post(settings.custom_ai_url, { messages });
      return res.json({ reply: reply.data.response });
    } catch (err) {
      return res.status(500).json({ error: 'Custom AI error' });
    }
  }

  // Default: OpenAI
  try {
    const reply = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: settings.default_model || 'gpt-4',
      messages
    }, {
      headers: { Authorization: `Bearer ${settings.openai_api_key}` }
    });

    return res.json({ reply: reply.data.choices[0].message.content });
  } catch (err) {
    return res.status(500).json({ error: 'OpenAI error' });
  }
});

app.post('/save-chat', (req, res) => {
  const chatLog = req.body.log;
  const filename = `chat_${Date.now()}.json`;
  const filepath = path.join(chatDir, filename);
  fs.writeFileSync(filepath, JSON.stringify(chatLog, null, 2), 'utf-8');
  res.json({ success: true });
});

app.get('/get-chat-history', (req, res) => {
  try {
    const files = fs.readdirSync(chatDir);
    res.json({ files });
  } catch {
    res.status(500).json({ files: [] });
  }
});


// הרצת יכולת לפי שם מודול
app.post('/run-capability', (req, res) => {
  const { capability } = req.body;
  if (!capability) {
    return res.status(400).json({ error: 'Missing capability name' });
  }

  const modulePath = path.join(__dirname, 'modules', capability + '.json');
  if (!fs.existsSync(modulePath)) {
    return res.status(404).json({ error: 'Module not found' });
  }

  try {
    const moduleData = JSON.parse(fs.readFileSync(modulePath, 'utf8'));
    res.json({ status: 'success', data: moduleData });
  } catch (err) {
    res.status(500).json({ error: 'Failed to read or parse module', detail: err.message });
  }
});


// שמירה של שיחה לקובץ JSON
app.post('/save-chat', (req, res) => {
  const { chat, agentId } = req.body;
  if (!chat || !agentId) {
    return res.status(400).json({ error: 'Missing chat or agentId' });
  }

  const filePath = path.join(__dirname, 'memory', `${agentId}_chat.json`);
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(chat, null, 2), 'utf8');
    res.json({ status: 'saved', path: filePath });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save chat', detail: err.message });
  }
});


const Agent = require('./server/agent_engine');



const session = require('express-session');
app.use(session({ secret: 'superagent_secret', resave: false, saveUninitialized: true }));

// התחברות
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'users.json'), 'utf8'));
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  // לאחר login, נטען גם את engine של המשתמש
bcrypt.compare(password, user.password, (err, result) => {
  if (result) {
    req.session.user = {
      username: user.username,
      role: user.role,
      engine: user.engine || "openai"
    };
    res.json({ success: true });
  } else {
    res.json({ success: false, message: 'סיסמה שגויה' });
  }
});
  res.json({ status: 'logged_in', user: req.session.user });
});

// הגנה על מסלולים
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user || (role && req.session.user.role !== role)) {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    next();
  };
}

// רישום פעילות סוכן
function logAgentAction(agentId, capability, source = "manual") {
  const logPath = path.join(__dirname, 'logs', 'agent_logs.json');
  const logEntry = {
    agentId,
    capability,
    source,
    timestamp: new Date().toISOString()
  };
  try {
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    const logs = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath, 'utf8')) : [];
    logs.push(logEntry);
    fs.writeFileSync(logPath, JSON.stringify(logs, null, 2), 'utf8');
  } catch (e) {
    console.error("Failed to log agent action:", e.message);
  }
}

// הרצת יכולת דרך סוכן
app.post('/agent-run', (req, res) => {
  const { agentId, capability } = req.body;
  if (!agentId || !capability) {
    return res.status(400).json({ error: 'Missing agentId or capability' });
  }

  try {
    const agent = new Agent(agentId);
    const info = agent.describe();
    if (!info.active) {
      return res.status(403).json({ error: 'Agent is not active' });
    }

    const result = agent.run(capability);
    logAgentAction(agentId, capability);
  res.json({ agent: info, output: result });
  } catch (err) {
    res.status(500).json({ error: 'Agent execution failed', detail: err.message });
  }
});


// הפעלת/כיבוי סוכן בקובץ config
app.post('/toggle-agent', (req, res) => {
  const { agentId } = req.body;
  if (!agentId) {
    return res.status(400).json({ error: 'Missing agentId' });
  }

  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const agent = agents.find(a => a.id === agentId);
    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    agent.active = !agent.active;
    fs.writeFileSync(configPath, JSON.stringify(agents, null, 2), 'utf8');
    res.json({ status: 'updated', agent });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update agent', detail: err.message });
  }
});


// יצירת סוכן חדש
app.post('/create-agent', (req, res) => {
  const { id, name, description, skills } = req.body;
  if (!id || !name) {
    return res.status(400).json({ error: 'Missing id or name' });
  }

  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));

    if (agents.find(a => a.id === id)) {
      return res.status(409).json({ error: 'Agent ID already exists' });
    }

    const newAgent = {
      id,
      name,
      description: description || '',
      skills: skills || [],
      active: true
    };

    agents.push(newAgent);
    fs.writeFileSync(configPath, JSON.stringify(agents, null, 2), 'utf8');
    res.json({ status: 'created', agent: newAgent });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create agent', detail: err.message });
  }
});


// מחיקת סוכן לפי ID
app.post('/delete-agent', (req, res) => {
  const { agentId } = req.body;
  if (!agentId) {
    return res.status(400).json({ error: 'Missing agentId' });
  }

  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    let agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const index = agents.findIndex(a => a.id === agentId);
    if (index === -1) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    const removed = agents.splice(index, 1);
    fs.writeFileSync(configPath, JSON.stringify(agents, null, 2), 'utf8');
    res.json({ status: 'deleted', agent: removed[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete agent', detail: err.message });
  }
});


const { Parser } = require('json2csv');

// ייצוא דוח סוכנים ל־CSV
app.get('/export-agents', (req, res) => {
  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const fields = ['id', 'name', 'description', 'skills', 'active'];
    const parser = new Parser({ fields });
    const csv = parser.parse(agents);
    res.header('Content-Type', 'text/csv');
    res.attachment('SuperAgent_Agents_Report.csv');
    res.send(csv);
  } catch (err) {
    res.status(500).json({ error: 'Failed to export', detail: err.message });
  }
});


const pdf = require('html-pdf');

// יצירת PDF לזיכרון של סוכן
app.get('/export-agent-pdf/:agentId', (req, res) => {
  const agentId = req.params.agentId;
  const memPath = path.join(__dirname, 'memory', `${agentId}_chat.json`);

  if (!fs.existsSync(memPath)) {
    return res.status(404).json({ error: 'No memory file for agent' });
  }

  const chat = JSON.parse(fs.readFileSync(memPath, 'utf8'));
  let html = `<h1>דו"ח זיכרון - סוכן ${agentId}</h1><ul>`;
  chat.forEach(entry => {
    html += `<li><strong>${entry.role}:</strong> ${entry.message}</li>`;
  });
  html += '</ul>';

  pdf.create(html, {}).toStream((err, stream) => {
    if (err) return res.status(500).json({ error: 'PDF creation failed', detail: err.message });
    res.setHeader('Content-type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${agentId}_memory_report.pdf"`);
    stream.pipe(res);
  });
});


// יצירת PDF כולל לכל הסוכנים
app.get('/export-full-report', async (req, res) => {
  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    let html = '<h1>דו"ח כולל - SuperAgent</h1><table border="1" cellpadding="10" cellspacing="0"><thead><tr><th>ID</th><th>שם</th><th>תיאור</th><th>כישורים</th><th>סטטוס</th><th>מספר שיחות</th></tr></thead><tbody>';

    for (const agent of agents) {
      let count = 0;
      const memPath = path.join(__dirname, 'memory', `${agent.id}_chat.json`);
      if (fs.existsSync(memPath)) {
        const mem = JSON.parse(fs.readFileSync(memPath, 'utf8'));
        count = mem.length;
      }

      html += `<tr>
        <td>${agent.id}</td>
        <td>${agent.name}</td>
        <td>${agent.description}</td>
        <td>${agent.skills.join(', ')}</td>
        <td>${agent.active ? 'פעיל' : 'כבוי'}</td>
        <td>${count}</td>
      </tr>`;
    }

    html += '</tbody></table>';

    pdf.create(html, {}).toStream((err, stream) => {
      if (err) return res.status(500).json({ error: 'PDF generation failed', detail: err.message });
      res.setHeader('Content-type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="SuperAgent_Full_Report.pdf"');
      stream.pipe(res);
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create full report', detail: err.message });
  }
});


const nodemailer = require('nodemailer');

// שליחת דוח PDF מלא באימייל
app.post('/email-full-report', async (req, res) => {
  const { to } = req.body;
  if (!to) return res.status(400).json({ error: 'Missing recipient email' });

  const reportPath = path.join(__dirname, 'SuperAgent_Full_Report.pdf');
  if (!fs.existsSync(reportPath)) {
    return res.status(404).json({ error: 'Full report file not found' });
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'YOUR_EMAIL@gmail.com',
      pass: 'YOUR_APP_PASSWORD'
    }
  });

  const mailOptions = {
    from: 'YOUR_EMAIL@gmail.com',
    to,
    subject: 'דו"ח SuperAgent',
    text: 'מצורף דו"ח PDF מלא של הסוכנים.',
    attachments: [
      {
        filename: 'SuperAgent_Full_Report.pdf',
        path: reportPath
      }
    ]
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) return res.status(500).json({ error: 'Email failed', detail: error.message });
    res.json({ status: 'sent', info });
  });
});


// שליחת דוח סוכן PDF באימייל
app.post('/email-agent-report', (req, res) => {
  const { agentId, to } = req.body;
  if (!agentId || !to) return res.status(400).json({ error: 'Missing agentId or recipient email' });

  const reportPath = path.join(__dirname, 'memory', `${agentId}_chat.json`);
  if (!fs.existsSync(reportPath)) {
    return res.status(404).json({ error: 'No memory for agent' });
  }

  const chat = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
  let html = `<h1>דו"ח זיכרון - סוכן ${agentId}</h1><ul>`;
  chat.forEach(entry => {
    html += `<li><strong>${entry.role}:</strong> ${entry.message}</li>`;
  });
  html += '</ul>';

  const pdfPath = path.join(__dirname, `${agentId}_temp.pdf`);
  pdf.create(html, {}).toFile(pdfPath, (err, file) => {
    if (err) return res.status(500).json({ error: 'PDF generation failed', detail: err.message });

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'YOUR_EMAIL@gmail.com',
        pass: 'YOUR_APP_PASSWORD'
      }
    });

    const mailOptions = {
      from: 'YOUR_EMAIL@gmail.com',
      to,
      subject: `דו"ח של סוכן ${agentId}`,
      text: 'מצורף דוח PDF',
      attachments: [
        { filename: `${agentId}_report.pdf`, path: pdfPath }
      ]
    };

    transporter.sendMail(mailOptions, (error, info) => {
      fs.unlinkSync(pdfPath);
      if (error) return res.status(500).json({ error: 'Email failed', detail: error.message });
      res.json({ status: 'sent', info });
    });
  });
});


// יצירת משתמש
app.post('/admin/create-user', requireRole('admin'), (req, res) => {
  const { username, password, role } = req.body;
  const usersPath = path.join(__dirname, 'config', 'users.json');
  const users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));

  if (users.find(u => u.username === username)) {
    return res.status(409).json({ error: 'User already exists' });
  }

  users.push({ username, password, role });
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf8');
  res.json({ status: 'created' });
});

// מחיקת משתמש
app.post('/admin/delete-user', requireRole('admin'), (req, res) => {
  const { username } = req.body;
  const usersPath = path.join(__dirname, 'config', 'users.json');
  let users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));

  const index = users.findIndex(u => u.username === username);
  if (index === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  users.splice(index, 1);
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf8');
  res.json({ status: 'deleted' });
});


// טעינת ושמירת הגדרות
app.get('/settings', (req, res) => {
  const settingsPath = path.join(__dirname, 'config', 'settings.json');
  const settings = fs.existsSync(settingsPath)
    ? JSON.parse(fs.readFileSync(settingsPath, 'utf8'))
    : {};
  res.json(settings);
});


// לוג שינויים להגדרות
app.post('/settings', (req, res) => {
  const settingsPath = path.join(__dirname, 'config', 'settings.json');
  const logPath = path.join(__dirname, 'logs', 'settings_log.json');
  const incoming = req.body;

  try {
    const existing = fs.existsSync(settingsPath)
      ? JSON.parse(fs.readFileSync(settingsPath, 'utf8'))
      : {};

    const logs = fs.existsSync(logPath)
      ? JSON.parse(fs.readFileSync(logPath, 'utf8'))
      : [];

    const user = req.session?.user?.username || 'unknown';
    const timestamp = new Date().toISOString();

    const merged = { ...existing };

    Object.entries(incoming).forEach(([key, newVal]) => {
      const oldVal = existing[key];
      if (oldVal !== newVal) {
        logs.push({ key, oldVal, newVal, user, timestamp });
        merged[key] = newVal;
      }
    });

    fs.writeFileSync(settingsPath, JSON.stringify(merged, null, 2), 'utf8');
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    fs.writeFileSync(logPath, JSON.stringify(logs, null, 2), 'utf8');

    res.json({ status: 'saved', settings: merged });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save settings', detail: err.message });
  }
});

// app.post('/settings', (req, res) => {
  const settingsPath = path.join(__dirname, 'config', 'settings.json');
  const incoming = req.body;
  try {
    const existing = fs.existsSync(settingsPath)
      ? JSON.parse(fs.readFileSync(settingsPath, 'utf8'))
      : {};
    const merged = { ...existing, ...incoming };
    fs.writeFileSync(settingsPath, JSON.stringify(merged, null, 2), 'utf8');
    res.json({ status: 'saved', settings: merged });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save settings', detail: err.message });
  }
});


    Object.entries(incoming).forEach(([key, newVal]) => {
      const oldVal = existing[key];
      if (oldVal !== newVal) {
        logs.push({
          key,
          oldValue: oldVal,
          newValue: newVal,
          changedBy: user,
          timestamp
        });
        merged[key] = newVal;
      }
    });

    fs.writeFileSync(settingsPath, JSON.stringify(merged, null, 2), 'utf8');
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    fs.writeFileSync(logPath, JSON.stringify(logs, null, 2), 'utf8');

    res.json({ status: 'saved', settings: merged });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save settings', detail: err.message });
  }
});

// שליפת לוג שינויים
app.get('/settings-log', (req, res) => {
  const logPath = path.join(__dirname, 'logs', 'settings_log.json');
  const logs = fs.existsSync(logPath)
    ? JSON.parse(fs.readFileSync(logPath, 'utf8'))
    : [];
  res.json(logs);
});


// שיוך יכולת לסוכן
app.post('/agent-assign-capability', (req, res) => {
  const { agentId, capName, config } = req.body;
  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  try {
    const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const agent = agents.find(a => a.id === agentId);
    if (!agent) return res.status(404).json({ error: 'Agent not found' });

    if (!agent.capabilities) agent.capabilities = [];
    const existing = agent.capabilities.find(c => c.name === capName);
    if (existing) {
      existing.config = config;
    } else {
      agent.capabilities.push({ name: capName, config });
    }

    fs.writeFileSync(configPath, JSON.stringify(agents, null, 2), 'utf8');
    res.json({ status: 'assigned' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to assign capability', detail: err.message });
  }
});


const pathRunLog = path.join(__dirname, 'logs', 'agent_runs_log.json');

function logAgentRun(agentId, capability, result) {
  const timestamp = new Date().toISOString();
  const logPath = pathRunLog;
  const logs = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath, 'utf8')) : [];
  logs.push({ agentId, capability, timestamp, result });
  fs.mkdirSync(path.dirname(logPath), { recursive: true });
  fs.writeFileSync(logPath, JSON.stringify(logs, null, 2), 'utf8');
}

// שימוש בלוג בתוך /agent-run
app.post('/agent-run', (req, res) => {
  const { agentId, capability } = req.body;
  const configPath = path.join(__dirname, 'config', 'agent_config.json');
  const agents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const agent = agents.find(a => a.id === agentId);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });

  const result = `בוצע ${capability} בהצלחה`; // Placeholder
  logAgentRun(agentId, capability, result);
  res.json({ agent: agent.name, output: result });
});


// שליפת משימות
app.get('/tasks', (req, res) => {
  const taskPath = path.join(__dirname, 'data', 'tasks.json');
  const data = fs.existsSync(taskPath) ? JSON.parse(fs.readFileSync(taskPath, 'utf8')) : [];
  res.json(data);
});

// שמירת/עדכון משימות
app.post('/tasks', (req, res) => {
  const taskPath = path.join(__dirname, 'data', 'tasks.json');
  const tasks = fs.existsSync(taskPath) ? JSON.parse(fs.readFileSync(taskPath, 'utf8')) : [];
  const incoming = req.body;
  tasks.push(incoming);
  fs.writeFileSync(taskPath, JSON.stringify(tasks, null, 2), 'utf8');
  res.json({ status: 'saved' });
});


// שליחת מייל אמיתי עם קובץ מצורף
const nodemailer = require('nodemailer');

app.post('/send-email', (req, res) => {
  const { to, fileName, filePath } = req.body;
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'settings.json'), 'utf8'));

  const transporter = nodemailer.createTransport({
    host: config.smtp_host,
    port: config.smtp_port,
    secure: config.smtp_port === 465,
    auth: {
      user: config.smtp_user,
      pass: config.smtp_pass
    }
  });

  const mailOptions = {
    from: config.email_from,
    to: to || config.email_default_to,
    subject: "קובץ מ־SuperAgent",
    text: "מצורף קובץ שנשלח ממערכת SuperAgent.",
    attachments: [
      {
        filename: fileName,
        path: filePath
      }
    ]
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("שגיאה בשליחה:", error);
      return res.status(500).json({ error: error.message });
    }
    res.json({ status: "sent", info });
  });
});


// שליחת סיכום יומי/שבועי אוטומטית
const cron = require('node-cron');
const { exec } = require('child_process');

const settings = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'settings.json'), 'utf8'));
const reportFreq = settings.auto_report.frequency === "weekly" ? "0 9 * * 0" : "0 9 * * *"; // every Sunday or every day at 09:00

cron.schedule(reportFreq, () => {
  console.log("שליחת דוח אוטומטי התחילה...");
  const fileName = settings.auto_report.format === "Excel" ? "chat_summary.xlsx" : "chat_summary.pdf";
  const filePath = path.join(__dirname, 'data', fileName);

  const mailPayload = {
    to: settings.auto_report.recipients[0],
    fileName: fileName,
    filePath: filePath
  };

  const req = require('http').request({
    hostname: 'localhost',
    port: 3000,
    path: '/send-email',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    }
  });

  req.write(JSON.stringify(mailPayload));
  req.end();
});


const session = require('express-session');
const bcrypt = require('bcrypt');
app.use(session({ secret: 'superagent-secret', resave: false, saveUninitialized: true }));

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'users.json'), 'utf8'));
  const user = users.find(u => u.username === username);
  if (!user) return res.json({ success: false, message: 'משתמש לא נמצא' });

  bcrypt.compare(password, user.password, (err, result) => {
    if (result) {
      // לאחר login, נטען גם את engine של המשתמש
bcrypt.compare(password, user.password, (err, result) => {
  if (result) {
    req.session.user = {
      username: user.username,
      role: user.role,
      engine: user.engine || "openai"
    };
    res.json({ success: true });
  } else {
    res.json({ success: false, message: 'סיסמה שגויה' });
  }
});
      res.json({ success: true });
    } else {
      res.json({ success: false, message: 'סיסמה שגויה' });
    }
  });
});


// נקודת גישה לשמירת הרשאות מ־GUI
app.post('/save-permissions', (req, res) => {
  fs.writeFileSync(path.join(__dirname, 'config', 'permissions.json'), JSON.stringify(req.body, null, 2), 'utf8');
  res.json({ status: "saved" });
});


// ניתוח קבצים בפרויקט לפי שם
const { exec } = require('child_process');
// ניתוח קוד אמיתי לכל קובץ בפרויקט
app.get('/analyze-project/:name', (req, res) => {
  const folder = path.join(__dirname, 'projects', req.params.name);
  const result = [];

  fs.readdirSync(folder).forEach(file => {
    const filePath = path.join(folder, file);
    const ext = path.extname(file).toLowerCase();
    const content = fs.readFileSync(filePath, 'utf8');

    let status = "מוכן";
    let suggestions = [];

    if (ext === '.js') {
      if (content.includes("var ")) suggestions.push("החלף var ל-let/const.");
      if (!content.includes("use strict")) suggestions.push("הוסף 'use strict' לראש הקובץ.");
    } else if (ext === '.py') {
      if ("print(" in content && "()" not in content) suggestions.push("וודא שימוש נכון ב-print.");
      if ("import os" in content && "os." not in content) suggestions.push("ייבאת os אך לא נעשה בו שימוש.");
    } else if (ext === '.html') {
      if (!content.includes("<!DOCTYPE html>")) suggestions.push("חסר Doctype בראש המסמך.");
    } else {
      status = "לא נדרש ניתוח";
    }

    result.push({ file, ext, status, suggestions });
  });

  res.json(result);
}););
  });
  res.json(result);
});


app.get('/project-files/:project', (req, res) => {
  const dir = path.join(__dirname, 'projects', req.params.project);
  const files = fs.readdirSync(dir);
  res.json(files);
});

app.get('/project-file/:project/:file', (req, res) => {
  const filePath = path.join(__dirname, 'projects', req.params.project, req.params.file);
  res.sendFile(filePath);
});

app.post('/save-project-file/:project/:file', (req, res) => {
  const filePath = path.join(__dirname, 'projects', req.params.project, req.params.file);
  fs.writeFileSync(filePath, req.body.content, 'utf8');
  res.json({ status: "saved" });
});


app.post('/save-as/:project/:newname', (req, res) => {
  const filePath = path.join(__dirname, 'projects', req.params.project, req.params.newname);
  fs.writeFileSync(filePath, req.body.content, 'utf8');
  res.json({ status: "saved as" });
});

app.get('/history/:project/:filename', (req, res) => {
  const dir = path.join(__dirname, 'projects', req.params.project);
  const base = req.params.filename;
  const files = fs.readdirSync(dir).filter(f => f.startsWith(base + ".bak"));
  res.json(files);
});

app.get('/load-version/:project/:file', (req, res) => {
  const filePath = path.join(__dirname, 'projects', req.params.project, req.params.file);
  res.sendFile(filePath);
});

// יצירת גיבוי בזמן שמירה רגילה
const origSave = app._router.stack.find(r => r.route && r.route.path === '/save-project-file/:project/:file');
if (origSave) {
  const idx = app._router.stack.indexOf(origSave);
  app._router.stack.splice(idx, 1);
}
app.post('/save-project-file/:project/:file', (req, res) => {
  const filePath = path.join(__dirname, 'projects', req.params.project, req.params.file);
  const backup = filePath + ".bak" + Date.now();
  if (fs.existsSync(filePath)) fs.copyFileSync(filePath, backup);
  fs.writeFileSync(filePath, req.body.content, 'utf8');
  res.json({ status: "saved with backup" });
});


app.post('/send-agent', (req, res) => {
  const { task, host, os, user, pass } = req.body;
  // כאן יתבצעו כל ההרצות האמיתיות (SSH / PowerShell וכו')
  console.log(`ביצוע משימה: ${task} על יעד ${host} (${os}) עם ${user}`);
  res.json({ status: "סוכן נשלח - הפעולה בתהליך (מוקצה)" });
});
