
# SuperAgent — מערכת סוכנים חכמה

## תיאור כללי
SuperAgent היא מערכת גמישה, דינמית וחכמה לניהול, הרצה, ניתוח ודיווח של סוכנים עצמאיים הפועלים במקביל. כל סוכן מבצע משימה או רצף משימות — תוך שמירה, דיווח ולוגיקה מלאה בזמן אמת.

---

## מבנה תיקיות
```
/agents/{agentId}/
  ├── configs/         # קובץ הגדרות אישי
  ├── scripts/         # סקריפטים להרצה
  ├── outputs/         # פלטים, תמונות, JSON
  ├── logs/            # לוג פעילות
/interface/
  ├── pages/           # דפי HTML לממשק
  ├── assets/          # CSS, JS
/modules/              # כל המנועים החכמים
/config/settings.json  # הגדרות כלליות למערכת
```

---

## מודולים עיקריים
- `AgentBuilder.js` — יצירת סוכן עם קונפיג וסקריפטים
- `AgentQueueManager.js` — ניהול תור והרצה מקבילית
- `DynamicRunner.js` — ריצה עם דינמיקה לפי שלבים
- `Notifier.js` — שליחת הודעות ל־Webhook / Telegram / Email
- `AgentResultManager.js` — שמירת פלטים
- `InsightEngine.js`, `KnowledgeHub.js` — ניתוח והשוואה
- `ImageCreator.js`, `SloganGenerator.js`, `MarketScanner.js`, `WebLogin.js`

---

## API חשובים
- `POST /api/create-agent` — יצירת סוכן
- `POST /send-email` — שליחת מייל
- `GET /get-agent-result/:id` — קבלת תוצאה
- `POST /save-agent-result/:id` — שמירה מחדש

---

## הוראות הרצה
1. התקן את כל המודולים:  
```bash
npm install express nodemailer socket.io puppeteer axios
```

2. הרץ את המערכת:  
```bash
node server/server.js
```

3. גש לממשק בדפדפן:  
```
http://localhost:3000/interface/pages/index.html
```

---

## הערות
- ניתן להחליף את מודול ה־AI דרך `config/settings.json`
- כל הפעולות נשמרות אוטומטית לקובץ אישי של הסוכן
- תמיכה מלאה ב־50+ סוכנים במקביל

---



---

## מודולים חדשים שנוספו

- `BreakCore.js` — ייצור פרומפטים אינטליגנטיים לפי הקשר
- `MindReader.js` — ניתוח קבצים ויזואליים ושמע (OCR / Whisper)
- `ShadowCore.js` — חקירת מידע ממקורות שונים
- `SoulFind.js` — מציאת כלים לפי קטגוריה (AI, שיווק, טקסט)
- `AgentQueueManager.js` — ניהול מקבילי ל-50 סוכנים
- `DynamicRunner.js` — שינוי/דילוג על שלבים תוך כדי ביצוע
- `Notifier.js` — שליחת התראות בזמן אמת (Webhook, Telegram, Email)
- `dashboard.html` — לוח בקרה חי לכל הסוכנים

---

## תיעוד שלב 3–4 (עדכון)

- תצוגה של תוצאות הסוכן עם עריכה ב־HTML
- סוכן מסוג פרו: ניהול משימות מרובות לפי סוג (יוצר, חוקר, חוקר בורסה)
- כל תוצאה נרשמת אוטומטית לקובץ `result.json`
- תמיכה בהוספת תהליכים מורכבים עם 10–20 שלבים



---

## יכולות מתקדמות שנוספו לאחרונה

- העלאת קבצים (PDF, תמונה, Excel) לסוכן — דרך `upload_file.html`
- צילום והעלאה מה-iPhone — דרך `upload_camera.html`
- קלט קולי → טקסט — דרך `voice_input.html` עם זיהוי קולי חכם
- MindReader — עכשיו עם OCR אמיתי (Tesseract.js)
- Whisper API מוכן לתמלול קולי מלא
- תיעוד מסודר להתקנה, הפעלה, שמירה

---

## מסכים חדשים:

- `/interface/pages/upload_file.html`
- `/interface/pages/upload_camera.html`
- `/interface/pages/voice_input.html`

---



---

## יכולות קוליות

- תמיכה בזיהוי דיבור דרך Web Speech API (ללא תשלום)
- תמיכה ב-Whisper API של OpenAI (דורש API Key ותשלום לפי שימוש)
- ניתן להגדיר ב-settings.json את הספק המועדף
- אפשר להפעיל הקלטה דרך voice_input.html ולשלוח לטיפול

## בחירת ספק AI וקול

- בממשק ההגדרות ניתן לבחור בין OpenAI לבין ספק פרטי
- ניתן להחליף בין Web Speech לבין Whisper בקלות

---



---

## יכולת בינה לומדת (AI מתפתח עצמאי)

- כל טעות, ביקורת עצמית, שגיאה — נשמרת אוטומטית
- KnowledgeLearner מאחד את כל הידע ומפיק תובנות
- סוכנים חדשים “נולדים חכמים יותר” ויודעים להימנע מטעויות עבר
- המערכת לומדת לבד, בלי צורך להדריך מחדש



---

## VoiceResponder – דיבור אנושי

- משתמש ב־Google TTS (ניתן לשדרג ל־ElevenLabs או Azure)
- שומר קובץ MP3 עם הקול האנושי של הסוכן
- נתמך בהגדרות המערכת (settings.json)

