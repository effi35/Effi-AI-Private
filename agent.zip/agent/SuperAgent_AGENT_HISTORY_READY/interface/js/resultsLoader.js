<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Agents Manager</title>
  <link rel="stylesheet" href="styles/agents.css">
</head>
<body>
  <h1>Agents Dashboard</h1>

  <table id="agentsTable">
    <thead>
      <tr>
        <th>Agent ID</th>
        <th>Name</th>
        <th>Description</th>
        <th>Extended</th>
        <th>Tasks</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <!-- מידע דינמי -->
    </tbody>
  </table>

  <script>
    async function fetchAgents() {
      try {
        const response = await fetch('/api/agents');
        const agents = await response.json();

        const tbody = document.querySelector('#agentsTable tbody');
        tbody.innerHTML = '';

        agents.forEach(agent => {
          const tr = document.createElement('tr');

          tr.innerHTML = `
            <td>${agent.id}</td>
            <td>${agent.name || '---'}</td>
            <td>${agent.description || '---'}</td>
            <td>${agent.extended ? 'Yes' : 'No'}</td>
            <td>${agent.tasks ? agent.tasks.map(t => t.name).join(', ') : '---'}</td>
            <td style="color: ${agent.status === 'Success' ? 'green' : agent.status === 'Failed' ? 'red' : 'black'}">
              ${agent.status || 'Pending'}
            </td>
            <td>
              <button onclick="runAgentNow('${agent.id}')">הפעל עכשיו</button>
              <button onclick="sendResult('${agent.id}')">שלח תוצאה</button>
              <button onclick="deleteAgent('${agent.id}')">מחק</button>
            </td>
          `;

          tbody.appendChild(tr);
        });

      } catch (error) {
        console.error('Error fetching agents:', error);
      }
    }

    async function deleteAgent(agentId) {
      if (confirm('Are you sure you want to delete this agent?')) {
        try {
          const response = await fetch(`/api/agents/${agentId}`, { method: 'DELETE' });
          if (response.ok) {
            alert('Agent deleted successfully.');
            fetchAgents();
          } else {
            alert('Failed to delete agent.');
          }
        } catch (error) {
          console.error(error);
        }
      }
    }

    async function sendResult(agentId) {
      try {
        const response = await fetch(`/api/agents/${agentId}/send`, { method: 'POST' });
        if (response.ok) {
          alert('Result sent to email!');
        } else {
          alert('Failed to send result.');
        }
      } catch (error) {
        console.error(error);
      }
    }

    async function runAgentNow(agentId) {
      try {
        const response = await fetch(`/run-agent-now/${agentId}`, { method: 'POST' });
        if (response.ok) {
          alert('Agent run initiated!');
          fetchAgents(); // Refresh status
        } else {
          alert('Failed to run agent.');
        }
      } catch (error) {
        console.error(error);
      }
    }

    window.onload = fetchAgents;
  </script>
</body>
</html>
