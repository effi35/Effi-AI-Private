
self.addEventListener('install', function(e) {
  e.waitUntil(caches.open('superagent-store').then(function(cache) {
    return cache.addAll([
      '/interface/pages/index.html',
      '/interface/pages/chat_interface.html',
      '/interface/pages/voice_input.html'
    ]);
  }));
});

self.addEventListener('fetch', function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});
