
let agentRunning = false;
let agentConfig = {
  type: 'simple',
  settings: {
    pingInterval: 5000
  }
};

document.getElementById('advancedModeCheckbox').addEventListener('change', function() {
  agentConfig.type = this.checked ? 'advanced' : 'simple';
});

document.getElementById('startAgentBtn').addEventListener('click', function() {
  agentRunning = true;
  document.getElementById('statusArea').textContent = "Agent is running.";
  sendStatusEmail("Agent started successfully.");
  pingAgent();
});

document.getElementById('testAgentBtn').addEventListener('click', function() {
  if (agentRunning) {
    document.getElementById('statusArea').textContent = "Agent test successful.";
    sendStatusEmail("Agent tested successfully.");
  } else {
    document.getElementById('statusArea').textContent = "Agent is not running.";
    sendStatusEmail("Agent test failed - agent not running.");
  }
});

function pingAgent() {
  setInterval(() => {
    if (!agentRunning) return;
    fetch('https://webhook.site/your-temp-api-url', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        agentId: "agent123",
        timestamp: new Date().toISOString()
      })
    })
    .then(response => {
      if (response.ok) {
        logToConsole("Ping successful.");
      } else {
        logToConsole("Ping failed.");
        agentRunning = false;
        document.getElementById('statusArea').textContent = "Agent stopped (Ping failed).";
        sendStatusEmail("Agent stopped due to failed ping.");
      }
    })
    .catch(error => {
      logToConsole("Ping error: " + error);
      agentRunning = false;
      document.getElementById('statusArea').textContent = "Agent stopped (Ping error).";
      sendStatusEmail("Agent stopped due to ping error.");
    });
  }, agentConfig.settings.pingInterval);
}

function sendStatusEmail(message) {
  fetch('/send-email', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      subject: "Agent Status Update",
      body: message
    })
  })
  .then(response => response.json())
  .then(data => logToConsole('Email sent successfully: ' + JSON.stringify(data)))
  .catch(error => logToConsole('Error sending email: ' + error));
}

async function createAgent() {
  const name = document.getElementById('agentName').value;
  const description = document.getElementById('agentDescription').value;
  const tasksInput = document.getElementById('agentTasks').value;
  const extendedMode = document.getElementById('extendedMode').checked;

  if (!name || !description || !tasksInput) {
    alert('Please fill all fields');
    return;
  }

  const tasks = tasksInput.split(',').map(task => ({ name: task.trim() }));
  const agentData = {
    name: name,
    description: description,
    extended: extendedMode,
    tasks: tasks
  };

  try {
    const response = await fetch('/api/create-agent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(agentData)
    });

    const result = await response.json();
    if (result.success) {
      document.getElementById('agentStatus').innerText = 'Agent created successfully! Agent ID: ' + result.agentId;
    } else {
      document.getElementById('agentStatus').innerText = 'Failed to create agent.';
    }
  } catch (error) {
    logToConsole('Error creating agent: ' + error);
    document.getElementById('agentStatus').innerText = 'Error creating agent.';
  }
}

function logToConsole(message) {
  const consoleDiv = document.getElementById("consoleLogs");
  const logEntry = document.createElement("div");
  logEntry.textContent = `${new Date().toLocaleTimeString()}: ${message}`;
  consoleDiv.appendChild(logEntry);
  consoleDiv.scrollTop = consoleDiv.scrollHeight;
}



const socket = io();

// Emit agent creation to server
function emitAgentAction(agentId, action, status, details) {
  socket.emit('agent_action', {
    agentId,
    action,
    status,
    details,
    timestamp: new Date().toISOString()
  });
}
