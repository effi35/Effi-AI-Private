
#!/bin/bash

echo "מתקין את כל התלויות..."
npm install express nodemailer socket.io puppeteer axios body-parser cors

echo "התקנה הושלמה!"
