
📁 ShayAI
│
├── 📁 interface..
│   ├── index.html..
│   ├── results.html..
│   ├── agent-results.html..
│   ├── commander.html..
│   ├── agents.html..
│   ├── agents-dashboard.html..
│   └── 📁 assets..
│            ├── 📁 js..
│            ├── 📁 css..
│                     ├── results.css..
│                     ├── results_alt.css..
│                     └── style.css..
│   ├── 📁 js..
│           ├── agentManager.js..
│           ├── resultsLoader.js..
│           └── modulesRunner.js..
│   └── 📁 pages..
│           ├── agents.html..
│           ├── agents-dashboard.html..
│           └── results.html..
│
├── 📁 modules..
│   ├── BreakCore.json..
│   ├── MindReader.json..
│   ├── SoulFind.json..
│   ├── AgentSmith.json..
│   ├── ShadowCore.json..
│   ├── agent_extended.js..
│   ├── agent_monitor.js..
│   └── modulesRunner.js..
│
├── 📁 config..
│   └── agent_config.json..
│
├── 📁 docs..
│   ├── README.txt..
│   ├──README2.txt..
│   ├── PROJECT_OVERVIEW.md..
│   ├── קובץ הסבר והגדרות.json..
│   └── רשימה להשלים.txt..
│
├── 📁 scripts..
│   └──  agents.js..
│
├── 📁 prompts..
│   └── example_prompts.txt..
│
├── 📁 mind-ShayAi..
│   └── ShayAi-mind.json..
│
├── 📁 js..
│   ├──moduleRunner.js..
│   ├──modulesRunner.js..
│   ├──reportGenerator.js..
│   ├──results.js..
│   └──resultsLoader.js..
│
├── 📁 css..
│   ├── agents.css..
│   ├── results.css..
│   └── style.css..
│
├── 📁 agents..
│   ├── (תיקיות agents נוצרות דינאמית)..
│   ├── results.html.. 
│   ├── 📁 reports..
│   ├── 📁 results..
│   └── 📁 tasks..
│
├── 📁 server..
│   ├── server.js..
│   └──agent_monitor.js..
│ 
├── README.md..
