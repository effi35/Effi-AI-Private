
// KnowledgeHub.js
// איחוד מידע מכל הסוכנים לקובץ מרכזי

const fs = require('fs');
const path = require('path');

function buildHub(baseDir = '../agents') {
  const agentsRoot = path.join(__dirname, baseDir);
  const aggregated = {};

  try {
    const agents = fs.readdirSync(agentsRoot).filter(name => {
      return fs.statSync(path.join(agentsRoot, name)).isDirectory();
    });

    agents.forEach(agentId => {
      const resultPath = path.join(agentsRoot, agentId, 'outputs', agentId + '_result.json');
      if (fs.existsSync(resultPath)) {
        const data = JSON.parse(fs.readFileSync(resultPath, 'utf-8'));
        aggregated[agentId] = data;
      }
    });

    const hubPath = path.join(agentsRoot, 'knowledge_hub.json');
    fs.writeFileSync(hubPath, JSON.stringify(aggregated, null, 2), 'utf-8');
    console.log('Knowledge Hub created.');
    return hubPath;
  } catch (err) {
    console.error('Error building knowledge hub:', err);
    return null;
  }
}

module.exports = buildHub;
