
// RemoteSSH.js
// שליטה בשרתים דרך SSH (כולל Raspberry Pi)

const { NodeSSH } = require('node-ssh');
const fs = require('fs');
const path = require('path');
const ssh = new NodeSSH();

async function executeRemoteCommand(agentId, command, configPath = '../config/access_control.json') {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, configPath), 'utf-8'));
  const sshConf = config.services.ssh_access;

  if (!sshConf.enabled) {
    console.log('SSH גישה אינה פעילה');
    return '[גישה ל-SSH אינה פעילה]';
  }

  try {
    await ssh.connect({
      host: sshConf.host,
      username: sshConf.user,
      port: sshConf.port || 22,
      privateKey: sshConf.private_key
    });

    const result = await ssh.execCommand(command);
    const logPath = path.join(__dirname, '../agents', agentId, 'logs', `ssh_exec_${Date.now()}.txt`);
    fs.writeFileSync(logPath, JSON.stringify(result, null, 2), 'utf-8');
    return result.stdout || result.stderr;
  } catch (err) {
    return '[שגיאה בהרצת פקודת SSH]: ' + err.message;
  }
}

module.exports = { executeRemoteCommand };
