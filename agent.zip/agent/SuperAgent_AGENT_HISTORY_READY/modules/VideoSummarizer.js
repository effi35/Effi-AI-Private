
// VideoSummarizer.js
// מסכם תוכן קולי מתוך קובץ וידאו

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const axios = require('axios');

async function summarizeVideo(agentId, videoPath, baseDir = '../agents') {
  const audioPath = videoPath.replace(/\.mp4$/, '.wav');
  execSync(`ffmpeg -i "${videoPath}" -ar 16000 -ac 1 -vn "${audioPath}"`);

  const audioData = fs.readFileSync(audioPath);
  const whisperRes = await axios.post('https://api.openai.com/v1/audio/transcriptions', audioData, {
    headers: {
      'Content-Type': 'audio/wav',
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  const transcript = whisperRes.data.text;
  const summaryPrompt = "סכם לי בקצרה את הנאמר:
" + transcript;

  const chatRes = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4',
    messages: [{ role: "user", content: summaryPrompt }]
  }, {
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  const summary = chatRes.data.choices[0].message.content;
  const outPath = path.join(__dirname, baseDir, agentId, 'logs', `video_summary_${Date.now()}.txt`);
  fs.writeFileSync(outPath, summary, 'utf-8');
  return summary;
}

module.exports = { summarizeVideo };
