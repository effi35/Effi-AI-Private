
// BreakCore.js
// יוצר פרומפטים מתוחכמים עם הקשר, סגנון וסיווג לפי משימה

const fs = require('fs');
const path = require('path');

function BreakCore(agentId, taskName, context, style = 'marketing', baseDir = '../agents') {
  const prompt = `כתיבת פרומפט עבור משימה "${taskName}" בסגנון "${style}":
${context ? `הקשר: ${context}` : ''}
הנחיות: היה מדויק, יצירתי וכולל הנעה לפעולה אם רלוונטי.`;
  
  const promptPath = path.join(__dirname, baseDir, agentId, 'outputs', `${taskName}_prompt.txt`);
  fs.writeFileSync(promptPath, prompt, 'utf-8');
  console.log('BreakCore prompt generated for', taskName);
  return prompt;
}

module.exports = BreakCore;
