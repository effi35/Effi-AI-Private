
// InsightEngine.js
// השוואה בין תוצאות של סוכנים וניתוח עומק

const fs = require('fs');
const path = require('path');

function compareAgents(agentIds, baseDir = '../agents') {
  const comparisons = {};

  agentIds.forEach(agentId => {
    const resultPath = path.join(__dirname, baseDir, agentId, 'outputs', agentId + '_result.json');
    try {
      const data = JSON.parse(fs.readFileSync(resultPath, 'utf-8'));
      comparisons[agentId] = data;
    } catch (err) {
      comparisons[agentId] = { error: 'Failed to load or parse result' };
    }
  });

  const analysis = {
    compared: comparisons,
    summary: `Compared ${agentIds.length} agents at ${new Date().toISOString()}`
  };

  const summaryPath = path.join(__dirname, baseDir, 'analysis_summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify(analysis, null, 2), 'utf-8');

  console.log('Insight analysis complete.');
  return analysis;
}

module.exports = compareAgents;
