
// DocWizard.js
// סוכן שיוצר מסמך PDF/Word מדו״ח טקסטואלי

const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

function createDocument(agentId, content, fileName = 'report', baseDir = '../agents') {
  const docPath = path.join(__dirname, baseDir, agentId, 'logs', `${fileName}_${Date.now()}.pdf`);
  const doc = new PDFDocument();

  doc.pipe(fs.createWriteStream(docPath));
  doc.fontSize(14).text(content, {
    align: 'right'
  });
  doc.end();

  return '[DocWizard] נוצר קובץ PDF: ' + path.basename(docPath);
}

module.exports = { createDocument };
