
// AgentVision.js
// סוכן שמתחבר למצלמת אבטחה ומנתח וידאו

const axios = require('axios');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function analyzeCamera(agentId, cameraUrl, task = 'count_people', baseDir = '../agents') {
  const snapshotPath = path.join(__dirname, baseDir, agentId, 'logs', `cam_snapshot_${Date.now()}.jpg`);
  try {
    execSync(`ffmpeg -i "${cameraUrl}" -frames:v 1 "${snapshotPath}"`);

    const imageData = fs.readFileSync(snapshotPath);
    const result = await axios.post('https://api.openai.com/v1/images/analyze', imageData, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'image/jpeg'
      },
      params: { task }
    });

    const report = result.data.description || '[אין תוצאה]';
    const logPath = path.join(__dirname, baseDir, agentId, 'logs', `vision_result_${Date.now()}.txt`);
    fs.writeFileSync(logPath, report, 'utf-8');
    return report;
  } catch (err) {
    return '[שגיאה בניתוח מצלמה]: ' + err.message;
  }
}

module.exports = { analyzeCamera };
