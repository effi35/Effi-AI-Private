
// ClipCreator.js
// סוכן שיוצר קליפים מוידאו קיים: חיבור קטעים, הוספת טקסטים

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

function createClip(agentId, videoPaths, outputName, textOverlay = '', baseDir = '../agents') {
  const tempListPath = path.join(__dirname, 'temp_files.txt');
  const outputPath = path.join(__dirname, baseDir, agentId, 'logs', `${outputName}_${Date.now()}.mp4`);

  // הכנת קובץ רשימה לחיבור
  const fileList = videoPaths.map(p => `file '${p}'`).join('\n');
  fs.writeFileSync(tempListPath, fileList, 'utf-8');

  try {
    execSync(`ffmpeg -f concat -safe 0 -i "${tempListPath}" -c copy "${outputPath}"`);

    if (textOverlay) {
      const tempOutput = outputPath.replace('.mp4', '_text.mp4');
      execSync(`ffmpeg -i "${outputPath}" -vf "drawtext=text='${textOverlay}':fontcolor=white:fontsize=30:x=10:y=H-th-10" -codec:a copy "${tempOutput}"`);
      fs.unlinkSync(outputPath);
      return '[ClipCreator] קליפ נוצר עם טקסט: ' + path.basename(tempOutput);
    }

    return '[ClipCreator] קליפ נוצר בהצלחה: ' + path.basename(outputPath);
  } catch (err) {
    return '[ClipCreator] שגיאה ביצירת קליפ: ' + err.message;
  }
}

module.exports = { createClip };
