
// WebLogin.js
// ביצוע Login לאתר באמצעות Puppeteer

const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

async function performLogin(agentId, loginUrl, username, password, outputDir = '../agents') {
  const screenshotPath = path.join(__dirname, outputDir, agentId, 'outputs', 'login_result.png');

  try {
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();

    await page.goto(loginUrl, { waitUntil: 'networkidle2' });

    // ניתן לשנות את הסלקטורים בהתאם לאתר
    await page.type('input[name="username"]', username);
    await page.type('input[name="password"]', password);
    await page.click('button[type="submit"]');

    await page.waitForTimeout(3000);
    await page.screenshot({ path: screenshotPath });

    await browser.close();
    console.log('Login completed and screenshot saved:', screenshotPath);
    return screenshotPath;
  } catch (err) {
    console.error('Login failed:', err.message);
    return null;
  }
}

module.exports = performLogin;
