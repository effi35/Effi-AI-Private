
// AgentResultManager.js
// שמירת תוצאות לסוכן בקובץ אישי לפי מפתח

const fs = require('fs');
const path = require('path');

function saveToAgentResult(agentId, key, data, baseDir = '../agents') {
  const resultPath = path.join(__dirname, baseDir, agentId, 'outputs', agentId + '_result.json');
  let result = {};

  try {
    if (fs.existsSync(resultPath)) {
      result = JSON.parse(fs.readFileSync(resultPath, 'utf-8'));
    }
  } catch (err) {
    console.error('Failed to read existing result:', err.message);
  }

  result[key] = data;

  try {
    fs.writeFileSync(resultPath, JSON.stringify(result, null, 2), 'utf-8');
    console.log('Updated result for', agentId);
  } catch (err) {
    console.error('Failed to save result:', err.message);
  }
}

module.exports = saveToAgentResult;
