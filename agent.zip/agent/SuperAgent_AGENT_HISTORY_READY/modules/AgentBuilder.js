
// AgentBuilder.js
// יוצר תיקיות, קונפיג, קבצי ריצה בסיסיים לפי משימה

const fs = require('fs');
const path = require('path');

function AgentBuilder(agentId, tasks, baseDir = '../agents') {
  const agentPath = path.join(__dirname, baseDir, agentId);
  const scriptsPath = path.join(agentPath, 'scripts');
  const runnerPath = path.join(agentPath, 'runner.js');

  // יצירת תיקיות
  if (!fs.existsSync(scriptsPath)) fs.mkdirSync(scriptsPath, { recursive: true });

  // יצירת קובץ runner.js בסיסי
  const runnerCode = `
    const fs = require('fs');
    const path = require('path');
    const logPath = path.join(__dirname, 'logs', 'activity.log');
    const outputPath = path.join(__dirname, 'outputs', '${agentId}_result.json');

    function log(action) {
      const entry = new Date().toISOString() + ' - ' + action + '\n';
      fs.appendFileSync(logPath, entry);
    }

    async function runAgent() {
      log('Started agent ${agentId}');
      let result = {};

      try {
        ${tasks.map(t => `result['${t.name}'] = await require('./scripts/${t.script}')(result);`).join('\n        ')}

        fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
        log('Finished agent ${agentId}');
      } catch (err) {
        log('Error: ' + err.message);
      }
    }

    runAgent();
  `;

  fs.writeFileSync(runnerPath, runnerCode, 'utf-8');

  // יצירת קובצי סקריפט לפי משימה
  tasks.forEach(task => {
    const scriptPath = path.join(scriptsPath, task.script);
    const scriptCode = `
      // ${task.name} Script
      module.exports = async function(result) {
        console.log('Running ${task.name}');
        // Simulate action
        return { status: 'ok', task: '${task.name}', time: new Date().toISOString() };
      };
    `;
    fs.writeFileSync(scriptPath, scriptCode, 'utf-8');
  });

  return { success: true, runner: runnerPath, scripts: tasks.map(t => t.script) };
}

module.exports = AgentBuilder;
