
// KnowledgeLearner.js
// מאחד את כל הביקורות, שגיאות, ומסקנות לידע מתפתח

const fs = require('fs');
const path = require('path');

function learnFromLogs(baseDir = '../agents') {
  const agentDirs = fs.readdirSync(path.join(__dirname, baseDir));
  const knowledge = {
    fails: [],
    reviews: [],
    patterns: {}
  };

  agentDirs.forEach(agentId => {
    const logsPath = path.join(__dirname, baseDir, agentId, 'logs');
    if (!fs.existsSync(logsPath)) return;

    // כשלונות
    const failsFile = path.join(logsPath, 'failures.json');
    if (fs.existsSync(failsFile)) {
      const fails = JSON.parse(fs.readFileSync(failsFile, 'utf-8'));
      knowledge.fails.push(...fails);
    }

    // ביקורת עצמית
    const reviews = fs.readdirSync(logsPath).filter(f => f.startsWith('selfreview_'));
    reviews.forEach(file => {
      const reviewText = fs.readFileSync(path.join(logsPath, file), 'utf-8');
      knowledge.reviews.push({ agentId, reviewText });
    });
  });

  // הפקת תובנות בסיסיות (דוגמה פשוטה)
  knowledge.patterns = {
    mostCommonErrors: [...new Set(knowledge.fails.map(f => f.error))],
    commonReviewWords: [...new Set(knowledge.reviews.flatMap(r => r.reviewText.split(' ')).filter(w => w.length > 5))]
  };

  const outputPath = path.join(__dirname, baseDir, 'knowledge_base.json');
  fs.writeFileSync(outputPath, JSON.stringify(knowledge, null, 2), 'utf-8');
  console.log('KnowledgeLearner updated knowledge base');
}

module.exports = { learnFromLogs };
