
// VoicePodcastAgent.js
// יוצר פודקאסטים חכמים מהתוכן שאתה מבקש

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const textToSpeech = require('@google-cloud/text-to-speech');
const client = new textToSpeech.TextToSpeechClient();

async function createPodcast(agentId, text, baseDir = '../agents') {
  const cleaned = text.trim().replace(/\s+/g, ' ');
  const chunks = cleaned.match(/[^.!?]{5,500}[.!?]/g) || [cleaned];

  const audioBuffers = [];
  for (const chunk of chunks) {
    const request = {
      input: { text: chunk },
      voice: { languageCode: 'he-IL', ssmlGender: 'MALE' },
      audioConfig: { audioEncoding: 'MP3' }
    };
    const [response] = await client.synthesizeSpeech(request);
    audioBuffers.push(response.audioContent);
  }

  const finalPath = path.join(__dirname, baseDir, agentId, 'logs', `podcast_${Date.now()}.mp3`);
  fs.writeFileSync(finalPath, Buffer.concat(audioBuffers), 'binary');
  console.log('Podcast saved for', agentId);
  return finalPath;
}

module.exports = { createPodcast };
