
// SoulFind.js
// איתור כלים לפי קטגוריה: AI, שיווק, טקסט, ניתוח

const fs = require('fs');
const path = require('path');

const toolLibrary = {
  "ai": ["ChatGPT", "Claude", "LLaMA", "Mistral", "Gemini"],
  "marketing": ["Canva", "Writesonic", "Copy.ai", "AdCreative", "Bannerbear"],
  "text": ["Grammarly", "Quillbot", "Hemingway", "TextCortex"],
  "data": ["Looker", "PowerBI", "Tableau", "BigQuery"],
};

function SoulFind(agentId, category, baseDir = '../agents') {
  const matches = toolLibrary[category.toLowerCase()] || ["No tools found"];
  const outputPath = path.join(__dirname, baseDir, agentId, 'outputs', `${category}_tools.json`);
  fs.writeFileSync(outputPath, JSON.stringify(matches, null, 2), 'utf-8');
  console.log('SoulFind results saved:', outputPath);
  return matches;
}

module.exports = SoulFind;
