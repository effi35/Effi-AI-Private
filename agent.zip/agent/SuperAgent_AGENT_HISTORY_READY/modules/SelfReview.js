
// SelfReview.js
// מאפשר לסוכן לכתוב לעצמו ביקורת עצמית על התוצאה שהפיק

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function SelfReview(agentId, resultText, baseDir = '../agents') {
  const settings = JSON.parse(fs.readFileSync(path.join(__dirname, baseDir, '..', 'config', 'settings.json'), 'utf-8'));
  const provider = settings.default_ai_provider;
  const prompt = `האם התוצאה הבאה עונה על הדרישות? האם יש מה לשפר? כתוב ביקורת עצמית מקצועית:

"${resultText}"`;

  let reply = '[SelfReview inactive]';
  if (provider === 'custom' && settings.custom_ai_url) {
    try {
      const res = await axios.post(settings.custom_ai_url, {
        messages: [{ role: "user", content: prompt }]
      });
      reply = res.data.response;
    } catch {}
  } else {
    try {
      const res = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: settings.default_model || 'gpt-4',
        messages: [{ role: "user", content: prompt }]
      }, {
        headers: { Authorization: `Bearer ${settings.openai_api_key}` }
      });
      reply = res.data.choices[0].message.content;
    } catch {}
  }

  const reviewPath = path.join(__dirname, baseDir, agentId, 'logs', `selfreview_${Date.now()}.txt`);
  fs.writeFileSync(reviewPath, reply, 'utf-8');
  console.log('SelfReview saved for', agentId);
  return reply;
}

module.exports = SelfReview;
