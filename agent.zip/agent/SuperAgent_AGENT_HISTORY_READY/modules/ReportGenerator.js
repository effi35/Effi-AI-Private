
// ReportGenerator.js
// יצירת דוח HTML מתוך קובץ תוצאה

const fs = require('fs');
const path = require('path');

function generateReport(agentId, baseDir = '../agents') {
  const resultPath = path.join(__dirname, baseDir, agentId, 'outputs', agentId + '_result.json');
  const reportPath = path.join(__dirname, baseDir, agentId, 'outputs', agentId + '_report.html');

  try {
    const data = JSON.parse(fs.readFileSync(resultPath, 'utf-8'));

    const html = `
      <html>
      <head><title>Agent ${agentId} Report</title></head>
      <body>
        <h1>Report for ${agentId}</h1>
        <ul>
          ${Object.entries(data).map(([key, val]) => `<li><b>${key}</b>: ${JSON.stringify(val)}</li>`).join('')}
        </ul>
      </body>
      </html>
    `;

    fs.writeFileSync(reportPath, html, 'utf-8');
    console.log('Report generated for agent:', agentId);
    return reportPath;
  } catch (err) {
    console.error('Failed to generate report:', err);
    return null;
  }
}

module.exports = generateReport;
