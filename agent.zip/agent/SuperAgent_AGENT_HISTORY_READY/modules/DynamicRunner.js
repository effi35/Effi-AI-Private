
// DynamicRunner.js
// רץ שלבים דינמיים עם אפשרות לדילוג, שינוי, או עצירה

const fs = require('fs');
const path = require('path');

async function DynamicRunner(agentId, tasks, baseDir = '../agents') {
  const agentPath = path.join(__dirname, baseDir, agentId);
  const logPath = path.join(agentPath, 'logs', 'activity.log');
  const outputPath = path.join(agentPath, 'outputs', agentId + '_result.json');
  const result = {};

  function log(step, status) {
    const line = new Date().toISOString() + ` | ${step} | ${status}\n`;
    fs.appendFileSync(logPath, line);
  }

  for (const task of tasks) {
    try {
      if (task.skip) {
        log(task.name, 'SKIPPED');
        continue;
      }

      if (task.overrideScript) {
        log(task.name, `OVERRIDDEN -> ${task.overrideScript}`);
        const mod = require(path.join(agentPath, 'scripts', task.overrideScript));
        result[task.name] = await mod(result);
      } else {
        const mod = require(path.join(agentPath, 'scripts', task.script));
        result[task.name] = await mod(result);
        log(task.name, 'DONE');
      }
    } catch (err) {
      log(task.name, 'FAILED: ' + err.message);
      if (task.abortOnFail) break;
    }
  }

  fs.writeFileSync(outputPath, JSON.stringify(result, null, 2), 'utf-8');
  return result;
}

module.exports = DynamicRunner;
