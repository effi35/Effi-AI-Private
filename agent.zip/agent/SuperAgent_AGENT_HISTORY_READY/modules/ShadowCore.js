
// ShadowCore.js
// חקירה והצלבת מקורות מידע חיצוניים

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function ShadowCore(agentId, keyword, sources = [], baseDir = '../agents') {
  const results = [];

  for (const source of sources) {
    try {
      const url = `${source}?q=${encodeURIComponent(keyword)}`;
      const res = await axios.get(url);
      results.push({ source, data: res.data });
    } catch (err) {
      results.push({ source, error: err.message });
    }
  }

  const outputPath = path.join(__dirname, baseDir, agentId, 'outputs', `${keyword}_shadow.json`);
  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2), 'utf-8');
  console.log('ShadowCore results saved:', outputPath);
  return results;
}

module.exports = ShadowCore;
