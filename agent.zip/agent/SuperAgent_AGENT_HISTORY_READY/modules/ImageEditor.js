
// ImageEditor.js
// סוכן לעריכת תמונות: הסרת רקע, שיפור צבעים, חידוד

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function editImage(agentId, imagePath, action = 'remove_background', baseDir = '../agents') {
  const imgData = fs.readFileSync(imagePath);
  const filename = path.basename(imagePath).replace(/\.(jpg|jpeg|png)/, '');
  const outName = `${action}_${filename}_${Date.now()}.png`;
  const outPath = path.join(__dirname, baseDir, agentId, 'logs', outName);

  try {
    if (action === 'remove_background') {
      const res = await axios.post('https://api.remove.bg/v1.0/removebg', imgData, {
        headers: {
          'X-Api-Key': process.env.REMOVE_BG_KEY,
          'Content-Type': 'application/octet-stream'
        },
        params: { size: 'auto' },
        responseType: 'arraybuffer'
      });
      fs.writeFileSync(outPath, res.data);
      return '[ImageEditor] רקע הוסר בהצלחה: ' + outName;
    } else {
      return '[ImageEditor] פעולה זו תתווסף בקרוב.';
    }
  } catch (err) {
    return '[ImageEditor] שגיאה בעריכת תמונה: ' + err.message;
  }
}

module.exports = { editImage };
