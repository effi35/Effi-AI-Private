
// FailTracker.js
// רושם כשלונות של סוכנים ומשמר ניתוח שגיאות

const fs = require('fs');
const path = require('path');

function logFailure(agentId, task, error, baseDir = '../agents') {
  const log = {
    agentId,
    task,
    error: error.message || error,
    timestamp: new Date().toISOString()
  };

  const logPath = path.join(__dirname, baseDir, agentId, 'logs', 'failures.json');
  let data = [];

  if (fs.existsSync(logPath)) {
    const existing = fs.readFileSync(logPath, 'utf-8');
    data = JSON.parse(existing);
  }

  data.push(log);
  fs.writeFileSync(logPath, JSON.stringify(data, null, 2), 'utf-8');
  console.log('FailTracker saved error for', agentId);
}

module.exports = { logFailure };
