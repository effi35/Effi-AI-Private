
// FlowMaster.js
// מחבר מספר סוכנים יחד לפעולה אוטומטית חכמה

const { analyzeCamera } = require('./AgentVision');
const { summarizeVideo } = require('./VideoSummarizer');
const { createDocument } = require('./DocWizard');
const { createExcel } = require('./ExcelGenius');
const { fetchPrivateData } = require('./AgentCustomBridge');
const { editImage } = require('./ImageEditor');
const { createClip } = require('./ClipCreator');
const { runDiagnostics } = require('./AgentFix');

async function runFlow(agentId, steps = []) {
  const results = [];

  for (const step of steps) {
    const { module, params } = step;
    try {
      let result = '[לא הוגדר]';
      if (module === 'AgentVision') result = await analyzeCamera(agentId, ...params);
      else if (module === 'VideoSummarizer') result = await summarizeVideo(agentId, ...params);
      else if (module === 'DocWizard') result = createDocument(agentId, ...params);
      else if (module === 'ExcelGenius') result = await createExcel(agentId, ...params);
      else if (module === 'AgentCustomBridge') result = await fetchPrivateData(agentId, ...params);
      else if (module === 'ImageEditor') result = await editImage(agentId, ...params);
      else if (module === 'ClipCreator') result = createClip(agentId, ...params);
      else if (module === 'AgentFix') result = runDiagnostics(agentId);

      results.push({ module, status: 'הושלם', output: result });
    } catch (err) {
      results.push({ module, status: 'שגיאה', error: err.message });
    }
  }

  return results;
}

module.exports = { runFlow };
