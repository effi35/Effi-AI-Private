
// ToneEngine.js
// מנתח את הטון הכללי של הפלט: חיובי, שלילי, נייטרלי

function analyzeTone(text) {
  const tone = {
    sentiment: 'neutral',
    keywords: []
  };

  const positiveWords = ['מדהים', 'מצוין', 'מעולה', 'טוב', 'נפלא', 'נהדר'];
  const negativeWords = ['גרוע', 'רע', 'כישלון', 'טעון שיפור', 'מאכזב'];

  const lower = text.toLowerCase();

  let pos = 0, neg = 0;
  positiveWords.forEach(word => { if (lower.includes(word)) { tone.keywords.push(word); pos++; } });
  negativeWords.forEach(word => { if (lower.includes(word)) { tone.keywords.push(word); neg++; } });

  if (pos > neg) tone.sentiment = 'positive';
  else if (neg > pos) tone.sentiment = 'negative';

  return tone;
}

module.exports = { analyzeTone };
