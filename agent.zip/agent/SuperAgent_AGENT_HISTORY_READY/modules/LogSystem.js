
// LogSystem.js
// שמירת לוגים לפי שלבים וזמנים

const fs = require('fs');
const path = require('path');

function log(agentId, message, baseDir = '../agents') {
  const logPath = path.join(__dirname, baseDir, agentId, 'logs', 'activity.log');
  const entry = new Date().toISOString() + ' - ' + message + '\n';

  try {
    fs.appendFileSync(logPath, entry, 'utf-8');
    console.log('Log saved for agent:', agentId);
  } catch (err) {
    console.error('Failed to write log:', err);
  }
}

module.exports = log;
