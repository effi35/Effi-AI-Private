
// MarketScanner.js
// קריאת מידע בורסאי בזמן אמת (לדוגמה דרך Yahoo Finance)

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function scanMarket(agentId, symbol, outputDir = '../agents') {
  const outputPath = path.join(__dirname, outputDir, agentId, 'outputs', `${symbol}_market.json`);
  const endpoint = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbol}`;

  try {
    const response = await axios.get(endpoint);
    const data = response.data.quoteResponse.result[0];

    fs.writeFileSync(outputPath, JSON.stringify(data, null, 2), 'utf-8');
    console.log('Market data saved:', outputPath);
    return data;
  } catch (err) {
    console.error('Failed to fetch market data:', err.message);
    return null;
  }
}

module.exports = scanMarket;
