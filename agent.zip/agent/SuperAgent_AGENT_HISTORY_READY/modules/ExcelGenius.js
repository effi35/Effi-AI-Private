
// ExcelGenius.js
// סוכן שיוצר קובצי Excel עם טבלאות ונוסחאות

const fs = require('fs');
const path = require('path');
const Excel = require('exceljs');

async function createExcel(agentId, sheetName = 'Data', rows = [], fileName = 'excel_report', baseDir = '../agents') {
  const workbook = new Excel.Workbook();
  const sheet = workbook.addWorksheet(sheetName);

  if (rows.length) {
    rows.forEach((row, idx) => {
      sheet.addRow(row);
    });
  }

  // נוסחה לדוגמה בסוף (אם יש נתונים מספריים)
  const colCount = rows[0]?.length || 0;
  if (colCount > 1 && rows.length > 1) {
    const totalRow = Array(colCount).fill('');
    totalRow[0] = 'סה״כ';
    totalRow[1] = { formula: `SUM(B2:B${rows.length})` };
    sheet.addRow(totalRow);
  }

  const outPath = path.join(__dirname, baseDir, agentId, 'logs', `${fileName}_${Date.now()}.xlsx`);
  await workbook.xlsx.writeFile(outPath);

  return '[ExcelGenius] קובץ Excel נוצר בהצלחה: ' + path.basename(outPath);
}

module.exports = { createExcel };
