
// ExecutionProfiler.js
// מנתח זמן ביצוע, שלבים, צווארי בקבוק

const fs = require('fs');
const path = require('path');

class ExecutionProfiler {
  constructor(agentId, taskName, baseDir = '../agents') {
    this.agentId = agentId;
    this.taskName = taskName;
    this.baseDir = baseDir;
    this.steps = [];
    this.startTime = Date.now();
  }

  markStep(label) {
    const now = Date.now();
    const last = this.steps.length ? this.steps[this.steps.length - 1].time : this.startTime;
    this.steps.push({ step: label, time: now, duration: now - last });
  }

  finish() {
    const total = Date.now() - this.startTime;
    const outputPath = path.join(__dirname, this.baseDir, this.agentId, 'logs', `${this.taskName}_profile.json`);
    const data = {
      agentId: this.agentId,
      task: this.taskName,
      totalTimeMs: total,
      steps: this.steps,
      timestamp: new Date().toISOString()
    };
    fs.writeFileSync(outputPath, JSON.stringify(data, null, 2), 'utf-8');
    console.log('ExecutionProfiler saved for', this.agentId);
  }
}

module.exports = ExecutionProfiler;
