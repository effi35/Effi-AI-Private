
// AgentSecrets.js
// ניהול סיסמאות מאובטח לפי משימה/שירות

const fs = require('fs');
const path = require('path');

function getSecret(key, baseDir = '../config') {
  const secrets = JSON.parse(fs.readFileSync(path.join(__dirname, baseDir, 'secrets.json'), 'utf-8'));
  return secrets[key] || null;
}

function getAccountCredentials(service, baseDir = '../config') {
  const secrets = JSON.parse(fs.readFileSync(path.join(__dirname, baseDir, 'secrets.json'), 'utf-8'));
  return secrets.accounts && secrets.accounts[service] ? secrets.accounts[service] : null;
}

module.exports = { getSecret, getAccountCredentials };
