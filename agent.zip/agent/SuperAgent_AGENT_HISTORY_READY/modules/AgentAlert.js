
// AgentAlert.js
// שליחת התרעות בזמן אמת

function sendAlert(message, type = 'sms') {
  console.log(`[AgentAlert] שולח ${type}: ${message}`);
  return true;
}

module.exports = { sendAlert };
