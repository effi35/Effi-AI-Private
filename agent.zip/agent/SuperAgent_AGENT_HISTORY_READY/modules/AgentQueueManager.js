
// AgentQueueManager.js
// ניהול תורים והרצות מקביליות של סוכנים

const { exec } = require('child_process');

class AgentQueueManager {
  constructor(concurrency = 5) {
    this.queue = [];
    this.running = 0;
    this.concurrency = concurrency;
  }

  addAgent(agentId, scriptPath) {
    this.queue.push({ agentId, scriptPath });
    this.runNext();
  }

  runNext() {
    if (this.running >= this.concurrency || this.queue.length === 0) return;

    const { agentId, scriptPath } = this.queue.shift();
    this.running++;

    console.log('Running agent:', agentId);

    exec(`node ${scriptPath}`, (error, stdout, stderr) => {
      if (error) console.error(`Agent ${agentId} error:`, error.message);
      else console.log(`Agent ${agentId} finished.`);
      this.running--;
      this.runNext();
    });
  }
}

module.exports = AgentQueueManager;
