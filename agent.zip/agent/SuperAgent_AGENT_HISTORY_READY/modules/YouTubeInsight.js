
// YouTubeInsight.js
// סוכן שסורק סרטון יוטיוב ומסכם את התוכן

const fs = require('fs');
const path = require('path');
const ytdl = require('ytdl-core');
const axios = require('axios');

async function summarizeYouTube(agentId, videoUrl, baseDir = '../agents') {
  const info = await ytdl.getInfo(videoUrl);
  const title = info.videoDetails.title;
  const description = info.videoDetails.description;

  let transcript = description;

  if (info.player_response && info.player_response.captions) {
    const captionTracks = info.player_response.captions.playerCaptionsTracklistRenderer.captionTracks;
    if (captionTracks.length) {
      const trackUrl = captionTracks[0].baseUrl;
      const captions = await axios.get(trackUrl);
      transcript = captions.data;
    }
  }

  const prompt = `סכם לי את תוכן הסרטון הבא בשם "${title}":
${transcript}`;
  const chatRes = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4',
    messages: [{ role: "user", content: prompt }]
  }, {
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  const summary = chatRes.data.choices[0].message.content;
  const outPath = path.join(__dirname, baseDir, agentId, 'logs', `youtube_summary_${Date.now()}.txt`);
  fs.writeFileSync(outPath, summary, 'utf-8');
  return summary;
}

module.exports = { summarizeYouTube };
