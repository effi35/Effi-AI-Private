
// SloganGenerator.js
// יוצר סלוגן באמצעות OpenAI ChatGPT

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function generateSlogan(agentId, topic, outputDir = '../agents') {
  const outputPath = path.join(__dirname, outputDir, agentId, 'outputs', 'slogan.txt');
  const endpoint = 'https://api.openai.com/v1/chat/completions';

  try {
    const response = await axios.post(endpoint, {
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'אתה כותב סלוגנים שיווקיים יצירתיים וקצרים מאוד.' },
        { role: 'user', content: `כתוב סלוגן מדויק בנושא: "${topic}"` }
      ]
    }, {
      headers: {
        'Authorization': 'Bearer YOUR_OPENAI_API_KEY',
        'Content-Type': 'application/json'
      }
    });

    const slogan = response.data.choices[0].message.content.trim();
    fs.writeFileSync(outputPath, slogan);
    console.log('Slogan saved:', outputPath);
    return slogan;
  } catch (err) {
    console.error('Failed to generate slogan:', err.message);
    return null;
  }
}

module.exports = generateSlogan;
