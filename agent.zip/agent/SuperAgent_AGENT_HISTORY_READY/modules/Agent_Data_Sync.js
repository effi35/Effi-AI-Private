
// Agent_Data_Sync.js
// כתיבה חיה של תוצאה בזמן ריצה

const fs = require('fs');
const path = require('path');

function syncData(agentId, key, value, baseDir = '../agents') {
  const resultPath = path.join(__dirname, baseDir, agentId, 'outputs', agentId + '_result.json');
  let data = {};

  try {
    if (fs.existsSync(resultPath)) {
      data = JSON.parse(fs.readFileSync(resultPath, 'utf-8'));
    }
  } catch (err) {
    console.error('Failed to load existing data:', err);
  }

  data[key] = value;

  try {
    fs.writeFileSync(resultPath, JSON.stringify(data, null, 2));
    console.log('Data synced for agent:', agentId);
  } catch (err) {
    console.error('Failed to write data:', err);
  }
}

module.exports = syncData;
