
// ImageCreator.js
// יוצר תמונה מתוך טקסט באמצעות OpenAI DALL·E

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function createImage(agentId, prompt, outputDir = '../agents') {
  const imagePath = path.join(__dirname, outputDir, agentId, 'outputs', 'generated_image.png');
  const endpoint = 'https://api.openai.com/v1/images/generations';

  try {
    const response = await axios.post(endpoint, {
      prompt: prompt,
      n: 1,
      size: '512x512'
    }, {
      headers: {
        'Authorization': 'Bearer YOUR_OPENAI_API_KEY',
        'Content-Type': 'application/json'
      }
    });

    const imageUrl = response.data.data[0].url;
    const imageResp = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    fs.writeFileSync(imagePath, imageResp.data);
    console.log('Image created and saved:', imagePath);
    return imagePath;
  } catch (err) {
    console.error('Failed to generate image:', err.message);
    return null;
  }
}

module.exports = createImage;
