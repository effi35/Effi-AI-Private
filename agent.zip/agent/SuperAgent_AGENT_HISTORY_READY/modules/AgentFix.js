
// AgentFix.js
// סוכן תיקון אוטומטי למחשב מבוסס Windows

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

function runDiagnostics(agentId, baseDir = '../agents') {
  const log = [];
  const timestamp = Date.now();
  const logPath = path.join(__dirname, baseDir, agentId, 'logs', `fix_report_${timestamp}.txt`);

  try {
    // בדיקת מצב רשת
    const ping = execSync('ping google.com -n 2').toString();
    log.push('בדיקת רשת:
' + ping);

    // ניקוי קבצים זמניים
    execSync('del /q/f/s %TEMP%\*');
    log.push('נוקו קבצים זמניים');

    // בדיקת שירותים פעילים
    const services = execSync('tasklist').toString();
    log.push('רשימת תהליכים:
' + services.slice(0, 800));

    // בדיקת עדכונים
    const updates = 'עדכוני מערכת יש לבדוק דרך הגדרות Windows'; // Placeholder
    log.push(updates);

    fs.writeFileSync(logPath, log.join('\n\n'), 'utf-8');
    return '[AgentFix] סריקה ותיקון בוצעו. דו״ח נשמר.';
  } catch (err) {
    const errorLog = '[AgentFix] שגיאה: ' + err.message;
    fs.writeFileSync(logPath, errorLog, 'utf-8');
    return errorLog;
  }
}

module.exports = { runDiagnostics };
