
// AgentCustomBridge.js
// מתחבר למערכות פרטיות לפי הגדרה אישית של המשתמש (API, DB, CSV)

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const mysql = require('mysql');

async function fetchPrivateData(agentId, config, baseDir = '../agents') {
  const logPath = path.join(__dirname, baseDir, agentId, 'logs', `custom_data_${Date.now()}.json`);
  let result = { success: false, data: null };

  try {
    if (config.type === 'api') {
      const res = await axios.get(config.url, {
        headers: config.headers || {},
        params: config.params || {}
      });
      result = { success: true, data: res.data };
    } else if (config.type === 'csv') {
      const csvData = fs.readFileSync(config.path, 'utf-8');
      result = { success: true, data: csvData };
    } else if (config.type === 'mysql') {
      const connection = mysql.createConnection(config.mysql);
      connection.connect();
      const query = config.mysql.query || 'SELECT * FROM sales';
      const rows = await new Promise((resolve, reject) => {
        connection.query(query, (err, results) => {
          if (err) reject(err);
          else resolve(results);
        });
      });
      connection.end();
      result = { success: true, data: rows };
    }
    fs.writeFileSync(logPath, JSON.stringify(result, null, 2), 'utf-8');
    return result;
  } catch (err) {
    result = { success: false, error: err.message };
    fs.writeFileSync(logPath, JSON.stringify(result, null, 2), 'utf-8');
    return result;
  }
}

module.exports = { fetchPrivateData };
