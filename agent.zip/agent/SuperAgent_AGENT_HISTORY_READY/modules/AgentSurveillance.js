
// AgentSurveillance.js
// שמירה ומעקב על מקור נתונים

function startSurveillance(taskName, sourceUrl) {
  console.log(`[AgentSurveillance] התחיל מעקב על ${taskName} דרך ${sourceUrl}`);
  return `[AgentSurveillance] שומר על ${taskName}`;
}

module.exports = { startSurveillance };
