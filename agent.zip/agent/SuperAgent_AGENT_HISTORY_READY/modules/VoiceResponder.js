
// VoiceResponder.js
// יוצר קול אנושי מהתשובה של הסוכן (TTS)

const textToSpeech = require('@google-cloud/text-to-speech');
const fs = require('fs');
const util = require('util');
const path = require('path');
const client = new textToSpeech.TextToSpeechClient();

async function speakResponse(agentId, text, baseDir = '../agents') {
  const request = {
    input: { text },
    voice: {
      languageCode: 'he-IL',
      ssmlGender: 'FEMALE'
    },
    audioConfig: {
      audioEncoding: 'MP3'
    }
  };

  const [response] = await client.synthesizeSpeech(request);
  const outPath = path.join(__dirname, baseDir, agentId, 'logs', `voice_${Date.now()}.mp3`);
  const writeFile = util.promisify(fs.writeFile);
  await writeFile(outPath, response.audioContent, 'binary');
  console.log('Voice response saved for', agentId);
  return outPath;
}

module.exports = { speakResponse };
