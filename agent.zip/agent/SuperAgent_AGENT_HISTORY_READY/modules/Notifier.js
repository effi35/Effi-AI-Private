
// Notifier.js
// שליחת הודעות ל-Webhook, Telegram או Email

const axios = require('axios');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

function Notifier(settingsPath = '../config/settings.json') {
  const settings = JSON.parse(fs.readFileSync(path.join(__dirname, settingsPath), 'utf-8'));

  async function notify({ method, message }) {
    if (method === 'webhook' && settings.webhook_url) {
      try {
        await axios.post(settings.webhook_url, { message });
        console.log('Webhook notification sent.');
      } catch (err) {
        console.error('Webhook failed:', err.message);
      }
    } else if (method === 'telegram' && settings.telegram_bot_token && settings.telegram_chat_id) {
      try {
        await axios.post(`https://api.telegram.org/bot${settings.telegram_bot_token}/sendMessage`, {
          chat_id: settings.telegram_chat_id,
          text: message
        });
        console.log('Telegram message sent.');
      } catch (err) {
        console.error('Telegram failed:', err.message);
      }
    } else if (method === 'email' && settings.email_to) {
      try {
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: settings.email_from,
            pass: settings.email_password
          }
        });

        await transporter.sendMail({
          from: settings.email_from,
          to: settings.email_to,
          subject: 'Agent Notification',
          html: `<p>${message}</p>`
        });
        console.log('Email sent.');
      } catch (err) {
        console.error('Email failed:', err.message);
      }
    }
  }

  return { notify };
}

module.exports = Notifier;
