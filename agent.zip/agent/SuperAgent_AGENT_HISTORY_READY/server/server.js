const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const AgentMonitor = require('./modules/agent_monitor');
const activeMonitors = {};

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

const agentConfigPath = path.join(__dirname, 'config', 'agent_config.json');
let agentConfig = require(agentConfigPath);

function startMonitorsForAgents() {
  const agentsDataPath = path.join(__dirname, 'config', 'agent_config.json');
  const agents = JSON.parse(fs.readFileSync(agentsDataPath, 'utf8'));

  agents.forEach(agent => {
    if (!activeMonitors[agent.id]) {
      const monitor = new AgentMonitor(agent.id);
      monitor.startMonitoring();
      activeMonitors[agent.id] = monitor;
      console.log(`Started monitor for agent ${agent.name}`);
    }
  });
}

startMonitorsForAgents();

// שליחת מייל רגילה
app.post('/send-email', async (req, res) => {
  const { subject, text } = req.body;

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'aifi.trader.bot@gmail.com',
        pass: 'vfdj yedl gmnn zexj'
      }
    });

    await transporter.sendMail({
      from: '"AI Agent" <aifi.trader.bot@gmail.com>',
      to: 'effi35@gmail.com',
      subject,
      text
    });

    res.json({ status: 'Email sent successfully!' });
  } catch (error) {
    console.error('Failed to send email:', error);
    res.status(500).json({ status: 'Failed to send email', error: error.message });
  }
});

app.post('/create-agent', (req, res) => {
  const { mode } = req.body;
  let agentSettings = {};

  if (mode === 'simple') {
    agentSettings = agentConfig.default_agent;
  } else if (mode === 'extended') {
    agentSettings = agentConfig.advanced_agent;
  } else {
    return res.status(400).json({ status: 'Invalid agent mode!' });
  }

  const agentResult = {
    agent_id: `agent_${Date.now()}`,
    config: agentSettings,
    status: 'created',
    created_at: new Date()
  };

  const savePath = path.join(__dirname, 'agents', `${agentResult.agent_id}.json`);
  fs.writeFileSync(savePath, JSON.stringify(agentResult, null, 2));

  res.json({ status: 'Agent created', agent: agentResult });
});

app.get('/ping', (req, res) => {
  res.json({ status: 'pong', timestamp: new Date() });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

app.get('/api/agents', (req, res) => {
  try {
    const agentsData = fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8');
    const agents = JSON.parse(agentsData);
    res.json(agents);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error reading agents' });
  }
});

app.delete('/api/agents/:id', (req, res) => {
  try {
    const agentId = req.params.id;
    const agentsData = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8'));
    const updatedAgents = agentsData.filter(agent => agent.id !== agentId);

    fs.writeFileSync(path.join(__dirname, 'config', 'agent_config.json'), JSON.stringify(updatedAgents, null, 2));
    res.status(200).send('Agent deleted.');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error deleting agent.');
  }
});

app.post('/api/agents/:id/send', (req, res) => {
  try {
    const agentId = req.params.id;
    const agentsData = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'agent_config.json'), 'utf8'));
    const agent = agentsData.find(a => a.id === agentId);

    if (!agent) return res.status(404).send('Agent not found');

    const resultPath = path.join(__dirname, 'agents', 'results', `${agentId}.json`);
    if (!fs.existsSync(resultPath)) return res.status(404).send('Result not found');

    const resultContent = fs.readFileSync(resultPath, 'utf8');

    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'aifi.trader.bot@gmail.com',
        pass: 'vfdj yedl gmnn zexj'
      }
    });

    const mailOptions = {
      from: 'aifi.trader.bot@gmail.com',
      to: 'effi35@gmail.com',
      subject: `Agent ${agent.name} Result`,
      text: resultContent
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Failed to send email.');
      }
      console.log('Email sent: ' + info.response);
      res.status(200).send('Email sent successfully.');
    });

  } catch (error) {
    console.error(error);
    res.status(500).send('Error sending result.');
  }
});

app.post('/run-agent-now/:id', (req, res) => {
  const agentId = req.params.id;
  const agentPath = path.join(__dirname, 'config', 'agent_config.json');
  const agents = JSON.parse(fs.readFileSync(agentPath, 'utf8'));

  const agent = agents.find(a => a.id === agentId);

  if (!agent) {
    return res.status(404).json({ message: 'Agent not found' });
  }

  agent.status = 'Running';
  fs.writeFileSync(agentPath, JSON.stringify(agents, null, 2));

  setTimeout(() => {
    const success = Math.random() > 0.2;
    agent.status = success ? 'Success' : 'Failed';

    const resultPath = path.join(__dirname, 'agents', 'results', `${agent.id}.json`);
    const resultData = {
      agentId: agent.id,
      status: agent.status,
      data: success ? "המשימה בוצעה בהצלחה!" : "המשימה נכשלה.",
      timestamp: new Date().toISOString()
    };
    fs.writeFileSync(resultPath, JSON.stringify(resultData, null, 2));
    fs.writeFileSync(agentPath, JSON.stringify(agents, null, 2));
  }, 5000);

  res.json({ message: 'הסוכן הופעל' });
});

app.get('/get-all-results', (req, res) => {
  const resultsFolder = path.join(__dirname, 'agents', 'results');
  const resultFiles = fs.readdirSync(resultsFolder);

  const allResults = resultFiles.map(file => {
    const content = fs.readFileSync(path.join(resultsFolder, file), 'utf8');
    return JSON.parse(content);
  });

  res.json(allResults);
});



// Socket.IO setup
const http = require('http').createServer(app);
const io = require('socket.io')(http);

http.listen(PORT, () => {
  console.log(`Server running with socket.io on port ${PORT}`);
});

// Emit live updates
function saveResultWithSocket(agentId, action, status, details) {
    const result = {
        agentId,
        action,
        status,
        details,
        timestamp: new Date().toISOString()
    };
    io.emit('new_action', result);
}



// === CREATE AGENT API ===
const fs = require('fs');
const path = require('path');

app.post('/api/create-agent', (req, res) => {
  const { name, description, extended, tasks } = req.body;
  const id = name.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();
  const agentDir = path.join(__dirname, '../agents/', id);
  const configDir = path.join(agentDir, 'configs');
  const scriptsDir = path.join(agentDir, 'scripts');
  const outputsDir = path.join(agentDir, 'outputs');
  const logsDir = path.join(agentDir, 'logs');

  // Ensure all directories exist
  [agentDir, configDir, scriptsDir, outputsDir, logsDir].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  // Build config
  const config = {
    agent_name: name,
    description,
    extended,
    tasks,
    created: new Date().toISOString(),
    status: "Pending"
  };

  // Save agent config file
  const configPath = path.join(configDir, `${id}_config.json`);
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');

  res.json({ success: true, agentId: id });
});



// === SEND EMAIL API ===
const nodemailer = require('nodemailer');

app.post('/send-email', async (req, res) => {
  const { subject, body, to } = req.body;
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'your_gmail_account@gmail.com',
      pass: 'your_gmail_password'
    }
  });

  const mailOptions = {
    from: 'SuperAgent <your_gmail_account@gmail.com>',
    to: to || 'admin@example.com',
    subject: subject || 'Super Agent Notification',
    html: `<p>${body}</p>`
  };

  try {
    await transporter.sendMail(mailOptions);
    res.json({ success: true });
  } catch (error) {
    console.error('Email send error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});



// === GET & SAVE Agent Result ===
const resultBase = path.join(__dirname, '../agents');

app.get('/get-agent-result/:agentId', (req, res) => {
  const agentId = req.params.agentId;
  const filePath = path.join(resultBase, agentId, 'outputs', agentId + '_result.json');
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      res.json(JSON.parse(content));
    } else {
      res.status(404).json({ error: 'Result not found' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error reading result file' });
  }
});

app.post('/save-agent-result/:agentId', (req, res) => {
  const agentId = req.params.agentId;
  const filePath = path.join(resultBase, agentId, 'outputs', agentId + '_result.json');
  try {
    fs.writeFileSync(filePath, JSON.stringify(req.body, null, 2), 'utf-8');
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Error saving result file' });
  }
});



const multer = require('multer');
const upload = multer({ dest: 'tmp/' });

app.post('/upload-file', upload.single('file'), (req, res) => {
  const agentId = req.body.agentId;
  const file = req.file;
  const dest = path.join(__dirname, '../agents', agentId, 'inputs', file.originalname);
  fs.renameSync(file.path, dest);
  res.json({ success: true, message: 'הקובץ נשמר לתיקיית הקלט של הסוכן.' });
});



const bodyParser = require('body-parser');
app.use(bodyParser.json());

const chatDir = path.join(__dirname, '../agents', 'default', 'chats');
if (!fs.existsSync(chatDir)) fs.mkdirSync(chatDir, { recursive: true });

app.post('/chat', async (req, res) => {
  const settings = JSON.parse(fs.readFileSync(path.join(__dirname, '../config/settings.json'), 'utf-8'));
  const provider = settings.default_ai_provider;
  const messages = req.body.messages || [];

  if (provider === 'custom' && settings.custom_ai_url) {
    try {
      const reply = await axios.post(settings.custom_ai_url, { messages });
      return res.json({ reply: reply.data.response });
    } catch (err) {
      return res.status(500).json({ error: 'Custom AI error' });
    }
  }

  // Default: OpenAI
  try {
    const reply = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: settings.default_model || 'gpt-4',
      messages
    }, {
      headers: { Authorization: `Bearer ${settings.openai_api_key}` }
    });

    return res.json({ reply: reply.data.choices[0].message.content });
  } catch (err) {
    return res.status(500).json({ error: 'OpenAI error' });
  }
});

app.post('/save-chat', (req, res) => {
  const chatLog = req.body.log;
  const filename = `chat_${Date.now()}.json`;
  const filepath = path.join(chatDir, filename);
  fs.writeFileSync(filepath, JSON.stringify(chatLog, null, 2), 'utf-8');
  res.json({ success: true });
});

app.get('/get-chat-history', (req, res) => {
  try {
    const files = fs.readdirSync(chatDir);
    res.json({ files });
  } catch {
    res.status(500).json({ files: [] });
  }
});
