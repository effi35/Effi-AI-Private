
const fs = require('fs');
const path = require('path');

class Agent {
  constructor(agentId) {
    this.agentId = agentId;
    this.config = this.loadAgentConfig();
    this.skills = this.config?.skills || [];
  }

  loadAgentConfig() {
    const configPath = path.join(__dirname, '../config/agent_config.json');
    const allAgents = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    return allAgents.find(agent => agent.id === this.agentId) || null;
  }

  describe() {
    return {
      id: this.agentId,
      name: this.config?.name || 'Unknown',
      description: this.config?.description || '',
      skills: this.skills,
      active: this.config?.active || false
    };
  }

  canRun(skill) {
    return this.skills.includes(skill);
  }

  run(skill) {
    if (!this.canRun(skill)) {
      return { error: `Agent ${this.agentId} cannot run skill: ${skill}` };
    }

    const modulePath = path.join(__dirname, '../modules', `${skill}.json`);
    if (!fs.existsSync(modulePath)) {
      return { error: `Skill module ${skill} not found.` };
    }

    const moduleData = JSON.parse(fs.readFileSync(modulePath, 'utf8'));
    return { result: moduleData };
  }
}

module.exports = Agent;
