function applyThemeColor(color) {
    document.documentElement.style.setProperty('--theme-color', color);
}
function setButtonDepth(depth) {
    document.documentElement.style.setProperty('--button-depth', depth + 'px');
}
function applyAnimation(effect) {
    document.body.className = '';
    if (effect !== 'none') {
        document.body.classList.add('animate-' + effect);
    }
}
function resetDefaults() {
    applyThemeColor('#2196f3');
    setButtonDepth(10);
    applyAnimation('none');
}
document.addEventListener('DOMContentLoaded', resetDefaults);
