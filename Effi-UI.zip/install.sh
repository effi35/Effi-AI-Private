#!/bin/bash
echo "מתקין את Effi-UI..."
mkdir -p /var/www/effi-ui
cp ui.html ui.css ui.js config.json /var/www/effi-ui/
echo "ההתקנה הושלמה. ניתן להטמיע את הממשק על ידי טעינת /var/www/effi-ui/ui.html"
