/**
 * Ultimate Communication Universe - Main JavaScript
 * מרכז התקשורת הסופי - JavaScript ראשי
 * 
 * @author shayAI
 * @version 1.0.0
 * @license MIT
 */

'use strict';

// ===== GLOBAL VARIABLES =====
const API_BASE_URL = window.location.origin;
const API_ENDPOINTS = {
    platforms: '/api/ultimate_communication/platforms',
    messages: '/api/ultimate_communication/messages',
    spam: '/api/ultimate_communication/spam',
    groups: '/api/ultimate_communication/groups',
    alerts: '/api/ultimate_communication/alerts',
    stats: '/api/ultimate_communication/stats',
    sync: '/api/ultimate_communication/sync'
};

// Application State
const AppState = {
    isLoaded: false,
    isOnline: navigator.onLine,
    currentTab: 'dashboard',
    platforms: new Map(),
    messages: [],
    notifications: [],
    settings: {
        rtl: true,
        notifications: true,
        sounds: true,
        autoSync: true,
        syncInterval: 60000 // 1 minute
    },
    stats: {
        totalMessages: 0,
        importantMessages: 0,
        spamBlocked: 0,
        platformsActive: 0
    }
};

// Event Emitter for custom events
class EventEmitter {
    constructor() {
        this.events = {};
    }

    on(event, callback) {
        if (!this.events[event]) {
            this.events[event] = [];
        }
        this.events[event].push(callback);
    }

    emit(event, data) {
        if (this.events[event]) {
            this.events[event].forEach(callback => callback(data));
        }
    }

    off(event, callback) {
        if (this.events[event]) {
            this.events[event] = this.events[event].filter(cb => cb !== callback);
        }
    }
}

const eventBus = new EventEmitter();

// ===== UTILITY FUNCTIONS =====

/**
 * Utility functions for common operations
 */
const Utils = {
    /**
     * Format date to Hebrew locale
     * @param {Date|string} date 
     * @returns {string}
     */
    formatDate(date) {
        const d = new Date(date);
        return d.toLocaleDateString('he-IL', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    },

    /**
     * Format time ago in Hebrew
     * @param {Date|string} date 
     * @returns {string}
     */
    timeAgo(date) {
        const now = new Date();
        const then = new Date(date);
        const diffMs = now - then;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);

        if (diffMins < 1) return 'עכשיו';
        if (diffMins < 60) return `לפני ${diffMins} דקות`;
        if (diffHours < 24) return `לפני ${diffHours} שעות`;
        if (diffDays < 7) return `לפני ${diffDays} ימים`;
        
        return this.formatDate(date);
    },

    /**
     * Debounce function calls
     * @param {Function} func 
     * @param {number} wait 
     * @returns {Function}
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Throttle function calls
     * @param {Function} func 
     * @param {number} limit 
     * @returns {Function}
     */
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    /**
     * Generate unique ID
     * @returns {string}
     */
    generateId() {
        return '_' + Math.random().toString(36).substr(2, 9);
    },

    /**
     * Safely parse JSON
     * @param {string} str 
     * @param {*} fallback 
     * @returns {*}
     */
    safeJsonParse(str, fallback = null) {
        try {
            return JSON.parse(str);
        } catch (e) {
            return fallback;
        }
    },

    /**
     * Format number with Hebrew numerals
     * @param {number} num 
     * @returns {string}
     */
    formatNumber(num) {
        return new Intl.NumberFormat('he-IL').format(num);
    },

    /**
     * Escape HTML characters
     * @param {string} text 
     * @returns {string}
     */
    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }
};

// ===== API MANAGER =====

/**
 * Handles all API communications
 */
class ApiManager {
    constructor() {
        this.baseUrl = API_BASE_URL;
        this.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
    }

    /**
     * Make API request
     * @param {string} url 
     * @param {Object} options 
     * @returns {Promise}
     */
    async request(url, options = {}) {
        try {
            const config = {
                method: 'GET',
                headers: this.headers,
                ...options
            };

            const response = await fetch(url, config);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data;

        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    /**
     * GET request
     * @param {string} endpoint 
     * @param {Object} params 
     * @returns {Promise}
     */
    async get(endpoint, params = {}) {
        const url = new URL(this.baseUrl + endpoint);
        Object.keys(params).forEach(key => 
            url.searchParams.append(key, params[key])
        );
        
        return this.request(url.toString());
    }

    /**
     * POST request
     * @param {string} endpoint 
     * @param {Object} data 
     * @returns {Promise}
     */
    async post(endpoint, data = {}) {
        return this.request(this.baseUrl + endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    /**
     * PUT request
     * @param {string} endpoint 
     * @param {Object} data 
     * @returns {Promise}
     */
    async put(endpoint, data = {}) {
        return this.request(this.baseUrl + endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    /**
     * DELETE request
     * @param {string} endpoint 
     * @returns {Promise}
     */
    async delete(endpoint) {
        return this.request(this.baseUrl + endpoint, {
            method: 'DELETE'
        });
    }
}

const api = new ApiManager();

// ===== NOTIFICATION MANAGER =====

/**
 * Handles notifications and alerts
 */
class NotificationManager {
    constructor() {
        this.permission = Notification.permission;
        this.queue = [];
        this.activeToasts = new Set();
    }

    /**
     * Request notification permission
     * @returns {Promise<string>}
     */
    async requestPermission() {
        if ('Notification' in window) {
            this.permission = await Notification.requestPermission();
            return this.permission;
        }
        return 'denied';
    }

    /**
     * Show system notification
     * @param {string} title 
     * @param {Object} options 
     * @returns {Notification|null}
     */
    showNotification(title, options = {}) {
        if (this.permission !== 'granted') {
            return null;
        }

        const notification = new Notification(title, {
            icon: 'assets/images/icons/notification-icon.png',
            badge: 'assets/images/icons/badge-icon.png',
            ...options
        });

        notification.onclick = () => {
            window.focus();
            notification.close();
        };

        return notification;
    }

    /**
     * Show toast notification
     * @param {string} message 
     * @param {string} type 
     * @param {number} duration 
     */
    showToast(message, type = 'info', duration = 5000) {
        const toastId = Utils.generateId();
        const toast = this.createToastElement(message, type, toastId);
        
        document.body.appendChild(toast);
        this.activeToasts.add(toastId);

        // Show toast
        setTimeout(() => {
            toast.classList.add('show');
        }, 100);

        // Auto hide
        if (duration > 0) {
            setTimeout(() => {
                this.hideToast(toastId);
            }, duration);
        }

        return toastId;
    }

    /**
     * Create toast element
     * @param {string} message 
     * @param {string} type 
     * @param {string} id 
     * @returns {HTMLElement}
     */
    createToastElement(message, type, id) {
        const toast = document.createElement('div');
        toast.className = `notification-toast ${type}`;
        toast.setAttribute('data-toast-id', id);

        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };

        toast.innerHTML = `
            <div class="toast-content">
                <i class="toast-icon ${icons[type] || icons.info}"></i>
                <div class="toast-message">${Utils.escapeHtml(message)}</div>
                <button class="toast-close" onclick="notificationManager.hideToast('${id}')">&times;</button>
            </div>
        `;

        return toast;
    }

    /**
     * Hide toast notification
     * @param {string} toastId 
     */
    hideToast(toastId) {
        const toast = document.querySelector(`[data-toast-id="${toastId}"]`);
        if (toast) {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
                this.activeToasts.delete(toastId);
            }, 300);
        }
    }

    /**
     * Clear all toasts
     */
    clearAllToasts() {
        this.activeToasts.forEach(toastId => {
            this.hideToast(toastId);
        });
    }
}

const notificationManager = new NotificationManager();

// ===== LOADING MANAGER =====

/**
 * Handles loading states and progress
 */
class LoadingManager {
    constructor() {
        this.isLoading = false;
        this.progress = 0;
        this.loadingElement = document.getElementById('loadingScreen');
        this.progressElement = document.getElementById('loadingProgress');
        this.textElement = document.getElementById('loadingText');
    }

    /**
     * Show loading screen
     * @param {string} text 
     */
    show(text = 'טוען...') {
        if (this.loadingElement) {
            this.loadingElement.style.display = 'flex';
            this.isLoading = true;
            
            if (this.textElement && text) {
                this.textElement.textContent = text;
            }
        }
    }

    /**
     * Hide loading screen
     */
    hide() {
        if (this.loadingElement) {
            this.loadingElement.style.display = 'none';
            this.isLoading = false;
            this.progress = 0;
        }
    }

    /**
     * Update loading progress
     * @param {number} percent 
     * @param {string} text 
     */
    updateProgress(percent, text = '') {
        this.progress = Math.max(0, Math.min(100, percent));
        
        if (this.progressElement) {
            this.progressElement.style.width = `${this.progress}%`;
        }
        
        if (this.textElement && text) {
            this.textElement.textContent = text;
        }
    }

    /**
     * Set loading text
     * @param {string} text 
     */
    setText(text) {
        if (this.textElement) {
            this.textElement.textContent = text;
        }
    }
}

const loadingManager = new LoadingManager();

// ===== TAB MANAGER =====

/**
 * Handles tab navigation
 */
class TabManager {
    constructor() {
        this.currentTab = 'dashboard';
        this.tabs = new Map();
        this.init();
    }

    /**
     * Initialize tab manager
     */
    init() {
        // Register tab buttons
        document.querySelectorAll('.nav-tab').forEach(tab => {
            const tabId = tab.getAttribute('data-tab');
            this.tabs.set(tabId, {
                button: tab,
                content: document.getElementById(tabId + 'Content'),
                active: tab.classList.contains('active')
            });

            tab.addEventListener('click', () => this.switchTab(tabId));
        });

        // Set initial active tab
        this.switchTab(this.currentTab);
    }

    /**
     * Switch to a tab
     * @param {string} tabId 
     */
    switchTab(tabId) {
        if (!this.tabs.has(tabId)) {
            console.warn(`Tab ${tabId} not found`);
            return;
        }

        // Deactivate all tabs
        this.tabs.forEach((tab, id) => {
            tab.button.classList.remove('active');
            if (tab.content) {
                tab.content.classList.remove('active');
            }
        });

        // Activate selected tab
        const selectedTab = this.tabs.get(tabId);
        selectedTab.button.classList.add('active');
        if (selectedTab.content) {
            selectedTab.content.classList.add('active');
        }

        this.currentTab = tabId;

        // Emit tab change event
        eventBus.emit('tabChanged', { tabId, tab: selectedTab });

        // Load tab content if needed
        this.loadTabContent(tabId);
    }

    /**
     * Load tab content
     * @param {string} tabId 
     */
    async loadTabContent(tabId) {
        try {
            switch (tabId) {
                case 'dashboard':
                    await this.loadDashboard();
                    break;
                case 'messages':
                    await this.loadMessages();
                    break;
                case 'platforms':
                    await this.loadPlatforms();
                    break;
                case 'spam':
                    await this.loadSpamManagement();
                    break;
                case 'groups':
                    await this.loadGroups();
                    break;
                case 'alerts':
                    await this.loadAlerts();
                    break;
            }
        } catch (error) {
            console.error(`Error loading tab ${tabId}:`, error);
            notificationManager.showToast(`שגיאה בטעינת ${tabId}`, 'error');
        }
    }

    /**
     * Load dashboard content
     */
    async loadDashboard() {
        const statsData = await api.get(API_ENDPOINTS.stats);
        if (statsData.success) {
            this.updateDashboardStats(statsData.stats);
        }

        const recentMessages = await api.get(API_ENDPOINTS.messages, { 
            important_only: true, 
            limit: 5 
        });
        if (recentMessages.success) {
            this.updateRecentMessages(recentMessages.messages);
        }

        const platformsData = await api.get(API_ENDPOINTS.platforms);
        if (platformsData.success) {
            this.updatePlatformStatus(platformsData.platforms);
        }
    }

    /**
     * Update dashboard stats
     * @param {Object} stats 
     */
    updateDashboardStats(stats) {
        const elements = {
            totalMessages: document.getElementById('totalMessages'),
            importantMessages: document.getElementById('importantMessages'),
            spamBlocked: document.getElementById('spamBlocked'),
            platformsActive: document.getElementById('platformsActive')
        };

        Object.keys(elements).forEach(key => {
            if (elements[key] && stats[key] !== undefined) {
                this.animateNumber(elements[key], stats[key]);
            }
        });

        AppState.stats = { ...AppState.stats, ...stats };
    }

    /**
     * Animate number change
     * @param {HTMLElement} element 
     * @param {number} targetValue 
     */
    animateNumber(element, targetValue) {
        const startValue = parseInt(element.textContent) || 0;
        const duration = 1000;
        const steps = 60;
        const stepValue = (targetValue - startValue) / steps;
        let currentStep = 0;

        const timer = setInterval(() => {
            currentStep++;
            const currentValue = Math.round(startValue + (stepValue * currentStep));
            element.textContent = Utils.formatNumber(currentValue);

            if (currentStep >= steps) {
                clearInterval(timer);
                element.textContent = Utils.formatNumber(targetValue);
            }
        }, duration / steps);
    }

    /**
     * Update recent messages
     * @param {Array} messages 
     */
    updateRecentMessages(messages) {
        const container = document.getElementById('recentImportantMessages');
        if (!container) return;

        if (messages.length === 0) {
            container.innerHTML = `
                <div class="no-messages">
                    <i class="fas fa-inbox"></i>
                    <p>אין הודעות חשובות חדשות</p>
                </div>
            `;
            return;
        }

        container.innerHTML = messages.map(message => `
            <div class="message-item" data-message-id="${message.id}">
                <div class="message-platform" style="background: ${this.getPlatformColor(message.platform)}">
                    <i class="${this.getPlatformIcon(message.platform)}"></i>
                </div>
                <div class="message-content">
                    <div class="message-sender">${Utils.escapeHtml(message.sender)}</div>
                    <div class="message-subject">${Utils.escapeHtml(message.subject)}</div>
                </div>
                <div class="message-time">${Utils.timeAgo(message.timestamp)}</div>
            </div>
        `).join('');
    }

    /**
     * Get platform color
     * @param {string} platform 
     * @returns {string}
     */
    getPlatformColor(platform) {
        const colors = {
            gmail: '#ea4335',
            outlook: '#0078d4',
            yahoo: '#6001d2',
            whatsapp: '#25d366',
            telegram: '#0088cc',
            facebook: '#1877f2',
            instagram: '#e4405f',
            default: '#667eea'
        };
        return colors[platform.toLowerCase()] || colors.default;
    }

    /**
     * Get platform icon
     * @param {string} platform 
     * @returns {string}
     */
    getPlatformIcon(platform) {
        const icons = {
            gmail: 'fas fa-envelope',
            outlook: 'fas fa-envelope',
            yahoo: 'fas fa-envelope',
            whatsapp: 'fab fa-whatsapp',
            telegram: 'fab fa-telegram',
            facebook: 'fab fa-facebook',
            instagram: 'fab fa-instagram',
            default: 'fas fa-envelope'
        };
        return icons[platform.toLowerCase()] || icons.default;
    }

    /**
     * Update platform status
     * @param {Array} platforms 
     */
    updatePlatformStatus(platforms) {
        const container = document.getElementById('platformsGrid');
        if (!container) return;

        container.innerHTML = platforms.slice(0, 8).map(platform => `
            <div class="platform-item ${platform.status}" data-platform="${platform.name}">
                <div class="platform-icon">
                    <i class="${this.getPlatformIcon(platform.name)}"></i>
                </div>
                <div class="platform-name">${Utils.escapeHtml(platform.display_name)}</div>
                <div class="platform-status">${this.getStatusText(platform.status)}</div>
            </div>
        `).join('');
    }

    /**
     * Get status text in Hebrew
     * @param {string} status 
     * @returns {string}
     */
    getStatusText(status) {
        const statusTexts = {
            connected: 'מחובר',
            disconnected: 'מנותק',
            connecting: 'מתחבר',
            error: 'שגיאה'
        };
        return statusTexts[status] || status;
    }

    /**
     * Load messages tab
     */
    async loadMessages() {
        const messages = await api.get(API_ENDPOINTS.messages, { limit: 50 });
        if (messages.success) {
            this.renderMessages(messages.messages);
            this.updateMessagesBadge(messages.total);
        }
    }

    /**
     * Render messages list
     * @param {Array} messages 
     */
    renderMessages(messages) {
        const container = document.getElementById('messagesList');
        if (!container) return;

        if (messages.length === 0) {
            container.innerHTML = `
                <div class="no-messages">
                    <i class="fas fa-inbox"></i>
                    <p>אין הודעות</p>
                </div>
            `;
            return;
        }

        container.innerHTML = messages.map(message => `
            <div class="message-item ${message.is_read ? '' : 'unread'}" data-message-id="${message.id}">
                <div class="message-platform" style="background: ${this.getPlatformColor(message.platform)}">
                    <i class="${this.getPlatformIcon(message.platform)}"></i>
                </div>
                <div class="message-content">
                    <div class="message-sender">${Utils.escapeHtml(message.sender)}</div>
                    <div class="message-subject">${Utils.escapeHtml(message.subject)}</div>
                    <div class="message-preview">${Utils.escapeHtml(message.content.substring(0, 100))}...</div>
                </div>
                <div class="message-meta">
                    <div class="message-time">${Utils.timeAgo(message.timestamp)}</div>
                    <div class="message-importance">
                        ${message.importance_score >= 70 ? '<i class="fas fa-star text-warning"></i>' : ''}
                        ${message.is_spam ? '<i class="fas fa-ban text-error"></i>' : ''}
                    </div>
                </div>
            </div>
        `).join('');

        // Add click handlers
        container.querySelectorAll('.message-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const messageId = item.getAttribute('data-message-id');
                this.openMessage(messageId);
            });
        });
    }

    /**
     * Update messages badge
     * @param {number} count 
     */
    updateMessagesBadge(count) {
        const badge = document.getElementById('messagesBadge');
        if (badge) {
            badge.textContent = Utils.formatNumber(count);
            badge.style.display = count > 0 ? 'flex' : 'none';
        }
    }

    /**
     * Open message details
     * @param {string} messageId 
     */
    openMessage(messageId) {
        // TODO: Implement message details modal
        console.log('Opening message:', messageId);
    }

    /**
     * Load platforms tab
     */
    async loadPlatforms() {
        const platforms = await api.get(API_ENDPOINTS.platforms);
        if (platforms.success) {
            this.renderPlatforms(platforms.platforms);
        }
    }

    /**
     * Render platforms by category
     * @param {Array} platforms 
     */
    renderPlatforms(platforms) {
        const categories = {
            email: document.getElementById('emailPlatforms'),
            social: document.getElementById('socialPlatforms'),
            messaging: document.getElementById('messagingPlatforms'),
            utility: document.getElementById('utilityPlatforms')
        };

        // Group platforms by type
        const groupedPlatforms = platforms.reduce((acc, platform) => {
            if (!acc[platform.type]) acc[platform.type] = [];
            acc[platform.type].push(platform);
            return acc;
        }, {});

        // Render each category
        Object.keys(categories).forEach(category => {
            const container = categories[category];
            const platformsList = groupedPlatforms[category] || [];

            if (container) {
                container.innerHTML = platformsList.map(platform => `
                    <div class="platform-item ${platform.status}" data-platform="${platform.name}">
                        <div class="platform-icon">
                            <i class="${this.getPlatformIcon(platform.name)}"></i>
                        </div>
                        <div class="platform-name">${Utils.escapeHtml(platform.display_name)}</div>
                        <div class="platform-status">${this.getStatusText(platform.status)}</div>
                        <div class="platform-actions">
                            <button class="btn-sm ${platform.enabled ? 'btn-success' : 'btn-secondary'}" 
                                    onclick="platformManager.togglePlatform('${platform.name}')">
                                ${platform.enabled ? 'פעיל' : 'מושבת'}
                            </button>
                        </div>
                    </div>
                `).join('');
            }
        });
    }

    /**
     * Load spam management tab
     */
    async loadSpamManagement() {
        // TODO: Implement spam management loading
        console.log('Loading spam management...');
    }

    /**
     * Load groups tab
     */
    async loadGroups() {
        // TODO: Implement groups loading
        console.log('Loading groups...');
    }

    /**
     * Load alerts tab
     */
    async loadAlerts() {
        // TODO: Implement alerts loading
        console.log('Loading alerts...');
    }
}

// ===== SYNC MANAGER =====

/**
 * Handles data synchronization
 */
class SyncManager {
    constructor() {
        this.isRunning = false;
        this.interval = null;
        this.lastSync = null;
    }

    /**
     * Start auto sync
     */
    start() {
        if (this.isRunning) return;

        this.isRunning = true;
        this.syncNow();
        
        this.interval = setInterval(() => {
            this.syncNow();
        }, AppState.settings.syncInterval);

        console.log('Sync manager started');
    }

    /**
     * Stop auto sync
     */
    stop() {
        if (!this.isRunning) return;

        this.isRunning = false;
        
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }

        console.log('Sync manager stopped');
    }

    /**
     * Perform immediate sync
     */
    async syncNow() {
        try {
            this.updateSyncStatus('מסנכרן...');
            
            const result = await api.post(API_ENDPOINTS.sync);
            
            if (result.success) {
                this.lastSync = new Date();
                this.updateSyncStatus('מסונכרן');
                
                // Emit sync complete event
                eventBus.emit('syncComplete', result);
                
                // Update current tab if needed
                if (tabManager.currentTab === 'dashboard') {
                    tabManager.loadDashboard();
                }
            } else {
                throw new Error(result.error || 'Sync failed');
            }
            
        } catch (error) {
            console.error('Sync error:', error);
            this.updateSyncStatus('שגיאה בסנכרון');
            notificationManager.showToast('שגיאה בסנכרון נתונים', 'error');
        }
    }

    /**
     * Update sync status display
     * @param {string} status 
     */
    updateSyncStatus(status) {
        const statusElement = document.getElementById('syncText');
        const iconElement = document.querySelector('#syncStatus .status-icon');
        
        if (statusElement) {
            statusElement.textContent = status;
        }
        
        if (iconElement) {
            iconElement.className = status === 'מסנכרן...' ? 
                'fas fa-sync-alt status-icon spinning' : 
                'fas fa-sync-alt status-icon';
        }
    }
}

// ===== GLOBAL INSTANCES =====
let tabManager;
let syncManager;

// ===== APPLICATION INITIALIZATION =====

/**
 * Initialize the application
 */
async function initializeApp() {
    try {
        loadingManager.show('מאתחל את המערכת...');
        loadingManager.updateProgress(10, 'טוען הגדרות...');

        // Load settings
        await loadSettings();
        loadingManager.updateProgress(25, 'מאתחל רכיבים...');

        // Initialize managers
        tabManager = new TabManager();
        syncManager = new SyncManager();
        loadingManager.updateProgress(50, 'מתחבר לשרתים...');

        // Setup event listeners
        setupEventListeners();
        loadingManager.updateProgress(75, 'טוען נתונים ראשוניים...');

        // Initial data load
        await loadInitialData();
        loadingManager.updateProgress(90, 'מסיים הכנות...');

        // Start sync manager
        if (AppState.settings.autoSync) {
            syncManager.start();
        }

        loadingManager.updateProgress(100, 'מסיים...');
        
        // Hide loading screen
        setTimeout(() => {
            loadingManager.hide();
            document.getElementById('app').style.display = 'block';
            AppState.isLoaded = true;
            
            // Show welcome notification
            notificationManager.showToast('מערכת התקשורת הסופית מוכנה לשימוש!', 'success');
        }, 500);

    } catch (error) {
        console.error('App initialization failed:', error);
        loadingManager.hide();
        notificationManager.showToast('שגיאה באתחול המערכת', 'error');
    }
}

/**
 * Load application settings
 */
async function loadSettings() {
    try {
        const saved = localStorage.getItem('ultimateCommunicationSettings');
        if (saved) {
            const settings = Utils.safeJsonParse(saved, {});
            AppState.settings = { ...AppState.settings, ...settings };
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

/**
 * Save application settings
 */
function saveSettings() {
    try {
        localStorage.setItem('ultimateCommunicationSettings', JSON.stringify(AppState.settings));
    } catch (error) {
        console.error('Error saving settings:', error);
    }
}

/**
 * Load initial data
 */
async function loadInitialData() {
    try {
        // Load basic stats
        const stats = await api.get(API_ENDPOINTS.stats);
        if (stats.success) {
            AppState.stats = stats.stats;
        }

        // Load platforms
        const platforms = await api.get(API_ENDPOINTS.platforms);
        if (platforms.success) {
            platforms.platforms.forEach(platform => {
                AppState.platforms.set(platform.name, platform);
            });
        }

    } catch (error) {
        console.error('Error loading initial data:', error);
    }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Online/offline status
    window.addEventListener('online', () => {
        AppState.isOnline = true;
        document.getElementById('connectionStatus').className = 'status-item online';
        document.getElementById('connectionText').textContent = 'מחובר';
        notificationManager.showToast('חיבור לאינטרנט נוצר', 'success');
    });

    window.addEventListener('offline', () => {
        AppState.isOnline = false;
        document.getElementById('connectionStatus').className = 'status-item offline';
        document.getElementById('connectionText').textContent = 'לא מחובר';
        notificationManager.showToast('חיבור לאינטרנט נפסק', 'warning');
    });

    // Button click handlers
    document.getElementById('refreshBtn')?.addEventListener('click', () => {
        if (syncManager) {
            syncManager.syncNow();
        }
    });

    document.getElementById('settingsBtn')?.addEventListener('click', () => {
        openSettingsModal();
    });

    document.getElementById('notificationBtn')?.addEventListener('click', () => {
        toggleNotificationsPanel();
    });

    // Quick action buttons
    document.getElementById('syncAllBtn')?.addEventListener('click', () => {
        if (syncManager) {
            syncManager.syncNow();
        }
    });

    document.getElementById('cleanSpamBtn')?.addEventListener('click', () => {
        runSpamCleaning();
    });

    document.getElementById('addPlatformBtn')?.addEventListener('click', () => {
        openAddPlatformModal();
    });

    document.getElementById('createGroupBtn')?.addEventListener('click', () => {
        openCreateGroupModal();
    });

    // Window events
    window.addEventListener('beforeunload', () => {
        saveSettings();
    });

    // Custom events
    eventBus.on('syncComplete', (data) => {
        console.log('Sync completed:', data);
    });

    eventBus.on('tabChanged', (data) => {
        console.log('Tab changed to:', data.tabId);
    });
}

/**
 * Open settings modal
 */
function openSettingsModal() {
    // TODO: Implement settings modal
    console.log('Opening settings modal...');
}

/**
 * Toggle notifications panel
 */
function toggleNotificationsPanel() {
    // TODO: Implement notifications panel
    console.log('Toggling notifications panel...');
}

/**
 * Run spam cleaning
 */
async function runSpamCleaning() {
    try {
        notificationManager.showToast('מתחיל ניקוי ספאם...', 'info');
        
        const result = await api.post(API_ENDPOINTS.spam + '/clean');
        
        if (result.success) {
            notificationManager.showToast(`ניקוי הושלם! נמחקו ${result.cleaned} הודעות ספאם`, 'success');
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        notificationManager.showToast('שגיאה בניקוי ספאם', 'error');
    }
}

/**
 * Open add platform modal
 */
function openAddPlatformModal() {
    // TODO: Implement add platform modal
    console.log('Opening add platform modal...');
}

/**
 * Open create group modal
 */
function openCreateGroupModal() {
    // TODO: Implement create group modal
    console.log('Opening create group modal...');
}

// ===== STARTUP =====

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Export for global access
window.UltimateCommunication = {
    AppState,
    api,
    notificationManager,
    loadingManager,
    tabManager,
    syncManager,
    eventBus,
    Utils
};