# 🚀 מרכז התקשורת הסופי - Ultimate Communication Universe

## 📝 תיאור כללי

**מרכז התקשורת הסופי** הוא מודול מתקדם למערכת Effi-AI Private המאפשר ניהול מאוחד של כל אמצעי התקשורת הדיגיטלית שלך. המערכת מרכזת בממשק אחד את כל תיבות הדואר, הרשתות החברתיות, אפליקציות ההודעות ושירותי החברות, עם יכולות מתקדמות של זיהוי ספאם, ניקוי אוטומטי וניהול קבוצות חכם.

## ✨ תכונות עיקריות

### 📧 ניהול דואר מאוחד
- **תמיכה בכל ספקי הדואר**: Gmail, Outlook, Yahoo, iCloud, IMAP/POP3
- **API מקוריים**: חיבור ישיר ל-Gmail API, Microsoft Graph API
- **סנכרון בזמן אמת**: עדכונים אוטומטיים כל דקה
- **תצוגה מאוחדת**: כל ההודעות במקום אחד

### 🌐 רשתות חברתיות
- **פלטפורמות מרכזיות**: Facebook, Instagram, WhatsApp, Telegram
- **פלטפורמות נוספות**: Twitter/X, LinkedIn, TikTok, YouTube
- **פלטפורמות מתקדמות**: Discord, Snapchat, Pinterest, Reddit
- **פלטפורמות עדכניות**: Threads, Mastodon, Bluesky

### 💬 אפליקציות הודעות
- **הודעות פרטיות**: WhatsApp, Telegram, Signal, Viber
- **הודעות עסקיות**: Slack, Microsoft Teams
- **הודעות מערכת**: SMS, MMS, RCS
- **הודעות בינלאומיות**: WeChat, Line

### 🏢 שירותי חברות
- **חברות שירות**: חשמל, גז, מים, אינטרנט, כבלים
- **שירותי סטרימינג**: Netflix, Disney+, Amazon Prime, Spotify
- **שירותים פיננסיים**: בנקים, חברות ביטוח, חברות אשראי
- **מודול מותאם**: יכולת להוסיף כל שירות או חברה

### 🤖 בינה מלאכותית מתקדמת
- **זיהוי ספאם**: אלגוריתמים מתקדמים לזיהוי הודעות זבל
- **ניתוח תוכן**: הבנת הקשר וחשיבות ההודעות
- **למידת מכונה**: הסתגלות להעדפות המשתמש
- **חיזוי חשיבות**: דירוג הודעות לפי רמת חשיבות

### 🧹 ניקוי ספאם אוטומטי
- **זיהוי חכם**: מנוע AI לזיהוי ספאם מדויק
- **הסרה אוטומטית**: הסרה מרשימות תפוצה באופן אוטומטי
- **כללים מותאמים**: יכולת להגדיר כללי סינון אישיים
- **רשימות לבנה ושחורה**: שליטה מלאה במי מקבל ומי לא

### 👥 ניהול קבוצות גמיש
- **סוגי קבוצות**: משפחה, עבודה, חברים, מותאם אישית
- **הרשאות מתקדמות**: שליטה מדויקת במי רואה מה
- **התראות קבוצתיות**: הודעות משותפות לכל הקבוצה
- **הגדרות אישיות**: כל חבר יכול להתאים לעצמו

### 🔔 מערכת התראות מתקדמת
- **סוגי התראות**: פופ-אפ, WhatsApp, צלילים, התראות מערכת
- **התראות מותאמות**: כל סוג הודעה עם התראה מיוחדת
- **לוח זמנים**: הגדרת שעות פעילות ומצב שקט
- **התראות דחיפות**: 10 רמות חשיבות לתעדוף

## 🛠️ דרישות מערכת

### מינימום
- **Python**: גרסה 3.8 ומעלה
- **זיכרון**: 512MB RAM
- **אחסון**: 1GB פנוי
- **רשת**: חיבור אינטרנט יציב

### מומלץ
- **Python**: גרסה 3.10 ומעלה
- **זיכרון**: 2GB RAM
- **אחסון**: 5GB פנוי
- **רשת**: חיבור אינטרנט מהיר ויציב

### תאימות
- **מערכות הפעלה**: Windows, macOS, Linux
- **דפדפנים**: Chrome, Firefox, Safari, Edge
- **מכשירים**: שולחן עבודה, מחשב נייד, טאבלט, נייד

## 📦 התקנה

### התקנה אוטומטית
```bash
# הורד את המודול
git clone https://github.com/your-repo/ultimate-communication-universe.git
cd ultimate-communication-universe

# הפעל את סקריפט ההתקנה
chmod +x install.sh
./install.sh
```

### התקנה ידנית
```bash
# התקן תלויות Python
pip install -r requirements.txt

# הפעל את המערכת
python module.py
```

### הגדרת שירותי API

#### Gmail API
1. עבור לקונסולת Google Cloud
2. צור פרויקט חדש או בחר פרויקט קיים
3. הפעל את Gmail API
4. צור אישורי OAuth 2.0
5. הורד את קובץ credentials.json

#### Microsoft Graph API
1. עבור לפורטל Azure
2. רשום אפליקציה חדשה
3. הגדר הרשאות Mail.Read
4. קבל את Application ID ו-Client Secret

#### Telegram Bot API
1. פתח שיחה עם @BotFather
2. צור בוט חדש עם הפקודה /newbot
3. קבל את ה-Bot Token

## 🚀 שימוש

### הפעלה ראשונה
1. הפעל את המערכת
2. פתח דפדפן וגש לכתובת `http://localhost:2020`
3. בצע הגדרה ראשונית של החשבונות
4. התחל לקבל התראות על הודעות חשובות

### הוספת פלטפורמה חדשה
1. לחץ על "הוסף פלטפורמה חדשה"
2. בחר את סוג הפלטפורמה
3. הזן את פרטי החיבור
4. אמת את החיבור
5. הגדר את העדפות הסינון

### יצירת קבוצה
1. עבור ללשונית "קבוצות"
2. לחץ "צור קבוצה חדשה"
3. בחר סוג קבוצה
4. הוסף חברים
5. הגדר הרשאות והתראות

### הגדרת כללי ספאם
1. עבור ללשונית "ניקוי ספאם"
2. לחץ "הגדרות ספאם"
3. הגדר סף זיהוי ספאם
4. הוסף כללים מותאמים
5. הגדר פעולות אוטומטיות

## 🔧 הגדרות מתקדמות

### קובץ הגדרות
המערכת משתמשת בקובץ `config/settings.json` לאחסון הגדרות:

```json
{
  "sync_interval": 60,
  "spam_threshold": 70,
  "auto_unsubscribe": true,
  "notification_sound": true,
  "rtl_support": true,
  "debug_mode": false,
  "max_platforms": 50,
  "backup_enabled": true
}
```

### משתני סביבה
```bash
export ULTIMATE_COMM_PORT=2020
export ULTIMATE_COMM_DEBUG=false
export ULTIMATE_COMM_LOG_LEVEL=INFO
```

### בסיס נתונים
המערכת משתמשת ב-SQLite כברירת מחדל. לשימוש במסד נתונים מתקדם יותר:

```python
DATABASE_CONFIG = {
    'type': 'postgresql',  # או 'mysql'
    'host': 'localhost',
    'port': 5432,
    'database': 'ultimate_comm',
    'username': 'user',
    'password': 'password'
}
```

## 🔒 אבטחה ופרטיות

### הצפנה
- **הצפנת נתונים**: AES-256 לכל הנתונים הרגישים
- **הצפנת תקשורת**: TLS 1.3 לכל התקשורת
- **אחסון סיסמאות**: שימוש ב-bcrypt לאחסון מוצפן

### פרטיות
- **אחסון מקומי**: כל הנתונים נשמרים במחשב שלך
- **אין שיתוף**: הנתונים לא נשלחים לשרתים חיצוניים
- **שליטה מלאה**: אתה שולט במי יכול לגשת למה

### הרשאות
- **מערכת הרשאות**: שליטה מדויקת במי יכול לעשות מה
- **תפקידים**: מנהל, חבר, צופה
- **הגבלות**: אפשרות להגביל גישה לפלטפורמות מסוימות

## 📊 ניטור וביצועים

### לוגים
המערכת יוצרת לוגים מפורטים:
- `logs/communication.log` - לוג כללי
- `logs/spam_cleaner.log` - לוג ניקוי ספאם
- `logs/platform_sync.log` - לוג סנכרון פלטפורמות

### מדדי ביצועים
- זמן תגובה ממוצע
- מספר הודעות שנעובדו
- אחוז דיוק זיהוי ספאם
- זמן זכירה של פלטפורמות

### התראות מערכת
- שימוש בזיכרון
- שימוש ב-CPU
- שימוש ברשת
- סטטוס פלטפורמות

## 🔄 גיבוי ושחזור

### גיבוי אוטומטי
```bash
# הפעלת גיבוי יומי
crontab -e
0 2 * * * /path/to/backup.sh
```

### שחזור נתונים
```bash
# שחזור מגיבוי
python restore.py --backup-file backup_2025_05_22.tar.gz
```

### סנכרון בין מכשירים
```bash
# ייצוא הגדרות
python export_settings.py --output settings_backup.json

# ייבוא הגדרות
python import_settings.py --input settings_backup.json
```

## 🛠️ פיתוח והרחבה

### הוספת פלטפורמה חדשה
```python
class NewPlatformConnector(PlatformConnector):
    def __init__(self, config):
        super().__init__(config)
        
    def connect(self):
        # לוגיקת החיבור
        pass
        
    def get_messages(self):
        # לוגיקת קבלת הודעות
        pass
```

### הוספת כלל ספאם
```python
spam_rule = SpamRule(
    rule_id="custom_rule_1",
    name="כלל מותאם",
    pattern=r"דפוס רגולרי",
    rule_type="regex",
    action="delete",
    score=80
)
```

### הוספת סוג התראה
```python
class CustomNotification(NotificationHandler):
    def send(self, message, recipients):
        # לוגיקת שליחת התראה מותאמת
        pass
```

## 🧪 בדיקות

### הפעלת בדיקות
```bash
# בדיקות יחידה
python -m pytest tests/unit/

# בדיקות אינטגרציה
python -m pytest tests/integration/

# בדיקות מקצה לקצה
python -m pytest tests/e2e/

# כל הבדיקות
python -m pytest
```

### בדיקות ביצועים
```bash
# בדיקת עומס
python performance_test.py --concurrent-users 100

# בדיקת זיכרון
python memory_test.py --duration 3600
```

## 📞 תמיכה ועזרה

### שאלות נפוצות
**ש: המערכת לא מקבלת הודעות מ-Gmail**
ת: בדוק שהגדרת נכון את ה-Gmail API והרשאות OAuth 2.0

**ש: איך להוסיף פלטפורמה שלא נתמכת?**
ת: השתמש במודול המותאם האישי או פתח issue ב-GitHub

**ש: המערכת צורכת הרבה זיכרון**
ת: הגדר את `sync_interval` לערך גבוה יותר ו-`max_platforms` לערך נמוך יותר

### קישורים שימושיים
- [תיעוד מלא](https://docs.ultimate-communication.app)
- [דוגמאות קוד](https://examples.ultimate-communication.app)
- [פורום קהילה](https://community.ultimate-communication.app)
- [דיווח על באגים](https://github.com/your-repo/issues)

## 🤝 תרומה לפרויקט

### איך לתרום
1. צור fork של הפרויקט
2. צור branch חדש: `git checkout -b feature/amazing-feature`
3. עשה commit לשינויים: `git commit -m 'Add amazing feature'`
4. דחף ל-branch: `git push origin feature/amazing-feature`
5. פתח Pull Request

### הנחיות תरומה
- כתוב קוד נקי ומתועד
- הוסף בדיקות לכל תכונה חדשה
- בצע בדיקות לפני שליחת PR
- עקוב אחר סטנדרטי הקוד

## 📄 רישיון

המודול מופץ תחת רישיון MIT. ראה את קובץ [LICENSE](LICENSE) לפרטים מלאים.

```
MIT License

Copyright (c) 2025 shayAI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 📝 היסטוריית גרסאות

### גרסה 1.0.0 (2025-05-22)
- 🎉 גרסה ראשונה יציבה
- ✅ תמיכה בכל ספקי הדואר הגדולים
- ✅ ניקוי ספאם אוטומטי
- ✅ ניהול קבוצות
- ✅ ממשק PWA מלא
- ✅ תמיכה מלאה בעברית ו-RTL

### תכניות עתידיות
- 🔜 תמיכה בפלטפורמות נוספות
- 🔜 בינה מלאכותית מתקדמת יותר
- 🔜 אפליקציות נייד מקוריות
- 🔜 סנכרון בין מכשירים
- 🔜 API חיצוני למפתחים

## 🙏 תודות

תודה מיוחדת לכל המפתחים והתורמים שעזרו ליצור את המודול הזה:
- צוות פיתוח Effi-AI Private
- קהילת המפתחים
- בודקי הבטא
- המשתמשים המסייעים בפיתוח

---

<div align="center">

**מרכז התקשורת הסופי - Ultimate Communication Universe**

*מודול מתקדם למערכת Effi-AI Private*

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PWA](https://img.shields.io/badge/PWA-enabled-green.svg)](https://web.dev/progressive-web-apps/)
[![RTL](https://img.shields.io/badge/RTL-Hebrew-blue.svg)](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Writing_Modes)

</div>