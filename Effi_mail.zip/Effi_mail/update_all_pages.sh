#!/bin/bash

# סקריפט לעדכון כל הדפים עם הניווט החדש
echo "🚀 מתחיל עדכון כל הדפים..."

# רשימת דפים לעדכון
pages=(
    "automation_workflows_advanced.html"
    "enterprise_command_center.html" 
    "live_connections_master.html"
    "dashboard_advanced.html"
    "smart_home_iot_advanced.html"
    "index.html"
    "machine_learning_advanced.html"
    "security_system_advanced.html"
    "ui_customization_advanced.html"
    "file_system_advanced.html"
    "modules_advanced.html"
    "backup_system_advanced.html"
    "connections_advanced.html"
    "blockchain_crypto_advanced.html"
    "chat_interface_advanced.html"
    "logs_system_advanced.html"
    "performance_monitoring_advanced.html"
    "animations_demo.html"
    "api_management_advanced.html"
    "data_analytics_bi_advanced.html"
    "physical_system_advanced.html"
    "system_settings_advanced.html"
    "unified_settings.html"
    "network_management_advanced.html"
    "ai_system_advanced.html"
)

# עדכון כל דף
for page in "${pages[@]}"; do
    echo "📝 מעדכן: $page"
    
    # הוספת CSS החדש
    sed -i 's|</css/global-theme.css">|</css/global-theme.css">\n    <link rel="stylesheet" href="/css/government-navigation.css">|g' "/root/Effi_ai_New/pages/$page"
    
    # הסרת כפתורי HOME ישנים
    sed -i '/home-button/,+4d' "/root/Effi_ai_New/pages/$page"
    sed -i '/חזור לעמוד הבית/,+4d' "/root/Effi_ai_New/pages/$page"
    sed -i '/חזור למרכז/,+4d' "/root/Effi_ai_New/pages/$page"
    
    # הוספת JavaScript החדש
    sed -i 's|</js/core-memory-system.js">|</js/core-memory-system.js">\n    <script src="/js/government-navigation.js"></script>|g' "/root/Effi_ai_New/pages/$page"
    
    echo "✅ $page עודכן"
done

echo "🎉 כל הדפים עודכנו בהצלחה!"
echo "🚀 המערכת מוכנה לשימוש עם 4 כפתורי ניווט קבועים בכל דף"