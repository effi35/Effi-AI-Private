/**
 * Ultimate Communication Universe - Service Worker
 * מרכז התקשורת הסופי - Service Worker
 * 
 * PWA functionality, offline support, and background sync
 * 
 * @author shayAI
 * @version 1.0.0
 */

const CACHE_NAME = 'ultimate-communication-v1.0.0';
const RUNTIME_CACHE = 'runtime-cache-v1.0.0';

// Files to cache for offline use
const STATIC_CACHE_FILES = [
    '/',
    '/index.html',
    '/css/ultimate_communication.css',
    '/css/animations.css',
    '/css/rtl_support.css',
    '/js/ultimate_communication.js',
    '/js/family_manager.js',
    '/js/spam_cleaner.js',
    '/js/platform_universe.js',
    '/js/pwa_support.js',
    '/manifest.json',
    '/assets/images/icons/icon-192x192.png',
    '/assets/images/icons/icon-512x512.png',
    '/assets/images/icons/favicon-32x32.png',
    '/assets/images/icons/favicon-16x16.png',
    '/assets/images/icons/apple-touch-icon.png',
    'https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700&display=swap',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

// API endpoints that should be cached
const API_CACHE_PATTERNS = [
    '/api/ultimate_communication/platforms',
    '/api/ultimate_communication/stats',
    '/api/ultimate_communication/messages'
];

// Network-first patterns (always try network first)
const NETWORK_FIRST_PATTERNS = [
    '/api/ultimate_communication/sync',
    '/api/ultimate_communication/spam/clean',
    '/api/ultimate_communication/alerts'
];

// ===== SERVICE WORKER EVENTS =====

/**
 * Service Worker Install Event
 * Pre-cache static assets
 */
self.addEventListener('install', event => {
    console.log('[SW] Installing service worker...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('[SW] Caching static assets...');
                return cache.addAll(STATIC_CACHE_FILES);
            })
            .then(() => {
                console.log('[SW] Static assets cached successfully');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('[SW] Error caching static assets:', error);
            })
    );
});

/**
 * Service Worker Activate Event
 * Clean up old caches
 */
self.addEventListener('activate', event => {
    console.log('[SW] Activating service worker...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(cacheName => {
                            return cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE;
                        })
                        .map(cacheName => {
                            console.log('[SW] Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        })
                );
            })
            .then(() => {
                console.log('[SW] Service worker activated');
                return self.clients.claim();
            })
    );
});

/**
 * Service Worker Fetch Event
 * Handle network requests with caching strategies
 */
self.addEventListener('fetch', event => {
    const request = event.request;
    const url = new URL(request.url);
    
    // Skip non-GET requests
    if (request.method !== 'GET') {
        return;
    }
    
    // Skip Chrome extension requests
    if (url.protocol === 'chrome-extension:') {
        return;
    }
    
    // Handle different types of requests
    if (url.pathname.startsWith('/api/')) {
        // API requests
        event.respondWith(handleApiRequest(request));
    } else if (isStaticAsset(request)) {
        // Static assets
        event.respondWith(handleStaticRequest(request));
    } else {
        // HTML pages
        event.respondWith(handlePageRequest(request));
    }
});

/**
 * Handle API requests with appropriate caching strategy
 */
async function handleApiRequest(request) {
    const url = new URL(request.url);
    const pathname = url.pathname;
    
    try {
        // Network-first for real-time data
        if (NETWORK_FIRST_PATTERNS.some(pattern => pathname.includes(pattern))) {
            return await networkFirst(request);
        }
        
        // Cache-first for relatively static data
        if (API_CACHE_PATTERNS.some(pattern => pathname.includes(pattern))) {
            return await cacheFirst(request);
        }
        
        // Default to network-only for other API requests
        return await fetch(request);
        
    } catch (error) {
        console.error('[SW] API request failed:', error);
        
        // Try to return cached response if available
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // Return offline response
        return new Response(
            JSON.stringify({
                success: false,
                error: 'Network unavailable',
                offline: true
            }),
            {
                status: 503,
                statusText: 'Service Unavailable',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
    }
}

/**
 * Handle static asset requests
 */
async function handleStaticRequest(request) {
    try {
        // Try cache first for static assets
        return await cacheFirst(request);
    } catch (error) {
        console.error('[SW] Static request failed:', error);
        
        // For critical assets, try network as fallback
        if (isCriticalAsset(request)) {
            try {
                const networkResponse = await fetch(request);
                if (networkResponse.ok) {
                    // Cache the response
                    const cache = await caches.open(RUNTIME_CACHE);
                    cache.put(request, networkResponse.clone());
                }
                return networkResponse;
            } catch (networkError) {
                console.error('[SW] Network fallback failed:', networkError);
            }
        }
        
        throw error;
    }
}

/**
 * Handle page requests
 */
async function handlePageRequest(request) {
    try {
        // Try network first for pages
        return await networkFirst(request);
    } catch (error) {
        console.error('[SW] Page request failed:', error);
        
        // Return cached index.html as fallback
        const cachedResponse = await caches.match('/index.html');
        if (cachedResponse) {
            return cachedResponse;
        }
        
        throw error;
    }
}

/**
 * Cache-first strategy
 */
async function cacheFirst(request) {
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
        // Update cache in background
        updateCacheInBackground(request);
        return cachedResponse;
    }
    
    // If not in cache, fetch from network
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
        // Cache the response
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
}

/**
 * Network-first strategy
 */
async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            // Cache successful responses
            const cache = await caches.open(RUNTIME_CACHE);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
        
    } catch (error) {
        // If network fails, try cache
        const cachedResponse = await caches.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        throw error;
    }
}

/**
 * Update cache in background
 */
function updateCacheInBackground(request) {
    fetch(request)
        .then(networkResponse => {
            if (networkResponse.ok) {
                return caches.open(RUNTIME_CACHE)
                    .then(cache => cache.put(request, networkResponse));
            }
        })
        .catch(error => {
            console.warn('[SW] Background cache update failed:', error);
        });
}

/**
 * Check if request is for a static asset
 */
function isStaticAsset(request) {
    const url = new URL(request.url);
    const pathname = url.pathname;
    
    return pathname.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)$/i);
}

/**
 * Check if asset is critical for app functionality
 */
function isCriticalAsset(request) {
    const url = new URL(request.url);
    const pathname = url.pathname;
    
    return pathname.includes('/css/') || 
           pathname.includes('/js/') || 
           pathname.includes('font');
}

// ===== BACKGROUND SYNC =====

/**
 * Background Sync Event
 * Handle sync when network is available
 */
self.addEventListener('sync', event => {
    console.log('[SW] Background sync triggered:', event.tag);
    
    if (event.tag === 'background-sync') {
        event.waitUntil(performBackgroundSync());
    } else if (event.tag === 'message-sync') {
        event.waitUntil(syncMessages());
    } else if (event.tag === 'spam-cleanup') {
        event.waitUntil(performSpamCleanup());
    }
});

/**
 * Perform background sync
 */
async function performBackgroundSync() {
    try {
        console.log('[SW] Performing background sync...');
        
        // Sync with server
        const response = await fetch('/api/ultimate_communication/sync', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                timestamp: Date.now(),
                source: 'service-worker'
            })
        });
        
        if (response.ok) {
            console.log('[SW] Background sync completed successfully');
            
            // Notify all clients
            const clients = await self.clients.matchAll();
            clients.forEach(client => {
                client.postMessage({
                    type: 'SYNC_COMPLETE',
                    data: { success: true }
                });
            });
        } else {
            throw new Error(`Sync failed with status: ${response.status}`);
        }
        
    } catch (error) {
        console.error('[SW] Background sync failed:', error);
        
        // Notify clients about failure
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'SYNC_FAILED',
                data: { error: error.message }
            });
        });
    }
}

/**
 * Sync messages in background
 */
async function syncMessages() {
    try {
        console.log('[SW] Syncing messages in background...');
        
        const response = await fetch('/api/ultimate_communication/messages/sync', {
            method: 'POST'
        });
        
        if (response.ok) {
            const data = await response.json();
            console.log('[SW] Messages synced:', data);
            
            // Show notification for important messages
            if (data.important_messages && data.important_messages.length > 0) {
                await showNotification(
                    'הודעות חשובות חדשות',
                    {
                        body: `יש לך ${data.important_messages.length} הודעות חשובות חדשות`,
                        icon: '/assets/images/icons/icon-192x192.png',
                        badge: '/assets/images/icons/badge-icon.png',
                        tag: 'important-messages',
                        actions: [
                            {
                                action: 'view',
                                title: 'צפה בהודעות',
                                icon: '/assets/images/icons/view-icon.png'
                            },
                            {
                                action: 'dismiss',
                                title: 'סגור',
                                icon: '/assets/images/icons/close-icon.png'
                            }
                        ]
                    }
                );
            }
        }
        
    } catch (error) {
        console.error('[SW] Message sync failed:', error);
    }
}

/**
 * Perform spam cleanup in background
 */
async function performSpamCleanup() {
    try {
        console.log('[SW] Performing spam cleanup...');
        
        const response = await fetch('/api/ultimate_communication/spam/auto-clean', {
            method: 'POST'
        });
        
        if (response.ok) {
            const data = await response.json();
            console.log('[SW] Spam cleanup completed:', data);
            
            // Show notification about cleanup results
            if (data.cleaned_count > 0) {
                await showNotification(
                    'ניקוי ספאם הושלם',
                    {
                        body: `נמחקו ${data.cleaned_count} הודעות ספאם`,
                        icon: '/assets/images/icons/icon-192x192.png',
                        tag: 'spam-cleanup'
                    }
                );
            }
        }
        
    } catch (error) {
        console.error('[SW] Spam cleanup failed:', error);
    }
}

// ===== PUSH NOTIFICATIONS =====

/**
 * Push Event
 * Handle push notifications
 */
self.addEventListener('push', event => {
    console.log('[SW] Push notification received:', event);
    
    let data = {};
    
    if (event.data) {
        try {
            data = event.data.json();
        } catch (error) {
            console.error('[SW] Error parsing push data:', error);
            data = { title: 'הודעה חדשה', body: event.data.text() };
        }
    }
    
    const options = {
        body: data.body || 'יש לך הודעה חדשה',
        icon: data.icon || '/assets/images/icons/icon-192x192.png',
        badge: data.badge || '/assets/images/icons/badge-icon.png',
        tag: data.tag || 'default',
        data: data.data || {},
        actions: data.actions || [
            {
                action: 'view',
                title: 'צפה',
                icon: '/assets/images/icons/view-icon.png'
            },
            {
                action: 'dismiss',
                title: 'סגור',
                icon: '/assets/images/icons/close-icon.png'
            }
        ],
        requireInteraction: data.requireInteraction || false,
        silent: data.silent || false
    };
    
    event.waitUntil(
        showNotification(data.title || 'הודעה חדשה', options)
    );
});

/**
 * Notification Click Event
 * Handle notification clicks
 */
self.addEventListener('notificationclick', event => {
    console.log('[SW] Notification clicked:', event);
    
    event.notification.close();
    
    const action = event.action;
    const data = event.notification.data || {};
    
    if (action === 'dismiss') {
        return;
    }
    
    // Handle different actions
    let url = '/';
    
    if (action === 'view' || !action) {
        if (data.url) {
            url = data.url;
        } else if (data.type === 'message') {
            url = '/#messages';
        } else if (data.type === 'platform') {
            url = '/#platforms';
        } else if (data.type === 'alert') {
            url = '/#alerts';
        }
    }
    
    event.waitUntil(
        clients.matchAll({
            type: 'window',
            includeUncontrolled: true
        }).then(clientList => {
            // If app is already open, focus it
            for (const client of clientList) {
                if (client.url.includes(url.split('#')[0])) {
                    client.focus();
                    client.postMessage({
                        type: 'NOTIFICATION_CLICKED',
                        data: { action, url, notificationData: data }
                    });
                    return;
                }
            }
            
            // If app is not open, open it
            return clients.openWindow(url);
        })
    );
});

/**
 * Show notification helper
 */
async function showNotification(title, options) {
    try {
        return await self.registration.showNotification(title, options);
    } catch (error) {
        console.error('[SW] Error showing notification:', error);
    }
}

// ===== MESSAGE HANDLING =====

/**
 * Message Event
 * Handle messages from main app
 */
self.addEventListener('message', event => {
    console.log('[SW] Message received:', event.data);
    
    const { type, data } = event.data;
    
    switch (type) {
        case 'SKIP_WAITING':
            self.skipWaiting();
            break;
            
        case 'SYNC_REQUEST':
            if (self.registration.sync) {
                self.registration.sync.register('background-sync');
            }
            break;
            
        case 'MESSAGE_SYNC':
            if (self.registration.sync) {
                self.registration.sync.register('message-sync');
            }
            break;
            
        case 'SPAM_CLEANUP':
            if (self.registration.sync) {
                self.registration.sync.register('spam-cleanup');
            }
            break;
            
        case 'CACHE_CLEAR':
            clearCaches();
            break;
            
        case 'NOTIFICATION_PERMISSION':
            handleNotificationPermission();
            break;
            
        default:
            console.warn('[SW] Unknown message type:', type);
    }
});

/**
 * Clear all caches
 */
async function clearCaches() {
    try {
        const cacheNames = await caches.keys();
        
        await Promise.all(
            cacheNames.map(cacheName => caches.delete(cacheName))
        );
        
        console.log('[SW] All caches cleared');
        
        // Notify clients
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'CACHES_CLEARED',
                data: { success: true }
            });
        });
        
    } catch (error) {
        console.error('[SW] Error clearing caches:', error);
    }
}

/**
 * Handle notification permission request
 */
async function handleNotificationPermission() {
    try {
        const permission = await Notification.requestPermission();
        
        // Notify clients about permission status
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'NOTIFICATION_PERMISSION_RESULT',
                data: { permission }
            });
        });
        
    } catch (error) {
        console.error('[SW] Error handling notification permission:', error);
    }
}

// ===== PERIODIC BACKGROUND SYNC =====

/**
 * Periodic Background Sync Event
 * Handle periodic sync (if supported)
 */
self.addEventListener('periodicsync', event => {
    console.log('[SW] Periodic sync triggered:', event.tag);
    
    if (event.tag === 'content-sync') {
        event.waitUntil(performPeriodicSync());
    }
});

/**
 * Perform periodic sync
 */
async function performPeriodicSync() {
    try {
        console.log('[SW] Performing periodic sync...');
        
        // Sync messages
        await syncMessages();
        
        // Perform spam cleanup
        await performSpamCleanup();
        
        console.log('[SW] Periodic sync completed');
        
    } catch (error) {
        console.error('[SW] Periodic sync failed:', error);
    }
}

// ===== ERROR HANDLING =====

/**
 * Error Event
 * Handle service worker errors
 */
self.addEventListener('error', event => {
    console.error('[SW] Service worker error:', event.error);
    
    // Report error to main app if possible
    self.clients.matchAll().then(clients => {
        clients.forEach(client => {
            client.postMessage({
                type: 'SERVICE_WORKER_ERROR',
                data: {
                    message: event.error.message,
                    stack: event.error.stack
                }
            });
        });
    });
});

/**
 * Unhandled Rejection Event
 * Handle unhandled promise rejections
 */
self.addEventListener('unhandledrejection', event => {
    console.error('[SW] Unhandled promise rejection:', event.reason);
    
    // Prevent the default handling
    event.preventDefault();
});

// ===== INITIALIZATION =====

console.log('[SW] Service worker script loaded');

// Register for periodic background sync if supported
if ('periodicSync' in self.registration) {
    self.registration.periodicSync.register('content-sync', {
        minInterval: 24 * 60 * 60 * 1000 // 24 hours
    }).catch(error => {
        console.warn('[SW] Periodic sync registration failed:', error);
    });
}