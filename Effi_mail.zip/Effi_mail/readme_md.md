# Effi-UI Dynamic Engine 🎨

מנוע שליטה ויזואלית דינמי למערכת Effi-AI - מאפשר שליטה מלאה בזמן אמת על כל רכיבי העיצוב במערכת.

## 📋 תוכן עניינים
- [תכונות עיקריות](#-תכונות-עיקריות)
- [דרישות מערכת](#-דרישות-מערכת)
- [התקנה מהירה](#-התקנה-מהירה)
- [מבנה הקבצים](#-מבנה-הקבצים)
- [שימוש בסיסי](#-שימוש-בסיסי)
- [הגדרות מתקדמות](#-הגדרות-מתקדמות)
- [API ופונקציות](#-api-ופונקציות)
- [פתרון בעיות](#-פתרון-בעיות)

## ✨ תכונות עיקריות

### 🎨 שליטה ויזואלית מלאה
- עריכת צבעים, גדלים, מרווחים ואפקטים בזמן אמת
- תצוגה מקדימה חיה לכל שינוי
- ארגז כלים גרפי עם Drag & Drop

### ⏰ חוקים מבוססי זמן
- הגדרת פרופילי עיצוב אוטומטיים
- מעבר חלק בין מצבים (יום/לילה)
- תזמון מדויק לפי שעות ותאריכים

### 📱 Progressive Web App
- התקנה על כל מכשיר
- תמיכה מלאה במצב אופליין
- סנכרון אוטומטי ברקע

### 🎭 אנימציות ותלת-ממד
- ספריית אנימציות עשירה
- אפקטי תלת-ממד מתקדמים
- תמיכה בתנועות מורכבות

## 💻 דרישות מערכת

### דפדפנים נתמכים:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### טכנולוגיות נדרשות:
- CSS Variables
- CSS Grid & Flexbox
- Service Workers
- Custom Elements
- Backdrop Filter

## 🚀 התקנה מהירה

### אופציה 1: התקנה אוטומטית
```bash
curl -o install.sh https://raw.githubusercontent.com/your-repo/effi-ui/main/install.sh
chmod +x install.sh
./install.sh
```

### אופציה 2: התקנה ידנית
1. הורד את כל הקבצים לתיקייה `/effi_ui_engine/`
2. הוסף את השורה הבאה לכל עמוד:
```html
<script src="/effi_ui_engine/effi_ui_loader.js" data-effi-auto="true"></script>
```

### אופציה 3: התקנה עם npm
```bash
npm install effi-ui-engine
```

## 📁 מבנה הקבצים

```
effi_ui_engine/
├── effi_ui_engine.js       # מנוע השליטה הראשי
├── effi_ui_engine.css      # סגנונות ואנימציות
├── effi_ui_panel.html      # ממשק ניהול גרפי
├── effi_ui_preview.html    # תצוגה מקדימה חיה
├── effi_ui_config.json     # קובץ הגדרות
├── effi_ui_assets.json     # רשימת רכיבים
├── effi_ui_loader.js       # סקריפט טעינה
├── setup_visual_control.html # מרכז בקרה
├── manifest.json           # הגדרות PWA
├── service-worker.js       # תמיכת אופליין
├── README.md              # מדריך זה
├── install.sh             # סקריפט התקנה
└── icons/                 # אייקונים
    ├── icon-192.png
    └── icon-512.png
```

## 🎯 שימוש בסיסי

### 1. טעינה בסיסית
```html
<!-- הוסף לתג <head> -->
<script src="/effi_ui_engine/effi_ui_loader.js"></script>
```

### 2. טעינה עם הגדרות
```html
<script src="/effi_ui_engine/effi_ui_loader.js" 
        data-effi-auto="true"
        data-effi-debug="false"
        data-effi-path="/custom/path/">
</script>
```

### 3. טעינה ידנית
```javascript
// טעינה ידנית כאשר מוכן
window.EffiUILoader.init().then(() => {
    console.log('Effi-UI loaded!');
});
```

## ⚙️ הגדרות מתקדמות

### פרופילים מותאמים אישית
```javascript
// יצירת פרופיל חדש
const myProfile = {
    name: "הפרופיל שלי",
    colors: {
        primary: "#ff6b6b",
        secondary: "#4ecdc4"
    },
    typography: {
        fontFamily: "Heebo, sans-serif",
        fontSize: {
            small: "14px",
            medium: "18px",
            large: "28px"
        }
    }
};

// הוספת הפרופיל
window.effiUI.addProfile('custom', myProfile);
```

### חוקי זמן
```javascript
// הוספת חוק זמן חדש
window.effiUI.addTimeBasedRule({
    name: "מצב לילה",
    startTime: "20:00",
    endTime: "06:00",
    profile: "dark",
    days: ["sunday", "monday", "tuesday", "wednesday", "thursday"]
});
```

### רכיבים מותאמים אישית
```javascript
// הוספת כפתור חדש לארגז הכלים
const customButton = {
    id: "btn-custom",
    name: "הכפתור שלי",
    type: "button",
    category: "כפתורים",
    styles: {
        background: "linear-gradient(45deg, #ff6b6b, #4ecdc4)",
        color: "white",
        padding: "15px 30px",
        borderRadius: "25px"
    },
    hover: {
        transform: "scale(1.1)",
        boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
    }
};

window.effiUI.addAsset('buttons', customButton);
```

## 🔧 API ופונקציות

### פונקציות ראשיות
```javascript
// החלפת פרופיל
window.effiUI.switchProfile('dark');

// קבלת פרופיל נוכחי
const currentProfile = window.effiUI.getCurrentProfile();

// שמירת הגדרות
window.effiUI.saveConfig();

// ייצוא הגדרות
window.effiUI.exportConfig();

// ייבוא הגדרות
window.effiUI.importConfig(file);

// ביטול פעולה אחרונה
window.effiUI.undo();
```

### אירועים
```javascript
// האזנה לשינוי פרופיל
window.addEventListener('effi-profile-changed', (e) => {
    console.log('Profile changed to:', e.detail.profile);
});

// האזנה לעדכון היסטוריה
window.addEventListener('effi-history-updated', (e) => {
    console.log('History updated:', e.detail.history);
});

// האזנה לטעינת המערכת
window.addEventListener('effi-ui-loaded', (e) => {
    console.log('System loaded in:', e.detail.loadTime, 'ms');
});
```

### טעינת רכיבים דינמית
```javascript
// טעינת רכיבים מ-URL חיצוני
fetch('https://api.example.com/assets')
    .then(res => res.json())
    .then(assets => {
        assets.forEach(asset => {
            window.effiUI.addAsset(asset.category, asset);
        });
    });
```

## 🐛 פתרון בעיות

### המערכת לא נטענת
1. בדוק שכל הקבצים במקומם
2. בדוק הרשאות CORS
3. בדוק קונסול לשגיאות
4. נסה טעינה ידנית

### Service Worker לא עובד
1. וודא HTTPS או localhost
2. נקה מטמון דפדפן
3. בדוק scope נכון
4. בדוק תמיכת דפדפן

### בעיות ביצועים
1. הקטן מספר אנימציות
2. השתמש ב-will-change בזהירות
3. אופטימיזציה של תמונות
4. הפעל compression

## 📱 התקנה כ-PWA

### במחשב:
1. פתח את המערכת בדפדפן
2. לחץ על כפתור ההתקנה בשורת הכתובת
3. אשר התקנה

### במובייל:
1. פתח את המערכת בדפדפן
2. לחץ על "הוסף למסך הבית"
3. אשר והתקן

## 🔐 אבטחה והרשאות

### הגדרת הרשאות
```javascript
// בקובץ effi_ui_config.json
{
    "permissions": {
        "allowColorChanges": true,
        "allowLayoutChanges": false,
        "requireAuth": true
    }
}
```

### אימות משתמשים
```javascript
// הגדרת אימות מותאם אישית
window.effiAuth = {
    isAuthenticated: () => {
        // לוגיקת אימות
        return true;
    },
    getUserRole: () => {
        return 'admin';
    }
};
```

## 🌐 תמיכה בשפות

המערכת תומכת מלאה בעברית ו-RTL.
להוספת שפות נוספות:

```javascript
// הוספת תרגום
window.effiUI.addTranslation('en', {
    'save': 'Save',
    'cancel': 'Cancel',
    'preview': 'Preview'
});
```

## 📞 תמיכה ועזרה

- 📧 Email: support@effi-ai.com
- 💬 Discord: https://discord.gg/effi-ui
- 📚 תיעוד מלא: https://docs.effi-ui.com
- 🐛 דיווח באגים: https://github.com/effi-ai/effi-ui/issues

## 📄 רישיון

MIT License - ראה קובץ LICENSE לפרטים נוספים.

---

פותח עם ❤️ עבור מערכת Effi-AI Private
