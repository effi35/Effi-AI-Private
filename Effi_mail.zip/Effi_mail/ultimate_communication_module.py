#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
מודול Ultimate Communication Universe
מרכז פיקוד מאוחד לכל התקשורת הדיגיטלית + ניקוי ספאם אוטומטי + קבוצות

מפתח: shayAI
גרסה: 1.0.0
רישיון: MIT
"""

import os
import json
import time
import asyncio
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path

# ייבוא מודולי המערכת הראשית
try:
    from effi_ai_private.core.module_interface import ModuleInterface, ModuleMetadata
    from effi_ai_private.core.security import credentials_manager
    from effi_ai_private.core.permissions import PermissionManager
except ImportError:
    # Fallback למקרה שהמערכת הראשית לא זמינה
    class ModuleInterface:
        def __init__(self, config=None):
            self.config = config or {}
            self.logger = logging.getLogger(self.__class__.__name__)
            self.is_initialized = False
    
    class ModuleMetadata:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

# ייבוא ספריות חיצוניות
import requests
from bs4 import BeautifulSoup
import imaplib
import smtplib
import poplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import email
from email.header import decode_header
import re
import hashlib
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed
import schedule
import websocket
import json


@dataclass
class PlatformConfig:
    """תצורת פלטפורמה"""
    name: str
    display_name: str
    type: str  # email, social, messaging, utility
    enabled: bool = True
    credentials: Dict[str, Any] = None
    settings: Dict[str, Any] = None
    last_sync: Optional[datetime] = None
    status: str = "disconnected"  # connected, disconnected, error


@dataclass
class UserProfile:
    """פרופיל משתמש"""
    user_id: str
    display_name: str
    email: str
    role: str  # admin, member, viewer
    platforms: List[str] = None
    preferences: Dict[str, Any] = None
    is_active: bool = True
    created_at: datetime = None


@dataclass
class GroupConfig:
    """תצורת קבוצה"""
    group_id: str
    name: str
    type: str  # family, work, friends, custom
    description: str = ""
    members: List[UserProfile] = None
    shared_platforms: List[str] = None
    alert_settings: Dict[str, Any] = None
    created_at: datetime = None


@dataclass
class Message:
    """הודעה מאוחדת"""
    message_id: str
    platform: str
    sender: str
    recipient: str
    subject: str = ""
    content: str = ""
    timestamp: datetime = None
    importance_score: int = 0
    is_spam: bool = False
    is_read: bool = False
    labels: List[str] = None
    attachments: List[str] = None


@dataclass
class SpamRule:
    """כלל זיהוי ספאם"""
    rule_id: str
    name: str
    pattern: str
    rule_type: str  # keyword, sender, regex, ai
    action: str  # delete, spam, unsubscribe
    score: int = 50
    enabled: bool = True
    created_by: str = "system"


class EmailConnector:
    """מחבר דואר אלקטרוני מאוחד"""
    
    def __init__(self, config: PlatformConfig, logger):
        self.config = config
        self.logger = logger
        self.connection = None
        
    def connect(self) -> bool:
        """התחברות לשרת דואר"""
        try:
            provider = self.config.settings.get('provider', 'imap')
            
            if provider == 'gmail':
                return self._connect_gmail()
            elif provider == 'outlook':
                return self._connect_outlook()
            elif provider == 'yahoo':
                return self._connect_yahoo()
            else:
                return self._connect_imap()
                
        except Exception as e:
            self.logger.error(f"שגיאה בחיבור לדואר {self.config.name}: {e}")
            return False
    
    def _connect_gmail(self) -> bool:
        """חיבור ל-Gmail דרך API"""
        try:
            # Google Gmail API integration
            credentials = self.config.credentials
            if not credentials or 'oauth_token' not in credentials:
                return False
                
            # כאן יבוא החיבור האמיתי ל-Gmail API
            self.logger.info(f"מתחבר ל-Gmail עבור {self.config.name}")
            self.config.status = "connected"
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיבור ל-Gmail: {e}")
            return False
    
    def _connect_outlook(self) -> bool:
        """חיבור ל-Outlook דרך Microsoft Graph API"""
        try:
            credentials = self.config.credentials
            if not credentials or 'access_token' not in credentials:
                return False
                
            # כאן יבוא החיבור האמיתי ל-Microsoft Graph
            self.logger.info(f"מתחבר ל-Outlook עבור {self.config.name}")
            self.config.status = "connected"
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיבור ל-Outlook: {e}")
            return False
    
    def _connect_imap(self) -> bool:
        """חיבור IMAP כללי"""
        try:
            server = self.config.settings.get('imap_server')
            port = self.config.settings.get('imap_port', 993)
            username = self.config.credentials.get('username')
            password = self.config.credentials.get('password')
            
            if not all([server, username, password]):
                return False
                
            self.connection = imaplib.IMAP4_SSL(server, port)
            self.connection.login(username, password)
            
            self.logger.info(f"מחובר בהצלחה ל-{server}")
            self.config.status = "connected"
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיבור IMAP: {e}")
            return False
    
    def get_messages(self, limit: int = 50) -> List[Message]:
        """קבלת הודעות"""
        try:
            messages = []
            
            if self.config.settings.get('provider') == 'gmail':
                messages = self._get_gmail_messages(limit)
            elif self.config.settings.get('provider') == 'outlook':
                messages = self._get_outlook_messages(limit)
            else:
                messages = self._get_imap_messages(limit)
                
            return messages
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת הודעות: {e}")
            return []
    
    def _get_imap_messages(self, limit: int) -> List[Message]:
        """קבלת הודעות דרך IMAP"""
        messages = []
        try:
            if not self.connection:
                return messages
                
            self.connection.select('INBOX')
            status, message_ids = self.connection.search(None, 'ALL')
            
            if status != 'OK':
                return messages
                
            message_ids = message_ids[0].split()[-limit:]
            
            for msg_id in message_ids:
                status, msg_data = self.connection.fetch(msg_id, '(RFC822)')
                if status == 'OK':
                    email_message = email.message_from_bytes(msg_data[0][1])
                    
                    # חילוץ מידע מההודעה
                    subject = self._decode_header(email_message.get('Subject', ''))
                    sender = self._decode_header(email_message.get('From', ''))
                    recipient = self._decode_header(email_message.get('To', ''))
                    date_str = email_message.get('Date', '')
                    
                    # חילוץ תוכן ההודעה
                    content = self._extract_email_content(email_message)
                    
                    message = Message(
                        message_id=f"{self.config.name}_{msg_id.decode()}",
                        platform=self.config.name,
                        sender=sender,
                        recipient=recipient,
                        subject=subject,
                        content=content,
                        timestamp=self._parse_date(date_str),
                        importance_score=0,
                        is_spam=False,
                        is_read=False,
                        labels=[],
                        attachments=[]
                    )
                    
                    messages.append(message)
                    
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת הודעות IMAP: {e}")
            
        return messages
    
    def _decode_header(self, header: str) -> str:
        """פענוח כותרת דואר"""
        try:
            if not header:
                return ""
                
            decoded_header = decode_header(header)[0][0]
            if isinstance(decoded_header, bytes):
                return decoded_header.decode('utf-8', errors='ignore')
            return str(decoded_header)
            
        except Exception:
            return str(header)
    
    def _extract_email_content(self, email_message) -> str:
        """חילוץ תוכן הודעת דואר"""
        try:
            content = ""
            
            if email_message.is_multipart():
                for part in email_message.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            content = payload.decode('utf-8', errors='ignore')
                            break
            else:
                payload = email_message.get_payload(decode=True)
                if payload:
                    content = payload.decode('utf-8', errors='ignore')
                    
            return content[:1000]  # הגבלת אורך התוכן
            
        except Exception as e:
            self.logger.error(f"שגיאה בחילוץ תוכן דואר: {e}")
            return ""
    
    def _parse_date(self, date_str: str) -> datetime:
        """פענוח תאריך מהודעת דואר"""
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(date_str)
        except Exception:
            return datetime.now()


class SpamDetector:
    """מזהה ספאם מתקדם עם AI"""
    
    def __init__(self, logger):
        self.logger = logger
        self.rules: List[SpamRule] = []
        self.whitelist: set = set()
        self.blacklist: set = set()
        self.load_rules()
    
    def load_rules(self):
        """טעינת כללי ספאם"""
        try:
            # כללים בסיסיים לזיהוי ספאם
            default_rules = [
                SpamRule("spam_1", "מילות פרסומת", r"(מבצע|הנחה|זכית|מתנה|חינם)", "regex", "spam", 70),
                SpamRule("spam_2", "הימורים", r"(הימור|קזינו|פוקר|רולטה)", "regex", "delete", 90),
                SpamRule("spam_3", "תרופות", r"(ויאגרה|סיאליס|תרופה)", "regex", "delete", 85),
                SpamRule("spam_4", "כסף קל", r"(כסף קל|העשר|השקעה)", "regex", "spam", 60),
                SpamRule("spam_5", "ניגרי נסיך", r"(נסיך|מיליון דולר|עזבונות)", "regex", "delete", 95),
            ]
            
            self.rules.extend(default_rules)
            self.logger.info(f"נטענו {len(default_rules)} כללי ספאם בסיסיים")
            
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת כללי ספאם: {e}")
    
    def analyze_message(self, message: Message) -> int:
        """ניתוח הודעה וחזרת ציון ספאם (0-100)"""
        try:
            spam_score = 0
            
            # בדיקת שולח
            spam_score += self._check_sender(message.sender)
            
            # בדיקת נושא
            spam_score += self._check_subject(message.subject)
            
            # בדיקת תוכן
            spam_score += self._check_content(message.content)
            
            # בדיקת כללים מותאמים
            spam_score += self._apply_custom_rules(message)
            
            # הגבלת הציון למקסימום 100
            return min(spam_score, 100)
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוח ספאם: {e}")
            return 0
    
    def _check_sender(self, sender: str) -> int:
        """בדיקת שולח"""
        try:
            sender_lower = sender.lower()
            
            # בדיקת רשימה שחורה
            if any(blocked in sender_lower for blocked in self.blacklist):
                return 90
            
            # בדיקת רשימה לבנה
            if any(trusted in sender_lower for trusted in self.whitelist):
                return -20
            
            # בדיקת דפוסי ספאם בכתובת
            spam_patterns = [
                'noreply@randomstring',
                'promo@',
                'marketing@',
                'newsletter@spam',
                '@suspicious-domain'
            ]
            
            for pattern in spam_patterns:
                if pattern in sender_lower:
                    return 40
                    
            return 0
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת שולח: {e}")
            return 0
    
    def _check_subject(self, subject: str) -> int:
        """בדיקת נושא"""
        try:
            if not subject:
                return 10
                
            subject_lower = subject.lower()
            spam_score = 0
            
            # מילות מפתח של ספאם
            spam_keywords = [
                'מבצע', 'הנחה', 'זכית', 'מתנה', 'חינם', 'דחוף',
                'הצעה מיוחדת', 'רק היום', 'הזדמנות', 'רווח',
                'הימור', 'קזינו', 'לוטו', 'הגרלה'
            ]
            
            for keyword in spam_keywords:
                if keyword in subject_lower:
                    spam_score += 15
            
            # בדיקת אותיות גדולות יתר על המידה
            if len([c for c in subject if c.isupper()]) > len(subject) * 0.7:
                spam_score += 20
            
            # בדיקת סימני קריאה רבים
            if subject.count('!') > 3:
                spam_score += 15
                
            return spam_score
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת נושא: {e}")
            return 0
    
    def _check_content(self, content: str) -> int:
        """בדיקת תוכן ההודעה"""
        try:
            if not content:
                return 5
                
            content_lower = content.lower()
            spam_score = 0
            
            # קישורים חשודים
            suspicious_links = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', content)
            if len(suspicious_links) > 5:
                spam_score += 30
            
            # בדיקת יחס תמונות לטקסט
            if content.count('<img') > 3 and len(content.strip()) < 200:
                spam_score += 25
            
            # מילים בשפות זרות (לא עברית/אנגלית)
            foreign_chars = re.findall(r'[^\u0000-\u007F\u0590-\u05FF]', content)
            if len(foreign_chars) > len(content) * 0.3:
                spam_score += 20
                
            return spam_score
            
        except Exception as e:
            self.logger.error(f"שגיאה בבדיקת תוכן: {e}")
            return 0
    
    def _apply_custom_rules(self, message: Message) -> int:
        """יישום כללים מותאמים אישית"""
        try:
            spam_score = 0
            
            for rule in self.rules:
                if not rule.enabled:
                    continue
                    
                if rule.rule_type == "regex":
                    pattern = re.compile(rule.pattern, re.IGNORECASE)
                    
                    # בדיקה בנושא
                    if pattern.search(message.subject or ""):
                        spam_score += rule.score
                    
                    # בדיקה בתוכן
                    if pattern.search(message.content or ""):
                        spam_score += rule.score
                    
                    # בדיקה בשולח
                    if pattern.search(message.sender or ""):
                        spam_score += rule.score
            
            return spam_score
            
        except Exception as e:
            self.logger.error(f"שגיאה ביישום כללים מותאמים: {e}")
            return 0


class UnsubscribeBot:
    """בוט להסרה אוטומטית מרשימות תפוצה"""
    
    def __init__(self, logger):
        self.logger = logger
        self.unsubscribe_attempts = {}
        
    def find_unsubscribe_link(self, message: Message) -> Optional[str]:
        """חיפוש קישור הסרה בהודעה"""
        try:
            content = message.content.lower()
            
            # דפוסים שונים של קישורי הסרה
            unsubscribe_patterns = [
                r'<a[^>]*href=["\']([^"\']*unsubscribe[^"\']*)["\']',
                r'https?://[^\s]*unsubscribe[^\s]*',
                r'<a[^>]*href=["\']([^"\']*remove[^"\']*)["\']',
                r'https?://[^\s]*remove[^\s]*'
            ]
            
            for pattern in unsubscribe_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    return matches[0]
            
            return None
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיפוש קישור הסרה: {e}")
            return None
    
    def safe_unsubscribe(self, url: str, message: Message) -> bool:
        """הסרה בטוחה מרשימת תפוצה"""
        try:
            # בדיקת בטיחות הקישור
            if not self._is_safe_url(url):
                self.logger.warning(f"קישור לא בטוח נדחה: {url}")
                return False
            
            # ביצוע הסרה
            response = requests.get(
                url, 
                timeout=10,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            )
            
            if response.status_code == 200:
                self.logger.info(f"הוסר בהצלחה מרשימת תפוצה: {message.sender}")
                
                # רישום הניסיון
                self.unsubscribe_attempts[message.sender] = {
                    'timestamp': datetime.now(),
                    'success': True,
                    'url': url
                }
                
                return True
            else:
                self.logger.warning(f"כשלון בהסרה מרשימת תפוצה: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"שגיאה בהסרה מרשימת תפוצה: {e}")
            return False
    
    def _is_safe_url(self, url: str) -> bool:
        """בדיקת בטיחות קישור"""
        try:
            # רשימת דומיינים מסוכנים ידועים
            dangerous_domains = [
                'bit.ly', 'tinyurl.com', 'shortened.link',
                'suspicious-site.com', 'phishing-domain.net'
            ]
            
            for domain in dangerous_domains:
                if domain in url.lower():
                    return False
            
            # בדיקת תווים חשודים
            if any(char in url for char in ['<', '>', '"', "'"]):
                return False
            
            # בדיקת אורך סביר
            if len(url) > 500:
                return False
                
            return True
            
        except Exception:
            return False


class GroupManager:
    """מנהל קבוצות"""
    
    def __init__(self, logger):
        self.logger = logger
        self.groups: Dict[str, GroupConfig] = {}
        self.users: Dict[str, UserProfile] = {}
        
    def create_group(self, name: str, group_type: str, creator_id: str) -> str:
        """יצירת קבוצה חדשה"""
        try:
            group_id = f"group_{int(time.time())}"
            
            group = GroupConfig(
                group_id=group_id,
                name=name,
                type=group_type,
                description="",
                members=[],
                shared_platforms=[],
                alert_settings={
                    'shared_alerts': True,
                    'individual_alerts': True,
                    'emergency_alerts': True,
                    'quiet_hours': {'start': '23:00', 'end': '07:00'}
                },
                created_at=datetime.now()
            )
            
            self.groups[group_id] = group
            self.logger.info(f"נוצרה קבוצה חדשה: {name} ({group_id})")
            
            return group_id
            
        except Exception as e:
            self.logger.error(f"שגיאה ביצירת קבוצה: {e}")
            return ""
    
    def add_member(self, group_id: str, user_profile: UserProfile) -> bool:
        """הוספת חבר לקבוצה"""
        try:
            if group_id not in self.groups:
                return False
                
            group = self.groups[group_id]
            
            # בדיקה שהחבר לא קיים כבר
            existing_member = next(
                (m for m in group.members if m.user_id == user_profile.user_id), 
                None
            )
            
            if existing_member:
                self.logger.warning(f"חבר כבר קיים בקבוצה: {user_profile.display_name}")
                return False
            
            group.members.append(user_profile)
            self.users[user_profile.user_id] = user_profile
            
            self.logger.info(f"נוסף חבר לקבוצה {group.name}: {user_profile.display_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהוספת חבר לקבוצה: {e}")
            return False
    
    def get_group_alerts(self, group_id: str) -> List[Dict[str, Any]]:
        """קבלת התראות קבוצתיות"""
        try:
            if group_id not in self.groups:
                return []
                
            group = self.groups[group_id]
            alerts = []
            
            # כאן יבוא הלוגיקה לקבלת התראות מכל הפלטפורמות
            # של כל חברי הקבוצה
            
            return alerts
            
        except Exception as e:
            self.logger.error(f"שגיאה בקבלת התראות קבוצתיות: {e}")
            return []


class UltimateCommunicationUniverseModule(ModuleInterface):
    """מודול Ultimate Communication Universe"""
    
    def __init__(self, config=None):
        super().__init__(config)
        self.name = "ultimate_communication_universe"
        self.display_name = "מרכז התקשורת הסופי"
        self.version = "1.0.0"
        
        # רכיבי המודול
        self.platforms: Dict[str, PlatformConfig] = {}
        self.email_connectors: Dict[str, EmailConnector] = {}
        self.spam_detector = None
        self.unsubscribe_bot = None
        self.group_manager = None
        
        # הגדרות
        self.sync_interval = 60  # סנכרון כל דקה
        self.spam_threshold = 70
        self.auto_unsubscribe = True
        
        # סטטוס
        self.is_running = False
        self.sync_thread = None
        
        # בסיס נתונים
        self.db_path = None
        
    @classmethod
    def get_metadata(cls) -> ModuleMetadata:
        """קבלת מטאדאטא של המודול"""
        return ModuleMetadata(
            name="ultimate_communication_universe",
            version="1.0.0",
            description="מרכז פיקוד מאוחד לכל התקשורת הדיגיטלית + ניקוי ספאם אוטומטי + קבוצות גמישות",
            author="shayAI",
            type="communication",
            dependencies=[
                "requests>=2.31.0",
                "beautifulsoup4>=4.12.0",
                "schedule>=1.2.0",
                "websocket-client>=1.6.0",
                "python-telegram-bot>=20.0"
            ],
            module_dependencies=["consciousness_engine"],
            ui_components={
                "panel": True,
                "settings_tab": True,
                "main_tab": True
            },
            config={
                "spam_threshold": 70,
                "sync_interval": 60,
                "auto_unsubscribe": True,
                "max_platforms": 50,
                "enable_ai_analysis": True
            },
            tags=["תקשורת", "דואר", "רשתות_חברתיות", "ספאם", "קבוצות", "התראות"],
            ui_tab_name="מרכז התקשורת הסופי"
        )
    
    def initialize(self) -> bool:
        """אתחול המודול"""
        try:
            self.logger.info("מתחיל אתחול מרכז התקשורת הסופי...")
            
            # יצירת תיקיות נדרשות
            self._create_directories()
            
            # אתחול בסיס נתונים
            self._initialize_database()
            
            # אתחול רכיבים
            self.spam_detector = SpamDetector(self.logger)
            self.unsubscribe_bot = UnsubscribeBot(self.logger)
            self.group_manager = GroupManager(self.logger)
            
            # טעינת הגדרות
            self._load_settings()
            
            # טעינת פלטפורמות
            self._load_platforms()
            
            self.is_initialized = True
            self.logger.info("אתחול מרכז התקשורת הסופי הושלם בהצלחה")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול מרכז התקשורת הסופי: {e}")
            return False
    
    def start(self) -> bool:
        """הפעלת המודול"""
        try:
            if not self.is_initialized:
                self.logger.error("המודול לא אותחל - לא ניתן להפעיל")
                return False
            
            self.logger.info("מפעיל מרכז התקשורת הסופי...")
            
            # התחברות לכל הפלטפורמות
            self._connect_all_platforms()
            
            # הפעלת סנכרון אוטומטי
            self._start_sync_thread()
            
            self.is_running = True
            self.logger.info("מרכז התקשורת הסופי פועל")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת מרכז התקשורת הסופי: {e}")
            return False
    
    def stop(self) -> bool:
        """עצירת המודול"""
        try:
            self.logger.info("עוצר מרכז התקשורת הסופי...")
            
            self.is_running = False
            
            # עצירת חוט הסנכרון
            if self.sync_thread and self.sync_thread.is_alive():
                self.sync_thread.join(timeout=5)
            
            # ניתוק מכל הפלטפורמות
            self._disconnect_all_platforms()
            
            self.logger.info("מרכז התקשורת הסופי נעצר")
            
            return True
            
        except Exception as e:
            self.logger.error(f"שגיאה בעצירת מרכז התקשורת הסופי: {e}")
            return False
    
    def handle_api_request(self, endpoint: str, method: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """טיפול בקריאות API"""
        try:
            self.logger.debug(f"API Request: {method} {endpoint}")
            
            if endpoint == "platforms" and method == "GET":
                return self._api_get_platforms()
            
            elif endpoint == "platforms" and method == "POST":
                return self._api_add_platform(data)
            
            elif endpoint == "messages" and method == "GET":
                return self._api_get_messages(data)
            
            elif endpoint == "spam/analyze" and method == "POST":
                return self._api_analyze_spam(data)
            
            elif endpoint == "spam/settings" and method == "GET":
                return self._api_get_spam_settings()
            
            elif endpoint == "spam/settings" and method == "POST":
                return self._api_update_spam_settings(data)
            
            elif endpoint == "groups" and method == "GET":
                return self._api_get_groups()
            
            elif endpoint == "groups" and method == "POST":
                return self._api_create_group(data)
            
            elif endpoint == "sync" and method == "POST":
                return self._api_sync_now()
            
            elif endpoint == "stats" and method == "GET":
                return self._api_get_stats()
            
            else:
                return {
                    "success": False,
                    "error": f"נקודת קצה לא נמצאה: {endpoint}",
                    "code": "ENDPOINT_NOT_FOUND"
                }
                
        except Exception as e:
            self.logger.error(f"שגיאה בטיפול בקריאת API: {e}")
            return {
                "success": False,
                "error": str(e),
                "code": "API_ERROR"
            }
    
    def _create_directories(self):
        """יצירת תיקיות נדרשות"""
        base_path = Path(__file__).parent
        directories = ['logs', 'data', 'config', 'temp']
        
        for directory in directories:
            dir_path = base_path / directory
            dir_path.mkdir(exist_ok=True)
    
    def _initialize_database(self):
        """אתחול בסיס נתונים"""
        try:
            self.db_path = Path(__file__).parent / 'data' / 'communication.db'
            
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # טבלת הודעות
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    platform TEXT,
                    sender TEXT,
                    recipient TEXT,
                    subject TEXT,
                    content TEXT,
                    timestamp DATETIME,
                    importance_score INTEGER,
                    is_spam BOOLEAN,
                    is_read BOOLEAN,
                    labels TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # טבלת פלטפורמות
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS platforms (
                    name TEXT PRIMARY KEY,
                    display_name TEXT,
                    type TEXT,
                    enabled BOOLEAN,
                    settings TEXT,
                    last_sync DATETIME,
                    status TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # טבלת קבוצות
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS groups (
                    group_id TEXT PRIMARY KEY,
                    name TEXT,
                    type TEXT,
                    description TEXT,
                    settings TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # טבלת כללי ספאם
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS spam_rules (
                    rule_id TEXT PRIMARY KEY,
                    name TEXT,
                    pattern TEXT,
                    rule_type TEXT,
                    action TEXT,
                    score INTEGER,
                    enabled BOOLEAN,
                    created_by TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            conn.close()
            
            self.logger.info("בסיס נתונים אותחל בהצלחה")
            
        except Exception as e:
            self.logger.error(f"שגיאה באתחול בסיס נתונים: {e}")
            raise
    
    def _load_settings(self):
        """טעינת הגדרות"""
        try:
            config_path = Path(__file__).parent / 'config' / 'settings.json'
            
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                
                self.sync_interval = settings.get('sync_interval', 60)
                self.spam_threshold = settings.get('spam_threshold', 70)
                self.auto_unsubscribe = settings.get('auto_unsubscribe', True)
                
                self.logger.info("הגדרות נטענו בהצלחה")
            else:
                self.logger.info("קובץ הגדרות לא נמצא - משתמש בהגדרות ברירת מחדל")
                
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת הגדרות: {e}")
    
    def _load_platforms(self):
        """טעינת פלטפורמות מבסיס הנתונים"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM platforms WHERE enabled = 1")
            rows = cursor.fetchall()
            
            for row in rows:
                name, display_name, ptype, enabled, settings_json, last_sync, status, created_at = row
                
                settings = json.loads(settings_json) if settings_json else {}
                
                platform = PlatformConfig(
                    name=name,
                    display_name=display_name,
                    type=ptype,
                    enabled=bool(enabled),
                    settings=settings,
                    status=status
                )
                
                self.platforms[name] = platform
            
            conn.close()
            self.logger.info(f"נטענו {len(self.platforms)} פלטפורמות")
            
        except Exception as e:
            self.logger.error(f"שגיאה בטעינת פלטפורמות: {e}")
    
    def _connect_all_platforms(self):
        """התחברות לכל הפלטפורמות"""
        try:
            for platform_name, platform in self.platforms.items():
                if platform.enabled and platform.type == 'email':
                    connector = EmailConnector(platform, self.logger)
                    if connector.connect():
                        self.email_connectors[platform_name] = connector
                        platform.status = "connected"
                    else:
                        platform.status = "error"
            
            self.logger.info(f"מחובר ל-{len(self.email_connectors)} פלטפורמות דואר")
            
        except Exception as e:
            self.logger.error(f"שגיאה בחיבור לפלטפורמות: {e}")
    
    def _disconnect_all_platforms(self):
        """ניתוק מכל הפלטפורמות"""
        try:
            for connector in self.email_connectors.values():
                if hasattr(connector, 'connection') and connector.connection:
                    try:
                        connector.connection.logout()
                    except:
                        pass
            
            self.email_connectors.clear()
            
            for platform in self.platforms.values():
                platform.status = "disconnected"
            
            self.logger.info("נותק מכל הפלטפורמות")
            
        except Exception as e:
            self.logger.error(f"שגיאה בניתוק מפלטפורמות: {e}")
    
    def _start_sync_thread(self):
        """הפעלת חוט סנכרון"""
        try:
            def sync_worker():
                while self.is_running:
                    try:
                        self._sync_all_platforms()
                        time.sleep(self.sync_interval)
                    except Exception as e:
                        self.logger.error(f"שגיאה בסנכרון: {e}")
                        time.sleep(30)  # המתנה קצרה במקרה של שגיאה
            
            self.sync_thread = threading.Thread(target=sync_worker, daemon=True)
            self.sync_thread.start()
            
            self.logger.info("חוט הסנכרון הופעל")
            
        except Exception as e:
            self.logger.error(f"שגיאה בהפעלת חוט סנכרון: {e}")
    
    def _sync_all_platforms(self):
        """סנכרון כל הפלטפורמות"""
        try:
            for platform_name, connector in self.email_connectors.items():
                messages = connector.get_messages(50)
                
                for message in messages:
                    # ניתוח ספאם
                    spam_score = self.spam_detector.analyze_message(message)
                    message.importance_score = 100 - spam_score
                    message.is_spam = spam_score >= self.spam_threshold
                    
                    # טיפול בספאם
                    if message.is_spam and self.auto_unsubscribe:
                        unsubscribe_link = self.unsubscribe_bot.find_unsubscribe_link(message)
                        if unsubscribe_link:
                            self.unsubscribe_bot.safe_unsubscribe(unsubscribe_link, message)
                    
                    # שמירת ההודעה
                    self._save_message(message)
                
                # עדכון זמן סנכרון אחרון
                self.platforms[platform_name].last_sync = datetime.now()
            
        except Exception as e:
            self.logger.error(f"שגיאה בסנכרון פלטפורמות: {e}")
    
    def _save_message(self, message: Message):
        """שמירת הודעה בבסיס הנתונים"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO messages 
                (id, platform, sender, recipient, subject, content, timestamp, 
                 importance_score, is_spam, is_read, labels)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                message.message_id,
                message.platform,
                message.sender,
                message.recipient,
                message.subject,
                message.content,
                message.timestamp,
                message.importance_score,
                message.is_spam,
                message.is_read,
                json.dumps(message.labels or [])
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"שגיאה בשמירת הודעה: {e}")
    
    # API Methods
    def _api_get_platforms(self) -> Dict[str, Any]:
        """קבלת רשימת פלטפורמות"""
        try:
            platforms_data = []
            
            for platform in self.platforms.values():
                platforms_data.append({
                    'name': platform.name,
                    'display_name': platform.display_name,
                    'type': platform.type,
                    'enabled': platform.enabled,
                    'status': platform.status,
                    'last_sync': platform.last_sync.isoformat() if platform.last_sync else None
                })
            
            return {
                'success': True,
                'platforms': platforms_data,
                'total': len(platforms_data)
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _api_get_messages(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """קבלת הודעות"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # פרמטרים
            limit = params.get('limit', 50)
            platform = params.get('platform')
            important_only = params.get('important_only', False)
            
            # בניית שאילתה
            query = "SELECT * FROM messages WHERE 1=1"
            query_params = []
            
            if platform:
                query += " AND platform = ?"
                query_params.append(platform)
            
            if important_only:
                query += " AND importance_score >= 70"
            
            query += " ORDER BY timestamp DESC LIMIT ?"
            query_params.append(limit)
            
            cursor.execute(query, query_params)
            rows = cursor.fetchall()
            
            messages = []
            for row in rows:
                message_data = {
                    'id': row[0],
                    'platform': row[1],
                    'sender': row[2],
                    'recipient': row[3],
                    'subject': row[4],
                    'content': row[5][:200] + '...' if len(row[5]) > 200 else row[5],
                    'timestamp': row[6],
                    'importance_score': row[7],
                    'is_spam': bool(row[8]),
                    'is_read': bool(row[9]),
                    'labels': json.loads(row[10]) if row[10] else []
                }
                messages.append(message_data)
            
            conn.close()
            
            return {
                'success': True,
                'messages': messages,
                'total': len(messages)
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _api_get_stats(self) -> Dict[str, Any]:
        """קבלת סטטיסטיקות"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # סה"כ הודעות
            cursor.execute("SELECT COUNT(*) FROM messages")
            total_messages = cursor.fetchone()[0]
            
            # הודעות ספאם
            cursor.execute("SELECT COUNT(*) FROM messages WHERE is_spam = 1")
            spam_messages = cursor.fetchone()[0]
            
            # הודעות חשובות
            cursor.execute("SELECT COUNT(*) FROM messages WHERE importance_score >= 70")
            important_messages = cursor.fetchone()[0]
            
            # הודעות היום
            today = datetime.now().strftime('%Y-%m-%d')
            cursor.execute("SELECT COUNT(*) FROM messages WHERE date(timestamp) = ?", (today,))
            today_messages = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'success': True,
                'stats': {
                    'total_messages': total_messages,
                    'spam_messages': spam_messages,
                    'important_messages': important_messages,
                    'today_messages': today_messages,
                    'platforms_connected': len([p for p in self.platforms.values() if p.status == 'connected']),
                    'spam_percentage': round((spam_messages / max(total_messages, 1)) * 100, 1)
                }
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}


# Export המחלקה הראשית
__all__ = ['UltimateCommunicationUniverseModule']