#!/bin/bash

# Ultimate Communication Universe - Installation Script
# מרכז התקשורת הסופי - סקריפט התקנה מקיף
# 
# Author: shayAI
# Version: 1.0.0
# License: MIT

set -e  # Exit on any error

# ===== CONFIGURATION =====
MODULE_NAME="ultimate_communication_universe"
MODULE_VERSION="1.0.0"
PYTHON_MIN_VERSION="3.8"
REQUIRED_SPACE_MB=1024
INSTALL_DIR="/root/Effi_ai_privet/effi_ai_private/modules/${MODULE_NAME}"
TEMP_DIR="/tmp/${MODULE_NAME}_install"
LOG_FILE="/tmp/${MODULE_NAME}_install.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Unicode symbols
CHECK="✅"
CROSS="❌"
ARROW="➡️"
STAR="⭐"
ROCKET="🚀"
GEAR="⚙️"
PACKAGE="📦"

# ===== UTILITY FUNCTIONS =====

# Print colored output
print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Print section header
print_header() {
    local title=$1
    echo
    print_color $BLUE "=================================================="
    print_color $WHITE "  $title"
    print_color $BLUE "=================================================="
    echo
}

# Print success message
print_success() {
    print_color $GREEN "$CHECK $1"
}

# Print error message
print_error() {
    print_color $RED "$CROSS $1"
}

# Print warning message
print_warning() {
    print_color $YELLOW "⚠️  $1"
}

# Print info message
print_info() {
    print_color $CYAN "$ARROW $1"
}

# Log function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check Python version
check_python_version() {
    if command_exists python3; then
        local python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
        local required_version=$PYTHON_MIN_VERSION
        
        if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" = "$required_version" ]; then
            return 0
        else
            return 1
        fi
    else
        return 1
    fi
}

# Check available disk space
check_disk_space() {
    local available_space=$(df / | awk 'NR==2 {print $4}')
    local required_space=$((REQUIRED_SPACE_MB * 1024))
    
    if [ "$available_space" -gt "$required_space" ]; then
        return 0
    else
        return 1
    fi
}

# Create directory with proper permissions
create_directory() {
    local dir_path=$1
    local description=$2
    
    print_info "יוצר תיקייה: $description"
    
    if [ ! -d "$dir_path" ]; then
        mkdir -p "$dir_path"
        chmod 755 "$dir_path"
        log "Created directory: $dir_path"
        print_success "תיקייה נוצרה בהצלחה: $dir_path"
    else
        print_success "תיקייה כבר קיימת: $dir_path"
    fi
}

# Download file with progress
download_file() {
    local url=$1
    local output_path=$2
    local description=$3
    
    print_info "מוריד: $description"
    
    if command_exists wget; then
        wget --progress=bar:force "$url" -O "$output_path" 2>&1 | \
        while IFS= read -r line; do
            echo "$line"
        done
    elif command_exists curl; then
        curl -L --progress-bar "$url" -o "$output_path"
    else
        print_error "לא נמצא wget או curl להורדת קבצים"
        return 1
    fi
    
    if [ $? -eq 0 ]; then
        print_success "הורדה הושלמה: $description"
        log "Downloaded: $url -> $output_path"
        return 0
    else
        print_error "שגיאה בהורדת: $description"
        return 1
    fi
}

# Install Python package
install_python_package() {
    local package=$1
    print_info "מתקין חבילת Python: $package"
    
    if pip3 install "$package" --quiet --disable-pip-version-check; then
        print_success "חבילה הותקנה: $package"
        log "Installed Python package: $package"
        return 0
    else
        print_error "שגיאה בהתקנת חבילה: $package"
        return 1
    fi
}

# Create file with content
create_file() {
    local file_path=$1
    local content=$2
    local description=$3
    
    print_info "יוצר קובץ: $description"
    
    echo "$content" > "$file_path"
    chmod 644 "$file_path"
    
    if [ $? -eq 0 ]; then
        print_success "קובץ נוצר: $description"
        log "Created file: $file_path"
        return 0
    else
        print_error "שגיאה ביצירת קובץ: $description"
        return 1
    fi
}

# ===== MAIN INSTALLATION FUNCTIONS =====

# Welcome message
show_welcome() {
    clear
    print_color $PURPLE "
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           🚀 מרכז התקשורת הסופי 🚀                        ║
║        Ultimate Communication Universe                       ║
║                                                              ║
║  מודול מתקדם למערכת Effi-AI Private                         ║
║  ניהול מאוחד של כל התקשורת הדיגיטלית                      ║
║                                                              ║
║  גרסה: $MODULE_VERSION                                       ║
║  מפתח: shayAI                                               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"
    
    print_info "מתחיל תהליך התקנה..."
    sleep 2
}

# System checks
check_system_requirements() {
    print_header "$GEAR בדיקת דרישות מערכת"
    
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        print_error "יש להפעיל את הסקריפט כמשתמש root"
        print_info "הפעל: sudo $0"
        exit 1
    fi
    print_success "הרצה כמשתמש root"
    
    # Check Python version
    print_info "בודק גרסת Python..."
    if check_python_version; then
        local python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
        print_success "Python $python_version זמין (נדרש: $PYTHON_MIN_VERSION+)"
    else
        print_error "Python $PYTHON_MIN_VERSION+ לא נמצא"
        print_info "מתקין Python..."
        
        if command_exists apt-get; then
            apt-get update -qq
            apt-get install -y python3 python3-pip python3-venv
        elif command_exists yum; then
            yum install -y python3 python3-pip
        elif command_exists dnf; then
            dnf install -y python3 python3-pip
        else
            print_error "לא ניתן להתקין Python אוטומטית"
            exit 1
        fi
        
        if check_python_version; then
            print_success "Python הותקן בהצלחה"
        else
            print_error "התקנת Python נכשלה"
            exit 1
        fi
    fi
    
    # Check pip
    print_info "בודק pip..."
    if command_exists pip3; then
        print_success "pip3 זמין"
    else
        print_error "pip3 לא נמצא"
        exit 1
    fi
    
    # Check disk space
    print_info "בודק שטח דיסק..."
    if check_disk_space; then
        print_success "יש מספיק שטח דיסק (נדרש: ${REQUIRED_SPACE_MB}MB)"
    else
        print_error "אין מספיק שטח דיסק (נדרש: ${REQUIRED_SPACE_MB}MB)"
        exit 1
    fi
    
    # Check network connectivity
    print_info "בודק חיבור אינטרנט..."
    if ping -c 1 google.com >/dev/null 2>&1; then
        print_success "חיבור אינטרנט פעיל"
    else
        print_warning "בעיה בחיבור אינטרנט - יכולות מסוימות עלולות להיות מוגבלות"
    fi
    
    # Check system tools
    print_info "בודק כלי מערכת..."
    local missing_tools=()
    
    for tool in wget curl git unzip; do
        if ! command_exists "$tool"; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        print_info "מתקין כלים חסרים: ${missing_tools[*]}"
        
        if command_exists apt-get; then
            apt-get install -y "${missing_tools[@]}"
        elif command_exists yum; then
            yum install -y "${missing_tools[@]}"
        elif command_exists dnf; then
            dnf install -y "${missing_tools[@]}"
        fi
    fi
    
    print_success "כל דרישות המערכת מתקיימות"
    log "System requirements check completed successfully"
}

# Create directory structure
create_directory_structure() {
    print_header "$PACKAGE יצירת מבנה תיקיות"
    
    # Main module directory
    create_directory "$INSTALL_DIR" "תיקיית המודול הראשית"
    
    # Subdirectories
    local subdirs=(
        "css:קבצי עיצוב"
        "js:קבצי JavaScript"
        "html:תבניות HTML"
        "assets:נכסים"
        "assets/images:תמונות"
        "assets/images/icons:אייקונים"
        "assets/images/screenshots:צילומי מסך"
        "assets/sounds:צלילים"
        "docs:תיעוד"
        "examples:דוגמאות"
        "logs:לוגים"
        "config:הגדרות"
        "data:נתונים"
        "temp:קבצים זמניים"
    )
    
    for subdir_info in "${subdirs[@]}"; do
        IFS=':' read -r subdir desc <<< "$subdir_info"
        create_directory "$INSTALL_DIR/$subdir" "$desc"
    done
    
    # Create temp directory
    create_directory "$TEMP_DIR" "תיקיית התקנה זמנית"
    
    print_success "מבנה התיקיות נוצר בהצלחה"
}

# Install Python dependencies
install_dependencies() {
    print_header "$PACKAGE התקנת תלויות"
    
    print_info "מעדכן pip..."
    pip3 install --upgrade pip --quiet
    
    print_info "מתקין תלויות Python..."
    
    # Core dependencies
    local core_deps=(
        "requests>=2.31.0"
        "beautifulsoup4>=4.12.0"
        "schedule>=1.2.0"
        "websocket-client>=1.6.0"
        "aiohttp>=3.8.0"
        "cryptography>=41.0.0"
        "pyjwt>=2.8.0"
        "sqlalchemy>=2.0.20"
        "pydantic>=2.0.0"
    )
    
    for dep in "${core_deps[@]}"; do
        install_python_package "$dep"
    done
    
    # API dependencies
    print_info "מתקין תלויות API..."
    local api_deps=(
        "google-api-python-client>=2.100.0"
        "google-auth>=2.22.0"
        "google-auth-oauthlib>=1.0.0"
        "microsoft-graph>=1.0.0"
        "python-telegram-bot>=20.0"
        "facebook-sdk>=3.1.0"
    )
    
    for dep in "${api_deps[@]}"; do
        install_python_package "$dep" || print_warning "חבילה אופציונלית לא הותקנה: $dep"
    done
    
    # AI/ML dependencies
    print_info "מתקין תלויות AI..."
    local ai_deps=(
        "scikit-learn>=1.3.0"
        "nltk>=3.8.1"
        "textblob>=0.17.1"
    )
    
    for dep in "${ai_deps[@]}"; do
        install_python_package "$dep" || print_warning "חבילה אופציונלית לא הותקנה: $dep"
    done
    
    print_success "כל התלויות הותקנו בהצלחה"
}

# Copy module files
copy_module_files() {
    print_header "$PACKAGE העתקת קבצי המודול"
    
    local current_dir=$(pwd)
    
    # Main Python files
    print_info "מעתיק קבצי Python..."
    local python_files=(
        "__init__.py"
        "module.py"
        "test_module.py"
    )
    
    for file in "${python_files[@]}"; do
        if [ -f "$current_dir/$file" ]; then
            cp "$current_dir/$file" "$INSTALL_DIR/"
            print_success "הועתק: $file"
        else
            print_warning "קובץ לא נמצא: $file"
        fi
    done
    
    # Configuration files
    print_info "מעתיק קבצי הגדרה..."
    local config_files=(
        "metadata.json"
        "requirements.txt"
        "README.md"
        "manifest.json"
    )
    
    for file in "${config_files[@]}"; do
        if [ -f "$current_dir/$file" ]; then
            cp "$current_dir/$file" "$INSTALL_DIR/"
            print_success "הועתק: $file"
        fi
    done
    
    # Web files
    print_info "מעתיק קבצי אינטרנט..."
    if [ -f "$current_dir/index.html" ]; then
        cp "$current_dir/index.html" "$INSTALL_DIR/"
        print_success "הועתק: index.html"
    fi
    
    if [ -f "$current_dir/service-worker.js" ]; then
        cp "$current_dir/service-worker.js" "$INSTALL_DIR/"
        print_success "הועתק: service-worker.js"
    fi
    
    # Copy directories if they exist
    local dirs_to_copy=("css" "js" "html" "assets" "docs" "examples")
    
    for dir in "${dirs_to_copy[@]}"; do
        if [ -d "$current_dir/$dir" ]; then
            cp -r "$current_dir/$dir"/* "$INSTALL_DIR/$dir/" 2>/dev/null || true
            print_success "הועתק תיקייה: $dir"
        fi
    done
    
    print_success "כל קבצי המודול הועתקו"
}

# Create default configuration
create_default_config() {
    print_header "$GEAR יצירת הגדרות ברירת מחדל"
    
    # Create settings.json
    local settings_content='{
  "sync_interval": 60,
  "spam_threshold": 70,
  "auto_unsubscribe": true,
  "notification_sound": true,
  "rtl_support": true,
  "debug_mode": false,
  "max_platforms": 50,
  "backup_enabled": true,
  "log_level": "INFO",
  "server_port": 2020,
  "server_host": "0.0.0.0"
}'
    
    create_file "$INSTALL_DIR/config/settings.json" "$settings_content" "קובץ הגדרות ראשי"
    
    # Create platforms.json
    local platforms_content='{
  "email_platforms": {
    "gmail": {
      "enabled": false,
      "api_type": "oauth2",
      "scopes": ["https://www.googleapis.com/auth/gmail.readonly"]
    },
    "outlook": {
      "enabled": false,
      "api_type": "graph",
      "scopes": ["Mail.Read"]
    }
  },
  "social_platforms": {
    "whatsapp": {
      "enabled": false,
      "api_type": "business"
    },
    "telegram": {
      "enabled": false,
      "api_type": "bot"
    }
  }
}'
    
    create_file "$INSTALL_DIR/config/platforms.json" "$platforms_content" "הגדרות פלטפורמות"
    
    # Create spam_rules.json
    local spam_rules_content='{
  "rules": [
    {
      "id": "basic_spam_1",
      "name": "מילות פרסומת בסיסיות",
      "pattern": "(מבצע|הנחה|זכית|מתנה|חינם)",
      "type": "regex",
      "action": "spam",
      "score": 70,
      "enabled": true
    },
    {
      "id": "basic_spam_2", 
      "name": "הימורים",
      "pattern": "(הימור|קזינו|פוקר|רולטה)",
      "type": "regex",
      "action": "delete",
      "score": 90,
      "enabled": true
    }
  ],
  "whitelist": [],
  "blacklist": []
}'
    
    create_file "$INSTALL_DIR/config/spam_rules.json" "$spam_rules_content" "כללי ספאם"
    
    print_success "קבצי הגדרה נוצרו בהצלחה"
}

# Download assets
download_assets() {
    print_header "$PACKAGE הורדת נכסים"
    
    print_info "יוצר אייקונים בסיסיים..."
    
    # Create basic SVG icons
    local icon_svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <circle cx="50" cy="50" r="45" fill="#667eea"/>
  <path d="M25 35h50v30H25z" fill="white"/>
  <path d="M30 45h15v5H30zm20 0h15v5H50zm-20 10h40v5H30z" fill="#667eea"/>
</svg>'
    
    # Create icons in different sizes
    local icon_sizes=(16 32 48 72 96 128 144 152 192 384 512)
    
    for size in "${icon_sizes[@]}"; do
        # For this demo, we'll create the SVG files
        # In production, you'd want to generate proper PNG files
        create_file "$INSTALL_DIR/assets/images/icons/icon-${size}x${size}.svg" "$icon_svg" "אייקון ${size}x${size}"
    done
    
    # Create favicon
    create_file "$INSTALL_DIR/assets/images/icons/favicon.svg" "$icon_svg" "Favicon"
    
    # Create basic sounds directory structure
    create_directory "$INSTALL_DIR/assets/sounds" "תיקיית צלילים"
    
    print_info "יוצר קבצי צלילים בסיסיים..."
    
    # Create placeholder sound files (in production, use real audio files)
    touch "$INSTALL_DIR/assets/sounds/notification.mp3"
    touch "$INSTALL_DIR/assets/sounds/alert.mp3"
    touch "$INSTALL_DIR/assets/sounds/success.mp3"
    touch "$INSTALL_DIR/assets/sounds/error.mp3"
    
    print_success "נכסים נוצרו בהצלחה"
}

# Set permissions
set_permissions() {
    print_header "$GEAR הגדרת הרשאות"
    
    print_info "מגדיר הרשאות קבצים..."
    
    # Set directory permissions
    find "$INSTALL_DIR" -type d -exec chmod 755 {} \;
    
    # Set file permissions
    find "$INSTALL_DIR" -type f -exec chmod 644 {} \;
    
    # Make Python files executable
    find "$INSTALL_DIR" -name "*.py" -exec chmod 755 {} \;
    
    # Make shell scripts executable
    find "$INSTALL_DIR" -name "*.sh" -exec chmod 755 {} \;
    
    # Set special permissions for config files
    chmod 600 "$INSTALL_DIR/config"/*.json 2>/dev/null || true
    
    # Set permissions for logs directory
    chmod 777 "$INSTALL_DIR/logs" 2>/dev/null || true
    
    print_success "הרשאות הוגדרו בהצלחה"
}

# Create startup script
create_startup_script() {
    print_header "$ROCKET יצירת סקריפט הפעלה"
    
    local startup_script_content='#!/bin/bash

# Ultimate Communication Universe Startup Script
# מרכז התקשורת הסופי - סקריפט הפעלה

MODULE_DIR="'$INSTALL_DIR'"
PYTHON_CMD="python3"
LOG_FILE="$MODULE_DIR/logs/startup.log"

# Create log directory if it doesn'"'"'t exist
mkdir -p "$(dirname "$LOG_FILE")"

# Function to log messages
log() {
    echo "[$(date '"'"'+%Y-%m-%d %H:%M:%S'"'"')] $1" | tee -a "$LOG_FILE"
}

# Check if module directory exists
if [ ! -d "$MODULE_DIR" ]; then
    echo "Error: Module directory not found: $MODULE_DIR"
    exit 1
fi

# Change to module directory
cd "$MODULE_DIR"

# Check if Python is available
if ! command -v $PYTHON_CMD >/dev/null 2>&1; then
    echo "Error: Python not found"
    exit 1
fi

# Check if main module file exists
if [ ! -f "module.py" ]; then
    echo "Error: module.py not found"
    exit 1
fi

log "Starting Ultimate Communication Universe..."

# Start the module
$PYTHON_CMD module.py "$@" 2>&1 | tee -a "$LOG_FILE"

log "Ultimate Communication Universe stopped"
'
    
    create_file "/usr/local/bin/ultimate-communication" "$startup_script_content" "סקריפט הפעלה גלובלי"
    chmod +x "/usr/local/bin/ultimate-communication"
    
    # Create desktop entry for GUI systems
    if [ -d "/usr/share/applications" ]; then
        local desktop_entry='[Desktop Entry]
Name=מרכז התקשורת הסופי
Name[en]=Ultimate Communication Universe
Comment=מרכז פיקוד מאוחד לכל התקשורת הדיגיטלית
Comment[en]=Unified command center for all digital communication
Exec=/usr/local/bin/ultimate-communication
Icon='$INSTALL_DIR'/assets/images/icons/icon-128x128.svg
Terminal=false
Type=Application
Categories=Network;Office;Communication;
StartupNotify=true
Keywords=email;communication;messages;social;
'
        
        create_file "/usr/share/applications/ultimate-communication.desktop" "$desktop_entry" "קיצור דרך בשולחן העבודה"
        chmod 644 "/usr/share/applications/ultimate-communication.desktop"
    fi
    
    print_success "סקריפטי הפעלה נוצרו בהצלחה"
}

# Create systemd service
create_systemd_service() {
    print_header "$GEAR יצירת שירות מערכת"
    
    if [ -d "/etc/systemd/system" ]; then
        local service_content='[Unit]
Description=Ultimate Communication Universe
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory='$INSTALL_DIR'
ExecStart=/usr/bin/python3 '$INSTALL_DIR'/module.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
Environment=PYTHONPATH='$INSTALL_DIR'

[Install]
WantedBy=multi-user.target
'
        
        create_file "/etc/systemd/system/ultimate-communication.service" "$service_content" "שירות systemd"
        
        # Reload systemd and enable service
        systemctl daemon-reload
        systemctl enable ultimate-communication.service
        
        print_success "שירות מערכת נוצר והופעל"
        print_info "לניהול השירות:"
        print_info "  הפעלה: systemctl start ultimate-communication"
        print_info "  עצירה: systemctl stop ultimate-communication"
        print_info "  סטטוס: systemctl status ultimate-communication"
    else
        print_warning "systemd לא זמין - לא נוצר שירות מערכת"
    fi
}

# Run initial tests
run_tests() {
    print_header "$GEAR בדיקות ראשוניות"
    
    cd "$INSTALL_DIR"
    
    print_info "בודק import של המודול..."
    if python3 -c "import sys; sys.path.insert(0, '.'); import module; print('Import successful')" 2>/dev/null; then
        print_success "המודול נטען בהצלחה"
    else
        print_warning "בעיה בטעינת המודול - יכול להיות בגלל תלויות חסרות"
    fi
    
    print_info "בודק קבצי הגדרה..."
    local config_files=("config/settings.json" "config/platforms.json" "config/spam_rules.json")
    
    for config_file in "${config_files[@]}"; do
        if [ -f "$config_file" ]; then
            if python3 -c "import json; json.load(open('$config_file'))" 2>/dev/null; then
                print_success "קובץ הגדרה תקין: $config_file"
            else
                print_error "קובץ הגדרה פגום: $config_file"
            fi
        else
            print_error "קובץ הגדרה חסר: $config_file"
        fi
    done
    
    print_info "בודק הרשאות..."
    if [ -r "module.py" ] && [ -x "module.py" ]; then
        print_success "הרשאות קבצים תקינות"
    else
        print_warning "בעיה בהרשאות קבצים"
    fi
    
    print_success "בדיקות ראשוניות הושלמו"
}

# Cleanup temporary files
cleanup() {
    print_header "$GEAR ניקוי קבצים זמניים"
    
    if [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"
        print_success "קבצים זמניים נמחקו"
    fi
    
    # Clean pip cache
    pip3 cache purge >/dev/null 2>&1 || true
    
    print_success "ניקוי הושלם"
}

# Show completion message
show_completion() {
    clear
    print_color $GREEN "
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║               $CHECK התקנה הושלמה בהצלחה! $CHECK                 ║
║                                                              ║
║           מרכז התקשורת הסופי מוכן לשימוש                    ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"
    
    print_header "$ROCKET המערכת מותקנת ומוכנה!"
    
    print_success "המודול הותקן בתיקייה: $INSTALL_DIR"
    print_success "קבצי הגדרה נמצאים ב: $INSTALL_DIR/config/"
    print_success "לוגים יישמרו ב: $INSTALL_DIR/logs/"
    
    echo
    print_color $CYAN "🚀 דרכים להפעלת המערכת:"
    print_info "1. הפעלה ישירה: /usr/local/bin/ultimate-communication"
    print_info "2. דרך Python: cd $INSTALL_DIR && python3 module.py"
    
    if [ -f "/etc/systemd/system/ultimate-communication.service" ]; then
        print_info "3. דרך systemd: systemctl start ultimate-communication"
    fi
    
    echo
    print_color $CYAN "$GEAR הגדרות ראשוניות:"
    print_info "1. ערוך את הקובץ: $INSTALL_DIR/config/settings.json"
    print_info "2. הגדר את פרטי החיבור לפלטפורמות השונות"
    print_info "3. התאם את כללי הספאם לפי הצרכים שלך"
    
    echo
    print_color $CYAN "🌐 גישה לממשק:"
    print_info "לאחר הפעלה, פתח דפדפן וגש לכתובת:"
    print_info "http://localhost:2020"
    print_info "או http://10.100.102.200:2020 (גישה חיצונית)"
    
    echo
    print_color $CYAN "📚 תיעוד ועזרה:"
    print_info "קובץ README: $INSTALL_DIR/README.md"
    print_info "דוגמאות: $INSTALL_DIR/examples/"
    print_info "תיעוד מלא: $INSTALL_DIR/docs/"
    
    echo
    print_color $CYAN "🔧 פתרון בעיות:"
    print_info "לוגי התקנה: $LOG_FILE"
    print_info "לוגי המערכת: $INSTALL_DIR/logs/"
    print_info "לבדיקת סטטוס: systemctl status ultimate-communication"
    
    echo
    print_color $YELLOW "⚠️  הערות חשובות:"
    print_warning "1. הגדר את פרטי ה-API לפני השימוש הראשון"
    print_warning "2. ודא שהפורט 2020 פתוח בחומת האש"
    print_warning "3. בצע גיבוי של קבצי ההגדרות לפני שינויים"
    
    echo
    print_color $GREEN "$STAR תודה שבחרת במרכז התקשורת הסופי! $STAR"
    print_info "גרסה: $MODULE_VERSION"
    print_info "מפתח: shayAI"
    print_info "רישיון: MIT"
    
    echo
}

# Error handler
error_handler() {
    local line_number=$1
    print_error "שגיאה בשורה $line_number"
    print_error "ההתקנה נפסקה"
    
    # Show log file location
    if [ -f "$LOG_FILE" ]; then
        print_info "לפרטי השגיאה, ראה: $LOG_FILE"
    fi
    
    # Cleanup on error
    cleanup
    
    exit 1
}

# ===== MAIN INSTALLATION PROCESS =====

# Set error handler
trap 'error_handler $LINENO' ERR

# Create log file
mkdir -p "$(dirname "$LOG_FILE")"
touch "$LOG_FILE"

# Start logging
log "Starting Ultimate Communication Universe installation"
log "Version: $MODULE_VERSION"
log "Install directory: $INSTALL_DIR"

# Main installation steps
main() {
    show_welcome
    check_system_requirements
    create_directory_structure
    install_dependencies
    copy_module_files
    create_default_config
    download_assets
    set_permissions
    create_startup_script
    create_systemd_service
    run_tests
    cleanup
    show_completion
    
    log "Installation completed successfully"
}

# Run main function
main "$@"

# Success exit
exit 0