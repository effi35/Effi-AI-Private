#!/bin/bash

echo 'מתקין את Effi-AI Prompt Generator Pro...'
pip3 install -r requirements.txt
python3 effi_prompt_generator.py
